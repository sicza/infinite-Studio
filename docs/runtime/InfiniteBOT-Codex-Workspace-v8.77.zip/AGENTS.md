# Project Visual Production Workspace

Collection → `$workspace-collection`（无 Authority 省略）。一 Workspace 一项目：首会话建项目事实 + Baseline，之后复用。

## 权责

Workspace 管路由/状态/依赖/恢复/提交；Skill 管方法与准出；Agent 产真实产物；Human 判质量。

技术检查只证技术事实（文件/输入/尺寸/API/衍生/完整性）；自评、reviewer、字数、重复 Hash 不证质量、不阻断交付。用户要求最高优先。

## 入口

首请求初始化：Windows `.agents\scripts\workspace_bootstrap.cmd`，其他 `.sh`；阻断时用 `.agents\runtime\toolchain\venv\Scripts\python.exe -X utf8 .agents\scripts\workspace_init.py initialize --workspace-root .`。每工作区一次，续接读 init-status。初始化不检查 API Key；联网前强制检查 Key。按返回状态继续；`visual-check` 保 Baseline 未过期，`resize` 等节点不被前置阻断。

会话开始先看 `.agents/runtime/update-required.json`：存在时先提醒用户并询问是否更新；用户明确同意后才运行 `python .agents/scripts/runtime_update.py --apply`（完成后重开会话），拒绝则继续当前需求。

## 读取纪律

- 先 `runtime_text.py outline --path <p>`，再 `view --path <p> [--start N] [--lines N]`；Hash 用 `hash --path <p>`。
- 不整读大文件、不把 `.py` 当文档；`rg -n` 定位后只读所需段；同会话同文件不重复整读。
- Gate 失败看 `error_code`/`next_action`，只重跑失败节点。
- Python 一律 `-X utf8`，不用 `chcp/copy`；状态不明先跑 `workspace_gate.py status --request <r>`。

## 事实

优先级：用户要求/input > Brief + 正式 Baseline + material-index > 专业推断；Reference 只供方法证据。

UTF-8 原子写入，Promote 前跑 text-integrity。Personal Layer 默认关（`user/manifest.json` enabled=false）；启用时 `$workspace-personal-skill` 写 `work/personal-context.json`，Primary Skill 消费时校验，不匹配即阻断。

## 需求与路由

新目标进 `$workspace-demand-intake`：只补 blocking 信息，不重复问、不用"确认"刷状态；续接/返修/补素材/交付回原 request。`.agents/lib/request_routing.py` 是 `request_type→primary_skill→production_branch` 唯一路由表。

只做需要的节点：只要方案/Prompt 就交；未明确要图像/HTML/品牌生态不升级规模。`wxian-image-production` 由 `work/requirement-lock.md` 锁唯一 `production_branch`。

## 生命周期

`request.md` 人类可读，不作凭证 Hash；`requirement-lock.md` 是机器意图源，批准不得写入。审批是独立事件 `work/approvals.jsonl`：`workspace_gate.py record-approval --request <r> --candidate-id <id> --mode user|auto_authorized --evidence "<原话>"`；追加批准不使候选失效，实质变化才过期。入口命令见 `$workspace-governance`。

返修定位最早责任层（requirement→reference→prompt→model→layout→postprocess→delivery），不全链重启；旧 request 可续接，证据不覆写，旧调用按 legacy 读。

## 生成

每轮 1 个候选，不覆盖历史；用真实调用记录（success/network_called/hash/尺寸）。新调用记 `intent_binding`，旧调用按 legacy 登记。专业审图可选，默认不作确认/交付前提。`pure_visual_image` 可复用干净母版（同路径同 Hash）；确需清文字/LOGO/UI 才 edit。

## 交付

最终阶段打开关键输入与正式文件；技术项由 Gate 验证，质量交人。`$workspace-governance promote` 是唯一提交入口，生成 revision/output manifest 并写 `completed`，之后 `$workspace-user-feedback` 登记 revision。

子 Agent 只做边界清晰子任务：交接给必要事实、相关文件与验收标准，允许为验证结论独立取证，产出落盘只回摘要与贡献；主 Agent 判断/收敛/交付。fork 与 fresh 都按实际成本选择，不默认 fork 更省。并行写同一共享文件时只保留一个写者。不得新增全局审计 Agent、评分或 Token Gate、重复证明。
