#!/usr/bin/env python3
"""Advisory, fail-open Runtime release check for Codex SessionStart."""
from __future__ import annotations

import os as _bytecode_guard_os, sys as _bytecode_guard_sys
_bytecode_guard_sys.dont_write_bytecode = True
_bytecode_guard_os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import argparse
import io
import json
import math
import re
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from urllib.request import Request, urlopen

AGENTS_ROOT = Path(__file__).resolve().parents[1]
if str(AGENTS_ROOT / "lib") not in sys.path:
    sys.path.insert(0, str(AGENTS_ROOT / "lib"))
from atomic_io import atomic_write_text
import runtime_update_state as update_state

SCHEMA_VERSION = 1
CHANNEL = "stable"
EXPECTED_FEED_URL = "https://sicza.github.io/infinite-Studio/latest.json"
MAX_RESPONSE_BYTES = 4096
NETWORK_TIMEOUT_SECONDS = 1.5
CACHE_TTL_SECONDS = 1800
VERSION_RE = re.compile(r"^V(\d+)\.(\d+)$")


class VersionCheckError(RuntimeError):
    pass


def parse_version(value: Any) -> tuple[int, int]:
    if not isinstance(value, str):
        raise VersionCheckError("version must be a string")
    match = VERSION_RE.fullmatch(value)
    if not match:
        raise VersionCheckError("version must match V<major>.<minor>")
    return int(match.group(1)), int(match.group(2))


def validate_local_release(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise VersionCheckError("local release marker must be an object")
    schema_version = value.get("schema_version")
    if type(schema_version) is not int or schema_version != SCHEMA_VERSION or value.get("channel") != CHANNEL:
        raise VersionCheckError("local release marker schema/channel mismatch")
    parse_version(value.get("version"))
    feed_url = value.get("version_feed_url")
    if feed_url != EXPECTED_FEED_URL:
        raise VersionCheckError("local release feed URL is not trusted")
    return value


def load_local_release(script_path: Path | None = None) -> dict[str, Any]:
    script = (script_path or Path(__file__)).resolve()
    root = script.parents[2]
    marker = root / ".agents" / "runtime-release.json"
    try:
        value = json.loads(marker.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise VersionCheckError("local release marker is unreadable") from exc
    return validate_local_release(value)


def cache_path(script_path: Path | None = None) -> Path:
    script = (script_path or Path(__file__)).resolve()
    return script.parents[2] / ".agents" / "runtime" / "version-check-cache.json"


def load_cached_remote(local: dict[str, Any], *, script_path: Path | None = None) -> dict[str, Any] | None | bool:
    path = cache_path(script_path)
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        checked_at = float(value["checked_at"])
        age = time.time() - checked_at
        if (value.get("local_version") != local["version"]
                or value.get("feed_url") != local["version_feed_url"]
                or not math.isfinite(checked_at)
                or age < 0
                or age >= CACHE_TTL_SECONDS):
            return False
        remote = value.get("remote")
        return validate_remote_release(remote) if remote is not None else None
    except Exception:
        return False


def write_cached_remote(local: dict[str, Any], remote: dict[str, Any] | None,
                        *, script_path: Path | None = None) -> None:
    path = cache_path(script_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "local_version": local["version"],
        "feed_url": local["version_feed_url"],
        "checked_at": time.time(),
        "remote": remote,
    }
    atomic_write_text(path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")


def validate_remote_release(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise VersionCheckError("remote release manifest must be an object")
    schema_version = value.get("schema_version")
    if type(schema_version) is not int or schema_version != SCHEMA_VERSION or value.get("channel") != CHANNEL:
        raise VersionCheckError("remote release manifest schema/channel mismatch")
    version = value.get("latest_version")
    parse_version(version)
    filename = value.get("release_filename")
    if filename != f"InfiniteBOT-Codex-Workspace-v{version[1:]}.zip":
        raise VersionCheckError("remote release filename/version mismatch")
    digest = value.get("release_sha256")
    if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-fA-F]{64}", digest):
        raise VersionCheckError("remote release SHA-256 is invalid")
    if not isinstance(value.get("published_at"), str) or not value["published_at"].strip():
        raise VersionCheckError("remote release timestamp is invalid")
    return value


def fetch_remote_release(
    feed_url: str,
    *,
    opener: Callable[..., Any] = urlopen,
) -> dict[str, Any]:
    request = Request(
        feed_url,
        headers={
            "Accept": "application/json",
            "Cache-Control": "no-cache",
            "User-Agent": "InfiniteBOT-Runtime-Version-Check/1",
        },
    )
    with opener(request, timeout=NETWORK_TIMEOUT_SECONDS) as response:
        if response.geturl() != EXPECTED_FEED_URL:
            raise VersionCheckError("version feed redirected away from the trusted URL")
        if getattr(response, "status", response.getcode()) != 200:
            raise VersionCheckError("version feed did not return HTTP 200")
        content_type = str(response.headers.get("Content-Type", "")).split(";", 1)[0].strip().lower()
        if content_type != "application/json":
            raise VersionCheckError("version feed is not JSON")
        payload = response.read(MAX_RESPONSE_BYTES + 1)
    if len(payload) > MAX_RESPONSE_BYTES:
        raise VersionCheckError("version feed exceeds the size limit")
    try:
        value = json.loads(payload.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise VersionCheckError("version feed contains invalid JSON") from exc
    return validate_remote_release(value)


def update_message(local: dict[str, Any], remote: dict[str, Any]) -> str | None:
    current = str(local["version"])
    latest = str(remote["latest_version"])
    if parse_version(latest) <= parse_version(current):
        return None
    return (
        f"检测到 InfiniteBOT Codex Workspace 新版本：当前 {current}，最新 {latest}。"
        f"是否现在更新？同意后运行 `{update_state.update_command()}`（完成后重开会话）；"
        "不更新就继续当前需求。"
    )


def _workspace_root(script_path: Path | None = None) -> Path:
    return (script_path or Path(__file__)).resolve().parents[2]


def _apply_remote(local: dict[str, Any], remote: dict[str, Any],
                  script_path: Path | None = None) -> dict[str, Any] | None:
    root = _workspace_root(script_path)
    if parse_version(remote["latest_version"]) > parse_version(local["version"]):
        update_state.write(
            root,
            local_version=str(local["version"]),
            latest_version=str(remote["latest_version"]),
            release_filename=str(remote["release_filename"]),
            release_sha256=str(remote["release_sha256"]),
        )
        message = update_message(local, remote)
        return {"continue": True, "systemMessage": message} if message else None
    update_state.clear(root)
    return None


def check_for_update(*, opener: Callable[..., Any] = urlopen, script_path: Path | None = None) -> dict[str, Any] | None:
    """Return a SessionStart payload. Never blocks on network/parse failure."""
    try:
        local = load_local_release(script_path)
        cached = load_cached_remote(local, script_path=script_path)
        if cached is not False:
            return _apply_remote(local, cached, script_path) if isinstance(cached, dict) else None
        remote = fetch_remote_release(str(local["version_feed_url"]), opener=opener)
        write_cached_remote(local, remote, script_path=script_path)
        return _apply_remote(local, remote, script_path)
    except Exception:
        return None


class _FakeResponse:
    def __init__(self, payload: bytes, *, url: str = "https://sicza.github.io/infinite-Studio/latest.json",
                 content_type: str = "application/json", status: int = 200):
        self.payload = payload
        self.url = url
        self.headers = {"Content-Type": content_type}
        self.status = status

    def __enter__(self) -> "_FakeResponse":
        return self

    def __exit__(self, *_: object) -> None:
        return None

    def geturl(self) -> str:
        return self.url

    def getcode(self) -> int:
        return self.status

    def read(self, size: int = -1) -> bytes:
        return self.payload if size < 0 else self.payload[:size]


def self_test() -> dict[str, Any]:
    base = {
        "schema_version": 1,
        "channel": "stable",
        "latest_version": "V8.61",
        "release_filename": "InfiniteBOT-Codex-Workspace-v8.61.zip",
        "release_sha256": "a" * 64,
        "published_at": "2026-09-22T00:00:00+00:00",
    }
    assert parse_version("V8.10") > parse_version("V8.9")
    assert update_message({"version": "V8.61"}, base) is None
    assert update_message({"version": "V8.60"}, base) is not None
    assert update_message({"version": "V9.0"}, base) is None
    assert "remote_copy" not in (update_message({"version": "V8.60"}, {**base, "remote_copy": "run me"}) or "")
    payload = json.dumps(base).encode("utf-8")
    parsed = fetch_remote_release(
        "https://sicza.github.io/infinite-Studio/latest.json",
        opener=lambda *_args, **_kwargs: _FakeResponse(payload),
    )
    assert parsed["latest_version"] == "V8.61"
    rejected = 0
    bad_cases = [
        _FakeResponse(b"not-json"),
        _FakeResponse(payload, url="https://example.com/latest.json"),
        _FakeResponse(payload, url="https://sicza.github.io/infinite-Studio/wrong.json"),
        _FakeResponse(payload, url="https://sicza.github.io/infinite-Studio/latest.json?shadow=1"),
        _FakeResponse(payload, content_type="text/html"),
        _FakeResponse(payload, content_type="application/jsonp"),
        _FakeResponse(payload, status=500),
        _FakeResponse(b"{" + b"x" * MAX_RESPONSE_BYTES + b"}"),
        _FakeResponse(json.dumps({**base, "schema_version": True}).encode("utf-8")),
    ]
    for response in bad_cases:
        try:
            fetch_remote_release(
                "https://sicza.github.io/infinite-Studio/latest.json",
                opener=lambda *_args, _response=response, **_kwargs: _response,
            )
        except VersionCheckError:
            rejected += 1
    assert rejected == len(bad_cases)
    local_rejected = 0
    for bad_schema, bad_url in (
        (True, EXPECTED_FEED_URL),
        (SCHEMA_VERSION, "https://sicza.github.io/infinite-Studio/wrong.json"),
        (SCHEMA_VERSION, "https://sicza.github.io/infinite-Studio/latest.json?shadow=1"),
    ):
        try:
            validate_local_release({
                "schema_version": bad_schema,
                "channel": "stable",
                "version": "V8.63",
                "version_feed_url": bad_url,
            })
        except VersionCheckError:
            local_rejected += 1
    assert local_rejected == 3
    with tempfile.TemporaryDirectory(prefix="runtime-version-cache-") as temp_dir:
        script_path = Path(temp_dir) / ".agents/scripts/runtime_version_check.py"
        cache = cache_path(script_path)
        cache.parent.mkdir(parents=True)
        local = {
            "version": "V8.61",
            "version_feed_url": "https://sicza.github.io/infinite-Studio/latest.json",
        }
        for invalid_checked_at in (time.time() + CACHE_TTL_SECONDS, float("nan")):
            cache.write_text(json.dumps({
                "local_version": local["version"],
                "feed_url": local["version_feed_url"],
                "checked_at": invalid_checked_at,
                "remote": base,
            }), encoding="utf-8")
            assert load_cached_remote(local, script_path=script_path) is False
    with tempfile.TemporaryDirectory(prefix="runtime-version-state-") as temp_dir:
        root = Path(temp_dir)
        script_path = root / ".agents/scripts/runtime_version_check.py"
        script_path.parent.mkdir(parents=True)
        marker_path = root / ".agents/runtime-release.json"

        def write_marker(version: str) -> None:
            marker_path.write_text(json.dumps({
                "schema_version": 1,
                "channel": "stable",
                "version": version,
                "version_feed_url": EXPECTED_FEED_URL,
            }), encoding="utf-8")

        write_marker("V8.61")
        newer = {**base, "latest_version": "V8.62",
                 "release_filename": "InfiniteBOT-Codex-Workspace-v8.62.zip"}
        result = check_for_update(
            script_path=script_path,
            opener=lambda *_a, **_k: _FakeResponse(json.dumps(newer).encode("utf-8")),
        )
        assert result is not None and "V8.62" in result["systemMessage"]
        assert update_state.pending(root) is not None
        write_marker("V8.62")
        result = check_for_update(
            script_path=script_path,
            opener=lambda *_a, **_k: _FakeResponse(json.dumps(newer).encode("utf-8")),
        )
        assert result is None
        assert update_state.pending(root) is None
        assert not update_state.update_required_path(root).exists()
    return {"status": "passed", "checks": 23, "rejected_bad_cases": rejected,
            "rejected_local_type_confusions": local_rejected,
            "update_gate_state": "passed"}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        print(json.dumps(self_test(), ensure_ascii=False))
        return 0
    result = check_for_update()
    if result is not None:
        print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
