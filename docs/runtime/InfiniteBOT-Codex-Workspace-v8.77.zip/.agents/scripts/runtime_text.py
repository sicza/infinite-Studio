#!/usr/bin/env python3
"""Safe UTF-8 text viewing, outlining and hashing for a Windows Codex Workspace.

The Runtime writes UTF-8 files, but the host console is often code-page 936 and
`more` / `type` / `certutil` either mojibake the text or require shell tricks.
This command gives the Agent one deterministic read path with UTF-8 stdout and
bounded line ranges, plus a portable hash command and a compact structural
outline so a large file can be read in sections instead of whole.
"""
from __future__ import annotations
import argparse
import ast
import hashlib
import json
import re
import sys
from pathlib import Path

OUTLINE_MD_SUFFIXES = {".md", ".markdown"}
OUTLINE_PY_SUFFIXES = {".py", ".pyw"}
OUTLINE_JSON_SUFFIXES = {".json"}
_MD_HEADING = re.compile(r"^(#{1,6})\s+(.+?)\s*$")


def _configure_stdout() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _jsonable(value: object) -> object:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, list):
        return [f"array[{len(value)}]"]
    if isinstance(value, dict):
        return [f"object[{len(value)}]"]
    return type(value).__name__


def _outline(text: str, kind: str) -> tuple[list[dict], str | None]:
    """Return compact structural entries plus an optional parse error message."""
    if kind == "markdown":
        entries: list[dict] = []
        fenced = False
        for number, line in enumerate(text.splitlines(), start=1):
            stripped = line.lstrip()
            if stripped.startswith("```") or stripped.startswith("~~~"):
                fenced = not fenced
                continue
            if fenced:
                continue
            match = _MD_HEADING.match(line)
            if match:
                entries.append({"line": number, "level": len(match.group(1)), "text": match.group(2)})
        return entries, None
    if kind == "python":
        try:
            tree = ast.parse(text)
        except SyntaxError as exc:
            return [], f"{exc.msg} (line {exc.lineno})"
        entries = []
        for node in tree.body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                entries.append({"line": node.lineno, "kind": "def", "name": node.name})
            elif isinstance(node, ast.ClassDef):
                entries.append({"line": node.lineno, "kind": "class", "name": node.name})
        return entries, None
    if kind == "json":
        try:
            value = json.loads(text)
        except json.JSONDecodeError as exc:
            return [], f"{exc.msg} (line {exc.lineno})"
        if isinstance(value, dict):
            return [{"key": key, "type": _jsonable(value[key])} for key in sorted(value)], None
        return [{"key": "$", "type": _jsonable(value)}], None
    return [], None


def _outline_kind(path: Path) -> str:
    suffix = path.suffix.casefold()
    if suffix in OUTLINE_MD_SUFFIXES:
        return "markdown"
    if suffix in OUTLINE_PY_SUFFIXES:
        return "python"
    if suffix in OUTLINE_JSON_SUFFIXES:
        return "json"
    return "text"


def _print_outline(path: Path, text: str, as_json: bool) -> None:
    kind = _outline_kind(path)
    entries, parse_error = _outline(text, kind)
    total = len(text.splitlines())
    payload = {
        "status": "ready",
        "path": str(path),
        "kind": kind,
        "lines": total,
        "bytes": path.stat().st_size,
        "sha256": _sha256(path),
        "outline": entries,
    }
    if parse_error:
        payload["parse_error"] = parse_error
    if as_json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return
    print(f"# {path}  kind={kind}  lines {total}  bytes {payload['bytes']}  sha256={payload['sha256']}")
    if parse_error:
        print(f"# parse_error: {parse_error}")
    for item in entries:
        if kind == "markdown":
            print(f"{item['line']:>5}: {'  ' * (item['level'] - 1)}{'#' * item['level']} {item['text']}")
        elif kind == "json":
            print(f"{item['key']}: {item['type']}")
        else:
            print(f"{item['line']:>5}: {item['kind']} {item['name']}")


def main() -> int:
    _configure_stdout()
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="command", required=True)

    view = sub.add_parser("view")
    view.add_argument("--path", required=True)
    view.add_argument("--start", type=int, default=1)
    view.add_argument("--lines", type=int, default=160)
    view.add_argument("--json", action="store_true")

    hash_cmd = sub.add_parser("hash")
    hash_cmd.add_argument("--path", required=True)
    hash_cmd.add_argument("--json", action="store_true")

    outline = sub.add_parser("outline", help="headings / top-level defs / top-level JSON keys plus size and hash")
    outline.add_argument("--path", required=True)
    outline.add_argument("--json", action="store_true")

    args = ap.parse_args()
    path = Path(args.path).resolve()
    if not path.is_file():
        print(json.dumps({"status": "blocked", "error_code": "file_missing", "target": str(path),
                          "reason": "file does not exist", "next_action": "check the path"},
                         ensure_ascii=False))
        return 2
    if args.command == "hash":
        digest = _sha256(path)
        if args.json:
            print(json.dumps({"status": "ready", "path": str(path), "sha256": digest, "bytes": path.stat().st_size},
                             ensure_ascii=False))
        else:
            print(digest)
        return 0

    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError as exc:
        print(json.dumps({"status": "blocked", "error_code": "not_utf8", "target": str(path),
                          "reason": f"file is not UTF-8 text: {exc}",
                          "next_action": "use a binary/hash path instead of text view"}, ensure_ascii=False))
        return 2
    if args.command == "outline":
        # Host editors on Windows may save a UTF-8 BOM; the Runtime itself does not write one,
        # but an outline must not turn a readable file into a fake parse error.
        _print_outline(path, text.lstrip("\ufeff"), args.json)
        return 0
    lines = text.splitlines()
    total = len(lines)
    start = max(1, args.start)
    count = max(1, args.lines)
    end = min(total, start + count - 1)
    chunk = lines[start - 1:end] if start <= total else []
    body = "\n".join(f"{number:>5}: {line}" for number, line in enumerate(chunk, start=start))
    if args.json:
        print(json.dumps({"status": "ready", "path": str(path), "sha256": _sha256(path), "total_lines": total,
                          "start": start, "end": end, "text": "\n".join(chunk)}, ensure_ascii=False, indent=2))
    else:
        print(f"# {path}  lines {start}-{end}/{total}  sha256={_sha256(path)}")
        print(body)
    return 0


if __name__ == "__main__":
    sys.exit(main())
