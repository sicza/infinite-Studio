#!/usr/bin/env python3
"""Create/validate request-bound Narrative→Visual→Prompt→Gate evidence. No provider/API calls."""
from __future__ import annotations

import argparse, json, shutil, sys, tempfile
from pathlib import Path

AGENTS_ROOT = Path(__file__).resolve().parents[1]
LIB = AGENTS_ROOT / "lib"
if str(LIB) not in sys.path: sys.path.insert(0, str(LIB))
from request_identity import identity as request_identity
from atomic_io import atomic_write_text
from visual_contracts import (
    VisualContractError, load_json, registry, semantic_checksum, sha256_file,
    validate_baseline_consumption, validate_narrative_contract, validate_prompt_binding,
    validate_schema, validate_visual_gate_result, validate_visual_return, validate_visual_spec,
    schema, workspace_relative,
)


def write_json(path: Path, value: dict) -> None:
    atomic_write_text(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def root_path(root: Path, value: Path) -> Path:
    """Resolve a CLI path against --workspace-root, not against the caller's CWD."""
    path = Path(value)
    return (root / path).resolve() if not path.is_absolute() else path.resolve()


def compiler_profile(name: str) -> dict:
    profiles = registry("prompt-compiler-profiles.json", "sicza.prompt-compiler-profiles.v1")
    value = profiles.get(name)
    if not isinstance(value, dict): raise VisualContractError(f"unknown prompt compiler profile: {name}")
    return value


def positive_spec(root: Path, request: Path, *, profile_id: str = "visual.still.production.v1") -> dict:
    ident=request_identity(root,request); req=workspace_relative(root,request)
    return {
        "schema_version":"sicza.visual-spec.v2",**ident,"profile_id":profile_id,"mode":"CREATE","task_kind":"still",
        "authority_trace":[{"role":"current_request","path":f"{req}/request.md","sha256":sha256_file(request/'request.md')}],
        "narrative_trace":None,
        "intent":{"primary":"make the requested subject immediately legible","visual_logic":"display"},
        "truth_protection":{"protect":["locked subject identity"]},
        "world_space":{"space":"one coherent grounded scene"},
        "performance":{},
        "projection":{"camera":"stable readable perspective"},
        "appearance":{"surface":"material response remains coherent"},
        "image_structure":{"hierarchy":"clear first and second read"},
        "image_formation":{"focus":"focus and edge hierarchy match intent"},
        "graphic":{},"identity":{"lock":"preserve required identity"},"channel_roles":{"lead":["identity"],"support":["projection"],"suppress":["background detail"]},"motion":None,"change_set":{},
        "success_condition":["target remains readable at delivery size"],"unresolved":[]
    }


def semantic_selftest() -> dict:
    """Exercise both positive evidence and audit-derived bypass attempts without provider calls."""
    from PIL import Image
    results={}
    with tempfile.TemporaryDirectory(prefix="visual-contract-selftest-") as td:
        root=Path(td)
        profile=compiler_profile("image.generic.v1")
        pack_rel=Path(profile["prompt_pack"]); pack=root/pack_rel; pack.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(AGENTS_ROOT.parent/pack_rel,pack)
        for name in ("a","b"):
            req=root/"requests"/"image-generation"/name
            (req/"input").mkdir(parents=True); (req/"work").mkdir(); (req/"output").mkdir()
            (req/"request.md").write_text(f"request {name}\n",encoding="utf-8")
            write_json(req/"state.json",{"primary_skill":"wxian-image-production","status":"active","revision":1})
            (req/"work"/"requirement-lock.md").write_text("production_branch: new-generation\n",encoding="utf-8")
        req=root/"requests"/"image-generation"/"a"; other=root/"requests"/"image-generation"/"b"; ident=request_identity(root,req)
        spec=positive_spec(root,req); spec_path=req/"work"/"visual-spec.json"; prompt=req/"work"/"prompt-package.md"; binding_path=req/"work"/"prompt-binding.json"; report_path=req/"work"/"independent-visual-review.json"; gate_path=req/"work"/"visual-gate-result.json"; target=req/"work"/"candidate.png"
        prompt.write_text("display make the requested subject immediately legible identity projection background detail, coherent readable hierarchy\n",encoding="utf-8")
        Image.new("RGBA",(4,3),(64,96,128,255)).save(target)

        def consumption(current):
            roles=current["channel_roles"]; intent=current["intent"]
            values=[("intent.visual_logic",intent["visual_logic"],intent["visual_logic"]),("intent.primary",intent["primary"],intent["primary"]),("channel_roles.lead",roles["lead"]," ".join(roles["lead"]))]
            if roles.get("support"): values.append(("channel_roles.support",roles["support"]," ".join(roles["support"])))
            if roles.get("suppress"): values.append(("channel_roles.suppress",roles["suppress"],"background detail"))
            return [{"field":field,"value":value,"prompt_evidence":[evidence]} for field,value,evidence in values]

        def refresh_chain():
            write_json(spec_path,spec)
            binding={"schema_version":"sicza.prompt-binding.v2",**ident,"visual_spec_path":workspace_relative(root,spec_path),"visual_spec_sha256":sha256_file(spec_path),"narrative_semantic_checksum":None,"prompt_path":workspace_relative(root,prompt),"prompt_sha256":sha256_file(prompt),"compiler_profile":"image.generic.v1","adapter_family":profile["adapter_family"],"prompt_pack_path":profile["prompt_pack"],"prompt_pack_sha256":sha256_file(pack),"spec_consumption":consumption(spec)}
            write_json(binding_path,binding)
            report={"schema_version":"sicza.visual-independent-review.v2",**ident,"reviewer_id":"independent-visual-reviewer","producer_id":"image-production-producer","target_path":workspace_relative(root,target),"target_sha256":sha256_file(target),"visual_spec_sha256":sha256_file(spec_path),"prompt_binding_sha256":sha256_file(binding_path),"review_methods":["sicza-visual-director/DIAGNOSE"],"source_bindings":[{"role":"current_request","path":workspace_relative(root,req/'request.md'),"sha256":sha256_file(req/'request.md')},{"role":"requirement_lock","path":workspace_relative(root,req/'work'/'requirement-lock.md'),"sha256":sha256_file(req/'work'/'requirement-lock.md')}],"verdict":"PASS","review_narrative":"The independent reviewer inspected the exact full-resolution target and a thumbnail against the untouched user request, then diagnosed the primary read, relationships, hierarchy, physical integrity, and delivery fitness without treating the producer Visual Spec as authority over the original demand.","observations":["Independent reviewer inspected the exact decoded target against the original demand and bound production evidence."]}
            write_json(report_path,report)
            ev={"target_path":workspace_relative(root,target),"target_sha256":sha256_file(target),"observation":"observable target evidence is bound to this exact decoded image file"}
            gates=[{"gate":name,"result":"PASS","evidence":[dict(ev)],"owner":"sicza-visual-director"} for name in ["VG-INTENT","VG-INTEGRITY","VG-HIERARCHY","VG-COHERENCE","VG-DELIVERY-FIT"]]
            review={"reviewer_id":report["reviewer_id"],"producer_id":report["producer_id"],"review_report_path":workspace_relative(root,report_path),"review_report_sha256":sha256_file(report_path),"verdict":"PASS","decoded_target":{"format":"PNG","width":4,"height":3,"mode":"RGBA"}}
            gate={"schema_version":"sicza.visual-gate-result.v3",**ident,"gate_profile":"gate.visual.production.v1","target_path":workspace_relative(root,target),"target_sha256":sha256_file(target),"visual_spec_path":workspace_relative(root,spec_path),"visual_spec_sha256":sha256_file(spec_path),"prompt_binding_path":workspace_relative(root,binding_path),"prompt_binding_sha256":sha256_file(binding_path),"result":"VISUAL_PASS","gates":gates,"reviewer":report["reviewer_id"],"independent_review":review}
            write_json(gate_path,gate)
            return binding,gate

        binding,gate=refresh_chain()
        validate_visual_spec(root,spec_path); validate_prompt_binding(root,binding_path); validate_visual_gate_result(root,gate_path); results["positive_chain"]="PASS"

        def blocked(name, fn):
            try: fn()
            except (VisualContractError,OSError,ValueError): results[name]="BLOCK"
            else: raise VisualContractError(f"semantic self-test unexpectedly passed: {name}")

        write_json(req/"state.json",{"primary_skill":"wxian-image-production","status":"active","revision":2}); blocked("stale_revision",lambda:validate_visual_spec(root,spec_path)); write_json(req/"state.json",{"primary_skill":"wxian-image-production","status":"active","revision":1})
        bad=json.loads(json.dumps(spec)); bad["authority_trace"].append({"role":"requirement_lock","path":workspace_relative(root,other/'work'/'requirement-lock.md'),"sha256":sha256_file(other/'work'/'requirement-lock.md')}); write_json(spec_path,bad); blocked("cross_request_authority",lambda:validate_visual_spec(root,spec_path)); binding,gate=refresh_chain()
        vac=json.loads(json.dumps(spec)); vac["intent"]={}; write_json(spec_path,vac); blocked("vacuous_visual_spec",lambda:validate_visual_spec(root,spec_path)); binding,gate=refresh_chain()
        missing=json.loads(json.dumps(gate)); missing["gates"]=[g for g in missing["gates"] if g["gate"]!="VG-COHERENCE"]; write_json(gate_path,missing); blocked("missing_mandatory_gate",lambda:validate_visual_gate_result(root,gate_path))
        empty=json.loads(json.dumps(gate)); empty["gates"][0]["evidence"]=[]; write_json(gate_path,empty); blocked("empty_gate_evidence",lambda:validate_visual_gate_result(root,gate_path))
        weak=json.loads(json.dumps(gate)); weak["gates"][0]["evidence"][0]["observation"]="looks ok"; write_json(gate_path,weak); blocked("weak_gate_evidence",lambda:validate_visual_gate_result(root,gate_path))
        unknown=json.loads(json.dumps(binding)); unknown["compiler_profile"]="unknown.profile"; write_json(binding_path,unknown); blocked("unknown_compiler_profile",lambda:validate_prompt_binding(root,binding_path))
        mismatch=json.loads(json.dumps(binding)); mismatch["adapter_family"]="wrong-adapter"; write_json(binding_path,mismatch); blocked("adapter_mismatch",lambda:validate_prompt_binding(root,binding_path)); binding,gate=refresh_chain()
        absent=json.loads(json.dumps(binding)); absent["spec_consumption"][0]["prompt_evidence"]=["absent compiled phrase"]; write_json(binding_path,absent); blocked("missing_prompt_consumption_evidence",lambda:validate_prompt_binding(root,binding_path)); binding,gate=refresh_chain()
        generic=json.loads(json.dumps(binding)); generic_prompt="display requested subject identity projection background detail"; [claim.update({"prompt_evidence":[generic_prompt]}) for claim in generic["spec_consumption"]]; write_json(binding_path,generic); blocked("generic_prompt_does_not_prove_spec_consumption",lambda:validate_prompt_binding(root,binding_path)); binding,gate=refresh_chain()
        nonimage=target.read_bytes(); target.write_bytes(b"not an image"); gate["target_sha256"]=sha256_file(target); gate["independent_review"]["decoded_target"]={"format":"PNG","width":4,"height":3,"mode":"RGBA"}; write_json(gate_path,gate); blocked("non_image_target",lambda:validate_visual_gate_result(root,gate_path)); target.write_bytes(nonimage); binding,gate=refresh_chain()
        same=json.loads(json.dumps(gate)); same["independent_review"]["reviewer_id"]="IMAGE-PRODUCTION-PRODUCER\u200b"; same["reviewer"]="IMAGE-PRODUCTION-PRODUCER\u200b"; write_json(gate_path,same); blocked("same_producer_reviewer",lambda:validate_visual_gate_result(root,gate_path))
        nul_same=json.loads(json.dumps(gate)); nul_same["independent_review"]["reviewer_id"]="image-production-producer\u0000"; nul_same["reviewer"]="image-production-producer\u0000"; write_json(gate_path,nul_same); blocked("same_producer_reviewer_embedded_control",lambda:validate_visual_gate_result(root,gate_path))
        wrong_hash=json.loads(json.dumps(gate)); wrong_hash["independent_review"]["review_report_sha256"]="0"*64; write_json(gate_path,wrong_hash); blocked("stale_review_report_hash",lambda:validate_visual_gate_result(root,gate_path))
        blocked_review=json.loads(json.dumps(gate)); blocked_review["independent_review"]["verdict"]="BLOCK"; write_json(gate_path,blocked_review); blocked("reviewer_block_cannot_promote",lambda:validate_visual_gate_result(root,gate_path))
        cross=json.loads(json.dumps(gate)); other_target=other/"work"/"candidate.png"; Image.new("RGBA",(1,1),(0,0,0,255)).save(other_target); cross["target_path"]=workspace_relative(root,other_target); cross["target_sha256"]=sha256_file(other_target); write_json(gate_path,cross); blocked("cross_request_target",lambda:validate_visual_gate_result(root,gate_path))

        # The independent reviewer must be provably reading the original demand, not only
        # the producer contract it is supposed to judge.
        binding,gate=refresh_chain()
        baseline_report=report_path.read_text(encoding="utf-8")

        def review_case(name, mutate):
            report=json.loads(baseline_report); mutate(report); write_json(report_path,report)
            gate["independent_review"]["review_report_sha256"]=sha256_file(report_path); write_json(gate_path,gate)
            blocked(name,lambda:validate_visual_gate_result(root,gate_path))
            report_path.write_text(baseline_report,encoding="utf-8")
            gate["independent_review"]["review_report_sha256"]=sha256_file(report_path); write_json(gate_path,gate)

        def drop_role(role):
            return lambda report: report.__setitem__("source_bindings",[b for b in report["source_bindings"] if b["role"]!=role])

        review_case("review_ignores_original_request",drop_role("current_request"))
        review_case("review_ignores_requirement_lock",drop_role("requirement_lock"))
        review_case("review_without_professional_method",lambda report:report.__setitem__("review_methods",["sicza-visual-director/SELECT"]))
        review_case("vacuous_review_narrative",lambda report:report.__setitem__("review_narrative","looks fine to me."))

        ref_source=root/"project"/"references"/"composition.png"; ref_source.parent.mkdir(parents=True,exist_ok=True); Image.new("RGB",(8,8),(32,64,96)).save(ref_source)
        ref_analysis=req/"work"/"composition-analysis.md"; ref_analysis.write_text("visible fact: one dominant subject relationship\n",encoding="utf-8")
        plan_path=req/"work"/"reference-plan.json"
        write_json(plan_path,{"sources":[{"source_path":workspace_relative(root,ref_source),"source_sha256":sha256_file(ref_source),"role":"composition","analysis":"full-reverse","use":"visual_only","analysis_path":workspace_relative(root,ref_analysis)}]})
        binding,gate=refresh_chain()
        blocked("review_ignores_full_reverse_reference",lambda:validate_visual_gate_result(root,gate_path))
        report=json.loads(baseline_report)
        report["source_bindings"]+= [
            {"role":"reference_plan","path":workspace_relative(root,plan_path),"sha256":sha256_file(plan_path)},
            {"role":"reference_source","path":workspace_relative(root,ref_source),"sha256":sha256_file(ref_source)},
            {"role":"reference_analysis","path":workspace_relative(root,ref_analysis),"sha256":sha256_file(ref_analysis)},
        ]
        write_json(report_path,report)
        gate["independent_review"]["review_report_sha256"]=sha256_file(report_path); write_json(gate_path,gate)
        validate_visual_gate_result(root,gate_path); results["review_consumes_reference_analysis"]="PASS"
        report["source_bindings"]=[b for b in report["source_bindings"] if b["role"]!="reference_analysis"]
        write_json(report_path,report)
        gate["independent_review"]["review_report_sha256"]=sha256_file(report_path); write_json(gate_path,gate)
        blocked("review_ignores_reference_analysis",lambda:validate_visual_gate_result(root,gate_path))
    return results


def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__); sub=ap.add_subparsers(dest="command",required=True)
    for command in ("validate-narrative","validate-spec","validate-binding","validate-visual-gate","validate-baseline","validate-return"):
        p=sub.add_parser(command); p.add_argument("--file",type=Path,required=True); p.add_argument("--workspace-root",type=Path,default=Path(__file__).resolve().parents[2])
    stamp=sub.add_parser("stamp-narrative"); stamp.add_argument("--file",type=Path,required=True); stamp.add_argument("--workspace-root",type=Path,default=Path(__file__).resolve().parents[2])
    bind=sub.add_parser("bind-prompt"); bind.add_argument("--visual-spec",type=Path,required=True); bind.add_argument("--prompt",type=Path,required=True); bind.add_argument("--compiler-profile",required=True); bind.add_argument("--spec-consumption",type=Path,help="optional spec-consumption JSON; inferred wording is not required for optional evidence"); bind.add_argument("--output",type=Path,required=True); bind.add_argument("--workspace-root",type=Path,default=Path(__file__).resolve().parents[2])
    ident=sub.add_parser("identity"); ident.add_argument("--request",type=Path,required=True); ident.add_argument("--workspace-root",type=Path,default=Path(__file__).resolve().parents[2])
    sub.add_parser("doctor")
    args=ap.parse_args()
    try:
        if args.command=="doctor":
            schema_ids={"narrative-visual-contract-schema.json":"sicza.narrative-visual-contract.v2","visual-spec-schema.json":"sicza.visual-spec.v2","prompt-binding-schema.json":"sicza.prompt-binding.v2","visual-gate-result-schema.json":"sicza.visual-gate-result.v3","visual-independent-review-schema.json":"sicza.visual-independent-review.v2","baseline-consumption-schema.json":"sicza.baseline-consumption.v2","visual-return-schema.json":"sicza.visual-return.v1"}
            for name,expected in schema_ids.items():
                obj=schema(name)
                if obj.get("$id")!=expected: raise VisualContractError(f"invalid contract schema id: {name}")
            registry("visual-spec-profiles.json","sicza.visual-spec-profiles.v1"); registry("visual-gate-profiles.json","sicza.visual-gate-profiles.v1"); registry("prompt-compiler-profiles.json","sicza.prompt-compiler-profiles.v1"); registry("visual-enforcement-profiles.json","sicza.visual-enforcement-profiles.v1")
            tests=semantic_selftest()
            print(json.dumps({"status":"ready","schemas":list(schema_ids),"semantic_selftests":tests,"provider_calls":False},ensure_ascii=False,indent=2)); return 0
        root=args.workspace_root.resolve()
        if args.command=="identity":
            request=(root/args.request).resolve() if not args.request.is_absolute() else args.request.resolve(); print(json.dumps({"status":"ready",**request_identity(root,request)},ensure_ascii=False,indent=2)); return 0
        if args.command=="stamp-narrative":
            path=root_path(root,args.file); obj=load_json(path); request=(root/obj["request_ref"]).resolve(); obj.update(request_identity(root,request)); obj["contract_revision"]=obj["request_revision"]
            if not isinstance(obj.get("semantic_checksum"),str) or len(str(obj.get("semantic_checksum","")))!=64: obj["semantic_checksum"]="0"*64
            validate_schema(obj,schema("narrative-visual-contract-schema.json")); obj["semantic_checksum"]=semantic_checksum(obj); write_json(path,obj); validate_narrative_contract(root,path)
            print(json.dumps({"status":"stamped","file":str(path),"semantic_checksum":obj["semantic_checksum"]},ensure_ascii=False,indent=2)); return 0
        if args.command=="bind-prompt":
            spec_path=root_path(root,args.visual_spec); prompt_path=root_path(root,args.prompt); spec=validate_visual_spec(root,spec_path); request=(root/spec["request_ref"]).resolve(); prof=compiler_profile(args.compiler_profile); pack=(root/prof["prompt_pack"]).resolve()
            if not pack.is_file(): raise VisualContractError(f"compiler prompt pack is missing: {prof['prompt_pack']}")
            consumption_raw=None
            if args.spec_consumption is not None:
                try: consumption_raw=json.loads(root_path(root,args.spec_consumption).read_text(encoding="utf-8"))
                except (OSError,json.JSONDecodeError) as exc: raise VisualContractError(f"invalid --spec-consumption JSON: {exc}") from exc
                if isinstance(consumption_raw,dict): consumption_raw=consumption_raw.get("spec_consumption")
                if not isinstance(consumption_raw,list): raise VisualContractError("--spec-consumption must be a JSON array or an object containing spec_consumption")
            # A still-production Visual Spec has required consumption fields. Refuse before writing
            # so a rejected bind never leaves an illegal work/prompt-binding.json behind.
            if spec.get("profile_id")=="visual.still.production.v1" and consumption_raw is None:
                raise VisualContractError("still-production Visual Spec requires --spec-consumption; refusing to write an invalid prompt-binding.json")
            value={"schema_version":"sicza.prompt-binding.v2",**request_identity(root,request),"visual_spec_path":workspace_relative(root,spec_path),"visual_spec_sha256":sha256_file(spec_path),"narrative_semantic_checksum":spec["narrative_trace"]["semantic_checksum"] if spec["narrative_trace"] else None,"prompt_path":workspace_relative(root,prompt_path),"prompt_sha256":sha256_file(prompt_path),"compiler_profile":args.compiler_profile,"adapter_family":prof["adapter_family"],"prompt_pack_path":prof["prompt_pack"],"prompt_pack_sha256":sha256_file(pack)}
            if consumption_raw is not None: value["spec_consumption"]=consumption_raw
            output_path=root_path(root,args.output); previous=output_path.read_bytes() if output_path.is_file() else None
            write_json(output_path,value)
            try: obj=validate_prompt_binding(root,output_path)
            except (VisualContractError,OSError,ValueError,KeyError):
                # The canonical path is required for validation; roll back so a failed bind leaves
                # the previous binding (or nothing) instead of an unvalidated file.
                if previous is None: output_path.unlink(missing_ok=True)
                else: output_path.write_bytes(previous)
                raise
        elif args.command=="validate-narrative": obj=validate_narrative_contract(root,root_path(root,args.file))
        elif args.command=="validate-spec": obj=validate_visual_spec(root,root_path(root,args.file))
        elif args.command=="validate-binding": obj=validate_prompt_binding(root,root_path(root,args.file))
        elif args.command=="validate-visual-gate": obj=validate_visual_gate_result(root,root_path(root,args.file))
        elif args.command=="validate-baseline": obj=validate_baseline_consumption(root,root_path(root,args.file))
        elif args.command=="validate-return": obj=validate_visual_return(root,root_path(root,args.file))
        else: raise VisualContractError("unsupported command")
        print(json.dumps({"status":"passed","schema_version":obj.get("schema_version")},ensure_ascii=False,indent=2)); return 0
    except (VisualContractError,OSError,ValueError,KeyError) as exc:
        print(json.dumps({"status":"blocked","error_code":"visual_contract_blocked","reason":str(exc),
                          "next_action":"fix the reported contract fact or regenerate the affected artifact, then rerun the same command"},
                         ensure_ascii=False,indent=2)); return 2

if __name__=="__main__": raise SystemExit(main())
