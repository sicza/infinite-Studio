param([string]$PythonExe = '')
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$workspaceRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$runtimeDir = Join-Path $workspaceRoot '.agents\runtime'
$credentialPath = Join-Path $runtimeDir 'credentials.json'

$form = New-Object System.Windows.Forms.Form
$form.Text = 'InfiniteBOT Codex - API Key'
$form.StartPosition = 'CenterScreen'
$form.ClientSize = New-Object System.Drawing.Size(520, 150)
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.TopMost = $true

$label = New-Object System.Windows.Forms.Label
$label.Text = 'Generation API Key'
$label.AutoSize = $true
$label.Location = New-Object System.Drawing.Point(20, 20)
$form.Controls.Add($label)

$textBox = New-Object System.Windows.Forms.TextBox
$textBox.Location = New-Object System.Drawing.Point(20, 48)
$textBox.Size = New-Object System.Drawing.Size(480, 24)
$textBox.UseSystemPasswordChar = $true
$form.Controls.Add($textBox)

$ok = New-Object System.Windows.Forms.Button
$ok.Text = 'Save'
$ok.DialogResult = [System.Windows.Forms.DialogResult]::OK
$ok.Location = New-Object System.Drawing.Point(330, 95)
$ok.Size = New-Object System.Drawing.Size(80, 30)
$form.Controls.Add($ok)

$cancel = New-Object System.Windows.Forms.Button
$cancel.Text = 'Cancel'
$cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$cancel.Location = New-Object System.Drawing.Point(420, 95)
$cancel.Size = New-Object System.Drawing.Size(80, 30)
$form.Controls.Add($cancel)

$form.AcceptButton = $ok
$form.CancelButton = $cancel
$form.Add_Shown({ $textBox.Focus() })
$result = $form.ShowDialog()
if ($result -ne [System.Windows.Forms.DialogResult]::OK) {
    exit 3
}

$key = $textBox.Text.Trim()
if ([string]::IsNullOrWhiteSpace($key)) {
    [System.Windows.Forms.MessageBox]::Show('API Key cannot be empty.', 'InfiniteBOT Codex', 'OK', 'Warning') | Out-Null
    exit 4
}

# Resolve the ACL owner before the secret is on disk: a failure path must not leave an
# unhardened key behind.
$apiScript = Join-Path $workspaceRoot '.agents\skills\image-generation-api\scripts\generation_api.py'
$apiConfig = Join-Path $workspaceRoot '.agents\skills\image-generation-api\config\api-runtime.json'
if (-not $PythonExe) {
    $PythonExe = Join-Path $workspaceRoot '.agents\runtime\toolchain\venv\Scripts\python.exe'
}
if (-not (Test-Path -LiteralPath $PythonExe -PathType Leaf)) {
    Write-Output '{"status":"blocked","reason":"Workspace Python is missing; run workspace_bootstrap before configuring the API key"}'
    exit 5
}
$previousPreference = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
$null = & $PythonExe '-X' 'utf8' '-c' 'raise SystemExit(0)' 2>&1
$probeExit = $LASTEXITCODE
$ErrorActionPreference = $previousPreference
if ($probeExit -ne 0) {
    Write-Output '{"status":"blocked","reason":"Workspace Python is not executable; run workspace_bootstrap before configuring the API key"}'
    exit 5
}

[System.IO.Directory]::CreateDirectory($runtimeDir) | Out-Null
# Harden the store while it is still empty, then write into it: the write cannot change the
# DACL, so a failed ACL step can never leave the secret on an unprotected file.
$createdStore = $false
if (-not (Test-Path -LiteralPath $credentialPath -PathType Leaf)) {
    [System.IO.File]::WriteAllText($credentialPath, '', (New-Object System.Text.UTF8Encoding($false)))
    $createdStore = $true
}

# The ACL is not a dialog concern: the credential store is also written outside this dialog,
# and one owner for that rule is what keeps a sandboxed executor able to read the key.
$previousPreference = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
$secured = & $PythonExe '-X' 'utf8' $apiScript 'secure-credential' '--config' $apiConfig 2>&1
$secureExit = $LASTEXITCODE
$ErrorActionPreference = $previousPreference
if ($secureExit -ne 0) {
    $detail = ($secured | Out-String).Trim()
    # Only a placeholder this run created may be removed. A rotation that fails must leave the
    # credential that was already working exactly where it is.
    if ($createdStore) { Remove-Item -LiteralPath $credentialPath -Force -ErrorAction SilentlyContinue }
    Write-Output (@{ status = 'blocked'; reason = 'credential ACL could not be applied'; detail = $detail } | ConvertTo-Json -Compress)
    exit 5
}

$payload = @{ generation_api_key = $key } | ConvertTo-Json
$utf8 = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($credentialPath, $payload + [Environment]::NewLine, $utf8)

$aclGrantees = @()
$securedText = ($secured | Out-String).Trim()
if ($securedText) {
    # The CLI pretty-prints its JSON, so the whole document must be parsed; taking the last
    # line would capture only the closing brace and silently drop the evidence.
    try { $aclGrantees = @((ConvertFrom-Json $securedText).grantees) } catch { $aclGrantees = @() }
}
Write-Output (@{
    status = 'configured'
    credential_store = '.agents/runtime/credentials.json'
    credential_value_exposed = $false
    credential_acl_grantees = $aclGrantees
    credential_acl_grantees_parsed = ($aclGrantees.Count -gt 0)
} | ConvertTo-Json -Compress)
exit 0
