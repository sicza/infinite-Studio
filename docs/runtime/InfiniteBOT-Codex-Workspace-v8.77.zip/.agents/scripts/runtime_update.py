#!/usr/bin/env python3
"""Check for and apply a formal InfiniteBOT Codex Workspace Runtime update."""

from __future__ import annotations

import os as _bytecode_guard_os, sys as _bytecode_guard_sys
_bytecode_guard_sys.dont_write_bytecode = True
_bytecode_guard_os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import argparse
import hashlib
import json
import os
import re
import shutil
import stat
import sys
import tempfile
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable
from urllib.request import Request, urlopen

SCRIPT = Path(__file__).resolve()
AGENTS_ROOT = SCRIPT.parents[1]
if str(AGENTS_ROOT / "lib") not in sys.path:
    sys.path.insert(0, str(AGENTS_ROOT / "lib"))
if str(SCRIPT.parent) not in sys.path:
    sys.path.insert(0, str(SCRIPT.parent))

from atomic_io import atomic_write_text
import runtime_update_state as update_state
import runtime_version_check as version_check

RUNTIME_BASE_URL = "https://sicza.github.io/infinite-Studio/runtime/"
EXPECTED_FEED_URL = "https://sicza.github.io/infinite-Studio/latest.json"
MAX_ARCHIVE_BYTES = 64 * 1024 * 1024
MAX_EXTRACTED_BYTES = 256 * 1024 * 1024
MAX_ENTRIES = 4096
DOWNLOAD_TIMEOUT_SECONDS = 60
RUNTIME_STATE_DIR = ".agents/runtime"
REQUIRED_FILES = (
    "AGENTS.md",
    ".codex/hooks.json",
    ".agents/scripts/runtime_update.py",
    ".agents/scripts/runtime_version_check.py",
    ".agents/runtime-release.json",
)


class UpdateError(RuntimeError):
    pass


def workspace_root() -> Path:
    return SCRIPT.parents[2]


def validate_relative(name: Any) -> str:
    if not isinstance(name, str) or not name or "\x00" in name:
        raise UpdateError("archive entry name is invalid")
    if name.startswith(("/", "\\")) or "\\" in name:
        raise UpdateError(f"archive entry is not a POSIX relative path: {name!r}")
    parts = name.split("/")
    if any(part in {"", ".", ".."} for part in parts):
        raise UpdateError(f"archive entry contains an unsafe path segment: {name!r}")
    return name


def inspect_archive(path: Path, remote: dict[str, Any]) -> tuple[list[str], dict[str, Any], dict[str, zipfile.ZipInfo]]:
    expected_version = str(remote["latest_version"])
    with zipfile.ZipFile(path) as archive:
        infos = archive.infolist()
        if not infos or len(infos) > MAX_ENTRIES:
            raise UpdateError("archive entry count is outside the allowed range")
        names = [validate_relative(info.filename) for info in infos]
        if len(names) != len(set(names)):
            raise UpdateError("archive contains duplicate entries")
        total = 0
        rows: dict[str, zipfile.ZipInfo] = {}
        for info in infos:
            if info.is_dir() or info.filename.endswith("/"):
                raise UpdateError("archive may contain regular files only")
            mode = info.external_attr >> 16
            if stat.S_ISLNK(mode):
                raise UpdateError("archive may not contain symbolic links")
            total += info.file_size
            if total > MAX_EXTRACTED_BYTES:
                raise UpdateError("archive expands beyond the size limit")
            rows[info.filename] = info
        if ".agents/runtime-release.json" not in rows:
            raise UpdateError("archive is missing the Runtime release marker")
        try:
            marker = json.loads(archive.read(".agents/runtime-release.json").decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise UpdateError("archive release marker is not valid JSON") from exc
    if not isinstance(marker, dict):
        raise UpdateError("archive release marker must be an object")
    if type(marker.get("schema_version")) is not int or marker.get("schema_version") != 1:
        raise UpdateError("archive release marker schema is invalid")
    if marker.get("channel") != "stable":
        raise UpdateError("archive release marker channel is invalid")
    if marker.get("version") != expected_version:
        raise UpdateError("archive release marker version does not match the index")
    if marker.get("version_feed_url") != EXPECTED_FEED_URL:
        raise UpdateError("archive release marker feed URL is not trusted")
    files = marker.get("files")
    if (not isinstance(files, list) or not files
            or any(not isinstance(item, str) for item in files)):
        raise UpdateError("archive release marker file list is invalid")
    normalized = [validate_relative(item) for item in files]
    if len(normalized) != len(set(normalized)):
        raise UpdateError("archive release marker file list contains duplicates")
    if set(normalized) != set(names):
        raise UpdateError("archive entry set does not match the release marker file list")
    for required in REQUIRED_FILES:
        if required not in normalized:
            raise UpdateError(f"archive is missing required Runtime file: {required}")
    return sorted(normalized), marker, rows


def download_archive(url: str, expected_sha256: str, *, directory: Path,
                     opener: Callable[..., Any] = urlopen) -> Path:
    if not re.fullmatch(r"https://sicza\.github\.io/infinite-Studio/runtime/"
                        r"InfiniteBOT-Codex-Workspace-v\d+\.\d+\.zip", url):
        raise UpdateError("Runtime download URL is not trusted")
    request = Request(url, headers={
        "Accept": "application/zip",
        "Cache-Control": "no-cache",
        "User-Agent": "InfiniteBOT-Runtime-Updater/1",
    })
    chunks: list[bytes] = []
    total = 0
    with opener(request, timeout=DOWNLOAD_TIMEOUT_SECONDS) as response:
        if response.geturl() != url:
            raise UpdateError("Runtime download redirected away from the trusted URL")
        if getattr(response, "status", response.getcode()) != 200:
            raise UpdateError("Runtime download did not return HTTP 200")
        content_type = str(response.headers.get("Content-Type", "")).split(";", 1)[0].strip().lower()
        if content_type not in {"application/zip", "application/x-zip-compressed",
                                "application/octet-stream"}:
            raise UpdateError("Runtime download is not a ZIP archive")
        declared = response.headers.get("Content-Length")
        if declared is not None:
            try:
                if int(declared) > MAX_ARCHIVE_BYTES:
                    raise UpdateError("Runtime archive exceeds the size limit")
            except ValueError as exc:
                raise UpdateError("Runtime archive Content-Length is invalid") from exc
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            total += len(chunk)
            if total > MAX_ARCHIVE_BYTES:
                raise UpdateError("Runtime archive exceeds the size limit")
            chunks.append(chunk)
    payload = b"".join(chunks)
    if hashlib.sha256(payload).hexdigest() != expected_sha256.lower():
        raise UpdateError("Runtime archive SHA-256 does not match the release index")
    directory.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix="update-download-", suffix=".zip", dir=directory)
    with os.fdopen(fd, "wb") as handle:
        handle.write(payload)
    return Path(name)


def extract_archive(path: Path, files: list[str], staging: Path) -> None:
    with zipfile.ZipFile(path) as archive:
        for rel in files:
            target = staging / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            data = archive.read(rel)
            target.write_bytes(data)
            if os.name != "nt":
                mode = archive.getinfo(rel).external_attr >> 16
                os.chmod(target, (mode & 0o777) or 0o644)


def install_tree(root: Path, staging: Path, files: list[str]) -> None:
    manifest = set(files)
    for rel in files:
        source = staging / rel
        target = root / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_name(f".{target.name}.runtime-update")
        shutil.copy2(source, temporary)
        os.replace(temporary, target)
    agents = root / ".agents"
    for current, _dirnames, filenames in os.walk(agents, topdown=False):
        directory = Path(current)
        relative_dir = directory.relative_to(root).as_posix()
        if relative_dir == RUNTIME_STATE_DIR or relative_dir.startswith(RUNTIME_STATE_DIR + "/"):
            continue
        for filename in filenames:
            relative = (directory / filename).relative_to(root).as_posix()
            if relative not in manifest:
                (directory / filename).unlink(missing_ok=True)
    for current, _dirnames, _filenames in os.walk(agents, topdown=False):
        directory = Path(current)
        if directory == agents:
            continue
        relative_dir = directory.relative_to(root).as_posix()
        if relative_dir == RUNTIME_STATE_DIR or relative_dir.startswith(RUNTIME_STATE_DIR + "/"):
            continue
        try:
            directory.rmdir()
        except OSError:
            pass


def write_last_update(root: Path, remote: dict[str, Any]) -> None:
    payload = {
        "schema_version": 1,
        "version": remote["latest_version"],
        "release_sha256": remote["release_sha256"],
        "installed_at": datetime.now(timezone.utc).isoformat(),
    }
    path = root / RUNTIME_STATE_DIR / "last-update.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_text(path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")


def apply_archive(root: Path, archive_path: Path, remote: dict[str, Any]) -> dict[str, Any]:
    files, _marker, _rows = inspect_archive(archive_path, remote)
    (root / RUNTIME_STATE_DIR).mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix="update-staging-", dir=root / RUNTIME_STATE_DIR))
    try:
        extract_archive(archive_path, files, staging)
        install_tree(root, staging, files)
    finally:
        shutil.rmtree(staging, ignore_errors=True)
    try:
        installed = json.loads((root / ".agents/runtime-release.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise UpdateError("installed Runtime marker is unreadable") from exc
    if installed.get("version") != remote["latest_version"]:
        raise UpdateError("installed Runtime marker does not match the release index")
    update_state.clear(root)
    write_last_update(root, remote)
    return {
        "status": "updated",
        "version": remote["latest_version"],
        "file_count": len(files),
    }


def fetch_update(root: Path) -> tuple[dict[str, Any], dict[str, Any]]:
    try:
        marker = json.loads((root / ".agents/runtime-release.json").read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise UpdateError("Runtime release marker is unreadable") from exc
    try:
        local = version_check.validate_local_release(marker)
    except version_check.VersionCheckError as exc:
        raise UpdateError(str(exc)) from exc
    remote = version_check.fetch_remote_release(str(local["version_feed_url"]))
    return local, remote


def update_available(local: dict[str, Any], remote: dict[str, Any]) -> bool:
    return version_check.parse_version(remote["latest_version"]) > version_check.parse_version(local["version"])


def status_payload(root: Path, local: dict[str, Any], remote: dict[str, Any]) -> dict[str, Any]:
    available = update_available(local, remote)
    if available:
        update_state.write(
            root,
            local_version=str(local["version"]),
            latest_version=str(remote["latest_version"]),
            release_filename=str(remote["release_filename"]),
            release_sha256=str(remote["release_sha256"]),
        )
    else:
        update_state.clear(root)
    return {
        "status": "update_available" if available else "up_to_date",
        "local_version": local["version"],
        "latest_version": remote["latest_version"],
        "release_filename": remote["release_filename"],
        "download_url": RUNTIME_BASE_URL + str(remote["release_filename"]),
        "next_action": update_state.update_command() if available else None,
    }


def acquire_lock(root: Path) -> Path:
    path = root / RUNTIME_STATE_DIR / "update.lock"
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_file():
        try:
            if time.time() - path.stat().st_mtime > 600:
                path.unlink()
        except OSError:
            pass
    try:
        descriptor = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError as exc:
        raise UpdateError("another Runtime update is already running") from exc
    with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
        handle.write(f"pid={os.getpid()}\n")
    return path


def release_lock(path: Path) -> None:
    if path.is_file():
        path.unlink()


def run_apply(root: Path) -> dict[str, Any]:
    lock = acquire_lock(root)
    archive: Path | None = None
    try:
        local, remote = fetch_update(root)
        if not update_available(local, remote):
            update_state.clear(root)
            return {"status": "up_to_date", "version": local["version"]}
        url = RUNTIME_BASE_URL + str(remote["release_filename"])
        archive = download_archive(url, str(remote["release_sha256"]),
                                   directory=root / RUNTIME_STATE_DIR)
        result = apply_archive(root, archive, remote)
        result["previous_version"] = local["version"]
        return result
    finally:
        if archive is not None and archive.exists():
            archive.unlink()
        release_lock(lock)


def _self_test() -> dict[str, Any]:
    with tempfile.TemporaryDirectory(prefix="runtime-update-selftest-") as temp_dir:
        root = Path(temp_dir)
        (root / ".agents/scripts").mkdir(parents=True)
        (root / ".agents/runtime/toolchain/venv").mkdir(parents=True)
        (root / ".agents/scripts/removed_script.py").write_text("old\n", encoding="utf-8")
        (root / ".agents/runtime/toolchain/venv/python").write_text("venv\n", encoding="utf-8")
        (root / ".agents/runtime-release.json").write_text(json.dumps({
            "schema_version": 1,
            "channel": "stable",
            "version": "V8.61",
            "version_feed_url": EXPECTED_FEED_URL,
        }) + "\n", encoding="utf-8")
        (root / ".codex").mkdir()
        (root / ".codex/hooks.json").write_text("old\n", encoding="utf-8")
        (root / "AGENTS.md").write_text("old agents\n", encoding="utf-8")
        (root / "project").mkdir()
        (root / "project/keep.md").write_text("project\n", encoding="utf-8")
        (root / "user").mkdir()
        (root / "user/keep.json").write_text("user\n", encoding="utf-8")

        files = list(REQUIRED_FILES)
        marker = {
            "schema_version": 1,
            "channel": "stable",
            "version": "V8.62",
            "version_feed_url": EXPECTED_FEED_URL,
            "files": sorted(files),
        }
        archive_path = root / "update.zip"
        with zipfile.ZipFile(archive_path, "w") as archive:
            for rel in files:
                payload = (json.dumps(marker) + "\n") if rel == ".agents/runtime-release.json" else f"new {rel}\n"
                info = zipfile.ZipInfo(rel, date_time=(2026, 1, 1, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                archive.writestr(info, payload)
        remote = {
            "schema_version": 1,
            "channel": "stable",
            "latest_version": "V8.62",
            "release_filename": "InfiniteBOT-Codex-Workspace-v8.62.zip",
            "release_sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest(),
            "published_at": "2026-11-17T00:00:00+00:00",
        }
        update_state.write(root, local_version="V8.61", latest_version="V8.62",
                           release_filename=remote["release_filename"],
                           release_sha256=remote["release_sha256"])
        result = apply_archive(root, archive_path, remote)
        assert result["status"] == "updated"
        assert (root / "AGENTS.md").read_text(encoding="utf-8") == "new AGENTS.md\n"
        assert not (root / ".agents/scripts/removed_script.py").exists()
        assert (root / ".agents/runtime/toolchain/venv/python").is_file()
        assert (root / "project/keep.md").is_file() and (root / "user/keep.json").is_file()
        installed = json.loads((root / ".agents/runtime-release.json").read_text(encoding="utf-8"))
        assert installed["version"] == "V8.62" and installed["files"] == sorted(files)
        assert update_state.load(root) is None
        assert (root / ".agents/runtime/last-update.json").is_file()

        traversal = root / "traversal.zip"
        with zipfile.ZipFile(traversal, "w") as archive:
            for rel in files:
                archive.writestr(rel, "{}")
            archive.writestr("../evil.txt", "evil")
        try:
            inspect_archive(traversal, remote)
        except UpdateError:
            pass
        else:
            raise AssertionError("archive path traversal was not rejected")

        mismatch = root / "mismatch.zip"
        with zipfile.ZipFile(mismatch, "w") as archive:
            for rel in files:
                payload = (json.dumps(marker) + "\n") if rel == ".agents/runtime-release.json" else "x"
                archive.writestr(rel, payload)
            archive.writestr("unexpected.txt", "x")
        try:
            inspect_archive(mismatch, remote)
        except UpdateError:
            pass
        else:
            raise AssertionError("unlisted archive entry was not rejected")
    return {"status": "passed", "checks": 15}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace-root", type=Path, default=workspace_root())
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--check", action="store_true", help="report whether a newer formal Runtime exists")
    mode.add_argument("--apply", action="store_true", help="download, verify, and install the newer formal Runtime")
    mode.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        print(json.dumps(_self_test(), ensure_ascii=False))
        return 0
    root = args.workspace_root.resolve()
    try:
        if args.apply:
            result = run_apply(root)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        local, remote = fetch_update(root)
        result = status_payload(root, local, remote)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 2 if result["status"] == "update_available" else 0
    except Exception as exc:
        print(json.dumps({"status": "error", "reason": str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    sys.exit(main())
