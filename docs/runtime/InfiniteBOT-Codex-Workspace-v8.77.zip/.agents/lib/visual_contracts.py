#!/usr/bin/env python3
"""Fail-closed request-local Narrative→Visual→Prompt→Gate contracts.

No provider/API calls occur here. Contract validity is bound to the active request identity,
revision and deterministic request fingerprint so stale or cross-request artifacts fail closed.
"""
from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from pathlib import Path
from typing import Any

AGENTS_ROOT = Path(__file__).resolve().parents[1]
CONTRACT_ROOT = AGENTS_ROOT / "skills" / "workspace-governance" / "config" / "visual-contracts"
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")

from request_identity import identity as current_identity


class VisualContractError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise VisualContractError(message)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    require(path.is_file(), f"required JSON file is missing: {path}")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise VisualContractError(f"invalid JSON: {path}: {exc}") from exc
    require(isinstance(value, dict), f"JSON root must be an object: {path}")
    return value


def bounded_path(root: Path, value: str | Path, *, must_exist: bool = True) -> Path:
    candidate = Path(value)
    if not candidate.is_absolute():
        candidate = root / candidate
    resolved = candidate.resolve()
    root = root.resolve()
    require(resolved == root or root in resolved.parents, f"path escapes Workspace: {value}")
    if must_exist:
        require(resolved.is_file(), f"file does not exist: {value}")
    return resolved


def workspace_relative(root: Path, path: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def resolve_request(root: Path, request_ref: str) -> Path:
    request = bounded_path(root, request_ref, must_exist=False)
    requests_root = (root / "requests").resolve()
    require(requests_root in request.parents, f"request_ref must be under requests/: {request_ref}")
    require(request.is_dir(), f"request_ref is not a request directory: {request_ref}")
    require((request / "request.md").is_file(), f"request is missing request.md: {request_ref}")
    require((request / "state.json").is_file(), f"request is missing state.json: {request_ref}")
    return request


def require_request_binding(root: Path, request: Path, obj: dict[str, Any], *, label: str) -> dict[str, Any]:
    expected = current_identity(root, request)
    for key in ("request_ref", "request_id", "request_revision", "request_fingerprint"):
        require(obj.get(key) == expected[key], f"{label} {key} does not match active request lineage")
    return expected


def _resolve_ref(schema_root: dict[str, Any], ref: str) -> dict[str, Any]:
    require(ref.startswith("#/"), f"only local schema refs are supported: {ref}")
    node: Any = schema_root
    for segment in ref[2:].split("/"):
        require(isinstance(node, dict) and segment in node, f"unresolved schema ref: {ref}")
        node = node[segment]
    require(isinstance(node, dict), f"schema ref must resolve to an object: {ref}")
    return node


def validate_schema(value: Any, schema: dict[str, Any], *, schema_root: dict[str, Any] | None = None, path: str = "$") -> None:
    root = schema_root or schema
    if "$ref" in schema:
        validate_schema(value, _resolve_ref(root, str(schema["$ref"])), schema_root=root, path=path)
        return
    if "anyOf" in schema:
        errors: list[str] = []
        for option in schema["anyOf"]:
            try:
                validate_schema(value, option, schema_root=root, path=path)
                break
            except VisualContractError as exc:
                errors.append(str(exc))
        else:
            raise VisualContractError(f"{path} does not match any allowed schema: {' | '.join(errors[:3])}")
        return
    if "const" in schema:
        require(value == schema["const"], f"{path} must equal {schema['const']!r}")
    if "enum" in schema:
        require(value in schema["enum"], f"{path} must be one of {schema['enum']}")
    expected = schema.get("type")
    if expected == "object":
        require(isinstance(value, dict), f"{path} must be an object")
        for key in schema.get("required", []):
            require(key in value, f"{path}.{key} is required")
        properties = schema.get("properties", {})
        additional = schema.get("additionalProperties", True)
        if additional is False:
            unknown = sorted(set(value) - set(properties))
            require(not unknown, f"{path} has unsupported fields: {unknown}")
        for key, item in value.items():
            child = properties.get(key)
            if child is not None:
                validate_schema(item, child, schema_root=root, path=f"{path}.{key}")
            elif isinstance(additional, dict):
                validate_schema(item, additional, schema_root=root, path=f"{path}.{key}")
    elif expected == "array":
        require(isinstance(value, list), f"{path} must be an array")
        if "minItems" in schema:
            require(len(value) >= int(schema["minItems"]), f"{path} requires at least {schema['minItems']} items")
        item_schema = schema.get("items")
        if isinstance(item_schema, dict):
            for index, item in enumerate(value):
                validate_schema(item, item_schema, schema_root=root, path=f"{path}[{index}]")
    elif expected == "string":
        require(isinstance(value, str), f"{path} must be a string")
        if "minLength" in schema:
            require(len(value) >= int(schema["minLength"]), f"{path} is too short")
        if "pattern" in schema:
            require(re.fullmatch(str(schema["pattern"]), value) is not None, f"{path} has invalid format")
    elif expected == "integer":
        require(isinstance(value, int) and not isinstance(value, bool), f"{path} must be an integer")
        if "minimum" in schema:
            require(value >= int(schema["minimum"]), f"{path} must be >= {schema['minimum']}")
    elif expected == "null":
        require(value is None, f"{path} must be null")


def schema(name: str) -> dict[str, Any]:
    return load_json(CONTRACT_ROOT / name)


def registry(name: str, version: str) -> dict[str, Any]:
    obj = load_json(CONTRACT_ROOT / name)
    require(obj.get("schema_version") == version, f"{name} schema_version mismatch")
    profiles = obj.get("profiles")
    require(isinstance(profiles, dict) and profiles, f"{name} profiles must be non-empty")
    return profiles


def _under(path: Path, base: Path) -> bool:
    path = path.resolve(); base = base.resolve()
    return path == base or base in path.parents


def _authority_role_allowed(root: Path, request: Path, role: str, path: Path) -> bool:
    exact = {
        "current_request": request / "request.md",
        "requirement_lock": request / "work" / "requirement-lock.md",
        "source_lock": request / "work" / "source-lock.json",
        "narrative_contract": request / "work" / "narrative-visual-contract.json",
        "project_brief": root / "project" / "project-brief.md",
        "material_index": root / "project" / "material-index.json",
        "visual_baseline": root / "project" / "baselines" / "project-visual-standard.md",
    }
    if role in exact:
        return path.resolve() == exact[role].resolve()
    if role == "request_input":
        return _under(path, request / "input") and path.resolve() != (request / "input").resolve()
    if role == "reference":
        return _under(path, request / "input") or _under(path, root / "project" / "references")
    if role == "user_locked_fact":
        allowed = [request / "request.md", request / "work" / "requirement-lock.md", request / "work" / "source-lock.json", root / "project" / "project-brief.md"]
        return any(path.resolve() == p.resolve() for p in allowed)
    if role == "other_authority":
        # Provenance-only compatibility role. It may point only at this request input/work or project facts;
        # it never substitutes for required canonical authority roles.
        return _under(path, request / "input") or _under(path, request / "work") or _under(path, root / "project")
    return False


def validate_authority_trace(root: Path, request: Path, trace: Any) -> list[dict[str, str]]:
    require(isinstance(trace, list) and trace, "authority_trace must be a non-empty array")
    seen: set[tuple[str, str]] = set(); normalized: list[dict[str, str]] = []
    for index, item in enumerate(trace):
        require(isinstance(item, dict), f"authority_trace[{index}] must be an object")
        role = str(item.get("role", "")); rel = str(item.get("path", "")); expected = str(item.get("sha256", ""))
        require(SHA256_RE.fullmatch(expected) is not None, f"authority_trace[{index}].sha256 is invalid")
        path = bounded_path(root, rel)
        require(_authority_role_allowed(root, request, role, path), f"authority role/path mismatch for current request: {role} -> {rel}")
        actual = sha256_file(path); require(actual == expected, f"authority hash mismatch: {rel}")
        key = (role, workspace_relative(root, path)); require(key not in seen, f"duplicate authority trace entry: {key}")
        seen.add(key); normalized.append({"role": role, "path": key[1], "sha256": actual})
    request_md = request / "request.md"; expected_path = workspace_relative(root, request_md); expected_hash = sha256_file(request_md)
    require(any(i["role"] == "current_request" and i["path"] == expected_path and i["sha256"] == expected_hash for i in normalized),
            "authority_trace current_request must bind this request/request.md")
    return normalized


def semantic_payload(contract: dict[str, Any]) -> dict[str, Any]:
    keys = ("selected_moment_or_windows", "protected_narrative_truth", "must_show", "may_show", "must_not_imply", "audience_information", "causal_evidence", "continuity_obligations", "open_issues", "result")
    return {key: contract.get(key) for key in keys}


def semantic_checksum(contract: dict[str, Any]) -> str:
    raw = json.dumps(semantic_payload(contract), ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _nonempty(value: Any) -> bool:
    if isinstance(value, dict):
        if not value: return False
        for k, v in value.items():
            if not isinstance(k, str) or not k.strip(): return False
            if isinstance(v, str) and not v.strip(): return False
            if isinstance(v, list) and (not v or any(not isinstance(x, str) or not x.strip() for x in v)): return False
        return True
    if isinstance(value, list):
        return bool(value) and all(isinstance(x, str) and x.strip() for x in value)
    return value is not None


_DEFAULT_IGNORABLE_RANGES = (
    (0x00AD, 0x00AD), (0x034F, 0x034F), (0x061C, 0x061C),
    (0x115F, 0x1160), (0x17B4, 0x17B5), (0x180B, 0x180F),
    (0x200B, 0x200F), (0x202A, 0x202E), (0x2060, 0x206F),
    (0x3164, 0x3164), (0xFE00, 0xFE0F), (0xFEFF, 0xFEFF),
    (0xFFA0, 0xFFA0), (0xFFF0, 0xFFF8), (0x1BCA0, 0x1BCA3),
    (0x1D173, 0x1D17A), (0xE0000, 0xE0FFF),
)


def _identity_ignored(character: str) -> bool:
    codepoint = ord(character)
    return unicodedata.category(character) in {"Cc", "Cf"} or any(start <= codepoint <= end for start, end in _DEFAULT_IGNORABLE_RANGES)


def _identity_key(value: Any) -> str:
    """Normalize an actor identifier before independence comparison.

    This prevents a producer from nominally becoming an independent reviewer by adding
    case differences or invisible Unicode controls. It is intentionally not an
    authentication system: the execution environment remains responsible for assigning
    the two identities to separate actors.
    """
    text = "".join(character for character in str(value or "") if not _identity_ignored(character))
    return unicodedata.normalize("NFKC", unicodedata.normalize("NFKC", text).casefold()).strip()


def _spec_consumption_requirements(spec: dict[str, Any]) -> dict[str, Any]:
    """Return the Visual Spec claims that a still-image prompt must explicitly consume.

    This is compiler provenance only. It verifies that a prompt contains the submitted
    evidence excerpts; it does not claim that natural-language prompting guarantees the
    generated pixels will faithfully implement those claims.
    """
    intent = spec.get("intent", {})
    roles = spec.get("channel_roles", {})
    required: dict[str, Any] = {
        "intent.visual_logic": intent.get("visual_logic"),
        "channel_roles.lead": roles.get("lead"),
    }
    if isinstance(intent.get("primary"), str) and intent["primary"].strip():
        required["intent.primary"] = intent["primary"]
    for bucket in ("support", "suppress"):
        value = roles.get(bucket)
        if value:
            required[f"channel_roles.{bucket}"] = value
    logic = intent.get("visual_logic")
    if logic == "event":
        required["performance"] = spec.get("performance")
    elif logic == "graphic_asset":
        required["graphic"] = spec.get("graphic")
    return required


def _consumption_leaves(value: Any) -> list[str]:
    """Return explicit prompt material required to prove compiler consumption."""
    if isinstance(value, str):
        return [value] if value.strip() else []
    if isinstance(value, list):
        return [leaf for item in value for leaf in _consumption_leaves(item)]
    if isinstance(value, dict):
        return [leaf for item in value.values() for leaf in _consumption_leaves(item)]
    return []


def _consumption_normalize(value: str) -> str:
    return " ".join(value.split()).casefold()


def _decode_image_facts(path: Path) -> dict[str, Any]:
    try:
        from PIL import Image
    except ImportError as exc:
        raise VisualContractError("Pillow is required to validate a reviewed image target") from exc
    try:
        with Image.open(path) as image:
            image.load()
            return {"format": str(image.format or ""), "width": int(image.width), "height": int(image.height), "mode": str(image.mode or "")}
    except OSError as exc:
        raise VisualContractError(f"reviewed target is not a decodable image: {path}") from exc


def validate_narrative_contract(root: Path, path: Path) -> dict[str, Any]:
    obj = load_json(path); validate_schema(obj, schema("narrative-visual-contract-schema.json"))
    request = resolve_request(root, obj["request_ref"])
    require(path.resolve() == (request / "work" / "narrative-visual-contract.json").resolve(), "Canonical Narrative contract path must be work/narrative-visual-contract.json")
    require_request_binding(root, request, obj, label="Narrative contract")
    require(obj["contract_revision"] == obj["request_revision"], "Narrative contract_revision must equal active request_revision")
    trace = validate_authority_trace(root, request, obj["authority_trace"])
    require(not any(item["role"] == "visual_baseline" or item["path"].startswith("project/baselines/") for item in trace),
            "Narrative contract cannot consume Project Visual Baseline as narrative authority")
    require(obj["semantic_checksum"] == semantic_checksum(obj), "Narrative contract semantic_checksum mismatch")
    require(not obj["open_issues"], "READY Narrative contract cannot retain open_issues")
    return obj


def validate_visual_spec(root: Path, path: Path) -> dict[str, Any]:
    obj = load_json(path); validate_schema(obj, schema("visual-spec-schema.json"))
    request = resolve_request(root, obj["request_ref"])
    require(path.resolve() == (request / "work" / "visual-spec.json").resolve(), "Canonical Visual Spec path must be work/visual-spec.json")
    require_request_binding(root, request, obj, label="Visual Spec")
    profiles = registry("visual-spec-profiles.json", "sicza.visual-spec-profiles.v1")
    profile = profiles.get(obj["profile_id"]); require(isinstance(profile, dict), f"unknown Visual Spec profile: {obj['profile_id']}")
    require(obj["task_kind"] == profile.get("task_kind"), "Visual Spec task_kind does not match profile")
    require(obj["mode"] in profile.get("modes", []), "Visual Spec mode is not allowed by profile")
    for section in profile.get("required_nonempty", []):
        require(_nonempty(obj.get(section)), f"Visual Spec profile requires non-empty {section}")
    if obj["profile_id"] == "visual.still.production.v1":
        roles = obj.get("channel_roles")
        require(isinstance(roles, dict) and roles.get("lead"), "still Visual Spec requires at least one channel_roles.lead")
        buckets = {name: set(values) for name, values in roles.items() if name in {"lead", "support", "suppress"} and isinstance(values, list)}
        require(buckets.get("lead"), "still Visual Spec requires a non-empty channel_roles.lead")
        require(not (buckets.get("lead", set()) & buckets.get("support", set()) or buckets.get("lead", set()) & buckets.get("suppress", set()) or buckets.get("support", set()) & buckets.get("suppress", set())), "channel_roles lead/support/suppress must not overlap")
        logic = obj.get("intent", {}).get("visual_logic") if isinstance(obj.get("intent"), dict) else None
        require(logic in {"event", "display", "graphic_asset"}, "still Visual Spec intent.visual_logic must be event|display|graphic_asset")
        if logic == "event":
            require(_nonempty(obj.get("performance")), "event still Visual Spec requires non-empty performance")
        if logic == "graphic_asset":
            require(_nonempty(obj.get("graphic")), "graphic_asset still Visual Spec requires non-empty graphic")
    require(len(obj["success_condition"]) >= int(profile.get("success_min", 1)), "Visual Spec success_condition is incomplete for profile")
    trace = validate_authority_trace(root, request, obj["authority_trace"])
    roles = {item["role"] for item in trace}; require("current_request" in roles, "Visual Spec authority_trace requires current_request")
    narrative = obj["narrative_trace"]
    if narrative is not None:
        contract_path = bounded_path(root, narrative["path"]); contract = validate_narrative_contract(root, contract_path)
        require(contract["request_ref"] == obj["request_ref"], "Visual Spec cannot consume a Narrative contract from another request")
        require(sha256_file(contract_path) == narrative["sha256"], "narrative_trace sha256 mismatch")
        require(contract["contract_id"] == narrative["contract_id"], "narrative_trace contract_id mismatch")
        require(contract["contract_revision"] == narrative["contract_revision"], "narrative_trace contract_revision mismatch")
        require(contract["semantic_checksum"] == narrative["semantic_checksum"], "narrative_trace semantic_checksum mismatch")
        require(any(i["role"] == "narrative_contract" and i["path"] == workspace_relative(root, contract_path) and i["sha256"] == narrative["sha256"] for i in trace),
                "authority_trace must bind the active narrative_contract")
    else:
        require("narrative_contract" not in roles, "authority_trace contains narrative_contract but narrative_trace is null")
    if obj["task_kind"] == "motion": require(obj["motion"] is not None and _nonempty(obj["motion"]), "motion task requires non-empty motion section")
    return obj


def validate_prompt_binding(root: Path, path: Path) -> dict[str, Any]:
    obj = load_json(path); validate_schema(obj, schema("prompt-binding-schema.json"))
    request = resolve_request(root, obj["request_ref"])
    require(path.resolve() == (request / "work" / "prompt-binding.json").resolve(), "Prompt Binding path must be work/prompt-binding.json")
    require_request_binding(root, request, obj, label="Prompt Binding")
    spec_path = bounded_path(root, obj["visual_spec_path"]); spec = validate_visual_spec(root, spec_path)
    require(spec["request_ref"] == obj["request_ref"], "Prompt Binding cannot bind a Visual Spec from another request")
    require(not spec["unresolved"], "Prompt Binding cannot consume a Visual Spec with unresolved items")
    require(sha256_file(spec_path) == obj["visual_spec_sha256"], "Prompt Binding visual_spec_sha256 mismatch")
    prompt_path = bounded_path(root, obj["prompt_path"]); require(_under(prompt_path, request / "work") and prompt_path != (request / "work").resolve(), "Bound Prompt must be inside current request work/")
    require(sha256_file(prompt_path) == obj["prompt_sha256"], "Prompt Binding prompt_sha256 mismatch")
    expected_semantic = spec["narrative_trace"]["semantic_checksum"] if spec["narrative_trace"] else None
    require(obj["narrative_semantic_checksum"] == expected_semantic, "Prompt Binding narrative semantic checksum mismatch")
    profiles = registry("prompt-compiler-profiles.json", "sicza.prompt-compiler-profiles.v1")
    profile = profiles.get(obj["compiler_profile"]); require(isinstance(profile, dict), f"unknown prompt compiler profile: {obj['compiler_profile']}")
    require(obj["adapter_family"] == profile.get("adapter_family"), "Prompt Binding adapter_family does not match compiler profile")
    pack = bounded_path(root, str(profile.get("prompt_pack", "")))
    require(obj["prompt_pack_path"] == workspace_relative(root, pack), "Prompt Binding prompt_pack_path does not match compiler profile")
    require(obj["prompt_pack_sha256"] == sha256_file(pack), "Prompt Binding prompt_pack_sha256 mismatch")
    expected_claims = _spec_consumption_requirements(spec) if spec.get("profile_id") == "visual.still.production.v1" else {}
    claims = obj.get("spec_consumption", [])
    by_field: dict[str, dict[str, Any]] = {}
    prompt_text = prompt_path.read_text(encoding="utf-8", errors="replace")
    for index, claim in enumerate(claims):
        field = claim["field"]
        require(field in expected_claims, f"Prompt Binding has unsupported Visual Spec consumption field: {field}")
        require(field not in by_field, f"Prompt Binding duplicates Visual Spec consumption field: {field}")
        require(claim["value"] == expected_claims[field], f"Prompt Binding consumption value does not match active Visual Spec: {field}")
        for excerpt in claim["prompt_evidence"]:
            require(excerpt in prompt_text, f"Prompt Binding evidence excerpt is absent from bound prompt: {field}")
        evidence_text = _consumption_normalize(" ".join(claim["prompt_evidence"]))
        required_leaves = [_consumption_normalize(value) for value in _consumption_leaves(expected_claims[field])]
        missing_leaves = [value for value in required_leaves if value not in evidence_text]
        require(not missing_leaves, f"Prompt Binding evidence does not explicitly consume active Visual Spec value: {field}")
        by_field[field] = claim
    if expected_claims:
        missing = sorted(set(expected_claims) - set(by_field))
        require(not missing, f"Prompt Binding omits required Visual Spec consumption fields: {missing}")
    else:
        require(not claims, "Prompt Binding spec_consumption is only valid for still-production Visual Specs")
    return obj


def _review_source_role_allowed(root: Path, request: Path, role: str, path: Path) -> bool:
    exact = {
        "current_request": request / "request.md",
        "requirement_lock": request / "work" / "requirement-lock.md",
        "reference_plan": request / "work" / "reference-plan.json",
        "personal_context": request / "work" / "personal-context.json",
        "project_brief": root / "project" / "project-brief.md",
    }
    if role in exact:
        return path.resolve() == exact[role].resolve()
    if role == "reference_source":
        return (_under(path, request / "input") and path.resolve() != (request / "input").resolve()) or _under(path, root / "project")
    if role == "reference_analysis":
        return _under(path, request / "work") and path.resolve() != (request / "work").resolve()
    if role == "decomposition_manifest":
        return path.resolve() == (request / "work" / "final" / "layer-manifest.json").resolve()
    if role == "decomposition_ownership_audit":
        return path.resolve() == (request / "work" / "final" / "ownership-audit.json").resolve()
    if role == "decomposition_layer":
        return _under(path, request / "work" / "final" / "layers")
    return False


def _required_review_sources(root: Path, request: Path) -> set[tuple[str, str, str]]:
    required = {
        ("current_request", workspace_relative(root, request / "request.md"), sha256_file(request / "request.md")),
        ("requirement_lock", workspace_relative(root, request / "work" / "requirement-lock.md"), sha256_file(request / "work" / "requirement-lock.md")),
    }
    plan_path = request / "work" / "reference-plan.json"
    if plan_path.is_file():
        required.add(("reference_plan", workspace_relative(root, plan_path), sha256_file(plan_path)))
        plan = load_json(plan_path)
        sources = plan.get("sources")
        require(isinstance(sources, list), "reference-plan sources must be an array")
        for index, item in enumerate(sources):
            require(isinstance(item, dict), f"reference-plan sources[{index}] must be an object")
            source_value = item.get("source_path")
            require(isinstance(source_value, str) and source_value.strip(), f"reference-plan sources[{index}] requires source_path")
            source = bounded_path(root, source_value)
            require(_review_source_role_allowed(root, request, "reference_source", source), f"reference source is outside request/project authority: {source_value}")
            required.add(("reference_source", workspace_relative(root, source), sha256_file(source)))
            analysis_value = item.get("analysis_path")
            if isinstance(analysis_value, str) and analysis_value.strip():
                analysis = bounded_path(root, analysis_value)
                require(_review_source_role_allowed(root, request, "reference_analysis", analysis), f"reference analysis is outside current request work: {analysis_value}")
                required.add(("reference_analysis", workspace_relative(root, analysis), sha256_file(analysis)))
            elif item.get("analysis") == "full-reverse":
                raise VisualContractError(f"full-reverse reference is missing analysis_path: {source_value}")
    personal_context = request / "work" / "personal-context.json"
    if personal_context.is_file():
        required.add(("personal_context", workspace_relative(root, personal_context), sha256_file(personal_context)))
    required |= _decomposition_review_sources(root, request)
    return required


def _decomposition_review_sources(root: Path, request: Path) -> set[tuple[str, str, str]]:
    """A layer delivery can only be reviewed against its layers, not against the flattened image.

    The recomposition of a source-locked decomposition is pixel-identical to the source by
    construction, so reviewing only that image proves nothing about who owns which pixels. When the
    request is a layer decomposition, the review must bind the manifest and every formal layer.
    """
    required: set[tuple[str, str, str]] = set()
    state_path = request / "state.json"
    if not state_path.is_file():
        return required
    state = load_json(state_path)
    if state.get("primary_skill") != "wxian-image-layer-decomposition":
        return required
    manifest_path = request / "work" / "final" / "layer-manifest.json"
    if not manifest_path.is_file():
        return required
    required.add(("decomposition_manifest", workspace_relative(root, manifest_path), sha256_file(manifest_path)))
    manifest = load_json(manifest_path)
    layers = manifest.get("layers")
    require(isinstance(layers, list), "layer manifest layers must be an array for review binding")
    for index, entry in enumerate(layers):
        require(isinstance(entry, dict) and isinstance(entry.get("file"), str),
                f"layer manifest layers[{index}] requires file for review binding")
        layer_path = bounded_path(root, entry["file"])
        require(_under(layer_path, request / "work"), f"layer file is outside the request work directory: {entry['file']}")
        required.add(("decomposition_layer", workspace_relative(root, layer_path), sha256_file(layer_path)))
    audit_path = request / "work" / "final" / "ownership-audit.json"
    if audit_path.is_file():
        required.add(("decomposition_ownership_audit", workspace_relative(root, audit_path), sha256_file(audit_path)))
    return required


def validate_independent_visual_review(root: Path, path: Path, *, expected_target: Path | None = None,
                                       expected_visual_spec_sha256: str | None = None,
                                       expected_prompt_binding_sha256: str | None = None,
                                       require_visual_spec: bool = True) -> dict[str, Any]:
    """Validate one independent review receipt.

    `require_visual_spec=False` is for branches whose profile declares no Visual Spec
    (`postprocess-chain` / `composite`): the receipt still has to be a real v2 report that binds
    this request and this exact target, but it cannot be asked to bind a Spec that the branch
    never produces. Callers outside new-generation must use this same validator rather than
    writing a weaker local check.
    """
    obj = load_json(path); validate_schema(obj, schema("visual-independent-review-schema.json"))
    request = resolve_request(root, obj["request_ref"])
    require_request_binding(root, request, obj, label="Independent visual review")
    reviewer_key = _identity_key(obj["reviewer_id"]); producer_key = _identity_key(obj["producer_id"])
    require(reviewer_key and producer_key, "independent visual reviewer and producer identities must be substantive")
    require(reviewer_key != producer_key, "independent visual reviewer must be separate from producer")
    target = bounded_path(root, obj["target_path"])
    require(_under(target, request / "work") and target.resolve() != (request / "work").resolve(), "independent visual review target must belong to current request work/")
    require(sha256_file(target) == obj["target_sha256"], "independent visual review target hash mismatch")
    if expected_target is not None:
        require(target.resolve() == expected_target.resolve(), "independent visual review targets another candidate")
    spec_path = request / "work" / "visual-spec.json"
    spec_present = spec_path.is_file()
    if require_visual_spec or spec_present:
        spec = validate_visual_spec(root, spec_path)
        spec_hash = sha256_file(spec_path)
        require(obj["visual_spec_sha256"] == spec_hash, "independent visual review does not bind the active Visual Spec")
        if expected_visual_spec_sha256 is not None:
            require(spec_hash == expected_visual_spec_sha256, "independent visual review Visual Spec changed after review")
    else:
        require(obj["visual_spec_sha256"] is None,
                "this branch produces no Visual Spec, so the independent review must not assert one")
        spec_hash = None
    binding_path = request / "work" / "prompt-binding.json"
    if binding_path.is_file():
        binding = validate_prompt_binding(root, binding_path)
        binding_hash = sha256_file(binding_path)
        require(binding["visual_spec_sha256"] == spec_hash, "independent visual review Prompt Binding targets another Visual Spec")
        require(obj["prompt_binding_sha256"] == binding_hash, "independent visual review does not bind the active Prompt Binding")
    else:
        binding_hash = None
        require(obj["prompt_binding_sha256"] is None, "independent visual review asserts a missing Prompt Binding")
    if expected_prompt_binding_sha256 is not None:
        require(binding_hash == expected_prompt_binding_sha256, "independent visual review Prompt Binding changed after review")
    seen: set[tuple[str, str, str]] = set()
    for index, item in enumerate(obj["source_bindings"]):
        role = item["role"]; source = bounded_path(root, item["path"])
        require(_review_source_role_allowed(root, request, role, source), f"independent review source role/path mismatch: {role} -> {item['path']}")
        actual = sha256_file(source); require(actual == item["sha256"], f"independent review source hash mismatch: {item['path']}")
        key = (role, workspace_relative(root, source), actual)
        require(key not in seen, f"duplicate independent review source binding: {role} -> {item['path']}")
        seen.add(key)
    missing = sorted(_required_review_sources(root, request) - seen)
    require(not missing, f"independent visual review did not inspect required original/reference sources: {missing}")
    require("sicza-visual-director/DIAGNOSE" in obj["review_methods"], "independent visual review must use sicza-visual-director/DIAGNOSE")
    require(len(set(obj["review_methods"])) == len(obj["review_methods"]), "independent visual review methods must be unique")
    require(len(obj["review_narrative"].strip()) >= 120, "independent visual review narrative is too weak")
    return obj


def validate_visual_gate_result(root: Path, path: Path) -> dict[str, Any]:
    obj = load_json(path); validate_schema(obj, schema("visual-gate-result-schema.json"))
    request = resolve_request(root, obj["request_ref"])
    require(path.resolve() == (request / "work" / "visual-gate-result.json").resolve(), "Visual Gate path must be work/visual-gate-result.json")
    require_request_binding(root, request, obj, label="Visual Gate")
    spec_path = bounded_path(root, obj["visual_spec_path"]); spec = validate_visual_spec(root, spec_path)
    require(not spec["unresolved"], "Visual Gate cannot pass an unresolved Visual Spec")
    require(sha256_file(spec_path) == obj["visual_spec_sha256"], "Visual Gate visual_spec_sha256 mismatch")
    target = bounded_path(root, obj["target_path"])
    require((_under(target, request / "work") and target != (request / "work").resolve()) or (_under(target, request / "input") and target != (request / "input").resolve()), "Visual Gate target must belong to current request input/ or work/")
    require(sha256_file(target) == obj["target_sha256"], "Visual Gate target_sha256 mismatch")
    bp, bh = obj["prompt_binding_path"], obj["prompt_binding_sha256"]
    require((bp is None) == (bh is None), "Visual Gate prompt binding path/hash must be both null or both set")
    if bp is not None:
        binding_path = bounded_path(root, bp); binding = validate_prompt_binding(root, binding_path)
        require(binding["request_ref"] == obj["request_ref"], "Visual Gate Prompt Binding belongs to another request")
        require(sha256_file(binding_path) == bh, "Visual Gate prompt_binding_sha256 mismatch")
        require(binding["visual_spec_sha256"] == obj["visual_spec_sha256"], "Visual Gate Prompt Binding targets another Visual Spec")
    profiles = registry("visual-gate-profiles.json", "sicza.visual-gate-profiles.v1")
    profile = profiles.get(obj["gate_profile"]); require(isinstance(profile, dict), f"unknown visual gate profile: {obj['gate_profile']}")
    review = obj["independent_review"]
    require(obj["reviewer"] == review["reviewer_id"], "Visual Gate reviewer must match independent review reviewer_id")
    reviewer_key = _identity_key(review["reviewer_id"]); producer_key = _identity_key(review["producer_id"])
    require(reviewer_key and producer_key, "Visual Gate reviewer and producer identities must be substantive")
    require(reviewer_key != producer_key, "Visual Gate reviewer must be independent from producer")
    report_path = bounded_path(root, review["review_report_path"])
    require(_under(report_path, request / "work") and report_path != (request / "work").resolve(), "independent review report must belong to current request work/")
    require(sha256_file(report_path) == review["review_report_sha256"], "independent review report hash mismatch")
    report = validate_independent_visual_review(
        root, report_path, expected_target=target,
        expected_visual_spec_sha256=obj["visual_spec_sha256"],
        expected_prompt_binding_sha256=obj["prompt_binding_sha256"],
    )
    for key, expected in {
        "reviewer_id": review["reviewer_id"], "producer_id": review["producer_id"],
        "target_path": obj["target_path"], "target_sha256": obj["target_sha256"],
        "visual_spec_sha256": obj["visual_spec_sha256"], "prompt_binding_sha256": obj["prompt_binding_sha256"],
        "verdict": review["verdict"],
    }.items():
        require(report.get(key) == expected, f"independent review report binding mismatch: {key}")
    if bool(profile.get("requires_decodable_image", False)):
        require(review["decoded_target"] is not None, "Visual Gate requires decoded target image facts")
        require(review["decoded_target"] == _decode_image_facts(target), "independent review decoded target facts do not match exact target bytes")
    else:
        require(review["decoded_target"] is None, "non-image Visual Gate must not assert unverified decoded image facts")
    allowed = set(profile.get("mandatory", [])) | set(profile.get("optional", [])); mandatory = set(profile.get("mandatory", []))
    seen: set[str] = set(); by_name: dict[str, dict[str, Any]] = {}
    for entry in obj["gates"]:
        name = entry["gate"]; require(name in allowed, f"gate is not declared by profile: {name}"); require(name not in seen, f"duplicate visual gate: {name}")
        seen.add(name); by_name[name] = entry
        for evidence in entry["evidence"]:
            ev_path = bounded_path(root, evidence["target_path"])
            require(ev_path.resolve() == target.resolve(), f"gate evidence must bind gated target: {name}")
            require(evidence["target_sha256"] == obj["target_sha256"] and sha256_file(ev_path) == evidence["target_sha256"], f"gate evidence target hash mismatch: {name}")
            require(len(evidence["observation"].strip()) >= 12, f"gate evidence observation is too weak: {name}")
    if obj["result"] == "VISUAL_PASS":
        require(review["verdict"] == "PASS", "VISUAL_PASS cannot bypass an independent reviewer BLOCK")
        missing = sorted(mandatory - seen); require(not missing, f"VISUAL_PASS missing mandatory gates: {missing}")
        require(all(by_name[name]["result"] == "PASS" for name in mandatory), "VISUAL_PASS requires all mandatory gates to PASS")
        require(not any(item["result"] in {"BLOCK", "UNVERIFIED"} for item in obj["gates"]), "VISUAL_PASS cannot contain BLOCK or UNVERIFIED gates")
    elif obj["result"] == "VISUAL_BLOCK":
        require(any(item["result"] in {"BLOCK", "UNVERIFIED"} for item in obj["gates"]), "VISUAL_BLOCK requires BLOCK or UNVERIFIED evidence")
    elif review["verdict"] == "BLOCK":
        require(obj["result"] != "VISUAL_PASS", "independent reviewer BLOCK cannot produce VISUAL_PASS")
    return obj


def validate_baseline_consumption(root: Path, path: Path) -> dict[str, Any]:
    obj = load_json(path); validate_schema(obj, schema("baseline-consumption-schema.json"))
    request = resolve_request(root, obj["request_ref"])
    require(path.resolve() == (request / "work" / "baseline-consumption.json").resolve(), "Baseline receipt path must be work/baseline-consumption.json")
    require_request_binding(root, request, obj, label="Baseline receipt")
    baseline = bounded_path(root, obj["baseline_path"]); index_path = bounded_path(root, obj["baseline_index_path"])
    require(obj["baseline_sha256"] == sha256_file(baseline), "Baseline receipt baseline_sha256 mismatch")
    require(obj["baseline_index_sha256"] == sha256_file(index_path), "Baseline receipt baseline_index_sha256 mismatch")
    index = load_json(index_path)
    require(index.get("baseline_sha256") == obj["baseline_sha256"], "Baseline index does not bind current formal Baseline")
    require(obj["consumer"] in set(index.get("consumers", [])), "Baseline consumer is not registered by Baseline index")
    families=set(index.get("family_ids",[])); floors=set(index.get("floor_ids",[])); chars=set(index.get("character_ids",[]))
    for key, known in (("family_ids",families),("floor_ids",floors),("character_ids",chars)):
        values=obj[key]; require(len(values)==len(set(values)), f"{key} must be unique"); require(set(values)<=known, f"Baseline receipt has unknown {key}")
    if obj["mode"] == "existing-prior": require(bool(obj["family_ids"]), "existing-prior requires at least one family_id")
    else: require(not obj["family_ids"], f"{obj['mode']} must not claim an existing family")
    if obj["mode"] == "novel-direction": require(len(obj["novelty_rationale"].strip()) >= 12, "novel-direction requires concrete novelty_rationale")
    else: require(not obj["novelty_rationale"].strip(), "novelty_rationale is only valid for novel-direction")
    override_ids=[]
    for item in obj["overrides"]:
        require(item["floor_id"] in floors, "Baseline override uses unknown floor_id"); override_ids.append(item["floor_id"])
    require(len(override_ids)==len(set(override_ids)) and not(set(override_ids)&set(obj["floor_ids"])), "Baseline floor decisions overlap or duplicate")
    family_paths=index.get("family_analysis_paths",{}); require(isinstance(family_paths,dict), "Baseline index family_analysis_paths invalid")
    allowed_refs={p for fid in obj["family_ids"] for p in family_paths.get(fid,[])} if obj["family_ids"] else {p for paths in family_paths.values() for p in paths}
    seen_refs=set()
    for item in obj["references"]:
        require(item["analysis_path"] in allowed_refs, f"Baseline receipt reference is not registered: {item['analysis_path']}")
        require(item["analysis_path"] not in seen_refs, "duplicate Baseline reference selection"); seen_refs.add(item["analysis_path"])
    return obj


def validate_visual_return(root: Path, path: Path) -> dict[str, Any]:
    obj = load_json(path); validate_schema(obj, schema("visual-return-schema.json"))
    request = resolve_request(root, obj["request_ref"])
    require(path.resolve() == (request / "work" / "visual-return.json").resolve(), "Visual Return path must be work/visual-return.json")
    state = load_json(request / "state.json"); require(state.get("revision") == obj["request_revision"], "Visual Return request_revision does not match state.json")
    contract_path = obj["related_contract_path"]; contract_hash = obj["related_contract_sha256"]
    require((contract_path is None) == (contract_hash is None), "related_contract_path/hash must be both null or both set")
    if contract_path is not None:
        resolved = bounded_path(root, contract_path); require(_under(resolved, request / "work"), "Visual Return related contract must belong to current request work/")
        require(sha256_file(resolved) == contract_hash, "Visual Return related contract hash mismatch")
    return obj
