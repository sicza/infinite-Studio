#!/usr/bin/env python3
"""Shared deterministic image finalization for KV/UI delivery gates.

Computes machine-addressable pixel, ownership, source-lock, recomposition and diff facts.
Professional visual review remains in the Skill QA manifests.
"""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Iterable

from PIL import Image, ImageChops, ImageDraw, ImageStat


class FinalizationError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise FinalizationError(message)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_rgba(path: Path) -> Image.Image:
    with Image.open(path) as opened:
        opened.load()
        require(opened.format == "PNG", f"formal artifact must be PNG: {path.name}")
        return opened.convert("RGBA")


def expected_delivery_reference(source_path: Path, delivery_canvas: tuple[int, int]) -> Image.Image:
    """Build delivery-space source authority directly from decoded source pixels.

    This deliberately never routes through an AI/model work surface. When delivery
    equals source size, RGB(A) pixels are preserved exactly. Explicit delivery resize
    is a single deterministic Lanczos resample from source.
    """
    with Image.open(source_path) as opened:
        opened.load()
        image = opened.convert("RGBA")
    if image.size == delivery_canvas:
        return image.copy()
    return image.resize(delivery_canvas, Image.Resampling.LANCZOS)


def require_delivery_reference(source_path: Path, delivery_path: Path, delivery_canvas: tuple[int, int], label: str) -> Image.Image:
    expected = expected_delivery_reference(source_path, delivery_canvas)
    actual = load_rgba(delivery_path)
    require(actual.size == delivery_canvas, f"{label} canvas mismatch")
    require(expected.tobytes() == actual.tobytes(), f"{label} is not derived directly from source pixels")
    return actual


def compose_full_canvas(layer_paths: Iterable[tuple[int, Path]], canvas: tuple[int, int]) -> Image.Image:
    result = Image.new("RGBA", canvas, (0, 0, 0, 0))
    seen_z: set[int] = set()
    count = 0
    for z_order, path in sorted(layer_paths, key=lambda item: item[0]):
        require(z_order not in seen_z, f"duplicate z_order in deterministic finalization: {z_order}")
        seen_z.add(z_order)
        layer = load_rgba(path)
        require(layer.size == canvas, f"deterministic recomposition requires full-canvas layer: {path.name}")
        result.alpha_composite(layer)
        count += 1
    require(count > 0, "deterministic recomposition requires at least one layer")
    return result


def require_pixel_equal(expected: Image.Image, actual_path: Path, label: str) -> None:
    actual = load_rgba(actual_path)
    require(actual.size == expected.size, f"{label} canvas mismatch")
    require(expected.convert('RGBA').tobytes() == actual.tobytes(),
            f"{label} is inconsistent with current final layer files")


def build_text_evaluation_mask(plan_layers: list[dict], canvas: tuple[int, int]) -> Image.Image:
    """255 = evaluate source fidelity, 0 = intentionally ignored ordinary text."""
    mask = Image.new("L", canvas, 255)
    draw = ImageDraw.Draw(mask)
    for layer in plan_layers:
        if not (layer.get("contains_text") and layer.get("text_policy") == "strip-and-fill"):
            continue
        for region in layer.get("text_regions", []):
            x, y, w, h = region
            draw.rectangle((x, y, x + w - 1, y + h - 1), fill=0)
    require(mask.getbbox() is not None, "text policy excludes the entire UI source canvas from fidelity evaluation")
    return mask



def _any_channel_changed(image: Image.Image, bands: tuple[str, ...]) -> Image.Image:
    changed = Image.new("L", image.size, 0)
    for band in bands:
        binary = image.getchannel(band).point(lambda value: 255 if value else 0)
        changed = ImageChops.lighter(changed, binary)
    return changed

def diff_metrics(source: Image.Image, recomposed: Image.Image, evaluation_mask: Image.Image | None = None) -> dict:
    require(source.size == recomposed.size, "source and recomposition sizes differ")
    raw = ImageChops.difference(source.convert("RGBA"), recomposed.convert("RGBA"))
    if evaluation_mask is None:
        mask = Image.new("L", source.size, 255)
    else:
        require(evaluation_mask.size == source.size, "evaluation mask size differs from source")
        mask = evaluation_mask.convert("L")
        require(mask.getbbox() is not None, "evaluation mask selects no pixels")
    # A changed pixel is any evaluated pixel with a non-zero RGBA channel difference.
    changed = _any_channel_changed(raw, ("R", "G", "B", "A"))
    evaluated_binary = mask.point(lambda value: 255 if value else 0)
    changed = ImageChops.multiply(changed, evaluated_binary)
    changed_pixels = sum(changed.histogram()[1:])
    evaluated_pixels = sum(evaluated_binary.histogram()[1:])
    mean_channels = ImageStat.Stat(raw, mask=mask).mean
    mean_abs = sum(mean_channels) / len(mean_channels)
    changed_bbox = changed.getbbox()
    return {
        "mean_absolute_channel_difference": mean_abs,
        "changed_bbox": list(changed_bbox) if changed_bbox else None,
        "pixel_identical": changed_bbox is None,
        "changed_pixels": changed_pixels,
        "evaluated_pixels": evaluated_pixels,
        "changed_pixel_ratio": (changed_pixels / evaluated_pixels) if evaluated_pixels else 0.0,
    }


def require_not_catastrophic(metrics: dict, label: str) -> None:
    """Require source/recomposition similarity above the machine-level completion floor."""
    ratio = float(metrics["changed_pixel_ratio"])
    mean_abs = float(metrics["mean_absolute_channel_difference"])
    require(not (ratio >= 0.75 and mean_abs >= 32.0),
            f"{label} has catastrophic source mismatch: changed_ratio={ratio:.6f}, mean_abs={mean_abs:.6f}")


def require_masked_source_rgb_lock(source: Image.Image, layer: Image.Image, mask: Image.Image,
                                   label: str, threshold: int = 16) -> None:
    require(source.size == layer.size == mask.size, f"{label} source-lock canvas mismatch")
    selected = mask.getchannel("A").point(lambda value: 255 if value > threshold else 0)
    require(selected.getbbox() is not None, f"{label} source-visible mask selects no pixels")
    src_rgb = source.convert("RGB")
    layer_rgb = layer.convert("RGB")
    raw = ImageChops.difference(src_rgb, layer_rgb)
    changed = _any_channel_changed(raw, ("R", "G", "B"))
    changed = ImageChops.multiply(changed, selected)
    require(changed.getbbox() is None, f"{label} violates source-visible RGB lock")


def require_scene_not_transparent(scene: Image.Image, label: str = "scene-clean") -> None:
    alpha = scene.getchannel("A")
    extrema = alpha.getextrema()
    require(extrema is not None and extrema[1] > 0, f"{label} is fully transparent")
    # scene-clean is declared transparent=false in the UI plan; transparent holes are not a final scene.
    require(extrema[0] == 255 and extrema[1] == 255, f"{label} must be fully opaque")


def ownership_maps(mask_paths: Iterable[Path], canvas: tuple[int, int], threshold: int = 16) -> tuple[dict, Image.Image, Image.Image]:
    require(0 <= threshold <= 254, "ownership threshold must be 0..254")
    coverage = Image.new("L", canvas, 0)
    overlap = Image.new("L", canvas, 0)
    count = 0
    for path in mask_paths:
        mask = load_rgba(path)
        require(mask.size == canvas, f"ownership mask canvas mismatch: {path.name}")
        binary = mask.getchannel("A").point(lambda value: 255 if value > threshold else 0, mode="L")
        duplicate = ImageChops.multiply(coverage, binary)
        overlap = ImageChops.lighter(overlap, duplicate)
        coverage = ImageChops.lighter(coverage, binary)
        count += 1
    require(count > 0, "ownership finalization found no primary owner masks")
    holes = ImageChops.invert(coverage)
    overlap_pixels = sum(overlap.histogram()[1:])
    hole_pixels = sum(holes.histogram()[1:])
    return ({
        "threshold": threshold,
        "primary_owner_layer_count": count,
        "overlap_pixels": overlap_pixels,
        "hole_pixels": hole_pixels,
        "overlap_bbox": list(overlap.getbbox()) if overlap.getbbox() else None,
        "hole_bbox": list(holes.getbbox()) if holes.getbbox() else None,
    }, overlap, holes)


def delivery_box_to_work(box, size_contract: dict) -> tuple[int, int, int, int]:
    """Map a delivery-space box onto the provider work surface."""
    transforms = size_contract.get("transforms")
    require(isinstance(transforms, dict), "size contract transforms are missing")
    work_to_delivery = transforms.get("work_to_delivery")
    require(isinstance(work_to_delivery, dict), "size contract work_to_delivery is missing")
    scale_x = float(work_to_delivery["scale_x"])
    scale_y = float(work_to_delivery["scale_y"])
    require(scale_x > 0 and scale_y > 0, "work_to_delivery scale must be positive")
    offset_x = float(work_to_delivery.get("offset_x", 0.0))
    offset_y = float(work_to_delivery.get("offset_y", 0.0))
    crop_x, crop_y = work_to_delivery["crop_rect"][0], work_to_delivery["crop_rect"][1]
    x = (float(box[0]) - offset_x) / scale_x + crop_x
    y = (float(box[1]) - offset_y) / scale_y + crop_y
    right = (float(box[0] + box[2]) - offset_x) / scale_x + crop_x
    bottom = (float(box[1] + box[3]) - offset_y) / scale_y + crop_y
    work_box = (int(round(x)), int(round(y)), int(round(right - x)), int(round(bottom - y)))
    require(work_box[2] > 0 and work_box[3] > 0, "mapped work box is empty")
    return work_box


def alpha_region_stats(alpha: Image.Image, box, threshold: int = 16) -> dict:
    """Count alpha distribution inside one box without materialising a full mask."""
    x, y, width, height = (int(v) for v in box)
    require(width > 0 and height > 0, "alpha region box must be positive")
    require(0 <= threshold <= 255, "alpha threshold must be 0..255")
    left, top = max(0, x), max(0, y)
    right, bottom = min(alpha.width, x + width), min(alpha.height, y + height)
    if right <= left or bottom <= top:
        return {"box": [x, y, width, height], "visible_pixels": 0, "opaque_pixels": 0,
                "semi_pixels": 0, "visible_ratio": 0.0, "semi_share": 0.0}
    histogram = alpha.crop((left, top, right, bottom)).histogram()
    visible = sum(histogram[threshold:])
    semi = sum(histogram[threshold:255])
    area = width * height
    return {
        "box": [x, y, width, height],
        "visible_pixels": visible,
        "opaque_pixels": histogram[255],
        "semi_pixels": semi,
        "visible_ratio": visible / area,
        "semi_share": (semi / visible) if visible else 0.0,
    }


def bbox_fill_ratio(alpha: Image.Image, box, threshold: int = 16) -> float:
    """Share of the declared bbox filled by visible alpha."""
    return alpha_region_stats(alpha, box, threshold)["visible_ratio"]


MAX_BBOX_FILL_RATIO = 0.9
MAX_OWNERSHIP_LOST_RATIO = 0.5
MIN_MEMBER_OWNERSHIP_SHARE = 0.8
MAX_FOREIGN_OWNERSHIP_SHARE = 0.2
MIN_MATTE_OPAQUE_SHARE = 0.25
MIN_REGISTERED_ALPHA_SHARE = 0.6
RECTANGULAR_LAYER_TYPES = frozenset({
    "background-clean", "text-logo-overlay", "decoration-overlay", "building", "vehicle", "prop",
})
SOFT_ALPHA_LAYER_TYPES = frozenset({"effect", "shadow", "reflection"})


def is_rectangular_layer(layer_type: str) -> bool:
    """Single exemption predicate shared by every consumer of the bbox fill rule."""
    return str(layer_type) in RECTANGULAR_LAYER_TYPES


def is_full_canvas_box(bbox, canvas) -> bool:
    if not (isinstance(bbox, (list, tuple)) and len(bbox) == 4):
        return False
    if not (isinstance(canvas, (list, tuple)) and len(canvas) == 2):
        return False
    return bbox[0] <= 0 and bbox[1] <= 0 and bbox[2] >= canvas[0] and bbox[3] >= canvas[1]


def has_transparent_provider_pass(api_calls) -> bool:
    if not isinstance(api_calls, (list, tuple)):
        return False
    for call in api_calls:
        parameters = call.get("parameters") if isinstance(call, dict) else None
        if isinstance(parameters, dict) and str(parameters.get("background", "")).lower() == "transparent":
            return True
    return False


def is_ownership_unit(layer_type: str, api_calls, bbox=None, canvas=None,
                      z_order=None, bottom_z=None) -> bool:
    """True when this layer is a subject unit whose provider matte must be resolved against peers.

    Membership is a structural fact - the layer actually produced at least one transparent provider
    response - and never the declared `strategy` string. A declared field would otherwise be the last
    switch that silences the pairwise matte check.

    A clean plate is excluded only when the label, a full-canvas bbox and the lowest z_order agree:
    a plate is by definition the bottom-most full-canvas candidate. Anything missing fails closed.
    """
    if not has_transparent_provider_pass(api_calls):
        return False
    if str(layer_type) == "background-clean":
        if (is_full_canvas_box(bbox, canvas) and isinstance(z_order, int) and isinstance(bottom_z, int)
                and z_order == bottom_z):
            return False
    return True


def is_soft_alpha_layer(layer_type: str) -> bool:
    return str(layer_type) in SOFT_ALPHA_LAYER_TYPES


def alpha_quality_metrics(alpha: Image.Image, delivery_bbox_hint, size_contract: dict,
                          threshold: int = 16, containment_tolerance_px: int = 8,
                          min_opaque_share: float = MIN_MATTE_OPAQUE_SHARE) -> dict:
    """Judge whether a provider response can serve as a per-unit alpha matte at all.

    A provider alpha that is a canvas-wide translucent veil, or that escapes the analyzed
    bbox, cannot isolate the declared unit no matter how ownership is resolved later.
    """
    binary = alpha.point(lambda value: 255 if value >= threshold else 0)
    alpha_bbox = binary.getbbox()
    require(alpha_bbox is not None, "provider alpha has no visible pixels")
    overall = alpha_region_stats(alpha, (0, 0, alpha.width, alpha.height), threshold)
    hint = delivery_box_to_work(delivery_bbox_hint, size_contract)
    tolerance = max(0, int(containment_tolerance_px))
    padded = (hint[0] - tolerance, hint[1] - tolerance, hint[2] + tolerance * 2, hint[3] + tolerance * 2)
    inside = alpha_region_stats(alpha, padded, threshold)
    visible_total = overall["visible_pixels"]
    containment_ratio = inside["visible_pixels"] / visible_total if visible_total else 0.0
    hint_coverage = inside["visible_pixels"] / (hint[2] * hint[3])
    opaque_share = overall["opaque_pixels"] / visible_total if visible_total else 0.0
    reasons: list[str] = []
    if containment_ratio < 0.9:
        reasons.append(
            f"provider alpha escapes the analyzed bbox: containment={containment_ratio:.4f} "
            f"alpha_bbox={list(alpha_bbox)} work_hint={list(hint)}")
    if opaque_share < float(min_opaque_share):
        reasons.append(
            f"provider alpha is not a matte: only {opaque_share:.4f} of visible alpha is fully opaque "
            f"(floor {float(min_opaque_share):.4f}); a translucent full-canvas veil cannot isolate one unit")
    if hint_coverage < 0.005:
        reasons.append(f"provider alpha barely covers the analyzed bbox: hint_coverage={hint_coverage:.6f}")
    return {
        "threshold": threshold,
        "alpha_bbox": list(alpha_bbox),
        "work_bbox_hint": list(hint),
        "containment_ratio": containment_ratio,
        "hint_coverage_ratio": hint_coverage,
        "visible_pixels": visible_total,
        "opaque_pixels": overall["opaque_pixels"],
        "opaque_share": opaque_share,
        "status": "passed" if not reasons else "failed",
        "reasons": reasons,
    }


def require_alpha_quality(metrics: dict, label: str) -> None:
    require(metrics.get("status") == "passed",
            f"{label} provider alpha is unusable for this unit: " + "; ".join(metrics.get("reasons") or []))


def alpha_mask_rgba(mask: Image.Image) -> Image.Image:
    rgba = Image.new("RGBA", mask.size, (255, 255, 255, 0))
    rgba.putalpha(mask.convert("L"))
    return rgba


def diff_artifacts(source: Image.Image, recomposed: Image.Image,
                   evaluation_mask: Image.Image | None = None) -> tuple[dict, Image.Image]:
    require(source.size == recomposed.size, "source and recomposition sizes differ")
    raw = ImageChops.difference(source.convert("RGBA"), recomposed.convert("RGBA"))
    if evaluation_mask is None:
        diff = raw
        metrics = diff_metrics(source, recomposed, None)
    else:
        require(evaluation_mask.size == source.size, "evaluation mask size differs from source")
        mask = evaluation_mask.convert("L")
        require(mask.getbbox() is not None, "evaluation mask selects no pixels")
        transparent = Image.new("RGBA", source.size, (0, 0, 0, 0))
        diff = Image.composite(raw, transparent, mask)
        metrics = diff_metrics(source, recomposed, mask)
    return metrics, diff
