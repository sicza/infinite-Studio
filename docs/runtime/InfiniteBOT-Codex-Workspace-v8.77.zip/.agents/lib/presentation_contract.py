#!/usr/bin/env python3
"""Shared fail-closed contract for how a produced picture presents itself.

A produced deliverable is a **complete picture**: the canvas is filled by image
content. Two things must never be asked of the model:

1. **carrier framing** — a business carrier label (ICON / LOGO / BANNER / KV /
   商店图 / 弹窗 …) named as the thing to create, instead of the complete
   picture. The carrier describes the business object downstream; it is not a
   picture instruction.
2. **presentation simulation** — rounded corners, an app-icon mask/crop,
   squircle, corner radius, a white corner field, or store safe-area frames
   baked into the artwork. Rounding, masking, safe areas and device frames
   belong to delivery / store post-processing, never to generation.

Both rules are machine facts here and are enforced by real consumers:
`image-generation-api` before any network call, and the image-production
delivery gate before Promote. Rounding or masking a delivered picture cannot be
asked for in a prompt and cannot be shipped by accident.

The prompt-side rules are intentionally *not* negation-aware for presentation
simulation: writing "no rounded corners" into a prompt still spends model
attention on corner treatment, so the contract bans the wording entirely.
Carrier framing is negation-aware so that legitimate negative lists such as
"No words, logos, UI" stay valid.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

SCHEMA_VERSION = "sicza.presentation-contract.v1"

# A complete-visual request describes the picture, not the carrier slot it will
# be placed in, and never simulates the carrier's presentation.
COMPLETE_VISUAL_STATEMENT = (
    "describe the complete picture itself (for example \"Create a complete image of ...\"); "
    "the carrier slot, its rounding and its safe area are delivery post-processing"
)


class PresentationError(ValueError):
    """Raised when a prompt or a delivered picture violates the contract."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise PresentationError(message)


# --- prompt contract -------------------------------------------------------

# rule_id -> compiled pattern. Each pattern is applied to the whole prompt with
# sentence-level reporting so the finding can point at real text.
SIMULATION_RULES: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("rounded-corner", re.compile(r"圆角", re.IGNORECASE)),
    ("rounded-corner", re.compile(r"\brounded[\s\-]+(?:square|corner|mask|app|icon|canvas|frame|crop|tile)\b", re.IGNORECASE)),
    ("corner-radius", re.compile(r"\bcorner[\s\-]*radius\b", re.IGNORECASE)),
    ("app-mask", re.compile(r"\b(?:app|application|store)[\s\-]*icon[\s\-]+(?:crop|mask|frame|shape|canvas|format|ratio|corner|tile)\b", re.IGNORECASE)),
    ("app-mask", re.compile(r"\bicon[\s\-]+(?:crop|mask|frame|squircle|tile)\b", re.IGNORECASE)),
    ("app-mask", re.compile(r"\bsquircle\b", re.IGNORECASE)),
    ("app-mask", re.compile(r"\bmask(?:ed|ing)?[\s\-]+corners?\b", re.IGNORECASE)),
    ("corner-field", re.compile(r"\bwhite[\s\-]+corner[\s\-]+(?:field|area|margin|block)\b", re.IGNORECASE)),
    ("corner-field", re.compile(r"\bcorner[\s\-]+field\b", re.IGNORECASE)),
    ("corner-field", re.compile(r"四角(?:留白|圆角|空|白)")),
    ("app-mask", re.compile(r"(?:图标|icon)[^。！？\n]{0,12}(?:裁切|蒙版|外形|外框|圆角)", re.IGNORECASE)),
    ("app-mask", re.compile(r"(?:裁切|蒙版|外框)[^。！？\n]{0,8}(?:圆角|圆角方形)")),
)

# --- carrier policy (single point) -----------------------------------------
# Two levels, one definition. `BLOCKING` artefacts spend model attention on the
# carrier slot itself and are refused before any network call. `RECEIPT` carriers
# are recorded as machine facts without blocking, because the user named ICON and
# rounding specifically and blocking every carrier word would refuse in-flight
# work that has no defect. Escalating RECEIPT to BLOCKING is a one-line change.
CARRIER_POLICY_RECEIPT = "receipt"

BLOCKING_CARRIERS_EN = ("app icon", "application icon", "game icon", "icon")
BLOCKING_CARRIERS_ZH = ("图标",)
RECEIPT_CARRIERS_EN = (
    "logo", "wordmark", "banner", "key visual", "kv", "store artwork",
    "store image", "store screenshot", "feature graphic", "screenshot",
)
RECEIPT_CARRIERS_ZH = ("标志", "字标", "横幅", "主视觉", "商店图", "商店截屏", "商店截图")

# a carrier word next to a canvas/presentation noun always simulates the slot,
# whatever the carrier's own policy level is
PRESENTATION_NOUNS = ("crop", "mask", "frame", "canvas", "shape", "ratio", "tile", "corner")

CREATION_VERB_EN = r"(?:create|generate|make|draw|render|design|produce|paint|build)"
CREATION_VERB_ZH = r"(?:生成|制作|做|绘制|设计|出|画)"

def _task_framing(words_en, words_zh) -> tuple[re.Pattern[str], ...]:
    return (
        re.compile(
            r"\b" + CREATION_VERB_EN + r"\b([^.\n]{0,80}?)\b(" + "|".join(re.escape(w) for w in words_en) + r")\b",
            re.IGNORECASE,
        ),
        re.compile(
            CREATION_VERB_ZH + r"[^。！？\n]{0,40}?(" + "|".join(re.escape(w) for w in words_zh) + r")"
        ),
    )


_TASK_FRAMING = _task_framing(BLOCKING_CARRIERS_EN, BLOCKING_CARRIERS_ZH)
_RECEIPT_FRAMING = _task_framing(RECEIPT_CARRIERS_EN, RECEIPT_CARRIERS_ZH)
_SLOT_SIMULATION = (
    re.compile(r"\b(?:app icon|application icon|game icon|icon|logo|banner|key visual|kv|store artwork)\b[^.,\n]{0,20}\b(?:"
               + "|".join(PRESENTATION_NOUNS) + r")\b", re.IGNORECASE),
    re.compile(r"(?:图标|标志|字标|横幅|主视觉|商店图)[^。！？\n]{0,10}(?:裁切|蒙版|外框|画布|比例|图块|圆角)"),
)

NEGATION_CUE = re.compile(
    r"^\s*(?:no|not|without|avoid|never|exclude|do\s+not|don'?t|omit|remove)\b|不得|禁止|不要|无需|不能|避免|没有",
    re.IGNORECASE,
)

_SENTENCE = re.compile(r"[^.!?\n。！？]+[.!?\n。！？]?", re.UNICODE)


def _sentences(text: str) -> list[tuple[int, str]]:
    return [(match.start(), match.group(0)) for match in _SENTENCE.finditer(text)]


def _excerpt(text: str, start: int, end: int, width: int = 48) -> str:
    lo = max(0, start - 8)
    hi = min(len(text), end + 8)
    fragment = text[lo:hi].replace("\n", " ").strip()
    if len(fragment) > width:
        fragment = fragment[: width - 1] + "…"
    return fragment


def find_simulation(text: str) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    seen: set[tuple[str, int]] = set()
    for rule_id, pattern in SIMULATION_RULES:
        for match in pattern.finditer(text):
            key = (rule_id, match.start())
            if key in seen:
                continue
            seen.add(key)
            findings.append({
                "rule": rule_id,
                "class": "presentation-simulation",
                "match": match.group(0),
                "offset": match.start(),
                "excerpt": _excerpt(text, match.start(), match.end()),
            })
    return sorted(findings, key=lambda item: item["offset"])


def find_carrier_framing(text: str) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    seen: set[int] = set()
    for index, (offset, sentence) in enumerate(_sentences(text)):
        if not sentence.strip():
            continue
        if index > 0 and NEGATION_CUE.search(sentence):
            continue
        if index == 0 and NEGATION_CUE.search(sentence[: sentence.find(" ") + 1] or ""):
            continue
        for pattern in _TASK_FRAMING:
            match = pattern.search(sentence)
            if match is None:
                continue
            head = sentence[: match.start()]
            if NEGATION_CUE.search(head):
                continue
            start = offset + match.start(1 if match.lastindex and match.lastindex >= 1 else 0)
            if start in seen:
                continue
            seen.add(start)
            findings.append({
                "rule": "carrier-framing",
                "class": "carrier-framing",
                "match": (match.group(2) if match.lastindex and match.lastindex >= 2 else match.group(0)),
                "offset": start,
                "excerpt": _excerpt(text, start, offset + match.end()),
            })
            break
    return sorted(findings, key=lambda item: item["offset"])


def find_slot_simulation(text: str) -> list[dict[str, Any]]:
    """Any carrier word that simulates the carrier's canvas is blocking."""
    findings: list[dict[str, Any]] = []
    seen: set[int] = set()
    for pattern in _SLOT_SIMULATION:
        for match in pattern.finditer(text):
            if match.start() in seen:
                continue
            seen.add(match.start())
            findings.append({
                "rule": "carrier-slot-simulation",
                "class": "carrier-framing",
                "match": match.group(0),
                "offset": match.start(),
                "excerpt": _excerpt(text, match.start(), match.end()),
            })
    return findings


def carrier_receipt(text: str) -> dict[str, Any]:
    """Non-blocking carrier hits, recorded as machine fact for later escalation."""
    findings: list[dict[str, Any]] = []
    seen: set[int] = set()
    for pattern in _RECEIPT_FRAMING:
        for sentence_start, sentence in _sentences(text):
            if not sentence.strip() or NEGATION_CUE.search(sentence):
                continue
            match = pattern.search(sentence)
            if match is None:
                continue
            hit_word = match.group(2) if match.lastindex and match.lastindex >= 2 else match.group(0)
            start = sentence_start + match.start()
            if start in seen:
                continue
            seen.add(start)
            findings.append({
                "rule": "carrier-receipt",
                "class": "carrier-framing",
                "policy": CARRIER_POLICY_RECEIPT,
                "match": hit_word,
                "offset": start,
                "excerpt": _excerpt(text, start, sentence_start + match.end()),
            })
    findings.sort(key=lambda item: item["offset"])
    return {
        "policy": CARRIER_POLICY_RECEIPT,
        "blocking": False,
        "hits": findings,
        "words": sorted({str(item["match"]).casefold() for item in findings}),
    }


def lint_prompt(text: str) -> dict[str, Any]:
    """Return the machine verdict for one authored prompt."""
    require(isinstance(text, str) and bool(text.strip()), "prompt text must be non-empty")
    findings = find_simulation(text) + find_carrier_framing(text) + find_slot_simulation(text)
    findings.sort(key=lambda item: item["offset"])
    return {
        "schema_version": SCHEMA_VERSION,
        "status": "blocked" if findings else "passed",
        "findings": findings,
        "rule_ids": sorted({item["rule"] for item in findings}),
        "carrier_policy": {
            "blocking": list(BLOCKING_CARRIERS_EN) + list(BLOCKING_CARRIERS_ZH),
            "receipt": list(RECEIPT_CARRIERS_EN) + list(RECEIPT_CARRIERS_ZH),
        },
        "receipts": carrier_receipt(text),
    }


def require_clean_prompt(text: str, *, label: str = "prompt") -> dict[str, Any]:
    """Fail closed on an authored prompt that violates the presentation contract."""
    verdict = lint_prompt(text)
    if verdict["status"] == "blocked":
        details = "; ".join(f"{item['rule']} @ {item['excerpt']!r}" for item in verdict["findings"][:4])
        raise PresentationError(
            f"{label} violates the complete-visual presentation contract: {details}. "
            f"Rewrite it to {COMPLETE_VISUAL_STATEMENT}."
        )
    return verdict


# --- delivered-picture contract -------------------------------------------

CORNER_TOLERANCE = 8
FLAT_TOLERANCE = 6
PLATE_TOLERANCE = 12

# A baked carrier plate is a colour that stays THIN inward at every point of every
# edge. Measuring the distance to content along one diagonal confuses it with a
# large centred subject, because that distance shrinks as the subject grows. So the
# depth is probed PERPENDICULAR to the four edges at several positions each: a
# margin stays thin everywhere, while a background necessarily reaches deep inward
# somewhere (a centred subject never spans every row and every column).
# A picture is refused when one clean flat colour owns the four corners, reaches at
# least this far inward there, and does NOT touch the middle of any edge. The reach is
# the only threshold: a 12%-thin-margin rule was tried twice and could not separate a
# carrier from a large centred subject, so no such rule survives here.
MASK_MIN_CORNER_REACH = 0.05

# A baked rounded carrier is not just "four flat corners". Its corner plate is a
# quarter-disc complement, so the corner box is mostly content: the share of the
# corner box still owned by the plate colour stays near (1 - pi/4) = 0.215. A flat
# background behind a cross, a bleeding disc or a cropped subject fills its whole
# corner box (share ~1.0), and a 45-degree chamfer sits at 0.5. Requiring the corner
# share to be small is what separates a BAKED ROUNDING (refuse) from a legitimate
# graphic whose background happens to own four corners (release).
ARC_MAX_CORNER_SHARE = 0.38
ARC_RADIUS_SYMMETRY = 0.4
ARC_MIN_CORNERS = 3


def _same(pixel, colour, tolerance: int = PLATE_TOLERANCE) -> bool:
    return all(abs(pixel[channel] - colour[channel]) <= tolerance for channel in range(3))


def _corner_squares(image, size: int) -> dict[str, list[tuple[int, ...]]]:
    """Pixel blocks at the four corners, used to describe the corner field."""
    width, height = image.size
    boxes = {
        "top-left": (0, 0, size, size),
        "top-right": (width - size, 0, width, size),
        "bottom-left": (0, height - size, size, height),
        "bottom-right": (width - size, height - size, width, height),
    }
    blocks: dict[str, list[tuple[int, ...]]] = {}
    for name, (x0, y0, x1, y1) in boxes.items():
        block = []
        for y in range(y0, y1):
            for x in range(x0, x1):
                pixel = image.getpixel((x, y))
                block.append(tuple(pixel[:3]) if isinstance(pixel, tuple) else (pixel, pixel, pixel))
        blocks[name] = block
    return blocks


def _mean(pixels) -> tuple[float, float, float]:
    count = len(pixels) or 1
    return tuple(sum(pixel[i] for pixel in pixels) / count for i in range(3))


def _flatness(pixels) -> float:
    """Largest per-channel spread inside a block; a flat plate stays below tolerance."""
    if not pixels:
        return 0.0
    return max(max(pixel[i] for pixel in pixels) - min(pixel[i] for pixel in pixels) for i in range(3))


def _distance(a, b) -> float:
    return max(abs(float(a[i]) - float(b[i])) for i in range(3))




def edge_depth(image, colour, size: int, *, vertical: bool, offset: int) -> int:
    """Depth of ``colour`` measured inward from an edge, starting at ``offset``."""
    width, height = image.size
    depth = 0
    if vertical:
        x = offset
        for y in range(height):
            if not _same(image.getpixel((x, y)), colour):
                break
            depth += 1
    else:
        y = offset
        for x in range(width):
            if not _same(image.getpixel((x, y)), colour):
                break
            depth += 1
    return depth


def plate_depth_profile(image, colour, size: int) -> tuple[int, int]:
    """Deepest and shallowest inward depth of the corner colour along the four edges."""
    width, height = image.size
    xs = sorted({0, width // 8, width // 4, width // 2, (3 * width) // 4, (7 * width) // 8, width - 1})
    ys = sorted({0, height // 8, height // 4, height // 2, (3 * height) // 4, (7 * height) // 8, height - 1})
    depths = [edge_depth(image, colour, size, vertical=True, offset=x) for x in xs]
    depths += [edge_depth(image, colour, size, vertical=False, offset=y) for y in ys]
    return max(depths), min(depths)


CORNER_ORIGINS = {
    "top-left": (0, 0, 1, 1),
    "top-right": (-1, 0, -1, 1),
    "bottom-left": (0, -1, 1, -1),
    "bottom-right": (-1, -1, -1, -1),
}


def corner_arc_shape(image, name: str, colour) -> dict[str, Any]:
    """Measure one corner as (edge reach, edge reach, plate share of its corner box).

    `share` is the discriminator: a circular corner radius keeps it near 0.215 while any
    straight-edged background fills the box. Reach is measured in original pixels from the
    corner along both edges, so an elliptical or clipped corner still reports a shape.
    """
    width, height = image.size
    ax, ay, sx, sy = CORNER_ORIGINS[name]
    origin_x = width - 1 if ax < 0 else 0
    origin_y = height - 1 if ay < 0 else 0

    def plate(x: int, y: int) -> bool:
        return 0 <= x < width and 0 <= y < height and _same(image.getpixel((x, y)), colour)

    reach_x = 0
    while reach_x < width and plate(origin_x + sx * reach_x, origin_y):
        reach_x += 1
    reach_y = 0
    while reach_y < height and plate(origin_x, origin_y + sy * reach_y):
        reach_y += 1
    if reach_x < 2 or reach_y < 2:
        return {"corner": name, "reach_x": reach_x, "reach_y": reach_y, "plate_share": 1.0, "arc": False}

    from collections import deque

    seen = {(0, 0)}
    queue = deque([(0, 0)])
    while queue:
        cx, cy = queue.popleft()
        for nx, ny in ((cx + 1, cy), (cx - 1, cy), (cx, cy + 1), (cx, cy - 1)):
            if nx < 0 or ny < 0 or nx >= reach_x or ny >= reach_y or (nx, ny) in seen:
                continue
            if not plate(origin_x + sx * nx, origin_y + sy * ny):
                continue
            seen.add((nx, ny))
            queue.append((nx, ny))
    share = len(seen) / float(reach_x * reach_y)
    symmetric = abs(reach_x - reach_y) <= ARC_RADIUS_SYMMETRY * max(reach_x, reach_y)
    return {
        "corner": name,
        "reach_x": reach_x,
        "reach_y": reach_y,
        "plate_share": round(share, 4),
        "arc": bool(share <= ARC_MAX_CORNER_SHARE and symmetric),
    }


def corner_arc_profile(image, colour) -> list[dict[str, Any]]:
    return [corner_arc_shape(image, name, colour) for name in CORNER_ORIGINS]


def corner_field_observation(path: Path | str) -> dict[str, Any]:
    """Describe the four corner blocks of a delivered picture as machine facts.

    Field contract: `corner_plate` and `presentation_risk` are the DECISION outputs (read by
    `require_complete_visual_picture` below); `uniform_corner_field`, `corner_reach_ratio`,
    `edge_midpoint_hits`, `corner_arc_profile` and `corner_arc_count` are the evidence they are
    derived from; `corner_means`, `corner_sample`, `corner_plate_depth*` and `size`/`path` are
    reporting fields a reviewer reads.

    `corner_plate` means the picture carries a BAKED ROUNDED CARRIER. All four conditions must
    hold: one flat colour owns the four corners; it reaches inward at the corners (>= 5% of the
    short edge); the content still runs to the frame at the middle of every edge; and at least
    three corners are shaped like a circular radius (their corner box is mostly content, share
    <= 0.38, with symmetric reaches). The last condition is what keeps this detector honest: a
    flat background behind a cross, a bleed disc or a cropped head fills its whole corner box
    (share ~1.0) and is released, while a 45-degree chamfer sits at 0.5 and is also released.

    `presentation_risk` records the weaker geometry (flat corners, deep reach, content at every
    edge midpoint) that failed the arc test. It is reported and never blocks: that shape is a
    flat-field composition owned by professional review, not a machine defect.
    """
    try:
        from PIL import Image
    except ImportError as exc:  # pragma: no cover - host dependency
        raise PresentationError("Pillow is required for the delivered-picture contract") from exc

    target = Path(path)
    require(target.is_file(), f"delivered picture is missing: {target}")
    with Image.open(target) as handle:
        image = handle.convert("RGB")
        width, height = image.size
        require(width >= 8 and height >= 8, "delivered picture is too small to inspect")
        size = max(2, int(min(width, height) * 0.02))
        corners = _corner_squares(image, size)
        means = {name: _mean(pixels) for name, pixels in corners.items()}
        flat = {name: _flatness(pixels) for name, pixels in corners.items()}
        reference = tuple(int(round(value)) for value in means["top-left"])
        corners_agree = all(_distance(reference, value) <= CORNER_TOLERANCE for value in means.values())
        corners_flat = all(value <= FLAT_TOLERANCE for value in flat.values())
        uniform = bool(corners_agree and corners_flat)
        deepest, shallowest = plate_depth_profile(image, reference, size)
        short_edge = min(width, height)
        # Only the rounded-carrier geometry is refused here. A centred subject on a
        # flat field, a uniform margin and a letterbox keep the field colour at the edge
        # midpoints, so they are released by construction and are owned by layout review
        # instead of this detector.
        midpoint_hits = sum(
            1 for x, y in ((width // 2, 0), (width // 2, height - 1), (0, height // 2), (width - 1, height // 2))
            if _same(image.getpixel((x, y)), reference)
        )
        corner_reach = deepest / short_edge if short_edge else 1.0
        plate_geometry = bool(uniform and corner_reach >= MASK_MIN_CORNER_REACH and midpoint_hits == 0)
        arcs = corner_arc_profile(image, reference) if uniform else []
        arc_corners = sum(1 for item in arcs if item["arc"])
        plate = bool(plate_geometry and arc_corners >= ARC_MIN_CORNERS)
        white = all(channel >= 240 for channel in reference)
        return {
            "schema_version": SCHEMA_VERSION,
            "contract": "complete-full-bleed-picture",
            "path": target.as_posix(),
            "size": [width, height],
            "corner_sample": size,
            "corner_means": {name: [round(value, 2) for value in mean] for name, mean in means.items()},
            "uniform_corner_field": uniform,
            "corner_plate_depth": deepest,
            "corner_plate_depth_min": shallowest,
            "edge_midpoint_hits": midpoint_hits,
            "corner_reach_ratio": round(corner_reach, 4),
            "mask_min_corner_reach": MASK_MIN_CORNER_REACH,
            "corner_arc_profile": arcs,
            "corner_arc_count": arc_corners,
            "arc_min_corners": ARC_MIN_CORNERS,
            "corner_plate": plate,
            # Non-blocking: the corner geometry is worth a look but the corner box is filled by a
            # straight-edged background, so this is a flat-field composition, not a baked mask.
            "presentation_risk": bool(plate_geometry and not plate),
            "corner_colour_near_white": bool(white),
        }


def require_complete_visual_picture(path: Path | str, *, label: str = "delivered picture") -> dict[str, Any]:
    """Fail closed when a delivered artwork carries a baked, rounded carrier mask."""
    observation = corner_field_observation(path)
    if observation["corner_plate"]:
        arcs = ", ".join(f"{item['corner']}={item['plate_share']:.2f}" for item in observation["corner_arc_profile"])
        raise PresentationError(
            f"{label} carries a baked rounded carrier, not a complete picture: one flat colour "
            f"({observation['corner_means']['top-left']}) owns the four corners, reaches "
            f"{observation['corner_reach_ratio']:.1%} of the short edge inward, the content runs to the "
            f"frame at the middle of every edge, and {observation['corner_arc_count']} corners are shaped like a "
            f"circular radius (corner box plate share: {arcs}). Rounding, masking, plates and store safe areas "
            "belong to delivery post-processing."
        )
    return observation


def rule_ids() -> list[str]:
    return sorted({rule_id for rule_id, _ in SIMULATION_RULES} | {"carrier-framing"})


def selftest() -> dict[str, Any]:
    """Prove the picture contract refuses baked rounding and releases legitimate geometry."""
    import tempfile

    from PIL import Image, ImageDraw

    white = (255, 255, 255)
    beige = (232, 222, 202)
    blue = (34, 70, 160)
    grey = (120, 124, 130)

    def baked_rounded(draw, size):
        draw.rounded_rectangle([0, 0, size - 1, size - 1], radius=size // 5, fill=grey)

    def cross_to_edges(draw, size):
        arm = size // 10
        start, end = (size - arm) // 2, (size + arm) // 2
        draw.rectangle([start, 0, end, size - 1], fill=blue)
        draw.rectangle([0, start, size - 1, end], fill=blue)

    def centred_subject(draw, size):
        inset = size * 27 // 100
        draw.ellipse([inset, inset, size - inset, size - inset], fill=grey)

    def uniform_margin(draw, size):
        border = size // 8
        draw.rectangle([0, 0, size - 1, size - 1], fill=white)
        draw.rectangle([border, border, size - 1 - border, size - 1 - border], fill=blue)

    def chamfered(draw, size):
        cut = size // 6
        draw.polygon([(cut, 0), (size - 1 - cut, 0), (size - 1, cut), (size - 1, size - 1 - cut),
                      (size - 1 - cut, size - 1), (cut, size - 1), (0, size - 1 - cut), (0, cut)], fill=grey)

    cases = (
        ("baked_rounded_carrier", baked_rounded, beige, "block"),
        ("flat_background_cross_bleeds_to_edges", cross_to_edges, beige, "pass"),
        ("centred_subject_on_flat_field", centred_subject, beige, "pass"),
        ("uniform_margin", uniform_margin, beige, "pass"),
        ("chamfered_corners", chamfered, white, "pass"),
    )
    results: dict[str, Any] = {}
    size = 512
    for name, paint, background, expected in cases:
        with tempfile.TemporaryDirectory(prefix="presentation-selftest-") as td:
            image = Image.new("RGB", (size, size), background)
            paint(ImageDraw.Draw(image), size)
            path = Path(td) / f"{name}.png"
            image.save(path, format="PNG")
            observation = corner_field_observation(path)
            try:
                require_complete_visual_picture(path)
            except PresentationError:
                outcome = "block"
            else:
                outcome = "pass"
            results[name] = {
                "expected": expected,
                "outcome": outcome,
                "corner_plate": observation["corner_plate"],
                "presentation_risk": observation["presentation_risk"],
                "corner_arc_count": observation["corner_arc_count"],
            }
            require(outcome == expected, f"presentation self-test expected {expected} but observed {outcome}: {name}")
    return results
