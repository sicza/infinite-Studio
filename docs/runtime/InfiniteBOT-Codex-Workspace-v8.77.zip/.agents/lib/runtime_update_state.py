#!/usr/bin/env python3
"""Shared Runtime update-gate state.

The version checker writes this state when the public release index confirms a
newer formal Runtime. Production gates read it and refuse to start work until
the updater clears it. Unknown/offline checks never write it (fail open), so a
network failure cannot lock the workspace.
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from atomic_io import atomic_write_text

SCHEMA_VERSION = 1
UPDATE_REQUIRED_PATH = Path(".agents") / "runtime" / "update-required.json"
RELEASE_MARKER_PATH = Path(".agents") / "runtime-release.json"
VERSION_RE = re.compile(r"^V(\d+)\.(\d+)$")
FILENAME_RE = re.compile(r"^InfiniteBOT-Codex-Workspace-v\d+\.\d+\.zip$")
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


def parse_version(value: Any) -> tuple[int, int]:
    if not isinstance(value, str):
        raise ValueError("version must be a string")
    match = VERSION_RE.fullmatch(value)
    if not match:
        raise ValueError("version must match V<major>.<minor>")
    return int(match.group(1)), int(match.group(2))


def update_required_path(root: Path) -> Path:
    return root / UPDATE_REQUIRED_PATH


def current_version(root: Path) -> str | None:
    try:
        value = json.loads((root / RELEASE_MARKER_PATH).read_text(encoding="utf-8"))
        version = value.get("version")
        parse_version(version)
        return version
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return None


def load(root: Path) -> dict[str, Any] | None:
    try:
        value = json.loads(update_required_path(root).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    if not isinstance(value, dict) or type(value.get("schema_version")) is not int:
        return None
    if value.get("schema_version") != SCHEMA_VERSION:
        return None
    try:
        parse_version(value.get("local_version"))
        parse_version(value.get("latest_version"))
    except ValueError:
        return None
    filename = value.get("release_filename")
    digest = value.get("release_sha256")
    checked_at = value.get("checked_at")
    if not isinstance(filename, str) or FILENAME_RE.fullmatch(filename) is None:
        return None
    if not isinstance(digest, str) or SHA256_RE.fullmatch(digest) is None:
        return None
    if not isinstance(checked_at, str) or not checked_at.strip():
        return None
    return value


def write(root: Path, *, local_version: str, latest_version: str, release_filename: str,
          release_sha256: str) -> None:
    payload = {
        "schema_version": SCHEMA_VERSION,
        "local_version": local_version,
        "latest_version": latest_version,
        "release_filename": release_filename,
        "release_sha256": release_sha256,
        "checked_at": datetime.now(timezone.utc).isoformat(),
    }
    path = update_required_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_text(path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")


def clear(root: Path) -> None:
    path = update_required_path(root)
    if path.is_file():
        path.unlink()


def pending(root: Path) -> dict[str, Any] | None:
    state = load(root)
    if state is None:
        return None
    current = current_version(root)
    if current is not None and parse_version(current) >= parse_version(state["latest_version"]):
        return None
    return state


def update_command() -> str:
    return "python .agents/scripts/runtime_update.py --apply"
