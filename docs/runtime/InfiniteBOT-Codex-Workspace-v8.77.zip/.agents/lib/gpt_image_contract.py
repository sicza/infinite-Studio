"""Shared GPT Image model, routing, quality, and size contract."""
from __future__ import annotations

import hashlib
import json
import math
import re


GPT_IMAGE_2 = "gpt-image-2"
GPT_IMAGE_25_SUNBURST = "gpt-image-2.5-sunburst"
GPT_IMAGE_25_FLARE = "gpt-image-2.5-flare"
GPT_IMAGE_MODELS = {GPT_IMAGE_2, GPT_IMAGE_25_SUNBURST, GPT_IMAGE_25_FLARE}
GPT_IMAGE_25_MODELS = {GPT_IMAGE_25_SUNBURST, GPT_IMAGE_25_FLARE}
DEFAULT_GPT_IMAGE_MODEL = GPT_IMAGE_25_FLARE

GPT_IMAGE_2_QUALITIES = {"auto", "low", "medium", "high"}
GPT_IMAGE_25_QUALITIES = {"auto", "low", "medium", "high", "xhigh", "max"}
GPT_BACKGROUNDS = {"auto", "opaque", "transparent"}
GPT_MODERATIONS = {"auto", "low"}
GPT_OUTPUT_FORMATS = {"png", "jpeg", "webp"}

GPT_IMAGE_25_RATIO_SIZES = {
    "1:1": "2880x2880",
    "16:9": "3840x2160",
    "4:3": "3264x2448",
    "9:16": "2160x3840",
    "3:4": "2448x3264",
}

_HIGH_FIDELITY_RE = re.compile(r"高清|高精度|4\s*[kｋ]|png|透明(?:底|背景)?|transparent", re.IGNORECASE)
_TRANSPARENT_RE = re.compile(r"透明(?:底|背景)?|transparent", re.IGNORECASE)
_DIMENSION_RE = re.compile(r"(?<!\d)(\d{2,4})\s*[x×X]\s*(\d{2,4})(?!\d)")
_RATIO_RE = re.compile(r"(?<!\d)(\d{1,2})\s*[:：]\s*(\d{1,2})(?!\d)")


def is_gpt_image_25(model: str) -> bool:
    return model in GPT_IMAGE_25_MODELS


def validate_gpt_model(model: str) -> None:
    if model not in GPT_IMAGE_MODELS:
        raise ValueError(f"unsupported GPT image model: {model}")


def gpt_image_size_constraints(model: str) -> dict[str, object]:
    """Return provider-owned image size constraints for runtime planners.

    Skills must consume this contract instead of copying GPT image limits.
    """
    validate_gpt_model(model)
    return {
        "provider": "openai-gpt-image",
        "model": model,
        "alignment": 16,
        "min_pixels": 655_360,
        "max_pixels": 8_294_400,
        "max_edge": 3840,
        "min_aspect_ratio": 1 / 3,
        "max_aspect_ratio": 3.0,
    }


def validate_gpt_size(model: str, size: str) -> None:
    validate_gpt_model(model)
    if size == "auto":
        return
    match = re.fullmatch(r"([1-9]\d*)x([1-9]\d*)", size)
    if not match:
        raise ValueError("GPT Image size must be auto or WIDTHxHEIGHT")
    width, height = map(int, match.groups())
    if width % 16 or height % 16:
        raise ValueError("GPT Image width and height must be multiples of 16")
    ratio = width / height
    if not (1 / 3 <= ratio <= 3):
        raise ValueError("GPT Image aspect ratio must be between 1:3 and 3:1")
    if max(width, height) > 3840:
        raise ValueError("GPT Image width and height may not exceed 3840")
    pixels = width * height
    if not (655_360 <= pixels <= 8_294_400):
        raise ValueError("GPT Image total pixels must be between 655360 and 8294400")


def resolve_upscale_tile_target(
    model: str, *, final_target: tuple[int, int], tile_target: tuple[int, int]
) -> dict[str, object]:
    """Resolve one tile's legal model canvas without confusing it with delivery.

    ``final_target`` is only the requested output canvas.  It is deliberately
    never converted into an Image API ``size``.  A tile keeps its source aspect
    ratio; when that ratio cannot fit the model envelope the returned transform
    specifies deterministic padding and a post-model crop.  Callers must re-tile
    rather than stretch, crop, or silently fall back to ``auto``.
    """
    validate_gpt_model(model)
    fw, fh = final_target
    tw, th = tile_target
    if min(fw, fh, tw, th) <= 0:
        raise ValueError("final_target and tile_target dimensions must be positive")
    if tw > fw or th > fh:
        raise ValueError("tile_target must be contained by final_target")
    # Pad, never distort, a very wide/tall core into a legal 3:1 model canvas.
    pad_w, pad_h = tw, th
    if tw / th > 3:
        pad_h = math.ceil(tw / 3)
    elif th / tw > 3:
        pad_w = math.ceil(th / 3)
    limits = gpt_image_size_constraints(model)
    # A model canvas must never reduce a planned final-tile core.  Smaller tiles
    # are padded/upscaled to the provider minimum; larger cores are re-tiled.
    min_scale = max(1.0, math.sqrt(int(limits["min_pixels"]) / (pad_w * pad_h)))
    max_scale = min(
        int(limits["max_edge"]) / pad_w,
        int(limits["max_edge"]) / pad_h,
        math.sqrt(int(limits["max_pixels"]) / (pad_w * pad_h)),
    )
    if min_scale > max_scale:
        raise ValueError("tile_target cannot be represented within GPT Image limits; re-tile it")
    alignment = int(limits["alignment"])
    scale = min_scale
    width = math.ceil((pad_w * scale) / alignment) * alignment
    height = math.ceil((pad_h * scale) / alignment) * alignment
    if width > int(limits["max_edge"]) or height > int(limits["max_edge"]):
        raise ValueError("tile_target alignment exceeds GPT Image limits; re-tile it")
    size = f"{width}x{height}"
    validate_gpt_size(model, size)
    # The core is centred on a deterministic padded canvas.  The receiver must
    # crop this exact box before mapping it to the final tile rectangle.
    core_w = round(tw * width / pad_w)
    core_h = round(th * height / pad_h)
    left = (width - core_w) // 2
    top = (height - core_h) // 2
    return {
        "final_target": {"width": fw, "height": fh},
        "tile_target": {"width": tw, "height": th},
        "model_size": size,
        "padding_transform": {
            "mode": "deterministic_pad_then_crop",
            "padded_source_size": {"width": pad_w, "height": pad_h},
            "model_crop_box": [left, top, left + core_w, top + core_h],
            "resample_to_tile_target": True,
        },
    }


def validate_upscale_tile_resolution(
    model: str, resolution: dict[str, object], *, final_target: tuple[int, int], tile_target: tuple[int, int]
) -> None:
    """Reject stale or forged final/tile resolution bindings."""
    expected = resolve_upscale_tile_target(model, final_target=final_target, tile_target=tile_target)
    if resolution != expected:
        raise ValueError("upscale final-target/tile-target resolution binding is stale or invalid")


def validate_gpt_quality(model: str, quality: str) -> None:
    validate_gpt_model(model)
    allowed = GPT_IMAGE_25_QUALITIES if is_gpt_image_25(model) else GPT_IMAGE_2_QUALITIES
    if quality not in allowed:
        raise ValueError(f"unsupported quality={quality} for {model}")


def formal_quality_is_valid(model: str, quality: str) -> bool:
    if model == GPT_IMAGE_2:
        return quality in GPT_IMAGE_2_QUALITIES
    if is_gpt_image_25(model):
        return quality in GPT_IMAGE_25_QUALITIES
    return False


def default_parameters(model: str) -> dict[str, str]:
    validate_gpt_model(model)
    return {
        "size": "auto",
        "quality": "max" if is_gpt_image_25(model) else "auto",
        "background": "opaque",
        "moderation": "auto",
        "output_format": "png",
    }


def model_scoped_text_applies(text: str, model: str) -> bool:
    """Keep model-scoped personal rules from leaking across GPT Image variants."""
    lower = str(text).casefold()
    if GPT_IMAGE_25_SUNBURST in lower:
        return model == GPT_IMAGE_25_SUNBURST
    if GPT_IMAGE_25_FLARE in lower:
        return model == GPT_IMAGE_25_FLARE
    if re.search(r"(?:gpt[-\s]*)?image\s*2[.．]5", lower):
        return model in GPT_IMAGE_25_MODELS
    if GPT_IMAGE_2 in lower or re.search(r"(?:gpt[-\s]*)?image\s*2(?![.．]5)", lower):
        return model == GPT_IMAGE_2
    return True


def custom_size_for_ratio(aspect_ratio: str) -> str:
    match = re.fullmatch(r"([1-9]\d*)\s*[:：]\s*([1-9]\d*)", aspect_ratio.strip())
    if not match:
        raise ValueError("aspect ratio must use W:H")
    width_ratio, height_ratio = map(int, match.groups())
    divisor = math.gcd(width_ratio, height_ratio)
    width_ratio //= divisor
    height_ratio //= divisor
    ratio = width_ratio / height_ratio
    if not (1 / 3 <= ratio <= 3):
        raise ValueError("GPT Image 2.5 aspect ratio must be between 1:3 and 3:1")
    edge_scale = min(3840 // (16 * width_ratio), 3840 // (16 * height_ratio))
    pixel_scale = math.isqrt(8_294_400 // (256 * width_ratio * height_ratio))
    scale = min(edge_scale, pixel_scale)
    if scale < 1:
        raise ValueError("aspect ratio cannot be represented within GPT Image 2.5 limits")
    size = f"{16 * width_ratio * scale}x{16 * height_ratio * scale}"
    validate_gpt_size(GPT_IMAGE_25_SUNBURST, size)
    return size


def size_for_ratio(model: str, aspect_ratio: str) -> str:
    validate_gpt_model(model)
    ratio = aspect_ratio.replace("：", ":").strip()
    return GPT_IMAGE_25_RATIO_SIZES.get(ratio) or custom_size_for_ratio(ratio)


def resolve_gpt_request(text: str, *, aspect_ratio: str | None = "1:1", explicit_size: str | None = None) -> dict[str, object]:
    """Resolve the user's GPT Image wording into an auditable request default set."""
    normalized = str(text or "").strip()
    lower = normalized.casefold()
    high_fidelity = bool(_HIGH_FIDELITY_RE.search(normalized))
    if high_fidelity or GPT_IMAGE_25_SUNBURST in lower or re.search(r"image\s*2[.．]5", lower):
        model = GPT_IMAGE_25_SUNBURST
    elif GPT_IMAGE_25_FLARE in lower:
        model = GPT_IMAGE_25_FLARE
    elif GPT_IMAGE_2 in lower or re.search(r"image\s*2(?![.．]5)", lower):
        model = GPT_IMAGE_2
    else:
        model = DEFAULT_GPT_IMAGE_MODEL

    requested_size = explicit_size
    if requested_size is None:
        dimension = _DIMENSION_RE.search(normalized)
        requested_size = f"{dimension.group(1)}x{dimension.group(2)}" if dimension else None
    if requested_size:
        size = requested_size.lower().replace("×", "x")
    else:
        ratio_match = _RATIO_RE.search(normalized)
        ratio = f"{ratio_match.group(1)}:{ratio_match.group(2)}" if ratio_match else aspect_ratio
        size = size_for_ratio(model, ratio) if ratio else "auto"
    validate_gpt_size(model, size)

    if re.search(r"\bwebp\b", normalized, re.IGNORECASE):
        output_format = "webp"
    elif re.search(r"\bjpe?g\b", normalized, re.IGNORECASE):
        output_format = "jpeg"
    else:
        output_format = "png"
    background = "transparent" if _TRANSPARENT_RE.search(normalized) else "opaque"
    if background == "transparent" and output_format not in {"png", "webp"}:
        raise ValueError("transparent background requires png or webp")
    # Resolution and quality are independent Image API controls. 2.5 uses max by
    # default for Workspace production; asking for 4K changes size, not quality.
    quality = "max" if is_gpt_image_25(model) else "high"
    validate_gpt_quality(model, quality)
    return {
        "api_profile": "gpt",
        "model": model,
        "parameters": {
            "size": size,
            "quality": quality,
            "background": background,
            "moderation": "auto",
            "output_format": output_format,
        },
        "resolution_source": "explicit_size" if requested_size else ("aspect_ratio_default" if ratio else "model_auto"),
    }


def validate_resolved_gpt_request(
    text: str,
    model: str,
    parameters: dict[str, object],
    *,
    aspect_ratio: str | None = "1:1",
) -> dict[str, object]:
    """Bind mandatory intent while allowing valid explicit overrides of defaults."""
    resolved = resolve_gpt_request(text, aspect_ratio=aspect_ratio)
    if model != resolved["model"]:
        raise ValueError(f"GPT model bypasses resolved user intent: expected {resolved['model']}, got {model}")
    expected = dict(resolved["parameters"])
    actual = {**expected, **parameters}
    size = str(actual.get("size", "")).lower()
    quality = str(actual.get("quality", "")).lower()
    background = str(actual.get("background", "")).lower()
    moderation = str(actual.get("moderation", "")).lower()
    output_format = str(actual.get("output_format", "")).lower()
    validate_gpt_size(model, size)
    validate_gpt_quality(model, quality)
    if background not in GPT_BACKGROUNDS:
        raise ValueError(f"unsupported background={background} for {model}")
    if moderation not in GPT_MODERATIONS:
        raise ValueError(f"unsupported moderation={moderation} for {model}")
    if output_format not in GPT_OUTPUT_FORMATS:
        raise ValueError(f"unsupported output_format={output_format} for {model}")
    if background == "transparent" and output_format not in {"png", "webp"}:
        raise ValueError("transparent background requires png or webp")

    normalized = str(text or "")
    if (_DIMENSION_RE.search(normalized) or _RATIO_RE.search(normalized)) and size != str(expected["size"]):
        raise ValueError(f"GPT size bypasses explicit user intent: expected {expected['size']}, got {size}")
    if _TRANSPARENT_RE.search(normalized) and background != "transparent":
        raise ValueError(f"GPT background bypasses transparent user intent: expected transparent, got {background}")
    if re.search(r"\bpng\b", normalized, re.IGNORECASE) and output_format != "png":
        raise ValueError(f"GPT output_format bypasses PNG user intent: expected png, got {output_format}")
    if re.search(r"\bwebp\b", normalized, re.IGNORECASE) and output_format != "webp":
        raise ValueError(f"GPT output_format bypasses WebP user intent: expected webp, got {output_format}")
    if re.search(r"\bjpe?g\b", normalized, re.IGNORECASE) and output_format != "jpeg":
        raise ValueError(f"GPT output_format bypasses JPEG user intent: expected jpeg, got {output_format}")

    effective = dict(resolved)
    effective["parameters"] = actual
    if "size" in parameters and size != str(expected["size"]):
        effective["resolution_source"] = "explicit_parameters"
    return effective


def validate_gpt_call_intent_binding(
    call: dict[str, object],
    request_text: str,
    request_path: str,
    request_sha256: str,
    *,
    aspect_ratio: str | None,
    intent_fingerprint: str | None = None,
    allow_legacy: bool = False,
) -> bool:
    """Validate GPT call intent against the stable intent snapshot.

    Returns ``True`` when the call is bound to the current intent snapshot and
    ``False`` when it is a legacy V8.71 call whose only evidence is the old
    whole-``request.md`` hash. Legacy calls are accepted only when the caller
    explicitly allows them and must be recorded as ``legacy_intent``; they are
    never silently reported as intent-bound.
    """
    binding = call.get("intent_binding")
    if isinstance(binding, dict):
        if binding.get("schema") != "sicza.request-intent.v1":
            raise ValueError("GPT call intent binding has an unsupported schema")
        if not isinstance(intent_fingerprint, str) or not intent_fingerprint:
            raise ValueError("GPT call intent binding cannot be verified without a current intent fingerprint")
        if binding.get("intent_fingerprint") != intent_fingerprint:
            raise ValueError("GPT call intent is stale for the current request intent")
        resolved = binding.get("resolved")
        if not isinstance(resolved, dict):
            raise ValueError("GPT call intent binding is missing the resolved intent snapshot")
        digest = hashlib.sha256(
            json.dumps(resolved, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        if binding.get("resolved_sha256") != digest:
            raise ValueError("GPT call intent resolution hash is invalid")
        return True

    legacy = call.get("gpt_intent_binding")
    if not isinstance(legacy, dict):
        raise ValueError("GPT call evidence requires intent_binding or legacy gpt_intent_binding")
    if not allow_legacy:
        if legacy.get("request_path") != request_path or legacy.get("request_sha256") != request_sha256:
            raise ValueError("GPT call intent source binding is missing or stale")
        model = str(call.get("model", ""))
        parameters = call.get("parameters")
        if not isinstance(parameters, dict):
            raise ValueError("GPT call parameters are missing")
        resolved = validate_resolved_gpt_request(request_text, model, parameters, aspect_ratio=aspect_ratio)
        if legacy.get("resolved") != resolved:
            raise ValueError("GPT call intent resolution does not match the current request")
        digest = hashlib.sha256(
            json.dumps(resolved, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        if legacy.get("resolved_sha256") != digest:
            raise ValueError("GPT call intent resolution hash is invalid")
        return False

    # Legacy evidence is accepted for old requests but never promoted to intent-bound.
    resolved = legacy.get("resolved")
    if isinstance(resolved, dict):
        digest = hashlib.sha256(
            json.dumps(resolved, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        if legacy.get("resolved_sha256") != digest:
            raise ValueError("GPT legacy call resolved intent hash is invalid")
    return False
