#!/usr/bin/env python3
"""Canonical image-production branch and current-input facts shared by all gates."""
from __future__ import annotations

import json
import re
from pathlib import Path

from request_routing import RoutingError, expected_production_branch

PRODUCTION_BRANCHES = {
    "new-generation",
    "image-edit",
    "video",
    "resize",
    "upscale",
    "localization",
    "composite",
    "postprocess-chain",
    "visual-brief-only",
    "prompt-only",
    "prompt-review-only",
}
ARTIFACT_ONLY_BRANCHES = {"visual-brief-only", "prompt-only", "prompt-review-only"}

# Requirement-lock authority. The lock is a container of SOURCED facts, never a place to
# store a professional decision: a central event, prop, device, camera or staging choice
# the Agent invented belongs to visual-requirement / visual-spec, not to user P0.
LOCK_FACT_KINDS = {
    "user_explicit": "verbatim current-user wording in request.md",
    "approved_revision": "verbatim user confirmation/continuation wording in request.md",
    "project_fact": "current project fact file under project/",
    "input_asset": "real file in the current request input/",
}
# Machine facts whose value has a closed domain that its own gate already validates. They
# cannot smuggle creative content, so they may be written bare.
LOCK_ENUM_KEYS = frozenset({
    "production_branch", "source_demand_type", "visual_variant", "has_real_props",
    "store_artwork_role", "store_sequence_position", "gameplay_truth_source",
})
# Machine facts that are paths into real evidence; the owning gate resolves and validates them.
# `gameplay_truth_approval` is NOT one of them: it is a user quote, not a path.
LOCK_PATH_KEYS = frozenset({
    "gameplay_truth_evidence", "gameplay_truth_analysis", "gameplay_reference_frame",
})
# Free-text machine facts DO change the picture. A key alone is not a source, so they must
# carry provenance and their value must be traceable to that source.
LOCK_SOURCED_KEYS = frozenset({"store_claim", "gameplay_action", "gameplay_visible_result"})
# `final_logo` is NOT closed-domain: a single unrelated quoted sentence must not be able to
# drop a mandatory brand asset, so it must carry an inline quote that really exists in
# request.md. Whether that sentence really means "no brand mark" is a professional decision -
# attempts to decide it with a keyword predicate produced false rejections of legitimate
# deliveries (标题 / 标准 / 目标 all contain 标), so this gate stops at provenance and the
# no-logo decision stays with the independent review that already inspects the final pixels.
LOCK_EVIDENCED_KEYS = frozenset({"final_logo"})
LOCK_BARE_KEYS = LOCK_ENUM_KEYS | LOCK_PATH_KEYS
LOCK_MACHINE_KEYS = LOCK_BARE_KEYS | LOCK_SOURCED_KEYS | LOCK_EVIDENCED_KEYS
LOCK_ENTRY = re.compile(
    r"^[-*]\s*(?P<fact>.+?)\s*\|\s*kind:\s*(?P<kind>[A-Za-z_]+)\s*\|\s*source:\s*(?P<source>[^|]+?)\s*"
    r"\|\s*evidence:\s*(?P<evidence>.+?)\s*$"
)
LOCK_MACHINE_SOURCED = re.compile(
    r"^(?P<key>[a-z][a-z0-9_]*)\s*:\s*(?P<value>.*?)\s*\|\s*kind:\s*(?P<kind>[A-Za-z_]+)\s*\|\s*"
    r"source:\s*(?P<source>[^|]+?)\s*\|\s*evidence:\s*(?P<evidence>.+?)\s*$"
)
LOCK_MACHINE_EVIDENCED = re.compile(r"^(?P<key>[a-z][a-z0-9_]*)\s*:\s*(?P<value>[^|]*?)\s*\|\s*evidence:\s*`?(?P<evidence>[^`]+?)`?\s*$")
LOCK_MACHINE_BARE = re.compile(r"^([a-z][a-z0-9_]*)\s*:\s*(.*)$")
LOCK_PROVENANCE_HINT = ("- <fact> | kind: user_explicit|approved_revision|project_fact|input_asset | "
                        "source: <workspace-relative path> | evidence: <verbatim quote from that source>")


class ProductionContractError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ProductionContractError(message)


def _collapse(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def _lock_root(request: Path) -> Path:
    return request.resolve().parents[2]


def _lock_source(root: Path, request: Path, kind: str, value: str) -> Path:
    raw = Path(value.strip())
    require(bool(raw.as_posix().strip()), f"requirement-lock {kind} entry requires a source path")
    path = (root / raw if not raw.is_absolute() else raw).resolve()
    require(path == root or root in path.parents, f"requirement-lock source escapes the Workspace: {value}")
    require(path.is_file(), f"requirement-lock source does not exist: {value}")
    if kind in {"user_explicit", "approved_revision"}:
        require(path == (request / "request.md").resolve(),
                f"requirement-lock {kind} must cite the current request.md, got: {value}")
    elif kind == "project_fact":
        require(path == (root / "project").resolve() or (root / "project").resolve() in path.parents,
                f"requirement-lock project_fact must cite a current project fact file, got: {value}")
    elif kind == "input_asset":
        require((request / "input").resolve() in path.parents,
                f"requirement-lock input_asset must cite a current request input/ file, got: {value}")
    return path


def _evidence_present(evidence: str, source_text: str) -> bool:
    if evidence in source_text:
        return True
    return _collapse(evidence) in _collapse(source_text)


def _sourced_fact(root: Path, request: Path, number: int, match: re.Match[str], label: str) -> dict:
    kind = match.group("kind").strip()
    require(kind in LOCK_FACT_KINDS,
            f"requirement-lock.md line {number} ({label}) declares unauthorized fact kind '{kind}'; a professional "
            f"proposal is not a lock fact (allowed: {sorted(LOCK_FACT_KINDS)})")
    evidence = match.group("evidence").strip()
    require(len(evidence) >= 2, f"requirement-lock.md line {number} ({label}) needs a verbatim evidence quote")
    source = _lock_source(root, request, kind, match.group("source"))
    return {"kind": kind, "evidence": evidence, "source": source}


def _is_textual(source: Path) -> bool:
    return source.suffix.casefold() in {".md", ".txt", ".json", ".yaml", ".yml", ".csv", ".srt", ".vtt"}


def _require_traceable(number: int, label: str, value: str, source: Path, evidence: str, citation: str,
                       kind: str = "user_explicit") -> None:
    if kind == "input_asset":
        # A binary asset cannot contain a quotable sentence, so this kind may only NAME the asset.
        # No free prefix is allowed: any "<prose>: file" form would let arbitrary wording ride in
        # on a real file, which is exactly the laundering this gate exists to stop.
        name = source.name.casefold()
        claim = _collapse(value).casefold()
        require(claim == name or claim == _collapse(citation).casefold(),
                f"requirement-lock.md line {number} ({label}) may only name the asset itself "
                f"({source.name}); describe the requirement in visual-requirement.md instead of locking it "
                "as prose, and do not put prose in front of the file name")
        require(evidence.casefold() in name or evidence.casefold() in citation.casefold(),
                f"requirement-lock.md line {number} ({label}) must cite the asset it is about "
                f"({source.name}); got {evidence!r}")
        return
    require(_is_textual(source),
            f"requirement-lock.md line {number} ({label}) cites a non-textual source ({source.name}); "
            "only input_asset can point at a binary, and it may only name the file")
    text = source.read_text(encoding="utf-8", errors="replace")
    require(_evidence_present(evidence, text),
            f"requirement-lock.md line {number} ({label}) evidence is not present in {citation}: {evidence!r} - "
            "the fact is not actually stated by that source")
    if value.strip():
        require(_evidence_present(value, text),
                f"requirement-lock.md line {number} ({label}) states {value!r} but {citation} does not contain that "
                "wording; a registered key is not a source, so quote the requirement or move the decision to "
                "visual-requirement.md")


def final_logo_disabled(root: Path, request: Path, text: str) -> bool:
    """True when the lock carries a `final_logo: user_explicit_none` decision quoted from the user.

    Exported so the delivery gate and the lock gate cannot drift apart on this decision. The
    quote must exist verbatim in request.md; it is not interpreted here.
    """
    match = LOCK_MACHINE_EVIDENCED.match(next((line.strip() for line in text.splitlines()
                                               if line.strip().startswith("final_logo:")), ""))
    if match is None:
        return False
    if match.group("value").strip() != "user_explicit_none":
        return False
    quote = match.group("evidence").strip()
    if len(quote) < 2:
        return False
    request_md = request / "request.md"
    if not request_md.is_file():
        return False
    return _evidence_present(quote, request_md.read_text(encoding="utf-8", errors="replace"))


def _variant_resolver(root: Path):
    """Load the one authority for business-carrier labels. A missing authority fails closed:
    an unverifiable "closed domain" is not a closed domain."""
    path = root / ".agents" / "skills" / "wxian-image-production" / "scripts" / "visual_variant_resolver.py"
    require(path.is_file(), f"cannot verify source_demand_type/visual_variant: resolver is missing at "
                            f"{path.relative_to(root).as_posix() if root in path.parents else path}")
    import importlib.util
    spec = importlib.util.spec_from_file_location("production_contract_variant_resolver", path)
    require(spec is not None and spec.loader is not None, "visual variant resolver is unloadable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


VARIANT_CARRIERS = ("活动配图", "互动图", "BANNER", "弹窗", "LOGO", "ICON", "铭牌", "KV", "商店图")
GAMEPLAY_TRUTH_SOURCES = {"current_reference", "project_material", "project_brief", "approved_concept", "user_confirmed_rule"}


def _allowed_variants(resolver) -> set[str]:
    """Every variant the resolver itself can emit - derived from the authority, not restated."""
    allowed = {"auto"}
    for carrier in VARIANT_CARRIERS:
        for props in (False, True):
            try:
                resolved = resolver.resolve(carrier, props, True)
            except Exception:  # noqa: BLE001 - a carrier that needs gameplay evidence is out of scope here
                continue
            if resolved.get("status") == "passed":
                allowed.add(str(resolved.get("visual_variant")))
    return allowed


def _validate_closed_domains(root: Path, request: Path, machine: dict[str, str]) -> None:
    """A key may skip provenance only when its domain is genuinely closed.

    `source_demand_type` was exempted as "validated downstream", but the resolver's default
    branch answers `not_applicable` for any unknown text, so arbitrary free text used to pass.
    Path facts have the same problem: an exempt path passed as long as nobody resolved it.
    """
    source_type = (machine.get("source_demand_type") or "").strip()
    declared_variant = (machine.get("visual_variant") or "").strip()
    has_props = (machine.get("has_real_props") or "").strip().lower()
    if "has_real_props" in machine:
        require(has_props in {"true", "false"}, f"has_real_props must be true|false, got {has_props!r}")
    if declared_variant or source_type:
        resolver = _variant_resolver(root)
        # `visual_variant` drives the presenting gate on its own, so its domain is closed even
        # when no carrier is declared.
        if declared_variant:
            allowed = _allowed_variants(resolver)
            require(declared_variant in allowed,
                    f"visual_variant {declared_variant!r} is not one the resolver can emit "
                    f"(allowed: {sorted(allowed)})")
        if source_type:
            try:
                # gameplay_ref handling stays with the reference/store gates; this only closes the
                # carrier label domain.
                resolved = resolver.resolve(source_type, has_props == "true", True)
            except Exception as exc:  # noqa: BLE001 - the resolver raises its own error type
                raise ProductionContractError(f"invalid source_demand_type {source_type!r}: {exc}") from exc
            if resolved.get("status") == "passed":
                require(declared_variant == resolved.get("visual_variant"),
                        f"source_demand_type {source_type!r} requires visual_variant="
                        f"{resolved.get('visual_variant')}, got {declared_variant or '(none)'}")
            else:
                require(not declared_variant,
                        f"source_demand_type {source_type!r} is not a recognised business carrier, so visual_variant "
                        "must be omitted rather than invented")
    truth_source = (machine.get("gameplay_truth_source") or "").strip()
    if "gameplay_truth_source" in machine:
        require(truth_source in GAMEPLAY_TRUTH_SOURCES,
                f"gameplay_truth_source must be one of {sorted(GAMEPLAY_TRUTH_SOURCES)}, got {truth_source!r}")
    if truth_source in {"current_reference", "project_material", "approved_concept"}:
        evidence = (machine.get("gameplay_truth_evidence") or "").strip()
        require(bool(evidence), f"gameplay_truth_source {truth_source} requires gameplay_truth_evidence")
        candidate = (root / evidence).resolve() if not Path(evidence).is_absolute() else Path(evidence).resolve()
        require(candidate.is_file(), f"gameplay_truth_evidence must resolve to a real file: {evidence}")
        allowed_roots = [(root / "project").resolve(), (request / "input").resolve(), (request / "work").resolve()]
        require(any(candidate == base or base in candidate.parents for base in allowed_roots),
                f"gameplay_truth_evidence must live in the current request input/ or work/, or in project/: {evidence}")
    for key in ("gameplay_truth_analysis", "gameplay_reference_frame"):
        value = (machine.get(key) or "").strip()
        if value:
            require(not Path(value).is_absolute(), f"{key} must be a Workspace-relative path: {value}")
            candidate = (root / value).resolve()
            require(candidate.is_file(), f"{key} must resolve to a real file: {value}")
    approval = (machine.get("gameplay_truth_approval") or "").strip()
    if "gameplay_truth_approval" in machine:
        # Documented meaning: the user's approval wording, verbatim from request.md.
        request_md = request / "request.md"
        require(bool(approval) and len(approval) >= 2, "gameplay_truth_approval must quote the user's approval")
        require(request_md.is_file() and _evidence_present(approval, request_md.read_text(encoding="utf-8", errors="replace")),
                f"gameplay_truth_approval must appear verbatim in request.md: {approval!r}")


def validate_lock_authority(root: Path, request: Path, text: str) -> dict:
    """Prove every lock statement about the requirement is traceable to a real source.

    This is a provenance check, not a semantic one: it cannot decide whether a quoted
    sentence really means what the entry claims. It can decide that the Agent did not
    invent the requirement out of its own creative proposal, which is the failure this
    guards. Semantic loyalty stays with the professional Skill and the independent review.

    The field that carries the claim is checked, not just the field that carries the
    citation: a paraphrased `fact` next to an unrelated quote is exactly how an invented
    requirement used to survive, so the fact itself must be quotable from its source.
    """
    entries: list[dict[str, str]] = []
    machine: dict[str, str] = {}
    seen: set[tuple[str, str, str, str]] = set()
    for number, raw in enumerate(text.splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith(("-", "*")):
            match = LOCK_ENTRY.match(line)
            require(match is not None,
                    f"requirement-lock.md line {number} is not a sourced fact: use '{LOCK_PROVENANCE_HINT}'")
            fact = match.group("fact").strip()
            require(bool(fact), f"requirement-lock.md line {number} has an empty fact")
            sourced = _sourced_fact(root, request, number, match, "entry")
            citation = match.group("source").strip()
            _require_traceable(number, "fact", fact, sourced["source"], sourced["evidence"], citation, sourced["kind"])
            key = (sourced["kind"], sourced["source"].as_posix(), _collapse(sourced["evidence"]), _collapse(fact))
            require(key not in seen, f"requirement-lock.md line {number} repeats an already declared fact")
            seen.add(key)
            entries.append({"fact": fact, "kind": sourced["kind"], "source": citation,
                            "evidence": sourced["evidence"]})
            continue

        sourced_match = LOCK_MACHINE_SOURCED.match(line)
        if sourced_match is not None:
            key_name = sourced_match.group("key")
            value = sourced_match.group("value").strip()
            sourced = _sourced_fact(root, request, number, sourced_match, key_name)
            # Even a closed-domain key that chooses to cite a source must cite a real, textual
            # one; otherwise "<bare key>: v | kind: project_fact | source: <binary>" would launder.
            _require_traceable(number, key_name, "" if key_name in LOCK_BARE_KEYS else value,
                               sourced["source"], sourced["evidence"],
                               sourced_match.group("source").strip(), sourced["kind"])
            machine[key_name] = value
            entries.append({"fact": f"{key_name}: {value}", "kind": sourced["kind"],
                            "source": sourced_match.group("source").strip(), "evidence": sourced["evidence"]})
            continue

        evidenced = LOCK_MACHINE_EVIDENCED.match(line)
        if evidenced is not None and evidenced.group("key") in LOCK_EVIDENCED_KEYS:
            key_name = evidenced.group("key")
            require(evidenced.group("value").strip() == "user_explicit_none",
                    f"requirement-lock.md line {number} ({key_name}) only accepts user_explicit_none")
            require(final_logo_disabled(root, request, line),
                    f"requirement-lock.md line {number} ({key_name}) must quote wording that exists verbatim in "
                    "request.md; whether that wording really means 'no brand mark' is a professional review "
                    "decision, not something this gate decides")
            entries.append({"fact": f"{key_name}: user_explicit_none", "kind": "user_explicit",
                            "source": workspace_relative(root, request / "request.md"),
                            "evidence": evidenced.group("evidence").strip()})
            continue

        bare = LOCK_MACHINE_BARE.match(line)
        require(bare is not None,
                f"requirement-lock.md line {number} is free prose; the lock holds sourced facts only "
                f"(headings, machine facts and '{LOCK_PROVENANCE_HINT}' entries)")
        key_name = bare.group(1)
        machine[key_name] = bare.group(2).strip()
        require(key_name not in LOCK_EVIDENCED_KEYS,
                f"requirement-lock.md line {number} ({key_name}) requires its inline '| evidence: `...`' no-logo "
                "instruction; without it the decision has no source")
        require(key_name in LOCK_BARE_KEYS,
                f"requirement-lock.md line {number} writes '{key_name}' without provenance. Closed-domain machine facts "
                f"that need no citation: {sorted(LOCK_BARE_KEYS)}. Every other fact - including a free-text claim such as "
                f"{sorted(LOCK_SOURCED_KEYS)} - must carry '| kind: ... | source: ... | evidence: ...' with a verbatim "
                "quote from that source")
    _validate_closed_domains(root, request, machine)
    return {"status": "passed", "sourced_facts": entries, "sourced_fact_count": len(entries)}


def lock_authority_report(root: Path, request: Path) -> dict:
    """Explain a lock line by line and draft the provenance line each offender needs.

    Existing Workspaces predate the provenance contract. This report is the migration path:
    it never edits the lock, it names what must be cited and, when the wording already exists
    in request.md, prints the exact line to write.
    """
    path = request / "work" / "requirement-lock.md"
    require(path.is_file(), "work/requirement-lock.md is missing")
    request_md = request / "request.md"
    request_text = request_md.read_text(encoding="utf-8", errors="replace") if request_md.is_file() else ""
    request_rel = workspace_relative(root, request_md) if request_md.is_file() else "request.md"
    lines: list[dict] = []
    for number, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith(("-", "*")):
            match = LOCK_ENTRY.match(line)
            state = "sourced_entry" if match else "needs_provenance"
            value = match.group("fact").strip() if match else line.lstrip("-* ")
        else:
            evidenced = LOCK_MACHINE_EVIDENCED.match(line)
            sourced = LOCK_MACHINE_SOURCED.match(line)
            bare = LOCK_MACHINE_BARE.match(line)
            if sourced:
                state, value = "sourced_machine_fact", sourced.group("value").strip()
            elif evidenced and evidenced.group("key") in LOCK_EVIDENCED_KEYS:
                state = "sourced_machine_fact" if final_logo_disabled(root, request, line) else "needs_provenance"
                value = evidenced.group("value").strip()
            elif bare and bare.group(1) in LOCK_BARE_KEYS:
                state, value = "closed_domain_fact", bare.group(2).strip()
            elif bare:
                state, value = "needs_provenance", bare.group(2).strip()
            else:
                state, value = "free_prose", line
        suggestion = None
        if state in {"needs_provenance", "free_prose"} and value:
            if _evidence_present(value, request_text):
                key = LOCK_MACHINE_BARE.match(line).group(1) if LOCK_MACHINE_BARE.match(line) else ""
                prefix = f"{key}: " if key else "- "
                suggestion = (f"{prefix}{value} | kind: user_explicit | source: {request_rel} | "
                              f"evidence: {value}")
            else:
                suggestion = "manual: quote the current user wording, cite a project fact file, or move the decision " \
                             "to visual-requirement.md"
        lines.append({"line": number, "state": state, "text": line[:120], "suggested": suggestion})
    valid = validate_lock_authority(root, request, path.read_text(encoding="utf-8")) if all(
        item["state"] in {"sourced_entry", "sourced_machine_fact", "closed_domain_fact"} for item in lines) else None
    return {"status": "passed" if valid else "needs_migration",
            "lock": workspace_relative(root, path),
            "lines": lines,
            "note": "this report never edits the lock; adopt the suggested lines yourself and re-run the gate"}


def visual_spec_required(root: Path, request: Path) -> bool:
    """Whether this branch's registered enforcement profile makes a Visual Spec mandatory.

    One policy, one implementation: the lock gate, the candidate tracker and the delivery gate
    must not each decide it differently. An unreadable registry fails closed.
    """
    registry = root / ".agents" / "skills" / "workspace-governance" / "config" / "visual-contracts" / "visual-enforcement-profiles.json"
    try:
        profiles = json.loads(registry.read_text(encoding="utf-8")).get("profiles", {})
    except (OSError, json.JSONDecodeError):
        return True
    entry = profiles.get("wxian-image-production", {})
    if not isinstance(entry, dict):
        return True
    try:
        branch = requirement_lock(request)[1]
    except ProductionContractError:
        return True
    profile = (entry.get("branches") or {}).get(branch) or entry.get("default") or {}
    return str(profile.get("visual_spec", "required")) == "required"


def requirement_lock(request: Path) -> tuple[Path, str]:
    path = request / "work" / "requirement-lock.md"
    require(path.is_file() and path.stat().st_size > 0, "image-production requires work/requirement-lock.md")
    text = path.read_text(encoding="utf-8")
    matches = re.findall(r"(?im)^\s*production_branch:\s*([^\n#]+?)\s*$", text)
    require(len(matches) == 1, "requirement-lock.md requires exactly one production_branch")
    branch = matches[0].strip()
    require(branch in PRODUCTION_BRANCHES, f"invalid production_branch: {branch}")
    request_type = request.parent.name
    try:
        expected = expected_production_branch(request_type)
    except RoutingError as exc:
        raise ProductionContractError(str(exc)) from exc
    require(expected is not None, f"request_type={request_type} is not an image-production route")
    require(branch == expected, f"request_type={request_type} requires production_branch={expected}, got {branch}")
    validate_lock_authority(_lock_root(request), request, text)
    return path, branch


def production_branch(request: Path) -> str:
    return requirement_lock(request)[1]


def request_input_files(request: Path) -> list[Path]:
    root = request / "input"
    if not root.is_dir():
        return []
    return sorted((p.resolve() for p in root.rglob("*") if p.is_file()), key=lambda p: p.as_posix().casefold())


def workspace_relative(root: Path, path: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def validate_source_lock(root: Path, request: Path) -> dict:
    actual = [workspace_relative(root, p) for p in request_input_files(request)]
    lock = request / "work" / "source-lock.json"
    if not actual:
        require(not lock.exists(), "source-lock.json must not exist when request input/ is empty")
        return {"status": "not_required", "source_count": 0}
    require(lock.is_file(), "non-empty request input/ requires work/source-lock.json")
    try:
        obj = json.loads(lock.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ProductionContractError(f"invalid source-lock.json: {exc}") from exc
    require(isinstance(obj, dict) and set(obj) == {"required_sources"}, "source-lock.json must contain required_sources only")
    values = obj["required_sources"]
    require(isinstance(values, list) and values, "required_sources must be a non-empty array")
    normalized: list[str] = []
    seen: set[str] = set()
    req_input = (request / "input").resolve()
    for index, value in enumerate(values):
        require(isinstance(value, str) and value.strip(), f"required_sources[{index}] must be a path string")
        p = Path(value.strip())
        p = (root / p if not p.is_absolute() else p).resolve()
        require(p == root or root.resolve() in p.parents, f"path escapes Workspace: {value}")
        require(p.is_file(), f"required current-demand source is missing: {value}")
        require(req_input in p.parents, f"current-demand source must resolve inside this request input/: {value}")
        rel = workspace_relative(root, p)
        require(rel not in seen, f"duplicate required source: {rel}")
        seen.add(rel)
        normalized.append(rel)
    require(sorted(normalized) == sorted(actual), f"source-lock must exactly cover current request input files; expected={sorted(actual)}, actual={sorted(normalized)}")
    return {"status": "passed", "required_sources": sorted(normalized), "source_count": len(normalized)}
