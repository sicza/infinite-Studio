#!/usr/bin/env python3
"""Stable request intent identity for generation and delivery evidence.

`request.md` stays the human-readable demand and approval history. Generation
evidence must not turn the whole file into an immutable hash, because appending
a user approval would otherwise invalidate work the user already accepted.

The intent fingerprint covers only the facts that change what must be produced:
request identity/revision, primary Skill, current input files, the machine
requirement lock and the source lock. Approvals are recorded separately in
`work/approvals.jsonl` and never change this fingerprint.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
from typing import Any

from request_identity import (
    RequestIdentityError,
    load_state,
    rel,
    request_id,
    sha256_file,
)

INTENT_SCHEMA = "sicza.request-intent.v1"


class RequestIntentError(ValueError):
    pass


def _optional_file(root: Path, path: Path) -> dict[str, str] | None:
    if not path.is_file():
        return None
    return {"path": rel(root, path), "sha256": sha256_file(path)}


def intent_payload(root: Path, request: Path) -> dict[str, Any]:
    """Canonical intent facts. Approval text is deliberately absent."""
    state = load_state(request)
    inputs: list[dict[str, str]] = []
    input_dir = request / "input"
    if input_dir.is_dir():
        for path in sorted(
            (item for item in input_dir.rglob("*") if item.is_file()),
            key=lambda item: rel(root, item).casefold(),
        ):
            inputs.append({"path": rel(root, path), "sha256": sha256_file(path)})
    return {
        "schema_version": INTENT_SCHEMA,
        "request_ref": rel(root, request),
        "request_id": request_id(root, request),
        "request_revision": state["revision"],
        "primary_skill": state["primary_skill"],
        "input": inputs,
        "requirement_lock": _optional_file(root, request / "work" / "requirement-lock.md"),
        "source_lock": _optional_file(root, request / "work" / "source-lock.json"),
    }


def intent_fingerprint(root: Path, request: Path) -> str:
    raw = json.dumps(intent_payload(root, request), ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def intent_identity(root: Path, request: Path) -> dict[str, Any]:
    """Compact identity for call evidence, candidate records and status output."""
    state = load_state(request)
    return {
        "schema": INTENT_SCHEMA,
        "request_ref": rel(root, request),
        "request_id": request_id(root, request),
        "request_revision": state["revision"],
        "primary_skill": state["primary_skill"],
        "intent_fingerprint": intent_fingerprint(root, request),
    }


def legacy_candidate_intent(candidate: dict[str, Any] | None, call_record: dict[str, Any] | None = None, *,
                            pointer: dict[str, Any] | None = None, legacy_pointer: bool = False) -> bool:
    """One legacy rule shared by approval recording, candidate confirmation and delivery.

    A candidate is legacy only when it predates request-intent evidence: the registered
    candidate carries no ``intent_fingerprint`` and its generation call record carries no
    ``intent_binding``. Recording an approval, confirming the candidate and delivering it must
    resolve this identically, otherwise the same candidate is accepted at one gate and rejected
    at the next.

    ``pointer`` contributes only its explicit ``legacy_intent`` marker and ``legacy_pointer``
    contributes the pre-intent confirmed-candidate schema, matching the older gates exactly.
    """
    if legacy_pointer:
        return True
    item = candidate if isinstance(candidate, dict) else {}
    confirmed = pointer if isinstance(pointer, dict) else {}
    if bool(item.get("legacy_intent")) or bool(confirmed.get("legacy_intent")):
        return True
    if "intent_fingerprint" in item:
        return False
    return not isinstance((call_record or {}).get("intent_binding"), dict)

