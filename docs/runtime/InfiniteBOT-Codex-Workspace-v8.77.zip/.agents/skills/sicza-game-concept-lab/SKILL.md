---
name: sicza-game-concept-lab
description: 从少量游戏设定、玩法、视觉参考或既有资产做高差异方向发散、关系系统驱动的素材生态、人物/IP/怪物/场景/玩法原型；要方向或 Prompt 时直接交付可执行 Prompt 与设计合同，完整概念包才多方向多图，互动 HTML 仅在明确需要时；单次成图改图→wxian-image-production，发行 KV/Store 包装→wxian-visual-packaging。
---

# 游戏概念实验室

作为 Primary 时先执行 `$workspace-governance consume-personal-context --request <request> --consumer sicza-game-concept-lab`；阻断则停止。作为辅助能力时继承调用方已验证的 Primary Context，不重复消费。

把极少量输入转化为：**有创意、有产品差异、设计具体、可直接生图、可验证、可持续迭代的游戏视觉原型。**

交付形态由目标决定，不默认整包：要方向 / Prompt / 设计合同 → 直接交付可执行 Prompt 与设计合同，不要求成图与 HTML；要完整概念包或入口测试 → 才生成方向证据图；互动展示仅在用户明确需要 HTML/互动页时调用 `$wxian-html-delivery`。Prompt 是创意的执行合同，不能用文字长度替代创意。

优先级：`Creative Quality > Product Difference > World × Gameplay > Design Causality > Concrete Design > Gameplay Readability > Prototype Testability > Prompt Execution`。可生图是设计终点，不是创意起点。

## 1. 入口模式

先判断当前真正任务，不默认从零发散。

- **DISCOVER**（只有 Premise / 少量世界设定）：`Premise → Research Fuel → Creative Discovery → Direction Seeds → Direction Prototypes → Prototype Realization → Test Prompts`
- **DEVELOP**（已选一个方向，要具体人物/怪物/场景/玩法/视觉原型）：`Selected Prototype → Freeze Production Anchors → Concrete Design → Image Contract → Prompt`
- **TRANSFORM**（成熟 Gameplay / 游戏 / 行业系统迁移）：`Reference → Grammar/Relationship Extraction → Mutation → World-bound Prototype`，必须改变底层 Grammar/Relationship 并重新绑定当前世界。
- **VISUALIZE / ITERATE**（已有资产或生成结果）：`Existing Truth → Reference Contract → Change Scope → Image Contract → Generate/Edit Prompt`。长期 IP / 多图复用角色先恢复 `ip-character-system.json + ip-character-binding.json`，执行 production preflight，再把 Mother Reference Binding 编译为真实 `image_conditioning_inputs`。已锁设计保持 FROZEN，除非 Change Scope 明确重开。

按交付规模选 `scope_profile`：`PROTOTYPE`（单方向，通常 1–3 类测试资产）、`PORTFOLIO`（多角色/地点/状态/系统或完整概念包）、`VERTICAL_SLICE`（最小可体验闭环及关键状态序列）。`PORTFOLIO / VERTICAL_SLICE` 必须执行 Content Architecture Pass，不能把单图合同重复很多次当内容架构。

`PORTFOLIO` 形态：`MULTI_DIRECTION_DIVERGENCE`（3–5 个高差异方向各成素材与 Prompt 组合）/ `SINGLE_DIRECTION_DEPTH`（一个方向跨资产、状态、事件、系统深化）/ `HYBRID_PORTFOLIO`（先多方向再深化一个）。

扩展发动机 `RELATIONSHIP_DRIVEN / SYSTEM_DRIVEN / HYBRID` 是 Lab 的专业判断，不要求用户填表；用户明确授权自主创作或收敛时，记录 Lab 决策及其授权来源，不把 Lab 选择伪装成用户事实。

## 2. Context & Research Gate

先收集可用事实：`当前用户要求 + Hard Locks + Project Brief + Visual Baseline + 已有项目资产/决策 + 用户 Reference`，已有信息直接复用。

正式 Visual Baseline 进入本次判断时写 canonical `work/baseline-consumption.json`，machine key=`game-concept-lab`，并通过 `$wxian-visual-baselines` 的 request-bound validator；纯文字/零视觉概念发现不伪造 Baseline，也不得因无 Baseline 被阻断（实际图片生产由对应 Primary 的视觉门禁负责）。

以下情况创意前必须研究：Premise 依赖真实地点/行业/技术/职业/基础设施；真实功能与约束能实质改善 Gameplay 或视觉；用户给了具体 Gameplay/产品参考需理解机制；用户明确要求；模型能力影响执行且 Model Profile 缺失/过期/冲突。事实来源优先官方一手，内部区分 `FACT / PRACTICE / INSPIRATION / UNVERIFIED`，研究压缩成 `Research Fuel` 直接进入设计。需要系统研究时调用 `$wxian-conducting-internet-research` 作为当前 request 的辅助能力，不创建第二 request。

## 3. Reference 加载索引

只加载当前阶段需要的文件；创意已冻结时默认不加载 01–04，除非 Review 指向创意/玩法根因。

| 阶段 / 条件 | 加载 |
|---|---|
| DISCOVER 创意发散（必读） | `references/01-creative-operators.md`；案例级/多方向再读 `references/16-direction-material-divergence.md` |
| 真实行业或跨域系统 | `references/02-cross-domain-creative-systems.md` |
| Gameplay Reference / 玩法变异 | `references/03-gameplay-grammar-library.md` + `references/04-gameplay-mutation.md` |
| Prototype Realization 人物 | `references/05-character-design.md`；长期 IP/多角色再 `05a` + `05b`，3+ 核心角色加 `05c` |
| Creature / 场景玩法空间 / 画风比例 Camera / Gameplay UI | `06` / `07` / `08` / `10` |
| DEVELOP 组合（05/06/07/08/09/10/11 按对象组合） | 多图内容包或完整概念集加 `14` + `15`；案例级 Prompt 组合加 `16` + `17`；涉及参考图加 `09` |
| VISUALIZE / ITERATE | `09` + `11` + Adapter；长期 IP 另 `05a` + `05b`；失败诊断才 `12` |
| 产物生命周期与权威 | `references/18-artifact-lifecycle.md`（写入/冻结/复用/移交前） |
| Prototype Spec 字段与证据规模 | `references/19-prototype-spec.md`（建/校验 PROVISIONAL Spec） |
| FROZEN 锚点字段 | `references/20-production-anchors.md`（用户选中 Prototype 后） |
| Content Architecture Pass 四件套 | `references/21-content-architecture-pass.md`（PORTFOLIO / VERTICAL_SLICE / 证据绑定字段） |
| 完成标准与 Prompt Portfolio 门禁 | `references/22-completion-standards.md`（声明完成级别、`promote` 前） |
| 输出路径与交付清单 | `references/23-workspace-outputs.md`（建产物、写 final-review/manifest） |
| Prompt 编译规则 | `references/24-prompt-compilation.md`（生成 Canonical/Target Prompt） |
| 目标模型 Adapter / Profile | `references/prompt-adapters/*`、`references/model-profiles/*` |

候选规模：内部产生 6–12 个 Direction Seeds，用户默认只看到 3–5 个真正不同的 Direction Prototypes。

## 4. 关键契约（精简）

- **FROZEN 锚点**：用户选中 Prototype 后才进入 FROZEN；对象字段与长期 IP canonical 文件（`work/ip-character-system.json / ip-character-binding.json / ip-character-preflight.json / ip-character-handoff.json`）见 `20`。FROZEN 只在用户明确改设计或 Review 证明上游错误时更新；变更须使下游 Visual Spec / Prompt Binding 失效。
- **关键假设**：世界观-only 输入的产品类型、玩家代理、体验目标、核心循环、内容规模先记 `ASSUMED`（ID `PLAYER_AGENT / PRODUCT_TYPE / TARGET_EXPERIENCE / CORE_LOOP / CONTENT_SCOPE`）；`PORTFOLIO / VERTICAL_SLICE` 完成前必须 `CONFIRMED` 并带证据。
- **Reference Contract**：每张图定义 `ROLE / PRESERVE / BORROW / REPLACE / IGNORE / AUTHORITY`；默认权威 `User Explicit Lock > Frozen IP/Character Anchor > Mother Reference Role Authority > Role-specific Reference > Gameplay/Environment Truth > Style Reference > Pose/Composition Reference > Previous Generated Image > Model Default`。“综合参考所有图片”不是可接受的合同。用户给录屏/视频 Reference 时在当前 request 内调用 `$wxian-video-source-analysis` 拆时间线与代表帧。
- **Change Scope**：编辑已有资产前建立 `LOCKED / EDITABLE / DERIVED CHANGE / FORBIDDEN`，正确层保持 LOCKED。
- **Image Contract**：正式生成/编辑前读 `references/11-image-contracts.md` 并冻结 BOUND Contract——`Asset Type / Purpose / Aspect Ratio / Primary Read / Subject Count / Position / Scale / Interaction Point / Gameplay Change Area / Foreground / Midground / Background / Reading Direction / Camera / Perspective / Framing / Pose/Action / Must Show / Must Preserve / Must Not Add`；多图再加 `Content Graph Refs / Coverage Refs / Parent ID / Variant Axes / Semantic Delta / Counting Class`。模型不负责自己决定核心构图。
- **Visual Director Pass**：Image Contract 冻结后、Prompt 编译前读 `references/13-visual-director-bridge.md`，调用 `$sicza-visual-director` 编译 `Visual Spec`（从零 `CREATE` / 重组 `TRANSFORM` / 局部修正 `ITERATE`）。本 Skill 拥有概念、Grammar、Mutation、Prototype、Production Anchor 与 Image Contract；Visual Director 拥有视觉编译；Mother Reference Binding 保持独立 Identity Conditioning Authority。
- **Prompt Compilation**：先读 `sicza-visual-director/references/prompt-adapter-invariants.md`，只投影已存在上游事实（Prototype Spec/Frozen Anchors + Mother Reference Binding + Reference Contract + Change Scope + Image Contract + Visual Spec）。未指定模型时输出 `TARGET = GENERAL` 自然语言 Prompt，不打断创意；后续只重编译 Adapter。每个正式 Coverage 槽产生完整、自足、可复制执行的 Canonical Prompt，禁止关键词骨架/待填模板/“沿用上一条”；身份与拓扑锁须重述。细节见 `24`。
- **Content Architecture**：所有 scope 先建最小 `work/concept-lab/product-blueprint.json`；PORTFOLIO/VERTICAL_SLICE 建四件套 `product-blueprint / content-graph / coverage-plan / content-audit`（见 `21`）。每张正式证据绑定 `sha256 / graph_refs / coverage_refs / variant_axes / semantic_delta / counting_delta / event_delta` 等字段；`NEW_*` 用结构化 `counting_delta`，`NEW_EVENT` 用 `event_delta`；只换镜头/色光/表情/裁切等记表现变化，不算语义新增。无 Coverage 槽位的探索图保留但不提高正式覆盖率；显示名不是身份键。

## 5. Review 与成图验证

用户返回真实结果要求判断/修正时读 `references/12-generation-review.md`；`PORTFOLIO / VERTICAL_SLICE` 每 10–20 项及全局收口时也用其做内容审计（无 API 结果时只验证计划、图谱、重复与一致性，不得声称验证图像质量或玩法体验）。长期 IP 额外检查 Identity Delta；3+ 核心角色阵容图按 `05c` 执行 Silhouette / Thumbnail / Grayscale / Lineup / Variant Stress Test。

按最早因果层定位：`Creative → Gameplay Grammar/Mutation → IP DNA/Cast/Character Identity → Character/Pose → Creature → Environment → Image Contract → Visual Director/Visual Spec → Reference Control → Gameplay Screen/UI → Adapter/Model Execution`；修最早错误层，不加长 Prompt 掩盖上游问题。

`portfolio_output=PROMPT_MARKDOWN | BOTH` 时，producer 完成后必须开启新的独立语义 reviewer（分离 actor ID，规范化小写，不靠大小写/空格/零宽字符伪造；完整阅读每条 Prompt 不抽样），逐条判断主体基数、角色/因果/素材具体度、视觉机制有效性、可执行性与伪丰富度，并对全部已批准方向对执行真实 Swap Test；结果写 `work/concept-lab/prompt-semantic-review.json` 与 canonical `work/final/prompt-semantic-review.md`，绑定 Manifest SHA 与每条 Prompt SHA。机器 Gate 只检查身份分离声明、全量覆盖、Hash、Swap Test 结构与 PASS 状态，不把字段/关键词/正则/producer 自签 Hash 当创意质量证明。

交付目标含真实图片或用户要看到画面时，每张 READY Prompt 通过 `work/generation-plan.json` 调用 `$image-generation-api`，原图存 `work/final/originals/`，回执绑定 Prompt、计划项与调用参数；方向/Prompt 交付、用户明确 Prompt-only（`prompt-only-authorization.json` 绑定原文与 Hash）或本次不需视觉验证时可跳过生成；producer 自报无效，失败不得用占位图或纯 Prompt 冒充。

需要互动 HTML（用户明确要求或交付形态确实需要）时调用 `$wxian-html-delivery`：每张图以标题 + 自己的完整 Prompt 独立配对，说明“该 Prompt 生成该图”，提供查看/筛选/对比/展开/复制；唯一 Prompt 路径与内容，不得截断、不得“同上”、不得一 Prompt 绑多图。其余情况 Markdown / Prompt / 原图 / JSON 即可完成交付，HTML 不是完成前提；独立 request 完成由 `$workspace-governance promote` 记录。

## 6. 与其他 Skill 的边界

- 从零游戏概念、画风玩法实验、人物×场景×玩法原型、成熟玩法变异：本 Skill。
- 概念已定、只要单次既定生图/改图/成图交付：`$wxian-image-production`；需先产生差异设计时仍由本 Skill 负责，并在同一 request 内调用 `$image-generation-api`。
- 用户要“先概念探索再直接交付图片文件”：`$wxian-image-production` 为 primary，本 Skill 作前置概念/原型能力，不创建第二 request。
- LOGO / ICON / KV / Store 等发行包装方案：`$wxian-visual-packaging`；海外手游发行视觉竞品研究：`$wxian-visual-competitive-analysis`；一般互联网事实/案例研究：`$wxian-conducting-internet-research`。

可以输出完整 Prototype Spec、Image Contract 和可直接生图 Prompt；不以“概念名称”作为完成标准。

## 7. 完成标准与交付

四档：`Prototype Complete`（方向有产品价值 + Spec 具体 + Test Contracts 可执行 + Test Prompts 可直接生成，仍 PROVISIONAL，完成声明只能 `DIRECTION_PROPOSED` 或 `PROTOTYPE_SPECIFIED`）、`Portfolio Complete`（四件套通过机器验证、Coverage 槽 APPROVED、重复/冲突处理完毕、无 blocking unknown）、`Production Complete`（选中方向 + FROZEN 锚点 + Production Contracts + Canonical/Target Prompts + 原图 + 按需 HTML + 适用 Gates PASS）、`Iteration Complete`（Failure Layer / 正确内容 / Change Scope 明确，下一轮可验证修复）。最终必须：有想法、想得通、设计具体、能直接画、能稳定继续做。完整判定条件与 Prompt Portfolio 门禁见 `22`。

正式 standalone 交付必经 `$workspace-governance promote`，由 Promote 唯一 blocking 调用 `portfolio_gate.py`；直接跑 Gate 只用于显式诊断。Prompt Portfolio 可先确定性 compile/validate 自查（命令见 `22` 与 `scripts/prompt_portfolio.py`、`scripts/prompt_semantic_review.py` 的 argparse）。产物路径、`work/final/*`、`delivery-manifest.json` 与作为 `wxian-image-production` 前置时的交接清单见 `23`；作为前置能力时不创建第二 request、不 Promote。

当用户明确需要 HTML/互动页交付时：交付接入：必须调用 `$wxian-html-delivery`，并由 `$workspace-governance promote` 验证。不使用 HTML 时，方向/Prompt/设计合同或 Markdown 概念包即为正式交付，HTML 不是完成前提。