# 产物生命周期与权威（Artifact Lifecycle）

> 从 SKILL.md 下沉（V8.73 token 整改）。时机：创建/冻结/复用/移交任何 concept-lab 产物前，或判断某层是否拥有权威时加载。

不同产物拥有不同生命周期与权威。

### EPHEMERAL

只用于推理，可在产生下一层后丢弃：

`Research Fuel / Premise Map / Creative Levers / Direction Seeds / Rejected Alternatives`

### PROVISIONAL

用于候选探索，必须具体到可生成，但在用户选择前允许变化：

`Direction Prototype / Prototype Spec / Test Image Contract / Test Prompt`

世界观-only 输入中的产品类型、玩家代理、体验目标、核心循环和内容规模先记为 `ASSUMED`，不能作为已确认产品事实。

这五类关键决定使用稳定假设 ID：`PLAYER_AGENT / PRODUCT_TYPE / TARGET_EXPERIENCE / CORE_LOOP / CONTENT_SCOPE`。不得通过省略记录绕过 Authority；`PORTFOLIO / VERTICAL_SLICE` 完成前全部必须有 `CONFIRMED` 状态和证据。

### FROZEN

用户选中方向后的长期设计事实：

`IP DNA Anchor / Cast Architecture / Character Identity Anchor / Variant Grammar / Mother Reference Manifest / Character Anchor / Creature Anchor / Environment Anchor / Gameplay Anchor / Style Anchor / UI Anchor`

`PORTFOLIO / VERTICAL_SLICE` 还冻结 `Product Blueprint / Content Graph / Coverage Plan`；其版本变化必须使下游 Visual Spec／Prompt Binding 失效。

FROZEN 只在用户明确改设计，或 Review 证明上游设计错误时更新。

### BOUND

只约束当前这一次生成/编辑：

`Mother Reference Binding / Reference Contract / Change Scope / Image Contract`

新图片可以建立新的 BOUND Contract，同时继续复用同一 FROZEN Anchor。

### COMPILED

从上游事实编译出的执行产物：

`Canonical Prompt / Target Model Prompt / ComfyUI Conditioning Instructions`

COMPILED 不拥有独立设计权威；上游变化后重新编译，不手工继承过时 Prompt。

### OBSERVED

真实生成/测试结果：

`Generated Image / Generation Review / Eval Result`

Observed 用于暴露问题；Production Truth 仍由上游 Authority 更新。
