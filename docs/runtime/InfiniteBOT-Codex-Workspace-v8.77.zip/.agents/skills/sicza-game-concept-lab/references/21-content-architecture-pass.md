# Content Architecture Pass｜产品因果与内容架构四件套

> 时机：`scope_profile=PORTFOLIO | VERTICAL_SLICE`、案例级 Prompt 组合，或需要 Content Graph / Coverage / 证据绑定字段时加载。

所有 scope 先建立最小 `work/concept-lab/product-blueprint.json`，把产品因果、Authority 与关键假设结构化。`scope_profile=PORTFOLIO | VERTICAL_SLICE` 时再读取 `14-product-content-architecture.md` 与 `15-portfolio-coverage-and-dedup.md`，建立完整四件套：

```text
work/concept-lab/product-blueprint.json
work/concept-lab/content-graph.json
work/concept-lab/coverage-plan.json
work/concept-lab/content-audit.json
```

Product Blueprint 记录产品因果与范围；Vertical Slice 的 `experience_loop` 必须用 entry/exit State 绑定首尾并保持每个相邻 Step 状态连续；Content Graph 用稳定 ID 管理内容及关系；Coverage Plan 定义必须证明的槽位；Content Audit 重算证据、重复、冲突与完成状态。

案例级创意任务在四件套之外建立：

```text
work/concept-lab/prompt-portfolio.json
work/final/prompts/**/*.md
```

其中 Manifest 只承担机器绑定，Markdown Prompt 是用户可直接使用的正式成果。多方向先做 Material Fertility 和 Direction Material DNA，再建立方向各自的 Graph/Coverage；不能先复制一批 Prompt，再用不同方向名称包装。单方向深度与多方向发散分别使用 `SINGLE_DIRECTION_DEPTH` 和 `MULTI_DIRECTION_DIVERGENCE`，需要二者时使用 `HYBRID_PORTFOLIO`。

每张正式证据额外绑定：

`batch_id / evidence_kind / path / byte_size / width / height / preview_path / sha256 / graph_refs / coverage_refs / coverage_claims / parent_asset_or_screen_id / variant_axes / semantic_delta / counting_class / counting_delta / event_delta / facts / judgements / recommendations / unknowns / image_specific_mechanisms / regions`

所有 `NEW_*` 必须用结构化 `counting_delta` 绑定对应 Graph 节点并证明类别允许的语义轴；`NEW_EVENT` 还必须用 `event_delta` 证明 Cause、Action 或 Consequence至少一项真实改变。只换镜头、色光、特效、表情、裁切、排版、语言、脸或服装必须记为表现变化，不能依靠自由文本宣称语义新增。产品方向另由 `direction_inventory` 验证 Player Agent、Product Type、Core Loop 或 World Causality 的真实变化。

没有 Coverage 槽位的探索图可以保留，但不能提高正式覆盖率。显示名不是身份键；卡牌格数、士兵实例数和画面人头数不等于独立角色数。
