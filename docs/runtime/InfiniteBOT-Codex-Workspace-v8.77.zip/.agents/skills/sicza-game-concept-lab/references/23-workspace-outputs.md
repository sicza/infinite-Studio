# Workspace 输出与交付路径

> 时机：建立 request 产物文件、写 final-review / delivery-manifest、或作为 `wxian-image-production` 前置能力交接产物时加载。

### 作为独立 `game-concept-lab` request

最终用户产物统一进入 `work/final/`：

```text
work/final/game-concept-lab.html      # 按需互动交付；仅需要 HTML 展示时生成，内嵌全部展示图片和逐图完整 Prompt
work/final/originals/*                # 全部实际生成原图；未做视觉验证或 Prompt-only 时不存在
work/final/game-concept-proposal.md   # 内部权威内容源
work/final/prototype-prompts.md       # 内部 Prompt 汇总；Prompt-only 时可作为外部交付
work/final/production-anchors.md      # 已进入 FROZEN Production Anchors 时
work/concept-lab/product-blueprint.json # 必须；scope_profile 与产品因果
work/concept-lab/prototype-spec.json     # PROTOTYPE 必须；结构化测试资产、合同与 Prompt
work/concept-lab/content-graph.json     # PORTFOLIO / VERTICAL_SLICE 必须
work/concept-lab/coverage-plan.json     # PORTFOLIO / VERTICAL_SLICE 必须
work/concept-lab/content-audit.json     # PORTFOLIO / VERTICAL_SLICE 必须
work/concept-lab/prompt-portfolio.json  # Prompt Portfolio 内部绑定
work/concept-lab/prompt-semantic-review.json # 独立全量语义审查绑定
work/final/prompts/**/*.md              # Prompt Portfolio 用户核心交付
work/final/prompt-semantic-review.md    # 逐 Prompt 与跨方向 Swap Test 审查证据
```

`game-concept-proposal.md` 保留足以直接执行的人物/场景/玩法/视觉具体设计和 Prototype 状态。完成后实际核对最终文件，写：

- `work/final-review.md`：只检查 Premise/Hard Lock、Direction 差异、World×Gameplay 因果、Prototype 具体度、Image Contract/Prompt 可执行性、Reference 边界；长期 IP/角色项目再检查 IP DNA、Character Identity、Variant Grammar、Mother Reference Binding 与适用的 Consistency Tests；
- `work/delivery-manifest.json`：按实际交付形态登记 active 交付。生成了 HTML 时把 HTML 记为 active `interactive_html`；每张真实生成原图记为 active `generated_original`；没有 HTML 时以 `game-concept-proposal.md / prompts / prototype-prompts.md` 等实际对外文件作为 active 交付。Markdown、JSON 与审查文件同时保留在 request 内作为内部权威和验证证据。用户明确要求 `Prompt-only` 时，Prompt 文件作为 active 外部交付；
- `product_blueprint` 对所有 scope 保留；Prototype 另含 `prototype_spec`；Portfolio 另含 `content_graph / coverage_plan / content_audit`。这些内部机器合同不因对外交付形态（HTML 或纯文档）而删除；
- Prompt Portfolio 另含一个 `prompt_portfolio_manifest`、一个 `prompt_semantic_review`、一个 `prompt_semantic_review_report` 和全部 `prompt_markdown` 文件；它们作为展示层与审查的权威来源，必须与 Manifest 一一对应；
- `portfolio_gate.py` 验证 Product Blueprint、Vertical Slice 连续状态链、全部语义计数与方向增量、图谱交叉引用、Coverage、证据路径/Hash、精确重复、近重复登记、冲突状态、Visual Spec 上游绑定和完成声明；18 项案例回归必须绑定真实来源 ID/Hash 并执行行为断言，52+146 条案例规模 Prompt 回归还必须验证内容锚、合同正文绑定和反模板克隆，不能只登记名称或数量；
- `$workspace-governance promote`：唯一 standalone completion。

### 作为 `wxian-image-production` 的前置能力

当最终目标是实际图片文件时，本 Skill 不创建第二 request、不 Promote。产物写入调用方当前 request：

```text
work/concept-lab/direction-prototypes.md
work/concept-lab/selected-prototype.md
work/concept-lab/test-prompts.md
work/concept-lab/ip-character-system.json      # 长期 IP / 正式角色适用
work/concept-lab/ip-character-binding.json     # 长期 IP / 正式角色适用
work/concept-lab/ip-character-preflight.json   # production preflight 证据
work/concept-lab/ip-character-handoff.json     # provider-resolved image conditioning inputs
work/concept-lab/product-blueprint.json        # 作为任何 Concept 前置的最小产品因果合同
work/concept-lab/content-graph.json            # PORTFOLIO / VERTICAL_SLICE 适用
work/concept-lab/coverage-plan.json            # PORTFOLIO / VERTICAL_SLICE 适用
work/concept-lab/content-audit.json             # PORTFOLIO / VERTICAL_SLICE 适用
```

用户已选择或已授权收敛的结果交回 `wxian-image-production` 写入正式 `visual-requirement.md`。长期 IP / 正式角色同时交接 `ip-character-system/binding/preflight/handoff`；`image_conditioning_inputs` 保持为独立图像输入通道。
