# Prompt Compilation 规则

> 时机：生成 Canonical/Target Prompt、编译 Prompt Portfolio、或选择 model adapter/profile 时加载。

先读取 `.agents/skills/sicza-visual-director/references/prompt-adapter-invariants.md`，再生成 Prompt Compilation 结果。它只能表达：

`Prototype Spec or Frozen Anchors + Mother Reference Binding(if applicable) + Reference Contract + Change Scope + Image Contract + Visual Spec`

Prompt Compilation 只投影已存在的上游事实。Mother Reference Binding 的 Preserve/Role 可进入文本语义；真实图像输入继续通过 `ip-character-handoff.json.image_conditioning_inputs` 进入 Provider/Workflow。

案例级 Prompt Portfolio 按 `references/17-prompt-portfolio-composition.md` 批量编译。每个正式 Coverage 槽分别产生完整、自足、可复制执行的 Canonical Prompt；禁止输出关键词骨架、待填模板或依赖“沿用上一条”的残缺 Prompt。相同角色、地点和建筑的身份／拓扑锁必须重述到当前 Prompt，差异只开放当前 Semantic Delta。

如果用户没有指定目标模型，不为了模型选择打断创意流程：输出 `TARGET = GENERAL` 的自然语言 Canonical Prompt。用户之后指定模型时只重新编译 Adapter，不重做上游设计。

目标模型已解析时，下列文件只提供 Game Concept domain delta；通用 Provider 方言统一引用 `wxian-image-production/references/prompt-packs/`：

1. GPT Image → `references/prompt-adapters/gpt-image.md`
2. Gemini / Nano Banana → `references/prompt-adapters/gemini-nano-banana.md`
3. ComfyUI / Diffusion → `references/prompt-adapters/comfyui-diffusion.md`

当前易变模型能力从 `references/model-profiles/` 读取。Profile `Verified At` 超过 30 天，或用户询问当前/最新能力、模型标识变化、真实行为冲突时，重新核对官方资料。
