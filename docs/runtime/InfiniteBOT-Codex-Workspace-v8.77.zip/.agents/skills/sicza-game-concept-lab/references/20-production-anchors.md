# Selection → Production Anchors（FROZEN 锚点字段）

> 时机：用户选中 Prototype 后建立 FROZEN 锚点、长期 IP/角色 canonical 文件时加载。

用户选中 Prototype 后才进入 FROZEN。按当前对象建立：

- 长期角色/IP：`IP DNA Anchor / Character Identity Anchor / Variant Grammar / Mother Reference Manifest`；3+ 核心角色再建立 `Cast Architecture`。完整方法与机器产物见 `references/05a-ip-character-system.md`、`05b-character-identity-grammar.md`、`05c-cast-architecture.md`。
- 临时角色：`Character Anchor = Identity / Exact Age / Face / Hair / Body / Proportion / Costume Architecture / Primary Functional Prop / Signature Color Placement / World-specific Hook`。
- Creature：`Gameplay Function / Habitat / Behavior / Locomotion / Anatomy / Silhouette / Surface`。
- Environment：`Identity / Macro Layout / Function Zones / Landmark / Navigation / Vertical Structure / Material Family / Lighting Logic / Scale`。
- Gameplay：`Primary Verb / Target / Constraint / System Response / Visible State Delta / Reward / Progression / Core Loop`。
- Style：`Realism / Proportion / Shape Language / Camera Family / Material Strategy / Color Structure / Lighting Logic / Detail Density`。
- UI（仅需要时）：`UI Family / Persistent Information / Contextual Information / Hierarchy / Safe Areas / Interaction Feedback`。

长期角色/IP 的 canonical 文件固定为：

```text
work/ip-character-system.json
work/ip-character-binding.json
work/ip-character-preflight.json
work/ip-character-handoff.json   # 仅实际生图/编辑时
```

执行顺序与 Provider/Mode 边界由 `05a-ip-character-system.md` 和对应脚本定义。FROZEN 事实变化后重新绑定/编译；OBSERVED 图片不拥有上游 Authority。
