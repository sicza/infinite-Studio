# 完成标准（Completion Standards）与 Prompt Portfolio 门禁

> 时机：声明任何完成级别、准备 `promote`、或需要判定 Portfolio / Prompt Portfolio 机器门禁条件时加载。

### Prototype Complete

`Direction 有产品价值 + Prototype Spec 已具体 + Test Image Contracts 可执行 + Test Prompts 可直接生成`

仍为 PROVISIONAL。

必须存在并通过 Schema 的 `work/concept-lab/product-blueprint.json`；世界观-only 任务可以保留关键 `ASSUMED` 项，但完成声明只能是 `DIRECTION_PROPOSED` 或 `PROTOTYPE_SPECIFIED`。
`PROTOTYPE_SPECIFIED` 还要求通过 Schema 的 `work/concept-lab/prototype-spec.json`，其中至少一个 READY 测试资产含完整 Image Contract 与可执行 Canonical Prompt。

### Portfolio Complete

`Product Blueprint + Content Graph + Coverage Plan + Content Audit` 均通过机器验证；每个未豁免 Coverage 槽位为 APPROVED；精确重复不重复计数；近重复有 Parent/Changed Axes/Semantic Delta；身份、名称、拓扑与变体冲突均已解决或明确接受；不存在 blocking unknown；`final-review.md` 明确 `PORTFOLIO_VERIFIED`。

当 `portfolio_output=PROMPT_MARKDOWN | BOTH` 时还必须：

- `prompt-portfolio.json` 通过结构、路径、Hash、Coverage、明显重复和合同一致性验证；
- 每条 Prompt 的主体、原子可见实体、地点、动作、可见后果和至少两个世界专属物必须作为 `content_anchors` 进入各自唯一的权威标签行；主体实体采用 `entity_id / entity_type / identity / visible_count=1`，identity 是最多四词的名词性目录项且不得包含另一已登记主体身份，`subject_identity` 是实体 identity 的精确有序组合，`subject_count` 等于原子实体数，禁止把多人关系句折叠成一个主体；
- Canonical Prompt 的 21 个权威标签必须各自独占一行、顺序固定且只出现一次，Validator 解析后与 Manifest 精确相等；标签名按 Unicode 规范化和大小写无关方式排除藏匿，正文其他位置出现同名标签、跨字段藏值或重复权威行一律阻断；
- 每个 Direction 必须拥有独占的主体／地点／动作／后果／世界物件 `anchor_lexicon`，由 FROZEN Direction Origin JSON 与 SHA 绑定，并接受词项所有权和明显串料校验；这些机器事实不证明真实语义归属，重签来源、重分配词库、DNA 填词与跨方向搬运必须由独立 reviewer 识别；
- Semantic Delta、Image Contract 全部执行字段严格绑定；至少八项视觉机制必须是 `operation / target / visible_result` 三元组，机器 Gate 检查结构、目标归属和明显复用，独立 reviewer 判断结果是否真正形成当前画面的可见机制，通用“仍可见”、关键词回声和复述 operation 均判 BLOCK；
- 视觉机制必须描述真实可见的构图、空间、光色、材质、层级或可读性操作，不能拿主体、地点、动作或排除项充数；
- 关系驱动与系统驱动的案例回归必须使用各自独立的素材词汇和因果合同，关系驱动内部不同方向也要各自锁定词汇边界；跨案例或跨方向角色、地点、事件、物件和系统混入视为语义污染，不得用“数量已达标”掩盖；
- Gate 计算编号／颜色／方向标签归一化克隆、正文近重复、内容锚重复、八机制组合滥用和合同绑定；它不声称这些词法检查已证明 Direction DNA、真实因果差异或创意质量；
- 必须存在由不同 reviewer 产出的全量语义审查 JSON 与 Markdown 报告；每条 Prompt 五类检查全部 PASS，全部方向对至少两组 Swap Test PASS，不存在 blocking unknown；`skin_swap_interchangeable=false`、producer 自评或抽样审查不能替代该证据；
- Active delivery role 按当前 scope/output 使用精确白名单；`portfolio_output=EVIDENCE` 不得夹带 `prompt_portfolio_manifest / prompt_markdown / prototype_prompts / prompt_semantic_review / prompt_semantic_review_report` 或用未知 role 改名绕过；任何正式 Prompt 交付都必须显式选择 `PROMPT_MARKDOWN | BOTH` 并进入同一语义审查门禁；
- 每条正式 Prompt 是 `CANONICAL_PROMPT` Evidence，内容 Hash 绑定 Prompt 正文而非整个文件；
- 所有Prompt均真实存在于 `work/final/prompts/**/*.md`；
- `final-review.md` 明确 `PROMPT_PORTFOLIO_VERIFIED` 与 `PROMPT_SEMANTIC_REVIEW_PASS`；
- 不要求图片、尺寸或预览，也不得声称验证了成图质量。

正式 standalone 交付必经 `$workspace-governance promote`，由 Promote 唯一 blocking 调用 `portfolio_gate.py`。直接运行该 Gate 只用于显式诊断，不属于正常交付序列。

Prompt Portfolio 可先由内部 Manifest 确定性写出并单独检查：

```bash
python .agents/skills/sicza-game-concept-lab/scripts/prompt_portfolio.py compile \
  --manifest <request>/work/concept-lab/prompt-portfolio.json --workspace-root .
python .agents/skills/sicza-game-concept-lab/scripts/prompt_portfolio.py validate \
  --manifest <request>/work/concept-lab/prompt-portfolio.json --workspace-root .
python .agents/skills/sicza-game-concept-lab/scripts/prompt_semantic_review.py \
  --manifest <request>/work/concept-lab/prompt-portfolio.json \
  --review <request>/work/concept-lab/prompt-semantic-review.json \
  --workspace-root .
```

### Production Complete

`Selected Direction + Frozen Anchors + Production Image Contracts + Canonical/Target Prompts + Generated Originals + （按需）Interactive HTML + Applicable Runtime Gates PASS`。长期 IP / 正式角色包含 `ip-character-system/binding` preflight；目标含实际图片时还要求当前 Provider×Mode 的 `ip-character-handoff.status=READY`。READY 的机器语义由 `05a-ip-character-system.md`、Registry 与 Runtime 定义。HTML 只有用户明确需要或交付形态确实需要时才生成，不在这条完成条件里强制出现。

### Iteration Complete

`Failure Layer 明确 + 正确内容明确 + Change Scope 明确 + 下一轮能验证修复`

最终必须达到：

**有想法、想得通、设计具体、能直接画、能稳定继续做。**
