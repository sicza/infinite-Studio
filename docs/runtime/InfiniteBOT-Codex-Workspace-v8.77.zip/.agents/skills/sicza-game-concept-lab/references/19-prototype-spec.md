# Prototype Spec 字段契约

> 时机：为第一轮方向建立或校验 `PROVISIONAL` Prototype Spec、判断测试证据规模时加载。

每个第一轮方向建立轻量但可直接生成的：

`STATUS = PROVISIONAL`

至少包括：

### Direction

`Product Type / Player Fantasy / Core Verb / World Rule / Core Reward / World Dependency`

### Character Core

有角色时必须具体到：

`Exact Age / Body / Head-to-body Ratio / Face / Hair / Costume Architecture / Primary Functional Prop / World-specific Hook`

重要外观需要能追溯到世界、Gameplay、职业、Camera 或视觉需求；武器只在 Gameplay 需要时设计。

### Environment Core

`Environment Identity / Original Function / Current Function / Gameplay Geometry / Landmark / Lighting / Camera`

### Gameplay Core

`Player Action / Target / System Response / Visible State Delta / Reward / Progression`

进入 `VERTICAL_SLICE` 或声称规则已闭合时，还必须写：

`Input / Known Information / Hidden Information / Legal Action / State Transition / Time or Turn / End Condition / Failure or Exit / Recovery / Next-run Difference / Dangerous Assumption / Falsification Test`

### Visual Core

`Art Direction / Proportion / Camera / Environment Scale / Prop Scale / NPC Density / Material & Lighting Logic`

### Test Evidence Scale

证据规模由交付目标决定，不设“每次任务最少几张”：

- 只要方向 / Prompt：不生成证据图；
- 需要视觉验证但只验证少数关键判断：只为真正会改变判断的方向生成证据图（通常 1–5 张）；
- 交付完整入口测试概念包：`Character Test / Hero Environment / Gameplay Hero Screen` 三类主证据图，选择 3–5 个高差异方向，每方向各 1 组，共 9–15 张；某类图确实无意义时换成最能证明产品价值的资产并记录替代理由；
- 角色、怪物、场景、道具、建筑或玩法界面等单对象差异设计：3–5 个方向、每方向 1 张主图，共 3–5 张；设定集、结构拆解或状态变化只按需求增补，不用重复镜头凑数。

上述数量是“完整概念包”的规模口径，不是普通任务的默认工作量；用户指定数量时遵从。
