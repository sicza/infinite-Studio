"""Observe a real image with a multimodal model through the workspace gateway.

Why this exists
---------------
Evidence review needs a reproducible observation entry point: the same image, the same region, the
same model and the same prompt must be re-runnable by someone else. Ad-hoc viewing cannot do that
(no region pinning, no model pinning, no batch, no re-run). This script provides exactly that: it
crops in ORIGINAL image pixel coordinates, pins the model, and never prints the API key.

Usage
-----
  python -X utf8 vision_observe.py --workspace-root <project-root> \
      --image <path> --prompt-file <path> \
      [--region x1,y1,x2,y2] [--model gemini-3.7-flash] [--out <path>] [--max-tokens 4000] [--json]

Reads credentials from <root>/.agents/runtime/credentials.json (key: generation_api_key) and the
gateway base URL from <root>/.agents/skills/image-generation-api/config/api-runtime.json.

Path resolution: --image resolves against --workspace-root (project-relative paths are the common
case); --prompt-file and --out resolve against the caller's working directory.

Every failure path returns a structured JSON object on stdout with a non-zero exit code: bad input
(bad region, non-decodable image, unreadable prompt), unusable endpoint config, gateway/transport
errors and empty completions. The script does not raise uncaught exceptions for bad input, and it
never echoes the credential.

Exit codes: 0 ok, 1 blocked (bad input or gateway/transport failure), 2 unusable endpoint config.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import io
import json
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from PIL import Image, UnidentifiedImageError

MAX_EDGE = 1536
DEFAULT_MODEL = "gemini-3.7-flash"
TIMEOUT_SECONDS = 300
CACHE_SCHEMA = "sicza.vision-observation.v1"
USAGE_SCHEMA = "sicza.vision-usage.v1"
CACHE_DIR = Path(".agents") / "runtime" / "vision-cache"
USAGE_LEDGER = Path(".agents") / "runtime" / "vision-usage.jsonl"


def fail(status: str, **extra: object) -> int:
    print(json.dumps({"status": status, **extra}, ensure_ascii=False))
    return 1


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def observation_key(image_sha256: str, scope: str, prompt_sha256: str, model: str, region: str | None) -> str:
    """Reuse is decided by real source bytes, purpose, contract and model - never by a path."""
    payload = json.dumps({
        "schema": CACHE_SCHEMA, "image": image_sha256, "scope": scope,
        "prompt": prompt_sha256, "model": model, "region": region or "",
    }, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def record_usage(root: Path, entry: dict) -> None:
    """Append one machine fact per invocation; this ledger is the only token/call evidence we have."""
    path = root / USAGE_LEDGER
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps({"schema": USAGE_SCHEMA, "at": datetime.now(timezone.utc).isoformat(), **entry},
                                    ensure_ascii=False) + "\n")
    except OSError:
        pass


def usage_report(root: Path) -> dict:
    path = root / USAGE_LEDGER
    if not path.is_file():
        return {"status": "ready", "ledger": str(path), "invocations": 0, "provider_calls": 0, "cache_hits": 0}
    counts = {"invocations": 0, "provider_calls": 0, "cache_hits": 0, "blocked": 0, "forced_reads": 0}
    by_scope: dict[str, dict[str, int]] = {}
    forced_reasons: dict[str, int] = {}
    images: set[str] = set()
    tokens: dict[str, int] = {}
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        counts["invocations"] += 1
        scope = str(item.get("scope", "general"))
        bucket = by_scope.setdefault(scope, {"invocations": 0, "provider_calls": 0, "cache_hits": 0, "blocked": 0})
        counts["provider_calls"] += 1 if item.get("provider_call") else 0
        bucket["invocations"] += 1
        if item.get("cached"):
            counts["cache_hits"] += 1
            bucket["cache_hits"] += 1
        if item.get("provider_call"):
            bucket["provider_calls"] += 1
        if item.get("status") != "ok":
            counts["blocked"] += 1
            bucket["blocked"] += 1
        if item.get("image_sha256"):
            images.add(str(item["image_sha256"]))
        reason = str(item.get("no_cache_reason") or "").strip()
        if reason:
            counts["forced_reads"] += 1
            forced_reasons[reason] = forced_reasons.get(reason, 0) + 1
        usage = item.get("provider_usage")
        if isinstance(usage, dict):
            for key, value in usage.items():
                if isinstance(value, (int, float)):
                    tokens[str(key)] = tokens.get(str(key), 0) + int(value)
    return {"status": "ready", "ledger": str(path), **counts, "distinct_images": len(images),
            "by_scope": by_scope, "forced_read_reasons": forced_reasons, "provider_tokens": tokens,
            "note": "provider_tokens only reflects what the gateway actually returned; absent fields are not estimated"}


def load_endpoint(root: Path) -> tuple[str, str]:
    """Return (base_url, api_key) without ever echoing the key."""
    cred = root / ".agents" / "runtime" / "credentials.json"
    cfg = root / ".agents" / "skills" / "image-generation-api" / "config" / "api-runtime.json"
    if not cred.is_file():
        raise FileNotFoundError(f"credentials not found: {cred}")
    if not cfg.is_file():
        raise FileNotFoundError(f"api runtime config not found: {cfg}")
    raw = json.loads(cfg.read_text(encoding="utf-8"))
    base = raw.get("base_url") or raw.get("connection", {}).get("base_url")
    if not base:
        raise KeyError("base_url missing from api-runtime.json")
    key = json.loads(cred.read_text(encoding="utf-8"))["generation_api_key"]
    return base.rstrip("/"), key


def parse_region(raw: str, size: tuple[int, int]) -> tuple[int, int, int, int]:
    """Validate an x1,y1,x2,y2 box in ORIGINAL pixel coordinates against the real image size."""
    parts = [part.strip() for part in raw.split(",")]
    if len(parts) != 4:
        raise ValueError(f"region needs exactly 4 comma-separated integers, got {len(parts)}: {raw!r}")
    try:
        coords = [int(part) for part in parts]
    except ValueError as exc:
        raise ValueError(f"region values must be integers: {raw!r}") from exc
    x1, y1, x2, y2 = coords
    width, height = size
    if not (0 <= x1 < x2 <= width and 0 <= y1 < y2 <= height):
        raise ValueError(
            f"region {x1},{y1},{x2},{y2} is out of bounds or not ordered; "
            f"image is {width}x{height} and requires 0<=x1<x2<=w, 0<=y1<y2<=h"
        )
    return x1, y1, x2, y2


def load_image(image_path: Path) -> Image.Image:
    """Decode eagerly so a corrupt or non-image input fails here, not halfway through encoding."""
    try:
        with Image.open(image_path) as opened:
            opened.load()
            image = opened.copy()
    except UnidentifiedImageError as exc:
        raise ValueError("file is not a decodable image (unsupported or corrupt format)") from exc
    except Image.DecompressionBombError as exc:
        raise ValueError("image exceeds the decoder pixel limit") from exc
    except (OSError, ValueError) as exc:
        raise ValueError(f"image could not be opened: {exc}") from exc
    if image.width < 1 or image.height < 1:
        raise ValueError("image has zero extent")
    return image


def encode(image_path: Path, region: str | None) -> tuple[str, str]:
    """Return (data_url, note). Region coordinates are ORIGINAL image pixels."""
    image = load_image(image_path)
    original_size = image.size
    note = ""
    if region:
        box = parse_region(region, original_size)
        image = image.crop(box)
        note = f"[crop {box[0]},{box[1]},{box[2]},{box[3]} of original {original_size}] "
    width, height = image.size
    if max(width, height) > MAX_EDGE:
        scale = MAX_EDGE / max(width, height)
        image = image.resize((max(1, int(width * scale)), max(1, int(height * scale))), Image.LANCZOS)
    if image.mode not in ("RGB", "L"):
        image = image.convert("RGB")
    buffer = io.BytesIO()
    image.save(buffer, format="JPEG", quality=90)
    payload = base64.b64encode(buffer.getvalue()).decode("ascii")
    return "data:image/jpeg;base64," + payload, note


def build_request(base: str, key: str, model: str, prompt: str, data_url: str, max_tokens: int) -> urllib.request.Request:
    body = {
        "model": model,
        "temperature": 0.2,
        "max_tokens": max_tokens,
        "messages": [{
            "role": "user",
            "content": [
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": data_url}},
            ],
        }],
    }
    return urllib.request.Request(
        base + "/chat/completions",
        data=json.dumps(body).encode("utf-8"),
        headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"},
    )


def extract_text(payload: dict) -> str:
    """Reasoning-heavy models may return an empty or missing content field; never crash on it."""
    choices = payload.get("choices") or []
    if not choices:
        return ""
    message = (choices[0].get("message") or {}).get("content")
    if isinstance(message, list):
        return "\n".join(str(part.get("text", "")) for part in message if isinstance(part, dict)).strip()
    return str(message or "").strip()


def main() -> int:
    parser = argparse.ArgumentParser(description="Observe an image through the workspace gateway.")
    parser.add_argument("command", nargs="?", choices=("observe", "report"), default="observe",
                        help="observe one image (default) or report accumulated call/cache/token usage")
    parser.add_argument("--workspace-root", default=".")
    parser.add_argument("--image", default=None)
    parser.add_argument("--prompt-file", default=None)
    parser.add_argument("--region", default=None, help="x1,y1,x2,y2 in ORIGINAL image pixels")
    parser.add_argument("--model", default=DEFAULT_MODEL)
    parser.add_argument("--scope", default="general",
                        help="what this observation is for (identity-lock, full-reverse, composition, ...)")
    parser.add_argument("--out", default=None)
    parser.add_argument("--max-tokens", type=int, default=4000)
    parser.add_argument("--no-cache", action="store_true",
                        help="force a real provider read; only for a changed source, a genuinely new question, or an independent blind review")
    parser.add_argument("--no-cache-reason", default="",
                        help="why this read cannot reuse an existing observation; required with --no-cache and recorded in the ledger")
    parser.add_argument("--json", action="store_true", help="print the raw gateway payload too")
    args = parser.parse_args()

    root = Path(args.workspace_root).resolve()
    if args.command == "report":
        print(json.dumps(usage_report(root), ensure_ascii=False, indent=2))
        return 0
    if not args.image or not args.prompt_file:
        return fail("blocked", reason="observe requires --image and --prompt-file")
    no_cache_reason = str(args.no_cache_reason or "").strip()
    if args.no_cache and len(no_cache_reason) < 8:
        # An unexplained forced read is indistinguishable from an ordinary cache miss, so the
        # "exception is traceable" property would be unverifiable.
        return fail("blocked", reason="--no-cache requires --no-cache-reason (at least 8 characters): "
                                      "state the changed source, the new question, or the blind-review need")

    image_path = Path(args.image)
    if not image_path.is_absolute():
        image_path = root / image_path
    if not image_path.is_file():
        return fail("blocked", reason="image not found", path=str(image_path))
    prompt_path = Path(args.prompt_file)
    if not prompt_path.is_file():
        prompt_path = root / args.prompt_file
    if not prompt_path.is_file():
        return fail("blocked", reason="prompt file not found", path=str(args.prompt_file))

    try:
        image_sha = file_sha256(image_path)
        prompt_sha = file_sha256(prompt_path)
    except OSError as exc:
        return fail("blocked", reason="cannot hash observation inputs", detail=str(exc)[:300])
    key = observation_key(image_sha, args.scope, prompt_sha, args.model, args.region)
    cache_path = root / CACHE_DIR / f"{key}.json"
    ledger = {"scope": args.scope, "model": args.model, "image_sha256": image_sha, "prompt_sha256": prompt_sha,
              "region": args.region or "", "cache_key": key, "no_cache_reason": no_cache_reason}

    if not args.no_cache and cache_path.is_file():
        try:
            cached = json.loads(cache_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            cached = None
        if isinstance(cached, dict) and cached.get("text"):
            text = str(cached["text"])
            out = Path(args.out) if args.out else (root / "tmp" / "vision-out" / (image_path.stem + ".md"))
            try:
                out.parent.mkdir(parents=True, exist_ok=True)
                out.write_text(text + "\n", encoding="utf-8")
            except OSError as exc:
                return fail("blocked", reason="cannot write output", path=str(out), detail=str(exc)[:300])
            record_usage(root, {**ledger, "status": "ok", "cached": True, "provider_call": False, "chars": len(text)})
            print(json.dumps({"status": "ok", "cached": True, "model": args.model, "scope": args.scope,
                              "out": str(out), "chars": len(text), "cache_key": key,
                              "note": "reused an observation of the same source, scope, contract and model"}, ensure_ascii=False))
            return 0

    try:
        base, key_value = load_endpoint(root)
    except (FileNotFoundError, KeyError, json.JSONDecodeError) as exc:
        record_usage(root, {**ledger, "status": "blocked", "cached": False, "reason": "endpoint config unusable", "provider_call": False})
        return fail("blocked", reason="endpoint config unusable", detail=str(exc)) or 2

    try:
        prompt = prompt_path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        record_usage(root, {**ledger, "status": "blocked", "cached": False, "reason": "prompt unreadable", "provider_call": False})
        return fail("blocked", reason="prompt file unreadable", detail=str(exc)[:300])

    try:
        data_url, note = encode(image_path, args.region)
    except ValueError as exc:
        record_usage(root, {**ledger, "status": "blocked", "cached": False, "reason": "image or region unusable", "provider_call": False})
        return fail("blocked", reason="image or region unusable", detail=str(exc))

    request = build_request(base, key_value, args.model, prompt, data_url, args.max_tokens)

    try:
        with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")[:800]
        hint = "upstream temporarily unavailable; retry" if exc.code == 503 else None
        record_usage(root, {**ledger, "status": "blocked", "cached": False, "reason": f"http {exc.code}", "provider_call": True})
        return fail("blocked", http_status=exc.code, model=args.model, detail=detail, hint=hint)
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        record_usage(root, {**ledger, "status": "blocked", "cached": False, "reason": "transport or payload error", "provider_call": True})
        return fail("blocked", reason="transport or payload error", model=args.model, detail=str(exc)[:800])
    except (OSError, ValueError) as exc:
        record_usage(root, {**ledger, "status": "blocked", "cached": False, "reason": "unexpected transport failure", "provider_call": True})
        return fail("blocked", reason="unexpected transport failure", model=args.model, detail=str(exc)[:800])

    text = (note + extract_text(payload)).strip()
    if not text:
        record_usage(root, {**ledger, "status": "blocked", "cached": False, "reason": "empty completion content",
                            "provider_call": True, "provider_usage": payload.get("usage")})
        return fail("blocked", reason="empty completion content", model=args.model,
                    hint="raise --max-tokens; reasoning models can spend it before emitting content")

    out = Path(args.out) if args.out else (root / "tmp" / "vision-out" / (image_path.stem + ".md"))
    try:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(text + "\n", encoding="utf-8")
    except OSError as exc:
        record_usage(root, {**ledger, "status": "blocked", "cached": False, "reason": "cannot write output", "provider_call": True})
        return fail("blocked", reason="cannot write output", path=str(out), detail=str(exc)[:300])

    try:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        cache_path.write_text(json.dumps({"schema": CACHE_SCHEMA, "image_sha256": image_sha,
                                          "scope": args.scope, "prompt_sha256": prompt_sha,
                                          "model": args.model, "region": args.region or "", "text": text},
                                         ensure_ascii=False), encoding="utf-8")
    except OSError:
        pass
    record_usage(root, {**ledger, "status": "ok", "cached": False, "provider_call": True, "chars": len(text),
                        "provider_usage": payload.get("usage")})

    result = {"status": "ok", "cached": False, "model": args.model, "scope": args.scope,
              "out": str(out), "chars": len(text), "cache_key": key}
    if args.json:
        result["raw"] = payload
    print(json.dumps(result, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
