---
name: wxian-visual-baselines
description: 从项目真实资产、历史产出与 curated Reference 建立、刷新唯一正式 Project Visual Baseline：项目级视觉综合判断（项目是什么、为何像、哪些结构高频有效、底线、可突破空间），不搬运单图分析。
---

# Project Visual Baseline｜项目视觉综合基准

进入前执行 `$workspace-governance consume-personal-context --request <request> --consumer wxian-visual-baselines`；阻断则停止。

## 0. 你在做什么

交付不是“分析汇总表”，而是**项目视觉认知模型**。本 Skill 是唯一 Project Visual Baseline Authority；不得发布第二份 Visual Baseline、Family registry 或另一套项目事实。需要把历史证据抽象成可生成视觉语法时，读 `references/visual-director-integration.md`，用 `$sicza-visual-director` 的 `BASELINE_DELTA` 与 `D-GRAMMAR / D-STYLE / D-SIGN / D-MEM / H-MULTISCALE / G-VERIFY` 作分析方法。

最终 `project/baselines/project-visual-standard.md` 必须让第一次进入项目的 Codex 在不重新翻全量素材、不读全量单图分析的情况下建立正确的项目脑内图像，并在真实需求里提高一稿命中概率。Baseline 告诉 Codex：项目是什么、现在做成什么样；哪些视觉信号最让结果“像这个项目”；历史上哪些结构最常成功、各自解决什么业务问题；不同历史方向真正差在哪、何时选 A 何时不该选；角色/品牌/资产边界与最低质量线；已有产出是**高概率先验**而不是白名单。

Baseline **不是**：单图 Reverse Analysis 的拼接；每张图一条 `source_note` 的审计报账；Family 字段填满的数据库 dump；“高品质/电影感/冲击力/层次清楚”这类通用原则合集；固定 Prompt、构图、色调或创意宪章。

视觉模型只服务三件事：Baseline 必需的真实观察、用户明确要求的参考/诊断、后处理空间定位；**不负责最终审美验收**，默认不要求多模型互评，专业结论由本 Skill 综合与 Agent 判断承担，最终质量由 Human 判定（见 `publication-contract.md`）。

正式发布目录：`project/baselines/{analyses/**, character-profiles/**, character-verifications/**, brand-profile.md, reference-map.json, synthesis-ledger.json, project-visual-standard.md, index.json, publication.json}`。

## 1. 证据角色

- Canonical / Project Evidence（`project/assets/characters|props|logos|game-screenshots|other/**`，以及明确标记为项目正式产出的截图/历史 KV/游戏画面）证明项目自身事实；canonical 目录由 `.agents/lib/asset_taxonomy.py` 唯一定义，`characters` 与 `props` 的正式资产必须全部进入深度分析与合成账本。道具只证明结构/配色/使用方向，不证明稀有度、性能或获取规则；规范位置唯一 = `project/assets/props/`，历史位置 `project/props/**` 仍按 props 分类但会报 `props_location_report.migration_required`，需迁移并重建分析。
- Reference（`project/references/**`）默认只证构图方法、镜头/空间机制、视觉钩子、色光/材质、信息层级、广告叙事；**不能**自动证明项目角色、品牌、玩法、世界观、剧情或历史正式风格。历史 KV/Banner 要参与“项目实际采用过的视觉语言”综合，必须在 `project/evidence-registry.json` 声明 `evidence_role=historical-project-output` + `provenance` + `authority_scope`；证据角色不清时显式写 `authority_boundary`，不得偷偷补全。

字段与迁移细节见 `references/evidence-roles.md`。

## 2. 构建与刷新流程

```bash
python .agents/skills/wxian-visual-baselines/scripts/baseline_gate.py build-source-manifest --request <request> --workspace-root .
python .agents/skills/wxian-visual-baselines/scripts/baseline_gate.py prepare-analyses --request <request> --workspace-root .
python .agents/skills/wxian-visual-baselines/scripts/baseline_gate.py prepare-aggregation --request <request> --workspace-root .
python .agents/skills/wxian-visual-baselines/scripts/baseline_gate.py publish --request <request> --workspace-root .
python .agents/skills/workspace-governance/scripts/workspace_gate.py complete-internal --request <request> --workspace-root .
```

`publish` 在正常路径只做一次完整 work-tree 专业验证；`validate-aggregation / validate-project-standard / validate-published` 只作显式诊断，不重复执行。`complete-internal` 是 non-Promote completion 唯一 Authority，只 fresh 校验已发布文件与 publication receipt 绑定。发布是整快照替换；Reference/Census、角色/品牌、Source Set、Synthesis Ledger、最终 Baseline 或编码任一失效，正式 Baseline 立即 stale。命令参数、输出字段与错误码**先看 [`baseline-gate-cli.md`](references/baseline-gate-cli.md)（读源码前先看这里）**，再读源码。

Reference ≤100：全部 unique Reference 进发布口径 Census（至少一次真实观察），深度解构按决策所需推进，命中同 source hash 与分析合同的分析直接复用。Reference >100：先对 100% Reference 做轻量 Census（`work/project-visual-standard/reference-census.json`）再按真实视觉差异聚类选代表图；`kv/`、`banner/` 只是存储目录，不能直接成 Cluster；所有 outlier 必须深挖。逐图分析由 `$wxian-visual-reverse-analysis` 完成，只负责观察事实，不负责项目级结论。增量刷新只补变化源与受影响综合。完整规则见 `references/census-and-incremental-refresh.md`。

## 3. 角色与品牌身份

每个 canonical 角色建 `character-profiles/<id>.md` + `character-verifications/<id>.md`，Production Card 至少锁定：脸型/肤色、眼睛/眉形、发型结构/发色分区、体型轮廓、服装大形、主辅色块、关键装备、高辨识细节；卡片完成后重新打开 canonical 原图二次核验，先改卡再验证。有 canonical Logo 时生成 `brand-profile.md`，必须看懂 Logo 本身：品牌名、字标结构、字体造型、色彩/材质、符号、轮廓、保护项、多语言资产关系。`$wxian-project-style-index` 只辅助生成/校验角色卡与 Brand Card，**不负责最终 Baseline 综合**。

## 4. Project Visual Synthesis（主能力）

**先综合，再写 Baseline；不要边看分析边填最终字段。** 内部工作文件：`work/project-visual-standard/visual-synthesis.md`（视觉负责人的综合判断草稿）+ `synthesis-ledger.json`（只负责证据追溯，最终 Baseline 不搬运 ledger）。

六遍顺序固定：Whole-set Gestalt（禁止先建 Family）→ Evidence Matrix（跨图同维度比较，找出跨图关系）→ Candidate Claims（区分度 / 反例 / 一次性因果测试）→ 先 Visual DNA 再拆 Family（Family 只在业务目的或视觉机制有决定性差异时成立，两两做 shared_core / decisive_difference / choose_first_when / do_not_merge）→ 分开 Historical Prior 与 Baseline Floor（高频不等于 Floor）→ Strategic Whitespace（可 `start_family_ids: none`，新方向仍须守项目身份与 Floor）。完整方法、检查问题与拒绝样例见 `references/visual-synthesis-method.md`。

Synthesis Ledger 硬要求：所有正式深度 analysis 都参与至少一条内部 claim（`analysis_participation`）；claim 不能机械近似复制；evidence 与 counterevidence 必须来自真实已分析素材；不确定保留不确定。Schema 见 `references/synthesis-ledger-schema.md`。

## 5. 最终 Baseline 与写作标准

正文结构固定为 Schema 8：`基准定位 / 项目视觉认知 / 当前产出结构 / 跨产出视觉 DNA / 产出差异决策 / 角色与品牌身份 / Baseline Floor / 创新空间 / 一稿校准 / 证据边界与刷新`。Schema 见 `references/project-visual-baseline-schema-v8.md`。

写作要求：读正文就应形成脑内图像；先综合结论再历史 Family；Family 是“历史产出原型”不是 Reference 清单；不复制逐图分析；不写审计/Gate 过程与 `none/fallback/insufficient` 堆叠；不把证据路径数量当专业程度；不把通用原则冒充项目 DNA；不把现有 Family 当未来白名单。

## 6. 发布准出与编码

V8.72 起独立视觉模型 grounding 复核**不是默认发布门禁**：`work/project-visual-standard/grounding-review.json` 存在时只校验结构与源绑定，缺失不影响发布；用户明确要求复核时才按 `references/grounding-review-protocol.md` 执行。发布真正强制的是分析合同完整性（`validate_analysis` 必填章节与 source hash/维度/分析合同版本一致、盲重建字段与正文深度达阈值、Phrase/Prompt 有内容）、跨源反模板化（swap-test / semantic-duplication）、全部正式分析参与 ledger，以及 Schema 8 各节与角色/品牌卡完整。

发布前主 Agent 必须只读最终 Baseline、暂不翻单图分析，回答 30 秒复述、第一稿起点、项目相似度、Family 差异、突破路径五问；答不清即综合失败，只允许带缺口清单回第 4 节重综 1 次，第二次必须绑定新增/修正证据，否则 blocked。检查清单见 `references/publication-contract.md`。

需要重新看原图时用 `scripts/vision_observe.py`（像素坐标裁切、可指定模型、可复现、不打印密钥）；稳定观察合同、裁切规范与同图复用规则见 `references/vision-observation-protocol.md` 与 `references/vision-prompt.md`。同一 `图片 Hash + scope + 提示词 + 模型 + region` 直接复用既有观察；`vision_observe.py report` 给出调用/缓存命中/token 计量。

所有 Workspace 自有文本必须严格 UTF-8：Python `Path.write_text(..., encoding="utf-8")`、JSON `ensure_ascii=False`、原子写入；PowerShell 禁止未声明编码的 `>`/`Out-File`/`Set-Content` 写正式文档。非 UTF-8、BOM、U+FFFD、私有区异常字符、`???` 丢失替换、典型 mojibake 均 BLOCK；禁止“猜着修乱码”后继续发布。详见 `references/encoding-integrity.md`。

## 7. 下游怎么读

下游先读 `project/baselines/index.json`，再读最终 Baseline：项目视觉认知、当前任务相关历史 Family、跨产出 Visual DNA、Baseline Floor、创新空间、目标角色/Brand Card。默认**不读** `synthesis-ledger.json`、Census 和全量单图分析；它们属于证据层，只在核验或细节不足时定向打开。Baseline 的目标是让下游“不从零开始”，不是“只能重复历史”。
