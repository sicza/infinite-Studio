# Inventory → 全量视觉 Census → 深度分析（含增量刷新）

> 时机：首次构建 Baseline、素材新增/替换/删除后的增量刷新、Reference >100 的 Census 与代表图选择时加载。

```bash
python .agents/skills/wxian-visual-baselines/scripts/baseline_gate.py build-source-manifest --request <request> --workspace-root .
```

### Reference ≤100

全部 unique Reference 进入**发布口径的视觉 Census**（至少一次真实观察、身份/类型/语义簇可用），以保证 Baseline 的覆盖率不靠抽样自证。深度解构按当前决策所需推进：先完成真正影响 Baseline 结论的代表与冲突项，其余条目在涉及相关决策时再加深，不必在首次构建时把所有条目都写成等长的完整机制文档。已有分析命中同一 source hash 与分析契约时直接复用。

**增量刷新**：Source Manifest 重建后，未变 source hash 与分析合同的单图分析直接复用；新增 1 张素材只补该素材的分析与受影响的综合，不重跑未变素材；只有 source hash、分析合同版本、证据角色（`evidence_role/provenance/authority_scope`）或项目核心事实变化才向 Baseline 传播。

### 增量刷新流程

素材新增/替换后，先重跑 `build-source-manifest`，并把新增源补进 `source-selection.json`；然后：

```bash
python .agents/skills/wxian-visual-baselines/scripts/baseline_gate.py prepare-analyses --request <request> --workspace-root .
```

它只把没有可复用分析的源放进 `needs_analysis`（未变 source hash 且通过当前分析合同的既有分析直接复用，不发起视觉调用）。只分析这些源，再重建受影响的 `visual-synthesis.md`、`synthesis-ledger.json` 与角色/品牌卡，最后按第 9 节发布。删除素材时同时删除其 work/正式分析，否则集合校验会按 stale 阻断。

### Reference >100

必须先对 **100% Reference** 做轻量视觉 Census：

```text
work/project-visual-standard/reference-census.json
```

Census 的职责不是生成最终结论，而是确保没有任何视觉方向在“完全没被看过”的情况下被忽略。

Cluster 必须来自真实视觉差异：视觉钩子、叙事机制、构图/镜头、色光、角色作用、信息负载；`kv/`、`banner/` 只是存储目录，不能直接成为视觉 Cluster。

然后再按 Cluster 选代表图做深度 Reverse Analysis。所有 outlier 必须深挖。

逐图分析仍由 `$wxian-visual-reverse-analysis` 完成。它只负责**观察事实**，不负责最终项目级结论。
