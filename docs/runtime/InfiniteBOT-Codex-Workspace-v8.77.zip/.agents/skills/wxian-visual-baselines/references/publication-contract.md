# 分析合同、可选复核与一稿校准（发布准出）

> 时机：准备 publish、决定是否做可选专业复核、或执行发布前一稿校准复述检查时加载。

V8.72 起，**独立视觉模型 grounding 复核不是默认发布门禁**。`work/project-visual-standard/grounding-review.json` 是可选证据：存在时只校验结构完整性与源绑定（覆盖当前已选源、`source_sha256` 一致、错误列表为数组），缺失不影响发布；不再要求重建评分 4/5、`reviewer_type=independent-visual-model` 或“复核员必须与观察员不同模型”。记录的复核发现会照实报告，但不阻断发布——发现要么在分析正文中被核对改写，要么按复核协议留痕。

发布前真正强制的是**分析合同完整性与专业综合质量**，取消复核门禁不降低其中任何一项：

- 每张已选源必须通过 `validate_analysis`：必填章节齐全，`## 1. 源绑定` 的 source hash / 维度 / 分析合同版本一致，盲重建相关字段与正文深度、视觉覆盖达阈值，Phrase 与 Prompt 有实际内容；
- 跨源反模板化（swap-test / semantic-duplication）通过；所有正式深度分析都参与 `synthesis-ledger.json` 的 claim 与 `analysis_participation`；
- `visual-synthesis.md` 固定章节、正式 Baseline Schema 8 各节、角色/品牌卡、Floor、创新空间与一稿校准路由完整，UTF-8 编码完整。

**用户明确要求专业复核时**，按 `references/grounding-review-protocol.md` 执行并把结果作为证据留痕；这是可选路径，不改变上面的默认发布代码路径。需要重新看原图（观察或交叉核对）时使用 `scripts/vision_observe.py`（原图像素坐标裁切、可指定模型、输入可复现，且从不打印密钥），观察侧的按素材类型稳定观察合同、裁切规范、失败处理与**同图复用规则**读取 `references/vision-observation-protocol.md` 与 `references/vision-prompt.md`。同一 `图片 Hash + scope + 提示词 + 模型 + region` 会直接复用既有观察而不发起新调用；`scripts/vision_observe.py report` 给出实际调用/缓存命中/网关返回的 token 计量。不要因为换了一个 Skill 就重新整图读取同一张参考图；也不要默认调用多个视觉模型互相评分。

正式发布前，主 Agent 必须只读最终 Baseline，暂时不翻单图分析，回答以下问题：

1. **30 秒项目复述**：这个项目当前视觉上是什么？
2. **第一稿起点**：如果现在做一个典型 KV/Banner，我会优先做哪三个设计决策？为什么？
3. **项目相似度**：什么东西缺失后，结果即使“很好看”也不像这个项目？
4. **Family 差异**：两个主要历史方向到底为何不同，什么 Brief 下不能互换？
5. **突破路径**：如果当前需求与所有历史方向都不匹配，哪些 DNA/Floor 仍需保留，哪些可以完全重做？

如果不能仅凭 Baseline 清楚回答，说明综合失败，**不能靠增加字段或 source_note 过门禁**。只允许携带明确缺口清单回到第 4 节重新综合 1 次；第二次必须绑定新增或修正的 source evidence，否则停止并返回 blocked reason，不继续循环改写。
