# 证据角色：项目产出 vs 参考方法

> 从 SKILL.md 下沉（V8.73 token 整改）。时机：开始综合前判断每类证据能证明什么、处理道具历史目录 `project/props/**` 迁移、或为历史 KV/Banner 声明 evidence role 时加载。

在开始综合前，先判断每类证据能证明什么。

### Canonical / Project Evidence

可以证明项目自身事实：

- `project/assets/characters/**`：角色身份；
- `project/assets/props/**`：道具/物件身份（含被角色使用的工具、装置、载具部件等）。道具图只证明该物件的结构、配色与使用方向，不证明稀有度、性能或获取规则；文件名里出现角色名不改变它的分类，道具不会被当作角色资产。**规范位置唯一 = `project/assets/props/`**：新素材一律放这里。`project/props/**` 是先于规范目录存在的**历史位置**——为不让项目已记录的素材被误判，Runtime 仍把它**按 props 分类**（不会变成角色），但会**明确报出迁移要求**（`props_location_report` 出 `migration_required` 与逐文件目标路径），不再静默容忍；发现非规范位置的道具时，应把文件移到规范目录并重建该 request 的选择与 Baseline。
- `project/assets/logos/**`：品牌身份；
- `project/assets/game-screenshots/**`、`project/assets/other/**`：游戏内画面与其他正式项目资产。
- 项目真实截图、历史正式 KV/Banner、游戏内画面、官方美术资产：如果它们被明确标记为项目正式产出，可以证明“项目过去真正长什么样”。

Canonical 目录由 `.agents/lib/asset_taxonomy.py` 唯一定义；`characters` 与 `props` 的正式资产必须全部进入深度分析与合成账本。道具身份在合成账本中使用合法的 `claim_type: asset-identity`。

### Reference

`project/references/**` 默认只能证明：

- 构图方法；
- 镜头与空间机制；
- 视觉钩子；
- 色光/材质手法；
- 信息层级；
- 广告叙事机制。

Reference **不能自动证明**：项目角色、品牌、玩法、世界观、官方剧情、历史正式风格。

`project/references/**` 只是默认存储位置，不等于 Evidence Authority。历史项目 KV/Banner 若要参与“项目过去实际采用过什么视觉语言”的综合，必须在 `project/evidence-registry.json` 声明 `evidence_role=historical-project-output`、`provenance` 与 `authority_scope`；未声明的 Reference 仍只能作为外部方法参考。

### 关键失败视角

如果项目历史真实 KV 被错误地只当 Reference 保存，那么 Baseline 只能把它理解成“可借鉴方法”，不能把它当“历史项目产出”。遇到这种证据角色不清时，Baseline 必须显式写明 `authority_boundary`，不得偷偷补全。
