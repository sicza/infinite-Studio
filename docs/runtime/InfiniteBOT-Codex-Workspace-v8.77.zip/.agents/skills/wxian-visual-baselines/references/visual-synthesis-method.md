# Project Visual Synthesis｜六遍综合方法

> 时机：执行本 Skill 主能力（先综合再写 Baseline）、建立 Gestalt/Evidence Matrix/Candidate Claims/Visual DNA/Family/Floor/Whitespace 时加载。

这是本 Skill 的主能力。**先综合，再写 Baseline；不要边看分析边填最终字段。**

生成内部工作文件：

```text
work/project-visual-standard/visual-synthesis.md
work/project-visual-standard/synthesis-ledger.json
```

`visual-synthesis.md` 是视觉负责人自己的综合判断草稿；`synthesis-ledger.json` 只负责证据追溯。最终 Baseline 不搬运 ledger。

## 4.1 第一遍：建立 Whole-set Gestalt｜整体视觉印象

先看完整证据集合，不分 Family，回答：

1. 如果只给我 10 秒，这个项目当前视觉上最像什么？
2. 它的画面通常在解决什么传播问题：角色展示、危机、玩法目标、活动氛围、情绪叙事、品牌包装，还是其他？
3. 第一视觉通常是什么？第二视觉通常是什么？
4. 人物、环境、威胁、道具、UI、标题、Logo 的优先级通常怎么排？
5. 哪些视觉信号一出现就明显提高“像这个项目”的概率？
6. 哪些东西虽然常见于同类游戏，但在这个项目证据里并不稳定？
7. 当前项目的质量特征到底体现在哪：人物完成度、材质、空间、打光、信息控制、情绪、特效、品牌包装中的哪些组合？

这一阶段**禁止先创建 Family**。否则模型会先分类，再强迫所有证据适应分类。

## 4.2 第二遍：建立 Evidence Matrix｜跨图比较矩阵

对完整证据按同一组视觉维度横向比较，而不是逐张复述：

- 业务目的 / 商业命题；
- 第一视觉钩子；
- 主体类型与主体占比；
- 人物在叙事中的角色；
- 环境承担的作用；
- 镜头距离 / 高低机位 / 透视强度；
- 前中后景组织；
- 明暗结构 / 冷暖关系；
- 材质与细节密度；
- 特效、烟尘、粒子使用量；
- 标题、Logo、UI、安全区与留白；
- 情绪强度；
- 缩略图第一读点；
- 可复用机制与不可继承内容。

目标是找出**跨图关系**：哪些东西经常一起出现，哪些互相排斥，哪些只在特定业务场景成立。

## 4.3 第三遍：提出 Candidate Claims｜候选项目结论

每条项目级结论必须先进入 `synthesis-ledger.json`，并通过三个测试：

### A. 区分度测试｜Differentiation Test

问：

> 把项目名换成另一个同类游戏，这句话是否仍几乎原样成立？

如果答案是“是”，它不是合格的项目 Visual DNA。

例如以下通常应被拒绝：

- “画面要有冲击力”；
- “角色要清晰”；
- “构图要有层次”；
- “色彩要统一”；
- “电影感强”；
- “第一视觉明确”。

必须继续追问：**这个项目具体通过什么方式做到？组合关系是什么？在什么任务里成立？**

### B. 反例测试｜Counterexample Test

主动找不符合该结论的历史证据。

如果大量反例存在：

- 缩小 scope；
- 从 `stable-prior` 降为 `situational`；
- 或删除该结论。

禁止为了形成“统一风格”而抹平真实差异。

### C. 因果测试｜One-shot Causal Test

问：

> 这条结论具体会改变下一次第一稿的哪个设计决策？

如果它不能改变：主体选择、镜头、构图、色光、信息层级、人物角色、品牌位置、细节预算或质量判断中的任何一项，它对 Baseline 没有实际价值。

每条 ledger claim 必须说明 `one_shot_effect`。

## 4.4 第四遍：先形成项目 Visual DNA，再拆当前产出 Family

顺序必须是：

```text
整体视觉认知
→ 跨图稳定关系
→ 项目 Visual DNA
→ 再判断历史产出中有哪些真正不同的 Family
```

不是：

```text
先 Cluster
→ 每个 Cluster 填一套相同字段
→ 把它们叫 Family
```

Family 只有在**业务目的或视觉机制存在决定性差异**时才成立。

每两个主要 Family 都要做横向比较：

- shared_core：它们共享什么项目 DNA；
- decisive_difference：真正决定它们不是同一个方向的差异；
- choose_first_when / choose_second_when：什么 Brief 下优先选哪一个；
- do_not_merge：什么东西不能平均化，否则两边都失去价值。

如果两个 Family 的构图、镜头、色光、人物作用、信息层级描述几乎一样，只是名字不同，**合并或重新划分**。

## 4.5 第五遍：把“常用”与“底线”彻底分开

### Historical Prior

代表：

> 历史证据中高频成立，默认从这里起稿更容易命中。

可以包括：某类主体、构图、镜头、色光、信息密度、人物/环境关系。

### Baseline Floor

只有“低于它就明显不像项目、身份错误、品牌错误或不可交付”的要求才能进入 Floor。

高频不等于 Floor。某个构图出现 70% 也不意味着新需求必须这样构图。

## 4.6 第六遍：明确 Strategic Whitespace｜创新空间

综合历史覆盖后，明确：

- 哪些视觉方向已经成熟；
- 哪些只是证据不足，不应误判成禁区；
- 哪些新镜头 / 色光 / 叙事 / 材质 / 空间机制值得探索；
- 当前 Brief 如果与历史 Family 不匹配，可以 `start_family_ids: none`。

创新不是“随便做”。新方向仍然必须保持项目身份、角色/品牌事实和 Baseline Floor。
