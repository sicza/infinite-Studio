# `baseline_gate.py` 命令参考（读源码前先看这里）

> 从 SKILL.md 下沉（V8.73 token 整改）。**先看本页，不要整读 `scripts/baseline_gate.py`。** 只有本页没有的字段/行为才用 `--help`、`rg -n` 精确查，并只读命中行段。

入口：`python .agents/skills/wxian-visual-baselines/scripts/baseline_gate.py <subcommand> [--request <r>] [--workspace-root .]`

## 子命令

| 子命令 | 作用 | 参数 |
|---|---|---|
| `build-source-manifest` | 重建 Source Manifest（素材新增/替换后先跑） | `--request` |
| `prepare-analyses` | 只把没有可复用分析的源放进 `needs_analysis` | `--request` |
| `validate-inventory` | 校验素材清单 | `--request` |
| `validate-single-analysis` | 校验单图逆向分析（必填章节、源绑定、盲重建深度） | `--request` |
| `validate-grounding-review` | 可选复核证据的结构与源绑定（缺失不阻断发布） | `--request` |
| `prepare-aggregation` | 聚合前准备（清点待综合分析） | `--request` |
| `validate-aggregation` | 显式诊断：综合集校验 | `--request` |
| `validate-project-standard` | 显式诊断：最终 Baseline Schema 8 校验 | `--request` |
| `publish` | 正常发布：唯一一次完整 work-tree 专业验证 + 整快照替换 | `--request` |
| `validate-published` | 显式诊断：已发布文件与 receipt 绑定 | `--request` |
| `self-test` | 自测 | 仅 `--workspace-root` |
| `doctor` | 排障（显式命令，不在 hot path） | 仅 `--workspace-root` |

全部子命令接受可选 `--workspace-root`（默认当前目录）。权威发布序列：`build-source-manifest → prepare-analyses → prepare-aggregation → publish → workspace_gate.py complete-internal`；`validate-*` 只作显式诊断，不在正常序列重复执行。

## 输出与退出码

- 成功/进行中：stdout 打印一个 JSON 对象，含 `status` 与上下文计数（如 `source_count`、`inventory_count`、`selected_count`、`needs_analysis`、`reused`、`manifest`、`family_count`、`character_profiles`）。
- `status` 取值：`ready` / `built` / `passed` / `published` / `ready_for_aggregation` / `needs_selection` / `needs_reference_census` / `blocked`。
- 失败：`{"status":"blocked","reason":"..."}`，进程退出码 `1`；`doctor` 也返回 0/1。
- 没有 `error_code` 字段；按 `reason` 定位，修真实事实后**重跑同一命令**，不要连跑整条链。

## 常见 `reason` 走向

- `needs_selection` / `needs_reference_census`：先补 `source-selection.json` 或 Census，再重跑。
- 删除素材后集合校验 stale：同时删除其 work/正式分析，再重跑。
- 发布 stale：Reference/Census、角色/品牌、Source Set、Synthesis Ledger、最终 Baseline 或编码任一失效都会使正式 Baseline stale；重新 `publish` 整快照。
