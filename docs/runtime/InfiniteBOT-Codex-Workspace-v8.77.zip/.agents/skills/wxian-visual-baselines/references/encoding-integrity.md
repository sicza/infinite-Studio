# 编码完整性（UTF-8 发布契约）

> 时机：写 Baseline 文本/JSON、排查 BOM 或 mojibake、发布前编码检查时加载。

所有 Workspace 自有文本必须是严格 UTF-8。不要依赖 Windows 当前代码页。

### 写文件

优先：

- Python `Path.write_text(..., encoding="utf-8")`；
- JSON 使用 `ensure_ascii=False`；
- 原子写入后替换目标。

在 PowerShell 中禁止使用未声明编码的 `>` / `>>` / `Out-File` / `Set-Content` 生成正式 Markdown/JSON。若必须通过 PowerShell 写文本，必须显式使用无 BOM UTF-8；无法保证时改用 Python。

### 发布前

`baseline_gate` 会对 Baseline work tree 与 published tree 做严格检查：

- 非 UTF-8 → BLOCK；
- UTF-8 BOM → BLOCK；
- U+FFFD replacement character → BLOCK；
- 私有区异常字符 → BLOCK；
- `???` 等丢失替换 → BLOCK；
- 典型 UTF-8↔GBK mojibake 片段（原 UTF-8 汉字被按 GBK 误读后形成的乱码串）→ BLOCK。

**禁止自动“猜着修乱码”后继续发布。** 乱码说明上游语义已经不可证明，必须从原始内容重新写入 UTF-8。
