# 单图分析复核（grounding review）｜可选专业证据

适用于：用户明确要求专业视觉复核，或团队主动用第二个观察/复核模型交叉核对单图分析与原图是否一致。
见 SKILL.md 第 7 节。

## 0. 定位：证据，不是默认发布门禁

- V8.72 起，独立视觉模型 grounding 复核**不是默认步骤**：没有 `grounding-review.json` 不阻断发布。
- 视觉模型只服务 Baseline 必要观察、用户明确要求的参考/诊断、后处理空间定位；不负责最终审美验收。
- **同一分析合同不默认多模型互评。** 是否复核由用户明确要求、证据冲突或高风险判断决定，不由流程强制。
- 复核发现不是“评分”而是**待核对线索**：要么核对后改写分析正文，要么按第 4 节留痕驳回。它不替 Human 做最终作品质量判断。

## 1. 机器合同（只在文件存在时校验）

canonical 路径：`work/project-visual-standard/grounding-review.json`。

文件存在时，`baseline_gate.py` 只校验结构完整性与源绑定：

- `schema_version: 1`；
- `sources` 为数组，覆盖当前 Source Manifest 的每个已选源**恰好一次**；
- 每行 `source_path` 在 Manifest 内且唯一，`source_sha256` 与 Manifest 完全一致；
- 六个发现列表（`omitted_objects` / `wrong_objects` / `spatial_errors` / `action_errors` / `ui_errors` / `light_errors`）**若出现**必须是数组；
- `decision` 若出现必须是非空字符串。

V8.72 取消的判据（不要再写成发布条件）：

- ~~复核员必须与观察员不同模型~~ → 不同模型是可追溯性建议，不是强制；
- ~~`reviewer_type=independent-visual-model`、`reviewer_id`、`method` 必填~~ → 建议记录以便追溯，但不校验；
- ~~`decision` 必须为 `pass`~~ → 只记录，不阻断；
- ~~重建评分不得低于 4/5~~ → 无评分阈值；`reconstruction_score` 可作为证据保留；
- ~~六个错误列表必须为空~~ → 有发现照实记录即可，按第 3/4 节处置。

复核记录中的发现会出现在 `validate-grounding-review` / `publish` 的输出里（`grounding_flagged_count`），但**不阻断**。真正防止质量下降的是分析合同本身（必填章节、源绑定、盲重建字段、正文深度与覆盖、跨源反模板化）和项目级综合检查。

## 2. 什么时候值得做（可选触发条件）

- 用户明确要求“专业复核 / 独立审图 / 盲重建评分”；
- 某条分析结论将进入 High-risk Floor、身份卡或品牌保护项；
- 观察模型自身可能偏差（左右手、光源方向、对象认错、结构认错）；
- 多源综合发现异常 outlier，或分析结论与可见事实冲突。

不满足以上条件时，通常不需要第二个视觉模型：用分析合同校验 + 按 `vision-observation-protocol.md` 直接裁切复核即可。

## 3. 复核方法（专业方法保留）

### 3.1 输入

- 逐源比对**原图**与分析的**完整正文**。送入前不得截断——截断会把长分析误报成 `omitted_objects`（已实测踩过）。
- 提示词必须包含四条约束，缺一条都会显著抬高误报：
  1. 每条问题必须指出**画面位置**并标注置信度，只保留 high；给不出位置或置信度不足的不写入。
  2. 分析正文**已经提到**该对象（即使措辞不同）不得写入 `omitted_objects`。
  3. 分析中**已声明为不确定或不可辨读**的内容不算错误。
  4. 只报告影响可重建性的事实差异，忽略文风、用词与细节颗粒度差异。

### 3.2 模型选择

- 用户指定复核模型时优先遵从；
- 未指定时，选择“同输入多次运行结果稳定”的多模态模型。2026-09 实测：强推理型多模态模型条目具体、可核查但发散；轻量小模型多次运行波动可达 0~7 条，**不适合作为复核员**；
- 与观察员使用不同模型有助于降低共同偏差，建议记录实际模型 id，但**不是强制条件**。

### 3.3 轮次预期

可选复核路径不会快速收敛。实测（同一批次 40 源分析，复核员为强多模态模型，每轮修正后重跑）：

| 轮次 | flagged 源数 | 说明 |
|---|---|---|
| 第 1 轮 | 25 | 揭出 190+ 处真实错误的第一批 |
| 第 2 轮 | 18 | 逐条核对并改写分析后重跑：上轮问题源清零，新条目出现且与上轮不重复 |
| 第 3 轮 | 18 | 同上 |
| 第 4 轮 | 17 | 同上，评分全部 5.0 |

结论：分析文本是概括性的，穷尽式比对永远能找到未提及的细节。**若决定走复核路径，就预留足够轮次**，把每轮意见当作待核对的具体线索，逐条看图核对后改写分析正文；不要因为 flagged 数没归零就放弃，也不要用批量裁定把列表清空。

## 4. 处置顺序（复核路径内的唯一合法路径）

对每一条被标记的项：

1. **先看图核对**：按 `vision-observation-protocol.md` 的裁切规范复核该条所指位置，必要时用 `scripts/vision_observe.py` 裁切重看。
2. 核对属实的差异 → **改写分析正文本身**。这是绝大多数情况的正确处置；实测 190+ 处修正都走这条路，其中包含观察模型自己写下的错误（光源方向、左右手、对象认错、结构认错）。
3. 核对不属实的（例如独立裁切观察一致支持原表述）→ 可以驳回该条，但**必须留下可被第三方复核的证据**：
   - 保留复核员的原始条目（写进该源的 `method` 字段或附注段落，不要删除）；
   - 写明驳回依据：哪个观察记录、哪个模型、哪次裁切、结论是什么；
   - 给不出这样的独立证据 → 不得驳回，继续核对或在报告中保持 open。
4. 无法核实的（原图损坏、无法复看、分辨率不足）→ 不得清空，保持 open 并如实记录。

机器校验只检查结构；**驳回的正当性由留痕与人复核承担，不由脚本承担**。最终报告不得把“机器校验通过”表述成“每条发现都已被机器验证”。

## 5. 留痕要求（不新增机器契约）

- 原始条目与驳回依据写进**现有字段**（`reviewer_id` / `method` / 各源附注段落的既有语义）内。
- **不要发明没有消费者的新字段**：没有脚本会校验它，写进去只会制造“看起来有机制”的假象。若确需结构化记录，先确认有真实消费者，否则按文本留痕处理。
- 若认为某个判据本身应该机器化，那是机器契约变更，必须连同 Gate 与其回归一起提出，不能只写进 Reference。
- 复核结果按轮次另存副本（含被替换模型的旧结果），文件名带模型与轮次，例如 `grounding-review-<model>-roundN.json`。理由：驳回依据引用的是某轮具体条目，覆盖后依据会变成悬空引用。
- canonical `grounding-review.json` 如果保留，必须覆盖当前已选源全集；只覆盖部分源的复核记录使用归档文件名，不要占用 canonical 路径。

## 6. 模型间分歧的定夺规则

1. **裁切复核**优先于整图印象。
2. **两个独立观察一致** > 单个模型重复断言（实测「犬姿态」：两个独立模型的裁切观察判趴卧，复核员三次判坐姿 → 判复核员误报）。
3. **原始观察记录**（未被争议引导时写下的描述）权重高于争议后产生的描述。
4. 定稿后在分析正文给出**单一明确结论**，不允许用「卧／坐」这类含糊表述回避。

## 7. 修正落地后的连锁动作（容易漏）

1. 重跑 `prepare-aggregation`（重建索引与 cross-source 反模板化检查，并刷新 `aggregation-evidence.json` 中的 grounding 证据 hash）；
2. 若改的是**角色卡分析**，同步 `character-profiles/*.md` 与 `character-verifications/*.md` 绑定的 `analysis_sha256`（gate 会校验，不同步会失败）；
3. 再跑 `publish` → `validate-published`；`validate-grounding-review` 仅作显式诊断，不在发布序列中重复执行。

## 8. 验收（可选路径）

结构自检：

```bash
python -X utf8 - <<'PY'
import json, pathlib
W = pathlib.Path("<work>/project-visual-standard")
path = W / "grounding-review.json"
if not path.is_file():
    print("grounding-review.json absent: optional evidence, publish is not blocked")
else:
    payload = json.loads(path.read_text(encoding="utf-8"))
    print("sources:", len(payload.get("sources", [])))
PY
```

或直接运行只读诊断：

```bash
python -X utf8 .agents/skills/wxian-visual-baselines/scripts/baseline_gate.py \
  validate-grounding-review --request <request> --workspace-root .
```

它返回 `grounding_review: not-provided`（缺失，不阻断）或 `grounding_review: validated`（含发现计数，不阻断），并校验源覆盖与 hash 绑定。**它不检查第 4 节的核对与留痕是否真的做过**——那部分由人复核。
