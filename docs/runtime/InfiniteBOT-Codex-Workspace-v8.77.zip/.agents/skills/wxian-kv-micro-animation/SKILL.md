---
name: wxian-kv-micro-animation
description: 把静态 KV、海报、Banner、商店图重构为 5 秒 Seedance 2.0 剧情微动画设计与完整 Prompt；真实视频生成由 wxian-image-production 执行。
---

# KV 微动画

进入前执行 `$workspace-governance consume-personal-context --request <request> --consumer wxian-kv-micro-animation`；阻断则停止。

把静态 KV 当成一个被冻结的 **Dramatic Keyframe**。目标不是加零散微动，而是：读懂这一瞬间的状态与因果 → 用最小 request-local Narrative Contract 闭合状态变化 → 判断它在 5 秒故事里的时间位置 → 由视觉导演设计可见表演、空间、镜头和成像 → 编译成可直接给 Seedance 2.0 使用的完整自然语言 Prompt。

本 Skill 保持 5 秒微动画的专业编排与交付 Authority；`$sicza-causal-narrative-runtime` 只解决事件/状态/角色知识/物体连续性，`$sicza-visual-director` 只解决这些事实如何被看见；最小接入见 `references/narrative-visual-integration.md`。**KV 是故事证据，不自动等于视频首帧，也不自动等于高潮或尾帧。**

## Workspace 接入

可作为独立 primary request，也可作 `$wxian-image-production` 的视频前置专业能力；调用方必须明确 `execution_mode`：`prompt_only | production_video`。

- **`prompt_only`**（只要 5 秒微动画剧情设计 / Seedance Prompt）：本 Skill 为 primary；完成后写 `work/final/micro-animation.md`、`work/final-review.md`、`work/delivery-manifest.json`，由 `$workspace-governance promote` 发布。
- **`production_video`**（要真实视频文件）：`$wxian-image-production` 为 primary。本 Skill 一次完成静态 KV 读图、剧情、时间位置、镜头策略、素材角色与 Seedance Prompt，写入调用方 `work/micro-animation/` 后立即返回生产 Skill 继续 API；中途不加用户确认。
- 项目 Workspace 必须消费当前正式 Baseline 的角色/品牌身份与最低线；Baseline 是项目先验和底线，不是剧情上限；当前 KV 的真实可见事实优先于历史视觉先验。独立 `prompt_only` request 的 canonical Baseline receipt 固定为 `work/baseline-consumption.json`，machine key=`kv-micro-animation`；作为 image-production 前置时沿用调用方 `image-production` receipt，不另建第二份 Baseline Authority。

## 适用范围与输入

适用：静态 KV / 海报 / 商店图 / Banner → 5 秒剧情微动画；“让这张图动起来但要有完整故事”；补全这一帧之前/之后发生了什么；从 KV 继续发展到新高潮；写 Seedance 2.0 图生视频 / 微动画 Prompt。不适用：与现有 KV 无关的从零视频创作、长视频/多场景/多镜头脚本、只要 Live Photo 或循环微动、泛用 Seedance 教程。

必需 1 张可读取的静态 KV；默认 5 秒、单段连续叙事镜头、未指定画幅时沿用源 KV 宽高比且不追问、原 KV 的角色/资产身份/场景/世界观与整体美术是视觉基线、最终输出完整自然语言 Prompt（不输出精简版）。可选：目标画幅、使用场景、剧情倾向、镜头自由度。**没有图片时停止，不猜图。**

## Core Workflow

**Phase 1 — READ**（`references/kv-reading.md`）产出 `OBSERVED / INFERRED / UNKNOWN`、`SOURCE_ASPECT_RATIO`、`ASSET_INVARIANTS`、`KV_STATE`、可见前因/后续线索与戏剧变化潜力；此阶段不写剧情。

**Phase 2 — POSITION**（`references/timeline-placement.md`）确定 `DRAMATIC_POSITION`、`KV_TIME_PLACEMENT`（START / PASS_THROUGH / END）、`KV_TARGET_WINDOW`（PASS_THROUGH）、`END_MODE`（END：PEAK_END / RESOLVED_END）；再读 `references/reference-binding.md` 生成与 Placement 一致的 `REFERENCE_ROLE`。

**Phase 3 — RECONSTRUCT**（`references/narrative-reconstruction.md`）内部至少 3 个真正不同的 Story Candidate，每个建立 `PRIMARY_DRAMATIC_CHANGE / VIDEO_START_STATE / PRE_KV_STATE / KV_STATE / POST_KV_STATE / Trigger / Development / Escalation / Climax / Final State`；先过 **KV Causal Integration Gate**，再比较叙事强度与 Seedance 可执行性。非典型题材或无法定义升级方式时读 `references/dramatic-change-patterns.md`（常见模式，不是封闭分类）。

**Phase 3.5 — NARRATIVE / VISUAL CONTRACT** 读 `references/narrative-visual-integration.md`：对胜出 Candidate 建立最小状态变化链；存在实质 Narrative State Delta 时调用 `$sicza-causal-narrative-runtime` 的必要模块并由 R09 生成叙事—视觉合同。随后调用 `$sicza-visual-director`，把合同或已锁静态事实写入唯一 `work/visual-spec.json`（`task_kind=motion`）并机器验证。Seedance Prompt 编译后按 `config/visual-contracts/visual-enforcement-profiles.json` 对当前 request 的适用级别处理 `work/prompt-binding.json`（该 profile 为 `optional`：存在时绑定 Prompt Pack 并机器验证，不存在不阻断；不得写成无条件必生成）。Prompt 阶段不得重新发明故事、相机逻辑或角色关系。

**Phase 4 — CONTINUITY**（`references/continuity-control.md`）检查：Asset Identity 全程稳定；Pose/State 可变化但每次变化有合法路径；START 不重演 0 秒已成立的动作；PASS_THROUGH / END 能从前置状态自然形成 KV；人脸身份稳定但表情与身体表演不被锁死。

**Phase 5 — CAMERA**（`references/camera-freedom.md`）在 Level 1/2/3 选最合适镜头自由度。`production_video`：直接锁定推荐 Level 进入 Phase 6，用户已指定则按用户值；`prompt_only`：用户已指定则直接执行，未指定先由 Skill 自行收敛，只有该选择确实会改变交付设计且无法从现有事实判断时才询问一次，不设中间确认节点。只有无法判断且会改变核心剧情/素材角色的事实缺口才阻塞。

**Phase 6 — DIRECT**：0–1s 起势/建立变化；1–3s 事件与戏剧张力明显升级；3–5s 进入高潮区并推进到最终动作落点。这是节奏骨架不是动作模板；“升级”必须来自当前故事的 `PRIMARY_DRAMATIC_CHANGE`（动作、距离、揭示、关系、情绪、系统激活、空间打开、产品功能、环境变化等），不得默认战斗化。高潮遵循 **One Dramatic Climax + Multiple Synchronized Payoffs**：一个主戏剧高潮，人物表演/资产动作/环境/光效/镜头在同一因果下同步兑现。

**Phase 7 — AUDIT** 先跑主规则自检；发现风险时读 `references/failure-patterns.md` 与 `references/failure-fallback.md`（Hard Fail 清单：故事无法自然生成/经过当前 KV State、KV State 与 Video Start State 混淆、Reference Role 与 Placement 冲突、关键资产无来源出现/消失/换身份、多个不相关主事件并行、只有元素微动没有事件因果、为稳定压成动态壁纸、非战斗题材无依据战斗化、末段无理由提前泄力或机械摆回 KV）。失败则内部重写，不输出失败版本。

**Phase 8 — COMPILE**（`references/seedance-prompt-compilation.md`）从已锁 Narrative/Visual Spec 编译：输出规格与 Reference Binding → Protected Truth / Asset Identity / State Continuity → Performance、Blocking、Contact、Gaze（适用时）→ 0–1/1–3/3–5 连续状态变化 → Camera Geometry/Motion/Composition 与空间可读性 → Lighting/Material/Atmosphere/Image Formation 连续变化 → Primary Dramatic Change 与一个主高潮的同步兑现 → Perception Hierarchy、项目身份与本图特有失败预防 → 只保留当前任务必要的模型指令，不复制方法论。

**Phase 9 — LINT**：5 秒内发生一件完整可读的事；有起势、明显升级、主戏剧高潮；KV 时间位置与素材参考角色明确；KV 与故事因果自然整合而非硬塞时间轴；Asset Identity 稳定、State Transition 连续；人物不因“稳定”失去表情与表演；镜头符合已锁 Camera Level；结尾符合 START / PASS_THROUGH / END 逻辑；Prompt 可直接复制使用。

## Hard Rules

1. KV 是一个静态故事瞬间，不是默认首帧、尾帧或高潮。2. Asset Invariants 与 KV State 必须分开；锁身份，不锁死姿态。3. Dramatic Position、KV Time Placement、KV Target Window 是不同决策。4. START 才允许 Video Start State = KV State。5. PASS_THROUGH / END 必须能从前置状态自然形成 KV。6. 任何候选都必须通过 KV Causal Integration Gate：故事必须能因果连续地解释并生成/经过这张 KV。7. “这张 KV 为什么值得被定格”是 Hero/Peak/广告主视觉的质量加分项，不是所有普通过渡瞬间的硬门禁。8. PRIMARY_DRAMATIC_CHANGE 用自然语言定义；Common Driver Patterns 只是参考，不是枚举。9. 一个主事件、一条主因果链、一个主戏剧高潮；允许多个同步视觉兑现。10. 不要为了稳定牺牲剧情张力。11. 不凭空增加核心角色、核心道具或改写核心世界观。12. Reference Role 必须与 Placement 一致；END/PASS_THROUGH 不得误绑定成起始状态。13. 用户未指定画幅时沿用源 KV 比例，不追问。14. 真实视频生产由 Skill 自动锁定镜头自由度；Prompt-only 默认同样自行收敛，只有无法判断且会改变设计时才询问一次 Camera Level，不作为必经确认节点。15. 最终交付必须是完整自然语言 Prompt。

不要做的（完整清单见 `references/anti-patterns.md`）：不把 KV 默认当首尾帧或高潮；不把锁资产身份写成全程锁死姿态表情；不为稳定压成动态壁纸；不只写头发/火焰/粒子/布料/光效/镜头推拉；不无依据加敌人/攻击/爆炸/追逐/新角色；不让多角色各演各的；不让道具凭空出现消失穿模换归属；不在 END/PASS_THROUGH 把 KV 误写成起始态；不最后机械摆回 KV；不把方法论复制进 Prompt。最终输出结构与模板见 `references/output-template.md`（只保留剧情设计、Seedance 素材使用、完整 Prompt 三段）。

## Reference 加载索引

首次进入对应阶段时读取，不一次性预读；返修只重读实际回退阶段及其下游变化的 Reference。

- 接入叙事/视觉合同 → `references/narrative-visual-integration.md`
- Phase 1 读 KV → `references/kv-reading.md`
- Phase 2 → `references/timeline-placement.md` + `references/reference-binding.md`
- Phase 3 重构事件 → `references/narrative-reconstruction.md`
- Phase 4 连续性 → `references/continuity-control.md`
- Phase 8 编译 Prompt → `references/seedance-prompt-compilation.md`
- 条件：Camera Gate 或重判镜头预算 → `references/camera-freedom.md`；无法定义“这 5 秒什么在变化” → `references/dramatic-change-patterns.md`；Audit 风险或反复失败 → `references/failure-patterns.md` + `references/failure-fallback.md`；需要参考推导方式 → `references/examples.md`；交付正文 → `references/output-template.md`；反模式自查 → `references/anti-patterns.md`。
- 评估：达尔文评分或回归测试用 `test-prompts.json`，它只验证 skill 效果，不参与正常用户任务输出。

Reference 是专业判断的单一事实源；SKILL.md 只定义流程与不可违反的总规则，不在 SKILL.md 复制第二套细则。
