# Output Contract（微动画设计 / Seedance 素材 / 完整 Prompt 三段式）

> 时机：写最终交付正文时加载；最终输出只保留该结构，不展示内部事实表、状态图、候选比较与 Audit。

正常最终输出只包含以下结构，不展示内部事实表、状态图、候选比较和 Audit：

```markdown
## 微动画设计
- **剧情核心：** 5 秒完整发生了什么
- **主戏剧变化：** 这一段里什么在持续增强/完成/兑现
- **KV 戏剧位置：** Opening / Mid-story / Peak / Ending
- **KV 时间位置：** Start / Pass-through / End
- **高潮：** 主戏剧高潮
- **镜头：** 已锁定的 Level + 实际策略

## Seedance 素材使用
- **输出画幅：** 源比例或用户指定比例
- **KV 参考角色：** Start Visual / Story Keyframe / Final Visual Target

## Seedance 2.0 完整提示词
[完整自然语言 Prompt，可直接复制使用]
```
