# Hard Fail、Failure Fallback 与一线修复

> 从 SKILL.md 下沉（V8.73 token 整改）。时机：Phase 7 AUDIT 发现风险、候选反复失败、需要一线修复与兜底动作时加载。

## Phase 7 Hard Fail

Hard Fail：
- Story Candidate 无法自然生成/经过当前 KV State
- KV State 与 Video Start State 混淆
- Reference Role 与 Placement 冲突
- 关键资产无来源出现/消失/换身份
- 多个互不相关主事件并行
- 只有元素微动，没有事件因果
- 为求稳定把剧情压成动态壁纸
- 非战斗题材被无依据战斗化
- 最后一段无理由提前泄力或机械摆回 KV

失败则内部重写，不输出失败版本。

## Failure Fallback Table

Failure Fallback Table

| 触发条件 | 一线修复 | 仍失败兜底 |
|---|---|---|
| 没有可读取图片 | 停止并要求用户提供 KV | 不猜图、不写通用 prompt |
| 无法判断 `SOURCE_ASPECT_RATIO` | 从实际文件尺寸或用户上传信息读取 | 仍不可读则要求重新上传图片 |
| Candidate 无法自然生成/经过 `KV_STATE` | 淘汰该 Candidate；Phase 3 每轮生成 3 个新候选，总计最多 2 轮 | 第二轮必须改变已记录的因果假设；同类失败仍复现则停止并返回缺失条件，不继续生成 |
| `KV_TIME_PLACEMENT` 与 `REFERENCE_ROLE` 冲突 | 回到 Phase 2 重判 Placement，再重跑 `reference-binding.md` | 不输出混合绑定版本 |
| START 方案重新执行 0 秒已成立动作 | 改为从 KV 当前状态继续发展 | 若必须补前因，则改判 PASS_THROUGH / END |
| PASS_THROUGH / END 一开始复制 KV | 重建 `VIDEO_START_STATE` 与 `PRE_KV_STATE` | 无法建立连续路径则淘汰该 Placement |
| 关键道具凭空出现/消失 | 回到 Phase 4 建立道具归属和进入路径 | 无法建立路径则删掉该动作设计 |
| Primary Change 变成战斗/爆炸偏置 | 读取 `dramatic-change-patterns.md`，用当前画面证据重定义变化 | 非战斗题材禁止无依据引入敌人/攻击 |
| 只有头发、火焰、粒子、镜头微动 | 回到 Phase 3 重建事件因果和高潮 | 不能补出事件时停止输出，说明 KV 缺少可用戏剧线索 |
| Camera Level 导致空间关系丢失 | 降一级镜头自由度并重写 Camera Direction | 仍不稳定则锁 Level 1 |
| Prompt 变成补丁墙 | 回到 Phase 8 做 Selective Compilation | 删除与当前图无关的防错条款 |
