# `workspace_gate.py` 命令参考（读源码前先看这里）

> 从 SKILL.md 下沉（V8.73 token 整改）。**先看本页，不要整读 `scripts/workspace_gate.py`。** 只有本页没有的字段/行为才用 `--help` 或 `rg -n` 精确查。

入口：`python .agents/skills/workspace-governance/scripts/workspace_gate.py <subcommand> [...] --workspace-root .`

## 子命令与参数

| 子命令 | 关键参数 | 说明 |
|---|---|---|
| `init-request` | `--request <内部路径>` 或 `--request-type <type>`；`--demand-label`、`--demand-title`、`--primary-skill`、`--request-text` | 新建 request；用户目录由脚本按 `requests/<type>/【YYYYMMDD】NN-类型-标题/` 生成 |
| `resolve-request` | 无 request 参数 | 继续当前未完成需求 |
| `resolve-latest` | 无 request 参数 | 定位刚真实 promoted 的用户交付（不含 Baseline/内部 request） |
| `revise-request` | `--request` | 同一成品返修 |
| `register-supplement` | `--request --input [--note]` | 补素材；图片生产同步刷新 `source-lock.json` |
| `set-state` | `--request [--status active|blocked]` | 只允许 `active` / `blocked` |
| `complete-internal` | `--request` | non-Promote completion 唯一 Authority（只 fresh 校验已发布文件与 receipt） |
| `promote` | `--request --manifest` | 唯一用户交付提交入口；写 revision/output manifest 与 `completed` |
| `record-approval` | `--request --candidate-id --mode user|auto_authorized --evidence "<原话>"` | 追加 `work/approvals.jsonl`，不写 requirement lock |
| `consume-personal-context` | `--request --consumer <skill>` | 消费 Personal Layer；未启用返回 `skipped`，不匹配即阻断 |
| `status` | `--request` | 只读 digest，不写文件 |
| `doctor` | `[--summary]` | 排障；显式命令，不在 hot path |

## 输出与退出码

- 成功：stdout 单个 JSON，`status` ∈ `ready / resolved / active / completed / recorded / consumed / loaded / skipped / passed`，常见字段 `request`、`primary_skill`、`request_state`、`request_revision`、`revision`。
- `status` 命令的 digest 字段：`request`、`request_type`、`primary_skill`、`production_branch`、`branch_error`、`request_state`、`request_revision`、`intent_fingerprint`、`files`（`requirement-lock.md / source-lock.json / visual-spec.json / prompt-binding.json / candidates.json / confirmed-candidate.json / delivery-manifest.json / final-review.md` 是否存在）、`candidates`、`confirmed`、`output_manifest`、`next_action`。
- 失败：`{"status":"blocked","error_code":"gate_blocked","reason":"...","next_action":"fix the reported fact or state, then rerun the same command"}`，退出码 `1`。
- `status` 的 `next_action` 直接说明下一步：缺 requirement-lock → 先生成意图源；无候选 → 先产 1 个候选；未确认 → 登记真实调用后确认；缺 delivery-manifest → 建 manifest 并跑交付检查；无 output manifest → promote；已交付 → 走用户反馈。**只修它指出的那一处，不重跑整条链。**

## 使用纪律

- 状态不明先跑只读 `status`，不要靠翻源码猜测阶段。
- 审批是独立事件：批准/确认文字只进 `work/approvals.jsonl`，不得写回 `requirement-lock.md` 或 `request.md` 当作生成凭证。
- `promote`/`complete-internal` 失败先读 `reason`；只补真实缺失事实后重跑同一命令。
