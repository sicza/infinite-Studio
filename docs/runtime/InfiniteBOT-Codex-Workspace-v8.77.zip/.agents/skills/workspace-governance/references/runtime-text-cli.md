# `runtime_text.py` 命令参考（读源码前先看这里）

> 从 SKILL.md 下沉（V8.73 token 整改）。**先看本页，不要把 `.py` 源码当文档整读。** 这是 Windows / 中文路径下唯一推荐的 UTF-8 文本读取与 Hash 入口。

入口：`python -X utf8 .agents/scripts/runtime_text.py <subcommand> --path <p> [...]`

## 子命令

| 子命令 | 参数 | 输出 |
|---|---|---|
| `outline` | `--path` `[--json]` | 结构摘要：Markdown 标题（line/level/text）、Python 顶层 `def`/`class`、JSON 顶层 key 与类型摘要；同时给 `lines`/`bytes`/`sha256`。**先跑它再决定读哪段** |
| `view` | `--path` `[--start N]` `[--lines N]` `[--json]` | 带行号的分段文本；默认 `--start 1 --lines 160` |
| `hash` | `--path` `[--json]` | 文件 `sha256` 与字节数；纯文本直接输出 hash |

## 输出字段

- `outline`（默认文本行）：`# <path> kind=<markdown|python|json|text> lines <n> bytes <n> sha256=<hex>`；随后逐条 `行号: 标题/def/class`，JSON 为 `key: type`。
- `outline --json` / `view --json`：`{"status":"ready","path","kind","lines"/"total_lines","bytes","sha256","outline"/"start"/"end"/"text"}`；解析失败另加 `parse_error`。
- 非 UTF-8 文件：`{"status":"blocked","error_code":"not_utf8","target","reason","next_action"}`，退出码 `2`。
- 文件不存在：`{"status":"blocked","error_code":"file_missing","target","reason","next_action"}`，退出码 `2`。

## 使用纪律

- 顺序固定：`outline` 看结构 → `view --start/--lines` 读需要的段 → 需要跨会话核对时 `hash`。同一会话同一文件不重复整读。
- 不要用 `more`/`type`/`certutil` 整段读取或转储源码，不要用 `chcp`/`copy` 绕过编码。
- 大 JSON 只读 `outline` 的顶层 key，再按需读片段；不要整份 dump 进上下文。
- 二进制/大媒体走专用脚本或 Hash，不用 `view`。
