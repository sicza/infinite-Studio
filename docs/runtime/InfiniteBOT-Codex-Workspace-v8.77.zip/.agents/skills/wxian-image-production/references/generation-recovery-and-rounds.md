# 生成轮次、候选确认与专业恢复

## 正式候选

- 每次 API 调用只生成/接收 **1 个正式候选**；不要一次请求多张再由 Agent 内部挑。
- `formal` 默认 3 轮；确认后的 `revision` 默认 2 轮。这是**成本护栏，不是判定结论**：护栏内自行判断；超过护栏仍不可用时，必须先用 `--round-reason` 写出已诊断的根因和本轮具体改变，才允许继续，否则停止盲刷并返回最早失败层。不要用"到第三轮了"代替失败诊断，也不要用轮次上限压缩用户明确要求的多个创意方向。
- `formal / validation / revision` 主视觉候选必须直接请求**所选模型的正式质量**，不要擅自用低质量预览充当正式或方向候选：Gemini=`quality=4k` + `size=<目标比例>`；`gpt-image-2` 默认 `quality=high`；GPT Image 2.5 默认 `quality=max`。4K/尺寸与 quality 独立，必须调用 `image-generation-api resolve-gpt` 取得当前合法参数，不得在本 Skill 重写映射。当前 Profile 无法满足用户明确质量要求时不具备正式候选资格。
- 每个新候选使用独立输出文件；永不覆盖上一轮。`formal/revision` 候选必须有同名 `<image>.call.json` 证明真实图像模型网络调用、输出路径和输出 Hash；Python/Pillow/本地脚本生成的主视觉不得登记为正式候选。

调用后 producer 应实际打开该候选并自检，可写同名 `<image>.review.json` 记录自检结果（自检是生产习惯，不是门禁，也不能授权自己的候选 `accept`）：

```json
{
  "subject_correct": true,
  "composition_correct": true,
  "style_matched": true,
  "placeholder_clean": true,
  "no_fake_logo_icon_text": true,
  "artifact_risk": "low | medium | high",
  "decision": "accept | retry | return_to_prompt_pack | return_to_requirement_doc | blocked",
  "reject_reason": "",
  "next_action": ""
}
```

五个布尔项和 `artifact_risk` 只能帮助 producer 提前淘汰明显失败。专业视觉审图是**可选诊断**：用户明确要求或高风险交付（新 IP/角色首次出场、复杂玩法证据、多轮争议、高价值主视觉）时，才由与 producer 上下文分离的 reviewer 实际打开同一文件，使用 `$sicza-visual-director DIAGNOSE`；存在多候选时再用 `SELECT`。reviewer 先读原始 `request.md`，再读 requirement lock、Reference 原图与真实逆向分析、命中的 Personal Context，最后审 Visual Spec / Prompt 和像素；不得只对被污染的 Spec 做一致性检查。审图结论是专业建议，不替代人类最终质量判断，也不因缺少审图阻断候选登记/确认/交付。

用户确认候选后，用独立事件记录批准（不写回 `request.md` 或 requirement lock）：

```bash
python .agents/skills/workspace-governance/scripts/workspace_gate.py record-approval --request <request> --candidate-id <id> --mode user|auto_authorized --evidence '<确认或授权原话>' --workspace-root .
python .agents/skills/wxian-image-production/scripts/candidate_tracker.py confirm --request <request> --candidate-id <id> --mode user|auto_authorized --evidence '<确认或授权原话>' --workspace-root .
```

- 新调用记录 `intent_binding`（稳定意图快照：request revision、输入文件、requirement lock）；追加批准不改变该快照，只有实质需求变化才使旧候选过期。
- 旧 V8.71 调用没有 `intent_binding` 时按 `legacy_intent` 证据登记，不得改写历史或伪造新凭证。
- 登记只校验真实调用证据（status/network_called/output hash/尺寸/参数/Reference），不强制审图或自检；提供审图时必须是真实 PASS 报告。
- 不确定当前处于哪一步时运行只读 `workspace_gate.py status --request <request>`。

方向验证不是低成本抽奖，但也不必每条路都先烧一张正式图。先用文字、构图骨架和已消费的 Reference 关系判断；只有该判断仍无法裁定某方向是否成立、确实需要像素证据时才调用验证图。调用时每个方向只允许 1 张真实正式质量模型候选（Gemini `quality=4k`；`gpt-image-2`=`high`；GPT Image 2.5=`max`；尺寸通过 `resolve-gpt` 决定），并显式绑定方向 ID：

```bash
python .agents/skills/wxian-image-production/scripts/candidate_tracker.py record --request <request> --source <验证图> --kind validation --direction-id <direction_id> --workspace-root .
```

validation 与 smoke 同样建议写各自 `<image>.review.json`（自检非门禁，缺失不阻断登记）；方向比较应优先消费已完成 self-check 的候选。只有用户明确要求低清 smoke/技术预检时才使用 `--kind smoke --direction-id <id>`；smoke 仍必须是真实模型调用，但可以低于 4K，且永远不能被 `select` 为确认母版或进入正式后处理/交付。

用户确认某一候选后，按上面「正式候选」一节的独立批准命令登记（`workspace_gate.py record-approval` 写 `work/approvals.jsonl`，`candidate_tracker.py confirm` 记确认），不要写回 `request.md` 或 requirement lock。

之后的派生链固定为 `confirmed candidate → pure_visual_image → locale master → resize → deterministic assets`；每一级读取上一层真实 path/hash，不靠文件名或“最新文件”猜。

若确认母版本身干净（没有需要清除的烘焙文字/LOGO/UI），`pure_visual_image` 可以直接复用同一文件与 Hash，不需要为“留下 operation 记录”再做一次无变化图生图；只有确实需要清除叠加内容时才执行真实 image edit。

## Reference 防污染

- 旧错误候选、已拒绝方向、历史 correction 图默认不得作为 `reference_images`。
- 如果任务就是编辑用户明确指定的那张当前候选，把它作为 `base_image`，不是偷偷塞进 Reference。
- 构图 Reference 默认只理解结构、不上传；角色身份和明确要求还原的 gameplay Reference 必须上传；正式 LOGO/ICON/UI/道具只后处理。

## “方向认可”与旧图

用户只说“这个方向对/按这个方向继续”时，认可的是事件、构图、信息结构、氛围或视觉机制；先把被认可部分抽象回 `visual-requirement.md`，再按新 Prompt 正式生成。只要旧图仍有角色、画风、构图、玩法或质量问题，它默认 `visual_only/forbidden_upload`，不得作为 `base_image` 或 `reference_images`。只有用户明确说“在这张图上改/保留原图只改局部”时才允许作为 `base_image`，并锁定保持区与修改区。

## 角色一致性返工诊断

用户反馈“角色不像/一致性差”时不得先加词盲刷：先查 `visual-requirement/prompt` 是否有可观察身份锚点；再查 `reference-plan` 与真实 API call 是否确实上传正确角色原画；两者都正确仍失败时，检查旧错图、构图/风格 Reference、错误角色版本或互相冲突的描述是否污染输入。第二次同类失败仍未改善，必须回最早错误层重写，不继续同一 request 重采样。

## 失败恢复

先判断失败层，再选择最小但正确的修复：

- 主体不准：重做身份锚点/Reference，不要靠负向词补。
- 背景可用、角色错：保留底图，单独修主体后编辑/合成。
- 特效错：主体与特效同步修，连同边缘光、反射和材质高光一起处理，不贴孤立特效层。
- 次要角色比例/方向错：单独优化次要角色，再回整图。
- 构图太挤：先扩图创造空间，再移动/缩放可变元素，不继续往原构图堆文字。
- 字体效果不稳：反推字体 Reference 的字形/描边/阴影/发光/材质；需要扣图时可先生成干净黑底白字字形。
- 清晰度/材质不足：做保持构图、角色、动作、色彩、文字和品牌资产不变的高清精修；逐区检查轮廓/几何、脸与手部解剖、发丝、皮肤、织物、盔甲/金属、建筑透视、自然元素结构、材质高光/反射和统一光影，去除糊边、噪点、压缩涂抹和无定义填充。精修不能靠随机新增纹理伪造细节；身份、结构、文字或构图发生漂移即作废。
- 整体结构/层级/主体关系/剧情因果错：退回 visual requirement 或 Prompt 重写，不在旧 Prompt 上叠补丁。
- 用户否定主题、构图、第一读或吸引力：回读完整需求与全部仍有效决定，废弃当前方向及同构机制家族，重新进入 Visual Director CREATE；不能把旧方案改名或添加 negative terms 后继续。

## 远端等待状态

图像调用返回 `remote_state_unknown` 时，保留 `<output>.attempt.json` 作为已提交证据；当前轮次停在该状态，不创建同参数重复调用。HTTP 明确失败、请求结构错误等已知失败仍按最早失败层修复后进入新的调用。Seedance 查询超时继续使用原 task id。

`failure_class=content_safety` 不是断线或瞬时网络错误。当前 request JSON 与 Prompt Hash 立即终止，`retry_safe=false`；不得自动重连、原样重放、仅换模型或把同义规避词当新版本。回到 `prompt-and-reference.md` 做一次有实质变化的安全改写，使用新的 Prompt 文件、API request 与输出路径进入新调用。该安全版本再次返回 `content_safety` 时停止本轮并向用户说明 Provider 边界，不能耗尽 formal/revision 轮次做盲试。
