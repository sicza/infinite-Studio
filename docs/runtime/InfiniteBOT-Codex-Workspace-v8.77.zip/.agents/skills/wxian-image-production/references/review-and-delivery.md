# 成图硬证据检查与交付

最终阶段先读取 [formal-output-and-delivery-contract.md](formal-output-and-delivery-contract.md)。这里的职责是证明生产链和文件事实成立，不替用户做审美满意度裁判。

## 完整视觉图门禁（presentation gate）

交付前的载体呈现由机器检查，不靠人工记忆：

    # 全局选项必须写在子命令之前
    python .agents/skills/wxian-image-production/scripts/presentation_gate.py --workspace-root . lint-prompt --prompt <work/api-prompts/main.txt>
    python .agents/skills/wxian-image-production/scripts/presentation_gate.py --workspace-root . check-picture --image <交付成图>
    python .agents/skills/wxian-image-production/scripts/presentation_gate.py --workspace-root . policy

- `lint-prompt`：提示词不得把载体（ICON 等）当造图目标，也不得模拟承载画布（圆角、蒙版、四角留白）；退出码 `2` 阻断并报出命中位置与规则 id；**可复制修正句式由联网前校验（generation_api 的 require_clean_prompt）给出**，CLI 本身不生成该句式；banner/KV/LOGO 等载具词只落机器收据、不阻断。
- `check-picture`：只回答"这张图有没有把载体圆角/色板烤进画面"，不评价画面质量，也不是载体识别器。退出码 `2` 只有一种情形：四个角块是同一片**纯净平整**颜色、该色在角上向内延伸 ≥5% 短边、**四条边的中点都不是该色**（内容顶到画框），**并且**至少三个角块的形状是**圆弧半径**（角框内该色占比 ≤0.38 且两向延伸对称）。
- **非阻断提示 `presentation_risk`**：前三个几何条件成立但角块不是圆弧形状（角框被直角背景填满）时，只记录风险提示，退出码 `0`。这类形状属于平涂背景上的合法构图，由 Layout/专业评审负责，不由本检测器裁决。
- **明确放行（不是缺陷）**：等距留白/边框/letterbox/pillarbox、平涂背景上的居中主体、四边出血的十字/圆盘/被裁切大头像、45° 切角构图——它们的角框要么被直角背景填满，要么边中点仍是背景色，因此一律不进阻断。
- **不得为过门禁改画面**：合法构图被提示时不需要也不允许为了"通过检测"而加渐变、纹理或改光影。艺术方向由需求与专业判断决定；本检测器只拦"圆角蒙版被烤进交付图"这类真实事故。
- 联网前同一契约由 `image-generation-api` 强制执行，违规提示词在网络调用前被拒。自检：`presentation_gate.py --workspace-root . doctor`。
- 联网前同一契约由 `image-generation-api` 强制执行，违规提示词在网络调用前被拒。

## 硬证据

实际打开最终文件并核对：可解码；实际像素/比例/格式/Alpha；精确文字拼写与语言；实际使用的角色/LOGO/ICON/UI/道具文件版本；Reference plan 与真实 API `reference_images`；resize 是否等比或有经验证的重构；manifest 的路径/Hash/role/locale/size/active；完整新图的 pure visual 和语言×尺寸矩阵。

发现文件缺失、Hash/尺寸错误、错误资产版本、精确文案错误、Reference 输入越权、非等比拉伸或矩阵缺项时 blocked，并回最早责任层。

## 视觉判断

角色“是否更像期待”、构图重心、背景扩展自然度、LOGO/ICON 观感大小、翻译语感等必须以实际像素判断，不能由 producer 的布尔自检代替。需要正式量化比较时调用 `$wxian-visual-scorecard`；分数不能代替原始需求、Reference 与像素的专业裁决。审图机制见下方“独立最终视觉审查”。

## 根因回退

```text
事实/资产错误 → requirement/reference
画面因果/信息结构 → visual requirement
Prompt 解释 → prompt
单点模型缺陷 → edit/retry
比例/布局 → layout/recompose
合成/导出 → deterministic postprocess
manifest/lineage → delivery
```

`work/final-review.md` 只写：硬证据状态、阻塞项（若有）、待用户确认项（若有）、最终文件。不要复制整个需求或流程历史。

交付清单采用 [formal-output-and-delivery-contract.md](formal-output-and-delivery-contract.md) 的最小 lineage 字段；对应 mode 的 `delivery_gate.py` 必须通过后再 promote。高风险、多产物、多轮返修或状态不确定时再调用 `$wxian-delivery-audit`。

## 专业视觉审图（可选）

专业视觉审图是诊断能力，不是交付门禁：

- 用户明确要求，或本次交付属于高风险时，可以由与 producer 上下文分离的 reviewer 使用 `$sicza-visual-director DIAGNOSE` 审看 exact target，多候选用 `SELECT`，需要量化比较时调用 `$wxian-visual-scorecard`。
- reviewer 的审查顺序为原始需求、Reference 原图与逆向分析、Personal Context、实际像素；审图报告保存 reviewer/producer identity、target hash 与结论，供用户参考。
- 审图结论不自动阻断候选确认或 Promote；只有用户明确把某次审图结论作为本次交付条件时才按用户要求执行。机器检查只验证硬证据（真实来源、对象 hash、尺寸、格式），不替代人类最终质量判断。
