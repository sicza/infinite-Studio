# Seedance 2.5 Prompt Pack

This pack produces complete natural-language video prompts. It is intentionally
separate from the configured Seedance 2.0 transport: compiling a 2.5 prompt is
not evidence that the current Runtime can submit a 2.5 video job.

Compile in this order: actual upload ordinal and role; protected identity and
existing shot facts; requested change; closed integer-second timeline; camera,
space, material and sound only when the task requires them; precise preserve and
avoid boundaries. Each image, video, and audio reference is named by its actual
input position, with both what it supplies and what must not be inherited.

For `text_to_video`, establish the initial state, one coherent action chain,
camera and final state. For `image_to_video` and `multimodal_reference`, make
the uploaded image/video/audio roles explicit. For `video_edit`, state the
integer-second interval to change and preserve the surrounding shot, identity,
audio and continuity. For `video_extend`, continue from the existing final
state; never restart the action or scene.

Time ranges use whole seconds only, are ordered, non-overlapping, and lie inside
the requested duration. Do not invent dialogue. When dialogue is requested,
identify speaker, language, timing, vocal quality and visible synchronization.
