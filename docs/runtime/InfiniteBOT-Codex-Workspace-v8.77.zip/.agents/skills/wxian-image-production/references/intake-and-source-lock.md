# 需求事实与素材 Source Lock

## 唯一事实源

`work/requirement-lock.md` 是当前 request 的唯一关键需求事实源，不是方案容器。第一条机器事实必须且只能有一个：

```text
production_branch: new-generation|image-edit|video|resize|upscale|localization|composite|postprocess-chain|visual-brief-only|prompt-only|prompt-review-only
```

分支全集以 `.agents/lib/production_contract.py` 的 `PRODUCTION_BRANCHES` 与 `visual-enforcement-profiles.json` 为准；本行只是便于阅读的镜像，两者不一致时以注册表为准并修正本行。

API、Promote、Audit 都直接读取它；缺失、重复或非法值阻塞，不得根据已有产物反推。**其余每一条会改变结果的事实都必须带来源**，只有两类形式：

```text
- <事实> | kind: user_explicit | source: <工作区相对路径> | evidence: <该来源中的逐字原文>
<自由文本事实键>: <值> | kind: user_explicit | source: <工作区相对路径> | evidence: <逐字原文>
```

| `kind` | 唯一合法 `source` |
|---|---|
| `user_explicit` | 当前 `request.md` |
| `approved_revision` | 当前 `request.md`（用户确认或授权继续的原话） |
| `project_fact` | `project/` 下的当前项目事实文件，如 `project/project-brief.md` |
| `input_asset` | 当前 `request/input/` 中的真实文件 |

`input_asset` 是唯一可以指向二进制文件（图片/视频）的类型，因此它**只允许写出该资产的文件名**，不能承载任何散文式要求，也不能在文件名前加一句话：

```text
- base.png | kind: input_asset | source: requests/.../input/base.png | evidence: base.png
```

要在 lock 里陈述任何要求本身（"必须使用…作为第一视觉焦点"），只能用 `user_explicit` / `approved_revision` 逐字引用 `request.md`，或写进 `visual-requirement.md`。其他 `kind` 的来源必须是文本文件——机器无法从图片里"逐字找到"任何句子，因此也不接受用二进制充当可引用来源。要表达"这是底图/身份图"，写进 `visual-requirement.md` 或由记录字段（`base_image`）表达，不要塞进 lock 的事实文本。

`evidence` 必须在声明的来源文件中逐字存在（允许换行/空白归一）；写不出逐字原文的，就不是可锁事实。**`-` 条目的 `<事实>` 本身也必须是该来源里能逐字找到的句子** —— 在无关引文旁边写一句 Agent 自己的转述，等同于没锁来源。要记录转述、取舍或综合结论，写进 `visual-requirement.md`，不要写进 lock。`kind: agent_proposal` 等未注册类型、指向非 `request.md` 的 `user_explicit`、指向用户文件的 `project_fact`、以及缺失/越界的来源路径一律阻塞。

**可以不带来源**的只有值域封闭、且下游 Gate 已经校验的机器事实：`production_branch`、`source_demand_type`、`visual_variant`、`has_real_props`、`store_artwork_role`、`store_sequence_position`、`gameplay_truth_source`，以及路径型 `gameplay_truth_evidence / gameplay_truth_analysis / gameplay_reference_frame`（必须是 Workspace 相对路径并解析到真实文件，绝对路径与悬空路径都会被拒）。

`gameplay_truth_approval` 不是路径型：它必须逐字引用 `request.md` 里用户确认或授权继续的原话（见下方 `store_artwork_role: gameplay` 段），机器会核对这段引文确实存在于 `request.md`。

`final_logo` 不算封闭值域：它必须写成 `final_logo: user_explicit_none | evidence: \`<用户原话>\``，且这段引文必须逐字出现在 `request.md`。机器只证明**引文真实存在**；"这句话是否真的等于不要品牌资产"仍由专业判断与独立审阅负责——不要用"没有 LOGO"之外的意思去引用它。

**必须带来源的自由文本事实**：`store_claim`、`gameplay_action`、`gameplay_visible_result`，以及任何未在上两行列出的新事实键（例如 `business_goal`）。它们不仅要有来源，**值本身也必须能在该来源中逐字找到** —— 注册键不等于来源，写 `store_claim:` 也不会让它变成用户要求。

已有 request 的 lock 早于本契约时，用 `source_lock_gate.py --request <request> --audit-lock` 逐行诊断并给出可直接采用的补来源写法；该命令只报告，不改写 lock。散文、表格、清单式要求一律被机器拒绝。

机器只证明"这段原文确实存在且被正确归类"，不证明 Agent 理解了它；语义忠诚仍由专业 Skill 与独立审阅负责。

下游视觉需求、Prompt、API 参数和后处理矩阵消费它，不各自复制需求全文。任何动作若改变已锁定的角色/资产版本、文案、语言-地区映射、画幅、目标尺寸、玩法、LOGO 策略或 must-not，必须先有用户新指令并更新 lock；不得静默漂移。

允许进入 lock 的内容必须能够逐项回指当前用户原话、当前 input、Project Brief、正式 Baseline 或已确认项目事实。Agent 为完成任务提出的中心事件、装置、道具、动作、镜头、站位、空间拓扑、光源解释和候选取舍，全部属于专业方案，只能进入 `visual-requirement.md` / Visual Director 的 request-local 投影 / `visual-spec.json`。即使 Agent 自动选择了一个方向，也不得把它回写成用户 P0、`must_keep`、business goal 或项目事实；用户说“按这个方向继续”只授权继续生产，不等于用户原本要求了其中的某个机械装置。

“必须有清楚因果”“不要站桩”“无武器”等约束只锁目标，不自动推出“人物必须推、拉、转、开、递交或操作某个物体”。专业层可以选择观察、尺度、距离、视线、身体压力、群体拓扑、展示比较、图形关系或真实事件；哪一种成立由 Visual Director 裁决。

`request_type → primary_skill → production_branch` 由 `.agents/lib/request_routing.py` 与本文件首行 `production_branch` 唯一决定。`KV / ICON / LOGO / Banner / 商店图` 等载体词不得改变 Primary Routing。

若上游/用户明确给出原业务 `source_demand_type`，它只作为业务载体/视觉处理标签保留：

```text
source_demand_type: 活动配图|互动图|BANNER|弹窗|LOGO|ICON|铭牌|KV|商店图
visual_variant: <visual_variant_resolver.py 的结果>
has_real_props: true|false   # 仅活动配图需要
```

`visual_variant_resolver.py` 只决定当前 `new-generation` 内的视觉处理方式，**无权修改 `request_type`、`primary_skill` 或 `production_branch`**。图像 API 在真实调用前只重新核对 `visual_variant`。互动图仍必须由 `reference-plan.json` 证明存在 `gameplay + must_upload`，否则调用前阻塞。直接做 KV/ICON/LOGO/商店成图仍属于 `image-generation → wxian-image-production → new-generation`；只有用户目标是方案、方向探索或包装策划时才进入 `wxian-visual-packaging`。

当 `source_demand_type: 铭牌` 时，锁定 `visual_variant: ui_nameplate_asset`；它必须使用 `graphic_asset` 逻辑、声明横向承载结构与中心内容安全区，并把角色/主题 Reference 仅作为 theme/visual grammar source，除非用户明确要求复现既有 UI。透明交付必须通过 Provider 请求、PNG/WebP 输出和最终 Alpha readback，不能以 Prompt 文案替代。

当 `visual_variant: store_artwork` 时还必须锁定：

```text
store_artwork_role: first-screen-conversion|gameplay|worldbuilding|character|selling-point
store_sequence_position: standalone|1|2|3|4|5|6|7|8|9|10
store_claim: <这一张唯一要证明的真实卖点>
```

当 `store_artwork_role: gameplay` 时额外锁定：

```text
gameplay_truth_source: current_reference|project_material|project_brief|approved_concept|user_confirmed_rule
gameplay_truth_evidence: <真实路径或原文证据>
gameplay_truth_approval: <仅 approved_concept 必填；用户选择/自动授权原话>
gameplay_action: <玩家实际做什么>
gameplay_visible_result: <操作/决策后画面必须看见什么>
```

详细执行规则读取 `store-artwork-production.md`；这些字段由 `store_artwork_gate.py` 在真实 API 调用和最终交付前硬校验。

先实际打开关键输入。当前 request 优先于项目默认资料；同层冲突才询问。

## 文案 / 地区

文案状态只用：`confirmed | missing | none`。

- `confirmed`：每个正式语言版本锁准确字符串；语言名/地区名不能替代真实文案。用户没指定首版语言时，已确认映射中有英文则默认优先英文；没有英文则直接使用已有真实语言映射，不自行翻译或额外询问。
- `missing`：不得让模型自行补节日名、营销语或品牌文字。正式首版需要该文案时只询问这一处必要信息；仅用户明确允许 preview 时可用明确标记为非最终的 placeholder，且不得进入正式候选/交付。
- `none`：不生成营销标题/说明/按钮占位；玩法成立必需的数字、符号、问号、运算符、选项和计数不按营销文案处理。
- 多语言/多地区数量或映射冲突：不猜对应关系，只询问冲突项。
- 没有画内文案但存在地区：跳过 localization 文案替换；除非用户明确 no-logo，正式 final 仍使用对应地区真实 LOGO/品牌资产。
- 无真实游戏道具素材时，不主动设计或交付空奖励框、图标槽、待填卡槽。这条是默认取舍，不是禁令：用户明确要求保留空白道具槽/占位框/待填卡槽时按其原话执行，并按 `user_explicit` 记入 lock；此时该空槽就是需求事实，不属于"无意义占位"。标题可读性优先靠字形/层级/描边/投影/光效/材质/色彩对比解决，不默认加底板。

## 当前素材 Source Lock

`request/input/` 只保存当前需求带入的真实文件。存在文件时运行：

```text
python .agents/skills/workspace-governance/scripts/source_lock_gate.py --request <request> --sync --workspace-root .
```

脚本从真实 `input/` 自动生成并验证 `work/source-lock.json`，Agent 不重复枚举路径。这个锁只证明当前附件没有被静默忽略/替换；是否上传给模型仍由 `reference-plan.json` 的 `must_upload / visual_only / postprocess_only / forbidden_upload` 决定。`input/` 为空时脚本保持 source-lock 不存在。用户只点名项目已有角色/品牌资产而没有当前附件时，按 Project Brief、Baseline、material-index 与真实项目文件解析。

## 首版比例与目标尺寸

同时存在“首版比例”和多个目标尺寸时，正式首版优先使用与锁定比例一致的目标尺寸作为构图基准；例如比例 `1:1` 且目标有 `1920x1080 + 1080x1080`，首版按 `1:1` 构图，确认后再派生 16:9。若没有任何目标尺寸匹配已锁定比例，不自行挑一个，必须只确认“首版以哪个比例/尺寸为基准”这一处冲突。
