---
name: wxian-image-production
description: 图片与视频制作主流程：需求锁定、视觉方案、Prompt、生成/编辑、候选确认、纯视觉、本地化、改尺寸、真实资产合成、终检与交付。
---

# 图片生产

本 Skill 作为当前 request 的 Primary 时，进入前执行 `$workspace-governance consume-personal-context --request <request> --consumer wxian-image-production`；阻断则停止。作为其他 Primary 的内部图片执行能力时，继承调用方已验证的 Primary Context；不得用 `wxian-image-production` 再次消费，也不得把辅助 API 执行伪装成第二个 Primary request。

开始或继续本 Skill 前必须通过 Workspace 视觉 preflight；`$workspace-governance` 会在 request 新建、续接、返修和 Promote 时硬执行 `workspace_init.py visual-check`。若返回 `needs_visual_baseline`，先刷新 Baseline，不得继续消费旧规则。

按当前分支/阶段渐进读取 Reference。视觉创意、诊断、改图、Prompt 或 Narrative→Visual 先读 `visual-director-integration.md`；共享内核不改变本 Skill 的 Primary/API/Promote Authority：

- 所有图片分支：`image-workflow-contracts.md`；存在当前附件时再读 `intake-and-source-lock.md`。
- `new-generation / prompt-*`：视觉决策读 `visual-thinking-and-brief.md`；Store 读 `store-artwork-production.md`；使用图片/视频事实时读 `current-demand-reference-analysis.md`；Prompt 编译读 `prompt-and-reference.md`，模型确定后只读 `prompt-packs/` 中当前模型对应文件；候选生产/返修读 `generation-recovery-and-rounds.md`。
- `localization / resize / composite / postprocess-chain` 以及 `new-generation` 确认后的后处理：只读 `postprocess-and-layout.md`、当前动作需要的 `resize-prompts-and-localization.md` 或 `resize-and-compositing.md`。
- 进入 manifest / Gate 前读 `formal-output-and-delivery-contract.md`；最终人工复核时读 `review-and-delivery.md`。

同一事实只保存一次，按四类责任归位：用户事实与沟通历史在 `request.md`、机器意图在 `requirement-lock.md`、批准事件在 `work/approvals.jsonl`；专业裁决在 `visual-requirement.md` 与 `visual-spec.json`；执行证据在 call/operation/candidate 记录；交付结果在 delivery manifest 与 output。下游按路径、Hash 和必要字段消费，不复制上游正文，也不为同一结论再造摘要或签核文件。

## 分支

只执行当前目标需要的分支，并把它作为 `work/requirement-lock.md` 的唯一机器事实：

`production_branch: new-generation | image-edit | video | resize | upscale | localization | composite | postprocess-chain | visual-brief-only | prompt-only | prompt-review-only`

缺失、重复或非法值直接阻塞；API、Promote、Audit 都读这一行，不根据已有文件反推。已有母版不重新生成，确定性后处理不进创意全链；`visual-brief-only` / `prompt-only` / `prompt-review-only` 在产物完成后停止，不调用生成 API。

## 需求锁定

新需求必须先经过 `$workspace-demand-intake`；本 Skill 不重复索取已由 Intake 锁定的公共字段，也不把构图、镜头、创意方向前移给用户。按 Intake Snapshot 与输入 Reference 写 `work/requirement-lock.md`，当前用户要求与 request input 优先，项目长期事实从 Project Brief、Baseline、material-index 定向读取。普通新生图尺寸缺失沿用 `1:1`；文案缺失/空白即 `none`，不得再追问。

`request/input/` 非空时运行 `source_lock_gate.py --sync`，由脚本生成并验证 `work/source-lock.json`，Agent 不手抄清单；它只证明证据完整存在，不等于全部上传。当前图片按职责分析：角色锁身份、玩法锁机制、构图/风格确实借用时才完整反推。当前 request 有会影响视觉事实的 Gameplay/广告/PV/实拍视频时，在本 request 内调用 `$wxian-video-source-analysis`，不要让用户先截图或解释。

使用 Baseline 时先把它当项目视觉先验与最低线：读视觉画像、相关 Family、Floor 与创新空间。已有 Family 可作起点但不必复刻，当前需求更适合时用 `novel-direction`。只把本次真实消费的 Family / Floor / Character / Reference 与用户覆盖项写入 `work/baseline-consumption.json`；machine key 固定为 `image-production`（`"consumer": "image-production"` 且 `--consumer-name image-production`），不得写 Skill 名。随后运行 `baseline_consumption.py`。

## 视觉需求

当当前 request 的最终交付是实际图片文件，但用户明确要求先从零探索游戏概念、画风玩法、人物×场景×玩法原型或成熟 Gameplay 变异时，先在当前 request 内调用 `$sicza-game-concept-lab`。它只形成 PROVISIONAL Direction / Prototype Spec / Test Prompt；用户选择或原需求已授权自动收敛后，再由本 Skill 写入正式视觉需求并进入生产。候选 Prototype 不是已确认 Production Truth，也不为其另建 request。

若该前置能力建立长期 IP / 正式角色，另需 `work/concept-lab/` 的 `ip-character-system/binding/preflight` 与 `READY` 的 `ip-character-handoff.json`；其 `image_conditioning_inputs` 按 `provider_slot_or_order` 构成 `reference_images` 不可改序前缀，`must_upload` Reference 续接在后。`base_image` 只是 edit target，不能升级为 Mother Reference。完整校验见 `$sicza-game-concept-lab` 的 `05a-ip-character-system.md`。

`new-generation`、复杂编辑和需要重构的 Resize 写 `work/visual-requirement.md`：它是专业裁决容器，不是需求事实容器。`P0` 只放来自 `requirement-lock.md` 的已锁事实，P1/P2 放专业优先级与取舍，并形成 `对象 → 动作/关系 → 空间 → 可见结果`。方向六项裁决按 `visual-thinking-and-brief.md` §2.2 写一次即止。

系列图同时锁定：角色身份、场景状态、时间进度、关键道具、光线方向、镜头推进。每帧写清继承项、变化项和变化原因。

## Prompt 与 Reference

需要视觉决策的分支先把当前 Reference 的真实逆向分析交给 `$sicza-visual-director CREATE/SELECT`，再生成 canonical `work/visual-spec.json`。Director 必须先裁定 visual_logic、可迁移核心关系、结构不同的方向与 `avoid_reversion`；不得从 lock 直跳 Prompt，也不得把专业方案回写成需求事实。需要模型时写 `work/prompt-package.md`（只描述最终画面，不写 API 参数、路径、Hash 或工作流）；若使用 `work/prompt-binding.json` 作为可选专业证据，执行前验证其与当前 Spec/Prompt 一致。

每张 Reference 只有一个明确职责。角色身份与需还原的 gameplay=`must_upload`；构图默认 `visual_only`；真实 LOGO/ICON/UI/道具=`postprocess_only`。视频本身是 truth source，不直接进入图片 `reference-plan.json`；经 `$wxian-video-source-analysis` 验证的代表帧可作为 Reference，但必须保留原视频 Hash 与时间点证据。生成前运行 `request_reference_gate.py validate-plan`，API 再校验真实上传集合。

存在 IP Character contract 时，先按 `$sicza-game-concept-lab` 的 `05a-ip-character-system.md` 完成 production preflight 与 Provider Handoff 编译再构造 API request；`image-generation-api` 会在联网前校验 Hash、Provider、执行模式、Mother Reference 前缀/顺序、edit target 与 runtime evidence，缺文件、旧 handoff、重排或降级都会阻断。

## 模型执行

超分走 `image-upscale → upscale`，按需 `$wxian-image-upscale`；未校准模型仅可确定性回退。

图片默认 `gemini`（`text_to_image / reference_to_image / image_to_image_edit` 均可用）：无参考走 `/v1/images/generations` JSON，参考图/图生图走同一 OpenAI-compatible Images 家族的 `/v1/images/edits` multipart，模型 `gemini-3.1-flash-image-preview`、`size=<目标比例>`、`quality=4k`。`must_upload` 不能因 transport 更新降级或改走无参考文生图。用户指定 GPT 或需要其独有能力时用 `gpt`；视频默认 `seedance`。

GPT 请求先调用 `image-generation-api resolve-gpt` 解析用户原话与比例/尺寸，并原样使用返回结果。路由：普通 GPT→Flare，image2→旧模型，image2.5→Sunburst；高清/高精度/4K/PNG/透明要求强制 Sunburst。2.5 的 quality、背景、格式、尺寸与完整边界均以 API Skill 的机器解析结果为准；Image Production 不维护第二套参数映射。

当 `video` 分支属于“静态 KV / 海报 / Banner → 5 秒剧情微动画”时，以 `execution_mode=production_video` 调用 `$wxian-kv-micro-animation`：一次读图后写入 `work/micro-animation/`（剧情位置、连续性、自动锁定的 Camera Level、`REFERENCE_ROLE`、完整 Seedance Prompt），随后立即调用 `$image-generation-api`。`REFERENCE_ROLE` 决定 `image_to_video_first_frame` / `reference_to_video` / 首尾两图时的 `image_to_video_first_last_frame`。默认 `duration=5`、`resolution=1080p`、`generate_audio=true`，画幅沿用源图；不在 Prompt 与 API 之间增加 Camera 确认，也不把 Prompt 当最终交付。

每轮只生成 1 个候选，不覆盖历史结果。专业视觉审图是可选诊断：用户明确要求或高风险交付时，可由上下文分离 reviewer 实看原尺寸与缩略图；默认不强制审图，审图结论也不替代人类最终质量判断。

## 候选与确认

候选生成、review（可选）、登记、轮次上限、批准、确认命令与失败恢复统一执行 `generation-recovery-and-rounds.md`。候选按真实调用证据登记；用户批准通过 `$workspace-governance record-approval` 记录为独立事件，不写回 `request.md` 或 requirement lock，也不会使已生成候选失效。进入纯视觉或正式后处理前必须已有绑定当前 request 意图的 `confirmed-candidate.json`；旧 request 的 legacy 生成证据按显式 `legacy_intent` 处理。首版 `copy=none` 不得自行补营销文案，正式 LOGO 默认确认后再用真实资产合成。

## 纯视觉与派生

确认后的正式派生统一执行 `image-workflow-contracts.md`、`formal-output-and-delivery-contract.md` 与 `postprocess-and-layout.md`：完整 `new-generation` 先由 confirmed candidate 生成唯一 `pure_visual_image`，再生成 locale/resize/composite 派生；若确认母版本身干净（无待清除的文字/LOGO/UI），`pure_visual_image` 可直接复用同一文件与 Hash，不做无变化图生图。真实 LOGO/ICON/UI/道具只用当前有效资产。confirmed 构图只建一次 Layout Plan，确定性派生按 operation lineage 映射；只有 AI expand/recompose 真正改变构图几何时才新建。

## 终检与交付

实际打开最终文件。硬证据检查：需求事实、资产、文案、尺寸、Alpha、Reference、调用/operation lineage、文件可读性。审美由用户或 `$wxian-visual-scorecard` 评价；专业审图默认可选，不作为交付前提，除非用户明确要求把本次审图结论作为交付条件。

生成 `work/final-review.md` 和 `work/delivery-manifest.json`。正式交付必经 `$workspace-governance promote`，由 Promote 唯一 blocking 调用 `delivery_gate.py` 并按 `production_branch` 验证确认候选、pure visual、派生链、真实 edit、Seedance task/容器或独立后处理 lineage。直接运行 `delivery_gate.py` 只用于显式诊断，不属于正常交付序列。

高风险、多产物或多轮返工时按需调用 `$wxian-delivery-audit`。
