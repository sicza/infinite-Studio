#!/usr/bin/env python3
"""Compile one signed, model-specific Prompt package for Prompt-only or API use."""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path
from typing import Any

ROOT=Path(__file__).resolve().parents[3]
class PromptError(ValueError):pass
def require(c:bool,m:str)->None:
 if not c:raise PromptError(m)
def sha(p:Path)->str:return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p:Path,v:Any)->None:p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def load(p:Path,label:str)->dict[str,Any]:
 try:v=json.loads(p.read_text(encoding='utf-8'))
 except (OSError,json.JSONDecodeError) as e:raise PromptError(f'{label} is invalid: {e}') from e
 require(isinstance(v,dict),f'{label} must be an object');return v
# A batch compiles one package per layer, so the same profile/API config files are parsed on
# every layer. Key the cache on path+mtime+size so a config edit inside one process still wins.
_CONFIG_CACHE:dict[tuple[str,int,int],dict[str,Any]]={}
def load_cached(p:Path,label:str)->dict[str,Any]:
 try:st=p.stat()
 except OSError:return load(p,label)
 key=(str(p.resolve()),st.st_mtime_ns,st.st_size)
 value=_CONFIG_CACHE.get(key)
 if value is None:
  value=load(p,label);_CONFIG_CACHE[key]=value
 return value
def rel(root:Path,p:Path)->str:
 try:return p.resolve().relative_to(root.resolve()).as_posix()
 except ValueError:raise PromptError(f'path escapes workspace: {p}')
def workspace_path(root:Path,value:str)->Path:
 p=(root/value).resolve();require(p==root or root in p.parents,'path escapes workspace');return p
def profiles(root:Path)->dict[str,Any]:
 data=load_cached(root/'.agents/skills/workspace-governance/config/visual-contracts/prompt-compiler-profiles.json','compiler profiles');value=data.get('profiles');require(isinstance(value,dict),'compiler profiles missing');return value
def api_models(root:Path)->dict[str,str]:
 data=load_cached(root/'.agents/skills/image-generation-api/config/api-runtime.json','API profile');return {name:str(v.get('default_model','')) for name,v in data.get('profiles',{}).items() if isinstance(v,dict)}
def execution_support(root:Path,provider:str,model:str,mode:str)->str:
 configured=api_models(root)
 if provider in {'gpt','gemini'}:
  return 'SUPPORTED' if configured.get(provider)==model or (provider=='gpt' and model in {'gpt-image-2','gpt-image-2.5-sunburst','gpt-image-2.5-flare'}) else 'PROMPT_ONLY'
 if provider=='seedance' and model==configured.get('seedance') and mode in {'text_to_video','image_to_video_first_frame','image_to_video_first_last_frame','reference_to_video'}:return 'SUPPORTED'
 return 'PROMPT_ONLY'
def select_profile(root:Path,provider:str,model:str,mode:str)->str:
 available=profiles(root)
 if provider=='gpt':key='image.gpt-image-2.5.edit.v1' if model.startswith('gpt-image-2.5') and mode=='image_to_image_edit' else 'image.gpt-image-2.5.generate.v1' if model.startswith('gpt-image-2.5') else 'image.gpt-image-2.generate.v1' if model=='gpt-image-2' else 'image.gpt-image.v1'
 elif provider=='gemini':key='image.gemini-image.generate.v1'
 elif model.startswith('seedance-2.5'):key='motion.seedance-2.5.v1'
 else:key='motion.seedance-2.0.v1'
 require(key in available,f'compiler profile missing: {key}');return key
def references(root:Path,raw:Any)->list[dict[str,Any]]:
 require(isinstance(raw,list),'references must be an array');out=[]
 for i,item in enumerate(raw):
  require(isinstance(item,dict),'reference item must be an object');path=workspace_path(root,str(item.get('source_path','')));require(path.is_file(),f'reference file missing: {path}');position=item.get('input_position',i);require(isinstance(position,int) and position>=0,'reference input_position invalid');role=str(item.get('role','')).strip();require(role,'reference role is required')
  out.append({'ordinal':i+1,'role':role,'source_path':rel(root,path),'source_sha256':sha(path),'input_position':position})
 require([x['input_position'] for x in out]==list(range(len(out))),'reference input positions must be contiguous and ordered')
 return out
def sentence_list(value:Any,label:str)->str:
 require(isinstance(value,list) and all(isinstance(x,str) and x.strip() for x in value),f'{label} must be non-empty string array');return '; '.join(x.strip() for x in value)
def compile_text(provider:str,model:str,mode:str,data:dict[str,Any],refs:list[dict[str,Any]])->str:
 scene=str(data.get('scene','')).strip();require(scene,'scene is required')
 protected=sentence_list(data.get('protected_truth',[]),'protected_truth');must_show=sentence_list(data.get('must_show',[]),'must_show');must_not_change=sentence_list(data.get('must_not_change',[]),'must_not_change');allowed=sentence_list(data.get('allowed_changes',[]),'allowed_changes')
 ref_lines=[f"Reference {item['ordinal']} (input {item['input_position'] + 1}) is only for {item['role']}. Do not inherit unrelated identity, text, brand, or scene facts from it." for item in refs]
 if provider=='gpt':
  lead='Modify only the requested change.' if mode=='image_to_image_edit' else 'Create one complete, production-ready image.'
  lines=[lead,f'Primary visual result: {scene}.',f'Must show: {must_show}.',f'Preserve exactly: {protected}; {must_not_change}.',f'Allow only necessary derived changes: {allowed}.',*ref_lines,'Keep identity, spatial relationships, camera, material response, light logic and reading hierarchy coherent. Do not add unsupported objects, text, logos, UI, or decorative detail.']
 elif provider=='gemini':
  lines=['Create or edit the image directly and concisely.',f'Task and primary read: {scene}.',f'Exact protected facts: {protected}.',f'Required visible result: {must_show}.',f'Change only: {allowed}. Do not change: {must_not_change}.',*ref_lines,'Keep the approved identity and spatial relationship stable; use only task-relevant detail.']
 else:
  duration=data.get('duration_seconds');require(isinstance(duration,int) and duration>0,'Seedance duration_seconds must be positive integer')
  timeline=data.get('timeline',[]);require(isinstance(timeline,list) and timeline,'Seedance timeline is required')
  lines=[f'Create one continuous {duration}-second video. Task: {scene}.',f'Protected identity and existing facts: {protected}.',f'Required visible result: {must_show}.',*ref_lines]
  if model.startswith('seedance-2.5'):
   previous=0
   for item in timeline:
    require(isinstance(item,dict),'timeline item invalid');start,end=item.get('start'),item.get('end');text=str(item.get('description','')).strip();require(isinstance(start,int) and isinstance(end,int) and 0<=start<end<=duration and start>=previous and text,'Seedance 2.5 timeline must use ordered in-range integer seconds');previous=end;lines.append(f'{start}s–{end}s: {text}.')
  else:
   for item in timeline:
    require(isinstance(item,dict) and isinstance(item.get('description'),str) and item['description'].strip(),'Seedance 2.0 timeline requires ordered event description');require('s' not in str(item.get('time','')).lower(),'Seedance 2.0 must not receive strict integer-second timing syntax');lines.append(item['description'].strip()+'.')
  lines += [f'Allow only: {allowed}. Do not change: {must_not_change}.', 'Use camera, sound, dialogue, material and light only when explicitly required by the task; preserve continuity and do not reset the scene.']
 return '\n'.join(lines)+'\n'
def validate_package(root:Path,path:Path)->dict[str,Any]:
 value=load(path,'final prompt package');required={'schema_version','compiler_profile','provider_profile','model_id','task_mode','execution_support','reference_bindings','prompt_pack_path','prompt_pack_sha256','prompt_text_path','prompt_sha256','parameters','validation'};require(required<=set(value) and value.get('schema_version')=='sicza.final-prompt.v1','final prompt package schema invalid');require(value['execution_support'] in {'SUPPORTED','PROMPT_ONLY','UNSUPPORTED'},'execution support invalid');prompt=workspace_path(root,str(value['prompt_text_path']));require(prompt.is_file() and sha(prompt)==value['prompt_sha256'],'final prompt bytes are stale');refs=references(root,value['reference_bindings']);require(refs==value['reference_bindings'],'reference package bindings are not canonical');profile=profiles(root).get(value['compiler_profile']);require(isinstance(profile,dict),'unknown compiler profile');pack=workspace_path(root,str(profile.get('prompt_pack','')));require(pack.is_file() and value.get('prompt_pack_path')==profile['prompt_pack'] and value.get('prompt_pack_sha256')==sha(pack),'selected prompt pack binding is stale');require(value.get('validation',{}).get('lint')=='PASS','final prompt lint failed');return value
def compile_package(root:Path,input_path:Path,output_dir:Path)->dict[str,Any]:
 data=load(input_path,'compiler input');provider=str(data.get('provider_profile','')).strip();model=str(data.get('model_id','')).strip();mode=str(data.get('task_mode','')).strip();require(provider in {'gpt','gemini','seedance'} and model and mode,'provider_profile, model_id and task_mode are required');refs=references(root,data.get('references',[]));profile=select_profile(root,provider,model,mode);profile_data=profiles(root)[profile];pack=workspace_path(root,profile_data['prompt_pack']);require(pack.is_file(),'selected prompt pack missing');source_prompt=data.get('source_prompt_path')
 if source_prompt is None:text=compile_text(provider,model,mode,data,refs)
 else:
  source=workspace_path(root,str(source_prompt));require(source.is_file(),'source_prompt_path missing');text=source.read_text(encoding='utf-8');require(text.strip(),'source_prompt_path is empty')
 output_dir.mkdir(parents=True,exist_ok=True);prompt=output_dir/'final-prompt.txt';prompt.write_text(text,encoding='utf-8');spec_path=data.get('visual_spec_path');spec_hash=None
 if spec_path:
  spec=workspace_path(root,str(spec_path));require(spec.is_file(),'visual_spec_path missing');spec_hash=sha(spec)
 package={'schema_version':'sicza.final-prompt.v1','compiler_profile':profile,'provider_profile':provider,'model_id':model,'task_mode':mode,'execution_support':execution_support(root,provider,model,mode),'reference_bindings':refs,'prompt_pack_path':profile_data['prompt_pack'],'prompt_pack_sha256':sha(pack),'prompt_text_path':rel(root,prompt),'prompt_sha256':sha(prompt),'visual_spec_sha256':spec_hash,'parameters':data.get('parameters',{}),'validation':{'lint':'PASS','semantic_review':'PENDING'}};require(isinstance(package['parameters'],dict),'parameters must be an object');path=output_dir/'final-prompt-package.json';write(path,package);validate_package(root,path);return {'status':'compiled','package_path':rel(root,path),'prompt_path':rel(root,prompt),'execution_support':package['execution_support'],'compiler_profile':profile}
def main()->int:
 ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest='command',required=True);p=sub.add_parser('compile');p.add_argument('--input',required=True,type=Path);p.add_argument('--output-dir',required=True,type=Path);p.add_argument('--workspace-root',type=Path,default=ROOT);p=sub.add_parser('validate');p.add_argument('--package',required=True,type=Path);p.add_argument('--workspace-root',type=Path,default=ROOT);a=ap.parse_args()
 try:out=compile_package(a.workspace_root.resolve(),a.input.resolve(),a.output_dir.resolve()) if a.command=='compile' else {'status':'passed','package':validate_package(a.workspace_root.resolve(),a.package.resolve())['compiler_profile']};print(json.dumps(out,ensure_ascii=False,indent=2));return 0
 except (PromptError,OSError,ValueError,json.JSONDecodeError) as e:print(json.dumps({'status':'blocked','reason':str(e)},ensure_ascii=False));return 1
if __name__=='__main__':raise SystemExit(main())
