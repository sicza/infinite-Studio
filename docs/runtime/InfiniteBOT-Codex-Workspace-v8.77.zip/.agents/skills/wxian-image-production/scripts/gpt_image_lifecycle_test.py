#!/usr/bin/env python3
"""Offline regression for GPT call-receipt binding across record, confirm, and delivery."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import shutil
import sys
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ValueError(f"cannot load module: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def expect_block(label: str, action) -> None:
    try:
        action()
    except (OSError, ValueError, json.JSONDecodeError):
        return
    raise ValueError(f"negative regression did not block: {label}")


def run(runtime_root: Path) -> dict:
    runtime_root = runtime_root.resolve()
    scripts = runtime_root / ".agents/skills/wxian-image-production/scripts"
    if str(scripts) not in sys.path:
        sys.path.insert(0, str(scripts))
    candidate = load_module(scripts / "candidate_tracker.py", "gpt_lifecycle_candidate_tracker")
    delivery = load_module(scripts / "delivery_gate.py", "gpt_lifecycle_delivery_gate")
    nameplate_gate = load_module(scripts / "nameplate_artwork_gate.py", "gpt_lifecycle_nameplate_gate")
    request_identity = load_module(runtime_root / ".agents/lib/request_identity.py", "gpt_lifecycle_request_identity")
    contract = load_module(runtime_root / ".agents/lib/gpt_image_contract.py", "gpt_lifecycle_contract")
    import visual_contracts

    def prepare_independent_review(root: Path, request: Path, source: Path) -> Path:
        work = request / "work"
        write_json(request / "state.json", {"primary_skill": "wxian-image-production", "status": "active", "revision": 1})
        lock = work / "requirement-lock.md"
        lock.write_text("production_branch: new-generation\n", encoding="utf-8")
        identity = request_identity.identity(root, request)
        spec = {
            "schema_version": "sicza.visual-spec.v2", **identity,
            "profile_id": "visual.still.production.v1", "mode": "CREATE", "task_kind": "still",
            "authority_trace": [{"role": "current_request", "path": request.joinpath("request.md").relative_to(root).as_posix(), "sha256": candidate.sha(request / "request.md")}],
            "narrative_trace": None,
            "intent": {"primary": "display the requested generated subject clearly", "visual_logic": "display"},
            "truth_protection": {"protect": ["original user request"]}, "world_space": {"space": "one coherent scene"},
            "performance": {}, "projection": {"camera": "stable readable projection"}, "appearance": {"surface": "coherent material response"},
            "image_structure": {"hierarchy": "single unambiguous first read"}, "image_formation": {"focus": "controlled focus hierarchy"},
            "graphic": {}, "identity": {"lock": "preserve requested subject"},
            "channel_roles": {"lead": ["identity"], "support": ["projection"], "suppress": ["background detail"]},
            "motion": None, "change_set": {}, "success_condition": ["subject remains readable at thumbnail size"], "unresolved": []
        }
        spec_path = work / "visual-spec.json"; write_json(spec_path, spec)
        prompt = work / "prompt-package.md"
        prompt.write_text("display display the requested generated subject clearly identity projection background detail\n", encoding="utf-8")
        profile = visual_contracts.registry("prompt-compiler-profiles.json", "sicza.prompt-compiler-profiles.v1")["image.generic.v1"]
        pack_rel = Path(profile["prompt_pack"]); pack = root / pack_rel; pack.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(runtime_root / pack_rel, pack)
        binding = {
            "schema_version": "sicza.prompt-binding.v2", **identity,
            "visual_spec_path": spec_path.relative_to(root).as_posix(), "visual_spec_sha256": candidate.sha(spec_path),
            "narrative_semantic_checksum": None, "prompt_path": prompt.relative_to(root).as_posix(), "prompt_sha256": candidate.sha(prompt),
            "compiler_profile": "image.generic.v1", "adapter_family": profile["adapter_family"],
            "prompt_pack_path": pack_rel.as_posix(), "prompt_pack_sha256": candidate.sha(pack),
            "spec_consumption": [
                {"field": "intent.visual_logic", "value": "display", "prompt_evidence": ["display"]},
                {"field": "intent.primary", "value": "display the requested generated subject clearly", "prompt_evidence": ["display the requested generated subject clearly"]},
                {"field": "channel_roles.lead", "value": ["identity"], "prompt_evidence": ["identity"]},
                {"field": "channel_roles.support", "value": ["projection"], "prompt_evidence": ["projection"]},
                {"field": "channel_roles.suppress", "value": ["background detail"], "prompt_evidence": ["background detail"]},
            ],
        }
        binding_path = work / "prompt-binding.json"; write_json(binding_path, binding)
        source_bindings = [
            {"role": "current_request", "path": (request / "request.md").relative_to(root).as_posix(), "sha256": candidate.sha(request / "request.md")},
            {"role": "requirement_lock", "path": lock.relative_to(root).as_posix(), "sha256": candidate.sha(lock)},
        ]
        reference_plan = work / "reference-plan.json"
        if reference_plan.is_file():
            source_bindings.append({"role": "reference_plan", "path": reference_plan.relative_to(root).as_posix(), "sha256": candidate.sha(reference_plan)})
            for item in json.loads(reference_plan.read_text(encoding="utf-8"))["sources"]:
                ref_source = root / item["source_path"]
                source_bindings.append({"role": "reference_source", "path": ref_source.relative_to(root).as_posix(), "sha256": candidate.sha(ref_source)})
                if item.get("analysis_path"):
                    ref_analysis = root / item["analysis_path"]
                    source_bindings.append({"role": "reference_analysis", "path": ref_analysis.relative_to(root).as_posix(), "sha256": candidate.sha(ref_analysis)})
        report = {
            "schema_version": "sicza.visual-independent-review.v2", **identity,
            "reviewer_id": "independent-gpt-lifecycle-reviewer", "producer_id": "gpt-lifecycle-producer",
            "target_path": source.relative_to(root).as_posix(), "target_sha256": candidate.sha(source),
            "visual_spec_sha256": candidate.sha(spec_path), "prompt_binding_sha256": candidate.sha(binding_path),
            "review_methods": ["sicza-visual-director/DIAGNOSE"],
            "source_bindings": source_bindings,
            "verdict": "PASS",
            "review_narrative": "The independent reviewer inspected the exact full-resolution candidate and its thumbnail against the untouched request before consulting the producer specification, then found no primary-read, hierarchy, relationship, physical-integrity, or delivery-fitness defect in this synthetic lifecycle fixture.",
            "observations": ["The exact candidate remains a single coherent display at both full and thumbnail inspection sizes."],
        }
        report_path = source.with_name(source.name + ".independent-review.json"); write_json(report_path, report)
        return report_path

    with tempfile.TemporaryDirectory() as temp_dir:
        root = Path(temp_dir).resolve()
        request = root / "requests/image-generation/gpt-lifecycle"
        work = request / "work"
        work.mkdir(parents=True)
        request_text = "请用gpt生图，4K，PNG透明底，16:9，无需确认。"
        request_source = request / "request.md"
        request_source.write_text(request_text, encoding="utf-8")
        write_json(request / "state.json", {"primary_skill": "wxian-image-production", "status": "active", "revision": 1})
        source = work / "master.png"
        Image.new("RGB", (3840, 2160), (24, 48, 72)).save(source, format="PNG", optimize=True)
        source_rel = source.relative_to(root).as_posix()
        source_sha = candidate.sha(source)
        resolved = contract.resolve_gpt_request(request_text, aspect_ratio="1:1")
        resolved_sha = hashlib.sha256(
            json.dumps(resolved, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        call = {
            "status": "success",
            "network_called": True,
            "api_profile": "gpt",
            "mode": "text_to_image",
            "model": resolved["model"],
            "parameters": resolved["parameters"],
            "reference_images": [],
            "output_path": source_rel,
            "output_sha256": source_sha,
            "gpt_intent_binding": {
                "request_path": request_source.relative_to(root).as_posix(),
                "request_sha256": candidate.sha(request_source),
                "resolved": resolved,
                "resolved_sha256": resolved_sha,
            },
        }
        call_path = source.with_name(source.name + ".call.json")
        write_json(call_path, call)
        review = {field: True for field in candidate.REVIEW_BOOL_FIELDS}
        review.update({"artifact_risk": "low", "decision": "accept", "reject_reason": "", "next_action": ""})
        write_json(source.with_name(source.name + ".review.json"), review)
        reference_dir = request / "input"; reference_dir.mkdir()
        reference_source = reference_dir / "composition-reference.png"
        Image.new("RGB", (320, 240), (96, 64, 32)).save(reference_source, format="PNG")
        reference_analysis = work / "composition-reference-analysis.md"
        reference_analysis.write_text("Visible fact: one dominant subject relationship. Transferable core: preserve the observed hierarchy rather than copy the surface object.\n", encoding="utf-8")
        write_json(work / "reference-plan.json", {"sources": [{"source_path": reference_source.relative_to(root).as_posix(), "source_sha256": candidate.sha(reference_source), "role": "composition", "analysis": "full-reverse", "use": "visual_only", "analysis_path": reference_analysis.relative_to(root).as_posix()}]})
        independent_report = prepare_independent_review(root, request, source)
        independent_bytes = independent_report.read_bytes()
        # V8.72: professional visual review is optional diagnostic evidence, not a gate.
        recorded = candidate.record(root, request, source_rel, "formal")
        if recorded.get("candidate", {}).get("independent_review"):
            raise ValueError("record reported an independent review that was never supplied")
        if recorded.get("candidate", {}).get("legacy_intent") is not True:
            raise ValueError("a call without intent_binding must be recorded as legacy_intent")
        self_review = json.loads(independent_report.read_text(encoding="utf-8"))
        self_review["reviewer_id"] = self_review["producer_id"]
        write_json(independent_report, self_review)
        try:
            candidate.bind_optional_review(root, request, source, review, independent_report.relative_to(root).as_posix())
        except candidate.CandidateError:
            pass
        else:
            raise ValueError("a supplied independent review may not be the producer itself")
        independent_report.write_bytes(independent_bytes)
        poisoned = json.loads(independent_report.read_text(encoding="utf-8"))
        poisoned["source_bindings"] = [item for item in poisoned["source_bindings"] if item.get("role") != "current_request"]
        write_json(independent_report, poisoned)
        try:
            candidate.bind_optional_review(root, request, source, review, independent_report.relative_to(root).as_posix())
        except candidate.CandidateError:
            pass
        else:
            raise ValueError("a supplied independent review may ignore the untouched original request")
        poisoned = json.loads(independent_bytes.decode("utf-8"))
        poisoned["source_bindings"] = [item for item in poisoned["source_bindings"] if item.get("role") != "reference_analysis"]
        write_json(independent_report, poisoned)
        try:
            candidate.bind_optional_review(root, request, source, review, independent_report.relative_to(root).as_posix())
        except candidate.CandidateError:
            pass
        else:
            raise ValueError("a supplied independent review may ignore a full-reverse Reference analysis")
        independent_report.write_bytes(independent_bytes)
        call_bytes = call_path.read_bytes()
        call_path.write_text("{}\n", encoding="utf-8")
        expect_block(
            "candidate confirm accepts a tampered call receipt",
            lambda: candidate.confirm(root, request, recorded["candidate"]["id"], "auto_authorized", "无需确认"),
        )
        call_path.write_bytes(call_bytes)
        candidate.confirm(root, request, recorded["candidate"]["id"], "auto_authorized", "无需确认")

        changed = json.loads(call_path.read_text(encoding="utf-8"))
        changed["service_request_id"] = "tampered-after-confirm"
        write_json(call_path, changed)
        expect_block(
            "delivery accepts a call receipt changed after confirmation",
            lambda: delivery.confirmed_candidate(root, request),
        )
        call_path.write_bytes(call_bytes)

        def make_extra_round(name: str) -> Path:
            extra = work / f"{name}.png"
            Image.new("RGB", (3840, 2160), (32, 64, 96)).save(extra, format="PNG")
            extra_call = dict(call)
            extra_call["output_path"] = extra.relative_to(root).as_posix()
            extra_call["output_sha256"] = candidate.sha(extra)
            write_json(extra.with_name(extra.name + ".call.json"), extra_call)
            write_json(extra.with_name(extra.name + ".review.json"), review)
            prepare_independent_review(root, request, extra)
            return extra

        # The round count is a cost guard, not a verdict: passing it requires a diagnosed root cause.
        candidate.record(root, request, make_extra_round("round2").relative_to(root).as_posix(), "formal")
        candidate.record(root, request, make_extra_round("round3").relative_to(root).as_posix(), "formal")
        fourth = make_extra_round("round4").relative_to(root).as_posix()
        expect_block(
            "formal round guard is passed without a diagnosed root cause",
            lambda: candidate.record(root, request, fourth, "formal"),
        )
        expect_block(
            "formal round guard accepts a restated prompt instead of a root cause",
            lambda: candidate.record(root, request, fourth, "formal", round_reason="再试一次看效果"),
        )
        extended = candidate.record(
            root, request, fourth, "formal",
            round_reason="root cause: the working prompt dropped the locked aspect; now the intent binding is rebuilt from request.md",
        )
        if extended.get("candidate", {}).get("round_guard") != "extended_with_root_cause":
            raise ValueError("a round past the cost guard must be recorded as extended with a root cause")
        delivery.confirmed_candidate(root, request)

        call_path.unlink()
        expect_block(
            "4K master bypasses missing call evidence",
            lambda: delivery.require_master_quality(root, source, "3840x2160", 3840, "4K GPT master"),
        )
        call_path.write_bytes(call_bytes)
        delivery.require_master_quality(root, source, "3840x2160", 3840, "4K GPT master")

        override_request = root / "requests/image-generation/gpt-explicit-overrides"
        override_work = override_request / "work"
        override_work.mkdir(parents=True)
        override_text = "请用gpt生图，无需确认。"
        override_source_text = override_request / "request.md"
        override_source_text.write_text(override_text, encoding="utf-8")
        write_json(override_request / "state.json", {"primary_skill": "wxian-image-production", "status": "active", "revision": 1})
        override_source = override_work / "master.png"
        Image.new("RGB", (2048, 1152), (72, 48, 24)).save(override_source, format="PNG", optimize=True)
        override_parameters = {
            "size": "2048x1152",
            "quality": "high",
            "background": "auto",
            "moderation": "low",
            "output_format": "png",
        }
        override_resolved = contract.validate_resolved_gpt_request(
            override_text, contract.GPT_IMAGE_25_FLARE, override_parameters, aspect_ratio="1:1"
        )
        override_resolved_sha = hashlib.sha256(
            json.dumps(override_resolved, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        override_call = {
            "status": "success",
            "network_called": True,
            "api_profile": "gpt",
            "mode": "text_to_image",
            "model": contract.GPT_IMAGE_25_FLARE,
            "parameters": override_resolved["parameters"],
            "reference_images": [],
            "output_path": override_source.relative_to(root).as_posix(),
            "output_sha256": candidate.sha(override_source),
            "gpt_intent_binding": {
                "request_path": override_source_text.relative_to(root).as_posix(),
                "request_sha256": candidate.sha(override_source_text),
                "resolved": override_resolved,
                "resolved_sha256": override_resolved_sha,
            },
        }
        write_json(override_source.with_name(override_source.name + ".call.json"), override_call)
        write_json(override_source.with_name(override_source.name + ".review.json"), review)
        prepare_independent_review(root, override_request, override_source)
        override_recorded = candidate.record(
            root, override_request, override_source.relative_to(root).as_posix(), "formal"
        )
        candidate.confirm(
            root, override_request, override_recorded["candidate"]["id"], "auto_authorized", "无需确认"
        )
        delivery.confirmed_candidate(root, override_request)

        nameplate_request = root / "requests/image-generation/nameplate-delivery"
        nameplate_work = nameplate_request / "work"
        nameplate_work.mkdir(parents=True)
        (nameplate_request / "request.md").write_text("制作职业铭牌。", encoding="utf-8")
        write_json(nameplate_request / "state.json", {"primary_skill": "wxian-image-production", "status": "active", "revision": 1})
        (nameplate_work / "requirement-lock.md").write_text("source_demand_type: 铭牌\nvisual_variant: ui_nameplate_asset\n", encoding="utf-8")
        nameplate_identity = request_identity.identity(root, nameplate_request)
        nameplate_spec = {
            "schema_version": "sicza.visual-spec.v2", **nameplate_identity,
            "profile_id": "visual.still.production.v1", "mode": "CREATE", "task_kind": "still",
            "authority_trace": [{"role": "current_request", "path": nameplate_request.joinpath("request.md").relative_to(root).as_posix(), "sha256": candidate.sha(nameplate_request / "request.md")}],
            "narrative_trace": None,
            "intent": {"primary": "recognizable horizontal nameplate asset", "visual_logic": "graphic_asset"},
            "truth_protection": {"protect": ["locked project identity"]}, "world_space": {"space": "flat UI asset surface"},
            "performance": {}, "projection": {"composition": "horizontal carrier"}, "appearance": {"finish": "controlled material response"},
            "image_structure": {"hierarchy": "readable at small size"}, "image_formation": {"focus": "crisp edge hierarchy"},
            "graphic": {"shape_language": "layered angular frame", "palette_roles": "dark base, bright accent", "motifs": "class crest abstraction", "safe_zone": "clear centered title zone"},
            "identity": {"lock": "preserve project identity"}, "channel_roles": {"lead": ["graphic"], "support": ["identity"], "suppress": ["scene detail"]},
            "motion": None, "change_set": {}, "success_condition": ["title zone remains readable"], "unresolved": []
        }
        write_json(nameplate_work / "visual-spec.json", nameplate_spec)
        nameplate_gate.validate(root, nameplate_request, require_visual_spec=True)
        (nameplate_work / "requirement-lock.md").write_text("source_demand_type: 角色铭牌\nvisual_variant: ui_nameplate_asset\n", encoding="utf-8")
        alias_spec = dict(nameplate_spec); alias_spec.update(request_identity.identity(root, nameplate_request))
        write_json(nameplate_work / "visual-spec.json", alias_spec)
        alias_result = nameplate_gate.validate(root, nameplate_request, require_visual_spec=True)
        if alias_result.get("status") != "passed" or alias_result.get("source_demand_type") != "铭牌":
            raise ValueError("nameplate alias did not retain the canonical nameplate treatment")
        (nameplate_work / "requirement-lock.md").write_text("source_demand_type: 铭牌\nvisual_variant: ui_nameplate_asset\n", encoding="utf-8")
        invalid_nameplate_spec = dict(nameplate_spec); invalid_nameplate_spec["graphic"] = dict(nameplate_spec["graphic"]); invalid_nameplate_spec["graphic"].pop("safe_zone")
        write_json(nameplate_work / "visual-spec.json", invalid_nameplate_spec)
        expect_block("nameplate accepts missing graphic safe zone", lambda: nameplate_gate.validate(root, nameplate_request, require_visual_spec=True))
        write_json(nameplate_work / "visual-spec.json", nameplate_spec)
        if delivery.presenting_variant(nameplate_request) != "ui_nameplate_asset" or "ui_nameplate_asset" not in delivery.PRESENTING_VARIANTS:
            raise ValueError("nameplate visual variant is not covered by the final-picture delivery gate")
        complete = nameplate_work / "complete-nameplate.png"
        complete_image = Image.new("RGB", (120, 80))
        complete_image.putdata([(x * 2, y * 3, (x + y) % 255) for y in range(80) for x in range(120)])
        complete_image.save(complete)
        delivery.require_presenting_picture(complete, "complete nameplate")
        rounded = nameplate_work / "rounded-nameplate.png"
        rounded_image = Image.new("RGB", (240, 160), "white")
        ImageDraw.Draw(rounded_image).rounded_rectangle([0, 0, 239, 159], radius=40, fill=(90, 96, 104))
        rounded_image.save(rounded)
        expect_block("nameplate delivery accepts baked rounded carrier mask", lambda: delivery.require_presenting_picture(rounded, "rounded nameplate"))
        flat_field_cross = nameplate_work / "flat-field-cross-nameplate.png"
        flat_field_image = Image.new("RGB", (120, 80), "white")
        flat_draw = ImageDraw.Draw(flat_field_image); flat_draw.line((60, 0, 60, 79), fill="black", width=5); flat_draw.line((0, 40, 119, 40), fill="black", width=5)
        flat_field_image.save(flat_field_cross)
        flattened = delivery.require_presenting_picture(flat_field_cross, "flat-field nameplate")
        if not isinstance(flattened, dict) or flattened.get("corner_plate") or not flattened.get("presentation_risk"):
            raise ValueError("a flat-field cross composition must be released with a non-blocking risk, and the "
                             "delivery gate must hand the observation back instead of discarding it")

    return {
        "status": "passed",
        "cases": [
            "confirm-rejects-tampered-call-receipt",
            "review-is-optional-evidence",
            "supplied-self-review-blocked",
            "supplied-review-requires-original-request",
            "supplied-review-requires-reference-analysis",
            "delivery-rejects-post-confirm-call-drift",
            "4k-master-requires-call-and-intent-evidence",
            "explicit-legal-overrides-survive-record-confirm-delivery",
            "nameplate-variant-requires-complete-final-picture",
            "nameplate-source-lock-requires-graphic-asset-and-safe-zone",
            "nameplate-alias-retains-canonical-treatment",
            "baked-rounded-nameplate-blocked",
            "flat-field-cross-nameplate-released-with-risk",
            "round-guard-requires-diagnosed-root-cause",
            "round-guard-rejects-restated-prompt",
            "round-guard-records-root-cause-extension",
        ],
        "network_called": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime-root", type=Path, default=Path(__file__).resolve().parents[4])
    args = parser.parse_args()
    try:
        result = run(args.runtime_root)
        code = 0
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        result = {"status": "failed", "reason": str(exc), "network_called": False}
        code = 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
