#!/usr/bin/env python3
"""Record non-overwriting generation rounds and the one confirmed candidate pointer.

V8.72: candidate evidence binds a stable request intent snapshot instead of the
whole request.md hash. Approvals are recorded as independent events in
work/approvals.jsonl; appending an approval never invalidates the generated
candidate. Professional visual review is optional evidence, never a mandatory
aesthetic gate.
"""
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path
try:
    from PIL import Image
except ImportError:
    Image=None

LIB=Path(__file__).resolve().parents[3]/'lib'
if str(LIB) not in sys.path: sys.path.insert(0,str(LIB))
from gpt_image_contract import formal_quality_is_valid, validate_gpt_call_intent_binding, validate_gpt_model, validate_gpt_size
from request_intent import RequestIdentityError, RequestIntentError, intent_identity, legacy_candidate_intent
from production_contract import visual_spec_required
from visual_contracts import VisualContractError, validate_independent_visual_review

MAX_ROUNDS={'formal':3,'revision':2}
REAL_MODEL_KINDS={'formal','revision','validation','smoke'}
MAX_QUALITY_KINDS={'formal','revision','validation'}
REVIEW_BOOL_FIELDS=('subject_correct','composition_correct','style_matched','placeholder_clean','no_fake_logo_icon_text')
REVIEW_DECISIONS={'accept','retry','return_to_prompt_pack','return_to_requirement_doc','blocked'}
REVIEW_ARTIFACT_RISKS={'low','medium','high'}
class CandidateError(ValueError): pass

def require(c,m):
    if not c: raise CandidateError(m)

def sha(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def bounded(root:Path,v:str|Path,exist=False)->Path:
    p=Path(v); p=(root/p if not p.is_absolute() else p).resolve(); require(p==root or root in p.parents,'path escapes Workspace')
    if exist: require(p.exists(),f'path missing: {v}')
    return p

def rel(root:Path,p:Path)->str: return p.relative_to(root).as_posix()

def req(root:Path,v:str)->Path:
    p=bounded(root,v,True); parts=p.relative_to(root).parts; require(len(parts)==3 and parts[0]=='requests','request must be requests/<type>/<name>'); return p

def load(path:Path,default):
    if not path.exists(): return default
    x=json.loads(path.read_text(encoding='utf-8')); require(isinstance(x,dict),'candidate index invalid'); return x

def write_json(path:Path,x): path.parent.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def load_review(root:Path, review_v:str)->dict:
    path=bounded(root,review_v,True); require(path.is_file(),'candidate review must be a JSON file')
    review=load(path,{})
    required=set(REVIEW_BOOL_FIELDS)|{'artifact_risk','decision','reject_reason','next_action'}
    require(set(review)==required,'candidate review schema invalid')
    for field in REVIEW_BOOL_FIELDS: require(isinstance(review[field],bool),f'candidate review {field} must be boolean')
    risk=str(review['artifact_risk']).strip(); decision=str(review['decision']).strip()
    require(risk in REVIEW_ARTIFACT_RISKS,'candidate review artifact_risk must be low|medium|high')
    require(decision in REVIEW_DECISIONS,'candidate review decision is invalid')
    reject=str(review['reject_reason']).strip(); next_action=str(review['next_action']).strip()
    if decision=='accept':
        require(all(review[field] for field in REVIEW_BOOL_FIELDS),'accepted candidate requires every professional self-check boolean=true')
        require(risk in {'low','medium'},'accepted candidate cannot have high artifact risk')
        require(not reject,'accepted candidate must not carry reject_reason')
    else:
        require(bool(reject),f'{decision} candidate review requires reject_reason')
        require(bool(next_action),f'{decision} candidate review requires next_action')
    return {field:review[field] for field in REVIEW_BOOL_FIELDS}|{'artifact_risk':risk,'decision':decision,'reject_reason':reject,'next_action':next_action}

def validate_candidate_call(root:Path,r:Path,source:Path,source_hash:str,kind:str,call_ref:str|None=None)->dict:
    expected=source.with_name(source.name+'.call.json')
    call_path=bounded(root,call_ref,True) if call_ref else expected
    require(call_path==expected,f'{kind} candidate call record path does not match source')
    require(call_path.is_file(),f'{kind} candidate requires real generation API call record: {rel(root,call_path)}')
    call=load(call_path,{})
    require(call.get('status')=='success' and call.get('network_called') is True,f'{kind} candidate call record must prove a successful real network model call')
    require(call.get('output_path')==rel(root,source),f'candidate call output_path does not match source: {rel(root,source)}')
    require(call.get('output_sha256')==source_hash,f'candidate call output hash does not match source: {rel(root,source)}')
    require(str(call.get('api_profile','')).strip() in {'gemini','gpt'},f'{kind} image candidate must come from an image generation/edit profile')
    require(bool(str(call.get('model','')).strip()),'candidate call record requires model')
    params=call.get('parameters')
    require(isinstance(params,dict),'candidate call record requires parameters')
    if call.get('api_profile')=='gemini':
        quality=str(params.get('quality','')).lower(); require(quality=='4k',f'{kind} Gemini candidate requires quality=4k in call evidence')
        ratio=str(params.get('size','')).strip(); require(bool(ratio) and ':' in ratio,f'{kind} Gemini candidate requires size=<aspect ratio> in call evidence')
    else:
        size=str(params.get('size','')).strip()
        model=str(call.get('model','')).strip(); quality=str(params.get('quality','')).lower()
        try:
            validate_gpt_model(model); validate_gpt_size(model,size)
        except ValueError as exc:
            raise CandidateError(str(exc)) from exc
        require(formal_quality_is_valid(model,quality),
                f'{kind} GPT candidate quality is unsupported for the selected model')
    request_source=r/'request.md'; require(request_source.is_file(),'candidate requires request.md intent source')
    identity=intent_identity(root,r)
    legacy_intent=False
    binding=call.get('intent_binding')
    if isinstance(binding,dict):
        require(binding.get('schema')==identity['schema'],'candidate call intent binding schema mismatch')
        require(binding.get('intent_fingerprint')==identity['intent_fingerprint'],
                'candidate call intent is stale for the current request intent')
        if call.get('api_profile')=='gpt':
            try:
                validate_gpt_call_intent_binding(call,request_source.read_text(encoding='utf-8'),rel(root,request_source),
                                                 sha(request_source),aspect_ratio=None if call.get('mode')=='image_to_image_edit' else '1:1',
                                                 intent_fingerprint=identity['intent_fingerprint'])
            except ValueError as exc:
                raise CandidateError(str(exc)) from exc
    else:
        legacy_intent=True
        if call.get('api_profile')=='gpt':
            try:
                validate_gpt_call_intent_binding(call,request_source.read_text(encoding='utf-8'),rel(root,request_source),
                                                 sha(request_source),aspect_ratio=None if call.get('mode')=='image_to_image_edit' else '1:1',
                                                 intent_fingerprint=None,allow_legacy=True)
            except ValueError as exc:
                raise CandidateError(str(exc)) from exc
    refs=call.get('reference_images')
    require(isinstance(refs,list) and all(isinstance(x,str) for x in refs),'candidate call record requires reference_images evidence')
    if Image is not None and source.suffix.lower() in {'.png','.jpg','.jpeg','.webp'}:
        with Image.open(source) as im:
            if kind in MAX_QUALITY_KINDS and call.get('api_profile')=='gemini':
                require(max(im.width, im.height) >= 3800, f'{kind} Gemini candidate must be a 4K-class source, got {im.width}x{im.height}')
            if kind in MAX_QUALITY_KINDS and call.get('api_profile')=='gpt':
                size=str(params.get('size','')).strip()
                if size!='auto':
                    ew,eh=(int(v) for v in size.split('x'))
                    require((im.width,im.height)==(ew,eh),f'{kind} GPT candidate dimensions must match size={size}, got {im.width}x{im.height}')
                else:
                    require(max(im.width,im.height)>=1024,f'{kind} GPT auto candidate is unexpectedly below model-native output class: {im.width}x{im.height}')
    result={'call_record':rel(root,call_path),'call_sha256':sha(call_path),'legacy_intent':legacy_intent}
    if not legacy_intent: result['intent_fingerprint']=identity['intent_fingerprint']
    return result

def bind_optional_review(root:Path,r:Path,source:Path,review:dict,independent_review_v:str|None)->dict:
    """Professional review is optional evidence; if supplied it must be a real PASS report."""
    if not independent_review_v: return {}
    report_path=bounded(root,independent_review_v,True)
    try:
        report=validate_independent_visual_review(root,report_path,expected_target=source,
                                                  require_visual_spec=visual_spec_required(root,r))
    except VisualContractError as exc:
        raise CandidateError(f'supplied independent professional review is invalid: {exc}') from exc
    require(report.get('verdict')=='PASS','supplied independent professional review must be PASS')
    return {'independent_review':rel(root,report_path),'independent_review_sha256':sha(report_path),
            'independent_reviewer':report['reviewer_id'],'review_methods':report['review_methods']}

def record(root:Path,r:Path,source_v:str,kind:str,direction_id:str|None=None,review_v:str|None=None,independent_review_v:str|None=None,round_reason:str|None=None)->dict:
    source=bounded(root,source_v,True); require(source.is_file() and (r/'work'==source or r/'work' in source.parents),'candidate must be in current request work/')
    source_hash=sha(source)
    call_binding=validate_candidate_call(root,r,source,source_hash,kind) if kind in REAL_MODEL_KINDS else {}
    review=None
    default_review=source.with_name(source.name+'.review.json')
    if review_v: review=load_review(root,review_v)
    elif default_review.is_file(): review=load_review(root,rel(root,default_review))
    independent=bind_optional_review(root,r,source,review or {},independent_review_v)
    index_path=r/'work/candidates.json'; data=load(index_path,{'candidates':[]}); require(set(data)=={'candidates'} and isinstance(data['candidates'],list),'candidate index schema invalid')
    require(all(x.get('source')!=rel(root,source) for x in data['candidates']),'candidate source already recorded')
    if kind in {'validation','smoke'}:
        direction=(direction_id or '').strip(); require(direction,'validation/smoke candidate requires direction_id')
        require(len(direction)<=80 and all(ch.isalnum() or ch in '-_' for ch in direction),'invalid direction_id')
        existing=[x for x in data['candidates'] if x.get('kind')==kind and x.get('direction_id')==direction]
        require(not existing,f'{kind} allows only one candidate per direction: {direction}')
        round_no=1; item={'id':f'{kind}-{direction}-R01','kind':kind,'direction_id':direction,'round':1,'source':rel(root,source),'sha256':source_hash,**call_binding,**independent}
        if review is not None: item['self_check']=review
    else:
        existing=[x for x in data['candidates'] if x.get('kind')==kind]
        reason=str(round_reason or '').strip()
        round_guard=''
        if kind in MAX_ROUNDS and len(existing)>=MAX_ROUNDS[kind]:
            require(reason,f'{kind} generation passed its {MAX_ROUNDS[kind]}-round cost guard: state the diagnosed root cause and what changes this round with --round-reason')
            require(len(reason)>=20,'round reason must name the diagnosed root cause and the concrete change, not restate the prompt')
            round_guard=reason
        round_no=len(existing)+1; item={'id':f'{kind}-R{round_no:02d}','kind':kind,'round':round_no,'source':rel(root,source),'sha256':source_hash,**call_binding,**independent}
        if review is not None: item['self_check']=review
        if reason: item['round_reason']=reason
        if round_guard: item['round_guard']='extended_with_root_cause'
    data['candidates'].append(item); write_json(index_path,data); return {'status':'recorded','candidate':item}

def confirm(root:Path,r:Path,candidate_id:str,mode:str,evidence:str)->dict:
    data=load(r/'work/candidates.json',{'candidates':[]}); matches=[x for x in data.get('candidates',[]) if x.get('id')==candidate_id]; require(len(matches)==1,'candidate id not found or ambiguous')
    item=matches[0]; require(item.get('kind') in {'formal','revision'},'validation/smoke candidate cannot become the confirmed production source')
    source=bounded(root,item['source'],True); require(sha(source)==item['sha256'],'candidate source hash changed')
    call_binding=validate_candidate_call(root,r,source,item['sha256'],str(item['kind']),str(item.get('call_record','')))
    require(item.get('call_sha256')==call_binding['call_sha256'],'candidate call record hash changed after registration')
    call_path=bounded(root,str(item.get('call_record','')),True)
    call_doc=json.loads(call_path.read_text(encoding='utf-8'))
    legacy=legacy_candidate_intent(item,call_doc)
    if not legacy:
        identity=intent_identity(root,r)
        require(str(item.get('intent_fingerprint',''))==identity['intent_fingerprint'],'candidate intent is stale for the current request intent')
    mode=mode.strip(); evidence=evidence.strip(); require(mode in {'user','auto_authorized'},'confirmation mode must be user|auto_authorized'); require(evidence,'confirmation evidence is required')
    if mode=='auto_authorized':
        require(any(token in evidence.lower() for token in ('自动','全自动','无需确认','不用确认','直接做到','auto','without confirmation','no confirmation')),
                'auto authorization evidence must explicitly authorize automatic continuation')
    approval=find_approval(r,candidate_id,mode,evidence)
    if approval is None:
        request_text=(r/'request.md').read_text(encoding='utf-8') if (r/'request.md').is_file() else ''
        require(evidence in request_text,'confirmation evidence must be recorded in work/approvals.jsonl or present in request.md')
        confirmation={'mode':mode,'evidence':evidence,'source':'request.md'}
    else:
        confirmation={'mode':mode,'evidence':evidence,'source':'approvals.jsonl','approval_id':approval.get('approval_id')}
    pointer={'candidate_id':item['id'],'kind':item['kind'],'round':item['round'],'source':item['source'],'sha256':item['sha256'],
             'call_record':call_binding['call_record'],'call_sha256':call_binding['call_sha256'],'confirmation':confirmation}
    if item.get('intent_fingerprint'): pointer['intent_fingerprint']=item['intent_fingerprint']
    if legacy: pointer['legacy_intent']=True
    if item.get('independent_review'):
        pointer.update({'independent_review':item['independent_review'],'independent_review_sha256':item.get('independent_review_sha256'),
                        'independent_reviewer':item.get('independent_reviewer'),'review_methods':item.get('review_methods')})
    write_json(r/'work/confirmed-candidate.json',pointer)
    return {'status':'confirmed',**pointer}

def approvals_path(r:Path)->Path: return r/'work'/'approvals.jsonl'

def read_approvals(r:Path)->list[dict]:
    path=approvals_path(r)
    if not path.is_file(): return []
    rows=[]
    for line in path.read_text(encoding='utf-8').splitlines():
        line=line.strip()
        if not line: continue
        try: item=json.loads(line)
        except json.JSONDecodeError as exc: raise CandidateError(f'invalid approvals.jsonl: {exc}') from exc
        require(isinstance(item,dict),'approval entry must be an object')
        rows.append(item)
    return rows

def find_approval(r:Path,candidate_id:str,mode:str,evidence:str)->dict|None:
    for item in read_approvals(r):
        if item.get('candidate_id')!=candidate_id: continue
        if item.get('mode')!=mode: continue
        if str(item.get('evidence','')).strip()!=evidence.strip(): continue
        return item
    return None

def main():
    ap=argparse.ArgumentParser(description=__doc__); sub=ap.add_subparsers(dest='cmd',required=True)
    rec=sub.add_parser('record'); rec.add_argument('--request',required=True); rec.add_argument('--source',required=True); rec.add_argument('--kind',choices=['formal','revision','validation','smoke'],required=True); rec.add_argument('--direction-id'); rec.add_argument('--review',help='optional JSON producer self-check for this exact candidate'); rec.add_argument('--independent-review',help='optional context-separated professional visual review for this exact candidate'); rec.add_argument('--round-reason',help='diagnosed root cause and the concrete change; required once the formal/revision cost guard is passed'); rec.add_argument('--workspace-root',type=Path,default=Path(__file__).resolve().parents[4])
    sel=sub.add_parser('confirm'); sel.add_argument('--request',required=True); sel.add_argument('--candidate-id',required=True); sel.add_argument('--mode',choices=['user','auto_authorized'],required=True); sel.add_argument('--evidence',required=True); sel.add_argument('--workspace-root',type=Path,default=Path(__file__).resolve().parents[4])
    a=ap.parse_args()
    try:
        root=a.workspace_root.resolve(); r=req(root,a.request); out=record(root,r,a.source,a.kind,getattr(a,'direction_id',None),getattr(a,'review',None),getattr(a,'independent_review',None),getattr(a,'round_reason',None)) if a.cmd=='record' else confirm(root,r,a.candidate_id,a.mode,a.evidence)
        print(json.dumps(out,ensure_ascii=False,indent=2)); return 0
    except (CandidateError,OSError,json.JSONDecodeError,RequestIntentError,RequestIdentityError) as e:
        print(json.dumps({'status':'blocked','reason':str(e)},ensure_ascii=False,indent=2)); return 1
if __name__=='__main__': sys.exit(main())
