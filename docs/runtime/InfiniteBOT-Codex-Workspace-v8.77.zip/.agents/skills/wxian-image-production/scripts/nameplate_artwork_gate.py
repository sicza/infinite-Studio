#!/usr/bin/env python3
"""Enforce the nameplate treatment inside the existing image-production path."""
from __future__ import annotations

import re
import sys
import importlib.util
from pathlib import Path

LIB = Path(__file__).resolve().parents[3] / "lib"
if str(LIB) not in sys.path:
    sys.path.insert(0, str(LIB))
from visual_contracts import VisualContractError, validate_visual_spec


class NameplateArtworkError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise NameplateArtworkError(message)


def field(text: str, name: str) -> str:
    values = re.findall(rf"(?im)^\s*{re.escape(name)}:\s*([^\n#]+?)\s*$", text)
    require(len(values) <= 1, f"{name} must not be repeated in requirement-lock.md")
    return values[0].strip() if values else ""


def resolved_nameplate(source_type: str) -> dict:
    resolver_path = Path(__file__).with_name("visual_variant_resolver.py")
    resolver_spec = importlib.util.spec_from_file_location("nameplate_visual_variant_resolver", resolver_path)
    require(resolver_spec is not None and resolver_spec.loader is not None, "visual variant resolver is unavailable")
    resolver = importlib.util.module_from_spec(resolver_spec)
    resolver_spec.loader.exec_module(resolver)
    result = resolver.resolve(source_type, False, False)
    require(isinstance(result, dict), "visual variant resolver returned an invalid result")
    return result


def validate(root: Path, request: Path, *, require_visual_spec: bool = True) -> dict:
    lock = request / "work" / "requirement-lock.md"
    require(lock.is_file(), "work/requirement-lock.md is required")
    text = lock.read_text(encoding="utf-8")
    source_type, variant = field(text, "source_demand_type"), field(text, "visual_variant")
    resolved = resolved_nameplate(source_type)
    canonical_type = resolved.get("source_demand_type")
    if canonical_type != "铭牌" and variant != "ui_nameplate_asset":
        return {"status": "not_applicable"}
    require(canonical_type == "铭牌" and resolved.get("visual_variant") == "ui_nameplate_asset", "ui_nameplate_asset requires a recognized 铭牌 source_demand_type")
    require(variant == "ui_nameplate_asset", "source_demand_type: 铭牌 requires visual_variant: ui_nameplate_asset")
    if require_visual_spec:
        try:
            spec = validate_visual_spec(root, request / "work" / "visual-spec.json")
        except VisualContractError as exc:
            raise NameplateArtworkError(str(exc)) from exc
        require(spec.get("intent", {}).get("visual_logic") == "graphic_asset", "nameplate Visual Spec requires intent.visual_logic: graphic_asset")
        graphic = spec.get("graphic")
        require(isinstance(graphic, dict), "nameplate Visual Spec requires graphic treatment")
        for key in ("shape_language", "palette_roles", "motifs", "safe_zone"):
            require(isinstance(graphic.get(key), str) and graphic[key].strip(), f"nameplate graphic.{key} is required")
    return {"status": "passed", "source_demand_type": canonical_type, "source_demand_alias": source_type, "visual_variant": variant}
