"""Offline regression coverage for Seedance local-image transport."""
from __future__ import annotations

import base64
import json
import tempfile
from pathlib import Path

from PIL import Image

from seedance_media import SeedanceMediaError, local_image_descriptor, payload_size_ok, safe_evidence


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def expect_rejected(action, label: str) -> None:
    try:
        action()
    except (SeedanceMediaError, AssertionError):
        return
    raise AssertionError(label + " was accepted")


def run() -> dict[str, object]:
    checks: list[str] = []
    with tempfile.TemporaryDirectory(prefix="seedance-media-") as raw:
        root = Path(raw)
        paths: dict[str, Path] = {}
        for fmt, suffix in (("PNG", ".png"), ("JPEG", ".jpg"), ("WEBP", ".webp")):
            path = root / (fmt.lower() + suffix)
            Image.new("RGB", (2, 2), (32, 64, 96)).save(path, format=fmt)
            paths[fmt] = path
        expected = {"PNG": "image/png", "JPEG": "image/jpeg", "WEBP": "image/webp"}
        descriptors = []
        for fmt, path in paths.items():
            descriptor = local_image_descriptor(path, role="reference_image", relative_path="requests/r/input/" + path.name,
                                                transport="data_uri", max_image_bytes=1024 * 1024)
            descriptors.append(descriptor)
            require(descriptor["evidence"]["mime_type"] == expected[fmt], fmt + " MIME detection failed")
            data_uri = descriptor["payload_url"]
            require(isinstance(data_uri, str) and data_uri.startswith("data:" + expected[fmt] + ";base64,"), fmt + " Data URI failed")
            encoded = data_uri.split(",", 1)[1]
            require(base64.b64decode(encoded) == path.read_bytes(), fmt + " bytes were re-encoded or changed")
            require("payload_url" not in safe_evidence(descriptor), fmt + " Data URI leaked into safe evidence")
        checks.extend(["T01 png", "T02 jpeg", "T03 webp", "T04 no-sidecar-required", "T05 empty-sidecar-not-used"])

        corrupted = root / "corrupted.png"
        corrupted.write_bytes(b"not an image")
        expect_rejected(lambda: local_image_descriptor(corrupted, role="first_frame", relative_path="requests/r/input/corrupted.png",
                                                        transport="data_uri", max_image_bytes=1024), "T07 corrupted input")
        expect_rejected(lambda: local_image_descriptor(root / "missing.png", role="first_frame", relative_path="requests/r/input/missing.png",
                                                        transport="data_uri", max_image_bytes=1024), "T08 missing input")
        expect_rejected(lambda: local_image_descriptor(paths["PNG"], role="first_frame", relative_path="requests/r/input/png.png",
                                                        transport="data_uri", max_image_bytes=1), "T09 image size")
        expect_rejected(lambda: payload_size_ok(b"x" * 10, 9, require), "T09 payload size")
        require(all(item["evidence"]["role"] == "reference_image" for item in descriptors), "T14 media roles changed")
        checks.extend(["T07 corrupt-blocked", "T08 missing-blocked", "T09 client-limits", "T12/T14 role-order-preserved"])
    return {"status": "passed", "checks": checks, "network_called": False}


if __name__ == "__main__":
    print(json.dumps(run(), ensure_ascii=False))
