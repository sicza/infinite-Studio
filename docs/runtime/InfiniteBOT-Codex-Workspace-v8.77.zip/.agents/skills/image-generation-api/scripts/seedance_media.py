"""Strict, in-memory Seedance image transport helpers."""
from __future__ import annotations

import base64
import hashlib
import io
from pathlib import Path
from typing import Any, Callable

SUPPORTED_TRANSPORTS = {"data_uri", "url_only"}
_MIME_BY_FORMAT = {"PNG": "image/png", "JPEG": "image/jpeg", "WEBP": "image/webp"}


class SeedanceMediaError(ValueError):
    pass


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise SeedanceMediaError(message)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def verified_image_mime(data: bytes, label: str) -> str:
    """Decode bytes and return their actual, allowed MIME type.

    The suffix is deliberately not used as evidence: a renamed or corrupt image
    must be rejected before any network request is attempted.
    """
    try:
        from PIL import Image, UnidentifiedImageError
        with Image.open(io.BytesIO(data)) as image:
            image.verify()
        with Image.open(io.BytesIO(data)) as image:
            actual = str(image.format or "").upper()
    except ImportError as exc:
        raise SeedanceMediaError("Pillow is required to validate local Seedance images") from exc
    except (UnidentifiedImageError, OSError, ValueError) as exc:
        raise SeedanceMediaError(f"{label} is not a decodable PNG, JPEG, or WebP image") from exc
    mime = _MIME_BY_FORMAT.get(actual)
    _require(mime is not None, f"{label} uses unsupported image format: {actual or 'unknown'}")
    return mime


def local_image_descriptor(
    source: Path,
    *,
    role: str,
    relative_path: str,
    transport: str,
    max_image_bytes: int,
) -> dict[str, Any]:
    """Return an in-memory payload value plus persistable, non-sensitive evidence."""
    _require(transport in SUPPORTED_TRANSPORTS, f"unsupported local_image_transport: {transport}")
    _require(source.is_file(), f"{role} source is not a file")
    data = source.read_bytes()
    _require(bool(data), f"{role} source is empty")
    _require(len(data) <= max_image_bytes,
             f"{role} exceeds configured local-image client limit ({len(data)} > {max_image_bytes} bytes)")
    mime = verified_image_mime(data, role)
    evidence = {
        "path": relative_path,
        "sha256": sha256_bytes(data),
        "role": role,
        "mime_type": mime,
        "file_size_bytes": len(data),
        "transport": transport,
    }
    if transport == "url_only":
        return {"payload_url": None, "evidence": evidence}
    # This value stays only in the validated in-memory request/Payload. Callers
    # must persist evidence, never this descriptor's payload_url.
    return {
        "payload_url": "data:" + mime + ";base64," + base64.b64encode(data).decode("ascii"),
        "evidence": evidence,
    }


def safe_evidence(descriptor: dict[str, Any]) -> dict[str, Any]:
    evidence = descriptor.get("evidence")
    _require(isinstance(evidence, dict), "Seedance media descriptor has no evidence")
    return dict(evidence)


def payload_size_ok(body: bytes, maximum: int, require: Callable[[bool, str], None]) -> None:
    require(len(body) <= maximum,
            f"Seedance request exceeds configured client request limit ({len(body)} > {maximum} bytes)")
