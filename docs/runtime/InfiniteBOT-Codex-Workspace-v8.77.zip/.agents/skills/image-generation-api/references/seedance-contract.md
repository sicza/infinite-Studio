# Seedance 视频请求契约

> 时机：提交/查询/下载 Seedance 视频、选择模型与分辨率、处理 Reference 图或首尾帧时加载。

Seedance

支持：

```text
text_to_video
image_to_video_first_frame
image_to_video_first_last_frame
reference_to_video
```

创建固定 `POST /v1/videos`，查询固定 `GET /v1/videos/{id}`；轮询间隔 20 秒，最多 360 次。`prompt` 必须在顶层；`resolution / ratio / duration / generate_audio / watermark / return_last_frame / seed / content` 必须写入 `metadata`，`metadata.content` 禁止 text 项。

模型：

```text
Seedance 2.0      → doubao-seedance-2-0-260128
Seedance 2.0 Fast → doubao-seedance-2-0-fast-260128
Seedance 2.0 Mini → doubao-seedance-2-0-mini-260615
```

参数：`ratio`、`resolution`、`duration`、`generate_audio`、`watermark`、`return_last_frame`、可选 `seed`。Seedance 2.0 默认 `resolution=1080p`、`generate_audio=true`；调用方未显式覆盖时使用该默认值。Reference 模式最多 9 张图、3 个视频；首尾帧模式最多首/尾各 1 张并禁止参考视频。Fast 不支持 1080p，显式切换 Fast 时必须使用 480p/720p。成功状态必须为 `succeeded`，成片读取 `content.video_url`；若 `return_last_frame=true`，同时要求 `content.last_frame_url`。

Seedance 的 `first_frame_source`、`last_frame_source` 和 `reference_image_sources` 可直接使用当前 Workspace 中允许范围的 PNG/JPEG/WebP。本地文件按实际可解码格式和 Hash 校验后，由配置中明确的 `local_image_transport` 处理；当前 `data_uri` 会仅在内存请求 Payload 中生成标准 Data URI，不改原图、不写入调用记录、Prompt 或日志。单图和完整请求都受独立的客户端请求上限约束（它不是服务端上限声明）。已有 HTTP(S) URL 保持原样；仅在显式 `url_only` 配置下才可复用 `.call.json` 的远程地址，并且必须同时通过输出路径、输出 Hash 和 HMAC 调用记录绑定校验。网关是否接受 Data URI 只能由一次真实提交闭环确认；不因 dry-run 或配置值而宣称已验证。
