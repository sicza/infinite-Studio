# 专业 Skill 直接生成计划（generation-plan.json）示例

> 时机：专业 Skill 要在当前 request 内直接调用图片 Profile、写 generation-plan 绑定 item 时加载。

```json
{
  "schema_version": "wxian.generation-plan.v1",
  "primary_skill": "sicza-game-concept-lab",
  "status": "READY",
  "items": [
    {
      "id": "direction-a",
      "status": "READY",
      "api_profile": "gemini",
      "mode": "text_to_image",
      "model": "gemini-3.1-flash-image-preview",
      "prompt_path": "requests/.../work/prompts/direction-a.txt",
      "prompt_sha256": "<sha256>",
      "output_path": "requests/.../work/final/originals/direction-a.png",
      "parameters": {"size": "1:1", "quality": "4k"}
    }
  ]
}
```
