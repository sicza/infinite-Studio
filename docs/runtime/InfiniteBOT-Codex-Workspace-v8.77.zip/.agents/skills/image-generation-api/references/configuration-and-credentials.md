# 凭据文件 ACL（Windows）与配置命令

> 从 SKILL.md 下沉（V8.73 token 整改）。时机：真实 invoke 前排查 `credential store is unreadable`、轮换 Key、修 ACL、配置 GUI 入口时加载。

凭据文件 ACL（Windows）

凭据文件写入后会断继承，并把写入者、SYSTEM、Administrators 以及该工作区上**已存在的每一个非宽泛主体**重新授为显式 ACE。原因是执行命令的身份不一定是配置 Key 的身份：沙箱执行器不是同一账户，只授写入者会让它读不到 Key。这也是唯一有效的修复规则，`configure_api_key_windows.ps1` 与 `secure-credential` 共用它。

已知边界：窄主体的授予是无差别的。沙箱平台用不可解析的合成能力 SID 授权，按可解析性过滤会把该修复本来要恢复的主体一起删掉，因此任何已出现在凭据目录或原凭据文件上的窄主体（含历史残留）都会保留 Read。显式 Deny 会作为 Deny 保留，断继承不会把被拒身份翻成允许。

相对上一版本的真实放宽有两处，都必须当作已知代价：一是上述窄主体无差别保留；二是 SYSTEM 与 Administrators 现在持显式 FullControl（上一版只授写入者）。后者是恢复能力所需——Administrators 本可随时取得所有权——但它确实写进了 DACL。显式 Deny 会被保留，但**权威位统一收敛为 Read 拒绝**：原本只拒绝写的主体，改写后会变成拒绝读，方向更严、不会提权。

密钥落盘顺序是「先建空暂存文件 → 硬化并验证 → 写入内容 → 原子替换」。因此内容不会落到未加固的文件上；轮换失败时原凭据保持不变，不会被破坏。硬化时同时读取凭据目录与原凭据文件的 ACL，所以只在文件上存在的窄主体不会因替换而丢失。GUI 配置入口只删除它自己新建的空占位，不会因 ACL 步骤失败而删除已有可用凭据。

`credential store is unreadable by the identity running this command` 表示当前执行身份不在该文件 DACL 里。修复必须由**拥有该文件的账户**执行 `api-check`：它会原地重写 ACL 并重检，不读取也不改写 Key 值。用同一个受限执行器重跑无法修复，因为那个身份没有改 DACL 的权限；`api-check` 会在该情形返回 `credential_acl_repaired=false`，不会假装成功。ACL 未能写入时 `secure-credential` 以非零退出并报 `blocked`，不会报 `secured`。

```powershell
.agents\scripts\workspace_bootstrap.cmd api-check
python .agents/skills/image-generation-api/scripts/generation_api.py configure
python .agents/skills/image-generation-api/scripts/generation_api.py check-config
python .agents/skills/image-generation-api/scripts/generation_api.py check-config --profile gemini
python .agents/skills/image-generation-api/scripts/generation_api.py secure-credential
```
