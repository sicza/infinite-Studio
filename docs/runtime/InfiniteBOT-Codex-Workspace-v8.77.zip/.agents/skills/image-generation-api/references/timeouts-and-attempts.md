# 运行超时与 attempt 恢复

> 时机：同步长请求超时、Seedance polling 切片、判断 `network_called` / `retry_safe` / 是否可恢复时加载。

运行超时

Gemini / GPT 图像生成与编辑是同步长请求，单次等待上限固定为 600 秒。达到上限时结果状态为 `remote_state_unknown`，保留同名 `.attempt.json`，当前请求不自动重复提交；新的调用只能在远端状态被确认或明确进入新的生成轮次后创建。

Seedance 创建请求单次等待 180 秒；提交成功立即把 task id 写入同名 `.attempt.json`。每个进程只执行配置的有限 polling slice，任务仍未结束时返回 `pending`；再次 invoke 同一 request 时只恢复既有 task 的 GET，不重复 POST，并受跨恢复总轮数上限约束。任务查询单次等待 60 秒，媒体下载单次等待 180 秒。
