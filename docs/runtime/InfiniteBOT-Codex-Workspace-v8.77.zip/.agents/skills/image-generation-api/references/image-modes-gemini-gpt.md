# Gemini / GPT Images 模式与参数契约

> 时机：构造 Gemini 或 GPT Images 请求、解析 GPT 模型选择与尺寸/质量边界、处理 edits mask 或响应读取时加载。

Gemini

Gemini 保留完整三种图片模式，transport 统一到当前网关的 OpenAI-compatible Images 家族：

```text
text_to_image
POST /v1/images/generations
Content-Type: application/json

reference_to_image / image_to_image_edit
POST /v1/images/edits
Content-Type: multipart/form-data
```

共同字段：

```text
model   = gemini-3.1-flash-image-preview
prompt  = 最终 Prompt
size    = 目标比例，例如 9:16
quality = 4k
n       = 1
```

`reference_to_image` 把 `reference-plan.json` 中所有 `must_upload` 图片按顺序作为重复 `image` part 上传；`image_to_image_edit` 先上传 `base_image`，再上传 `must_upload` Reference。角色身份锁、玩法锁与 Reference provenance 不因 API transport 改变而降级。Gemini 当前不发送 `mask`；局部修改通过 base/reference + 明确编辑指令完成。单次 Gemini 3 图片工作流最多接受 14 个图片输入；Reference Plan 仍应按角色身份/玩法/构图/风格职责最小化选择，不为了凑满上限而上传无关图片。

`parameters` 只允许 `size`、`quality`，其中 `quality` 必须为 `4k`。不要再调用 `generateContent`、`/v1beta/models/...`，不要再使用旧 `resolution/aspect_ratio` 字段。

### GPT Images

无参考图走 `POST /v1/images/generations`；有参考图或编辑走 `POST /v1/images/edits` multipart。支持三种图片模式。参数按当前 Provider 契约使用：`size`、`quality`、`background`、`moderation`、`output_format`、可选 `output_compression`；`n=1` 固定由执行器发送。Workspace 的模型级默认值与用户词义路由如下，不直接照搬 Provider 的 `auto` 默认。

当前支持 `gpt-image-2`、`gpt-image-2.5-sunburst`、`gpt-image-2.5-flare`。`gpt` Profile 默认模型是 `gpt-image-2.5-flare`。构造 GPT 请求前必须先解析当前用户原话：

```powershell
python .agents/skills/image-generation-api/scripts/generation_api.py resolve-gpt --request-text "<当前用户相关原话>" --aspect-ratio <已锁定比例>
```

明确像素时追加 `--size WIDTHxHEIGHT`。执行器从当前用户原话重算结果，并在调用记录写入 `intent_binding`（稳定意图快照：request revision、input 文件、requirement lock）；`request.md` 的沟通/批准追加不会使调用失效。只有实质需求变化才使旧调用过期。V8.71 旧调用没有 `intent_binding` 时按 legacy 证据读取，不能伪装成新凭证。

- 用户批准候选是独立事件：用 `workspace_gate.py record-approval` 写入 `work/approvals.jsonl`，不要把批准文字写回 `requirement-lock.md`。
- 生成前若状态不确定，先运行只读 `workspace_gate.py status --request <request>`；不要为确认 CLI 契约去读大段实现源码。
- 调用失败按 attempt 证据恢复：`never_sent / failed_before_send / response_received / remote_state_unknown`；未知状态不盲目重发，明确失败只重试失败操作，不重做已完成的视觉分析、Prompt 与 Gate。
- Provider 错误诊断只读 attempt/record 已有字段；需要更多字段时用 `--help` 或 `rg -n` 精确查脚本，不整段转储源码。

路由优先级：出现“高清 / 高精度 / 4K / PNG / PNG透明底 / transparent”等高保真或透明输出要求时一律 `gpt-image-2.5-sunburst`；否则 `image2.5生图` 默认 Sunburst，`image2生图` 使用 `gpt-image-2`，普通“GPT生图”默认 `gpt-image-2.5-flare`。显式 `gpt-image-2.5-sunburst/flare` 名称可直接选择，但高保真触发词仍优先切到 Sunburst。

GPT Image 2.5 默认 `quality=max`、`background=opaque`、`output_format=png`。**4K/尺寸与 quality 是独立参数**：用户要求 4K 时解析合法的大尺寸 canvas，但不把 4K 强行映射成 `xhigh`；若用户未另行指定质量，2.5 仍用 `max`。透明底固定 `background=transparent`，且格式只能是 PNG/WebP。默认值可被用户的显式合法参数覆盖，但不得覆盖透明底与格式等显式约束。仅给比例时，GPT Image 2/2.5 都默认使用 `1:1→2880x2880`、`16:9→3840x2160`、`4:3→3264x2448`、`9:16→2160x3840`、`3:4→2448x3264`；其他比例按 16 的倍数、1:3–3:1、单边≤3840、总像素 655,360–8,294,400 的边界求最大合法尺寸。明确尺寸优先，但必须满足同一边界。

`gpt-image-2` 的最高质量为 `high`，不接受 `max` 或 `xhigh`；其尺寸与 2.5 共用上述自定义尺寸边界。高保真触发词仍按前述优先级升级到 Sunburst。

上述 2.5 参数边界核对自 OpenAI 官方 Image generation 文档：<https://developers.openai.com/api/docs/guides/image-generation>（2026-09-14）。模型与参数属于易变 Runtime 事实；官方约束变化时先更新共享 `gpt_image_contract.py` 及回归，再修改说明。

`edits` 最多 16 张 `image`。GPT Image 2.5 的 `image_to_image_edit` 支持可选 `mask_image`：mask 与第一张被编辑图必须同格式、同尺寸、各自 <50MB，mask 必须包含 Alpha；mask 只作为编辑引导，仍需清晰 Prompt。Gemini 仍不发送 mask。响应必须优先读取 `data[].url`，没有 URL 才读取 `data[].b64_json`。

官方文档还定义了独立的 GPT 多轮绘图 `POST /v1/responses`；当前 Codex Workspace 的 API request contract 没有完整会话输入，因此本 Profile **不伪装成已接入 Responses**。需要该能力时应独立增加明确的 multi-turn request contract，而不是把 `/v1/responses` 混入当前直连图片调用。
