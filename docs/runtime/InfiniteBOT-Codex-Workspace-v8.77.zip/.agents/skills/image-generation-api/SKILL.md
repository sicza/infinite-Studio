---
name: image-generation-api
description: 执行专业 Skill 已定的 Gemini/GPT Images 生成编辑与 Seedance 视频请求：配置、参数校验、真实调用、媒体保存、调用记录；不改 Prompt、不做审美判断。
---

# 图像 / 视频 API 执行

只执行调用 Skill 已确定的 Prompt、Reference、模型与参数；不修改专业判断。`wxian-image-production` 请求的 dry-run/invoke 读取当前 request `requirement-lock.md` 的 `production_branch` 并校验 source-lock/业务分支/Reference plan；受约束 direct caller（如 KV/UI 拆层）改为校验当前 `source-lock + generation-plan binding`，不得伪造 production branch。关键证据缺失即阻塞。

## 配置

非敏感 API 配置位于 `config/api-runtime.json`；API Key 位于 `.agents/runtime/credentials.json` 的 `generation_api_key`。普通初始化不检查或提示 Key；显式 `api-check` 在 Windows 调用 `.agents/scripts/configure_api_key_windows.ps1`，macOS / Linux 返回本地隐藏输入命令。`dry-run` 不联网、不用 Key，可在缺 Key 环境验证合同与 payload；真实 `invoke` 缺 Key 时在联网前阻断。

> **`config/api-runtime.json` 的 `base_url` 是团队 LAN 网关默认值**：跨工作区复用、对外交付或接入其他网络前必须改成自己的网关地址；`allow_insecure_http` 仅限团队内网使用，不得带入外网或交付配置。这是配置事实而非安全认证，改配置不改专业判断。

Profile：`gemini` → OpenAI-compatible Images 生成/参考/编辑（Gemini）；`gpt` → OpenAI-compatible Images 生成/编辑；`seedance` → Seedance 视频提交/轮询/下载。Key 轮换直接编辑 `credentials.json` 或走 `api-check`；调用记录只保存凭据状态。

```powershell
.agents\scripts\workspace_bootstrap.cmd api-check
python .agents/skills/image-generation-api/scripts/generation_api.py configure
python .agents/skills/image-generation-api/scripts/generation_api.py check-config [--profile gemini]
python .agents/skills/image-generation-api/scripts/generation_api.py secure-credential
```

`check-config` 不联网，只证明本地配置完整；真实调用成功才证明当时端点可用。Windows ACL 断继承、窄主体保留、Deny 收敛、暂存→硬化→原子替换、`credential store is unreadable by the identity running this command` 的修复身份规则见 `references/configuration-and-credentials.md`。

## 最小请求契约

API 请求放在当前 request `work/api-requests/`。**Prompt 只保存一次**：调用方把最终 Prompt 写成 UTF-8 文本（如 `work/api-prompts/main.txt`），请求只引用 `prompt_path`。字段只保留：`api_profile / mode / prompt_path / output_path / parameters / 可选 model / 当前模式需要的图片路径或媒体 URL`。不重复 Prompt，不维护 `prompt_source.anchor`、素材 provenance、网络/费用授权账本；执行器从真实文件自动计算 Prompt/输入/输出 Hash 并写调用记录。

本地图片只允许来自当前 request `input/`、`work/` 或 `project/` 下的真实项目原始资料；`project/baselines/`、其他 request 输出与 Workspace 外路径禁止作素材。`reference_images` 必须与 `work/reference-plan.json` 的 `must_upload` 完全一致；编辑底图用 `base_image`，不混进 Reference。

当前 request 一旦存在 `work/ip-character-*` 或 `work/concept-lab/ip-character-*` 长期角色契约，生图前必须已有同目录、绑定当前 system/binding、Provider、Mode 与 Runtime Hash 的 `ip-character-preflight.json` + `ip-character-handoff.json`；API 强制 Mother Reference 成为 `reference_images` 原序前缀，文件漂移、漏传、重排、Provider/Mode/edit target 不符均在联网前阻断。

## 图片模式

- **Gemini**：`text_to_image` → `POST /v1/images/generations`（JSON）；`reference_to_image` / `image_to_image_edit` → `POST /v1/images/edits`（multipart）。`parameters` 只允许 `size`、`quality`（必须 `4k`），`n=1`；不发 `mask`；单次最多 14 个图片输入；禁用 `generateContent`、`/v1beta/models/...` 与旧 `resolution/aspect_ratio`。
- **GPT Images**：无参考图 → `/v1/images/generations`；有参考或编辑 → `/v1/images/edits` multipart；支持三种模式。参数 `size / quality / background / moderation / output_format / 可选 output_compression`，`n=1` 由执行器固定。构造请求前必须先按用户原话解析模型：

```powershell
python .agents/skills/image-generation-api/scripts/generation_api.py resolve-gpt --request-text "<当前用户相关原话>" --aspect-ratio <已锁定比例>
```

- **GPT 模型路由**：出现“高清/高精度/4K/PNG/透明底/transparent”等高保真或透明要求一律 `gpt-image-2.5-sunburst`；`image2.5生图` 默认 Sunburst，`image2生图` 用 `gpt-image-2`，普通“GPT生图”默认 `gpt-image-2.5-flare`；显式名称可选但高保真触发词优先。默认 `quality=max`、`background=opaque`、`output_format=png`；4K/尺寸与 quality 独立，不得把 4K 映射成 `xhigh`；透明底固定 `background=transparent` 且只允许 PNG/WebP；仅给比例时按契约边界求最大合法尺寸。`gpt-image-2` 最高质量 `high`。
- **Reference 规则**：`text_to_image` 两 Profile 均可；`reference_to_image` 至少一个 `reference_images`；`image_to_image_edit` 必须 `base_image`，GPT Image 2.5 可附 `mask_image`（与首图同格式同尺寸、各自 <50MB、含 Alpha），Gemini 不可。身份锁/构图参考/编辑底图由专业 Skill 决定，API 层不重选。

尺寸表、edits 最多 16 张、响应优先 `data[].url` 再 `b64_json`、`/v1/responses` 未接入、官方文档核对日期（2026-09-14）与全部参数边界见 `references/image-modes-gemini-gpt.md`；易变事实变化时先改共享 `gpt_image_contract.py` 及回归再改文档。

## 专业 Skill 直接生成计划

`sicza-game-concept-lab`、`wxian-visual-packaging`、`wxian-visual-competitive-analysis`、`wxian-conducting-internet-research`、`wxian-image-layer-decomposition`、`wxian-game-ui-layer-decomposition` 可在当前 request 内直接调用图片 Profile，无需改路由。调用前必须写 `work/generation-plan.json`（`status=READY` + items）；每次 API request 精确匹配一个 `READY` item，Prompt Hash、Profile、Mode、Model、参数、Reference、输出路径任一漂移在联网前阻断；输出只进当前 request `work/final/originals/`；调用记录写 `generation_plan_binding`。JSON 示例见 `references/generation-plan.md`。

`intent_binding` 是稳定意图快照（request revision、input 文件、requirement lock）；`request.md` 的沟通/批准追加不使调用失效，只有实质需求变化才使旧调用过期；V8.71 旧调用无该字段按 legacy 证据读，不伪装成新凭证。用户批准候选是独立事件：`workspace_gate.py record-approval` 写 `work/approvals.jsonl`，不写回 `requirement-lock.md`。状态不确定先跑只读 `workspace_gate.py status --request <request>`；Provider 错误诊断只读 attempt/record 已有字段，需要更多字段用 `--help` 或 `rg -n` 精确查脚本，不整段转储源码。

## 超时与 Seedance

同步生成/编辑单次等待上限 600 秒；达上限状态 `remote_state_unknown`，保留同名 `.attempt.json`，不自动重复提交，新调用须远端状态确认或进入新生成轮次。Seedance：创建 180 秒、查询 60 秒、下载 180 秒，提交成功立即把 task id 写 `.attempt.json`，每次 invoke 只执行有限 polling slice，未结束返回 `pending`，再次 invoke 只恢复既有 task 的 GET 不重复 POST。失败按 attempt 证据恢复：`never_sent / failed_before_send / response_received / remote_state_unknown`；未知状态不盲目重发，明确失败只重试失败操作（见 `references/timeouts-and-attempts.md`）。

Seedance 模式：`text_to_video / image_to_video_first_frame / image_to_video_first_last_frame / reference_to_video`；创建固定 `POST /v1/videos`，查询 `GET /v1/videos/{id}`，轮询间隔 20 秒、最多 360 次；`prompt` 在顶层，`resolution/ratio/duration/generate_audio/watermark/return_last_frame/seed/content` 写 `metadata`，`metadata.content` 禁止 text 项。模型 `doubao-seedance-2-0-260128`（2.0）/ `...-fast-260128` / `...-mini-260615`；默认 `resolution=1080p`、`generate_audio=true`；Reference 最多 9 图 3 视频，首尾帧模式各 1 张且禁止参考视频；Fast 不支持 1080p。成功状态 `succeeded`，成片读 `content.video_url`，`return_last_frame=true` 还要求 `content.last_frame_url`。本地媒体 transport、`url_only` 复用与 HMAC 校验细则见 `references/seedance-contract.md`。

## 执行与成功边界

```powershell
python .agents/skills/image-generation-api/scripts/generation_api.py dry-run --request <request.json> --workspace-root .
python .agents/skills/image-generation-api/scripts/generation_api.py invoke --request <request.json> --workspace-root .
```

用户要求生成/编辑/视频制作即执行意图；平台级确认由实际运行环境处理，本 Workspace 不复制文本授权证明。执行器不自动换 Profile、模型或 Prompt，不覆盖已有输出；默认 Profile 由调用它的专业 Skill 决定，API 层不再次询问用户。成功记录实际 Profile、端点路径、模型、模式、Prompt/输入 Hash、参数、输出 Hash/尺寸或任务 ID，不保存 Key；服务未给 request id 时记 `service_request_id=null` + `provider_not_supplied`，以成功 HTTP、请求/响应 Hash、输出 Hash 与执行器绑定构成证据，不伪造 ID、不丢弃已通过媒体校验的结果。

API 成功只证明技术调用成功：图片必须可解码、格式/尺寸/比例符合请求；视频必须任务成功且真实媒体已下载。调用方仍须实际查看结果并执行专业门禁。`background=transparent` 时执行器还验证返回 PNG/WebP 确有 Alpha 且非全不透明/全透明（棋盘格不算透明 PNG）。鉴权、网络、参数、能力、内容安全、解析、下载失败返回真实错误；不得创建 Mock/占位媒体或宣布专业交付完成。
