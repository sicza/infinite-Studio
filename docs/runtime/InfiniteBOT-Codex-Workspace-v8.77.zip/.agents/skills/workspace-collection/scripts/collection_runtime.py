#!/usr/bin/env python3
"""Deterministic Collection ledger and SmartSheet transport; never changes request state."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, re, sys, uuid
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen

os.environ["PYTHONDONTWRITEBYTECODE"] = "1"; sys.dont_write_bytecode = True
TABLES={"prompt","experience","issue","feature"}
SYSTEM_FIELDS={"created_by","source"}
SECRET=re.compile(r"(?i)(authorization|bearer|api[_-]?key|token|cookie|password|secret)")
class CollectionError(ValueError): pass
def need(ok,msg):
    if not ok: raise CollectionError(msg)
def read(path):
    need(path.is_file(),f"missing file: {path}"); value=json.loads(path.read_text(encoding="utf-8")); need(isinstance(value,dict),"JSON root must be object"); return value
def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True); tmp=path.with_suffix(path.suffix+".tmp"); tmp.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf-8"); tmp.replace(path)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def bounded(root,value,exists=False):
    path=(root/Path(value)).resolve() if not Path(value).is_absolute() else Path(value).resolve(); need(path==root or root in path.parents,"path escapes workspace");
    if exists: need(path.exists(),f"path missing: {value}")
    return path
def request(root,value):
    path=bounded(root,value,True); parts=path.relative_to(root).parts; need(len(parts)==3 and parts[0]=="requests" and path.is_dir(),"request must be requests/<type>/<name>"); return path
def identity(root,req):
    state=read(req/"state.json"); need(isinstance(state.get("revision"),int) and state["revision"]>0,"invalid revision"); ref=req.relative_to(root).as_posix(); rid=hashlib.sha256(("sicza.request-id.v1\n"+ref).encode()).hexdigest(); return ref,rid,state
def safe(value):
    text=json.dumps(value,ensure_ascii=False) if not isinstance(value,str) else value; need(not SECRET.search(text),"secret-like content is forbidden in Collection record"); return value
def profile(root):
    path=root/"user/profile.json"; value=read(path); name=value.get("display_name"); need(isinstance(name,str) and name.strip(),"user/profile.json display_name is required"); return name.strip()
def source(ref,rid,revision,key,sid): return json.dumps({"submission_id":sid,"request_id":rid,"request_ref":ref,"revision":revision,"candidate_key":key},ensure_ascii=False,separators=(",",":"))
def table_config(root,kind):
    config=read(root/".agents/collection-webhooks.json"); need(config.get("schema_version")=="sicza.collection-webhooks.v1","unsupported Collection config schema"); table=config.get("tables",{}).get(kind); need(isinstance(table,dict),"table config missing"); fields=table.get("fields"); need(isinstance(fields,dict) and all(isinstance(k,str) and isinstance(v,str) and v for k,v in fields.items()),"table fields are invalid"); return table,fields
def rating(root,ref,revision):
    path=root/".agents/skills/workspace-user-feedback/scripts/user_feedback.py"
    need(path.is_file(),"User Feedback rating Authority is missing")
    try:
        spec=importlib.util.spec_from_file_location("workspace_collection_feedback",path)
        need(spec is not None and spec.loader is not None,"User Feedback rating Authority cannot be loaded")
        module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        result=module.get_rating(root,ref,revision)
    except (OSError, ValueError, ImportError, AttributeError) as exc:
        raise CollectionError("User Feedback rating Authority is unavailable") from exc
    need(isinstance(result,dict) and result.get("status")=="ready","User Feedback rating Authority returned an invalid result")
    value=result.get("rating")
    need(value is None or (isinstance(value,int) and not isinstance(value,bool) and 1<=value<=5),"User Feedback rating Authority returned an invalid rating")
    return value
def eligible(root,ref,state):
    status=state.get("status"); score=rating(root,ref,state["revision"])
    need(status in {"completed","blocked"} or (isinstance(score,int) and score>=3),"Collection requires a completed/blocked request or an existing medium/high rating")
def validate_payload(root,kind,payload):
    _,fields=table_config(root,kind)
    need(isinstance(payload,dict) and payload,"payload must be a non-empty object")
    need(all(isinstance(k,str) for k in payload),"payload keys must be strings")
    invalid=set(payload)-(set(fields)|SYSTEM_FIELDS)
    need(not invalid,f"payload has unsupported fields: {', '.join(sorted(invalid))}")
    return {k:safe(v) for k,v in payload.items() if k not in SYSTEM_FIELDS}
def validate_draft(root,value):
    need(value.get("schema_version")=="sicza.collection-draft.v1","invalid Collection draft schema")
    kind=value.get("table"); need(kind in TABLES,"invalid Collection draft table")
    ref=value.get("source_request_ref"); need(isinstance(ref,str),"invalid Collection source request")
    req=request(root,ref); actual_ref,rid,state=identity(root,req)
    need(actual_ref==ref and value.get("source_request_id")==rid,"Collection draft request identity drift")
    need(value.get("source_revision")==state["revision"],"Collection draft revision drift")
    eligible(root,ref,state)
    payload=validate_payload(root,kind,value.get("semantic_payload"))
    snapshots=value.get("evidence_snapshot")
    need(isinstance(snapshots,list) and len(snapshots)==1 and isinstance(snapshots[0],dict),"invalid Collection evidence snapshot")
    item=snapshots[0]; path=bounded(root,item.get("path",""),True)
    need(path.is_file() and (path==req or req in path.parents),"Collection evidence must be a file inside its source request")
    need(item.get("kind")=="workspace_file" and item.get("sha256")==sha(path),"Collection evidence drift")
    fingerprint=hashlib.sha256((sha(path)+"\n"+json.dumps(payload,sort_keys=True,ensure_ascii=False)).encode()).hexdigest()
    need(value.get("evidence_fingerprint")==fingerprint,"Collection draft fingerprint drift")
    return kind,ref,rid,state,payload
def draft(root,args):
    req=request(root,args.request); ref,rid,state=identity(root,req); eligible(root,ref,state)
    kind=args.table; need(kind in TABLES,"invalid table"); need(args.occurrence.strip(),"occurrence is required")
    evidence=bounded(root,args.evidence,True)
    need(evidence.is_file() and (evidence==req or req in evidence.parents),"Collection evidence must be a file inside its source request")
    payload=validate_payload(root,kind,read(bounded(root,args.payload,True)))
    key=hashlib.sha256((kind+"\n"+ref+"\n"+args.occurrence).encode()).hexdigest()
    fingerprint=hashlib.sha256((sha(evidence)+"\n"+json.dumps(payload,sort_keys=True,ensure_ascii=False)).encode()).hexdigest()
    result={"schema_version":"sicza.collection-draft.v1","table":kind,"source_request_ref":ref,"source_request_id":rid,"source_revision":state["revision"],"primary_skill":state.get("primary_skill"),"candidate_key":key,"evidence_fingerprint":fingerprint,"evidence_snapshot":[{"kind":"workspace_file","path":evidence.relative_to(root).as_posix(),"sha256":sha(evidence)}],"semantic_payload":payload,"created_at":datetime.now(timezone.utc).isoformat()}
    path=root/"tmp/collection"/rid/f"r{state['revision']}"/(key+".json"); write(path,result)
    return {"status":"drafted","draft":path.relative_to(root).as_posix(),"candidate_key":key}
def confirm(root,args):
    draft_path=bounded(root,args.draft,True); value=read(draft_path)
    _,_,_,_,payload=validate_draft(root,value); name=profile(root)
    sid=str(uuid.uuid5(uuid.NAMESPACE_URL,"sicza.collection.v1/"+value["candidate_key"]))
    path=root/"user/collection/submissions"/(sid+".json")
    if path.exists():
        existing=read(path)
        need(existing.get("candidate_key")==value["candidate_key"] and existing.get("evidence_fingerprint")==value["evidence_fingerprint"],"confirmed Collection candidate differs; use a new occurrence")
        return {"status":"already_confirmed","submission_id":sid}
    value["submission_id"]=sid; value["confirmed_at"]=datetime.now(timezone.utc).isoformat(); value["created_by"]=name
    value["semantic_payload"]=payload; value["semantic_payload"]["created_by"]=name
    value["semantic_payload"]["source"]=source(value["source_request_ref"],value["source_request_id"],value["source_revision"],value["candidate_key"],sid)
    value["payload_sha256"]=hashlib.sha256(json.dumps(value["semantic_payload"],ensure_ascii=False,sort_keys=True).encode()).hexdigest()
    write(path,value)
    write(root/"user/collection/outbox"/(sid+".json"),{"submission_id":sid,"state":"pending","submission":path.relative_to(root).as_posix(),"payload_sha256":value["payload_sha256"]})
    return {"status":"confirmed","submission_id":sid}
def deliver(root,args):
    sub_path=bounded(root,args.submission,True); sub=read(sub_path)
    kind=sub.get("table"); need(kind in TABLES,"invalid Collection submission table")
    config,fields=table_config(root,kind); sid=sub.get("submission_id")
    need(isinstance(sid,str) and sub_path==root/"user/collection/submissions"/(sid+".json"),"invalid Collection submission path")
    public_payload=validate_payload(root,kind,sub.get("semantic_payload"))
    system_payload=sub["semantic_payload"]
    need(isinstance(system_payload.get("created_by"),str) and system_payload["created_by"].strip(),"Collection submission has no creator")
    expected_source=source(sub.get("source_request_ref"),sub.get("source_request_id"),sub.get("source_revision"),sub.get("candidate_key"),sid)
    need(system_payload.get("source")==expected_source,"Collection submission source drift")
    expected=hashlib.sha256(json.dumps(system_payload,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
    need(sub.get("payload_sha256")==expected,"Collection submission payload drift")
    receipt_path=root/"user/collection/receipts"/(sid+".json"); outbox_path=root/"user/collection/outbox"/(sid+".json")
    if receipt_path.is_file():
        receipt=read(receipt_path); need(receipt.get("payload_sha256")==expected and receipt.get("remote_status")=="accepted","Collection receipt drift"); write(outbox_path,{"submission_id":sid,"state":"delivered","submission":sub_path.relative_to(root).as_posix(),"payload_sha256":expected}); return {"status":"already_delivered","submission_id":sid}
    url=config.get("webhook_url"); need(isinstance(url,str) and url.startswith("https://"),"local webhook_url is not configured")
    values={fields[key]:value for key,value in system_payload.items() if key in fields and value not in (None,"",[],{})}
    body=json.dumps({"add_records":[{"values":values}]},ensure_ascii=False).encode()
    try:
        response=json.loads(urlopen(Request(url,data=body,headers={"Content-Type":"application/json"},method="POST"),timeout=30).read().decode("utf-8")); need(response.get("errcode")==0,"remote rejected submission")
    except Exception as exc:
        out={"submission_id":sid,"state":"ambiguous","submission":sub_path.relative_to(root).as_posix(),"payload_sha256":expected,"error_type":type(exc).__name__}; write(outbox_path,out); raise CollectionError("delivery ambiguous; explicit retry required") from exc
    receipt={"submission_id":sid,"submitted_at":datetime.now(timezone.utc).isoformat(),"table":kind,"payload_sha256":expected,"remote_status":"accepted"}; write(receipt_path,receipt); write(outbox_path,{"submission_id":sid,"state":"delivered","submission":sub_path.relative_to(root).as_posix(),"payload_sha256":expected}); return {"status":"delivered","submission_id":sid}
def main():
    p=argparse.ArgumentParser(); s=p.add_subparsers(dest="cmd",required=True)
    d=s.add_parser("draft"); d.add_argument("--request",required=True); d.add_argument("--table",choices=sorted(TABLES),required=True); d.add_argument("--evidence",required=True); d.add_argument("--payload",required=True); d.add_argument("--occurrence",required=True)
    c=s.add_parser("confirm"); c.add_argument("--draft",required=True)
    x=s.add_parser("deliver"); x.add_argument("--submission",required=True)
    for q in (d,c,x): q.add_argument("--workspace-root",type=Path,default=Path.cwd())
    a=p.parse_args()
    try: print(json.dumps({"draft":draft,"confirm":confirm,"deliver":deliver}[a.cmd](a.workspace_root.resolve(),a),ensure_ascii=False)); return 0
    except (CollectionError,OSError,json.JSONDecodeError) as exc: print(json.dumps({"status":"blocked","reason":str(exc)},ensure_ascii=False)); return 1
if __name__=="__main__": raise SystemExit(main())
