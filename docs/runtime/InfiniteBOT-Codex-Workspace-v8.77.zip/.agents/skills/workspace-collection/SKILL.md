---
name: workspace-collection
description: 从 Request evidence 形成可审计的 Prompt/Experience/Issue/Feature 候选，用户确认后投递配置的 Shared SmartSheet。
---

# Shared Collection

Collection 是非阻塞辅助能力：不改变 request 状态、Primary Skill、Promote、评分或 Personal Skill。只在明确分享、Collection Flush、真实 completed/blocked Request 或已有高/中信号时加载。

只使用真实 Request、revision、Prompt/Provider/Artifact、Feedback 和用户原话证据。无 Authority 时 omit、UNKNOWN 或拒绝候选，绝不猜测。先运行 `collection_runtime.py draft`，向用户展示候选；只有明确确认后才 `confirm` 和 `deliver`。证据文件必须属于该 Request；草稿确认时重新核对 Request、revision、证据 Hash 和可归集状态。一个 `table + request + occurrence` 只形成一个稳定 submission；成功后 receipt 与 outbox 都进入 `delivered`，重复投递只返回既有结果。

`user/profile.json` 缺少 `display_name` 时只询问一次；不得使用机器名、账号名或邮箱替代。Webhook 配置在 `.agents/collection-webhooks.json`，正式包只含空 URL 模板；本地部署后填入真实 URL，任何日志、submission、outbox、receipt 或输出都不得回显 URL 或 token。

模拟 A3 是本版本经用户明确授权的发布门槛替代，必须在任何验证/交付声明中标为 `SIMULATED_ACCEPTED`，不得称为真实 completed Request 语义验证。
