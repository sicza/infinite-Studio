# Visual Domain Gates

本文件是**按需视觉审图**能力，不是所有视觉任务的全局交付前提。只有以下任一成立时才执行本文件：

- 当前调用方 `visual-enforcement-profiles.json` 的 `visual_gate` 要求 `visual-gate-result.json`，且当前分支命中；
- 用户明确要求审图、评分、复看或视觉验收；
- 调用方或用户要求对高价值资产、争议对象做独立复核。

默认设计、诊断、迭代、方案比较与 Prompt 交付直接输出专业结论，不强制独立 reviewer，也不强制生成 gate evidence。审图属于专业判断，技术 Gate 只证明对象身份、来源绑定与 Hash 事实，不替代像素结论。

本文件只判断 **视觉域是否通过**，不拥有 Codex 的 Release / Promote / Final Delivery Authority。

唯一结构化证据：`.agents/skills/workspace-governance/config/visual-contracts/visual-gate-result-schema.json`。

合法总结果：

- `VISUAL_PASS`
- `VISUAL_BLOCK`
- `NEED_UPSTREAM`
- `NEED_DOMAIN`

最终发布仍由当前 Primary Skill 的 Gate 与 `$workspace-governance promote` 决定。

## 审图项

1. `VG-INTENT`
2. `VG-INTEGRITY`
3. `VG-HIERARCHY`
4. `VG-COHERENCE`
5. `VG-DELIVERY-FIT`

旗舰 KV、活动主视觉、IP 定义视觉、系列主资产等高价值任务追加 `VG-DISTINCTIVENESS`。

## VG-INTENT

审图者按 `原始用户需求 → 当前 Reference 的可迁移核心关系 → 实际像素` 顺序检查核心意图、核心视觉关系、传播信息、使用场景和实际读图；Visual Spec 和 Prompt 是被审实现，不得反过来覆盖原始需求。关键词齐全、Spec 自洽但像素关系错误仍然 BLOCK。

需要生成 `visual-gate-result.json` 时，机器合同要求审图者与 producer 身份分离并绑定独立审图报告；仅用户口头要求复看而不落 gate evidence 时，可由当前 Agent 以同一专业方法执行，但必须实际查看目标像素。

## VG-INTEGRITY

读取已激活完整性门禁。身份、数量、空间、接触、结构、文字/Logo、连续性等关键项存在 `BLOCK` 或必要证据 `UNVERIFIED` 时不得 `VISUAL_PASS`。

## VG-HIERARCHY

同时实际查看全尺寸图和短边 256–360 像素缩略图，检查第一读、第二读、注意竞争、目标观看尺寸和必读信息优先级。层级服从任务意图，不默认“主体必须第一读”；装置、框体、光效或背景在缩略图夺走活动命题时 BLOCK。

## VG-COHERENCE

检查世界、表演、相机、光、材质、图像结构、成像、图形传播和项目身份能否共存；一致性不等于所有资产同质化。

## VG-DISTINCTIVENESS

高价值任务检查去 Logo、去色、缩略图条件下是否仍有项目专属构型/记忆锚点。随机怪异或临时特效不构成稳定识别。

## VG-DELIVERY-FIT

只检查视觉结果在目标画幅、尺寸、裁切、安全区、透明背景、平台遮挡与缩略图条件下是否仍成立。文件复制、manifest、正式发布不是本 Gate 的权限。

## 结构化结果

示例字段：

```json
{
  "schema_version": "sicza.visual-gate-result.v3",
  "request_ref": "requests/...",
  "request_id": "<64hex>",
  "request_revision": 1,
  "request_fingerprint": "<64hex>",
  "gate_profile": "gate.visual.production.v1",
  "target_path": "requests/.../work/candidate.png",
  "target_sha256": "<64hex>",
  "visual_spec_path": "requests/.../work/visual-spec.json",
  "visual_spec_sha256": "<64hex>",
  "prompt_binding_path": "requests/.../work/prompt-binding.json",
  "prompt_binding_sha256": "<64hex>",
  "result": "VISUAL_PASS",
  "gates": [
    {
      "gate": "VG-INTENT",
      "result": "PASS",
      "evidence": [{"target_path": "requests/.../work/candidate.png", "target_sha256": "<64hex>", "observation": "核心关系在交付尺寸下仍可直接读出"}],
      "owner": "sicza-visual-director"
    }
  ],
  "reviewer": "<审图者身份>",
  "independent_review": {
    "reviewer_id": "<审图者身份>",
    "producer_id": "<producer 身份>",
    "review_report_path": "requests/.../work/independent-visual-review.json",
    "review_report_sha256": "<64hex>",
    "verdict": "PASS",
    "decoded_target": {"format": "PNG", "width": 1920, "height": 1080, "mode": "RGBA"}
  }
}
```

验证：

```text
python .agents/scripts/visual_contract_gate.py validate-visual-gate --file <path> --workspace-root .
```

## 停止条件

- 执行审图时，当前视觉域全部审图项有真实证据且无 BLOCK/UNVERIFIED → `VISUAL_PASS`；
- 视觉机制本身失败 → `VISUAL_BLOCK`；
- 上游事实/合同不足 → `NEED_UPSTREAM`；
- 依赖其他专业正确性 → `NEED_DOMAIN`。

禁止把 `VISUAL_PASS` 写成 `RELEASE`，也禁止视觉完成度覆盖 Primary Skill 的机器交付 Gate。
