# 视觉事实契约、参考契约与 Request-local 视觉投影

> 从 SKILL.md 下沉（V8.73 token 整改）。时机：锁定事实/硬约束/参考边界、建立或更新 `visual_projection`、处理叙事交接 trace 时加载。

视觉事实契约

```yaml
visual_truth:
  task:
  use_case:
  output_format:
  immutable_truth:
    characters:
    identities:
    event:
    causal_relationships:
    required_objects:
    environment_facts:
  hard_constraints:
    aspect_ratio:
    count:
    preserve:
    prohibit:
    continuity:
  flexible_variables:
```

- `immutable_truth` 不得因视觉优化被改写。
- `hard_constraints` 具有否决权。
- 未知事实标记为 `unknown`，不得补造。
- 图像编辑中，未声明可变的高价值结构默认保留。
- 超出视觉因果判断的专业事实升级到对应领域专家或可靠参考。

## 参考契约

```yaml
reference_contract:
  - source:
    use_for:
    do_not_inherit:
    confidence:
```

1. 只继承明确授权的视觉通道。
2. 多参考先检查身份、相机、姿态、风格、几何冲突。
3. 参考不得覆盖视觉事实。
4. 单个参考可以只提供局部机制。
5. 未解析的参考冲突不得进入提示词或视觉规格。
6. 不确定是否继承高影响变量时，默认不继承。

## Request-local 视觉投影

```yaml
visual_projection:
  mode:
  narrative_trace:
    contract_id:
    contract_revision:
    semantic_checksum:
  truth:
  intent:
  message:
  references:
  hierarchy:
    primary:
    secondary:
  direction:
    selected:
    memory_anchor:
    avoid_reversion:
  channel_roles:
    lead:
    support:
    suppress:
  protect:
  route:
    observed_domain:
    root_hypothesis:
    root_owner:
    repair_owner:
    dependents:
    load_depth:
    evidence:
    confidence:
  open_failures:
  next_action:
```

- 未列入 `lead / support / suppress` 的通道默认中性。
- 只保留未解决问题。
- 被拒绝方向只保留 `avoid_reversion`，不保存完整失败方案。
- 核心事实只存在于现有 Codex Authority；`visual_projection` 只保存当前 request 的派生视觉决策，各工作流只保存自身增量状态。
- 叙事交接存在时，`narrative_trace` 记录当前活动合同；无叙事交接时省略。
