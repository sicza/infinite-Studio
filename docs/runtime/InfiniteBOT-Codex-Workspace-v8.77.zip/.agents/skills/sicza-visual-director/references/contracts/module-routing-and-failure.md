# 模块角色、路由/按需读取契约与失败分类

> 时机：决定加载哪个专业族/子模块与深度（INDEX/CORE/DIAG/DEEP/GATES）、判定失败范围/层级/来源与所有权时加载。

模块角色

### 机制所有者

直接拥有设计或修复机制：

- `W-*`
- `P-*`
- `R-*`
- `A-*`
- `I-*`
- `F-*`
- `G-INFO`
- `G-TYPE`
- `G-LAYOUT`
- `G-REL`
- `G-BRAND`
- `G-MULTI`
- `G-SPATIAL`

### 验证者

只验证最终读图或传播结果：

- `H-*`
- `G-VERIFY`

`可见失败 → 验证者 → 机制搜索 → 根因所有者 → 修复 → 复验`

### 治理模块

管理长期语法、身份、变化和漂移：

- `D-*`

## 路由契约

地址：

`FAMILY / SUBMODULE / DEPTH`

深度：

- `INDEX`：只导航。
- `CORE`：核心模型、可观察变量、决策规则、门禁。
- `DIAG`：`CORE` + 失败信号 + 修复操作。
- `DEEP`：复杂机制、边界与依赖。
- `GATES`：只验证。

默认：

- `CREATE → CORE`
- `DIAGNOSE → DIAG`
- 依赖模块 → `CORE` 或 `GATES`
- 回归检查 → `GATES`
- 难以解释且证据冲突 → `DEEP`

## 按需读取契约

- `INDEX`：只读取目标专业族文件顶部的快速目录与定位信息。
- `CORE`：定位目标 `## SUBMODULE`，只读取其“不负责 / 核心模型 / 可观察变量 / 决策规则 / 门禁”。
- `DIAG`：在 `CORE` 基础上增加该子模块的“失败信号 / 修复操作”。
- `GATES`：只读取目标子模块的“门禁”及判定所需边界。
- `DEEP`：读取目标子模块完整章节；只有明确依赖时才增加相关章节。
- 路由到一个子模块时，默认禁止整文件加载该专业族。
- 使用失败特征库时，先读取“快速索引”；命中症状后只读取对应 `## 症状` 章节。
- 未命中明确失败特征时，不读取完整失败特征库；返回证据收集或直接进入已知模块。

每轮默认只加载：

`1 个主模块 + 0–2 个依赖模块`

若同时需要超过 3 个专业模块，先检查是否混入多个根因。

依赖关系不自动加载参考。子模块只使用：

- `前置条件`
- `协同检查`
- `重新验证`
- `升级条件`

只有主路由或基于证据的 `升级条件` 可以增加专业模块。

## 根因与修复所有权

观察域、根因所有者、修复所有者必须分离；按 `visual_projection.route` 记录。

## 失败分类

```yaml
failure:
  observed_evidence:
  scope:
  layer:
  source:
  confidence:
  owner:
```

范围：

- `LOCAL`
- `REGIONAL`
- `GLOBAL`
- `SYSTEMIC`

层级：

- `INTENT`
- `STRUCTURAL`
- `RELATIONAL`
- `RENDERING`
- `SURFACE`
- `COHERENCE`
- `DELIVERY`

来源：

- `DESIGN`
- `INSTRUCTION`
- `MODEL_CAPABILITY`
- `SOURCE`
- `DELIVERY`
- `UNKNOWN`

重复修复同一根因仍无改善时，必须重新判定失败来源；禁止无限追加提示词。
