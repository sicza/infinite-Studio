# `visual_contract_gate.py` 命令参考（读源码前先看这里）

> 从 SKILL.md 下沉（V8.73 token 整改）。**先看本页，不要整读 `scripts/visual_contract_gate.py`。** 只有本页没有的字段/行为才用 `--help` 或 `rg -n` 精确查。

入口：`python .agents/scripts/visual_contract_gate.py <subcommand> [...] --workspace-root .`

## 子命令与参数

| 子命令 | 参数 | 校验对象 / 作用 |
|---|---|---|
| `validate-narrative` | `--file` | Narrative–Visual Contract |
| `validate-spec` | `--file` | 唯一 Visual Spec（`<request>/work/visual-spec.json`） |
| `validate-binding` | `--file` | Prompt Binding（`work/prompt-binding.json`） |
| `validate-visual-gate` | `--file` | Visual Gate 结果（`visual-gate-result.json`） |
| `validate-baseline` | `--file` | Baseline Consumption receipt（`work/baseline-consumption.json`） |
| `validate-return` | `--file` | Visual Return |
| `stamp-narrative` | `--file` | 写入 request identity + `contract_revision` + `semantic_checksum` 后复验 |
| `bind-prompt` | `--visual-spec --prompt --compiler-profile --output [--spec-consumption]` | 生成并校验 `prompt-binding.json`（`sicza.prompt-binding.v2`：绑定 spec/prompt/pack 的 path+SHA、compiler_profile、adapter_family；写前校验，失败回滚旧 binding） |
| `identity` | `--request` | 输出 request identity（revision/hash 等） |
| `doctor` | 无 | schema/registry 自检（不联网） |

全部子命令接受可选 `--workspace-root`。`--compiler-profile` 必须来自 `config/visual-contracts/prompt-compiler-profiles.json`；`visual.still.production.v1` 的 Spec 在 bind 时必须提供 `--spec-consumption`（JSON 数组，或含 `spec_consumption` 的对象），否则拒绝写入。

## 输出与退出码

- 校验通过：`{"status":"passed","schema_version":"..."}`，退出码 `0`。
- `stamp-narrative`：`{"status":"stamped","file":"...","semantic_checksum":"<64 hex>"}`。
- `identity`：`{"status":"ready", ...request identity 字段}`。
- `doctor`：`{"status":"ready","schemas":[...],"semantic_selftests":{...},"provider_calls":false}`。
- 失败：`{"status":"blocked","error_code":"visual_contract_blocked","reason":"...","next_action":"fix the reported contract fact or regenerate the affected artifact, then rerun the same command"}`，退出码 `2`。

## 使用纪律

- Gate 只证明结构/绑定/哈希等机器事实，不证明专业质量；视觉域审图是按需能力，见 SKILL.md 验证边界。
- 失败只修 `reason` 指出的那一处合同事实或重生成受影响产物，再重跑同一命令；不要为了过 Gate 放宽 schema。
- 需要新字段时先确认 canonical schema（`workspace-governance/config/visual-contracts/*.json`），不要在 Skill 内自建同义 schema。
