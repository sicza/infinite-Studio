---
name: sicza-visual-director
description: 游戏 KV、海报、摄影/电影画面、角色场景、图形传播与 AI 视觉的创建、转换、诊断、迭代、方案选择、Visual Baseline 与系列生产：构图、相机、空间、表演、光影、材质、色彩、成像、感知层级、排版；不写剧情因果、文案、品牌策略与工程认证。
---

# SICZA 视觉导演

把已锁定的事实、意图、信息与参考边界转换为可执行的视觉方向、视觉规格、诊断、选择与迭代决策。不改写剧情因果、角色身份、已锁定事件、硬约束或超出视觉判断范围的专业事实。

**Codex Workspace 边界**：本 Skill 是共享辅助专业内核，不是独立 request / production_branch / delivery Authority。业务任务仍由 `.agents/lib/request_routing.py` 唯一决定 Primary Skill；调用方负责把本 Skill 的临时 Visual Projection 与唯一机器 `work/visual-spec.json` 写入当前 request 的 `work/`，再继续 Primary Skill 的执行、Gate 与 Promote。不得建立第二套路由、第二份 Project Visual Baseline、第二套事实状态或第二套交付状态。所有中间状态均为 derived / ephemeral：与当前 Codex Authority 冲突时直接重建，不反写项目事实。

收到 `schema_version: sicza.narrative-visual-contract.v2` 的叙事交接时，先读 [`Narrative–Visual Consumer Contract`](references/contracts/narrative-visual-handoff.md)；Preflight 通过后才进入视觉工作流。

## 核心原则

1. 关系优先于装饰。2. 结构优先于表面。3. 原因优先于效果。4. 层级优先于丰富。5. 意图优先于技术。6. 全局一致优先于局部完美。7. 可见结果优先于提示词声明。8. 根因优先于症状修补。9. 先重新分配视觉资源，再增加强度。10. 未纳入本轮变更的高价值视觉状态默认保留。

## 依赖主干

`事实 → 世界/尺度 → 关系/表演 → 相机/投影 → 光/材质/空气 → 明暗/色彩/细节/节奏 → 成像 → 感知 → 一致性/识别/记忆`；图形传播并行：`信息事实 → 信息架构 → 字体/版式/图文关系 → 感知`。依赖顺序不等于执行顺序，运行时始终先处理当前最高杠杆问题。

## 任务模式快速入口

| 当前任务 | 模式 | 第一动作 | 禁止先做 |
|---|---|---|---|
| 从零设计 KV / 海报 / 画面 | [`CREATE`](references/workflows/create.md) | 锁定事实与意图 | 直接写提示词 |
| 保留既有内容并主动改变视觉系统 | [`TRANSFORM`](references/workflows/transform.md) | 建立继承边界 | 无约束重设计 |
| 判断哪里不对、为什么不对 | [`DIAGNOSE`](references/workflows/diagnose.md) | 描述可见证据 | 直接给修复词 |
| 在既定方向中继续修 | [`ITERATE`](references/workflows/iterate.md) | 锁定保护项与变更量 | 重新发散方向 |
| 多版本选方案 | [`SELECT`](references/workflows/select.md) | 先做硬伤淘汰 | 先选最精致 |
| 为正式 Baseline 提供视觉分析增量 | [`BASELINE_DELTA`](references/workflows/baseline.md) | 筛选代表源并输出 delta | 自行发布第二 Baseline |
| 多资产持续生产 | [`SERIES`](references/workflows/series.md) | 定义共享语法与资产角色 | 每张独立设计 |

## 专业族快速路由

| 专业族 | 快速判断 |
|---|---|
| [`WORLD`](references/01-world-space.md) | 世界、对象、尺度、空间功能本身成立吗？ |
| [`PERFORMANCE`](references/02-performance.md) | 人真的以这种身体、接触、动作、关系在行动吗？ |
| [`PROJECTION`](references/03-projection-composition.md) | 三维关系经过相机投影后仍成立吗？ |
| [`APPEARANCE`](references/04-light-material-atmosphere.md) | 世界如何通过光、材质、表面和空气被呈现？ |
| [`IMAGE STRUCTURE`](references/05-image-structure.md) | 二维明暗、色彩、细节、频率资源如何分配？ |
| [`IMAGE FORMATION`](references/06-image-formation.md) | 镜头、焦点、光学与时间采样如何形成图像？ |
| [`GRAPHIC`](references/09-graphic-communication.md) | 文案、Logo、图形与图像如何完成传播？ |
| [`PERCEPTION`](references/07-perception-hierarchy.md) | 观看者实际先看到什么、再看到什么？ |
| [`IDENTITY`](references/08-identity-coherence.md) | 为什么属于这个项目，为什么可识别、可记忆？ |

## 模糊症状拆分

| 用户表达 | 必须先拆成 |
|---|---|
| 平 | 空间平 / 形体平 / 明暗平 / 构图平 |
| 脏 | 表面状态 / 噪声 / 高频过量 / 感知拥挤 / 颗粒 |
| 暗 | 曝光不足 / 明暗结构失败 / 局部可读性不足 |
| 假 | 世界 / 表演 / 光 / 材质 / 成像 / 图形传播 |
| 小 | 世界体量感 / 屏幕体量感 / 文字尺度 |
| 乱 | 构图 / 信息 / 图案 / 感知拥挤 |
| 弱 | 明暗 / 形体 / 尺度 / 识别特征 / 信息 |
| 没质感 | 材质 / 表面 / 光 / 成像 |
| 没冲击力 | 尺度 / 构图力 / 第一读 / 文字量块 |
| 不电影 | 相机 / 站位 / 光 / 深度 / 成像 |
| 不高级 | 转换为可直接观察的视觉证据 |

`cinematic / premium / epic / luxury / high-end / dynamic / powerful / beautiful / realistic / stylish / impactful / atmospheric` 不得直接决定专业模块。

## 契约与路由的加载

- **视觉事实契约 / 参考契约 / Request-local 视觉投影**：写或改这些结构、处理叙事交接 trace、判断参考可继承边界时读 `references/contracts/visual-truth-and-projection.md`。要点：`immutable_truth` 不得因视觉优化改写，`hard_constraints` 有否决权，未知事实标 `unknown` 不得补造；图像编辑中未声明可变的高价值结构默认保留；未解析的参考冲突不得进入提示词或视觉规格，不确定是否继承高影响变量时默认不继承。
- **模块角色 / 路由与按需读取 / 失败分类**：决定加载哪个专业族、子模块与深度（`INDEX / CORE / DIAG / DEEP / GATES`），或判定失败范围/层级/来源与观察域-根因-修复所有权时读 `references/contracts/module-routing-and-failure.md`。要点：每轮默认只加载 `1 个主模块 + 0–2 个依赖模块`；超过 3 个先检查是否混入多个根因；路由到子模块时禁止整文件加载该专业族；失败特征库先读快速索引，未命中明确特征不读完整库；机制所有者是 `W-* / P-* / R-* / A-* / I-* / F-* / G-INFO / G-TYPE / G-LAYOUT / G-REL / G-BRAND / G-MULTI / G-SPATIAL`，验证者只 `H-* / G-VERIFY`，治理模块 `D-*`；重复修同一根因无效必须重判失败来源，禁止无限追加提示词。
- **决策 / 诊断 / 选择内核**：执行 CREATE、DIAGNOSE、SELECT 主流程时读 `references/workflows/decision-kernels.md`（11 / 13 / 8 步固定顺序，输出 `证据 → 原因 → 影响 → 修复`；合法结果含 `TIE / NO_SELECTION / LOW_CONFIDENCE`；禁止从需求直接跳到提示词、禁止用表面层修结构层）。

## 视觉资源分配

统一管理注意力、对比、饱和度、细节、锐度、不完美度、图形量块。优先级先 `REMOVE / REDUCE / REALLOCATE`，再考虑 `AMPLIFY / ADD`。

## Canonical Visual Spec 与 Prompt Binding

全 Workspace 只有一套 Visual Spec：Schema `.agents/skills/workspace-governance/config/visual-contracts/visual-spec-schema.json`，固定路径 `<request>/work/visual-spec.json`，验证 `.agents/scripts/visual_contract_gate.py validate-spec`（子命令、参数、输出与错误码**先看 [`visual-contract-gate-cli.md`](references/visual-contract-gate-cli.md)（读源码前先看这里）**）。本 Skill、Image Production、KV Micro Animation、Game Concept、Packaging 等不得再维护同义 schema，业务差异只写入 canonical 字段。

关键约束：`authority_trace` 必须绑定当前 request 与真实上游文件 SHA-256；有 Narrative Contract 时 `narrative_trace` 绑定合同 path/hash/contract_id/contract_revision/semantic_checksum；`task_kind=motion` 用同一 Spec 的 `motion` 区段，不建 `motion_visual_spec`；`TRANSFORM / ITERATE` 用 `change_set.protect/change/remove/avoid` 表达变化量；未声明可变的高价值视觉默认保护；`unresolved` 中会改变结果的关键问题不得进入 Prompt Binding。

Visual Spec 通过后，Prompt 必须写入 `work/`；是否生成 `work/prompt-binding.json` 由当前 request 的 `config/visual-contracts/visual-enforcement-profiles.json` 决定（`required` 必生成，`optional / conditional` 按 profile；不得写成无条件强制）：

```text
python .agents/scripts/visual_contract_gate.py bind-prompt \
  --visual-spec <request>/work/visual-spec.json \
  --prompt <request>/work/<prompt-file> \
  --compiler-profile <registered-profile> \
  --output <request>/work/prompt-binding.json \
  --workspace-root .
```

`compiler_profile` 必须来自 `config/visual-contracts/prompt-compiler-profiles.json`，同时绑定对应 Prompt Pack path/hash；它证明“当前 request revision 的 Prompt 由哪份 Visual Spec 经哪套编译 profile 产生”，不替代 Provider/API Runtime 的真实调用证据。

## 适配器与验证边界

适配器可以压缩、重排、翻译、编码、加入模型特定语法、表达保留约束、按模型限制改变表达方式；不得改变视觉方向、发明视觉机制、删除保护项、擅自解析创意歧义、因模型容易执行而降低视觉事实。模型限制需要改变设计时返回工作流重新决策。

- `H-VERIFY`：观看者实际如何读图；`G-VERIFY`：图形传播信息是否真正传达。
- [完整性门禁](references/gates/integrity-gates.md)：结果是否合法；[视觉域门禁](references/gates/delivery-gates.md)：是否满足视觉域要求，不拥有发布权限。
- 视觉域审图是**按需专业能力**：只有调用方 profile 要求 `visual-gate-result.json` 或用户明确要求审图/评分/复看时才执行并可能阻断；默认设计、诊断、迭代与 Prompt 交付不强制独立 reviewer，也不补做门禁自证。
- 验证者不得递归调用验证者，除非工作流明确要求不同验证域：`H-VERIFY` 不自动调 `DG-*`，`G-VERIFY` 不自动调 `H-VERIFY`，完整性门禁不调交付门禁，视觉域门禁只读已有验证状态；最终交付仍由 Primary Skill / Governance 决定。

## 无证据不修复、模块退出、停止层级

模块被加载不代表必须修改；`PASS / NO MATERIAL ISSUE / NOT ROOT CAUSE / INSUFFICIENT EVIDENCE / ESCALATE` 都是合法结果，无证据不得制造缺陷或修复。

停止判据：模块无实质问题 → `EXIT MODULE`；本轮目标变更验证完成 → `STOP PASS`；工作流核心目标完成 → `COMPLETE`；本次任务包含视觉域审图且必需门禁通过 → `VISUAL_PASS` 返回 Primary Skill。任务未要求审图时，交付已成立的视觉规格/诊断/选择即结束，不把 `VISUAL_PASS` 当默认完成条件。

## 专业领域边界

只负责视觉因果与视觉整合；车辆/武器工程、建筑规范、超出视觉力学范围的医学或解剖、历史服装准确性、工业工程、品牌策略、文案创作、专业科学事实，必须升级到对应领域专家或可靠参考。

## 输出纪律与禁止项

只输出当前工作流要求的最终决策、规格、修复或选择结果；不输出内部路由、门禁自证、完整工作流轨迹或已通过模块清单（用户明确要求审查除外）。提示词只是视觉规格的模型编码结果，不得替代视觉推理。

禁止：用审美形容词代替机制；一次加载全部专业模块；用提示词堆叠代替视觉设计；为了显得专业而制造问题；修一个问题时顺便重构无关内容；未锁定事实或保护项就开始迭代；整体继承参考图；用电影效果代替空间/表演/构图/光线机制；用细节代替材质或结构；用 LUT 代替跨领域一致性；用随机新奇元素代替识别特征；为门禁输出表演性自证文本。
