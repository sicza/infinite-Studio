# KV / Banner 图层执行、合成与失败续做

## 1. Output contract

本文件是 `wxian-image-layer-decomposition` 的**唯一人类可读 Final Output Contract Authority**。`SKILL.md` 与其它 Reference 只做摘要或语义说明，不得维护第二份 Final 目录或 Manifest 字段清单。

机器 Authority 为 `scripts/delivery_gate.py` 与共享 `.agents/lib/deterministic_layer_finalization.py`。若本文与机器 Gate 不一致，必须视为 Contract Drift 并修复，不能任选其一执行。

### 1.1 Pre-final / execution work

```text
work/source-work.png                 # provider-legal work surface
work/decomposition-size.json          # source/work/delivery + transforms when persisted
work/layer-analysis.md
work/layer-graph.json
work/occlusion-graph.json
work/interaction-graph.json
work/layer-plan.json
work/api-prompts/
work/layer-prompt-package.md       # reconstruction plan only
work/layer-prompt-manifest.json    # reconstruction plan only
work/visual-spec.json              # reconstruction plan only
work/prompt-binding.json           # reconstruction plan only
work/generation-plan.json          # includes source_contract
work/api-requests/
work/final/originals/provider/     # Provider 原始响应；每个选中的 API pass 的不可变原始证据
work/final/originals/<layer_id>.png # 批准的 PSD 原件：由 final full-canvas layer 按 bbox 确定性裁切，PSD 唯一可嵌入的 source
work/intermediate/                 # source-lock / masks / merge 中间件
```

### 1.2 Mandatory final pack

```text
work/final/layers/full-canvas/<layer_id>.png
work/final/layers/crops/<layer_id>.png
work/final/layer-manifest.json
work/final/layer-graph.json
work/final/ownership-audit.json
work/final/ownership-overlap.png
work/final/ownership-holes.png
work/final/recomposition.png
work/final/recomposition-diff.png
work/final/recomposition-diff.json
work/final/layer-qa.json          # 按需可选的专业 QA 记录
work/final/layered.psd
work/final/layered.preview.png
work/final/layered-psd.json
```

Primary Pixel Owner 的 `source_visible_mask` 也是 mandatory final artifact；实际路径由 `layer-manifest.json` 绑定，不建立第二套固定命名。若 `recomposition-diff.json` 绑定 evaluation mask，该 mask 同样属于正式交付证据。上述 Gate-required 文件必须进入 active `delivery-manifest.json`；按需生成的专业 QA 记录若存在也必须纳入。

`layered.psd` 由独立 `$wxian-layered-psd-export` 消费 Final Manifest 生成。PSD document canvas 等于 `delivery_canvas`；每个 layer 是 Embedded Smart Object，其 `editable_master`、hash、intrinsic size 与 delivery-space bbox/transform 必须可代码回读验证。普通拆图的默认 `editable_master` 为 1× bbox。不存在 raster PSD fallback。

生产与回读只能使用：

```bash
python .agents/skills/wxian-layered-psd-export/scripts/psd_export.py build \
  --workspace-root <workspace-root> \
  --manifest work/final/layer-manifest.json \
  --output work/final/layered.psd \
  --receipt work/final/layered-psd.json

python .agents/skills/wxian-layered-psd-export/scripts/psd_export.py verify \
  --workspace-root <workspace-root> \
  --receipt work/final/layered-psd.json
```

`layered.preview.png` 是由同一 exporter 从 manifest/master 确定性生成的 1× document composite。

### 1.3 Optional QA views

```text
work/final/previews/
```

`previews/`、灰/黑/白/棋盘背景预览只用于人工 QA convenience，**不是 delivery Authority，也不是 completion mandatory artifact**。正式图层 Authority 是 Manifest 绑定的 delivery-space RGBA PNG + `editable_master` + geometry；full-canvas PNG 用于确定性回合成，PSD Smart Object 使用 editable master。

## 2. Source / Work / Delivery Size Contract

源图尺寸是输入事实；模型工作尺寸只服务 provider 合法性；最终交付尺寸默认保持源图。普通拆图默认 prefer 1× work，尺寸对齐优先 padding，不得默认升 4K，也不得让模型 work surface 静默改写最终 PSD 尺寸。

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py prepare-work-surface ^
  --source <source> ^
  --output <work/source-work.png> ^
  --record-output <work/decomposition-size.json> ^
  --profile image ^
  --model gpt-image-2.5-sunburst ^
  --workspace-root .
```

Plan / Generation API 必须同时绑定 `source_canvas_size`、`delivery_canvas_size`、`work_canvas_size` 与完整 `size_contract`。Source-visible RGB 回写必须从原始 source/delivery reference 取像素，不能把缩小后的模型工作图重新放大冒充原始像素。

随后直接从原始 source 建立 delivery-space Reference；禁止从 work surface 回投影生成此 Reference：

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py prepare-delivery-reference ^
  --source <source> ^
  --size-contract <work/decomposition-size.json> ^
  --output <work/final/delivery-reference.png> ^
  --workspace-root .
```

默认 `delivery=source` 时保持 source RGB 像素；只有用户显式要求不同 delivery 尺寸时才从原 source 单次重采样。Final Gate 会从原 source 重新计算 expected delivery reference 并逐像素比对，因此错误 Reference + 自报 hash 无法通过。

## 3. Native Alpha Output QA

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py alpha-audit ^
  --layer <generated-transparent.png> ^
  --report <work/...alpha.json> ^
  --size-contract <work/decomposition-size.json> ^
  --bbox-hint <X> <Y> <WIDTH> <HEIGHT> ^
  --workspace-root .
```

透明输出必须 RGBA 且存在透明像素。带 `--size-contract` 与 `--bbox-hint` 时，同一份报告同时给出 matte 质量判定，任一不满足即 `status=failed` 且命令失败：

```text
containment_ratio >= 0.9      可见 alpha 必须落在分析阶段声明的 bbox 内（容差 8px）
opaque_share >= 0.25          可见 alpha 中必须有相当比例的全不透明像素
hint_coverage_ratio > 0.005   分析声明的 bbox 内必须有真实内容
```

`opaque_share` 判据针对“整画布半透明面纱”：那种响应一个全不透明像素都没有，既不是该单元的 alpha，也无法在后续归属中被修复。0.25 的下限给羽化边缘留出空间，同时仍能区分面纱与真实 matte。`effect` / `shadow` / `reflection` 三个软 alpha 层类型只校验几何（containment 与覆盖率），不要求不透明占比，因为它们本来就允许大面积半透明。

生成模型经常返回这类面纱：必须在进入 source-lock 之前止损，重提该 Pass 或改用下面第 3.1 节的分割手段，不得靠调阈值或 bbox 矩形裁切继续。

### 3.1 各 Pass 的 alpha 语义

`background=transparent` 的 Pass 必须只包含本 Pass 的目标单元；`visible` Pass 只包含当前可见像素，不得包含被更前层遮住的区域，否则该层 alpha 会去抢别的层的像素。`background=opaque` 的净底板候选不参与 matte 质量判定，它由 `patch-clean-plate` 处理。净底板被排除需要三个事实同时成立：标签是 `background-clean`、声明 bbox 等于整张交付画布、且它是 Plan 里 z_order 最低的一层。缺任一项（含字段缺失）都按普通归属单元处理，因此把前景层改名成 `background-clean` 或把它的 bbox 撑到全画布都不能关掉 matte 判定与两两重叠检查。

Final Gate 会重算**每一个** `background=transparent` 的 Provider 原始响应，不按 `strategy` 豁免，因此把策略写成 `source_asset` 之类并不能跳过这条判定；工作流中跳过 `alpha-audit` 也不能绕过完成门禁。

两两 matte 重叠检查同样覆盖**每个单元的每个透明 Pass**：只要任一 Pass 与另一单元任一 Pass 的重叠份额超过 0.5 就阻断，不能靠“visible Pass 干净、reconstruct Pass 重叠”绕开。

“是不是归属单元”只由结构事实决定：该层实际产出了一个 `background=transparent` 的 Provider 响应。声明 `strategy` 不能把一层排除在检查之外——`clean_plate_patch` 之类只要真的产出了透明 Pass，就仍参与两两比较。唯一的排除是同时满足标签、全画布 bbox 与最低 z_order 的净底板。

## 3.2 Exclusive Ownership Resolution

各层 alpha 互斥归属必须由确定性命令完成，禁止自写脚本、禁止用 bbox 矩形填充 alpha：

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py resolve-ownership ^
  --plan <work/layer-plan.json> ^
  --locked L100_SKY=work/intermediate/L100_SKY--visible-locked.png ^
  --locked L300_HERO=work/intermediate/L300_HERO--visible-locked.png ^
  --output-dir work/final/ownership ^
  --workspace-root .
```

命令按 z 序从高到低分配，每个可见像素只归一个 owner，并输出：

```text
work/final/ownership/<layer_id>.png                     互斥全画布 RGBA 层
work/final/ownership/<layer_id>--ownership-mask.png     source_visible_mask
work/final/ownership/ownership-resolution.json          逐层分配与冲突收据
```

收据同时给出每层的 `lost_ratio`（自身 alpha 被更高层拿走的比例）与 `bbox_fill_ratio`，并据此阻断三类失败：

```text
lost_ratio > 0.5        该层 alpha 大面积覆盖了别的单元，说明 Provider matte 没有做单元分离
bbox_fill_ratio >= 0.9  该层 alpha 就是一个 bbox 矩形，不是轮廓
declared_pixels == 0    该层在自己声明的 bbox 内没有任何内容
```

这两个上限是契约常量（0.5 / 0.9），CLI 只能收紧不能放宽：`--max-lost-ratio` 与 `--max-bbox-fill-ratio` 超过常量即拒绝执行。轮廓判定是二选一而不是豁免：`text-logo-overlay` / `decoration-overlay` / `building` / `vehicle` / `prop` / 全画布净底板这类矩形本体层必须真的接近矩形（`bbox_fill_ratio >= 0.9`），其余层必须是形状轮廓（`< 0.9`）。把层类型写成矩形类型并不能跳过判定，只会换一条必须满足的条件。该谓词由共享库单点定义，`resolve-ownership` 与 Final Gate 使用同一份。

`--locked` 必须覆盖所有 `source_locked_*` / `model_native_alpha` 且有 API Pass 的层，缺一层即阻断。

`resolve-ownership` 是工作流助手：它在生成阶段就暴露冲突、产出互斥层与 mask，让执行者尽早止损。它不是交付 Authority——收据由生产侧写出，因此不能作为判据。正式层的 `source_visible_mask` 直接取它产出的 mask。

真正的权威判据在 Final Gate，且不读任何收据：Gate 直接从 hash 绑定的 Provider 原始响应重算任意两个归属单元 alpha 的重叠份额，超过 0.5 即阻断。互斥层在归属解析之后必然两两不重叠，因此“某单元 matte 也认领了别的单元”这个失败信号只存在于 Provider 原始响应里，必须在那里检查。

## 4. Source Pixel Lock

将 Image 2.5 的透明提取仅作为 Alpha carrier，把源图 RGB 锁回：

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py source-lock ^
  --source <work/final/delivery-reference.png> ^
  --alpha-carrier <visible-alpha.png> ^
  --output <work/intermediate/Lxxx-visible-locked.png> ^
  --workspace-root .
```

这一步的价值：可见区保持源画面，而不是接受模型重画后的近似 RGB。

## 5. Hidden Reconstruction Merge

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py merge-reconstruction ^
  --visible <work/intermediate/Lxxx-visible-locked.png> ^
  --reconstruction <work/final/originals/provider/Lxxx-reconstruct.png> ^
  --output <work/final/layers/full-canvas/Lxxx.png> ^
  --workspace-root .
```

合并逻辑：

```text
visible Alpha 覆盖区 → visible/source RGB 为 Authority
仅 reconstruction 独有 Alpha 区 → 模型补全
```

## 6. Clean Plate Patch

先把所有应从背景移除对象的 visible-alpha 合成 occupancy mask：

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py mask-union ^
  --layers <visible-a.png> <visible-b.png> ... ^
  --output <work/intermediate/background-occlusion-mask.png> ^
  --expand 6 ^
  --feather 2 ^
  --workspace-root .
```

再只用模型候选补洞：

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py patch-clean-plate ^
  --source <work/final/delivery-reference.png> ^
  --generated <work/final/originals/provider/L000-background-clean.png> ^
  --mask <work/intermediate/background-occlusion-mask.png> ^
  --output <work/final/layers/full-canvas/L000_BACKGROUND_CLEAN.png> ^
  --workspace-root .
```

这样未遮挡环境保持源像素，只有需要移除/补全的区域来自模型。

## 7. Crop Derivative

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py crop ^
  --layer <full-canvas-layer.png> ^
  --output <component-crop.png> ^
  --record-output <crop-record.json> ^
  --padding 16 ^
  --workspace-root .
```

crop 只由当前 full-canvas 图层确定性裁切产生；专业 QA 记录不是裁切或完成前提。

## 8. Preview / Gray Review

## 8.1 Approved PSD Original

每个 API layer 完成 source-lock / merge 后，必须以**计划阶段固定的 bbox**生成 PSD 原件；不得按偶然 Alpha bbox 再猜测位置，也不得把 Provider 的整张 work-surface 直接缩放进 PSD。

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py finalize-editable-master ^
  --layer <work/final/layers/full-canvas/L300_HERO.png> ^
  --provider-original <work/final/originals/provider/L300_HERO__visible.png> ^
  --bbox <x> <y> <width> <height> ^
  --minimum-visible-coverage-ratio <analysis value> ^
  --output <work/final/originals/L300_HERO.png> ^
  --record-output <work/final/master-receipts/L300_HERO.json> ^
  --layer-id L300_HERO ^
  --workspace-root .
```

该命令阻断 bbox 外可见 Alpha、空内容和低于分析覆盖下限的 layer。将 receipt 的 `provider_originals` 与 `derivation` 原样写入 Final Manifest 的 `editable_master`；Gate 会独立重算，不接受手写替代。

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py preview --layer <layer.png> --output <preview.png>
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py gray-export --layer <layer.png> --output <gray.png>
```

灰底只是审阅衍生，不是拆层方法。

## 9. Batch API

Agent 完成 `layer-plan.json` 与每个 Prompt 后：

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_batch.py prepare-contract --plan <work/layer-plan.json> --workspace-root .
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_batch.py build --plan <work/layer-plan.json> --workspace-root .
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_batch.py run --plan <work/layer-plan.json> --workspace-root . --mode dry-run
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_batch.py run --plan <work/layer-plan.json> --workspace-root . --mode invoke
```

`prepare-contract` 对 reconstructed plan 是强制门禁，生成 `visual-spec.json / prompt-binding.json / layer-prompt-manifest.json` 并绑定当前 layer-plan、source/work/delivery size contract 和逐 Pass Prompt SHA。纯 source-only extraction 返回 `not_required`。

`build` 创建有限 generation-plan 与 API request，并写入 `source_contract`；Image API 会在每次 request preflight 时验证 plan/source/work/delivery hash 与 reconstructed Visual Contract。`dry-run` 复用单一进程离线验证整批 request，不要求 credential；`invoke` 才允许联网。`run` 不改 Prompt，不改参数，不自动重试内容性失败。

## 10. Source-visible Ownership Audit

Final manifest 中每个 `primary_pixel_owner=true` 的层都要提供 `source_visible_mask`（full-canvas RGBA mask）。然后：

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py ownership-audit ^
  --manifest <work/final/layer-manifest.json> ^
  --overlap-output <work/final/ownership-overlap.png> ^
  --hole-output <work/final/ownership-holes.png> ^
  --report <work/final/ownership-audit.json> ^
  --workspace-root .
```

如果某些区域（例如文字 strip、无 ground-truth 的 hidden completion）不应参与像素比较，先用 `regions-mask` 从 bbox 列表建立 evaluation mask：

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py regions-mask ^
  --regions-json <work/evaluation-exclusions.json> ^
  --size <WIDTHxHEIGHT> ^
  --mode exclude ^
  --expand 2 ^
  --feather 1 ^
  --output <work/final/evaluation-mask.png> ^
  --workspace-root .
```

## 11. Recompose

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py recompose ^
  --manifest <work/final/layer-manifest.json> ^
  --output <work/final/recomposition.png> ^
  --workspace-root .
```

然后：

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py compare ^
  --source <work/final/delivery-reference.png> ^
  --recomposed <work/final/recomposition.png> ^
  --diff-output <work/final/recomposition-diff.png> ^
  --report <work/final/recomposition-diff.json> ^
  --evaluation-mask <work/final/evaluation-mask.png> ^
  --workspace-root .
```

像素差异报告只是定位工具；最终仍要实际视觉检查。

## 12. Failure Continuation

单层失败：

```text
记录 layer/pass
保留其他已通过层
只重做失败 pass
重跑受依赖的 source-lock/merge/clean-plate/recomposition
```

API 超时、远端状态未知时遵守 image-generation-api 的 `remote_state_unknown` 规则，不自动再次收费提交。

## 13. Final completion contract

正式 `promote` 由 `scripts/delivery_gate.py` 验证，不接受只有通用 `delivery-manifest.json` 的完成声明。

### `wxian.kv-final-layer-manifest.v2`

根字段：

```text
schema_version / status
layer_plan_path / layer_plan_sha256
decomposition_skill
source_image / source_sha256 / source_canvas_size
delivery_canvas_size
delivery_reference_image / delivery_reference_sha256
layer_graph_path / layer_graph_sha256
layers[]
```

每个 `layers[]` 至少绑定：

```text
layer_id / status / layer_type / depth_band / z_order
file / sha256 / output_mode / anchor / bbox / dependencies
blend_mode / blend_mode_hint
primary_pixel_owner
source_visible_mask / source_visible_mask_sha256
source_visible_region_source_locked
reconstructed_region_present
reconstruction_confidence / reconstruction_provenance
motion_envelope_px / motion_margin_px / interaction_members
crop_file / crop_sha256
editable_master.file / editable_master.sha256 / editable_master.size
editable_master.scale_vs_delivery (=1.0) / editable_master.provenance (`source_preserved | ai_reconstructed | ai_upscaled | deterministic_resample | mixed`)
editable_master.provider_originals[] (selected API output file / sha256 / work-canvas size)
editable_master.derivation (delivery_bbox_crop_v1 / source_canvas_file / source_canvas_sha256 / crop_bbox)
minimum_visible_coverage_ratio
```

Final layer set 必须与当前 `layer-plan.json` 完全一致；任何 `unrecoverable` layer 都不能作为 completed request 晋升。Gate 必须从当前 source/plan/layer/mask bytes 重算 Source Lock、ownership、recomposition 与 diff；报告或 QA 中的结论、pixel diff 数值或 hash 只能作为绑定记录，不能替代重新计算。

### `wxian.kv-layer-qa.v2`（按需专业 QA，可选）

用户明确要求审图/质量复核，或高风险交付时生成。它不是默认完成前提；若要作为交付证据，必须 SHA 绑定当前字节：

```text
layer-manifest
ownership-audit
recomposition
recomposition-diff
```

推荐记录全部 layer 已被审阅，并逐项给出以下专业观察：

```text
source_visible_fidelity_review
alpha_boundary_review
geometry_review
occlusion_review
interaction_integrity_review
```

`layer_reviews` 推荐逐层记录 `layer_id` / `layer_sha256` / `verdict` / `observation`，让结论可回指具体层字节：

```json
{
  "layer_reviews": [
    {"layer_id": "L400_LEFT_MEDIC", "layer_sha256": "...", "verdict": "PASS",
     "observation": "本层 alpha 只覆盖左侧医护与其手提医疗箱，医疗箱完整在本层，未包含担架组或台阶"}
  ]
}
```

`layer_sha256` 必须等于当前正式层字节，`observation` 描述该层 alpha 实际包含什么。QA 记录只表达专业判断，不证明机器事实，也不会单独阻断交付。

Final Gate 另外独立重算（不采信 QA 声明）：Provider matte 质量、层 alpha 是否等于 bbox 矩形、`character_registry` 中每个角色与道具是否由自己那层覆盖、是否被其它角色层侵占。

所有正式交付的 layer/crop/mask/manifest/graph/recomposition/PSD 资产，以及已生成的专业 QA 记录，必须进入 active `delivery-manifest.json`；否则 `workspace-governance promote` 必须 BLOCK。
