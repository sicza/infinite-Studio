---
name: wxian-image-layer-decomposition
description: 把已合成 KV、Banner、Poster、Key Art、角色、场景、特效、LOGO 按深度、遮挡与语义恢复为可编辑分层工程（RGBA PNG + 确定性回合成 + PSD）；真实游戏 UI 截图→wxian-game-ui-layer-decomposition。
---

# Composite Image Layer Decomposition

进入前执行：

```text
$workspace-governance consume-personal-context --request <request> --consumer wxian-image-layer-decomposition
```

新需求由 `$workspace-demand-intake` 建立 `request_type=image-layer-decomposition`。

## Scope

输入分两类：

```text
decomposition_profile=kv-depth
已合成 KV / Banner / Poster / Key Art，重点是深度、遮挡和 2.5D 控制

decomposition_profile=generic-composite
角色图、场景图、特效图、LOGO、混合视觉，重点是语义归属和独立编辑价值
```

真实游戏界面截图、HUD、Panel、菜单、Screen-space UI 与 World-space UI 不属于 `generic-composite`，由 Game UI Primary 承接。

输出：具有明确深度、遮挡、交互关系、像素归属、坐标和可重组能力的 Layer Asset Pack。

完成目标：

```text
source-visible 区域保持源图 Authority
需要运动暴露的隐藏区域完成有限重建
独立控制单元具有 layer_id / bbox / anchor / z_order
角色粒度按 decomposition_granularity 锁定，并输出 character_registry
每个登记的 character / held prop 由自己那层覆盖，角色不被背景层或邻近角色层吞并
source-visible 普通像素具有唯一 Primary Pixel Owner
正式透明层使用原生 Alpha PNG，且 Provider alpha 是可用 matte
所有正式层可按 z_order 确定性回合成
```

`rgb 源锁 + 覆盖率 + 回合成一致` 只证明可见画面没有被改动，不证明角色被正确拆分。角色归属的机器证据只有两处：Provider matte 质量与 `character_registry` 覆盖检查。

## Authority / Owners

```text
Source image                 原始像素、构图、镜头、位置、比例、source-visible 外观 Authority
Size Contract V2             source / work surface / delivery 尺寸与 transform Authority
Layer/Occlusion/Interaction  分层、遮挡、交互关系 Authority
layer-plan.json              本次生成与资产契约 Authority
final layer manifest         正式交付资产索引 Authority
machine finalization         hash / geometry / ownership / source-lock / recomposition / diff
layer-qa.json                （可选）Alpha、遮挡合理性、隐藏补全与视觉质量的专业 QA 记录
workspace-governance         promote / completion owner
```

`VISIBLE_REGION` 使用 Source Lock；`RECONSTRUCTED_REGION` 使用模型补全并记录置信度与 provenance。补全范围由预计运动暴露区与 seam safety 决定。

## Required References

分析与拆层：

- [decomposition-method.md](references/decomposition-method.md)
- [taxonomy-and-output-contract.md](references/taxonomy-and-output-contract.md)

模型与 Prompt：

- [gpt-image-2-5-layer-workflow.md](references/gpt-image-2-5-layer-workflow.md)
- [layer-prompts-and-quality.md](references/layer-prompts-and-quality.md)

资产处理、QA 与正式完成：

- [layer-execution-contracts.md](references/layer-execution-contracts.md)

其中 `layer-execution-contracts.md` 是 Final Output layout / mandatory artifacts / final manifest schema 的唯一人类可读 Authority；`taxonomy-and-output-contract.md` 不维护第二份 Final Manifest。其它 Reference 按对应专业规则分工维护。

## Execution

### 1. Intake / Canonical Source

读取源图、`request.md`、输入材料与下游用途，建立 Source Lock、Size Contract V2 与 `work/layer-input-lock.md`。记录：

```text
source path / sha256 / dimensions / format
carrier
source canvas / delivery canvas / work surfaces
intended downstream
decomposition granularity (per-character / per-unit / per-role-group)
explicit isolate / keep-together requests
text/logo fidelity requirement
motion budget when known
```

用户未指定固定层数时，以“可重新合成 + 主体可独立显隐/位移 + 轻量 2.5D 视差安全”为默认完成目标。

角色粒度未明确时按 `per-character` 执行，并在 `work/requirement-lock.md` 写入 `layer_granularity` 行；Plan 的 `decomposition_granularity` 必须与该行一致，Plan 侧没有临时降级通道。用户确实要求合并时，由需求阶段把 lock 记成更粗的粒度。

### 2. Analysis

依次生成：

```text
work/layer-analysis.md
work/layer-graph.json
work/occlusion-graph.json
work/interaction-graph.json
work/layer-plan.json
```

分析顺序：

```text
depth relation
→ semantic ownership
→ occlusion
→ interaction binding
→ independent-control value
→ source-visible ownership
→ hidden completion scope
```

主体层使用 `interaction_bound_subject_unit`；Layer Plan 与三个分析 Graph 通过 path + SHA256 和 schema/semantic binding 连接。

Layer Plan 必须同时给出 `decomposition_granularity` 与 `character_registry`。登记表是场景里每个角色实例的清单，逐项记录它属于哪一层、角色 bbox，以及它手持/穿戴/背负的道具 bbox。没有登记表，后续无法从像素上区分“角色在自己的层里”和“角色被留在背景里”。

`per-character` 下，`character_registry` 的每个角色映射到各自独立的 `hero-subject` / `supporting-character` 层；一个角色被登记到 `npc-group`、`vehicle` 或环境层，或两个角色共用一层，都会在 `validate_plan` 直接阻断。

### 3. Plan / Visual Contract

当 Plan 含 reconstruction strategy 时先编译 Visual Contract，再构建 generation plan：

```text
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_batch.py prepare-contract --plan <work/layer-plan.json> --workspace-root .
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_batch.py build --plan <work/layer-plan.json> --workspace-root .
```

`prepare-contract` 生成：

```text
work/visual-spec.json
work/prompt-binding.json
work/layer-prompt-package.md
work/layer-prompt-manifest.json
```

纯 `source_locked_extract` Plan 的 Visual Contract 状态为 `not_required`。

### 4. Provider Execution

先验证请求，再执行 Provider：

```text
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_batch.py run --plan <work/layer-plan.json> --workspace-root . --mode dry-run
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_batch.py run --plan <work/layer-plan.json> --workspace-root . --mode invoke
```

`dry-run` 只做本地 contract/preflight；`invoke` 执行实际 Provider 调用。单层失败只重做该层 Pass 与受其依赖的下游资产。

每个 `background=transparent` 的 Pass 返回后，先用 `alpha-audit --size-contract --bbox-hint` 判定它是否是可用 matte。整画布半透明、越出声明 bbox、或空内容都必须在 source-lock 之前止损：重提该 Pass、换分割手段，或缩小该层目标。禁止用调阈值、bbox 矩形裁切或“先合进去再说”继续。

### 5. Deterministic Asset Finalization

按 [layer-execution-contracts.md](references/layer-execution-contracts.md) 使用 `layer_assets.py` 完成：

```text
prepare-work-surface
prepare-delivery-reference
alpha-audit
source-lock
merge-reconstruction
mask-union / regions-mask
patch-clean-plate
resolve-ownership
crop
ownership-audit
recompose
compare
```

各层 alpha 的互斥归属只能由 `resolve-ownership` 完成：它按 z 序分配、输出每层 mask 与冲突收据，并阻断“alpha 大面积覆盖其它单元”和“alpha 等于 bbox 矩形”两类失败。该命令是工作流助手，不是交付 Authority：它的收据不可作为判据，Final Gate 会直接从 Provider 原始响应重算两两 matte 重叠份额。禁止自写归属脚本，禁止用 bbox 矩形填充 alpha，禁止用阈值调参掩盖 Provider matte 失败。

正式层以 full-canvas RGBA 为回合成 Authority；crop 由 full-canvas 确定性派生。Primary Owner 的 `source_visible_mask` 取自 `resolve-ownership` 收据；Ownership 只覆盖 source-visible 像素。

### 6. QA（按需）

用户明确要求审图/质量复核，或高风险交付时，执行专业 QA 覆盖：

```text
Alpha / edge quality
geometry / perspective / pose
occlusion continuity
interaction-unit integrity
hidden reconstruction plausibility
text/logo fidelity
visual recomposition quality
```

专业 QA 结果写入 `work/final/layer-qa.json`，作为绑定当前字节的专业记录；它不是默认完成前提，也不替代下列机器事实。机器 finalization 独立验证：

```text
source / plan / graph / asset hashes
full-canvas geometry
Primary Pixel Ownership coverage
source-visible RGB lock
z-order recomposition bytes
recomposition diff metrics
formal delivery membership
```

隐藏生成区没有 source ground truth，其质量由结构连续性、证据一致性、运动安全与专业 review 判断。

## Final Delivery

正式交付包含（`layer-qa.json` 为按需可选的专业 QA 记录）：

```text
work/final/layers/full-canvas/*.png
work/final/layers/crops/*.png
work/final/layer-manifest.json
work/final/layer-graph.json
work/final/ownership-audit.json
work/final/ownership-overlap.png
work/final/ownership-holes.png
work/final/recomposition.png
work/final/recomposition-diff.png
work/final/recomposition-diff.json
work/final/layer-qa.json
work/final/layered.psd
work/final/layered.preview.png
work/final/layered-psd.json
```

PSD 是独立下游 Skill 的代码交付，不属于拆图判断本身。禁止手写 PSD 或手写 `layered-psd.json` 收据：

```bash
python .agents/skills/wxian-layered-psd-export/scripts/psd_export.py build \
  --workspace-root <workspace-root> \
  --manifest work/final/layer-manifest.json \
  --output work/final/layered.psd \
  --receipt work/final/layered-psd.json

python .agents/skills/wxian-layered-psd-export/scripts/psd_export.py verify \
  --workspace-root <workspace-root> \
  --receipt work/final/layered-psd.json
```

普通拆图默认 `delivery_canvas = source_canvas`，`editable_master = 1x bbox`。Provider 原始响应必须写入 `work/final/originals/provider/`；经 source-lock / final full-canvas layer 以声明 bbox 确定性裁切出的批准 PSD 原件必须写入 `work/final/originals/<layer_id>.png`。PSD 只能嵌入该批准原件，且 Final Manifest 必须绑定全部选中的 Provider 原始响应、full-canvas 源、裁切 bbox 与 hash；不存在 raster PSD fallback。

Gate 与交付自检使用同一回读校验器，因此手写产物无法通过 Completion。完整契约见 `references/layer-execution-contracts.md`。

`workspace-governance promote` 在 `primary_skill=wxian-image-layer-decomposition` 时调用 `scripts/delivery_gate.py`。Completion 要求：

```text
layer-manifest schema = wxian.kv-final-layer-manifest.v2, status=READY
layer-graph 与 analysis Authority hash 一致
layer-plan schema = wxian.kv-layer-plan.v6（V8.70 收紧），decomposition_granularity 与 requirement-lock 的 layer_granularity 一致
character_registry 合法：per-character 必须非空，且一人一层、道具同层
每个 background=transparent 的 Provider 原始响应通过 matte 质量判定
每个正式层 alpha 不等于自身 bbox 矩形
character_registry 中每个 character / held prop 由自己那层认领（归属份额 >= 0.8），其它归属单元至多占 0.2
任意两个归属单元（由结构事实判定：真的产出了透明 Pass）的 Provider matte 重叠份额 <= 0.5（Gate 从原始响应重算，不读收据）
ownership result = overlap_pixels=0 / hole_pixels=0
recomposition 与当前 final layers 精确一致
recomposition diff 与当前 source/recomposition 重算结果一致
layer-qa.json（若生成）绑定当前 manifest / ownership / recomposition / diff 字节；不作为完成前提
Final Manifest 覆盖当前 Layer Plan 的全部可交付 layer
layered PSD 文档画布等于 delivery_canvas；逐层回读必须为 Embedded Smart Object，embedded master hash / intrinsic size / transform 与 Final Manifest 一致；每层必须满足分析阶段声明的 `minimum_visible_coverage_ratio`，并且 source-visible mask 不得为空
所有正式资产进入 active delivery-manifest.json
```

`layer-qa.json` 是按需专业 QA 记录；machine finalization 负责可确定计算的事实。Completion 由机器可验证事实决定；用户明确要求审图或高风险交付时，专业 QA 作为诊断证据附加，不自动阻断交付。

## Boundary / Routing

HUD、游戏界面截图的按钮、面板、导航、Screen-space UI、World-space UI 拆分使用 `$wxian-game-ui-layer-decomposition`。
