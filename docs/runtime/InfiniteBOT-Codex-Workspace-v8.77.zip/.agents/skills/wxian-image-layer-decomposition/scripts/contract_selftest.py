#!/usr/bin/env python3
from __future__ import annotations
import os as _bytecode_guard_os, sys as _bytecode_guard_sys
_bytecode_guard_sys.dont_write_bytecode = True
_bytecode_guard_os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import argparse
import copy
import hashlib
import importlib.util
import json
import tempfile
import sys
from pathlib import Path

from PIL import Image

HERE = Path(__file__).resolve().parent
RUNTIME_ROOT = HERE.parents[3]

# Assigned in main() from --workspace-root, so the selftest always exercises the Runtime
# the caller names instead of silently testing a second copy next to this script.
mod = None


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


BLOCKED_CASES: list[str] = []


def expect_block(plan: dict, plan_path: Path, root: Path, label: str) -> str:
    write_json(plan_path, plan)
    try:
        mod.validate_plan(plan_path, root)
    except mod.BatchError as exc:
        BLOCKED_CASES.append(label)
        return str(exc)
    raise AssertionError(f"negative fixture unexpectedly passed: {label}")


def main() -> int:
    global mod
    parser = argparse.ArgumentParser(description="KV layer plan contract selftest")
    parser.add_argument("--workspace-root", type=Path, default=RUNTIME_ROOT)
    args = parser.parse_args()
    runtime = args.workspace_root.resolve()
    lib = runtime / ".agents" / "lib"
    assert lib.is_dir(), f"runtime lib is missing under --workspace-root: {lib}"
    if str(lib) not in sys.path:
        sys.path.insert(0, str(lib))
    from decomposition_size import plan_size_contract, SKILL_IMAGE
    mod = load_module(runtime / ".agents" / "skills" / "wxian-image-layer-decomposition" / "scripts" / "layer_batch.py",
                      "kv_layer_batch")
    with tempfile.TemporaryDirectory(prefix="kv-layer-contract-") as td:
        root = Path(td)
        request = root / "requests" / "image-layer-decomposition" / "case"
        inp = request / "input"; work = request / "work"
        inp.mkdir(parents=True); work.mkdir(parents=True)
        write_json(request / "state.json", {"primary_skill": "wxian-image-layer-decomposition", "status": "active", "revision": 1})
        def write_lock(granularity, override=None):
            body = "# Requirement lock\n\n- layer_granularity: " + granularity + "\n"
            if override:
                body += "- granularity_override_evidence: " + override + "\n"
            (work / "requirement-lock.md").write_text(body, encoding="utf-8")
        write_lock("per-character")
        (request / "request.md").write_text(
            "Split every character into its own layer and keep held props with the character.\n",
            encoding="utf-8",
        )

        source = inp / "kv.png"; canonical = work / "source-work.png"
        Image.new("RGBA", (1024, 1024), (32, 48, 64, 255)).save(source)
        Image.open(source).save(canonical)
        size_contract = plan_size_contract((1024, 1024), skill=SKILL_IMAGE, model="gpt-image-2.5-sunburst")
        layer_graph = work / "layer-graph.json"
        occlusion_graph = work / "occlusion-graph.json"
        interaction_graph = work / "interaction-graph.json"
        write_json(layer_graph, {
            "schema_version": "wxian.kv-layer-graph.v1", "status": "READY",
            "source_sha256": sha(source), "work_sha256": sha(canonical), "delivery_canvas_size": [1024, 1024],
            "nodes": [
                {"node_id": "L000_BG", "kind": "environment", "depth_band": "BG_DEEP", "bbox": [0, 0, 1024, 1024]},
                {"node_id": "L300_HERO", "kind": "interaction-bound-subject", "depth_band": "SUBJECT", "bbox": [200, 100, 400, 700]},
            ],
            "edges": [{"type": "behind", "from": "L000_BG", "to": "L300_HERO"}],
        })
        write_json(occlusion_graph, {
            "schema_version": "wxian.kv-occlusion-graph.v1", "status": "READY", "source_sha256": sha(source),
            "edges": [{"from": "L300_HERO", "to": "L000_BG"}],
        })
        write_json(interaction_graph, {
            "schema_version": "wxian.kv-interaction-graph.v1", "status": "READY", "source_sha256": sha(source),
            "clusters": [{
                "cluster_id": "IC_HERO", "primary_subject": "hero_body",
                "members": ["hero_body", "sword"], "binding_reasons": ["held/direct-action-unit"]
            }],
        })
        graph_files = {
            "layer_graph": {"path": layer_graph.relative_to(root).as_posix(), "sha256": sha(layer_graph)},
            "occlusion_graph": {"path": occlusion_graph.relative_to(root).as_posix(), "sha256": sha(occlusion_graph)},
            "interaction_graph": {"path": interaction_graph.relative_to(root).as_posix(), "sha256": sha(interaction_graph)},
        }
        prompts = work / "api-prompts"; prompts.mkdir()
        (prompts / "bg_clean.txt").write_text("Remove the subject and reconstruct only the hidden environment.\n", encoding="utf-8")
        (prompts / "hero_visible.txt").write_text("Extract only the currently visible interaction-bound hero unit.\n", encoding="utf-8")
        common_params_opaque = {"size": "1024x1024", "quality": "max", "background": "opaque", "moderation": "auto", "output_format": "png"}
        common_params_alpha = {**common_params_opaque, "background": "transparent"}
        canonical_rel = canonical.relative_to(root).as_posix()
        base = {
            "schema_version": "wxian.kv-layer-plan.v6",
            "status": "READY",
            "source_image": source.relative_to(root).as_posix(),
            "source_sha256": sha(source),
            "work_source": canonical_rel,
            "work_sha256": sha(canonical),
            "source_canvas_size": [1024, 1024],
            "delivery_canvas_size": [1024, 1024],
            "work_canvas_size": [1024, 1024],
            "size_contract": size_contract,
            "default_model": "gpt-image-2.5-sunburst",
            "downstream_intent": "light-parallax",
            "decomposition_profile": "kv-depth",
            "decomposition_granularity": "per-character",
            "character_registry": [{
                "character_id": "hero_body", "layer_id": "L300_HERO", "bbox": [200, 100, 400, 700],
                "held_props": [{"prop_id": "sword", "bbox": [300, 300, 120, 200]}],
            }],
            "analysis_artifacts": graph_files,
            "relationships": [
                {"type": "occludes", "from": "L300_HERO", "to": "L000_BG"},
                {"type": "behind", "from": "L000_BG", "to": "L300_HERO"},
                {"type": "interaction_bound", "from": "hero_body", "to": "sword"},
            ],
            "layers": [
                {
                    "layer_id": "L000_BG", "name": "clean background", "layer_type": "background-clean", "depth_band": "BG_DEEP", "z_order": 0,
                    "strategy": "clean_plate_patch", "source_bbox_hint": [0, 0, 1024, 1024], "anchor_hint": [0, 0],
                    "includes": ["environment"], "excludes": ["hero"], "interaction_cluster_id": "", "interaction_members": [], "bound_assets": [],
                    "occluded_by": ["L300_HERO"], "occludes": [], "primary_pixel_owner": True, "visible_region_policy": "source_locked",
                    "reconstruction_scope": "hero reveal only", "minimum_visible_coverage_ratio": 0.01, "motion_margin_px": 16,
                    "motion_envelope_px": {"left": 32, "top": 16, "right": 32, "bottom": 16},
                    "reconstruction_confidence": "medium", "reconstruction_provenance": ["adjacent environment"],
                    "blend_mode": "normal", "blend_mode_hint": "normal",
                    "api_calls": [{"id": "clean", "mode": "image_to_image_edit", "prompt_path": (prompts / "bg_clean.txt").relative_to(root).as_posix(),
                                   "output_path": (work / "final" / "originals" / "provider" / "L000_BG__clean.png").relative_to(root).as_posix(),
                                   "base_image": canonical_rel, "parameters": common_params_opaque}],
                },
                {
                    "layer_id": "L300_HERO", "name": "hero interaction unit", "layer_type": "hero-subject", "depth_band": "SUBJECT", "z_order": 300,
                    "strategy": "source_locked_extract", "source_bbox_hint": [200, 100, 400, 700], "anchor_hint": [200, 100],
                    "includes": ["hero", "sword"], "excludes": ["environment"], "interaction_cluster_id": "IC_HERO", "interaction_members": ["hero_body", "sword"], "bound_assets": [],
                    "occluded_by": [], "occludes": ["L000_BG"], "primary_pixel_owner": True, "visible_region_policy": "source_locked",
                    "reconstruction_scope": "visible only", "minimum_visible_coverage_ratio": 0.01, "motion_margin_px": 0,
                    "motion_envelope_px": {"left": 0, "top": 0, "right": 0, "bottom": 0},
                    "reconstruction_confidence": "none", "reconstruction_provenance": [],
                    "blend_mode": "normal", "blend_mode_hint": "normal",
                    "api_calls": [{"id": "visible", "mode": "image_to_image_edit", "prompt_path": (prompts / "hero_visible.txt").relative_to(root).as_posix(),
                                   "output_path": (work / "final" / "originals" / "provider" / "L300_HERO__visible.png").relative_to(root).as_posix(),
                                   "base_image": canonical_rel, "parameters": common_params_alpha}],
                },
            ],
        }
        plan_path = work / "layer-plan.json"
        write_json(plan_path, base)
        plan, _, compiled = mod.validate_plan(plan_path, root)
        assert plan["schema_version"].endswith("v6") and len(compiled) == 2

        # The restored generic-composite profile uses the same production entry and
        # executable contract for character, environment, effect, logo and mixed art.
        generic_types = ("supporting-character", "midground-environment", "effect", "text-logo-overlay", "decoration-overlay")
        for layer_type in generic_types:
            generic = copy.deepcopy(base)
            generic["decomposition_profile"] = "generic-composite"
            generic["decomposition_granularity"] = "per-role-group"
            write_lock("per-role-group", "Split every character into its own layer")
            generic["character_registry"] = []
            generic["layers"][1]["layer_type"] = layer_type
            generic["layers"][1]["interaction_cluster_id"] = ""
            generic["layers"][1]["interaction_members"] = []
            generic["relationships"] = generic["relationships"][:2]
            write_json(plan_path, generic)
            checked, _, items = mod.validate_plan(plan_path, root)
            assert checked["decomposition_profile"] == "generic-composite" and len(items) == 2
            write_lock("per-character")

        bad = copy.deepcopy(base); bad["decomposition_profile"] = "game-ui"
        assert "decomposition_profile" in expect_block(bad, plan_path, root, "UI profile routed to generic decomposition")

        bad = copy.deepcopy(base); bad["relationships"][2]["to"] = "typo_missing_member"
        assert "unknown to endpoint" in expect_block(bad, plan_path, root, "unknown interaction endpoint")
        bad = copy.deepcopy(base); bad["layers"][1]["source_bbox_hint"] = [900, 900, 400, 400]
        assert "exceeds delivery canvas" in expect_block(bad, plan_path, root, "bbox overflow")
        bad = copy.deepcopy(base); bad["layers"][1]["api_calls"] = []
        assert "requires a visible pass" in expect_block(bad, plan_path, root, "missing visible pass")
        bad = copy.deepcopy(base); bad["layers"][1]["minimum_visible_coverage_ratio"] = 0
        assert "minimum_visible_coverage_ratio" in expect_block(bad, plan_path, root, "invalid visible coverage minimum")
        bad = copy.deepcopy(base); bad["layers"][1]["api_calls"][0]["base_image"] = source.relative_to(root).as_posix()
        assert "must bind work_source" in expect_block(bad, plan_path, root, "wrong edit base")
        # Character granularity is a machine contract: one layer per character, held props inside it.
        bad = copy.deepcopy(base); bad["character_registry"] = []
        assert "per-character granularity requires a non-empty character_registry" in expect_block(
            bad, plan_path, root, "per-character plan without a character inventory")
        write_lock("per-character")
        bad = copy.deepcopy(base); bad["decomposition_granularity"] = "per-unit"
        assert "disagrees with requirement-lock layer_granularity=per-character" in expect_block(
            bad, plan_path, root, "plan silently picks a coarser granularity than the lock")
        write_lock("per-unit", "Split every character into its own layer")
        assert "disagrees with requirement-lock layer_granularity=per-unit" in expect_block(
            base, plan_path, root, "plan disagrees with a coarser lock")
        bad = copy.deepcopy(base); bad["decomposition_granularity"] = "per-unit"
        assert "a non-empty character_registry requires decomposition_granularity=per-character" in expect_block(
            bad, plan_path, root, "character inventory declared under a coarser granularity")
        write_lock("per-character")
        bad = copy.deepcopy(base)
        bad["character_registry"].append({"character_id": "nurse", "layer_id": "L300_HERO", "bbox": [210, 110, 60, 120]})
        assert "one layer per character" in expect_block(bad, plan_path, root, "two characters collapsed into one layer")
        bad = copy.deepcopy(base); bad["character_registry"][0]["layer_id"] = "L000_BG"
        assert "needs a character layer type" in expect_block(bad, plan_path, root, "character buried in a background layer")
        bad = copy.deepcopy(base); bad["character_registry"][0]["held_props"][0]["bbox"] = [900, 900, 50, 50]
        assert "held prop sword bbox must stay inside" in expect_block(bad, plan_path, root, "held prop outside its layer")
        bad = copy.deepcopy(base); bad["analysis_artifacts"]["layer_graph"]["sha256"] = "0" * 64
        assert "sha256 is stale" in expect_block(bad, plan_path, root, "stale analysis graph")

        # Mutate a graph semantically, refresh its hash, and verify that schema/plan consistency still blocks it.
        bad_graph = json.loads(layer_graph.read_text(encoding="utf-8"))
        bad_graph["nodes"][1]["bbox"] = [210, 100, 400, 700]
        write_json(layer_graph, bad_graph)
        bad = copy.deepcopy(base); bad["analysis_artifacts"]["layer_graph"]["sha256"] = sha(layer_graph)
        assert "bbox disagrees" in expect_block(bad, plan_path, root, "graph/plan bbox disagreement")
        write_json(layer_graph, {
            "schema_version": "wxian.kv-layer-graph.v1", "status": "READY",
            "source_sha256": sha(source), "work_sha256": sha(canonical), "delivery_canvas_size": [1024, 1024],
            "nodes": [
                {"node_id": "L000_BG", "kind": "environment", "depth_band": "BG_DEEP", "bbox": [0, 0, 1024, 1024]},
                {"node_id": "L300_HERO", "kind": "interaction-bound-subject", "depth_band": "SUBJECT", "bbox": [200, 100, 400, 700]},
            ],
            "edges": [{"type": "behind", "from": "L000_BG", "to": "L300_HERO"}],
        })

        bad_interaction = json.loads(interaction_graph.read_text(encoding="utf-8"))
        bad_interaction["clusters"][0]["members"] = ["hero_body", "shield"]
        write_json(interaction_graph, bad_interaction)
        bad = copy.deepcopy(base); bad["analysis_artifacts"]["interaction_graph"]["sha256"] = sha(interaction_graph)
        assert "must exactly match interaction graph cluster" in expect_block(bad, plan_path, root, "interaction cluster disagreement")

    print(json.dumps({"status": "ready", "tool": "image-layer-contract-selftest", "positive": 6,
                      "negative": len(BLOCKED_CASES), "blocked_cases": BLOCKED_CASES,
                      "network_called": False}, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
