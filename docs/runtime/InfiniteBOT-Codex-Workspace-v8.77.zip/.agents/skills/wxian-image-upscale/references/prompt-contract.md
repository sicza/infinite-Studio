# IMAGE2.5 strict Tile Prompt contract

The machine authority is `config/prompt-contract-schema.json`; compiler and validator enforce it before an API request. A Tile declares `execution_mode`: only `MODEL_EDIT` can carry a GPT Image 2.5 model, explicit quality, and a legal Tile `size`; `DETERMINISTIC_ONLY` must carry none. `graphic_exact` is deterministic-only.

All model Tiles use the immutable `gpt25-tile-enhance-v1` template. Its first image is the editable crop; one optional second image is only a global overview. The renderer permits only the selected content profile and evidence-supported local detail, and binds the rendered Prompt hash.

`final_target` and `tile_target` are separate facts. The planner derives a legal 16-aligned model canvas for each Tile and records deterministic pad/crop coordinates. Any aspect conflict, illegal size, stale source/plan/tile hash, unknown model parameter, changed payload identity, or generic Personal Layer injection blocks execution. Protected text, logos, UI and alpha are restored from the deterministic baseline, not entrusted to model language.

No uncalibrated model result is a formal success. The initial production path is a clearly labelled `DETERMINISTIC_FALLBACK`; model enhancement remains `EXPERIMENTAL` until repeated real-provider comparison and protected-region QA establish a profile-specific calibration.
