Task:
Refine this supplied crop from a finished image for high-resolution viewing. Treat the first input image as the authoritative content and framing for this crop. This is a faithful detail-enhancement edit, not a redesign or a new scene.

Change only:
Improve the legibility of existing small-scale surface detail, edge definition and local tonal separation where supported by the source. Reduce unwanted compression artifacts or accidental noise without removing intentional texture. Keep detail natural and consistent with the original image.

Preserve:
Keep the exact crop framing, subject identity, object count, silhouettes, proportions, poses, perspective, occlusion, spatial positions, color relationships, lighting, shadows and original visual style. Preserve partially cropped objects as partial; do not complete or reframe them.

{context_section}

{content_section}

Do not:
Do not invent or remove subjects, limbs, objects, marks or ornaments. Do not rewrite text, logos, numbers or interface elements. Avoid halos, oversharpening, artificial grain, painterly smearing and hallucinated microtexture.
