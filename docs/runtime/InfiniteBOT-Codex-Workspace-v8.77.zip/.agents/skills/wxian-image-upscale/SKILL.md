---
name: wxian-image-upscale
description: 对已完成图片执行严格保真、可恢复的确定性或经验证的局部生成式超分。
---

# WXIAN Image Upscale

这是 `wxian-image-production` 的按需执行器，不是 Primary Skill，也不建立第二套 API、Governance 或 Personal Layer。

仅处理 `image-upscale → wxian-image-production → upscale`。先运行 `scripts/upscale_pipeline.py plan`：它保存 EXIF/ICC/Alpha、原文件与规范解码事实、资源预算、不可变 `plan_identity` 及独立文件摘要收据，拒绝目标宽高比冲突，生成 Lanczos baseline、无重叠 Core 与有边界 Context Tile。默认交付 `DETERMINISTIC_FALLBACK`；只有真实 IMAGE2.5 对照试验已在该 content profile 得到可追溯校准批准，才可提交 `MODEL_EDIT` Tile。

每个模型 Tile 必须先用 `prepare-tiles` 导出绑定 Source，再依次执行 `compile_upscale_prompt.py --plan --tile`、`validate_upscale_prompt.py`、现有 `image-generation-api`，并保存实际 Provider Call receipt、输入/输出 Hash、几何配准、保护区与接缝 QA。固定模板 `gpt25-tile-enhance-v1` 不得被 Agent 改写。文字、LOGO、UI 和 Alpha 区域一律由 deterministic baseline 覆盖；`graphic_exact` 不得产生 API request。所有模型 Tile 通过后由 `assemble` 生成唯一模型成品。

使用 `upscale_pipeline.py validate` 在拼接/Promote 前验证 coverage、身份、Hash、目标尺寸、保护区、QA 与校准 receipt。模型结果没有经过真实对照质量标定时，结果必须保持 `EXPERIMENTAL` 或回退为 `DETERMINISTIC_FALLBACK`，不得称为 IMAGE2.5 成功。
