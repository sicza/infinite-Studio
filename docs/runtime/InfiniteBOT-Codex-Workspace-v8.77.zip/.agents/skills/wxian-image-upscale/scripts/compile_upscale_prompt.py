#!/usr/bin/env python3
"""Render the immutable IMAGE2.5 Tile Prompt template from a validated spec."""
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent; SKILL=HERE.parent; ROOT=SKILL.parents[2]
sys.path.insert(0,str(HERE))
from validate_upscale_prompt import ContractError, validate

def sha(p:Path)->str: return hashlib.sha256(p.read_bytes()).hexdigest()
def main()->int:
 p=argparse.ArgumentParser();p.add_argument('--contract',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--plan',type=Path,required=True);p.add_argument('--tile',type=Path,required=True);p.add_argument('--workspace-root',type=Path,default=ROOT);a=p.parse_args()
 try:
  c=json.loads(a.contract.read_text(encoding='utf-8')); validate(a.contract.resolve(),root=a.workspace_root.resolve(),plan=a.plan.resolve(),tile=a.tile.resolve())
  template=(SKILL/'references/prompt-packs/gpt25-tile-enhance-v1.md').read_text(encoding='utf-8').strip()
  context=''
  if c['context_role']=='global_overview': context='Reference roles:\nImage 1 is the editable crop and the authority for all visible content and placement. Image 2 shows the original complete artwork only to maintain consistent color, lighting, material treatment and character identity. Do not recreate the full artwork inside this crop.'
  presets=json.loads((SKILL/'config/prompt-presets.json').read_text(encoding='utf-8'))
  content=''
  if c['content_profile'] in presets['profiles']: content='Content-specific:\n'+presets['profiles'][c['content_profile']]
  text=template.format(context_section=context,content_section=content).replace('\n\n\n','\n\n').strip()+'\n'
  a.output.parent.mkdir(parents=True,exist_ok=True); a.output.write_text(text,encoding='utf-8')
  c['rendered_prompt_sha256']=sha(a.output); a.contract.write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  validate(a.contract.resolve(),root=a.workspace_root.resolve(),rendered=a.output,plan=a.plan.resolve(),tile=a.tile.resolve())
  print(json.dumps({'status':'compiled','prompt_path':str(a.output),'sha256':c['rendered_prompt_sha256']},indent=2));return 0
 except (ContractError,ValueError,OSError,json.JSONDecodeError) as e: print(json.dumps({'status':'blocked','reason':str(e)}));return 1
if __name__=='__main__': raise SystemExit(main())
