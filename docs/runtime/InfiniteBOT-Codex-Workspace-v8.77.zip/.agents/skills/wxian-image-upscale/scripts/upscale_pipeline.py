#!/usr/bin/env python3
"""Replayable IMAGE2.5-assisted upscale pipeline with an honest local fallback."""
from __future__ import annotations
import argparse, hashlib, hmac, json, shutil, sys
from pathlib import Path
from typing import Any
from PIL import Image, ImageOps

ROOT=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(ROOT/'.agents/lib'))
from gpt_image_contract import GPT_IMAGE_25_SUNBURST, resolve_upscale_tile_target

PLAN_SCHEMA='wxian.upscale-plan.v2'; QUALITY_SCHEMA='wxian.upscale-quality.v2'
MAX_TARGET_PIXELS=268_435_456; MAX_SOURCE_PIXELS=134_217_728; TEMP_MULTIPLIER=16
class UpscaleError(ValueError): pass
def require(c:bool,m:str)->None:
 if not c: raise UpscaleError(m)
def sha(p:Path)->str:
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def receipt_authentication(receipt:dict[str,Any],credential:str)->str:
 payload={key:value for key,value in receipt.items() if key!='receipt_authentication'}
 return hmac.new(credential.encode('utf-8'),json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8'),hashlib.sha256).hexdigest()
def validate_receipt_authentication(receipt:dict[str,Any])->None:
 proof=receipt.get('receipt_authentication');require(isinstance(proof,dict) and proof.get('algorithm')=='hmac-sha256' and isinstance(proof.get('value'),str),'provider receipt authentication is missing')
 store=ROOT/'.agents/runtime/credentials.json';require(store.is_file(),'MODEL_ENHANCED requires the configured API credential for receipt verification')
 credentials=read_json(store,'API credential store');credential=credentials.get('generation_api_key');require(isinstance(credential,str) and credential.strip(),'MODEL_ENHANCED requires a configured API credential for receipt verification')
 require(hmac.compare_digest(proof['value'],receipt_authentication(receipt,credential)),'provider receipt authentication is invalid')
def canonical(v:Any)->bytes:return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
def write_json(p:Path,v:Any)->None:p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def read_json(p:Path,label:str)->dict[str,Any]:
 try:v=json.loads(p.read_text(encoding='utf-8'))
 except (OSError,json.JSONDecodeError) as e:raise UpscaleError(f'{label} is invalid: {e}') from e
 require(isinstance(v,dict),f'{label} must be an object');return v
def decoded_sha(im:Image.Image)->str:
 rgba=im.convert('RGBA');return hashlib.sha256(f'{rgba.width}x{rgba.height}:RGBA:'.encode('ascii')+rgba.tobytes()).hexdigest()
def source_metadata(p:Path)->dict[str,Any]:
 try:
  with Image.open(p) as raw:
   w,h=raw.size;require(w*h<=MAX_SOURCE_PIXELS,'source exceeds safe decoded-pixel limit')
   orientation=raw.getexif().get(274,1);alpha='A' in raw.getbands() or 'transparency' in raw.info;icc=raw.info.get('icc_profile')
   im=ImageOps.exif_transpose(raw);im.load();rgba=im.convert('RGBA')
 except (OSError,ValueError) as e:raise UpscaleError(f'unable to decode source image: {e}') from e
 return {'file_sha256':sha(p),'decoded_sha256':decoded_sha(rgba),'original_size':[w,h],'normalized_size':[rgba.width,rgba.height],'exif_orientation':int(orientation or 1),'has_alpha':alpha,'icc_profile_sha256':hashlib.sha256(icc).hexdigest() if isinstance(icc,bytes) else None,'mode':'RGBA'}
def load_source(p:Path)->Image.Image:
 with Image.open(p) as raw:
  require(raw.width*raw.height<=MAX_SOURCE_PIXELS,'source exceeds safe decoded-pixel limit');im=ImageOps.exif_transpose(raw);im.load();return im.convert('RGBA')
def target_for(src:tuple[int,int],w:int|None,h:int|None,scale:float|None)->tuple[int,int,str]:
 sw,sh=src
 if w is not None or h is not None:
  require(w is not None and h is not None,'explicit target requires both width and height; no auto completion');require(w>0 and h>0,'target dimensions must be positive');require(w*sh==h*sw,'TARGET_ASPECT_CONFLICT: explicit target ratio differs from source; choose matching dimensions or block');return w,h,'explicit_pixels'
 require(scale is not None and scale>0,'provide target width+height or a positive scale');w,h=round(sw*scale),round(sh*scale);require(w>0 and h>0,'scale produces invalid target');return w,h,'scale'
def resource_plan(work:Path,target:tuple[int,int],tiles:int)->dict[str,Any]:
 pixels=target[0]*target[1];rgba=pixels*4;estimate=rgba*TEMP_MULTIPLIER+tiles*2_000_000;free=shutil.disk_usage(work).free
 return {'target_pixels':pixels,'decoded_rgba_bytes':rgba,'estimated_temp_bytes':estimate,'available_temp_bytes':free,'status':'READY' if pixels<=MAX_TARGET_PIXELS and estimate<=free else 'BLOCKED'}
def tiles_for(w:int,h:int,max_core:int=1536,context:int=96)->list[dict[str,Any]]:
 out=[];idx=1
 for y in range(0,h,max_core):
  for x in range(0,w,max_core):
   x2,y2=min(w,x+max_core),min(h,y+max_core)
   out.append({'tile_id':f'tile-{idx:04d}','core_box':[x,y,x2,y2],'context_box':[max(0,x-context),max(0,y-context),min(w,x2+context),min(h,y2+context)],'content_profile':'environment','execution_mode':'DETERMINISTIC_ONLY','protection_policy':'strict'});idx+=1
 return out
def validate_coverage(tiles:list[dict[str,Any]],w:int,h:int)->None:
 """Exact coverage proof by rectangle sweeps; never allocates target-sized memory."""
 events:dict[int,list[tuple[int,int,int]]]={}
 for tile in tiles:
  box=tile.get('core_box',tile.get('target_box'));require(isinstance(box,list) and len(box)==4,'tile core_box is invalid');x1,y1,x2,y2=map(int,box);require(0<=x1<x2<=w and 0<=y1<y2<=h,'tile core box outside final target');events.setdefault(y1,[]).append((1,x1,x2));events.setdefault(y2,[]).append((-1,x1,x2))
 active:list[tuple[int,int]]=[];previous=0
 for y in sorted({0,h,*events}):
  if y>previous:
   cursor=0
   for x1,x2 in sorted(active):require(x1==cursor,'tile cores have a hole or overlap');cursor=x2
   require(cursor==w,'tile cores do not cover the final target')
  for delta,x1,x2 in events.get(y,[]):
   item=(x1,x2)
   if delta==1:require(item not in active,'duplicate tile core');active.append(item)
   else:require(item in active,'invalid tile sweep removal');active.remove(item)
  previous=y
 require(not active,'tile sweep did not close')
def plan_identity(plan:dict[str,Any])->str:
 """Hash only the immutable geometry/source plan, never post-call evidence."""
 tiles=[]
 for tile in plan.get('tiles',[]):
  require(isinstance(tile,dict),'tile plan is invalid')
  tiles.append({key:tile.get(key) for key in ('tile_id','core_box','context_box','content_profile','protection_policy','resolution')})
 immutable={key:plan.get(key) for key in ('schema_version','source','final_target','resource_plan','deterministic_baseline')}
 immutable['tiles']=tiles
 return hashlib.sha256(canonical(immutable)).hexdigest()
def save_plan(path:Path,plan:dict[str,Any])->dict[str,Any]:
 # A JSON file cannot contain a hash of its own final bytes.  Keep its exact
 # byte digest in a sibling receipt, while plan_identity covers canonical plan
 # facts inside the immutable plan itself.
 plan.pop('plan_sha256',None);plan.pop('plan_file_sha256',None);plan['plan_identity']=plan_identity(plan);write_json(path,plan)
 write_json(path.with_name('job-plan.receipt.json'),{'schema_version':'wxian.upscale-plan-receipt.v1','plan_identity':plan['plan_identity'],'plan_file_sha256':sha(path)})
 return plan
def plan(source:Path,work:Path,width:int|None,height:int|None,scale:float|None)->dict[str,Any]:
 facts=source_metadata(source);sw,sh=facts['normalized_size'];tw,th,reason=target_for((sw,sh),width,height,scale);tiles=tiles_for(tw,th);work.mkdir(parents=True,exist_ok=True);resources=resource_plan(work,(tw,th),len(tiles));require(resources['status']=='READY','RESOURCE_PRECHECK_BLOCKED: target exceeds pixel or temporary-storage budget')
 im=load_source(source);baseline=work/'deterministic-baseline.png';preview=work/'source-preview.png';im.save(preview,'PNG');im.resize((tw,th),Image.Resampling.LANCZOS).save(baseline,'PNG')
 for tile in tiles:
  x1,y1,x2,y2=tile['core_box'];tile['resolution']=resolve_upscale_tile_target(GPT_IMAGE_25_SUNBURST,final_target=(tw,th),tile_target=(x2-x1,y2-y1))
 validate_coverage(tiles,tw,th)
 value={'schema_version':PLAN_SCHEMA,'status':'READY','source':{'path':str(source.resolve()),**facts},'final_target':{'width':tw,'height':th,'source':reason},'resource_plan':resources,'deterministic_baseline':{'path':str(baseline.resolve()),'sha256':sha(baseline),'algorithm':'lanczos','status':'DETERMINISTIC_FALLBACK'},'tiles':tiles,'model_enhancement_status':'EXPERIMENTAL'};path=work/'job-plan.json';save_plan(path,value)
 write_json(work/'quality-report.json',{'schema_version':QUALITY_SCHEMA,'plan_identity':value['plan_identity'],'status':'DETERMINISTIC_FALLBACK','baseline_sha256':sha(baseline),'model_enhancement_status':'EXPERIMENTAL','reason':'no calibrated real-model comparison is bound to this job'})
 (work/'before-after.html').write_text('<!doctype html><meta charset="utf-8"><title>Upscale comparison</title><style>body{font:14px system-ui;background:#111;color:#eee;margin:24px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}img{max-width:100%;height:auto;background:#222}</style><h1>Strict-fidelity upscale comparison</h1><p>Result status: <b>DETERMINISTIC_FALLBACK</b>. No calibrated IMAGE2.5 enhancement is claimed.</p><div class="grid"><figure><img src="source-preview.png"><figcaption>Source</figcaption></figure><figure><img src="deterministic-baseline.png"><figcaption>Lanczos target baseline</figcaption></figure></div>',encoding='utf-8')
 return {'status':'planned','plan':str(path),'tile_count':len(tiles),'final_target':f'{tw}x{th}','fallback':'DETERMINISTIC_FALLBACK'}
def prepare_tiles(work:Path)->dict[str,Any]:
 value=validate_plan(work);data=value['plan'];baseline=Path(data['deterministic_baseline']['path']);folder=work/'tiles';folder.mkdir(exist_ok=True)
 with Image.open(baseline) as opened:
  base=opened.convert('RGBA')
  for tile in data['tiles']:
   x1,y1,x2,y2=tile['context_box'];p=folder/f"{tile['tile_id']}.png";base.crop((x1,y1,x2,y2)).save(p,'PNG');tile['prepared_source']={'path':str(p.resolve()),'sha256':sha(p),'box':tile['context_box']}
 save_plan(work/'job-plan.json',data);return {'status':'prepared','tile_count':len(data['tiles']),'plan_identity':data['plan_identity']}
def assemble(work:Path)->dict[str,Any]:
 value=validate_plan(work);data=value['plan'];require(value['model_enhancement_status']=='CALIBRATED','assemble requires calibrated MODEL_EDIT evidence')
 baseline=Path(data['deterministic_baseline']['path']);out=work/'model-enhanced.png';require(not out.exists(),'model-enhanced output already exists')
 with Image.open(baseline) as opened:
  canvas=opened.convert('RGBA')
  for tile in data['tiles']:
   if tile.get('execution_mode')!='MODEL_EDIT':continue
   result=Path(tile['result']['path']);x1,y1,x2,y2=tile['core_box']
   with Image.open(result) as output:canvas.alpha_composite(output.convert('RGBA'),(x1,y1))
  canvas.save(out,'PNG')
 fw,fh=int(data['final_target']['width']),int(data['final_target']['height'])
 with Image.open(out) as check:require(check.size==(fw,fh),'assembled output geometry mismatch')
 write_json(work/'quality-report.json',{'schema_version':QUALITY_SCHEMA,'plan_identity':data['plan_identity'],'status':'MODEL_ENHANCED','model_enhancement_status':'CALIBRATED','baseline_sha256':data['deterministic_baseline']['sha256'],'final_path':str(out.resolve()),'final_sha256':sha(out),'tile_count':len(data['tiles']),'calibration_path':str((work/'calibration-evidence.json').resolve()),'reason':'provider receipts, per-tile QA, calibration, and assembly are bound'})
 return {'status':'assembled','output':str(out),'sha256':sha(out),'plan_identity':data['plan_identity']}
def validate_model_tile(work:Path,data:dict[str,Any],tile:dict[str,Any])->None:
 required={'prepared_source','prompt_contract','provider_call','result','qa'};require(required<=set(tile),f"MODEL_EDIT tile {tile.get('tile_id')} lacks provider evidence")
 prepared=Path(tile['prepared_source']['path']);require(prepared.is_file() and sha(prepared)==tile['prepared_source']['sha256'],'prepared tile source hash mismatch')
 contract_path=Path(tile['prompt_contract']['path']);require(contract_path.is_file() and sha(contract_path)==tile['prompt_contract']['sha256'],'tile prompt contract hash mismatch');contract=read_json(contract_path,'tile prompt contract');require(contract.get('execution_mode')=='MODEL_EDIT' and contract.get('tile_id')==tile['tile_id'],'tile prompt contract does not bind MODEL_EDIT tile');require(contract.get('plan_identity')==data['plan_identity'],'tile prompt contract plan identity mismatch');require(contract.get('tile_source_sha256')==sha(prepared),'tile prompt contract source mismatch')
 receipt_path=Path(tile['provider_call']['path']);require(receipt_path.is_file() and sha(receipt_path)==tile['provider_call']['sha256'],'provider call receipt hash mismatch');receipt=read_json(receipt_path,'provider call receipt');validate_receipt_authentication(receipt);binding=receipt.get('upscale_binding',{});require(receipt.get('status')=='success' and receipt.get('network_called') is True,'provider call is not a real successful network receipt');require(isinstance(receipt.get('http_status'),int) and 200<=receipt['http_status']<300 and isinstance(receipt.get('response_sha256'),str) and len(receipt['response_sha256'])==64,'provider response evidence is incomplete');require(binding.get('plan_identity')==data['plan_identity'] and binding.get('tile_id')==tile['tile_id'],'provider call does not bind this tile');require(receipt.get('prompt_source',{}).get('sha256')==contract.get('rendered_prompt_sha256'),'provider call prompt binding mismatch')
 result=Path(tile['result']['path']);require(result.is_file() and sha(result)==tile['result']['sha256'],'tile model output hash mismatch');require(receipt.get('output_sha256')==sha(result),'provider receipt output hash mismatch');executor=receipt.get('executor_binding',{});require(isinstance(executor,dict) and executor.get('path')=='.agents/skills/image-generation-api/scripts/generation_api.py','provider executor binding is invalid');executor_path=ROOT/executor['path'];require(executor_path.is_file() and executor.get('sha256')==sha(executor_path),'provider executor binding is stale')
 with Image.open(result) as im:require(im.size==tuple(tile['resolution']['tile_target'].values()),'tile model output geometry mismatch')
 qa=tile['qa'];require(qa.get('source_sha256')==sha(prepared) and qa.get('result_sha256')==sha(result),'tile QA hashes mismatch');require(qa.get('alignment',{}).get('status')=='passed','tile geometric alignment failed');require(qa.get('protected_regions',{}).get('status')=='passed','tile protected-region QA failed');require(qa.get('seam',{}).get('status')=='passed','tile seam QA failed')
def validate_calibration(work:Path,data:dict[str,Any])->dict[str,Any]:
 p=work/'calibration-evidence.json';require(p.is_file(),'MODEL_EDIT requires calibration-evidence.json');e=read_json(p,'calibration evidence');require(e.get('schema_version')=='wxian.upscale-calibration.v1' and e.get('status')=='APPROVED','calibration is not approved');require(e.get('content_profile') in {t['content_profile'] for t in data['tiles'] if t.get('execution_mode')=='MODEL_EDIT'},'calibration content profile is unrelated');receipt=Path(str(e.get('provider_call_path','')));require(receipt.is_file() and sha(receipt)==e.get('provider_call_sha256'),'calibration provider receipt stale');call=read_json(receipt,'calibration provider receipt');validate_receipt_authentication(call);require(call.get('status')=='success' and call.get('network_called') is True and isinstance(call.get('service_request_id'),str) and bool(call['service_request_id'].strip()),'calibration lacks real provider-issued request evidence');require(isinstance(call.get('response_sha256'),str) and len(call['response_sha256'])==64 and isinstance(call.get('output_sha256'),str) and len(call['output_sha256'])==64,'calibration provider evidence is incomplete');require(isinstance(e.get('accepted_by'),str) and e['accepted_by'].strip(),'calibration lacks accountable acceptance');return e
def validate_plan(work:Path)->dict[str,Any]:
 p=work/'job-plan.json';require(p.is_file(),'job-plan.json missing');data=read_json(p,'job plan');require(data.get('schema_version')==PLAN_SCHEMA,'invalid job plan schema');require(data.get('plan_identity')==plan_identity(data),'job plan identity is stale');receipt=read_json(work/'job-plan.receipt.json','job plan receipt');require(receipt.get('schema_version')=='wxian.upscale-plan-receipt.v1' and receipt.get('plan_identity')==data['plan_identity'] and receipt.get('plan_file_sha256')==sha(p),'job plan file digest is stale')
 source=Path(data['source']['path']);require(source.is_file() and sha(source)==data['source']['file_sha256'],'source changed after planning');require(source_metadata(source)['decoded_sha256']==data['source']['decoded_sha256'],'decoded source facts changed after planning');fw,fh=int(data['final_target']['width']),int(data['final_target']['height']);require(data.get('resource_plan',{}).get('status')=='READY' and fw*fh<=MAX_TARGET_PIXELS,'resource plan is not safe')
 baseline=Path(data['deterministic_baseline']['path']);require(baseline.is_file() and sha(baseline)==data['deterministic_baseline']['sha256'],'baseline hash stale')
 with Image.open(baseline) as im:require(im.size==(fw,fh),'baseline dimensions do not equal final target')
 tiles=data.get('tiles');require(isinstance(tiles,list) and tiles,'tile plan missing');validate_coverage(tiles,fw,fh);has_model=False
 for tile in tiles:
  mode=tile.get('execution_mode');require(mode in {'MODEL_EDIT','DETERMINISTIC_ONLY'},'tile execution_mode missing')
  if mode=='MODEL_EDIT':has_model=True;validate_model_tile(work,data,tile)
 calibration=validate_calibration(work,data) if has_model else None
 return {'status':'passed','plan':data,'tile_count':len(tiles),'final_target':f'{fw}x{fh}','model_enhancement_status':'CALIBRATED' if calibration else 'EXPERIMENTAL'}
def validate(work:Path)->dict[str,Any]:
 value=validate_plan(work);value.pop('plan',None);return value
def main()->int:
 ap=argparse.ArgumentParser();sub=ap.add_subparsers(dest='command',required=True);p=sub.add_parser('plan');p.add_argument('--source',required=True,type=Path);p.add_argument('--work',required=True,type=Path);p.add_argument('--width',type=int);p.add_argument('--height',type=int);p.add_argument('--scale',type=float);p=sub.add_parser('prepare-tiles');p.add_argument('--work',required=True,type=Path);p=sub.add_parser('assemble');p.add_argument('--work',required=True,type=Path);p=sub.add_parser('validate');p.add_argument('--work',required=True,type=Path);a=ap.parse_args()
 try:
  out=plan(a.source,a.work,a.width,a.height,a.scale) if a.command=='plan' else prepare_tiles(a.work) if a.command=='prepare-tiles' else assemble(a.work) if a.command=='assemble' else validate(a.work);print(json.dumps(out,ensure_ascii=False,indent=2));return 0
 except (UpscaleError,OSError,ValueError,json.JSONDecodeError) as e:print(json.dumps({'status':'blocked','reason':str(e)},ensure_ascii=False));return 1
if __name__=='__main__':raise SystemExit(main())
