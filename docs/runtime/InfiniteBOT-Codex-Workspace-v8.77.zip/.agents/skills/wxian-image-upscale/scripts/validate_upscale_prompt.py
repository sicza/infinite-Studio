#!/usr/bin/env python3
"""Validate an IMAGE2.5 Tile Prompt Contract against current file facts."""
from __future__ import annotations
import argparse, hashlib, json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
if str(ROOT / ".agents/lib") not in sys.path: sys.path.insert(0, str(ROOT / ".agents/lib"))
from gpt_image_contract import GPT_IMAGE_25_MODELS, validate_gpt_quality, validate_gpt_size

HASH = re.compile(r"^[a-f0-9]{64}$")
REQUIRED_PRESERVE = {"identity","composition","geometry","text","logos","ui","palette","lighting"}
ALLOWED_CHANGES = {"source_supported_microtexture","local_edge_definition","artifact_reduction"}
PROFILES = {"character_detail","hard_surface","environment","graphic_exact","transparent_asset"}

class ContractError(ValueError): pass
def sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()
def require(c: bool, m: str) -> None:
    if not c: raise ContractError(m)
def load(path: Path) -> dict:
    obj=json.loads(path.read_text(encoding="utf-8")); require(isinstance(obj,dict),"contract must be object"); return obj
def bounded(root: Path, value: str) -> Path:
    p=(root/value).resolve(); require(p==root or root in p.parents,"path escapes workspace"); return p

def validate(contract_path: Path, *, root: Path, rendered: Path|None=None, plan: Path|None=None, tile: Path|None=None) -> dict:
    c=load(contract_path)
    required={"schema_version","template_id","source_sha256","job_plan_sha256","plan_identity","tile_id","tile_source_sha256","content_profile","protection_policy","execution_mode","source_role","context_role","allowed_changes","preserve","evidence_supported_details","model","quality","size"}
    require(set(c).issuperset(required) and set(c).issubset(required|{"context_sha256","rendered_prompt_sha256","final_target","tile_target","resolution"}),"unexpected or missing prompt contract fields")
    require(c["schema_version"]=="wxian.upscale-prompt.v1" and c["template_id"]=="gpt25-tile-enhance-v1","unsupported prompt template")
    require(all(isinstance(c[k],str) and HASH.fullmatch(c[k]) for k in ("source_sha256","job_plan_sha256","plan_identity","tile_source_sha256")),"contract hashes invalid")
    require(isinstance(c["tile_id"],str) and re.fullmatch(r"tile-[0-9]{4,6}",c["tile_id"]),"tile_id invalid")
    require(c["content_profile"] in PROFILES and c["protection_policy"]=="strict","profile/protection invalid")
    require(c["execution_mode"] in {"MODEL_EDIT","DETERMINISTIC_ONLY"},"execution_mode is required and invalid")
    require(c["source_role"]=="editable_crop" and c["context_role"] in {"none","global_overview"},"source/context role invalid")
    require((c["context_role"]=="global_overview") == ("context_sha256" in c),"context hash role mismatch")
    require(isinstance(c["allowed_changes"],list) and len(c["allowed_changes"])<=3 and set(c["allowed_changes"])<=ALLOWED_CHANGES,"allowed_changes invalid")
    require(isinstance(c["preserve"],list) and REQUIRED_PRESERVE <= set(c["preserve"]),"strict hard preserve locks missing")
    require(isinstance(c["evidence_supported_details"],list) and len(c["evidence_supported_details"])<=3 and all(isinstance(x,str) and 3<=len(x)<=120 for x in c["evidence_supported_details"]),"evidence detail invalid")
    model,quality,size=c["model"],c["quality"],c["size"]
    if c["execution_mode"]=="MODEL_EDIT":
        require(all(isinstance(x,str) for x in (model,quality,size)),"MODEL_EDIT requires model, quality and size")
        require(model in GPT_IMAGE_25_MODELS,"MODEL_EDIT requires a GPT Image 2.5 model")
        validate_gpt_size(model,size); validate_gpt_quality(model,quality)
        require(c["content_profile"]!="graphic_exact","graphic_exact cannot obtain model write authority")
        require("final_target" in c and "tile_target" in c and "resolution" in c,"MODEL_EDIT requires isolated final/tile resolution evidence")
    else:
        require(model is None and quality is None and size is None and not c["allowed_changes"],"DETERMINISTIC_ONLY must not contain model parameters or changes")
    if plan:
        require(sha(plan)==c["job_plan_sha256"],"job plan hash is stale")
        plan_value=load(plan);require(plan_value.get("plan_identity")==c["plan_identity"],"job plan identity is stale")
    if tile:
        require(sha(tile)==c["tile_source_sha256"],"tile source hash is stale")
    if rendered:
        require(rendered.is_file(),"rendered prompt missing")
        digest=sha(rendered); require(c.get("rendered_prompt_sha256")==digest,"rendered prompt hash missing or stale")
        text=rendered.read_text(encoding="utf-8")
        require(all(x not in text for x in ("/", "\\\\", c["tile_id"], c["source_sha256"], "8K", "API")),"prompt leaks internal metadata")
    return {"status":"passed","tile_id":c["tile_id"],"execution_mode":c["execution_mode"],"model":model,"size":size}

def main() -> int:
    p=argparse.ArgumentParser(); p.add_argument("--contract",required=True,type=Path);p.add_argument("--workspace-root",type=Path,default=ROOT);p.add_argument("--rendered",type=Path);p.add_argument("--plan",type=Path);p.add_argument("--tile",type=Path);a=p.parse_args()
    try: print(json.dumps(validate(a.contract.resolve(),root=a.workspace_root.resolve(),rendered=a.rendered,plan=a.plan,tile=a.tile),indent=2));return 0
    except (ContractError,ValueError,OSError,json.JSONDecodeError) as e: print(json.dumps({"status":"blocked","reason":str(e)}));return 1
if __name__=="__main__": raise SystemExit(main())
