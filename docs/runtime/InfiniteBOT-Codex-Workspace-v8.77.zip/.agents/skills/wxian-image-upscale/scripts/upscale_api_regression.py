#!/usr/bin/env python3
"""Offline API binding regression: Tile prompt, source, size and final payload identity."""
from __future__ import annotations
import hashlib,importlib.util,json,tempfile,sys
from pathlib import Path
from PIL import Image
HERE=Path(__file__).resolve().parent;RUNTIME=HERE.parents[3];sys.path.insert(0,str(RUNTIME/'.agents/lib'))
from gpt_image_contract import GPT_IMAGE_2,GPT_IMAGE_25_SUNBURST,resolve_upscale_tile_target
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load_api():
 p=RUNTIME/'.agents/skills/image-generation-api/scripts/generation_api.py';s=importlib.util.spec_from_file_location('upscale_api',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def run():
 api=load_api()
 with tempfile.TemporaryDirectory() as d:
  root=Path(d);req=root/'requests/image-upscale/case';work=req/'work';(work/'api-requests').mkdir(parents=True);(req/'input').mkdir();Image.new('RGBA',(64,64),(1,2,3,255)).save(req/'input/source.png');Image.new('RGBA',(512,512),(1,2,3,255)).save(work/'tile.png')
  req.joinpath('state.json').write_text(json.dumps({'primary_skill':'wxian-image-production','revision':1}),encoding='utf-8');req.joinpath('request.md').write_text('严格保真放大这张图到 2048x2048',encoding='utf-8')
  work.joinpath('requirement-lock.md').write_text('production_branch: upscale\n',encoding='utf-8');work.joinpath('source-lock.json').write_text(json.dumps({'required_sources':['requests/image-upscale/case/input/source.png']}),encoding='utf-8')
  prompt=work/'tile-0001.txt';prompt.write_text((HERE.parent/'references/prompt-packs/gpt25-tile-enhance-v1.md').read_text(encoding='utf-8').format(context_section='',content_section=''),encoding='utf-8')
  resolution=resolve_upscale_tile_target(GPT_IMAGE_25_SUNBURST,final_target=(2048,2048),tile_target=(512,512));contract=work/'tile-0001.prompt.json';plan=work/'job-plan.json';plan_value={'schema_version':'wxian.upscale-plan.v2','source':{'sha256':sha(req/'input/source.png')},'tiles':[{'tile_id':'tile-0001'}]};plan_identity=hashlib.sha256(json.dumps(plan_value,sort_keys=True,separators=(',',':')).encode()).hexdigest();plan_value['plan_identity']=plan_identity;plan.write_text(json.dumps(plan_value),encoding='utf-8')
  c={'schema_version':'wxian.upscale-prompt.v1','template_id':'gpt25-tile-enhance-v1','source_sha256':sha(req/'input/source.png'),'job_plan_sha256':sha(plan),'plan_identity':plan_identity,'tile_id':'tile-0001','tile_source_sha256':sha(work/'tile.png'),'content_profile':'environment','protection_policy':'strict','execution_mode':'MODEL_EDIT','source_role':'editable_crop','context_role':'none','allowed_changes':['artifact_reduction'],'preserve':['identity','composition','geometry','text','logos','ui','palette','lighting'],'evidence_supported_details':[],'model':GPT_IMAGE_25_SUNBURST,'quality':'high','size':resolution['model_size'],'rendered_prompt_sha256':sha(prompt),'final_target':resolution['final_target'],'tile_target':resolution['tile_target'],'resolution':resolution};contract.write_text(json.dumps(c),encoding='utf-8')
  binding={'prompt_contract_path':contract.relative_to(root).as_posix(),'prompt_contract_sha256':sha(contract),'plan_identity':plan_identity,'tile_id':'tile-0001','final_target':resolution['final_target'],'tile_target':resolution['tile_target'],'resolution':resolution}
  request={'api_profile':'gpt','mode':'image_to_image_edit','model':GPT_IMAGE_25_SUNBURST,'prompt_path':prompt.relative_to(root).as_posix(),'output_path':'requests/image-upscale/case/work/tile-result.png','parameters':{'size':resolution['model_size'],'quality':'high','background':'opaque','moderation':'auto','output_format':'png'},'base_image':'requests/image-upscale/case/work/tile.png','reference_images':[],'upscale_binding':binding}
  out=api.validate_request(request,root,work,{'name':'gpt','default_model':GPT_IMAGE_25_SUNBURST});assert out['upscale_binding']['final_request_identity_sha256'];assert out['parameters']['size']==resolution['model_size']
  request['parameters']['size']='1024x1024'
  try:api.validate_request(request,root,work,{'name':'gpt','default_model':GPT_IMAGE_25_SUNBURST})
  except api.ApiError:pass
  else:raise AssertionError('tile size bypass was accepted')
  request['parameters']['size']=resolution['model_size'];c['model']=GPT_IMAGE_2;contract.write_text(json.dumps(c),encoding='utf-8');binding['prompt_contract_sha256']=sha(contract);request['model']=GPT_IMAGE_2
  try:api.validate_request(request,root,work,{'name':'gpt','default_model':GPT_IMAGE_25_SUNBURST})
  except api.ApiError:pass
  else:raise AssertionError('non-IMAGE2.5 upscale model was accepted')
 return {'status':'passed','checks':['upscale-branch-api-allowlist','fixed-prompt-hash','tile-source-hash','final-tile-resolution-binding','final-payload-identity','size-bypass-blocked','non-image25-model-blocked']}
if __name__=='__main__':print(json.dumps(run(),indent=2))
