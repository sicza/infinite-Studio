#!/usr/bin/env python3
"""Counterexamples for the single IMAGE2.5 Tile Prompt contract."""
from __future__ import annotations
import hashlib,json,subprocess,tempfile,sys,os
from pathlib import Path
from PIL import Image
sys.dont_write_bytecode=True;os.environ.setdefault('PYTHONDONTWRITEBYTECODE','1')
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE));import upscale_pipeline
from validate_upscale_prompt import ContractError,validate
ROOT=HERE.parents[4]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def blocked(fn,label):
 try:fn()
 except (ContractError,ValueError):return label
 raise AssertionError(f'{label} unexpectedly passed')
def run():
 with tempfile.TemporaryDirectory() as d:
  d=Path(d);source=d/'source.png';Image.new('RGBA',(64,64),(1,2,3,255)).save(source);work=d/'work';upscale_pipeline.plan(source,work,128,128,None);upscale_pipeline.prepare_tiles(work);plan=work/'job-plan.json';pv=json.loads(plan.read_text(encoding='utf-8'));tile=pv['tiles'][0];source_tile=Path(tile['prepared_source']['path']);contract=d/'tile-0001.prompt.json'
  c={'schema_version':'wxian.upscale-prompt.v1','template_id':'gpt25-tile-enhance-v1','source_sha256':sha(source),'job_plan_sha256':sha(plan),'plan_identity':pv['plan_identity'],'tile_id':tile['tile_id'],'tile_source_sha256':sha(source_tile),'content_profile':'environment','protection_policy':'strict','execution_mode':'MODEL_EDIT','source_role':'editable_crop','context_role':'none','allowed_changes':['artifact_reduction'],'preserve':['identity','composition','geometry','text','logos','ui','palette','lighting'],'evidence_supported_details':[],'model':'gpt-image-2.5-sunburst','quality':'high','size':tile['resolution']['model_size'],'final_target':tile['resolution']['final_target'],'tile_target':tile['resolution']['tile_target'],'resolution':tile['resolution']}
  contract.write_text(json.dumps(c),encoding='utf-8');out=d/'tile-0001.txt';cp=subprocess.run([sys.executable,'-B',str(HERE/'compile_upscale_prompt.py'),'--contract',str(contract),'--output',str(out),'--plan',str(plan),'--tile',str(source_tile),'--workspace-root',str(ROOT)],capture_output=True,text=True,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'});assert cp.returncode==0,cp.stdout+cp.stderr
  validate(contract,root=ROOT,rendered=out,plan=plan,tile=source_tile)
  c=json.loads(contract.read_text(encoding='utf-8'));c['size']='1000x1000';contract.write_text(json.dumps(c),encoding='utf-8');blocked(lambda:validate(contract,root=ROOT),'illegal-model-size-blocked')
  c['size']=tile['resolution']['model_size'];c['plan_identity']='0'*64;contract.write_text(json.dumps(c),encoding='utf-8');blocked(lambda:validate(contract,root=ROOT,plan=plan),'plan-identity-tamper-blocked')
  c['plan_identity']=pv['plan_identity'];c['model']=None;c['quality']=None;c['size']=None;c['execution_mode']='DETERMINISTIC_ONLY';c['allowed_changes']=[];c['content_profile']='graphic_exact';contract.write_text(json.dumps(c),encoding='utf-8');validate(contract,root=ROOT,plan=plan,tile=source_tile)
 return {'status':'passed','checks':['schema-python-contract-parity','real-plan-tile-hash-chain','illegal-model-size-blocked','plan-identity-tamper-blocked','fixed-template-render','graphic-exact-deterministic-only']}
if __name__=='__main__':print(json.dumps(run(),indent=2))
