#!/usr/bin/env python3
"""Exercise formal deterministic-upscale Delivery Gate without a provider call."""
from __future__ import annotations
import hashlib,importlib.util,json,tempfile,sys
from pathlib import Path
from PIL import Image
HERE=Path(__file__).resolve().parent;RUNTIME=HERE.parents[3]
sys.path.insert(0,str(RUNTIME/'.agents/skills/wxian-image-production/scripts'));sys.path.insert(0,str(RUNTIME/'.agents/lib'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def module(path,name):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def run():
 pipe=module(HERE/'upscale_pipeline.py','pipe');gate=module(RUNTIME/'.agents/skills/wxian-image-production/scripts/delivery_gate.py','gate')
 with tempfile.TemporaryDirectory() as d:
  root=Path(d);req=root/'requests/image-upscale/case';inp=req/'input';inp.mkdir(parents=True);src=inp/'source.png';Image.new('RGBA',(32,20),(2,4,6,128)).save(src);work=req/'work/upscale';pipe.plan(src,work,160,100,None)
  req.joinpath('work/requirement-lock.md').write_text('production_branch: upscale\n',encoding='utf-8');req.joinpath('work/source-lock.json').write_text(json.dumps({'required_sources':['requests/image-upscale/case/input/source.png']}),encoding='utf-8')
  base=work/'deterministic-baseline.png';html=work/'before-after.html';req.joinpath('work/delivery-manifest.json').write_text(json.dumps({'files':[{'role':'upscaled_image','source':base.relative_to(root).as_posix(),'sha256':sha(base),'active':True,'size':'160x100'},{'role':'upscale_comparison_html','source':html.relative_to(root).as_posix(),'sha256':sha(html),'active':True}]}),encoding='utf-8')
  out=gate.validate(root,req);assert out['provenance']=='deterministic_fallback'
 return {'status':'passed','checks':['upscale-delivery-role-contract','plan-coverage-replay','explicit-target-dimension','deterministic-provenance','comparison-html']}
if __name__=='__main__':print(json.dumps(run(),indent=2))
