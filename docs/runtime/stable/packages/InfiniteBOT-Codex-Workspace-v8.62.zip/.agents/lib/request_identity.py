#!/usr/bin/env python3
"""Deterministic request identity and revision fingerprint for request-local contracts."""
from __future__ import annotations
import hashlib, json
from pathlib import Path
from typing import Any

class RequestIdentityError(ValueError): pass

def require(c: bool, m: str) -> None:
    if not c: raise RequestIdentityError(m)

def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()

def rel(root: Path, path: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()

def load_state(request: Path) -> dict[str, Any]:
    p=request/'state.json'; require(p.is_file(), 'request state.json is missing')
    try: value=json.loads(p.read_text(encoding='utf-8'))
    except json.JSONDecodeError as e: raise RequestIdentityError(f'invalid state.json: {e}') from e
    require(isinstance(value,dict), 'state.json root must be object')
    require(isinstance(value.get('revision'),int) and value['revision']>=1, 'state revision must be >= 1')
    require(isinstance(value.get('primary_skill'),str) and value['primary_skill'], 'state primary_skill is missing')
    return value

def request_id(root: Path, request: Path) -> str:
    ref=rel(root,request)
    return hashlib.sha256(('sicza.request-id.v1\n'+ref).encode('utf-8')).hexdigest()

def request_fingerprint(root: Path, request: Path) -> str:
    state=load_state(request)
    request_md=request/'request.md'; require(request_md.is_file(), 'request.md is missing')
    input_dir=request/'input'
    inputs=[]
    if input_dir.is_dir():
        for p in sorted((x for x in input_dir.rglob('*') if x.is_file()), key=lambda x: rel(root,x).casefold()):
            inputs.append({'path':rel(root,p),'sha256':sha256_file(p)})
    optional={}
    for key,name in (('requirement_lock','requirement-lock.md'),('source_lock','source-lock.json')):
        p=request/'work'/name
        optional[key]={'path':rel(root,p),'sha256':sha256_file(p)} if p.is_file() else None
    payload={
        'schema_version':'sicza.request-fingerprint.v1',
        'request_ref':rel(root,request),
        'request_id':request_id(root,request),
        'request_revision':state['revision'],
        'primary_skill':state['primary_skill'],
        'request_md_sha256':sha256_file(request_md),
        'input':inputs,
        **optional,
    }
    raw=json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':'))
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()

def identity(root: Path, request: Path) -> dict[str, Any]:
    state=load_state(request)
    return {
        'request_ref':rel(root,request),
        'request_id':request_id(root,request),
        'request_revision':state['revision'],
        'request_fingerprint':request_fingerprint(root,request),
    }
