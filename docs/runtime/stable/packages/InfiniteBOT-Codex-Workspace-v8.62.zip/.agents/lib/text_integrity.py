#!/usr/bin/env python3
"""Strict UTF-8 text integrity checks for Workspace-generated artifacts.

This module never guesses or auto-repairs semantic content. It detects invalid UTF-8,
BOM/control-byte contamination and common UTF-8<->GBK mojibake signatures, then blocks
publication/promotion so the producer must rewrite from the original source.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Iterable

TEXT_SUFFIXES = {".md", ".json", ".txt", ".yaml", ".yml", ".py", ".toml", ".csv"}

# Multi-character signatures intentionally chosen to be rare in normal Simplified Chinese,
# but frequent after UTF-8 bytes are decoded/rewritten through GBK/CP936.
MOJIBAKE_SIGNATURES = (
    "瑙掕", "鍙", "鐨勫", "缁勭", "浠ュ", "鏄庣", "鍦ㄧ", "涓嶅",
    "闇€", "鍔ㄤ", "瀹夊", "妯″", "鎴栬", "璇ユ", "鍏抽", "鐜",
    "璧勪", "杈撳", "瑙嗚", "鍖哄", "銆佹", "锛屽", "锛屾", "鈥",
    "锟斤拷",
)

PRIVATE_USE_RE = re.compile(r"[\ue000-\uf8ff]")
REPEATED_QUESTION_RE = re.compile(r"\?{3,}")
CJK_QUESTION_RE = re.compile(r"[\u4e00-\u9fff]\?[\u4e00-\u9fff]")


class TextIntegrityError(ValueError):
    pass


def inspect_text(text: str) -> list[str]:
    findings: list[str] = []
    if text.startswith("\ufeff"):
        findings.append("UTF-8 BOM is not allowed in generated Workspace text")
    if "\x00" in text:
        findings.append("NUL byte found in text")
    if "\ufffd" in text:
        findings.append("Unicode replacement character U+FFFD found")
    if PRIVATE_USE_RE.search(text):
        findings.append("private-use Unicode codepoint found; likely decoding corruption")
    if REPEATED_QUESTION_RE.search(text):
        findings.append("repeated question marks found; likely lossy encoding replacement")

    hits = [sig for sig in MOJIBAKE_SIGNATURES if sig in text]
    # One very strong marker or multiple independent signatures is enough to block.
    if "锟斤拷" in hits or len(hits) >= 2:
        findings.append("probable UTF-8/GBK mojibake signatures: " + ", ".join(hits[:8]))
    elif hits and CJK_QUESTION_RE.search(text):
        findings.append("probable mojibake mixed with lossy '?' replacement: " + hits[0])
    return findings


def read_utf8(path: Path) -> str:
    raw = path.read_bytes()
    try:
        text = raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise TextIntegrityError(f"not valid UTF-8: {path}: {exc}") from exc
    findings = inspect_text(text)
    if findings:
        raise TextIntegrityError(f"text integrity failed: {path}: {'; '.join(findings)}")
    return text


def validate_file(path: Path) -> None:
    if not path.is_file() or path.suffix.casefold() not in TEXT_SUFFIXES:
        return
    read_utf8(path)


def validate_tree(root: Path, *, suffixes: Iterable[str] | None = None) -> dict[str, int]:
    allowed = {s.casefold() for s in suffixes} if suffixes is not None else TEXT_SUFFIXES
    checked = 0
    for path in sorted(root.rglob("*"), key=lambda p: p.as_posix().casefold()):
        if path.is_file() and path.suffix.casefold() in allowed:
            read_utf8(path)
            checked += 1
    return {"checked_text_files": checked}
