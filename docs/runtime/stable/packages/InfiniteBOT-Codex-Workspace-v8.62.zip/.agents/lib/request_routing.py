#!/usr/bin/env python3
"""Canonical request routing registry for the Codex Workspace.

request_type is the routing fact. Asset/carrier labels such as KV, ICON, LOGO,
Banner or Store never override the primary Skill. Image-production request types
also own exactly one production_branch.
"""
from __future__ import annotations

REQUEST_ROUTES = {
    "baseline": {"primary_skill": "wxian-visual-baselines"},
    "visual-packaging": {"primary_skill": "wxian-visual-packaging"},
    "visual-competitive-analysis": {"primary_skill": "wxian-visual-competitive-analysis"},
    "game-concept-lab": {"primary_skill": "sicza-game-concept-lab"},
    "image-generation": {"primary_skill": "wxian-image-production", "production_branch": "new-generation"},
    "image-edit": {"primary_skill": "wxian-image-production", "production_branch": "image-edit"},
    "video-production": {"primary_skill": "wxian-image-production", "production_branch": "video"},
    "resize": {"primary_skill": "wxian-image-production", "production_branch": "resize"},
    "localization": {"primary_skill": "wxian-image-production", "production_branch": "localization"},
    "composite": {"primary_skill": "wxian-image-production", "production_branch": "composite"},
    "postprocess": {"primary_skill": "wxian-image-production", "production_branch": "postprocess-chain"},
    "visual-brief": {"primary_skill": "wxian-image-production", "production_branch": "visual-brief-only"},
    "prompt-writing": {"primary_skill": "wxian-image-production", "production_branch": "prompt-only"},
    "prompt-review": {"primary_skill": "wxian-image-production", "production_branch": "prompt-review-only"},
    "image-layer-decomposition": {"primary_skill": "wxian-image-layer-decomposition"},
    "game-ui-layer-decomposition": {"primary_skill": "wxian-game-ui-layer-decomposition"},
    "visual-reverse-analysis": {"primary_skill": "wxian-visual-reverse-analysis"},
    "video-source-analysis": {"primary_skill": "wxian-video-source-analysis"},
    "visual-scorecard": {"primary_skill": "wxian-visual-scorecard"},
    "kv-micro-animation": {"primary_skill": "wxian-kv-micro-animation"},
    "internet-research": {"primary_skill": "wxian-conducting-internet-research"},
}

PRIMARY_SKILLS = frozenset(route["primary_skill"] for route in REQUEST_ROUTES.values())
IMAGE_PRODUCTION_REQUEST_TYPES = frozenset(
    request_type for request_type, route in REQUEST_ROUTES.items()
    if route["primary_skill"] == "wxian-image-production"
)


class RoutingError(ValueError):
    pass


def route_for(request_type: str) -> dict[str, str]:
    key = request_type.strip()
    if key not in REQUEST_ROUTES:
        raise RoutingError(f"unsupported request_type: {key}")
    return dict(REQUEST_ROUTES[key])


def validate_primary(request_type: str, primary_skill: str) -> dict[str, str]:
    route = route_for(request_type)
    if primary_skill != route["primary_skill"]:
        raise RoutingError(
            f"request_type={request_type} requires primary_skill={route['primary_skill']}, got {primary_skill}"
        )
    return route


def expected_production_branch(request_type: str) -> str | None:
    return route_for(request_type).get("production_branch")
