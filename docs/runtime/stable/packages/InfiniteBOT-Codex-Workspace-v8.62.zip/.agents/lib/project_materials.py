from __future__ import annotations
import hashlib, json
from pathlib import Path

class ProjectMaterialError(ValueError):
    pass

def sha256_file(path: Path) -> str:
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):
            h.update(b)
    return h.hexdigest()

def _bounded(root:Path,value:str|Path)->Path:
    p=Path(value)
    p=(root/p if not p.is_absolute() else p).resolve()
    if not (p==root or root in p.parents):
        raise ProjectMaterialError('path escapes Workspace')
    return p

def load_material_index(root:Path)->dict[str,dict]:
    path=root/'project/material-index.json'
    if not path.is_file():
        return {}
    try:
        data=json.loads(path.read_text(encoding='utf-8'))
    except (OSError,json.JSONDecodeError) as exc:
        raise ProjectMaterialError('project/material-index.json is invalid') from exc
    if not isinstance(data,dict) or data.get('schema_version') not in {1,2} or not isinstance(data.get('sources'),list):
        raise ProjectMaterialError('project/material-index.json schema invalid')
    out={}
    for item in data['sources']:
        if not isinstance(item,dict):
            continue
        rel=str(item.get('path','')).strip()
        digest=str(item.get('sha256','')).strip().lower()
        if rel and len(digest)==64:
            out[rel]=item
    return out

def indexed_project_source(root:Path,path:Path, *, require_current_hash:bool=True)->bool:
    root=root.resolve(); path=path.resolve()
    try:
        rel=path.relative_to(root).as_posix()
    except ValueError:
        return False
    item=load_material_index(root).get(rel)
    if not item or not path.is_file():
        return False
    return (not require_current_hash) or sha256_file(path)==str(item.get('sha256','')).lower()

def require_authorized_source(root:Path,path:Path,request:Path, *, allow_work:bool=True)->str:
    root=root.resolve(); path=_bounded(root,path); request=request.resolve()
    if not path.is_file():
        raise ProjectMaterialError(f'source missing: {path}')
    allowed=[request/'input']
    if allow_work:
        allowed.append(request/'work')
    if any(path==base or base in path.parents for base in allowed):
        return path.relative_to(root).as_posix()
    if indexed_project_source(root,path):
        return path.relative_to(root).as_posix()
    raise ProjectMaterialError('source is not current request evidence or a current indexed project material')
