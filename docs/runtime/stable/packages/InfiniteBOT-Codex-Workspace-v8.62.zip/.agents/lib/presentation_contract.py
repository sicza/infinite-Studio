#!/usr/bin/env python3
"""Shared fail-closed contract for how a produced picture presents itself.

A produced deliverable is a **complete picture**: the canvas is filled by image
content. Two things must never be asked of the model:

1. **carrier framing** — a business carrier label (ICON / LOGO / BANNER / KV /
   商店图 / 弹窗 …) named as the thing to create, instead of the complete
   picture. The carrier describes the business object downstream; it is not a
   picture instruction.
2. **presentation simulation** — rounded corners, an app-icon mask/crop,
   squircle, corner radius, a white corner field, or store safe-area frames
   baked into the artwork. Rounding, masking, safe areas and device frames
   belong to delivery / store post-processing, never to generation.

Both rules are machine facts here and are enforced by real consumers:
`image-generation-api` before any network call, and the image-production
delivery gate before Promote. Rounding or masking a delivered picture cannot be
asked for in a prompt and cannot be shipped by accident.

The prompt-side rules are intentionally *not* negation-aware for presentation
simulation: writing "no rounded corners" into a prompt still spends model
attention on corner treatment, so the contract bans the wording entirely.
Carrier framing is negation-aware so that legitimate negative lists such as
"No words, logos, UI" stay valid.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

SCHEMA_VERSION = "sicza.presentation-contract.v1"

# A complete-visual request describes the picture, not the carrier slot it will
# be placed in, and never simulates the carrier's presentation.
COMPLETE_VISUAL_STATEMENT = (
    "describe the complete picture itself (for example \"Create a complete image of ...\"); "
    "the carrier slot, its rounding and its safe area are delivery post-processing"
)


class PresentationError(ValueError):
    """Raised when a prompt or a delivered picture violates the contract."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise PresentationError(message)


# --- prompt contract -------------------------------------------------------

# rule_id -> compiled pattern. Each pattern is applied to the whole prompt with
# sentence-level reporting so the finding can point at real text.
SIMULATION_RULES: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("rounded-corner", re.compile(r"圆角", re.IGNORECASE)),
    ("rounded-corner", re.compile(r"\brounded[\s\-]+(?:square|corner|mask|app|icon|canvas|frame|crop|tile)\b", re.IGNORECASE)),
    ("corner-radius", re.compile(r"\bcorner[\s\-]*radius\b", re.IGNORECASE)),
    ("app-mask", re.compile(r"\b(?:app|application|store)[\s\-]*icon[\s\-]+(?:crop|mask|frame|shape|canvas|format|ratio|corner|tile)\b", re.IGNORECASE)),
    ("app-mask", re.compile(r"\bicon[\s\-]+(?:crop|mask|frame|squircle|tile)\b", re.IGNORECASE)),
    ("app-mask", re.compile(r"\bsquircle\b", re.IGNORECASE)),
    ("app-mask", re.compile(r"\bmask(?:ed|ing)?[\s\-]+corners?\b", re.IGNORECASE)),
    ("corner-field", re.compile(r"\bwhite[\s\-]+corner[\s\-]+(?:field|area|margin|block)\b", re.IGNORECASE)),
    ("corner-field", re.compile(r"\bcorner[\s\-]+field\b", re.IGNORECASE)),
    ("corner-field", re.compile(r"四角(?:留白|圆角|空|白)")),
    ("app-mask", re.compile(r"(?:图标|icon)[^。！？\n]{0,12}(?:裁切|蒙版|外形|外框|圆角)", re.IGNORECASE)),
    ("app-mask", re.compile(r"(?:裁切|蒙版|外框)[^。！？\n]{0,8}(?:圆角|圆角方形)")),
)

# --- carrier policy (single point) -----------------------------------------
# Two levels, one definition. `BLOCKING` artefacts spend model attention on the
# carrier slot itself and are refused before any network call. `RECEIPT` carriers
# are recorded as machine facts without blocking, because the user named ICON and
# rounding specifically and blocking every carrier word would refuse in-flight
# work that has no defect. Escalating RECEIPT to BLOCKING is a one-line change.
CARRIER_POLICY_RECEIPT = "receipt"

BLOCKING_CARRIERS_EN = ("app icon", "application icon", "game icon", "icon")
BLOCKING_CARRIERS_ZH = ("图标",)
RECEIPT_CARRIERS_EN = (
    "logo", "wordmark", "banner", "key visual", "kv", "store artwork",
    "store image", "store screenshot", "feature graphic", "screenshot",
)
RECEIPT_CARRIERS_ZH = ("标志", "字标", "横幅", "主视觉", "商店图", "商店截屏", "商店截图")

# a carrier word next to a canvas/presentation noun always simulates the slot,
# whatever the carrier's own policy level is
PRESENTATION_NOUNS = ("crop", "mask", "frame", "canvas", "shape", "ratio", "tile", "corner")

CREATION_VERB_EN = r"(?:create|generate|make|draw|render|design|produce|paint|build)"
CREATION_VERB_ZH = r"(?:生成|制作|做|绘制|设计|出|画)"

def _task_framing(words_en, words_zh) -> tuple[re.Pattern[str], ...]:
    return (
        re.compile(
            r"\b" + CREATION_VERB_EN + r"\b([^.\n]{0,80}?)\b(" + "|".join(re.escape(w) for w in words_en) + r")\b",
            re.IGNORECASE,
        ),
        re.compile(
            CREATION_VERB_ZH + r"[^。！？\n]{0,40}?(" + "|".join(re.escape(w) for w in words_zh) + r")"
        ),
    )


_TASK_FRAMING = _task_framing(BLOCKING_CARRIERS_EN, BLOCKING_CARRIERS_ZH)
_RECEIPT_FRAMING = _task_framing(RECEIPT_CARRIERS_EN, RECEIPT_CARRIERS_ZH)
_SLOT_SIMULATION = (
    re.compile(r"\b(?:app icon|application icon|game icon|icon|logo|banner|key visual|kv|store artwork)\b[^.,\n]{0,20}\b(?:"
               + "|".join(PRESENTATION_NOUNS) + r")\b", re.IGNORECASE),
    re.compile(r"(?:图标|标志|字标|横幅|主视觉|商店图)[^。！？\n]{0,10}(?:裁切|蒙版|外框|画布|比例|图块|圆角)"),
)

NEGATION_CUE = re.compile(
    r"^\s*(?:no|not|without|avoid|never|exclude|do\s+not|don'?t|omit|remove)\b|不得|禁止|不要|无需|不能|避免|没有",
    re.IGNORECASE,
)

_SENTENCE = re.compile(r"[^.!?\n。！？]+[.!?\n。！？]?", re.UNICODE)


def _sentences(text: str) -> list[tuple[int, str]]:
    return [(match.start(), match.group(0)) for match in _SENTENCE.finditer(text)]


def _excerpt(text: str, start: int, end: int, width: int = 48) -> str:
    lo = max(0, start - 8)
    hi = min(len(text), end + 8)
    fragment = text[lo:hi].replace("\n", " ").strip()
    if len(fragment) > width:
        fragment = fragment[: width - 1] + "…"
    return fragment


def find_simulation(text: str) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    seen: set[tuple[str, int]] = set()
    for rule_id, pattern in SIMULATION_RULES:
        for match in pattern.finditer(text):
            key = (rule_id, match.start())
            if key in seen:
                continue
            seen.add(key)
            findings.append({
                "rule": rule_id,
                "class": "presentation-simulation",
                "match": match.group(0),
                "offset": match.start(),
                "excerpt": _excerpt(text, match.start(), match.end()),
            })
    return sorted(findings, key=lambda item: item["offset"])


def find_carrier_framing(text: str) -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    seen: set[int] = set()
    for index, (offset, sentence) in enumerate(_sentences(text)):
        if not sentence.strip():
            continue
        if index > 0 and NEGATION_CUE.search(sentence):
            continue
        if index == 0 and NEGATION_CUE.search(sentence[: sentence.find(" ") + 1] or ""):
            continue
        for pattern in _TASK_FRAMING:
            match = pattern.search(sentence)
            if match is None:
                continue
            head = sentence[: match.start()]
            if NEGATION_CUE.search(head):
                continue
            start = offset + match.start(1 if match.lastindex and match.lastindex >= 1 else 0)
            if start in seen:
                continue
            seen.add(start)
            findings.append({
                "rule": "carrier-framing",
                "class": "carrier-framing",
                "match": (match.group(2) if match.lastindex and match.lastindex >= 2 else match.group(0)),
                "offset": start,
                "excerpt": _excerpt(text, start, offset + match.end()),
            })
            break
    return sorted(findings, key=lambda item: item["offset"])


def find_slot_simulation(text: str) -> list[dict[str, Any]]:
    """Any carrier word that simulates the carrier's canvas is blocking."""
    findings: list[dict[str, Any]] = []
    seen: set[int] = set()
    for pattern in _SLOT_SIMULATION:
        for match in pattern.finditer(text):
            if match.start() in seen:
                continue
            seen.add(match.start())
            findings.append({
                "rule": "carrier-slot-simulation",
                "class": "carrier-framing",
                "match": match.group(0),
                "offset": match.start(),
                "excerpt": _excerpt(text, match.start(), match.end()),
            })
    return findings


def carrier_receipt(text: str) -> dict[str, Any]:
    """Non-blocking carrier hits, recorded as machine fact for later escalation."""
    findings: list[dict[str, Any]] = []
    seen: set[int] = set()
    for pattern in _RECEIPT_FRAMING:
        for sentence_start, sentence in _sentences(text):
            if not sentence.strip() or NEGATION_CUE.search(sentence):
                continue
            match = pattern.search(sentence)
            if match is None:
                continue
            hit_word = match.group(2) if match.lastindex and match.lastindex >= 2 else match.group(0)
            start = sentence_start + match.start()
            if start in seen:
                continue
            seen.add(start)
            findings.append({
                "rule": "carrier-receipt",
                "class": "carrier-framing",
                "policy": CARRIER_POLICY_RECEIPT,
                "match": hit_word,
                "offset": start,
                "excerpt": _excerpt(text, start, sentence_start + match.end()),
            })
    findings.sort(key=lambda item: item["offset"])
    return {
        "policy": CARRIER_POLICY_RECEIPT,
        "blocking": False,
        "hits": findings,
        "words": sorted({str(item["match"]).casefold() for item in findings}),
    }


def lint_prompt(text: str) -> dict[str, Any]:
    """Return the machine verdict for one authored prompt."""
    require(isinstance(text, str) and bool(text.strip()), "prompt text must be non-empty")
    findings = find_simulation(text) + find_carrier_framing(text) + find_slot_simulation(text)
    findings.sort(key=lambda item: item["offset"])
    return {
        "schema_version": SCHEMA_VERSION,
        "status": "blocked" if findings else "passed",
        "findings": findings,
        "rule_ids": sorted({item["rule"] for item in findings}),
        "carrier_policy": {
            "blocking": list(BLOCKING_CARRIERS_EN) + list(BLOCKING_CARRIERS_ZH),
            "receipt": list(RECEIPT_CARRIERS_EN) + list(RECEIPT_CARRIERS_ZH),
        },
        "receipts": carrier_receipt(text),
    }


def require_clean_prompt(text: str, *, label: str = "prompt") -> dict[str, Any]:
    """Fail closed on an authored prompt that violates the presentation contract."""
    verdict = lint_prompt(text)
    if verdict["status"] == "blocked":
        details = "; ".join(f"{item['rule']} @ {item['excerpt']!r}" for item in verdict["findings"][:4])
        raise PresentationError(
            f"{label} violates the complete-visual presentation contract: {details}. "
            f"Rewrite it to {COMPLETE_VISUAL_STATEMENT}."
        )
    return verdict


# --- delivered-picture contract -------------------------------------------

CORNER_TOLERANCE = 8
FLAT_TOLERANCE = 6
PLATE_TOLERANCE = 12

# A baked carrier plate is a colour that stays THIN inward at every point of every
# edge. Measuring the distance to content along one diagonal confuses it with a
# large centred subject, because that distance shrinks as the subject grows. So the
# depth is probed PERPENDICULAR to the four edges at several positions each: a
# margin stays thin everywhere, while a background necessarily reaches deep inward
# somewhere (a centred subject never spans every row and every column).
# A picture is refused when one clean flat colour owns the four corners, reaches at
# least this far inward there, and does NOT touch the middle of any edge. The reach is
# the only threshold: a 12%-thin-margin rule was tried twice and could not separate a
# carrier from a large centred subject, so no such rule survives here.
MASK_MIN_CORNER_REACH = 0.05


def _same(pixel, colour, tolerance: int = PLATE_TOLERANCE) -> bool:
    return all(abs(pixel[channel] - colour[channel]) <= tolerance for channel in range(3))


def _corner_squares(image, size: int) -> dict[str, list[tuple[int, ...]]]:
    """Pixel blocks at the four corners, used to describe the corner field."""
    width, height = image.size
    boxes = {
        "top-left": (0, 0, size, size),
        "top-right": (width - size, 0, width, size),
        "bottom-left": (0, height - size, size, height),
        "bottom-right": (width - size, height - size, width, height),
    }
    blocks: dict[str, list[tuple[int, ...]]] = {}
    for name, (x0, y0, x1, y1) in boxes.items():
        block = []
        for y in range(y0, y1):
            for x in range(x0, x1):
                pixel = image.getpixel((x, y))
                block.append(tuple(pixel[:3]) if isinstance(pixel, tuple) else (pixel, pixel, pixel))
        blocks[name] = block
    return blocks


def _mean(pixels) -> tuple[float, float, float]:
    count = len(pixels) or 1
    return tuple(sum(pixel[i] for pixel in pixels) / count for i in range(3))


def _flatness(pixels) -> float:
    """Largest per-channel spread inside a block; a flat plate stays below tolerance."""
    if not pixels:
        return 0.0
    return max(max(pixel[i] for pixel in pixels) - min(pixel[i] for pixel in pixels) for i in range(3))


def _distance(a, b) -> float:
    return max(abs(float(a[i]) - float(b[i])) for i in range(3))




def edge_depth(image, colour, size: int, *, vertical: bool, offset: int) -> int:
    """Depth of ``colour`` measured inward from an edge, starting at ``offset``."""
    width, height = image.size
    depth = 0
    if vertical:
        x = offset
        for y in range(height):
            if not _same(image.getpixel((x, y)), colour):
                break
            depth += 1
    else:
        y = offset
        for x in range(width):
            if not _same(image.getpixel((x, y)), colour):
                break
            depth += 1
    return depth


def plate_depth_profile(image, colour, size: int) -> tuple[int, int]:
    """Deepest and shallowest inward depth of the corner colour along the four edges."""
    width, height = image.size
    xs = sorted({0, width // 8, width // 4, width // 2, (3 * width) // 4, (7 * width) // 8, width - 1})
    ys = sorted({0, height // 8, height // 4, height // 2, (3 * height) // 4, (7 * height) // 8, height - 1})
    depths = [edge_depth(image, colour, size, vertical=True, offset=x) for x in xs]
    depths += [edge_depth(image, colour, size, vertical=False, offset=y) for y in ys]
    return max(depths), min(depths)


def corner_field_observation(path: Path | str) -> dict[str, Any]:
    """Describe the four corner blocks of a delivered picture as machine facts.

    Field contract: `uniform_corner_field`, `corner_reach_ratio`, `edge_midpoint_hits` and
    `corner_plate` are the DECISION inputs (read by `require_complete_visual_picture` below);
    `corner_means`, `corner_sample`, `corner_plate_depth*`, `border*`/`size`/`path` are EVIDENCE
    fields whose consumer is the machine-readable output of the gate CLI (a reviewer reads
    them); none of them is read by code, and none of them needs to be.

    `uniform_corner_field` means all four corner blocks are flat and share one colour.
    `corner_plate` means the picture carries a BAKED ROUNDED CARRIER: that colour owns
    the four corners, reaches inward at the corners (>= `MASK_MIN_CORNER_REACH` of the
    short edge), and yet does NOT touch the middle of any edge - the content runs to the
    frame there. A plain uniform margin, a letterbox or a centred subject keep the field
    colour at the edge midpoints and are therefore NOT flagged by this detector (layout
    review owns those); borders thinner than the ~2% corner sampling floor are out of range; and because the corner block itself must stay flat, a synthetic baked rounded carrier is only refused from about 7% of the short edge upward (measured 6.5-7%), so finer rounding is outside this detector. The depth numbers are reported as evidence.
    """
    try:
        from PIL import Image
    except ImportError as exc:  # pragma: no cover - host dependency
        raise PresentationError("Pillow is required for the delivered-picture contract") from exc

    target = Path(path)
    require(target.is_file(), f"delivered picture is missing: {target}")
    with Image.open(target) as handle:
        image = handle.convert("RGB")
        width, height = image.size
        require(width >= 8 and height >= 8, "delivered picture is too small to inspect")
        size = max(2, int(min(width, height) * 0.02))
        corners = _corner_squares(image, size)
        means = {name: _mean(pixels) for name, pixels in corners.items()}
        flat = {name: _flatness(pixels) for name, pixels in corners.items()}
        reference = tuple(int(round(value)) for value in means["top-left"])
        corners_agree = all(_distance(reference, value) <= CORNER_TOLERANCE for value in means.values())
        corners_flat = all(value <= FLAT_TOLERANCE for value in flat.values())
        uniform = bool(corners_agree and corners_flat)
        deepest, shallowest = plate_depth_profile(image, reference, size)
        short_edge = min(width, height)
        # Only the rounded-carrier geometry is refused here. A centred subject on a
        # flat field, a uniform margin and a letterbox keep the field colour at the edge
        # midpoints, so they are released by construction and are owned by layout review
        # instead of this detector.
        midpoint_hits = sum(
            1 for x, y in ((width // 2, 0), (width // 2, height - 1), (0, height // 2), (width - 1, height // 2))
            if _same(image.getpixel((x, y)), reference)
        )
        corner_reach = deepest / short_edge if short_edge else 1.0
        plate = bool(uniform and corner_reach >= MASK_MIN_CORNER_REACH and midpoint_hits == 0)
        white = all(channel >= 240 for channel in reference)
        return {
            "schema_version": SCHEMA_VERSION,
            "contract": "complete-full-bleed-picture",
            "path": target.as_posix(),
            "size": [width, height],
            "corner_sample": size,
            "corner_means": {name: [round(value, 2) for value in mean] for name, mean in means.items()},
            "uniform_corner_field": uniform,
            "corner_plate_depth": deepest,
            "corner_plate_depth_min": shallowest,
            "edge_midpoint_hits": midpoint_hits,
            "corner_reach_ratio": round(corner_reach, 4),
            "mask_min_corner_reach": MASK_MIN_CORNER_REACH,
            "corner_plate": plate,
            "corner_colour_near_white": bool(white),
        }


def require_complete_visual_picture(path: Path | str, *, label: str = "delivered picture") -> dict[str, Any]:
    """Fail closed when a delivered artwork carries a baked carrier mask."""
    observation = corner_field_observation(path)
    if observation["corner_plate"]:
        raise PresentationError(
            f"{label} carries a baked rounded carrier, not a complete picture: one flat colour "
            f"({observation['corner_means']['top-left']}) owns the four corners and reaches "
            f"{observation['corner_reach_ratio']:.1%} of the short edge inward there, while the content runs to the "
            "frame at the middle of every edge - i.e. rounded corners and a carrier plate were baked into the "
            "artwork. The contract requires a complete visual; rounding, masking, plates and store safe areas belong "
            "to delivery post-processing."
        )
    return observation


def rule_ids() -> list[str]:
    return sorted({rule_id for rule_id, _ in SIMULATION_RULES} | {"carrier-framing"})
