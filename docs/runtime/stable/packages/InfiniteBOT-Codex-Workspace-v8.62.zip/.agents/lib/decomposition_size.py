#!/usr/bin/env python3
"""Authoritative source/work/delivery sizing for layer decomposition.

The contract deliberately separates:
- source canvas: decoded user input facts,
- work surface: provider-legal model execution geometry,
- delivery canvas: document/export geometry,
- editable master geometry: owned by each layer, not this planner.
"""
from __future__ import annotations

import hashlib
import json
import math
import sys
from pathlib import Path
from typing import Any

LIB = Path(__file__).resolve().parent
if str(LIB) not in sys.path:
    sys.path.insert(0, str(LIB))
from gpt_image_contract import gpt_image_size_constraints, validate_gpt_size

CONTRACT_SCHEMA = "wxian.decomposition-size.v2"
SKILL_IMAGE = "wxian-image-layer-decomposition"
SKILL_UI = "wxian-game-ui-layer-decomposition"
SUPPORTED_SKILLS = {SKILL_IMAGE, SKILL_UI}


class SizeContractError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise SizeContractError(message)


def _align_up(value: int, alignment: int) -> int:
    return ((value + alignment - 1) // alignment) * alignment


def _legal_surface_for_content(width: int, height: int, c: dict[str, Any]) -> tuple[int, int] | None:
    """Return an origin-preserving padded surface for content, or None if impossible."""
    a = int(c["alignment"])
    max_edge = int(c["max_edge"])
    max_pixels = int(c["max_pixels"])
    min_pixels = int(c["min_pixels"])
    min_ratio = float(c["min_aspect_ratio"])
    max_ratio = float(c["max_aspect_ratio"])
    w, h = max(1, int(width)), max(1, int(height))

    # Pad, never stretch, to satisfy provider aspect constraints.
    ratio = w / h
    if ratio > max_ratio:
        h = max(h, math.ceil(w / max_ratio))
    elif ratio < min_ratio:
        w = max(w, math.ceil(h * min_ratio))
    w = _align_up(w, a)
    h = _align_up(h, a)
    if w > max_edge or h > max_edge or w * h > max_pixels:
        return None
    # A too-small surface is not legal yet; caller may increase content scale.
    if w * h < min_pixels:
        return None
    return w, h


def _fits_max(width: int, height: int, c: dict[str, Any]) -> tuple[int, int] | None:
    """Like _legal_surface_for_content, but ignores minimum pixel floor."""
    a = int(c["alignment"])
    max_edge = int(c["max_edge"])
    max_pixels = int(c["max_pixels"])
    min_ratio = float(c["min_aspect_ratio"])
    max_ratio = float(c["max_aspect_ratio"])
    w, h = max(1, int(width)), max(1, int(height))
    ratio = w / h
    if ratio > max_ratio:
        h = max(h, math.ceil(w / max_ratio))
    elif ratio < min_ratio:
        w = max(w, math.ceil(h * min_ratio))
    w = _align_up(w, a)
    h = _align_up(h, a)
    if w > max_edge or h > max_edge or w * h > max_pixels:
        return None
    return w, h


def _surface_at_scale(source: tuple[int, int], scale: float, c: dict[str, Any]) -> tuple[int, int, int, int] | None:
    cw = max(1, round(source[0] * scale))
    ch = max(1, round(source[1] * scale))
    surface = _fits_max(cw, ch, c)
    if surface is None:
        return None
    return cw, ch, surface[0], surface[1]


def _resolve_scale(source: tuple[int, int], preferred: float, c: dict[str, Any]) -> tuple[float, int, int, int, int, str]:
    """Find a legal model surface while preserving aspect and preferring requested scale."""
    require(preferred > 0, "preferred work scale must be > 0")
    min_pixels = int(c["min_pixels"])

    preferred_result = _surface_at_scale(source, preferred, c)
    if preferred_result and preferred_result[2] * preferred_result[3] >= min_pixels:
        cw, ch, sw, sh = preferred_result
        mode = "preferred"
        return preferred, cw, ch, sw, sh, mode

    # If preferred is too large, choose the largest legal scale <= preferred.
    if preferred_result is None:
        lo, hi = 0.0, preferred
        best: tuple[float, int, int, int, int] | None = None
        for _ in range(60):
            mid = (lo + hi) / 2
            result = _surface_at_scale(source, mid, c)
            if result is not None:
                cw, ch, sw, sh = result
                best = (mid, cw, ch, sw, sh)
                lo = mid
            else:
                hi = mid
        require(best is not None, "source aspect cannot be represented within model maximum constraints")
        scale, cw, ch, sw, sh = best
        require(sw * sh >= min_pixels, "largest legal work surface is below provider minimum pixel count")
        return scale, cw, ch, sw, sh, "clamped_max"

    # Preferred fits maximum but falls below minimum pixels: increase only as much as required.
    lo, hi = preferred, preferred
    result = preferred_result
    while result[2] * result[3] < min_pixels:
        hi *= 1.25
        result = _surface_at_scale(source, hi, c)
        require(result is not None, "provider minimum pixel count cannot be reached within maximum constraints")
    for _ in range(60):
        mid = (lo + hi) / 2
        result = _surface_at_scale(source, mid, c)
        if result is not None and result[2] * result[3] >= min_pixels:
            hi = mid
        else:
            lo = mid
    result = _surface_at_scale(source, hi, c)
    assert result is not None
    cw, ch, sw, sh = result
    return hi, cw, ch, sw, sh, "raised_minimum"


def plan_size_contract(
    source_size: tuple[int, int],
    *,
    skill: str,
    model: str,
    delivery_size: tuple[int, int] | None = None,
    preferred_work_scale: float | None = None,
) -> dict[str, Any]:
    require(skill in SUPPORTED_SKILLS, f"unsupported decomposition skill: {skill}")
    sw, sh = map(int, source_size)
    require(sw > 0 and sh > 0, "source canvas must be positive")
    dw, dh = map(int, delivery_size or source_size)
    require(dw > 0 and dh > 0, "delivery canvas must be positive")
    default_scale = 2.0 if skill == SKILL_UI else 1.0
    preferred = float(preferred_work_scale if preferred_work_scale is not None else default_scale)
    constraints = gpt_image_size_constraints(model)
    scale, cw, ch, ww, wh, resolution_mode = _resolve_scale((sw, sh), preferred, constraints)
    size_string = f"{ww}x{wh}"
    validate_gpt_size(model, size_string)
    right, bottom = ww - cw, wh - ch
    transform = {
        "source_to_work": {
            "scale_x": cw / sw,
            "scale_y": ch / sh,
            "offset_x": 0,
            "offset_y": 0,
            "content_rect": [0, 0, cw, ch],
        },
        "work_to_delivery": {
            "crop_rect": [0, 0, cw, ch],
            "scale_x": dw / cw,
            "scale_y": dh / ch,
            "offset_x": 0,
            "offset_y": 0,
        },
    }
    return {
        "schema_version": CONTRACT_SCHEMA,
        "skill": skill,
        "source_canvas": {"width": sw, "height": sh},
        "delivery_canvas": {
            "width": dw,
            "height": dh,
            "policy": "preserve_source" if (dw, dh) == (sw, sh) else "explicit_size",
        },
        "work_surfaces": [{
            "id": "decomposition",
            "provider": str(constraints["provider"]),
            "model": model,
            "width": ww,
            "height": wh,
            "content_width": cw,
            "content_height": ch,
            "preferred_scale": preferred,
            "effective_scale_x": cw / sw,
            "effective_scale_y": ch / sh,
            "resolution_mode": resolution_mode,
            "normalization": {
                "mode": (
                    "none" if (cw, ch) == (sw, sh) and right == 0 and bottom == 0 else
                    "pad" if (cw, ch) == (sw, sh) else
                    "resize" if right == 0 and bottom == 0 else
                    "resize_and_pad"
                ),
                "left": 0,
                "top": 0,
                "right": right,
                "bottom": bottom,
            },
            "constraints": constraints,
        }],
        "transforms": transform,
    }


def contract_sha256(value: dict[str, Any]) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def validate_size_contract(value: dict[str, Any], *, source_size: tuple[int, int] | None = None) -> dict[str, Any]:
    require(value.get("schema_version") == CONTRACT_SCHEMA, f"size contract schema must be {CONTRACT_SCHEMA}")
    require(value.get("skill") in SUPPORTED_SKILLS, "size contract skill is invalid")
    source = value.get("source_canvas")
    delivery = value.get("delivery_canvas")
    surfaces = value.get("work_surfaces")
    transforms = value.get("transforms")
    require(isinstance(source, dict) and isinstance(delivery, dict), "size contract canvases are missing")
    require(isinstance(surfaces, list) and len(surfaces) >= 1, "size contract requires work_surfaces")
    require(isinstance(transforms, dict), "size contract transforms are missing")

    actual_source = (int(source.get("width", 0)), int(source.get("height", 0)))
    actual_delivery = (int(delivery.get("width", 0)), int(delivery.get("height", 0)))
    require(actual_source[0] > 0 and actual_source[1] > 0, "size contract source canvas is invalid")
    require(actual_delivery[0] > 0 and actual_delivery[1] > 0, "size contract delivery canvas is invalid")
    if source_size is not None:
        require(actual_source == tuple(source_size), "size contract source canvas does not match decoded source")
    expected_policy = "preserve_source" if actual_delivery == actual_source else "explicit_size"
    require(delivery.get("policy") == expected_policy, "size contract delivery policy does not match source/delivery geometry")

    seen_ids: set[str] = set()
    for item in surfaces:
        require(isinstance(item, dict), "work surface must be an object")
        sid = str(item.get("id", "")).strip()
        require(sid and sid not in seen_ids, "work surface id must be non-empty and unique")
        seen_ids.add(sid)
        model = str(item.get("model", ""))
        constraints = gpt_image_size_constraints(model)
        require(item.get("provider") == constraints["provider"], f"work surface provider mismatch: {sid}")
        require(item.get("constraints") == constraints, f"work surface constraints are stale: {sid}")
        width, height = int(item.get("width", 0)), int(item.get("height", 0))
        validate_gpt_size(model, f"{width}x{height}")
        cw, ch = int(item.get("content_width", 0)), int(item.get("content_height", 0))
        require(cw > 0 and ch > 0 and cw <= width and ch <= height, "work surface content bounds are invalid")
        sx, sy = float(item.get("effective_scale_x", 0)), float(item.get("effective_scale_y", 0))
        require(sx > 0 and sy > 0, f"work surface effective scale is invalid: {sid}")
        require(abs(sx - cw / actual_source[0]) < 1e-9 and abs(sy - ch / actual_source[1]) < 1e-9,
                f"work surface effective scale does not match content/source geometry: {sid}")
        norm = item.get("normalization")
        require(isinstance(norm, dict), f"work surface normalization missing: {sid}")
        require(norm.get("mode") in {"none", "pad", "resize", "resize_and_pad"}, f"work surface normalization mode invalid: {sid}")
        require([int(norm.get(k, -1)) for k in ("left", "top")] == [0, 0], f"work surface origin padding must remain zero: {sid}")
        require(int(norm.get("right", -1)) == width - cw and int(norm.get("bottom", -1)) == height - ch,
                f"work surface padding does not match content bounds: {sid}")

    primary = surfaces[0]
    stw = transforms.get("source_to_work")
    wtd = transforms.get("work_to_delivery")
    require(isinstance(stw, dict) and isinstance(wtd, dict), "size contract transform stages are missing")
    cw, ch = int(primary["content_width"]), int(primary["content_height"] )
    require(stw.get("content_rect") == [0, 0, cw, ch], "source_to_work content_rect mismatch")
    require(abs(float(stw.get("scale_x", 0)) - cw / actual_source[0]) < 1e-9 and
            abs(float(stw.get("scale_y", 0)) - ch / actual_source[1]) < 1e-9 and
            int(stw.get("offset_x", -1)) == 0 and int(stw.get("offset_y", -1)) == 0,
            "source_to_work transform mismatch")
    require(wtd.get("crop_rect") == [0, 0, cw, ch], "work_to_delivery crop_rect mismatch")
    require(abs(float(wtd.get("scale_x", 0)) - actual_delivery[0] / cw) < 1e-9 and
            abs(float(wtd.get("scale_y", 0)) - actual_delivery[1] / ch) < 1e-9 and
            int(wtd.get("offset_x", -1)) == 0 and int(wtd.get("offset_y", -1)) == 0,
            "work_to_delivery transform mismatch")
    return value

