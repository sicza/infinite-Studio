from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from project_materials import indexed_project_source

VIDEO_EXTENSIONS = frozenset({'.mp4', '.mov', '.webm', '.mkv', '.m4v', '.avi'})
IMAGE_EXTENSIONS = frozenset({'.png', '.jpg', '.jpeg', '.webp'})


class VideoEvidenceError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise VideoEvidenceError(message)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def bounded(root: Path, value: str | Path, *, must_exist: bool = False) -> Path:
    candidate = Path(value)
    if not candidate.is_absolute():
        candidate = root / candidate
    resolved = candidate.resolve()
    root = root.resolve()
    require(resolved == root or root in resolved.parents, f'path escapes Workspace: {value}')
    if must_exist:
        require(resolved.exists(), f'path does not exist: {value}')
    return resolved


def relative(root: Path, path: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def is_video(path: Path) -> bool:
    return path.is_file() and path.suffix.lower() in VIDEO_EXTENSIONS


def authorized_video_source(root: Path, request: Path, source: Path) -> bool:
    source = source.resolve()
    req_input = (request / 'input').resolve()
    if req_input in source.parents:
        return True
    return indexed_project_source(root.resolve(), source)


def _load_json(path: Path) -> dict[str, Any]:
    require(path.is_file(), f'missing JSON evidence: {path}')
    try:
        value = json.loads(path.read_text(encoding='utf-8'))
    except (OSError, json.JSONDecodeError) as exc:
        raise VideoEvidenceError(f'invalid JSON evidence: {path}') from exc
    require(isinstance(value, dict), f'JSON evidence root must be object: {path}')
    return value


def analysis_dir_from_path(root: Path, request: Path, value: str | Path) -> Path:
    path = bounded(root, value, must_exist=True)
    if path.is_file():
        directory = path.parent
    else:
        directory = path
    base = (request / 'work' / 'video-source-analysis').resolve()
    require(base in directory.resolve().parents or directory.resolve() == base,
            'video analysis must be inside current request work/video-source-analysis/')
    return directory.resolve()


def validate_source_manifest(root: Path, request: Path, analysis_dir: Path) -> dict[str, Any]:
    manifest_path = analysis_dir / 'source-manifest.json'
    data = _load_json(manifest_path)
    require(data.get('schema_version') == 1, 'video source manifest schema_version must be 1')
    required = {'schema_version', 'source_path', 'source_sha256', 'backend', 'media', 'frames'}
    require(required <= set(data), 'video source manifest missing required fields')
    source = bounded(root, str(data['source_path']), must_exist=True)
    require(is_video(source), 'video source manifest source_path is not a supported video')
    require(authorized_video_source(root, request, source), 'video source is not current request input or indexed project material')
    require(sha256_file(source) == str(data['source_sha256']), 'video source hash mismatch')
    media = data['media']
    require(isinstance(media, dict), 'video source manifest media must be object')
    for key in ('duration_ms', 'width', 'height', 'fps'):
        require(key in media, f'video media missing {key}')
    require(isinstance(media['duration_ms'], int) and media['duration_ms'] > 0, 'video duration_ms must be > 0')
    require(isinstance(media['width'], int) and media['width'] > 0, 'video width must be > 0')
    require(isinstance(media['height'], int) and media['height'] > 0, 'video height must be > 0')
    require(isinstance(media['fps'], (int, float)) and media['fps'] > 0, 'video fps must be > 0')
    frames = data['frames']
    require(isinstance(frames, list) and frames, 'video source manifest must contain extracted frames')
    seen_paths: set[str] = set()
    seen_ts: set[tuple[int, str]] = set()
    for index, item in enumerate(frames):
        require(isinstance(item, dict), f'frames[{index}] must be object')
        require({'path', 'sha256', 'timestamp_ms', 'kind'} <= set(item), f'frames[{index}] missing fields')
        path = bounded(root, str(item['path']), must_exist=True)
        require(path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS, f'frames[{index}] is not a supported image')
        require(analysis_dir.resolve() in path.resolve().parents, f'frames[{index}] must stay inside its analysis directory')
        rel = relative(root, path)
        require(rel not in seen_paths, f'duplicate frame path: {rel}')
        seen_paths.add(rel)
        require(sha256_file(path) == str(item['sha256']), f'frame hash mismatch: {rel}')
        ts = item['timestamp_ms']
        require(isinstance(ts, int) and 0 <= ts <= media['duration_ms'], f'invalid frame timestamp: {rel}')
        kind = str(item['kind'])
        require(kind in {'overview', 'refine'}, f'invalid frame kind: {kind}')
        key = (ts, kind)
        require(key not in seen_ts, f'duplicate frame timestamp/kind: {key}')
        seen_ts.add(key)
    return data


def validate_evidence(root: Path, request: Path, analysis_dir: Path) -> dict[str, Any]:
    manifest = validate_source_manifest(root, request, analysis_dir)
    evidence_path = analysis_dir / 'evidence.json'
    data = _load_json(evidence_path)
    required = {'schema_version', 'source_path', 'source_sha256', 'observations', 'inferences', 'representative_frames'}
    require(set(data) == required, 'video evidence.json must contain only the canonical fields')
    require(data['schema_version'] == 1, 'video evidence schema_version must be 1')
    require(str(data['source_path']) == str(manifest['source_path']), 'video evidence source_path mismatch')
    require(str(data['source_sha256']) == str(manifest['source_sha256']), 'video evidence source_sha256 mismatch')

    frame_map = {str(item['path']): item for item in manifest['frames']}
    observations = data['observations']
    require(isinstance(observations, list) and observations, 'video evidence requires at least one observation')
    allowed_types = {
        'gameplay_action', 'gameplay_visible_result', 'ui_feedback', 'gameplay_state',
        'character_action', 'scene_event', 'camera', 'composition', 'lighting_color',
        'environment', 'text_ui', 'audio_dialogue', 'narrative_event', 'other'
    }
    obs_ids: set[str] = set()
    observation_facts: dict[str, dict[str, Any]] = {}
    duration = int(manifest['media']['duration_ms'])
    for index, item in enumerate(observations):
        require(isinstance(item, dict), f'observations[{index}] must be object')
        require(set(item) == {'id', 'type', 'fact', 'start_ms', 'end_ms', 'frame_paths'},
                f'observations[{index}] has invalid fields')
        oid = str(item['id'])
        require(oid and oid not in obs_ids, f'invalid/duplicate observation id: {oid}')
        obs_ids.add(oid)
        otype = str(item['type'])
        require(otype in allowed_types, f'invalid observation type: {otype}')
        fact = str(item['fact']).strip()
        require(fact and fact.lower() not in {'unknown', 'none', 'n/a', 'na', '未知', '待定'}, f'observation fact must be concrete: {oid}')
        start = item['start_ms']; end = item['end_ms']
        require(isinstance(start, int) and isinstance(end, int) and 0 <= start <= end <= duration,
                f'invalid observation time range: {oid}')
        refs = item['frame_paths']
        require(isinstance(refs, list) and refs, f'observation must reference at least one extracted frame: {oid}')
        require(len(set(map(str, refs))) == len(refs), f'duplicate frame_paths in observation: {oid}')
        for ref in refs:
            require(str(ref) in frame_map, f'observation references unknown frame: {ref}')
        observation_facts[oid] = item

    inferences = data['inferences']
    require(isinstance(inferences, list), 'video evidence inferences must be array')
    inf_ids: set[str] = set()
    for index, item in enumerate(inferences):
        require(isinstance(item, dict), f'inferences[{index}] must be object')
        require(set(item) == {'id', 'claim', 'confidence', 'supported_by'}, f'inferences[{index}] has invalid fields')
        iid = str(item['id'])
        require(iid and iid not in inf_ids, f'invalid/duplicate inference id: {iid}')
        inf_ids.add(iid)
        claim = str(item['claim']).strip()
        require(claim, f'inference claim must not be empty: {iid}')
        require(str(item['confidence']) in {'high', 'medium', 'low'}, f'invalid inference confidence: {iid}')
        support = item['supported_by']
        require(isinstance(support, list) and support, f'inference must cite observation ids: {iid}')
        require(all(str(ref) in obs_ids for ref in support), f'inference cites unknown observation: {iid}')

    representative = data['representative_frames']
    require(isinstance(representative, list) and representative, 'video evidence requires representative_frames')
    require(len(set(map(str, representative))) == len(representative), 'representative_frames contains duplicates')
    for ref in representative:
        require(str(ref) in frame_map, f'representative frame is not in source manifest: {ref}')

    analysis_md = analysis_dir / 'video-analysis.md'
    require(analysis_md.is_file(), 'video-analysis.md is required')
    text = analysis_md.read_text(encoding='utf-8')
    require(str(manifest['source_path']) in text, 'video-analysis.md must bind source_path')
    require(str(manifest['source_sha256']) in text, 'video-analysis.md must bind source_sha256')
    require(any(str(ref) in text for ref in representative), 'video-analysis.md must cite at least one representative frame path')

    return {
        'status': 'passed',
        'analysis_dir': relative(root, analysis_dir),
        'source_path': manifest['source_path'],
        'source_sha256': manifest['source_sha256'],
        'media': manifest['media'],
        'frame_count': len(manifest['frames']),
        'observation_count': len(observations),
        'inference_count': len(inferences),
        'representative_frames': [str(x) for x in representative],
        'observations': observation_facts,
    }


def find_analysis_for_source(root: Path, request: Path, source: Path) -> Path | None:
    base = request / 'work' / 'video-source-analysis'
    if not base.is_dir():
        return None
    source_rel = relative(root, source)
    source_hash = sha256_file(source)
    matches: list[Path] = []
    for manifest_path in base.glob('*/source-manifest.json'):
        try:
            data = json.loads(manifest_path.read_text(encoding='utf-8'))
        except (OSError, json.JSONDecodeError):
            continue
        if isinstance(data, dict) and data.get('source_path') == source_rel and data.get('source_sha256') == source_hash:
            matches.append(manifest_path.parent.resolve())
    if len(matches) == 1:
        return matches[0]
    return None


def verified_video_frame(root: Path, request: Path, frame: Path) -> bool:
    frame = frame.resolve()
    base = (request / 'work' / 'video-source-analysis').resolve()
    if base not in frame.parents or frame.suffix.lower() not in IMAGE_EXTENSIONS or not frame.is_file():
        return False
    for parent in frame.parents:
        if parent == base:
            break
        manifest_path = parent / 'source-manifest.json'
        if not manifest_path.is_file():
            continue
        try:
            manifest = validate_source_manifest(root, request, parent)
        except (VideoEvidenceError, OSError, ValueError):
            return False
        rel = relative(root, frame)
        return any(item.get('path') == rel and item.get('sha256') == sha256_file(frame) for item in manifest['frames'])
    return False
