#!/usr/bin/env python3
"""Shared contracts for the formal Project Visual Baseline."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

BASELINE_SCHEMA = "8"
BASELINE_INDEX_SCHEMA = 6
BASELINE_SECTION_COUNT = 10


def evidence_registry_sha256(root: Path) -> str:
    """Return the canonical digest for project evidence metadata, including absence."""
    path = root / "project" / "evidence-registry.json"
    if not path.is_file():
        return hashlib.sha256(b"no-evidence-registry\n").hexdigest()
    value = json.loads(path.read_text(encoding="utf-8"))
    canonical = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def project_context_sha256(root: Path, visual_fingerprint: str, brief: Path) -> str:
    """Compute the one Baseline context identity used by gate and initialization."""
    payload = visual_fingerprint + "\n" + hashlib.sha256(brief.read_bytes()).hexdigest()
    payload += "\n" + evidence_registry_sha256(root)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()
