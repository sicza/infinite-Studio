#!/usr/bin/env python3
"""Canonical image-production branch and current-input facts shared by all gates."""
from __future__ import annotations

import json
import re
from pathlib import Path

from request_routing import RoutingError, expected_production_branch

PRODUCTION_BRANCHES = {
    "new-generation",
    "image-edit",
    "video",
    "resize",
    "localization",
    "composite",
    "postprocess-chain",
    "visual-brief-only",
    "prompt-only",
    "prompt-review-only",
}
ARTIFACT_ONLY_BRANCHES = {"visual-brief-only", "prompt-only", "prompt-review-only"}


class ProductionContractError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ProductionContractError(message)


def requirement_lock(request: Path) -> tuple[Path, str]:
    path = request / "work" / "requirement-lock.md"
    require(path.is_file() and path.stat().st_size > 0, "image-production requires work/requirement-lock.md")
    text = path.read_text(encoding="utf-8")
    matches = re.findall(r"(?im)^\s*production_branch:\s*([^\n#]+?)\s*$", text)
    require(len(matches) == 1, "requirement-lock.md requires exactly one production_branch")
    branch = matches[0].strip()
    require(branch in PRODUCTION_BRANCHES, f"invalid production_branch: {branch}")
    request_type = request.parent.name
    try:
        expected = expected_production_branch(request_type)
    except RoutingError as exc:
        raise ProductionContractError(str(exc)) from exc
    require(expected is not None, f"request_type={request_type} is not an image-production route")
    require(branch == expected, f"request_type={request_type} requires production_branch={expected}, got {branch}")
    return path, branch


def production_branch(request: Path) -> str:
    return requirement_lock(request)[1]


def request_input_files(request: Path) -> list[Path]:
    root = request / "input"
    if not root.is_dir():
        return []
    return sorted((p.resolve() for p in root.rglob("*") if p.is_file()), key=lambda p: p.as_posix().casefold())


def workspace_relative(root: Path, path: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def validate_source_lock(root: Path, request: Path) -> dict:
    actual = [workspace_relative(root, p) for p in request_input_files(request)]
    lock = request / "work" / "source-lock.json"
    if not actual:
        require(not lock.exists(), "source-lock.json must not exist when request input/ is empty")
        return {"status": "not_required", "source_count": 0}
    require(lock.is_file(), "non-empty request input/ requires work/source-lock.json")
    try:
        obj = json.loads(lock.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ProductionContractError(f"invalid source-lock.json: {exc}") from exc
    require(isinstance(obj, dict) and set(obj) == {"required_sources"}, "source-lock.json must contain required_sources only")
    values = obj["required_sources"]
    require(isinstance(values, list) and values, "required_sources must be a non-empty array")
    normalized: list[str] = []
    seen: set[str] = set()
    req_input = (request / "input").resolve()
    for index, value in enumerate(values):
        require(isinstance(value, str) and value.strip(), f"required_sources[{index}] must be a path string")
        p = Path(value.strip())
        p = (root / p if not p.is_absolute() else p).resolve()
        require(p == root or root.resolve() in p.parents, f"path escapes Workspace: {value}")
        require(p.is_file(), f"required current-demand source is missing: {value}")
        require(req_input in p.parents, f"current-demand source must resolve inside this request input/: {value}")
        rel = workspace_relative(root, p)
        require(rel not in seen, f"duplicate required source: {rel}")
        seen.add(rel)
        normalized.append(rel)
    require(sorted(normalized) == sorted(actual), f"source-lock must exactly cover current request input files; expected={sorted(actual)}, actual={sorted(normalized)}")
    return {"status": "passed", "required_sources": sorted(normalized), "source_count": len(normalized)}
