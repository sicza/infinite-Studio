#!/usr/bin/env python3
"""Canonical project asset taxonomy.

`project/assets/<category>/...` is the one machine fact that says what a project
asset *is*. Two Runtime consumers depend on it — `workspace_init.py` (material
index / storage role) and `wxian-visual-baselines/scripts/baseline_gate.py`
(deep-analysis source kind) — so the mapping lives here exactly once. A second
implementation of the same mapping is a defect: the two copies drift and a
Baseline that was just published is judged stale by the other side.

`props` is a first-class canonical asset category. A prop picture is project
identity evidence for an *object*: it must never be classified as a character
because its filename happens to contain a character name.
"""
from __future__ import annotations

from pathlib import PurePosixPath
from typing import Any, Iterable

ASSET_ROOT = ("project", "assets")

# Legacy location: props were placed here before the canonical folder existed.
# They are classified as props (never as characters) but are NOT mandatory for deep
# analysis, so recognising them changes no Baseline fingerprint.
LEGACY_PROP_ROOT = ("project", "props")

# The ONE location props may live in. Material outside it is a migration finding, not
# a silent tolerance: see props_location_report().
CANONICAL_PROPS_ROOT = ("project", "assets", "props")

# category directory -> canonical kind used by the Baseline gate
ASSET_CATEGORY_KINDS: dict[str, str] = {
    "characters": "character",
    "props": "prop",
    "logos": "logo",
    "game-screenshots": "game-screenshot",
    "other": "other-asset",
}
ASSET_CATEGORIES: tuple[str, ...] = tuple(ASSET_CATEGORY_KINDS)

# kinds whose canonical sources must all be selected for deep analysis
REQUIRED_SELECTION_KINDS = frozenset({"character", "prop"})

# kinds that outrank filename heuristics: storage ownership is explicit
STORAGE_OWNED_KINDS = frozenset({"character", "prop", "game-screenshot", "logo"})

IDENTITY_AUTHORITY: dict[str, str] = {
    "character": "canonical-character-asset",
    "prop": "canonical-prop-asset",
    "reference": "reference-only",
}

EVIDENCE_DEFAULTS: dict[str, tuple[str, str, str]] = {
    "character": ("canonical-identity", "project canonical asset", "identity only"),
    "prop": ("canonical-identity", "project canonical asset", "object identity only"),
    "game-screenshot": ("gameplay-evidence", "project gameplay capture", "visible gameplay and presentation only"),
    "reference": ("external-reference", "curated visual reference; explicit registry may mark historical output", "visual methods only"),
}


def _lowered(parts: Iterable[str]) -> tuple[str, ...]:
    return tuple(str(part).casefold() for part in parts)


def asset_category(parts: Iterable[str]) -> str | None:
    """Return the canonical category when the path is a project asset directory."""
    lowered = _lowered(parts)
    if len(lowered) < 4 or lowered[:2] != ASSET_ROOT:
        return None
    category = lowered[2]
    return category if category in ASSET_CATEGORY_KINDS else None


def is_legacy_prop(parts: Iterable[str]) -> bool:
    "project/props/** is a recognised prop location (never a character)."
    lowered = _lowered(parts)
    return len(lowered) >= 3 and lowered[:2] == LEGACY_PROP_ROOT


def canonical_kind(parts: Iterable[str]) -> str | None:
    category = asset_category(parts)
    return ASSET_CATEGORY_KINDS[category] if category else None


def canonical_role(parts: Iterable[str]) -> str | None:
    """Reproduce the material-index storage role for a project asset path.

    A legacy props path keeps its real location in the role, so the two locations stay
    distinguishable in the material index and the same prop can live in both without
    producing a duplicate role.
    """
    original = tuple(str(part) for part in parts)
    if is_legacy_prop(original):
        rest = PurePosixPath(*original[2:]).with_suffix("").as_posix()
        return f"asset:legacy-props/{rest}"
    category = asset_category(original)
    if category is None:
        return None
    rest = PurePosixPath(*original[3:]).with_suffix("").as_posix()
    return f"asset:{category}/{rest}"


def is_prop_parts(parts: Iterable[str]) -> bool:
    return asset_category(parts) == "props" or is_legacy_prop(parts)




def identity_authority_for(kind: str) -> str:
    return IDENTITY_AUTHORITY.get(kind, "none")


def evidence_defaults(kind: str) -> tuple[str, str, str]:
    return EVIDENCE_DEFAULTS.get(kind, ("unknown", "unclassified source", "unknown"))



def props_location_report(paths: Iterable[Any]) -> dict[str, Any]:
    """Report props that are not in the canonical `project/assets/props/` location.

    Accepts BOTH a path string and a sequence of segments: the only production call site hands
    over `source_path` strings, and iterating a string by character silently produced an empty
    report, so the shape is normalised here and pinned by a regression leg.
    """
    # Top-level normalisation FIRST: a bare path string is one path, a bare segment tuple is
    # one path, and anything else ambiguous fails loudly. Normalising only per element made a
    # bare string iterate into single characters and silently report "clean".
    if isinstance(paths, str):
        paths = [paths]
    elif isinstance(paths, (list, tuple)) and paths and all(isinstance(part, str) for part in paths):
        if any(chr(47) in part for part in paths):
            # a sequence of path strings
            paths = list(paths)
        elif isinstance(paths, tuple):
            # a single sequence of segments, e.g. (project, props, name.jpg)
            paths = [paths]
        else:
            # a list of slash-less single-segment names: each is its own path. Root-level
            # files carry no migration meaning and must never crash the caller.
            paths = list(paths)

    canonical: list[str] = []
    non_canonical: list[str] = []
    targets: dict[str, str] = {}
    for raw in paths:
        parts = tuple(str(raw).split("/")) if isinstance(raw, str) else tuple(str(part) for part in raw)
        parts = tuple(part for part in parts if part not in ("", "."))
        lowered = tuple(part.lower() for part in parts)
        if len(lowered) >= 3 and lowered[:3] == CANONICAL_PROPS_ROOT:
            canonical.append("/".join(parts))
        elif is_legacy_prop(parts):
            # Only the historical props location counts; `project/assets/other/props/x.png` is
            # an other-asset per the taxonomy and must not be reported as a prop to migrate.
            key = "/".join(parts)
            non_canonical.append(key)
            targets[key] = "/".join(CANONICAL_PROPS_ROOT) + "/" + parts[-1]
    return {
        "canonical_root": "/".join(CANONICAL_PROPS_ROOT),
        "canonical": sorted(canonical),
        "non_canonical": sorted(non_canonical),
        "migration_targets": targets,
        "migration_required": bool(non_canonical),
    }
