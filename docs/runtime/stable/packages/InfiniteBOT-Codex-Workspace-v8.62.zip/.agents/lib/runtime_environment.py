#!/usr/bin/env python3
"""Resolve machine-local runtime tools without hard-coding them into project files."""
from __future__ import annotations

import json
import os
import shutil
from pathlib import Path


def runtime_state_path(workspace_root: Path) -> Path:
    return workspace_root.resolve() / ".agents" / "runtime" / "runtime-status.json"


def _stored_binary(workspace_root: Path, name: str) -> str | None:
    path = runtime_state_path(workspace_root)
    if not path.is_file():
        return None
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    tools = value.get("resolved_tools", {}) if isinstance(value, dict) else {}
    candidate = tools.get(name) if isinstance(tools, dict) else None
    if not isinstance(candidate, str) or not candidate:
        return None
    p = Path(candidate)
    return str(p) if p.is_file() else None


def resolve_binary(workspace_root: Path, name: str) -> str | None:
    """Prefer current PATH, then the last verified machine-local absolute path."""
    current = shutil.which(name)
    if current:
        return current
    return _stored_binary(workspace_root, name)


def runtime_python() -> str:
    return os.path.realpath(os.sys.executable)
