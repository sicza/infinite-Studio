#!/usr/bin/env python3
"""Prepare, refine, and validate auditable video-source evidence for Workspace tasks."""
from __future__ import annotations
import os as _bytecode_guard_os, sys as _bytecode_guard_sys
_bytecode_guard_sys.dont_write_bytecode = True
_bytecode_guard_os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import argparse
import json
import math
import shutil
import subprocess
import sys
from fractions import Fraction
from pathlib import Path
from typing import Any

LIB = Path(__file__).resolve().parents[3] / 'lib'
if str(LIB) not in sys.path:
    sys.path.insert(0, str(LIB))
from runtime_environment import resolve_binary
from video_evidence import (
    VIDEO_EXTENSIONS,
    VideoEvidenceError,
    authorized_video_source,
    bounded,
    relative,
    sha256_file,
    validate_evidence,
    validate_source_manifest,
)


class VideoSourceError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise VideoSourceError(message)


def request_path(root: Path, value: str) -> Path:
    request = bounded(root, value, must_exist=True)
    parts = request.relative_to(root).parts
    require(len(parts) == 3 and parts[0] == 'requests' and request.is_dir(), 'request must be requests/<type>/<name>')
    return request


def parse_fraction(value: str | None) -> float:
    if not value or value in {'0/0', 'N/A'}:
        return 0.0
    try:
        return float(Fraction(value))
    except (ValueError, ZeroDivisionError):
        try:
            return float(value)
        except ValueError:
            return 0.0


def probe_ffmpeg(source: Path) -> dict[str, Any] | None:
    workspace_root = Path(__file__).resolve().parents[4]
    ffprobe = resolve_binary(workspace_root, 'ffprobe')
    if not ffprobe:
        return None
    cp = subprocess.run(
        [ffprobe, '-v', 'error', '-show_streams', '-show_format', '-of', 'json', str(source)],
        capture_output=True, text=True, encoding='utf-8', check=False, timeout=60,
    )
    if cp.returncode != 0:
        return None
    try:
        data = json.loads(cp.stdout)
    except json.JSONDecodeError:
        return None
    streams = data.get('streams', []) if isinstance(data, dict) else []
    video = next((s for s in streams if isinstance(s, dict) and s.get('codec_type') == 'video'), None)
    if not isinstance(video, dict):
        return None
    audio = next((s for s in streams if isinstance(s, dict) and s.get('codec_type') == 'audio'), None)
    fmt = data.get('format', {}) if isinstance(data.get('format'), dict) else {}
    duration_s = 0.0
    for candidate in (video.get('duration'), fmt.get('duration')):
        try:
            duration_s = float(candidate)
            if duration_s > 0:
                break
        except (TypeError, ValueError):
            continue
    fps = parse_fraction(str(video.get('avg_frame_rate') or video.get('r_frame_rate') or ''))
    width = int(video.get('width') or 0)
    height = int(video.get('height') or 0)
    if duration_s <= 0 or fps <= 0 or width <= 0 or height <= 0:
        return None
    return {
        'duration_ms': max(1, int(round(duration_s * 1000))),
        'width': width,
        'height': height,
        'fps': round(fps, 6),
        'frame_count': int(video.get('nb_frames')) if str(video.get('nb_frames', '')).isdigit() else None,
        'video_codec': str(video.get('codec_name') or 'unknown'),
        'audio_codec': str(audio.get('codec_name') or 'unknown') if isinstance(audio, dict) else None,
        'has_audio': isinstance(audio, dict),
        'container': str(fmt.get('format_name') or source.suffix.lower().lstrip('.')),
    }


def probe_opencv(source: Path) -> dict[str, Any] | None:
    try:
        import cv2  # type: ignore
    except Exception:
        return None
    cap = cv2.VideoCapture(str(source))
    if not cap.isOpened():
        return None
    try:
        fps = float(cap.get(cv2.CAP_PROP_FPS) or 0)
        frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0)
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
        duration_ms = int(round((frames / fps) * 1000)) if fps > 0 and frames > 0 else 0
        if fps <= 0 or duration_ms <= 0 or width <= 0 or height <= 0:
            return None
        return {
            'duration_ms': duration_ms,
            'width': width,
            'height': height,
            'fps': round(fps, 6),
            'frame_count': frames,
            'video_codec': 'opencv-decoded',
            'audio_codec': None,
            'has_audio': None,
            'container': source.suffix.lower().lstrip('.'),
        }
    finally:
        cap.release()


def probe(source: Path) -> tuple[str, dict[str, Any]]:
    media = probe_ffmpeg(source)
    if media:
        return 'ffmpeg', media
    media = probe_opencv(source)
    if media:
        return 'opencv', media
    raise VideoSourceError('no usable video decoder: install ffmpeg/ffprobe or OpenCV with video decoding support')


def extract_ffmpeg(source: Path, target: Path, timestamp_ms: int, max_width: int) -> bool:
    workspace_root = Path(__file__).resolve().parents[4]
    ffmpeg = resolve_binary(workspace_root, 'ffmpeg')
    if not ffmpeg:
        return False
    vf = f"scale=w='min({max_width}\\,iw)':h=-2" if max_width > 0 else 'null'
    cp = subprocess.run(
        [ffmpeg, '-v', 'error', '-ss', f'{timestamp_ms / 1000:.3f}', '-i', str(source),
         '-frames:v', '1', '-vf', vf, '-q:v', '2', '-y', str(target)],
        capture_output=True, text=True, encoding='utf-8', check=False, timeout=90,
    )
    return cp.returncode == 0 and target.is_file() and target.stat().st_size > 0


def extract_opencv(source: Path, target: Path, timestamp_ms: int, max_width: int) -> bool:
    try:
        import cv2  # type: ignore
    except Exception:
        return False
    cap = cv2.VideoCapture(str(source))
    if not cap.isOpened():
        return False
    try:
        cap.set(cv2.CAP_PROP_POS_MSEC, float(timestamp_ms))
        ok, frame = cap.read()
        if not ok or frame is None:
            return False
        if max_width > 0 and frame.shape[1] > max_width:
            ratio = max_width / frame.shape[1]
            frame = cv2.resize(frame, (max_width, max(1, int(round(frame.shape[0] * ratio)))), interpolation=cv2.INTER_AREA)
        return bool(cv2.imwrite(str(target), frame, [int(cv2.IMWRITE_JPEG_QUALITY), 95]))
    finally:
        cap.release()


def extract_frame(source: Path, target: Path, timestamp_ms: int, max_width: int, preferred_backend: str) -> str:
    target.parent.mkdir(parents=True, exist_ok=True)
    if preferred_backend == 'ffmpeg' and extract_ffmpeg(source, target, timestamp_ms, max_width):
        return 'ffmpeg'
    if extract_opencv(source, target, timestamp_ms, max_width):
        return 'opencv'
    if preferred_backend != 'ffmpeg' and extract_ffmpeg(source, target, timestamp_ms, max_width):
        return 'ffmpeg'
    raise VideoSourceError(f'failed to extract frame at {timestamp_ms}ms')


def overview_timestamps(duration_ms: int, count: int) -> list[int]:
    require(count >= 2, 'overview frame count must be >= 2')
    end = max(0, duration_ms - min(100, max(1, duration_ms // 100)))
    if duration_ms <= count:
        return sorted(set(range(0, duration_ms + 1)))
    values = [int(round(i * end / (count - 1))) for i in range(count)]
    return sorted(set(max(0, min(end, x)) for x in values))


def range_timestamps(start_ms: int, end_ms: int, count: int) -> list[int]:
    require(0 <= start_ms <= end_ms, 'invalid refine time range')
    require(count >= 2, 'refine frame count must be >= 2')
    if start_ms == end_ms:
        return [start_ms]
    return sorted(set(int(round(start_ms + i * (end_ms - start_ms) / (count - 1))) for i in range(count)))


def analysis_dir(root: Path, request: Path, source: Path) -> Path:
    return request / 'work' / 'video-source-analysis' / f'{source.stem}-{sha256_file(source)[:12]}'


def frame_record(root: Path, path: Path, timestamp_ms: int, kind: str) -> dict[str, Any]:
    return {'path': relative(root, path), 'sha256': sha256_file(path), 'timestamp_ms': int(timestamp_ms), 'kind': kind}


def write_manifest(path: Path, value: dict[str, Any]) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def prepare(root: Path, request: Path, source: Path, count: int, max_width: int, force: bool) -> dict[str, Any]:
    require(source.is_file() and source.suffix.lower() in VIDEO_EXTENSIONS, 'source is not a supported video')
    require(authorized_video_source(root, request, source), 'video source must be current request input or current indexed project material')
    directory = analysis_dir(root, request, source)
    if directory.exists() and force:
        shutil.rmtree(directory)
    manifest_path = directory / 'source-manifest.json'
    if manifest_path.is_file() and not force:
        manifest = validate_source_manifest(root, request, directory)
        return {'status': 'ready', 'analysis_dir': relative(root, directory), 'manifest': manifest, 'reused': True}
    directory.mkdir(parents=True, exist_ok=True)
    backend, media = probe(source)
    frames_dir = directory / 'frames'
    records = []
    used_backend = backend
    backends = set()
    for index, ts in enumerate(overview_timestamps(int(media['duration_ms']), count), 1):
        target = frames_dir / f'overview-{index:03d}-{ts:09d}ms.jpg'
        used_backend = extract_frame(source, target, ts, max_width, used_backend)
        backends.add(used_backend)
        records.append(frame_record(root, target, ts, 'overview'))
    manifest = {
        'schema_version': 1,
        'source_path': relative(root, source),
        'source_sha256': sha256_file(source),
        'backend': ('mixed' if len(backends) > 1 else next(iter(backends))),
        'media': media,
        'frames': records,
    }
    write_manifest(manifest_path, manifest)
    return {'status': 'ready', 'analysis_dir': relative(root, directory), 'manifest': manifest, 'reused': False}


def refine(root: Path, request: Path, source: Path, start_ms: int, end_ms: int, count: int, max_width: int) -> dict[str, Any]:
    directory = analysis_dir(root, request, source)
    manifest = validate_source_manifest(root, request, directory)
    require(str(manifest['source_path']) == relative(root, source), 'analysis directory is not bound to this source')
    require(int(end_ms) <= int(manifest['media']['duration_ms']), 'refine end exceeds video duration')
    existing = {(int(item['timestamp_ms']), str(item['kind'])) for item in manifest['frames']}
    records = list(manifest['frames'])
    existing_backend = str(manifest.get('backend') or 'ffmpeg')
    used_backend = 'ffmpeg' if existing_backend == 'mixed' else existing_backend
    backends = set() if existing_backend == 'mixed' else {existing_backend}
    refine_dir = directory / 'frames'
    added = []
    for ts in range_timestamps(start_ms, end_ms, count):
        if (ts, 'refine') in existing:
            continue
        index = 1 + sum(1 for item in records if item.get('kind') == 'refine')
        target = refine_dir / f'refine-{index:03d}-{ts:09d}ms.jpg'
        used_backend = extract_frame(source, target, ts, max_width, used_backend)
        backends.add(used_backend)
        rec = frame_record(root, target, ts, 'refine')
        records.append(rec); added.append(rec); existing.add((ts, 'refine'))
    records.sort(key=lambda item: (int(item['timestamp_ms']), str(item['kind']), str(item['path'])))
    manifest['backend'] = ('mixed' if len(backends) > 1 else next(iter(backends)))
    manifest['frames'] = records
    write_manifest(directory / 'source-manifest.json', manifest)
    return {'status': 'ready', 'analysis_dir': relative(root, directory), 'added_frames': added, 'frame_count': len(records)}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest='cmd', required=True)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument('--request', required=True)
    common.add_argument('--workspace-root', type=Path, default=Path(__file__).resolve().parents[4])
    common.add_argument('--source', required=True)

    p = sub.add_parser('prepare', parents=[common])
    p.add_argument('--overview-frames', type=int, default=12)
    p.add_argument('--max-width', type=int, default=1600)
    p.add_argument('--force', action='store_true')

    r = sub.add_parser('refine', parents=[common])
    r.add_argument('--start-ms', type=int, required=True)
    r.add_argument('--end-ms', type=int, required=True)
    r.add_argument('--frames', type=int, default=8)
    r.add_argument('--max-width', type=int, default=1600)

    v = sub.add_parser('validate', parents=[common])

    args = ap.parse_args()
    try:
        root = args.workspace_root.resolve()
        request = request_path(root, args.request)
        source = bounded(root, args.source, must_exist=True)
        if args.cmd == 'prepare':
            result = prepare(root, request, source, args.overview_frames, args.max_width, args.force)
        elif args.cmd == 'refine':
            result = refine(root, request, source, args.start_ms, args.end_ms, args.frames, args.max_width)
        else:
            directory = analysis_dir(root, request, source)
            result = validate_evidence(root, request, directory)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (VideoSourceError, VideoEvidenceError, OSError, ValueError, subprocess.SubprocessError) as exc:
        print(json.dumps({'status': 'blocked', 'reason': str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == '__main__':
    sys.exit(main())
