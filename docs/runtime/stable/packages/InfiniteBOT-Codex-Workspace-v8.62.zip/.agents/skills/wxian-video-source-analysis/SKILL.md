---
name: wxian-video-source-analysis
description: 统一视频输入分析能力。把 Gameplay 录屏、竞品广告/PV、游戏宣传片、实拍或其他真实视频转换成可审计的时间线事实、关键帧、Gameplay/UI/镜头/叙事观察和受证据约束的推断。既可作为独立视频分析需求，也可在 wxian-image-production、wxian-visual-competitive-analysis、wxian-visual-reverse-analysis、sicza-game-concept-lab 等当前 request 内作为辅助能力；不负责生成视频。
---

# 视频输入分析

本 Skill 作为当前 request 的 Primary 时，进入前执行 `$workspace-governance consume-personal-context --request <request> --consumer wxian-video-source-analysis`；阻断则停止。作为图片生产、竞品分析、视觉逆向或游戏概念等 Primary 的辅助能力时，继承调用方已验证的 Primary Context，不以自身名再次消费，也不冒充第二 Primary。

本 Skill 只回答一件事：**真实视频里实际发生了什么，以及哪些结论能由哪些时间点/帧证明。**

原视频是事实源；抽出的帧是可视化证据；`evidence.json` 是机器可验证的事实链。不得把模型推断、用户未确认机制或看不见的操作输入写成视频事实。

## 1. 使用边界

- 用户直接说“分析这个视频 / 看看这个 Gameplay / 拆这个广告/PV” → `request_type=video-source-analysis`，本 Skill 为 primary。
- 图片生产拿视频作为玩法、动作、镜头、竞品或视觉证据 → 在**当前图片 request** 内调用本 Skill，不创建第二 request。
- 竞品分析、单图/视觉反推、游戏概念实验需要理解用户给的视频 → 在当前 primary request 内调用本 Skill。
- “给我生成/编辑一个视频文件”仍属于 `$wxian-image-production` 的 `video` branch，本 Skill 不取代 Seedance 生产。

## 2. 先建立真实视频证据

对每个视频先运行：

```bash
python .agents/skills/wxian-video-source-analysis/scripts/video_source.py prepare \
  --request <request> --source <video-path> --workspace-root .
```

脚本必须完成：

- 验证视频来自当前 request `input/` 或当前 `material-index`；
- 绑定 `source_path + source_sha256`；
- 读取 duration / resolution / fps / codec / audio presence；
- 抽取均匀 Overview Frames；
- 写 `work/video-source-analysis/<source-id>/source-manifest.json`。

若运行环境没有可用 `ffmpeg/ffprobe` 且 OpenCV 也无法解码，明确 BLOCK；禁止假装已经“看过视频”。

## 3. 分层看视频，不靠几张随机截图脑补

### Overview Pass

先看完整 Overview Frames，定位：

- 场景/阶段切换；
- 主要角色、对象和 UI 状态；
- Gameplay 行为发生的区间；
- 关键视觉、镜头、叙事变化；
- 需要二次放大的时间段。

### Event Refinement

对动作快、UI 状态变化、因果链不清或决定性瞬间附近的区间继续抽帧：

```bash
python .agents/skills/wxian-video-source-analysis/scripts/video_source.py refine \
  --request <request> --source <video-path> \
  --start-ms <start> --end-ms <end> --frames 8 --workspace-root .
```

直到关键结论能够被时间区间 + 至少一张真实帧支持。长视频按段分层分析，不一次抽数百帧污染上下文。

## 4. 事实、推断严格分开

### Observation

只写直接可观察内容，例如：

- `gameplay_action`：角色挥动镐子击打矿石节点；
- `gameplay_visible_result`：矿石破碎后掉落蓝色资源并进入背包计数；
- `ui_feedback`：右上资源数量从 24 增加到 27；
- `camera`：第三人称跟随镜头在冲刺时向后拉开；
- `scene_event`：爆炸后桥面坍塌并打开新的移动路径。

不要把“玩家按下 X”“这是 Roguelike”“这个功能每天只能用一次”写成事实，除非视频本身有足够可见/可听证据。

### Inference

需要解释时单独写推断，并引用 Observation ID：

- 机制推断；
- 玩法循环；
- 用户目标；
- 叙事关系；
- 广告意图；
- 镜头为什么这样设计。

每条标 `high | medium | low`。无法证实则保持 Unknown。

## 5. `evidence.json`

每个视频分析目录必须写：

```json
{
  "schema_version": 1,
  "source_path": "requests/.../input/gameplay.mp4",
  "source_sha256": "...",
  "observations": [
    {
      "id": "obs-001",
      "type": "gameplay_action",
      "fact": "角色挥动镐子击打矿石节点",
      "start_ms": 8200,
      "end_ms": 9400,
      "frame_paths": ["requests/.../work/video-source-analysis/.../frames/refine-001-000008600ms.jpg"]
    }
  ],
  "inferences": [
    {
      "id": "inf-001",
      "claim": "采集资源可能是当前循环中的基础资源获取环节",
      "confidence": "medium",
      "supported_by": ["obs-001", "obs-002"]
    }
  ],
  "representative_frames": ["requests/.../work/video-source-analysis/.../frames/refine-001-000008600ms.jpg"]
}
```

同时写 `video-analysis.md`，第一部分必须绑定真实 `source_path / source_sha256`；正文按任务只保留有用内容，并引用代表帧真实路径。

完成后运行：

```bash
python .agents/skills/wxian-video-source-analysis/scripts/video_source.py validate \
  --request <request> --source <video-path> --workspace-root .
```

未通过不得把视频分析升级为下游 Production Truth。

## 6. Gameplay 视频专项

至少判断：

`可见玩家/角色行为 → 交互对象 → 可见反馈 → 可见结果 → 下一状态`

能看到重复循环时再归纳 Gameplay Loop；只看到一次事件不得硬写完整核心循环。

商店玩法图需要从 `evidence.json` 中选择真实 `gameplay_action` 与 `gameplay_visible_result`，再选一张代表性关键帧进入图片 `reference-plan.json`。**原视频继续作为 gameplay truth source，关键帧才是图片模型可上传的 gameplay Reference。**

## 7. 广告 / PV / 竞品视频专项

按任务提取：

- Hook 出现时间；
- 产品/角色/世界/Gameplay 谁承担主要信息；
- 镜头与剪辑节奏；
- UI、标题、CTA、品牌元素何时出现；
- 画面如何证明卖点；
- 哪些只是广告演绎，哪些能证明真实 Gameplay；
- 可迁移视觉机制与不可迁移 IP/品牌外壳。

广告演绎不得自动升级成真实游戏机制。

## 8. 独立用户需求交付

当 `primary_skill=wxian-video-source-analysis`：

1. 每个视频先完成并验证自己的 `source-manifest.json + evidence.json + video-analysis.md`；
2. 最终汇总写 `work/final/video-source-analysis.md`，必须保留每个 source 的 Hash、关键时间点、代表帧、Observation 与 Inference 边界；
3. `work/final-review.md` 核对源绑定、时间线、代表帧、事实/推断、未知项和是否存在无证据机制结论；
4. `work/delivery-manifest.json` 至少列 `work/final/video-source-analysis.md` 为 active，推荐 role=`video_source_analysis`；
5. 由 `$workspace-governance promote` 发布。

## 9. 快速自查

| 检查项 | 通过标准 | 失败处理 |
|---|---|---|
| 源绑定 | 视频路径与 SHA256 真实一致 | 重建 manifest |
| 完整观看 | 先 Overview，再对关键区间 refine | 不用随机单帧代表整段 |
| 时间证据 | 每条 Observation 有合法时间范围 | 无时间证据不写事实 |
| 帧证据 | 每条 Observation 引用真实抽帧 | 继续抽帧 |
| 事实/推断 | Observation 与 Inference 分离 | 改写，未知保留 Unknown |
| Gameplay 因果 | 行为/对象/反馈/结果可见 | 不凭题材猜玩法 |
| 广告真实性 | 广告演绎不冒充真实 Gameplay | 降级为演绎证据 |
| 下游图片 | 原视频=truth；关键帧=image reference | 不把整个视频冒充图片 Reference |
| 运行能力 | decoder 可用且脚本成功 | 无解码能力直接 BLOCK |
