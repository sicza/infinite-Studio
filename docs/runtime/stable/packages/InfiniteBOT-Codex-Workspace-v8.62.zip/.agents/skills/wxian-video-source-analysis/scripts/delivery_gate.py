#!/usr/bin/env python3
"""Hard delivery gate for standalone wxian-video-source-analysis requests."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

LIB = Path(__file__).resolve().parents[3] / 'lib'
if str(LIB) not in sys.path:
    sys.path.insert(0, str(LIB))
from video_evidence import VideoEvidenceError, relative, validate_evidence


class DeliveryError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise DeliveryError(message)


def bounded(root: Path, value: str | Path, *, exist: bool = False) -> Path:
    p = Path(value)
    p = (root / p if not p.is_absolute() else p).resolve()
    root = root.resolve()
    require(p == root or root in p.parents, 'path escapes Workspace')
    if exist:
        require(p.exists(), f'path does not exist: {value}')
    return p


def validate(root: Path, request: Path) -> dict:
    state_path = request / 'state.json'
    require(state_path.is_file(), 'state.json missing')
    state = json.loads(state_path.read_text(encoding='utf-8'))
    require(state.get('primary_skill') == 'wxian-video-source-analysis', 'delivery gate only applies to wxian-video-source-analysis')

    base = request / 'work' / 'video-source-analysis'
    require(base.is_dir(), 'work/video-source-analysis/ is required')
    analysis_dirs = sorted({p.parent for p in base.glob('*/source-manifest.json')})
    require(analysis_dirs, 'at least one prepared video analysis is required')

    final = request / 'work' / 'final' / 'video-source-analysis.md'
    require(final.is_file() and final.read_text(encoding='utf-8').strip(), 'work/final/video-source-analysis.md is required')
    final_text = final.read_text(encoding='utf-8')

    validated = []
    for directory in analysis_dirs:
        try:
            result = validate_evidence(root, request, directory)
        except Exception as exc:
            raise DeliveryError(f'video analysis evidence invalid: {relative(root,directory)}: {exc}') from exc
        require(str(result['source_path']) in final_text, f'final analysis missing source_path: {result["source_path"]}')
        require(str(result['source_sha256']) in final_text, f'final analysis missing source_sha256: {result["source_path"]}')
        require(any(frame in final_text for frame in result['representative_frames']),
                f'final analysis must cite a representative frame: {result["source_path"]}')
        validated.append(result)

    manifest_path = request / 'work' / 'delivery-manifest.json'
    require(manifest_path.is_file(), 'work/delivery-manifest.json is required')
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    files = manifest.get('files', []) if isinstance(manifest, dict) else []
    active = [item for item in files if isinstance(item, dict) and item.get('active') is True]
    target_rel = relative(root, final)
    require(any(item.get('role') == 'video_source_analysis' and item.get('source') == target_rel for item in active),
            'delivery manifest must actively deliver work/final/video-source-analysis.md with role=video_source_analysis')

    return {
        'status': 'passed',
        'source_count': len(validated),
        'sources': [item['source_path'] for item in validated],
        'final': target_rel,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--request', required=True)
    ap.add_argument('--workspace-root', type=Path, default=Path(__file__).resolve().parents[4])
    args = ap.parse_args()
    try:
        root = args.workspace_root.resolve()
        request = bounded(root, args.request, exist=True)
        require(request.is_dir(), 'request directory missing')
        print(json.dumps(validate(root, request), ensure_ascii=False, indent=2))
        return 0
    except (DeliveryError, VideoEvidenceError, OSError, ValueError, json.JSONDecodeError) as exc:
        print(json.dumps({'status': 'blocked', 'reason': str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == '__main__':
    sys.exit(main())
