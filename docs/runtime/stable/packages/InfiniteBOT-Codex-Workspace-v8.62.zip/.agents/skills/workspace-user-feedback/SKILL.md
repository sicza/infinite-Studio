---
name: workspace-user-feedback
description: 为每次真实 promoted 交付按 request + revision 登记反馈，记录用户明确评分、低分改进信息、长期偏好和高分案例；评分不阻塞完成。
---

# User Feedback

用户交付由 `$workspace-governance promote` 成功后自动执行 `register-delivery`，以 `request + revision` 为唯一反馈对象并登记为 `unrated`。

如果用户已经收到文件但 Promote 尚未完成，`rate` 不得伪造 `output/manifest.json` 或 promoted revision，也不得丢弃评分。它会把评分写入 `user/feedback-pending.jsonl`，状态为 `pending_delivery`；之后同一 `request + revision` Promote 成功时，`register-delivery` 自动对账到正式历史、评分和高分案例。若 request 已进入新 revision，旧 pending 事件不会静默绑定到新成品。

```text
user/preferences.md        长期稳定偏好/禁忌，带 scope 与用户证据
user/demand-history.md     每个真实交付 revision 的轻量索引与评分状态
user/high-score-demands.md 用户明确 4-5 分案例索引
user/ratings.md            用户明确评分及低分原因/改进
```

## 评分

成品已经实际交给用户后，询问一次 1–5 分。用户不评分时保持 `unrated`，不得补默认分，不阻塞新需求或返修。

```bash
python .agents/skills/workspace-user-feedback/scripts/user_feedback.py rate \
  --request <request> --score <1..5> --workspace-root .
```

返回 `status=pending_delivery` 表示评分已持久化但尚未绑定正式交付；这不是评分失败，也不改变 request 状态。返回 `status=recorded` 才表示评分已绑定 promoted revision。

默认评分当前最后 promoted revision；需要指定旧 revision 时加 `--revision <N>`。

1–3 分记录用户明确给出的 `reason` 与 `improvement`；缺项返回 `followup_needed`，只补问缺失项，不得由 Agent 代填。4–5 分自动进入 `high-score-demands.md`。同一 request 的不同 revision 独立登记和评分。

## 长期偏好

只有用户明确、长期稳定且可复用的偏好才写入：

```bash
python .agents/skills/workspace-user-feedback/scripts/user_feedback.py remember-preference \
  --text '<用户原意>' --scope <global|image-production|visual-packaging|reverse-analysis|scorecard|delivery> --workspace-root .
```

相关任务只读取 `global + 当前 scope`：

```bash
python .agents/skills/workspace-user-feedback/scripts/user_feedback.py get-preferences \
  --scope <scope> --workspace-root .
```

当前用户要求始终覆盖历史偏好；一次性要求不写入长期偏好。

## Personal Skill 候选

当用户的反馈已经形成跨项目可复用的明确方法，而不是单次项目事实或单次成品修改时，调用 `$workspace-personal-skill` 把方法整理到 `user/candidates/<name>/SKILL.md`。候选 Skill 完成后使用 Codex 原生问卷只确认一次加载范围：先选 `全局` 或 `指定需求类型`；选择后者时，再从 `$workspace-personal-skill list-request-types` 返回的当前真实业务类型中多选一个或多个。问卷结果直接作为 registry 的机器事实，不再二次确认。

用户确认后由 `$workspace-personal-skill promote-candidate` 写入 `user/skills/` 并登记 `user/manifest.json`。项目角色、品牌资产、项目禁用元素和单次需求细节继续留在 `project/` 或 request，不进入 Personal Skill。
