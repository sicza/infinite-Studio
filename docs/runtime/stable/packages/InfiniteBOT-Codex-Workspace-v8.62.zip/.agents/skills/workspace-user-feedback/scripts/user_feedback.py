#!/usr/bin/env python3
"""Post-delivery feedback store. Feedback never gates request completion."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

FILES = {
    "preferences.md": "# Preferences\n\n",
    "demand-history.md": "# Demand History\n\n",
    "high-score-demands.md": "# High Score Demands\n\n",
    "ratings.md": "# Ratings\n\n",
    "feedback-pending.jsonl": "",
}


class FeedbackError(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise FeedbackError(message)


def bounded(root: Path, value: str | Path, exist: bool = False) -> Path:
    path = Path(value)
    path = (root / path if not path.is_absolute() else path).resolve()
    require(path == root or root in path.parents, f"path escapes Workspace: {value}")
    if exist:
        require(path.exists(), f"path does not exist: {value}")
    return path


def request_path(root: Path, value: str) -> Path:
    path = bounded(root, value, True)
    parts = path.relative_to(root).parts
    require(len(parts) == 3 and parts[0] == "requests" and path.is_dir(),
            "request must be requests/<type>/<name>")
    return path


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_json(path: Path) -> dict:
    require(path.is_file(), f"JSON file missing: {path}")
    value = json.loads(path.read_text(encoding="utf-8"))
    require(isinstance(value, dict), f"invalid JSON object: {path}")
    return value


def user_root(root: Path) -> Path:
    user = root / "user"
    legacy = root / "USER"
    if legacy.exists() and not user.exists():
        legacy.rename(user)
    return user


def init_store(root: Path):
    user = user_root(root)
    user.mkdir(parents=True, exist_ok=True)
    for name, head in FILES.items():
        path = user / name
        if not path.exists():
            path.write_text(head, encoding="utf-8")
    return {"status": "ready", "files": sorted(FILES)}


def append_unique(path: Path, marker: str, block: str) -> bool:
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    if marker in text:
        return False
    with path.open("a", encoding="utf-8") as handle:
        handle.write(block.rstrip() + "\n\n")
    return True


def delivery_snapshot(req: Path) -> tuple[dict, dict, int, Path]:
    state = load_json(req / "state.json")
    manifest_path = req / "output" / "manifest.json"
    manifest = load_json(manifest_path)
    revision = manifest.get("active_revision")
    require(isinstance(revision, int) and revision >= 1, "output manifest active_revision is invalid")
    require(state.get("status") == "completed", "feedback registration requires a completed user delivery")
    require(state.get("revision") == revision, "request state and promoted revision do not match")
    files = manifest.get("files")
    require(isinstance(files, list) and files, "output manifest has no delivered files")
    return state, manifest, revision, manifest_path


def delivery_marker(rel: str, revision: int) -> str:
    return f"request: `{rel}` | revision: {revision}"


def register(root: Path, value: str):
    init_store(root)
    req = request_path(root, value)
    _, _, revision, manifest_path = delivery_snapshot(req)
    rel = req.relative_to(root).as_posix()
    marker = delivery_marker(rel, revision)
    block = (
        f"- {marker}\n"
        f"  manifest: `{manifest_path.relative_to(root).as_posix()}`\n"
        f"  manifest_sha256: `{sha256_file(manifest_path)}`\n"
        "  rating: unrated"
    )
    added = append_unique(user_root(root) / "demand-history.md", marker, block)
    reconciled = reconcile_pending(root, rel, revision)
    rating = history_rating(root, rel, revision) or "unrated"
    return {"status": "ready", "registered": added, "request": rel,
            "revision": revision, "rating": rating, "reconciled": reconciled}


def history_has_delivery(root: Path, rel: str, revision: int) -> bool:
    text = (user_root(root) / "demand-history.md").read_text(encoding="utf-8")
    return delivery_marker(rel, revision) in text


def history_rating(root: Path, rel: str, revision: int) -> int | None:
    path = user_root(root) / "demand-history.md"
    if not path.is_file():
        return None
    lines = path.read_text(encoding="utf-8").splitlines()
    header = f"- {delivery_marker(rel, revision)}"
    start = next((index for index, line in enumerate(lines) if line == header), None)
    if start is None:
        return None
    for line in lines[start + 1:]:
        if line.startswith("- request: "):
            break
        if line.strip().startswith("rating:"):
            value = line.split(":", 1)[1].strip()
            return int(value) if value.isdigit() else None
    return None


def update_history_rating(root: Path, rel: str, revision: int, score: int) -> None:
    path = user_root(root) / "demand-history.md"
    lines = path.read_text(encoding="utf-8").splitlines()
    header = f"- {delivery_marker(rel, revision)}"
    start = next((index for index, line in enumerate(lines) if line == header), None)
    require(start is not None, "delivery is not registered in demand-history")
    end = len(lines)
    for index in range(start + 1, len(lines)):
        if lines[index].startswith("- request: "):
            end = index
            break
    rating_index = next((index for index in range(start + 1, end)
                         if lines[index].strip().startswith("rating:")), None)
    require(rating_index is not None, "demand-history delivery block has no rating field")
    lines[rating_index] = f"  rating: {score}"
    path.write_text("\n".join(lines).rstrip() + "\n\n", encoding="utf-8")


def pending_path(root: Path) -> Path:
    return user_root(root) / "feedback-pending.jsonl"


def load_pending(root: Path) -> list[dict]:
    path = pending_path(root)
    if not path.is_file():
        return []
    events = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        event = json.loads(line)
        require(isinstance(event, dict), "pending feedback event must be an object")
        events.append(event)
    return events


def save_pending(root: Path, events: list[dict]) -> None:
    path = pending_path(root)
    path.write_text("".join(json.dumps(event, ensure_ascii=False, sort_keys=True) + "\n" for event in events), encoding="utf-8")


def pending_event(root: Path, rel: str, revision: int) -> dict | None:
    return next((event for event in load_pending(root)
                 if event.get("request") == rel and event.get("revision") == revision
                 and event.get("status") == "pending"), None)


def record_pending(root: Path, rel: str, revision: int, score: int,
                   reason: str, improvement: str) -> bool:
    events = load_pending(root)
    for event in events:
        if event.get("request") != rel or event.get("revision") != revision:
            continue
        if event.get("status") == "pending":
            require(event.get("score") == score, "pending feedback already exists with a different score")
            old_reason = str(event.get("reason", "")).strip()
            old_improvement = str(event.get("improvement", "")).strip()
            require((not old_reason or not reason or old_reason == reason) and
                    (not old_improvement or not improvement or old_improvement == improvement),
                    "pending feedback already exists with different details")
            if reason and not old_reason:
                event["reason"] = reason
            if improvement and not old_improvement:
                event["improvement"] = improvement
            save_pending(root, events)
            return bool(reason and not old_reason or improvement and not old_improvement)
    events.append({"schema": 1, "request": rel, "revision": revision, "score": score,
                   "reason": reason, "improvement": improvement, "status": "pending"})
    save_pending(root, events)
    return True


def apply_rating(root: Path, rel: str, revision: int, score: int,
                 reason: str, improvement: str) -> None:
    ratings = user_root(root) / "ratings.md"
    prefix = f"- request: `{rel}` | revision: {revision} | score: "
    lines = ratings.read_text(encoding="utf-8").splitlines()
    existing_index = next((index for index, line in enumerate(lines) if line.startswith(prefix)), None)
    detail = f"- request: `{rel}` | revision: {revision} | score: {score}"
    if reason:
        detail += f" | reason: {reason}"
    if improvement:
        detail += f" | improvement: {improvement}"
    if existing_index is None:
        lines.append(detail)
    else:
        previous = lines[existing_index]
        previous_score = int(previous.split("| score: ", 1)[1].split(" |", 1)[0])
        require(previous_score == score,
                "rating already exists with a different score; preserve the explicit rating unless the user explicitly corrects it")
        if reason or improvement:
            lines[existing_index] = detail
    ratings.write_text("\n".join(lines).rstrip() + "\n", encoding="utf-8")
    update_history_rating(root, rel, revision, score)
    if score >= 4:
        marker = delivery_marker(rel, revision)
        append_unique(user_root(root) / "high-score-demands.md", marker,
                      f"- {marker} | score: {score}")


def reconcile_pending(root: Path, rel: str, revision: int) -> int:
    events = load_pending(root)
    count = 0
    changed = False
    for event in events:
        if event.get("request") != rel or event.get("revision") != revision or event.get("status") != "pending":
            continue
        reason = str(event.get("reason", "")).strip()
        improvement = str(event.get("improvement", "")).strip()
        if int(event.get("score", 0)) <= 3 and (not reason or not improvement):
            continue
        apply_rating(root, rel, revision, int(event["score"]), reason, improvement)
        event["status"] = "reconciled"
        count += 1
        changed = True
    if changed:
        save_pending(root, events)
    return count


def resolve_rating_revision(root: Path, req: Path, requested: int | None) -> int:
    if requested is not None:
        require(requested >= 1, "revision must be >= 1")
        return requested
    manifest_path = req / "output" / "manifest.json"
    if manifest_path.is_file():
        manifest = load_json(manifest_path)
        revision = manifest.get("active_revision")
    else:
        state = load_json(req / "state.json")
        revision = state.get("revision")
    require(isinstance(revision, int) and revision >= 1, "output manifest active_revision is invalid")
    return revision


def rate(root: Path, value: str, score: int, reason: str | None = None,
         improvement: str | None = None, revision: int | None = None):
    require(1 <= score <= 5, "score must be 1-5")
    init_store(root)
    req = request_path(root, value)
    rel = req.relative_to(root).as_posix()
    revision = resolve_rating_revision(root, req, revision)
    reason = (reason or "").strip()
    improvement = (improvement or "").strip()
    require(score <= 3 or not (reason or improvement),
            "reason/improvement are only stored for explicit low-score feedback")

    if history_has_delivery(root, rel, revision):
        apply_rating(root, rel, revision, score, reason, improvement)
        pending_status = "recorded"
    else:
        manifest = req / "output" / "manifest.json"
        if manifest.is_file():
            manifest_data = load_json(manifest)
            require(manifest_data.get("active_revision") == revision,
                    "requested revision is not the active promoted revision")
            register(root, value)
            apply_rating(root, rel, revision, score, reason, improvement)
            pending_status = "recorded"
        else:
            state = load_json(req / "state.json")
            require(state.get("status") in {"active", "blocked"},
                    "feedback without output/manifest.json requires an active or blocked request")
            require(state.get("revision") == revision, "pending feedback revision does not match request state")
            recorded = record_pending(root, rel, revision, score, reason, improvement)
            pending_status = "pending_delivery"
    pending = pending_event(root, rel, revision) if pending_status == "pending_delivery" else None
    effective_reason = str(pending.get("reason", "")).strip() if pending else reason
    effective_improvement = str(pending.get("improvement", "")).strip() if pending else improvement
    followup_needed = score <= 3 and (not effective_reason or not effective_improvement)
    return {
        "status": pending_status,
        "request": rel,
        "revision": revision,
        "score": score,
        "high_score": score >= 4,
        "reconciled_on_promote": pending_status == "pending_delivery",
        "recorded": recorded if pending_status == "pending_delivery" else True,
        "followup_needed": followup_needed,
        "missing_low_score_detail": [
            name for name, value in (("reason", effective_reason), ("improvement", effective_improvement))
            if score <= 3 and not value
        ],
    }


def remember_preference(root: Path, text: str, scope: str, evidence_request: str | None):
    init_store(root)
    text = text.strip()
    scope = scope.strip()
    require(text, "preference text is required")
    require(scope in {"global", "image-production", "visual-packaging", "reverse-analysis", "scorecard", "delivery"},
            "invalid preference scope")
    evidence = "user-current-message"
    if evidence_request:
        req = request_path(root, evidence_request)
        evidence = req.relative_to(root).as_posix()
    marker = f"scope: {scope} | preference: {text}"
    block = f"- {marker} | evidence: `{evidence}`"
    added = append_unique(user_root(root) / "preferences.md", marker, block)
    return {"status": "ready", "stored": added, "scope": scope, "preference": text}


def get_preferences(root: Path, scope: str):
    init_store(root)
    require(scope in {"global", "image-production", "visual-packaging", "reverse-analysis", "scorecard", "delivery"},
            "invalid preference scope")
    lines = []
    for line in (user_root(root) / "preferences.md").read_text(encoding="utf-8").splitlines():
        stripped = line.strip()
        if not stripped.startswith("- scope: "):
            continue
        if stripped.startswith("- scope: global |") or stripped.startswith(f"- scope: {scope} |"):
            lines.append(stripped[2:])
    return {"status": "ready", "scope": scope, "preferences": lines}


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)
    for name in ("init-store", "register-delivery", "rate", "remember-preference", "get-preferences"):
        command = sub.add_parser(name)
        command.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])
        if name in {"register-delivery", "rate"}:
            command.add_argument("--request", required=True)
        if name == "rate":
            command.add_argument("--score", type=int, required=True)
            command.add_argument("--revision", type=int)
            command.add_argument("--reason")
            command.add_argument("--improvement")
        if name == "remember-preference":
            command.add_argument("--text", required=True)
            command.add_argument("--scope", default="global")
            command.add_argument("--evidence-request")
        if name == "get-preferences":
            command.add_argument("--scope", required=True)
    args = parser.parse_args()
    root = args.workspace_root.resolve()
    try:
        if args.cmd == "init-store":
            result = init_store(root)
        elif args.cmd == "register-delivery":
            result = register(root, args.request)
        elif args.cmd == "rate":
            result = rate(root, args.request, args.score, args.reason, args.improvement, args.revision)
        elif args.cmd == "remember-preference":
            result = remember_preference(root, args.text, args.scope, args.evidence_request)
        else:
            result = get_preferences(root, args.scope)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (FeedbackError, OSError, json.JSONDecodeError, ValueError) as exc:
        print(json.dumps({"status": "blocked", "reason": str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    sys.exit(main())
