---
name: workspace-demand-intake
description: 当前 Project Workspace 的统一新需求接收入口：识别需求类型，复用当前消息、附件、Project Brief/Baseline 中已知事实，只补真正阻塞的最小字段，再创建 request 并路由到唯一 primary Skill。用于“我有一个XX需求/新建需求/帮我做XX”等新目标；不处理当前需求续接、返修、交付或初始化。
---

# Workspace Demand Intake

**Intake 只锁原始需求事实，不替专业 Skill 做需求改写、创意设计、Prompt 或成品判断。**

## 1. 先判断是不是新需求

只有新目标进入本 Skill。以下直接交 `$workspace-governance` 续接原 request：

- “继续刚才 / 按上一版改 / 这张再改一下 / 补一张素材” → `resolve-request` 或 supplement；
- “上一张 / 刚交付的 / 返修刚才成品” → `resolve-latest` + 必要时 `revise-request`；
- Workspace 初始化 / Baseline 内部刷新 → 按 `AGENTS.md` 初始化链，不弹业务 Intake。

## 2. 从现有上下文先填，不重复问

按以下顺序解析：

1. 当前用户消息；
2. 当前消息附件及用户给出的“图1/图2/视频用途”；
3. `project/project-brief.md` 可直接确定的项目名称与项目事实；
4. 当前正式 Baseline 能确定的 canonical 角色/品牌身份；
5. 当前需求类型的默认值。

不得询问能够从以上来源可靠获得的信息，也不得让用户填写后续专业 Skill 本应决定的构图、镜头、创意方向、Prompt、评分项或制作步骤。

## 3. 公共 Intake 字段

用户最多需要提供这一层信息：

```text
【项目名称】：
【需求名称】：
【需求类型】：
【具体要求】：
【尺寸】：
【文案】：
【素材】：
```

字段语义：

- `项目名称`：当前单项目 Workspace 已知时自动带入；只有无法确定或用户明确跨项目时才问。
- `需求名称`：可空；Intake 根据需求类型 + 核心主题生成简短工作名。
- `需求类型`：用户没写但语义唯一时自动归一；存在两个会走不同专业链的合理解释时才问。
- `具体要求`：用户给出的主题、目标、范围和硬要求；这是任务边界，不要求用户写完整创作方案。
- `尺寸`：按需求类型解释；不能统一强制。普通新生图缺失默认 `1:1`。
- `文案`：普通视觉任务可空；**未填/空白 = 本次不需要营销文案**，不得追问。只有本地化、换文案等任务本身依赖文字时才成为必需字段。
- `素材`：普通从零任务可空；需要源图/待编辑对象/待评分对象的任务按对应 Contract 必需。

详细 Contract 只定位 [demand-contracts.md](references/demand-contracts.md) 中当前需求类型对应小节；不预读其他类型。

## 4. 缺字段时使用 Codex 原生用户输入

只有 Contract 标记为 blocking 的字段仍未知时才询问。当前 Codex host 暴露 request-user-input 交互时优先使用该 UI；单次最多组织 1–3 个短问题，把相关缺失字段合并成紧凑问题，不做逐字段审讯。

如果当前 host 不暴露该交互能力，才在聊天中返回同一份精简补全块。无论哪种形式：

- 已知字段自动带入；
- 默认值直接落值；
- 可选字段留空不追问；
- 一次收齐当前真正阻塞项；
- 用户回答后立即继续，不再重复确认一遍。

## 5. 建立 Source Lock，而不是专业 Brief

信息足够后形成最小 Intake Snapshot，内容只包括：

```text
project_name
demand_name
demand_type
primary_skill
branch_or_mode（适用时）
store_artwork_role（直接商店成图且可从原话可靠判断时）
target_market（适用时）
source_mode（适用时）
specific_requirements
size_or_aspect
copy
materials + roles
video_source_mode（存在真实视频输入且会改变专业链时）
explicit_must / explicit_must_not
```

不要在 Intake 阶段自行增加“更高级/电影感/镜头运动/构图/光影/创意方向”等用户没有要求的专业结论。那些属于下游专业 Skill。

## 6. 创建 request 并进入专业链

根据当前类型对应的 [demand-contracts.md](references/demand-contracts.md) 小节判断用户执行意图，并以 `.agents/lib/request_routing.py` 为唯一机器路由表选择 `request_type → primary_skill`；`wxian-image-production` 还同时得到唯一 `production_branch`。`$workspace-governance init-request` 会硬校验 request 目录类型与 primary Skill，不允许载体词或旧业务标签覆盖路由。随后由 `$workspace-governance init-request` **自动分配用户需求目录名**，Intake 不再自行拼 slug：

```text
requests/<request_type>/【YYYYMMDD】NN-需求类型-需求标题/
```

命名规则：

- `YYYYMMDD`：创建 request 时的本机当日日期；
- `NN`：当天所有用户需求共用一个递增序号，01、02……10；跨 `request_type` 也不能重复或各自从 01 重新计数；
- `需求类型`：使用用户业务载体/任务类型的短标签；已明确 `BANNER / KV / LOGO / ICON / 商店图` 时直接使用该标签，否则使用当前 request type 的规范短标签；
- `需求标题`：优先使用用户给的需求名称；为空时由 Intake 根据主题、核心文案、活动名、角色/对象等生成一个简短可辨识标题，不写泛词如“新需求/测试/最终版”；
- Governance 负责 Windows 非法字符清洗、序号分配和重复冲突处理，Agent 不得手填日期或序号。

创建调用只传 `request_type + demand_label + demand_title`，不得为用户需求传自造 `--request` 路径。`request.md` 只保存一份用户原文，再附已归一 Intake Snapshot；Snapshot 不复制用户原文；当前用户附件进入 `input/` 并保留真实文件名/角色说明。仅当 `user/manifest.json` 的 `enabled=true` 时，`init-request` 才解析当前 request_type 命中的 Personal Skill 并写入 `work/personal-context.json`；未开启时完全跳过 Personal Layer。Intake 随后只加载 `load_paths` 指向的已命中正文，再进入 primary Skill；不扫描或预读整个 `user/skills/`。命中 Skill 加载失败时阻断当前 request 并记录 `work/personal-layer-error.json`，不得静默回退。

**Intake 完成后不向用户展示内部 route/source-lock/gate。** 专业 Skill 继续完成需求拆解、Baseline 消费、Reference 判断、创意发散、需求文档、Prompt、生成或研究。

## 7. 完成条件

Intake 只有两种结果：

- `ready`：最小事实足够，request 已创建并进入唯一 primary Skill；
- `needs_user_input`：只缺会改变真实执行链的 blocking 字段，并已发出一次最小补充请求。

禁止为了“表格完整”追问可选字段，禁止把专业决策前移给用户。
