# Demand Intake Contracts

这里定义“一个需求开始前最少必须知道什么”。字段未列为 Blocking 时，由默认值、当前 Workspace、附件或 primary Skill 继续推导，不在 Intake 阶段追问。

## 共同规则

- `project_name`：当前 Project Workspace 默认从 Project Brief 推导。
- `demand_name`：全部可自动生成。
- `specific_requirements`：只要当前消息已经给出可执行主题/目标/范围即视为存在。
- `copy`：除 localization/text-replacement 外，空或缺失统一为 `none`。
- `materials`：只有任务本质依赖现有对象时才 Blocking。
- “KV / Banner / ICON / 海报”等只是载体词；**“直接做图”与“做包装方案/方向探索”必须按用户执行意图区分。**
- 唯一机器路由表是 `.agents/lib/request_routing.py`。`request_type` 先确定唯一 `primary_skill`；只有 `wxian-image-production` 的 request 再由同一表确定唯一 `production_branch`。任何 `source_demand_type`、资产名、载体名或视觉变体都不得覆盖这条链。

## A. 图片与视频生产 → `wxian-image-production`

### `image-generation` → branch `new-generation`
用于：生图、活动图、Banner 成图、KV 成图、海报、角色图、ICON 成图等。

- Blocking：`specific_requirements`；`demand_type` 仅在无法从语义判断载体时 Blocking。
- Default：`size=1:1`；`copy=none`；`materials=none`。
- 用户给一个主题/范围即可开始，构图、镜头、Reference 使用、项目化改写由专业链完成。
- 直接生产商店图仍属于本 route。能从原话判断时同步归一商店图职责：`首图/转化`→`first-screen-conversion`，`玩法`→`gameplay`，`世界观/场景幻想`→`worldbuilding`，`角色/IP`→`character`，明确系统/成长/社交/奖励/功能卖点→`selling-point`；无法判断且职责会改变画面证明方式时，只补问“这一张主要要证明什么”。玩法商店图不得在 Intake 阶段替用户编玩法，真实玩法事实由 `wxian-image-production` 的商店图专项门禁核验。

### `image-edit` → branch `image-edit`
用于：改图、重绘、精修、换角色、删/加元素、色调调整等。

- Blocking：待编辑源图；`specific_requirements`。
- Default：尺寸沿用源图；`copy=none`。

### `video-production` → branch `video`
用于：真实视频文件、图生视频、文本生视频。

- Blocking：`specific_requirements`；图生视频时源图必须存在。
- Default：有源图时沿用源比例；无源图且用户未给画幅时，只在画幅会改变制作时询问。
- 静态 KV → 5 秒剧情微动画的真实视频：本 Skill 为 primary；在同一 request 内以 `execution_mode=production_video` 调用 `$wxian-kv-micro-animation`，自动完成剧情、Camera Level、素材角色和 Seedance Prompt 后立即进入真实 Seedance API，不追加镜头确认。

### `resize` → branch `resize`
- Blocking：源图；目标尺寸或目标比例。
- 文案不参与 Intake。

### `localization` → branch `localization`
用于：换语言、替换标题/文案、多语言图。

- Blocking：源图；目标语言；目标文案或明确“由现有文案翻译到目标语言”的授权。
- 这里 `copy` 不能以空值自动解释为 none，因为文字就是任务对象。

### `composite` → branch `composite`
用于：加真实 Logo/ICON/UI/道具、确定性合成。

- Blocking：底图；待合成真实资产；`specific_requirements`。
- Default：尺寸沿用底图。

### `postprocess` → branch `postprocess-chain`
- Blocking：源图；要执行的后处理目标。
- 只问会改变实际处理链的目标尺寸/语言/资产。

### `visual-brief` → branch `visual-brief-only`
- Blocking：`specific_requirements`。
- Default：图像类目标缺尺寸时 `1:1`。
- 不要求用户提供构图、镜头、风格细节。

### `prompt-writing` → branch `prompt-only`
- Blocking：`specific_requirements`。
- 素材按是否需要身份/参考决定；普通从零 Prompt 不要求素材。

### `prompt-review` → branch `prompt-review-only`
- Blocking：待审 Prompt；审查目标若用户没写默认“是否忠实、可执行、符合当前项目”。

## B. 视觉包装方案 → `wxian-visual-packaging`

用于：LOGO / ICON / KV / Store 的**方案、方向探索、包装策划、品牌升级**，不是“直接生成一张成图”。

- `request_type=visual-packaging`。
- Blocking：模块范围 `logo|icon|kv|store`（可从语义推导）；`specific_requirements`/商业目标。
- Default：方向数量与专业展开按 Skill 自己的默认；尺寸、文案、素材均可空。
- 用户如果说“直接给我生成一张 KV/ICON”，应路由 image-generation，不应误进包装策划。
- 方案默认交付项目化单文件 HTML；所有展示图内嵌。实际生成验证图保存在当前 request 的 `work/final/originals/` 并逐图绑定完整 Prompt。

## C. 单图视觉反推 → `wxian-visual-reverse-analysis`

- `request_type=visual-reverse-analysis`。
- Blocking：至少一张真实目标图。
- Default：未说明用途时做完整用途特异反推；不问尺寸/文案。

## D. 视觉评分 / 候选比较 → `wxian-visual-scorecard`

- `request_type=visual-scorecard`。
- Blocking：至少一个真实评分对象。
- Default：单对象=诊断评分；多对象=比较排序；项目目标从当前 request/Baseline 推导。
- 只有用户的比较目标确实无法判断时才补问。

## E. KV / Banner 与通用合成图拆层 → `wxian-image-layer-decomposition`

- `request_type=image-layer-decomposition`。
- Carrier：已合成的 KV / Banner / Poster / Key Art、角色图、场景图、特效图、LOGO 与混合视觉；HUD/UI 截图组件拆分不走此 Skill。
- Profile：KV/Banner/Poster/Key Art 使用 `kv-depth`；角色/场景/特效/LOGO/混合视觉使用 `generic-composite`。
- Blocking：至少 1 张真实源图；拆层用途或后续要独立控制的对象（如 2.5D 视差、角色单独动、局部替换）。
- Default：先按景深与遮挡关系建立 layer/occlusion plan，再做语义归属；保留原画布、原构图、角色身份和当前可见区域。未指定层数时不追问固定模板层数。
- Default output：full-canvas delivery PNG layers + deterministic crops + recomposition + Embedded Smart Object PSD；普通拆图默认 `delivery_canvas=source_canvas`、`editable_master=1x bbox`。PSD 由独立 `wxian-layered-psd-export` 代码编译，不存在 raster PSD fallback；透明层优先 GPT Image 2.5 原生 Alpha，灰底仅作 QA review 衍生。

## F. 游戏 UI 截图拆层 → `wxian-game-ui-layer-decomposition`

- `request_type=game-ui-layer-decomposition`。
- Carrier：真实游戏运行截图、HUD/Panel/菜单/主城/建筑详情等界面；KV/Banner 的前中后景深度拆层不走此 Skill。
- Blocking：至少 1 张真实截图。页面用途、拆分粒度、文字保留策略如用户未指定均由 Skill 自主判断，不反问。
- Default：先建立 Screen Structure Map，区分 `scene / screen-ui / world-ui`；`granularity_mode=balanced`；普通文字 `text_policy=strip-and-fill`；只生成截图中观察到的 State。
- Hard requirement：`scene_clean` 必须补全所有被 Screen-space / World-space UI 遮挡的场景；需独立输出的 UI base 也必须补全其被子控件遮挡的部分。
- Multi-screen：相同 HUD/导航/通用控件先做 `COMMON / LOCAL / VARIANT` 去重；同 master 不重复生成。
- Default output：scene clean plate + full-canvas transparent UI layers + deterministic crops + bbox/anchor/z-order/reuse manifest + recomposition QA + 每个 Screen 的 Embedded Smart Object PSD。UI 默认 `work=prefer 2x`、`editable_master=2x bbox`，但 `delivery_canvas=source_canvas`；PSD 由独立 `wxian-layered-psd-export` 代码编译，不存在 raster PSD fallback。

## G. 项目 Visual Baseline → `wxian-visual-baselines`

- `request_type=baseline`。
- 正常初始化/Reference 刷新由 Workspace 自动触发，不弹业务 Intake。
- 用户显式要求“重建/更新 Baseline”且 Project 已初始化时，无额外字段即可开始；用户指定范围则作为约束。

## H. KV 5 秒微动画设计 → `wxian-kv-micro-animation`

用于：只要剧情微动画设计 / Seedance 2.0 Prompt，而不是直接交付视频文件。

- `request_type=kv-micro-animation`。
- Blocking：1 张可读静态 KV。
- Default：`duration=5s`；画幅沿用 KV；使用场景/剧情倾向可空。
- `prompt_only` 下镜头自由度不在 Intake 强制询问；未提供时由 Skill 在最终 Prompt 前确认。真实视频生产不询问，Skill 自动锁定推荐 Camera Level。
- 如果用户要求最终视频文件，改由 `wxian-image-production` 的 `video` branch 为 primary，本 Skill 作为专业前置。

## I. 海外手游美术竞品分析 → `wxian-visual-competitive-analysis`

用于：基于自身 Visual Baseline / 当前包装与竞品包装做美术、视觉、KV、Banner、Campaign、商店包装等交叉分析，目标是提炼竞品有效视觉解法并反哺自身项目。

- `request_type=visual-competitive-analysis`。
- Blocking：`specific_requirements` 中至少能判断本次要研究/改进什么；如果用户明确要求“基于我提供的资料分析”，则至少一份可读取的竞品资料为 Blocking。
- `source_mode`：当前消息存在竞品资料时记为 `user-materials`，否则记为 `internet-research`。
- `target_market`：从用户原话、Project Brief 或当前项目发行目标推导；仍未知时记为 `global-exploratory`。
- Default：主动研究优先 KV / Banner / Campaign Visual；不要求用户填写竞品数量、构图、镜头、分析维度、历史 ICON 或 ASO 数据。
- 默认交付项目化单文件 HTML，并内嵌全部实际用于结论的代表证据图；如生成项目化验证图，原图进入 `work/final/originals/` 并逐图绑定完整 Prompt。
- 用户只有 Baseline / 项目资料、尚无 Current Packaging 时仍可开始，不为此追问包装方案。
- 如果用户目标只是市场规模、收入、下载、榜单、商业格局或其他非视觉竞品研究，路由 `$wxian-conducting-internet-research`。
- 如果用户已经要直接设计/生产具体 KV、Banner、ICON 等成品，而竞品只作为 Reference，路由对应 `$wxian-visual-packaging` / `$wxian-image-production`，竞品研究作为辅助，不单独建第二 request。

## J. 互联网调研 → `wxian-conducting-internet-research`

用于：搜索互联网、竞品研究、案例搜集、当前信息核验、市场/实体/事件/视觉研究。

- `request_type=internet-research`。
- Blocking：研究主题/问题；只有不同解释会改变搜索空间时才补充 `decision_to_support`。
- Default：`depth=STANDARD`；地区/时间/平台从用户原话和当前项目目标推导；未要求正式文件时默认 Markdown 研究交付。
- “最新/当前/全部/历史完整”由研究 Skill 自己提升 freshness/depth，不要求用户填研究方法。


## K. 游戏概念 / 画风玩法实验 → `sicza-game-concept-lab`

用于：从零游戏概念探索、画风玩法入口测试、人物×场景×玩法原型、角色／怪物／场景等单对象差异设计、把成熟 Gameplay 变异到新世界，并默认完成 Prompt→图片 API→互动 HTML 的同 request 闭环。

- `request_type=game-concept-lab`。
- Blocking：`specific_requirements` 中至少存在可执行的核心 Premise、产品问题或待变异 Gameplay 目标。
- Default：完整入口测试为 3–5 个方向，每方向角色／场景／玩法 3 张主证据图（共 9–15 张）；单对象差异设计为 3–5 个方向、每方向 1 张主图（共 3–5 张）。尺寸、文案、素材可空，由专业 Skill 依据目标补全。
- 除用户明确只要 Prompt 外，必须调用图片 API，将全部生成原图保存到 `work/final/originals/`，并交付内嵌图片、逐图完整 Prompt 的项目化单文件 HTML。
- 用户只有一句世界设定也可开始，不要求其提前填写年龄、服装、镜头、玩法循环、画风、Prompt 或完整产品方案。
- 用户给成熟 Gameplay Reference 时由本 Skill 先拆 Grammar / Must-preserve Fun，再做 World-bound Mutation，不能由 Intake 询问用户“希望怎么改玩法”。
- 用户已有固定概念，只要求单次直接生图/改图，不进入本 Skill，路由 `$wxian-image-production`；只要还要求先产生多个差异设计方向，就仍进入本 Skill。
- 用户要求“先探索多个游戏概念/画风玩法方向并最终直接交付实际图片文件”时，`$wxian-image-production` 为 primary，本 Skill 作为当前 request 的前置专业能力，不创建第二 request。
- LOGO / ICON / KV / Store 的发行包装方向仍归 `$wxian-visual-packaging`；海外发行视觉竞品研究仍归 `$wxian-visual-competitive-analysis`。

## L. 视频输入分析 → `wxian-video-source-analysis`

用于：直接分析 Gameplay 录屏、广告视频、PV、游戏宣传片、实拍或其他真实视频，输出时间线事实、关键帧、玩法/UI/镜头/叙事观察与证据约束推断；不是生成视频。

- `request_type=video-source-analysis`。
- Blocking：至少一个可读取真实视频；`specific_requirements` 只需能判断用户主要想看“玩法 / 视觉 / 广告包装 / 镜头叙事 / 完整分析”中的哪类目标，完全未限定时默认完整分析。
- Default：不要求用户截图、标时间点、解释玩法或手动挑关键帧；由 Skill 先 Overview，再对关键事件自动 refine。
- 如果用户要求的是“生成/编辑视频文件”，仍路由 `$wxian-image-production` 的 `video` branch。
- 如果视频只是图片生产、竞品分析、视觉反推或游戏概念的证据，不建立第二 request，由对应 primary Skill 在当前 request 内调用 `$wxian-video-source-analysis`。
- Gameplay 商店图允许直接把当前 Gameplay 视频作为事实源；图片生成前必须由视频分析链抽取并验证代表关键帧，原视频不能直接冒充图片 Reference。

## M. 辅助研究与视频分析，不创建第二需求

`wxian-conducting-internet-research` 作为其他 primary Skill 的辅助时，不走新 Intake、不新建 request。调用方只给研究问题、决策目的、范围和输出位置。

同理，`wxian-kv-micro-animation` 作为真实视频生产的前置时不新建第二 request；`sicza-game-concept-lab` 作为“概念探索后直接出实际图片”的图片生产前置时，也不新建第二 request；`wxian-video-source-analysis` 作为图片生产、竞品分析、视觉反推或游戏概念的真实视频证据能力时，同样不新建第二 request。
作为 primary request 时默认交付项目化单文件 HTML；视觉研究内嵌全部实际用于结论的代表图片。研究证据图保留来源身份，只有真实 API 生成图进入 `work/final/originals/` 并绑定完整 Prompt。
