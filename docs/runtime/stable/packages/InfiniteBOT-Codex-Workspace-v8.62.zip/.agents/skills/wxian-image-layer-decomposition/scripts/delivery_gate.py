#!/usr/bin/env python3
"""Final delivery gate for KV/Banner layer decomposition."""
from __future__ import annotations
import os as _bytecode_guard_os, sys as _bytecode_guard_sys
_bytecode_guard_sys.dont_write_bytecode = True
_bytecode_guard_os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
import argparse, hashlib, importlib.util, json, math, sys
from pathlib import Path
from typing import Any
from PIL import Image

PRIMARY="wxian-image-layer-decomposition"
MANIFEST_SCHEMA="wxian.kv-final-layer-manifest.v2"
QA_SCHEMA="wxian.kv-layer-qa.v1"

class DeliveryError(ValueError): pass
def require(c,m):
    if not c: raise DeliveryError(m)
def sha(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def bounded(root:Path,v:str|Path,exist=False)->Path:
    p=Path(v); p=(root/p if not p.is_absolute() else p).resolve(); root=root.resolve()
    require(p==root or root in p.parents,f'path escapes Workspace: {v}')
    if exist: require(p.is_file(),f'file missing: {v}')
    return p
def rel(root:Path,p:Path)->str: return p.resolve().relative_to(root.resolve()).as_posix()
def load(p:Path)->dict[str,Any]:
    require(p.is_file(),f'JSON missing: {p}')
    try: v=json.loads(p.read_text(encoding='utf-8'))
    except json.JSONDecodeError as e: raise DeliveryError(f'invalid JSON: {p}: {e}') from e
    require(isinstance(v,dict),f'JSON root must be object: {p}'); return v
def module(path:Path,name:str):
    s=importlib.util.spec_from_file_location(name,path); require(s and s.loader,f'cannot load {path}')
    m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
def rgba_info(path:Path)->tuple[tuple[int,int],tuple[int,int]|None]:
    with Image.open(path) as im:
        im.load(); require(im.format=='PNG',f'formal layer must be PNG: {path.name}')
        require('A' in im.getbands(),f'formal layer must have alpha channel: {path.name}')
        a=im.getchannel('A'); return im.size,a.getextrema()
def require_file(root:Path,work:Path,path_value:str,hash_value:str,label:str)->Path:
    p=bounded(root,path_value,True); require(work==p or work in p.parents,f'{label} must stay inside request work/')
    require(hash_value==sha(p),f'{label} sha256 mismatch'); return p

def _visible_pixel_count(image:Image.Image, threshold:int=16)->int:
    return sum(value >= threshold for value in image.getchannel('A').getdata())

def _require_master_lineage(root:Path, work:Path, final:Path, plan_layer:dict[str,Any], work_canvas_size:list[int], entry:dict[str,Any],
                            master:dict[str,Any], master_file:Path, layer_file:Path)->None:
    """Bind the PSD source to the exact selected provider responses and delivery crop."""
    lid=str(entry['layer_id'])
    originals=(final/'originals').resolve()
    provider=(originals/'provider').resolve()
    require(master_file.parent==originals,
            f'editable master must be the approved PSD original directly inside work/final/originals: {lid}')
    derivation=master.get('derivation')
    require(isinstance(derivation,dict),f'editable_master derivation is required: {lid}')
    required_derivation={'operation','source_canvas_file','source_canvas_sha256','crop_bbox'}
    require(required_derivation<=set(derivation),f'editable_master derivation fields missing: {lid}')
    require(derivation['operation']=='delivery_bbox_crop_v1',f'editable_master derivation operation invalid: {lid}')
    require(derivation['source_canvas_file']==entry['file'] and derivation['source_canvas_sha256']==entry['sha256'],
            f'editable_master derivation must bind the final full-canvas layer: {lid}')
    require(derivation['crop_bbox']==entry['bbox'],f'editable_master derivation crop_bbox must equal final bbox: {lid}')
    x,y,w,h=entry['bbox']
    full=finalizer_load(root, layer_file)
    expected=full.crop((x,y,x+w,y+h))
    actual=finalizer_load(root, master_file)
    require(expected.size==actual.size and list(expected.getdata())==list(actual.getdata()),
            f'editable_master pixels are not the declared final-layer bbox crop: {lid}')
    calls=plan_layer.get('api_calls',[])
    sources=master.get('provider_originals')
    if not calls:
        require(sources in ([],None),f'non-provider layer must not claim provider_originals: {lid}')
        return
    require(isinstance(sources,list) and sources,f'editable_master provider_originals are required: {lid}')
    expected_paths={str(call['output_path']) for call in calls}
    seen:set[str]=set()
    for source in sources:
        require(isinstance(source,dict),f'editable_master provider original must be object: {lid}')
        require({'file','sha256','size'}<=set(source),f'editable_master provider original fields missing: {lid}')
        raw=require_file(root,work,str(source['file']),str(source['sha256']),f'provider original {lid}')
        require(provider in raw.parents,f'provider original must stay inside work/final/originals/provider/: {lid}')
        size,_=rgba_info(raw)
        require(list(size)==source['size']==work_canvas_size,f'provider original size must equal work canvas: {lid}')
        seen.add(rel(root,raw))
    require(seen==expected_paths,f'editable_master provider originals must bind exactly all selected API outputs: {lid}')

def finalizer_load(root:Path,path:Path)->Image.Image:
    with Image.open(path) as opened:
        opened.load()
        return opened.convert('RGBA')

def validate(root:Path,request:Path,delivery_sources:set[str]|None=None)->dict[str,Any]:
    state=load(request/'state.json'); require(state.get('primary_skill')==PRIMARY,'wrong primary_skill')
    work=request/'work'; final=work/'final'; require(final.is_dir(),'work/final is missing')
    batch=module(request.resolve().parents[2]/'.agents/skills/wxian-image-layer-decomposition/scripts/layer_batch.py','kv_batch_gate')
    finalizer=module(root/'.agents/lib/deterministic_layer_finalization.py','deterministic_layer_finalization_kv')
    psd=module(root/'.agents/skills/wxian-layered-psd-export/scripts/psd_export.py','smart_object_psd_kv_gate')
    plan_path=work/'layer-plan.json'; plan,_,_=batch.validate_plan(plan_path,root)
    plan_sha=sha(plan_path); canvas=tuple(plan['delivery_canvas_size'])
    source=bounded(root,plan['source_image'],True); source_sha=sha(source)

    mf_path=final/'layer-manifest.json'; mf=load(mf_path)
    require(mf.get('schema_version')==MANIFEST_SCHEMA,'KV final manifest schema mismatch')
    require(mf.get('status')=='READY','KV final manifest must be READY')
    require(mf.get('layer_plan_path')==rel(root,plan_path) and mf.get('layer_plan_sha256')==plan_sha,'KV final manifest plan binding is stale')
    require(mf.get('decomposition_skill')==PRIMARY,'KV final manifest decomposition_skill mismatch')
    require(mf.get('source_image')==plan['source_image'] and mf.get('source_sha256')==source_sha,'KV final manifest source binding is stale')
    require(mf.get('source_canvas_size')==plan['source_canvas_size'],'KV final manifest source canvas mismatch')
    require(mf.get('delivery_canvas_size')==list(canvas),'KV final manifest delivery canvas mismatch')
    delivery_ref=require_file(root,work,mf.get('delivery_reference_image',''),mf.get('delivery_reference_sha256',''),'delivery reference')
    dsize,_=rgba_info(delivery_ref); require(dsize==canvas,'delivery reference canvas mismatch')
    delivery_image=finalizer.require_delivery_reference(source,delivery_ref,canvas,'KV delivery reference')
    graph_work=work/'layer-graph.json'; graph_final=final/'layer-graph.json'
    require(graph_final.is_file() and sha(graph_final)==sha(graph_work),'final layer-graph must exactly preserve analyzed layer-graph')
    require(mf.get('layer_graph_path')==rel(root,graph_final) and mf.get('layer_graph_sha256')==sha(graph_final),'KV final manifest graph binding is stale')

    pmap={x['layer_id']:x for x in plan['layers']}
    require(all(x.get('strategy')!='unrecoverable' for x in plan['layers']),'unrecoverable planned layer cannot be promoted as complete')
    layers=mf.get('layers'); require(isinstance(layers,list) and layers,'KV final manifest layers missing')
    ids=[x.get('layer_id') for x in layers if isinstance(x,dict)]
    require(len(ids)==len(layers) and set(ids)==set(pmap) and len(ids)==len(set(ids)),'KV final manifest must contain exactly all planned layers')
    expected_delivery={rel(root,mf_path),rel(root,graph_final)}
    primary_count=0
    layer_files:dict[str,Path]={}
    owner_masks:list[Path]=[]
    for e in layers:
        lid=e['layer_id']; p=pmap[lid]
        required={'layer_id','status','layer_type','depth_band','z_order','file','sha256','output_mode','anchor','bbox','dependencies','blend_mode','blend_mode_hint','primary_pixel_owner','source_visible_mask','source_visible_mask_sha256','source_visible_region_source_locked','reconstructed_region_present','reconstruction_confidence','reconstruction_provenance','minimum_visible_coverage_ratio','motion_envelope_px','motion_margin_px','interaction_members','qa_status','crop_file','crop_sha256','editable_master'}
        require(required<=set(e),f'KV final layer fields missing: {lid}')
        require(e['status']=='passed' and e['qa_status']=='PASS',f'KV layer not passed: {lid}')
        for k in ('layer_type','depth_band','z_order','blend_mode_hint','primary_pixel_owner','reconstruction_confidence','minimum_visible_coverage_ratio','motion_envelope_px','motion_margin_px','interaction_members'):
            require(e[k]==p[k],f'KV final layer disagrees with plan {k}: {lid}')
        require(e['blend_mode']=='normal' and e['output_mode']=='delivery-canvas' and e['anchor']==[0,0],f'KV full-canvas layer contract invalid: {lid}')
        require(e['bbox']==p['source_bbox_hint'],f'KV final bbox disagrees with plan: {lid}')
        layer_file=require_file(root,work,e['file'],e['sha256'],f'layer {lid}')
        layer_files[lid]=layer_file
        size,ext=rgba_info(layer_file); require(size==canvas,f'KV full-canvas size mismatch: {lid}'); require(ext and ext[1]>0,f'KV layer is fully transparent: {lid}')
        if p['layer_type']!='background-clean': require(ext[0]<255,f'KV transparent component has no transparent pixels: {lid}')
        crop=require_file(root,work,e['crop_file'],e['crop_sha256'],f'crop {lid}'); _,cext=rgba_info(crop); require(cext and cext[1]>0,f'KV crop empty: {lid}')
        expected_delivery|={rel(root,layer_file),rel(root,crop)}
        master=e['editable_master']; require(isinstance(master,dict),f'editable_master invalid: {lid}')
        mfile=require_file(root,work,str(master.get('file','')),str(master.get('sha256','')),f'editable master {lid}')
        msize,mext=rgba_info(mfile); require(mext and mext[1]>0,f'editable master empty: {lid}')
        require(list(msize)==master.get('size'),f'editable master size mismatch: {lid}')
        require(float(master.get('scale_vs_delivery',0))==1.0,f'normal decomposition editable master must be 1x: {lid}')
        require(list(msize)==[e['bbox'][2],e['bbox'][3]],f'normal decomposition editable master must match bbox: {lid}')
        require(master.get('provenance') in {'source_preserved','ai_reconstructed','ai_upscaled','deterministic_resample','mixed'},f'editable master provenance invalid: {lid}')
        _require_master_lineage(root,work,final,p,plan['work_canvas_size'],e,master,mfile,layer_file)
        x,y,w,h=e['bbox']
        alpha=finalizer_load(root,layer_file).getchannel('A').point(lambda value:255 if value>=16 else 0)
        alpha_bbox=alpha.getbbox(); require(alpha_bbox is not None,f'KV layer has no visible alpha at threshold: {lid}')
        require(alpha_bbox[0]>=x and alpha_bbox[1]>=y and alpha_bbox[2]<=x+w and alpha_bbox[3]<=y+h,
                f'KV layer alpha escapes declared bbox: {lid}')
        required_pixels=math.ceil(w*h*float(e['minimum_visible_coverage_ratio']))
        require(_visible_pixel_count(finalizer_load(root,mfile))>=required_pixels,
                f'KV layer visible coverage is below the analyzed minimum: {lid}')
        expected_delivery.add(rel(root,mfile))
        if e['primary_pixel_owner']:
            primary_count+=1; require(bool(e['source_visible_mask']),'primary owner missing source_visible_mask: '+lid)
            mask=require_file(root,work,e['source_visible_mask'],e['source_visible_mask_sha256'],f'source visible mask {lid}')
            owner_masks.append(mask)
            msize,mext=rgba_info(mask); require(msize==canvas and mext and mext[1]>0,f'invalid source visible mask: {lid}')
            expected_delivery.add(rel(root,mask))
        else:
            require(e['source_visible_mask'] in (None,''),'non-primary layer must not claim source_visible_mask: '+lid)
        require(isinstance(e['source_visible_region_source_locked'],bool) and isinstance(e['reconstructed_region_present'],bool),f'KV provenance flags invalid: {lid}')
        if e['primary_pixel_owner']:
            require(e['source_visible_region_source_locked'] is True,f'primary owner must declare source-visible source lock: {lid}')

    canonical_image=delivery_image
    for e in layers:
        if e['primary_pixel_owner']:
            finalizer.require_masked_source_rgb_lock(canonical_image,finalizer.load_rgba(layer_files[e['layer_id']]),
                                                     finalizer.load_rgba(bounded(root,e['source_visible_mask'],True)),
                                                     f"KV layer {e['layer_id']}")

    own_path=final/'ownership-audit.json'; own=load(own_path)
    require(own.get('status')=='passed' and own.get('operation')=='ownership-audit','KV ownership audit must pass')
    threshold=own.get('threshold',16); require(isinstance(threshold,int) and not isinstance(threshold,bool),'KV ownership threshold invalid')
    own_actual, overlap_actual, holes_actual=finalizer.ownership_maps(owner_masks,canvas,threshold)
    for key in ('threshold','primary_owner_layer_count','overlap_pixels','hole_pixels','overlap_bbox','hole_bbox'):
        require(own.get(key)==own_actual[key],f'KV ownership audit differs from deterministic result: {key}')
    require(own_actual['overlap_pixels']==0 and own_actual['hole_pixels']==0,'KV ownership audit has overlap or holes')
    overlap_file=require_file(root,work,own['overlap_output'],own['overlap_sha256'],'ownership overlap_output')
    hole_file=require_file(root,work,own['hole_output'],own['hole_sha256'],'ownership hole_output')
    finalizer.require_pixel_equal(finalizer.alpha_mask_rgba(overlap_actual),overlap_file,'KV ownership overlap map')
    finalizer.require_pixel_equal(finalizer.alpha_mask_rgba(holes_actual),hole_file,'KV ownership hole map')
    expected_delivery|={rel(root,overlap_file),rel(root,hole_file)}

    recomp=final/'recomposition.png'; size,_=rgba_info(recomp); require(size==canvas,'KV recomposition canvas mismatch')
    recomposed_actual=finalizer.compose_full_canvas([(int(e['z_order']),layer_files[e['layer_id']]) for e in layers],canvas)
    finalizer.require_pixel_equal(recomposed_actual,recomp,'KV recomposition')
    diff_path=final/'recomposition-diff.json'; diff=load(diff_path)
    require(diff.get('source')==rel(root,delivery_ref) and diff.get('source_sha256')==sha(delivery_ref),'KV recomposition diff source binding stale')
    require(diff.get('recomposed')==rel(root,recomp) and diff.get('recomposed_sha256')==sha(recomp),'KV recomposition diff output binding stale')
    require(diff.get('professional_visual_review_required') is True,'KV recomposition diff must require professional visual review')
    evaluation_mask=None
    if diff.get('evaluation_mask') not in (None,''):
        mask_path=require_file(root,work,diff['evaluation_mask'],diff.get('evaluation_mask_sha256'),'KV recomposition evaluation mask')
        evaluation_mask=finalizer.load_rgba(mask_path).getchannel('A')
        expected_delivery.add(rel(root,mask_path))
    actual_metrics, actual_diff=finalizer.diff_artifacts(canonical_image,recomposed_actual,evaluation_mask)
    for key in ('changed_bbox','pixel_identical'):
        require(diff.get(key)==actual_metrics[key],f'KV recomposition diff differs from deterministic result: {key}')
    reported_mean=diff.get('mean_absolute_channel_difference')
    require(isinstance(reported_mean,(int,float)) and abs(float(reported_mean)-float(actual_metrics['mean_absolute_channel_difference']))<1e-9,
            'KV recomposition diff differs from deterministic result: mean_absolute_channel_difference')
    diff_image=require_file(root,work,diff.get('diff'),diff.get('diff_sha256'),'KV recomposition diff image')
    finalizer.require_pixel_equal(actual_diff,diff_image,'KV recomposition diff image')
    expected_delivery.add(rel(root,diff_image))
    finalizer.require_not_catastrophic(actual_metrics,'KV recomposition')

    qa_path=final/'layer-qa.json'; qa=load(qa_path)
    require(qa.get('schema_version')==QA_SCHEMA and qa.get('status')=='PASS','KV layer QA must PASS')
    require(qa.get('layer_manifest_path')==rel(root,mf_path) and qa.get('layer_manifest_sha256')==sha(mf_path),'KV QA manifest binding stale')
    require(qa.get('ownership_audit_path')==rel(root,own_path) and qa.get('ownership_audit_sha256')==sha(own_path),'KV QA ownership binding stale')
    require(qa.get('recomposition_path')==rel(root,recomp) and qa.get('recomposition_sha256')==sha(recomp),'KV QA recomposition binding stale')
    require(qa.get('recomposition_diff_path')==rel(root,diff_path) and qa.get('recomposition_diff_sha256')==sha(diff_path),'KV QA diff binding stale')
    require(set(qa.get('reviewed_layer_ids',[]))==set(pmap),'KV QA must review every layer')
    for k in ('source_visible_fidelity_review','alpha_boundary_review','geometry_review','occlusion_review','interaction_integrity_review'):
        require(qa.get(k)=='PASS',f'KV QA review not PASS: {k}')
    expected_delivery|={rel(root,delivery_ref),rel(root,own_path),rel(root,recomp),rel(root,diff_path),rel(root,qa_path)}

    psd_path=final/'layered.psd'; preview_path=final/'layered.preview.png'; psd_receipt_path=final/'layered-psd.json'
    psd_receipt=load(psd_receipt_path)
    require(psd_receipt.get('source_manifest')==rel(root,mf_path),'KV PSD receipt must bind the final layer manifest')
    require(psd_receipt.get('psd')==rel(root,psd_path),'KV PSD receipt must bind work/final/layered.psd')
    require(psd_receipt.get('preview')==rel(root,preview_path),'KV PSD receipt must bind work/final/layered.preview.png')
    psd.verify(root,psd_receipt_path)
    expected_delivery|={rel(root,psd_path),rel(root,preview_path),rel(root,psd_receipt_path)}
    if delivery_sources is not None:
        missing=expected_delivery-delivery_sources; require(not missing,f'KV delivery-manifest omits required final artifacts: {sorted(missing)}')
    return {'status':'ready','layer_count':len(layers),'required_delivery_files':len(expected_delivery)}

def main()->int:
    ap=argparse.ArgumentParser(); ap.add_argument('--request',required=True); ap.add_argument('--workspace-root',type=Path,default=Path.cwd()); ap.add_argument('--delivery-manifest')
    a=ap.parse_args()
    try:
        root=a.workspace_root.resolve(); request=bounded(root,a.request); require(request.is_dir(),'request directory missing')
        sources=None
        if a.delivery_manifest:
            dm=load(bounded(root,a.delivery_manifest,True)); sources={str(x.get('source')) for x in dm.get('files',[]) if isinstance(x,dict) and x.get('active') is True}
        out=validate(root,request,sources); print(json.dumps(out,ensure_ascii=False)); return 0
    except Exception as e:
        print(json.dumps({'status':'blocked','reason':str(e)},ensure_ascii=False)); return 1
if __name__=='__main__': raise SystemExit(main())
