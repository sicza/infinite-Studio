#!/usr/bin/env python3
"""Deterministic alpha extraction, preview, recomposition, and comparison for layer delivery."""

from __future__ import annotations
import os as _bytecode_guard_os, sys as _bytecode_guard_sys
_bytecode_guard_sys.dont_write_bytecode = True
_bytecode_guard_os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import argparse
import hashlib
import io
import json
import re
import sys
import math
from pathlib import Path

LIB=Path(__file__).resolve().parents[3]/'lib'
if str(LIB) not in sys.path: sys.path.insert(0,str(LIB))
from project_materials import indexed_project_source
from decomposition_size import plan_size_contract, validate_size_contract, SKILL_IMAGE, SKILL_UI

try:
    from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageStat
except ImportError as exc:
    print(json.dumps({"status": "blocked", "reason": "Pillow is not installed"}))
    raise SystemExit(2) from exc


class LayerError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise LayerError(message)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def layer_baseline_floor_ids(path: Path) -> set[str]:
    index = path.parent / "index.json"
    require(index.is_file(), "formal Baseline index is missing")
    value = json.loads(index.read_text(encoding="utf-8"))
    ids = value.get("floor_ids", [])
    require(isinstance(ids, list) and all(isinstance(item, str) and item for item in ids), "Baseline index floor_ids invalid")
    return set(ids)

def workspace_path(value: str, root: Path, *, must_exist: bool = False) -> Path:
    candidate = Path(value)
    if not candidate.is_absolute():
        candidate = root / candidate
    resolved = candidate.resolve()
    require(resolved == root or root in resolved.parents, f"path escapes Workspace: {value}")
    if must_exist:
        require(resolved.is_file(), f"input does not exist: {value}")
    return resolved


def workspace_relative(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def stored_workspace_path(value: str, root: Path, *, must_exist: bool = False) -> Path:
    require(bool(value) and not Path(value).is_absolute(), f"stored Workspace path must be relative: {value}")
    return workspace_path(value, root, must_exist=must_exist)


def request_root_from_work(path: Path, root: Path) -> Path:
    relative = path.relative_to(root)
    lowered = [part.lower() for part in relative.parts]
    require("requests" in lowered and "work" in lowered, "outputs must be inside the current request work directory")
    request_index = lowered.index("requests")
    work_index = lowered.index("work", request_index + 1)
    require(work_index >= request_index + 3, "request path must be requests/<type>/<request>/work")
    return root.joinpath(*relative.parts[:work_index])


def require_source(path: Path, root: Path, request_root: Path) -> None:
    path=path.resolve(); allowed=[(request_root/'input').resolve(),(request_root/'work').resolve()]
    in_request=any(path==base or base in path.parents for base in allowed)
    require(in_request or indexed_project_source(root.resolve(),path),
            "source must be current request input/work or current indexed project material")

def prepare_output(value: str, root: Path) -> tuple[Path, Path]:
    output = workspace_path(value, root)
    request_root = request_root_from_work(output, root)
    require(not output.exists(), f"output already exists: {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    return output, request_root


def save_png(image: Image.Image, output: Path) -> None:
    require(output.suffix.lower() == ".png", "layer outputs must be PNG")
    image.convert("RGBA").save(output, format="PNG", optimize=True)
    with Image.open(output) as check:
        check.load()
        require(check.mode == "RGBA", "saved layer lost RGBA mode")


def extract_command(args: argparse.Namespace) -> dict:
    root = args.workspace_root.resolve()
    source = workspace_path(args.source, root, must_exist=True)
    mask = workspace_path(args.mask, root, must_exist=True)
    source_canvas, request_root = prepare_output(args.source_canvas_output, root)
    component = workspace_path(args.component_output, root) if args.component_output else None
    record = workspace_path(args.record_output, root)
    for path in (source, mask):
        require_source(path, root, request_root)
    for path in (component, record):
        if path is not None:
            require(request_root_from_work(path, root) == request_root, "all outputs must use the same request work directory")
            require(not path.exists(), f"output already exists: {path}")
            path.parent.mkdir(parents=True, exist_ok=True)
    with Image.open(source) as opened:
        opened.load()
        image = opened.convert("RGBA")
    with Image.open(mask) as opened:
        opened.load()
        alpha_mask = opened.convert("L")
    require(alpha_mask.size == image.size, "mask size must match source image")
    original_alpha = image.getchannel("A")
    combined_alpha = ImageChops.multiply(original_alpha, alpha_mask)
    require(combined_alpha.getbbox() is not None, "mask contains no visible layer pixels")
    image.putalpha(combined_alpha)
    save_png(image, source_canvas)
    alpha_bbox = combined_alpha.getbbox()
    component_path = None
    if component is not None:
        component_path = component
        save_png(image.crop(alpha_bbox), component)
    value = {
        "layer_id": args.layer_id,
        "source_image": workspace_relative(source, root),
        "source_sha256": sha256_file(source),
        "mask_image": workspace_relative(mask, root),
        "mask_sha256": sha256_file(mask),
        "source_canvas_file": workspace_relative(source_canvas, root),
        "source_canvas_sha256": sha256_file(source_canvas),
        "source_canvas_size": list(image.size),
        "component_crop_file": workspace_relative(component_path, root) if component_path else None,
        "component_crop_sha256": sha256_file(component_path) if component_path else None,
        "bbox": list(alpha_bbox),
        "anchor": [alpha_bbox[0], alpha_bbox[1]],
        "z_order": args.z_order,
        "blend_mode": "normal",
        "acquisition_method": "verified_mask_extraction",
    }
    record.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"status": "success", "operation": "extract", "record": workspace_relative(record, root), **value}


def checkerboard(size: tuple[int, int], cell: int = 16) -> Image.Image:
    image = Image.new("RGBA", size, (220, 220, 220, 255))
    draw = ImageDraw.Draw(image)
    for y in range(0, size[1], cell):
        for x in range(0, size[0], cell):
            if (x // cell + y // cell) % 2:
                draw.rectangle((x, y, min(x + cell - 1, size[0] - 1), min(y + cell - 1, size[1] - 1)), fill=(170, 170, 170, 255))
    return image


def preview_command(args: argparse.Namespace) -> dict:
    root = args.workspace_root.resolve()
    layer = workspace_path(args.layer, root, must_exist=True)
    output, request_root = prepare_output(args.output, root)
    require_source(layer, root, request_root)
    with Image.open(layer) as opened:
        opened.load()
        rgba = opened.convert("RGBA")
    require("A" in rgba.getbands() and rgba.getchannel("A").getextrema()[0] < 255, "layer lacks transparent alpha")
    width, height = rgba.size
    preview = Image.new("RGBA", (width * 2, height * 2), (0, 0, 0, 0))
    backgrounds = [checkerboard(rgba.size), Image.new("RGBA", rgba.size, "black"), Image.new("RGBA", rgba.size, "white"), Image.new("RGBA", rgba.size, (128, 128, 128, 255))]
    for index, background in enumerate(backgrounds):
        background.alpha_composite(rgba)
        preview.alpha_composite(background, ((index % 2) * width, (index // 2) * height))
    save_png(preview, output)
    return {"status": "success", "operation": "preview",
            "layer": workspace_relative(layer, root), "layer_sha256": sha256_file(layer),
            "output": workspace_relative(output, root), "output_sha256": sha256_file(output)}


def gray_export_command(args: argparse.Namespace) -> dict:
    root = args.workspace_root.resolve()
    layer = workspace_path(args.layer, root, must_exist=True)
    output, request_root = prepare_output(args.output, root)
    require_source(layer, root, request_root)
    with Image.open(layer) as opened:
        opened.load()
        rgba = opened.convert("RGBA")
    require(rgba.getchannel("A").getextrema()[0] < 255, "gray-export requires a transparent working layer")
    background = Image.new("RGBA", rgba.size, (128, 128, 128, 255))
    background.alpha_composite(rgba)
    save_png(background, output)
    return {"status": "success", "operation": "gray-export",
            "layer": workspace_relative(layer, root), "layer_sha256": sha256_file(layer),
            "output": workspace_relative(output, root), "output_sha256": sha256_file(output),
            "background": "#808080"}


def recompose_command(args: argparse.Namespace) -> dict:
    root = args.workspace_root.resolve()
    manifest_path = workspace_path(args.manifest, root, must_exist=True)
    output, request_root = prepare_output(args.output, root)
    require_source(manifest_path, root, request_root)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    source_path = stored_workspace_path(str(manifest.get("source_image", "")), root, must_exist=True)
    require_source(source_path, root, request_root)
    require(str(manifest.get("source_sha256", "")) == sha256_file(source_path), "manifest source_sha256 does not match source_image")
    baseline_path = root / "project" / "baselines" / "project-visual-standard.md"
    baseline_result: dict[str, object] | None = None
    declared_value = str(manifest.get("baseline_source", "")).strip()
    baseline_fields_present = any(key in manifest for key in ("baseline_sha256", "baseline_floor_ids", "baseline_overrides"))
    if declared_value:
        require(baseline_path.is_file(), "manifest declares Baseline use but no formal Baseline exists")
        declared_baseline = stored_workspace_path(declared_value, root, must_exist=True)
        require(declared_baseline == baseline_path.resolve(), "manifest baseline_source must point to the formal project Baseline")
        require(str(manifest.get("baseline_sha256", "")) == sha256_file(declared_baseline), "manifest baseline_sha256 does not match the formal Baseline")
        baseline_floor_ids = manifest.get("baseline_floor_ids")
        baseline_overrides = manifest.get("baseline_overrides")
        require(isinstance(baseline_floor_ids, list) and all(isinstance(item, str) and item for item in baseline_floor_ids), "manifest baseline_floor_ids must be a string array")
        require(len(set(baseline_floor_ids)) == len(baseline_floor_ids), "manifest baseline_floor_ids must be unique")
        require(isinstance(baseline_overrides, list), "manifest baseline_overrides must be an array")
        consumer_path = request_root / "work" / "baseline-consumption.json"
        require(consumer_path.is_file(), "canonical work/baseline-consumption.json is required when Baseline is used")
        consumer_record = json.loads(consumer_path.read_text(encoding="utf-8"))
        require(isinstance(consumer_record, dict), "Baseline consumer record must be an object")
        require(consumer_record.get("baseline_sha256") == sha256_file(baseline_path), "consumer record baseline_sha256 mismatch")
        require(consumer_record.get("consumer") == "layer-decomposition", "consumer record must target layer-decomposition")
        consumed_floor_ids = consumer_record.get("floor_ids", [])
        require(isinstance(consumed_floor_ids, list) and all(isinstance(item, str) and item for item in consumed_floor_ids), "consumer record floor_ids must be a string array")
        require(len(set(consumed_floor_ids)) == len(consumed_floor_ids), "consumer record floor_ids must be unique")
        relevant_ids = layer_baseline_floor_ids(baseline_path)
        require(set(consumed_floor_ids).issubset(relevant_ids), "consumer record contains unknown Baseline floors")
        require(set(baseline_floor_ids) == set(consumed_floor_ids), "manifest baseline_floor_ids must match the floors actually consumed")
        consumed_overrides = consumer_record.get("overrides", [])
        require(isinstance(consumed_overrides, list) and all(isinstance(item, dict) for item in consumed_overrides), "consumer record overrides must be an object array")
        consumed_override_ids = {str(item.get("floor_id", "")) for item in consumed_overrides}
        require(all(consumed_override_ids), "consumer override floor_id values must be non-empty")
        require(consumed_override_ids.issubset(relevant_ids), "consumer override contains unknown Baseline floors")
        override_manifest_ids = {str(item.get("floor_id", "")) if isinstance(item, dict) else str(item) for item in baseline_overrides}
        require(override_manifest_ids == consumed_override_ids, "manifest baseline_overrides must match the actual user overrides")
        baseline_result = {"source": workspace_relative(declared_baseline, root), "sha256": sha256_file(declared_baseline),
                           "floor_ids": baseline_floor_ids, "overrides": baseline_overrides}
    else:
        require(not baseline_fields_present, "baseline fields require baseline_source")
    canvas_size = manifest.get("delivery_canvas_size")
    layers = manifest.get("layers")
    require(isinstance(canvas_size, list) and len(canvas_size) == 2 and all(isinstance(item, int) and item > 0 for item in canvas_size), "manifest requires positive delivery_canvas_size")
    require(isinstance(layers, list) and layers, "manifest requires non-empty layers")
    require(all(isinstance(item, dict) for item in layers), "manifest layers must be objects")
    ids = [str(item.get("layer_id", "")) for item in layers]
    require(len(ids) == len(layers) and all(ids) and len(set(ids)) == len(ids), "layer_id values must be present and unique")
    orders = [item.get("z_order") for item in layers]
    require(all(isinstance(item, int) and not isinstance(item, bool) for item in orders), "z_order values must be integers")
    require(len(set(orders)) == len(orders), "z_order values must be unique")
    dependencies: dict[str, list[str]] = {}
    for entry in layers:
        require("status" in entry and "dependencies" in entry and "blend_mode" in entry, f"layer requires status, dependencies, and blend_mode: {entry['layer_id']}")
        raw_dependencies = entry["dependencies"]
        require(isinstance(raw_dependencies, list) and all(isinstance(item, str) for item in raw_dependencies), f"dependencies must be a string array: {entry['layer_id']}")
        require(all(item in ids for item in raw_dependencies), f"dependency references an unknown layer: {entry['layer_id']}")
        require(entry["layer_id"] not in raw_dependencies, f"layer depends on itself: {entry['layer_id']}")
        dependencies[entry["layer_id"]] = raw_dependencies
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(layer_id: str) -> None:
        require(layer_id not in visiting, f"layer dependencies contain a cycle at: {layer_id}")
        if layer_id in visited:
            return
        visiting.add(layer_id)
        for dependency in dependencies[layer_id]:
            visit(dependency)
        visiting.remove(layer_id)
        visited.add(layer_id)

    for layer_id in ids:
        visit(layer_id)
    canvas = Image.new("RGBA", tuple(canvas_size), (0, 0, 0, 0))
    used: list[dict[str, object]] = []
    for entry in sorted(layers, key=lambda item: int(item.get("z_order", 0))):
        require(entry["status"] == "passed", f"layer is not passed: {entry['layer_id']}")
        require(entry["blend_mode"] == "normal", f"unsupported blend mode for deterministic recomposition: {entry.get('blend_mode')}")
        layer_path = stored_workspace_path(str(entry.get("file", "")), root, must_exist=True)
        require_source(layer_path, root, request_root)
        require(layer_path.suffix.lower() == ".png", f"layer file must be PNG: {entry['layer_id']}")
        require(str(entry.get("sha256", "")) == sha256_file(layer_path), f"manifest sha256 does not match layer file: {entry['layer_id']}")
        with Image.open(layer_path) as opened:
            opened.load()
            require("A" in opened.getbands(), f"layer file has no alpha channel: {entry['layer_id']}")
            layer = opened.convert("RGBA")
        mode = str(entry.get("output_mode", ""))
        require(mode == "delivery-canvas", f"formal recomposition only accepts delivery-canvas layers: {entry['layer_id']}")
        require(layer.size == tuple(canvas_size), f"delivery-canvas size mismatch: {entry['layer_id']}")
        require(entry.get("anchor") == [0, 0], f"delivery-canvas anchor must be [0, 0]: {entry['layer_id']}")
        position = (0, 0)
        canvas.alpha_composite(layer, position)
        used.append({"layer_id": entry["layer_id"], "file": workspace_relative(layer_path, root),
                     "sha256": sha256_file(layer_path), "position": list(position)})
    save_png(canvas, output)
    return {"status": "success", "operation": "recompose",
            "manifest": workspace_relative(manifest_path, root), "manifest_sha256": sha256_file(manifest_path),
            "baseline": baseline_result, "output": workspace_relative(output, root),
            "output_sha256": sha256_file(output), "layers": used}


def compare_command(args: argparse.Namespace) -> dict:
    root = args.workspace_root.resolve()
    source = workspace_path(args.source, root, must_exist=True)
    recomposed = workspace_path(args.recomposed, root, must_exist=True)
    diff_output, request_root = prepare_output(args.diff_output, root)
    report = workspace_path(args.report, root)
    require(request_root_from_work(report, root) == request_root and not report.exists(), "report must be a new file in the same request work directory")
    for path in (source, recomposed):
        require_source(path, root, request_root)
    with Image.open(source) as opened:
        opened.load()
        before = opened.convert("RGBA")
    with Image.open(recomposed) as opened:
        opened.load()
        after = opened.convert("RGBA")
    require(before.size == after.size, "source and recomposition sizes differ")
    raw_diff = ImageChops.difference(before, after)
    evaluation_mask = None
    evaluation_mask_path = None
    if args.evaluation_mask:
        evaluation_mask_path = workspace_path(args.evaluation_mask, root, must_exist=True)
        require_source(evaluation_mask_path, root, request_root)
        with Image.open(evaluation_mask_path) as opened:
            opened.load()
            require(opened.size == before.size, "evaluation mask size differs from source")
            if "A" in opened.getbands():
                evaluation_mask = opened.getchannel("A")
            else:
                evaluation_mask = opened.convert("L")
        require(evaluation_mask.getbbox() is not None, "evaluation mask selects no pixels")
        transparent = Image.new("RGBA", before.size, (0, 0, 0, 0))
        diff = Image.composite(raw_diff, transparent, evaluation_mask)
        mean_channels = ImageStat.Stat(raw_diff, mask=evaluation_mask).mean
        mean_abs = sum(mean_channels) / len(mean_channels)
    else:
        diff = raw_diff
        histogram = diff.histogram()
        total_channels = before.width * before.height * 4
        weighted = sum((index % 256) * count for index, count in enumerate(histogram))
        mean_abs = weighted / total_channels
    save_png(diff, diff_output)
    # RGBA Image.getbbox() can miss RGB-only differences when the diff alpha band is zero.
    # Build a one-band changed-pixel map so pixel_identical is a true byte/content fact.
    changed_pixels = Image.new("L", raw_diff.size, 0)
    for band in ("R", "G", "B", "A"):
        band_changed = raw_diff.getchannel(band).point(lambda value: 255 if value else 0)
        changed_pixels = ImageChops.lighter(changed_pixels, band_changed)
    if evaluation_mask is not None:
        changed_pixels = ImageChops.multiply(changed_pixels, evaluation_mask.point(lambda value: 255 if value else 0))
    changed_bbox = changed_pixels.getbbox()
    value = {
        "source": workspace_relative(source, root), "source_sha256": sha256_file(source),
        "recomposed": workspace_relative(recomposed, root), "recomposed_sha256": sha256_file(recomposed),
        "diff": workspace_relative(diff_output, root), "diff_sha256": sha256_file(diff_output),
        "evaluation_mask": workspace_relative(evaluation_mask_path, root) if evaluation_mask_path else None,
        "evaluation_mask_sha256": sha256_file(evaluation_mask_path) if evaluation_mask_path else None,
        "mean_absolute_channel_difference": mean_abs,
        "changed_bbox": list(changed_bbox) if changed_bbox else None,
        "pixel_identical": changed_bbox is None,
        "professional_visual_review_required": True,
    }
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"status": "success", "operation": "compare",
            "report": workspace_relative(report, root), **value}



def _load_rgba(path: Path) -> Image.Image:
    with Image.open(path) as opened:
        opened.load()
        return opened.convert("RGBA")


def _edge_pad_rgba(image: Image.Image, size: tuple[int, int]) -> Image.Image:
    """Origin-preserving edge extension. Content pixels are never stretched for alignment padding."""
    width, height = size
    require(width >= image.width and height >= image.height, "work surface cannot be smaller than resized content")
    out = Image.new("RGBA", size, (0, 0, 0, 0))
    out.paste(image, (0, 0))
    if width > image.width:
        edge = image.crop((image.width - 1, 0, image.width, image.height)).resize((width - image.width, image.height))
        out.paste(edge, (image.width, 0))
    if height > image.height:
        row = out.crop((0, image.height - 1, width, image.height)).resize((width, height - image.height))
        out.paste(row, (0, image.height))
    return out


def prepare_work_surface_command(args: argparse.Namespace) -> dict:
    root = args.workspace_root.resolve()
    source = workspace_path(args.source, root, must_exist=True)
    output, request_root = prepare_output(args.output, root)
    record = workspace_path(args.record_output, root)
    require(request_root_from_work(record, root) == request_root, "work-surface image and record must use the same request work directory")
    require(not record.exists(), f"output already exists: {record}")
    record.parent.mkdir(parents=True, exist_ok=True)
    require_source(source, root, request_root)
    with Image.open(source) as opened:
        opened.load()
        source_mode = opened.mode
        image = opened.convert("RGBA")
    skill = SKILL_UI if args.profile == "game-ui" else SKILL_IMAGE
    delivery_size = None
    if args.delivery:
        m = re.fullmatch(r"([1-9]\d*)x([1-9]\d*)", args.delivery.strip().lower())
        require(m is not None, "delivery must be WIDTHxHEIGHT")
        delivery_size = tuple(map(int, m.groups()))
    contract = plan_size_contract(
        image.size, skill=skill, model=args.model, delivery_size=delivery_size,
        preferred_work_scale=args.preferred_work_scale,
    )
    surface = contract["work_surfaces"][0]
    content_size = (int(surface["content_width"]), int(surface["content_height"]))
    work_size = (int(surface["width"]), int(surface["height"]))
    content = image if content_size == image.size else image.resize(content_size, Image.Resampling.LANCZOS)
    work_image = _edge_pad_rgba(content, work_size)
    save_png(work_image, output)
    value = {
        "schema_version": "wxian.decomposition-work-surface.v2",
        "source_image": workspace_relative(source, root),
        "source_sha256": sha256_file(source),
        "source_mode": source_mode,
        "work_image": workspace_relative(output, root),
        "work_sha256": sha256_file(output),
        "size_contract": contract,
    }
    record.parent.mkdir(parents=True, exist_ok=True)
    record.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"status": "success", "operation": "prepare-work-surface", "record": workspace_relative(record, root), **value}



def prepare_delivery_reference_command(args: argparse.Namespace) -> dict:
    """Create the authoritative delivery-space source reference directly from source pixels.

    Never route source-visible fidelity through the model work surface. If delivery
    equals source, RGB pixels are preserved exactly (RGBA alpha is added only when
    absent). If the user explicitly requests a different delivery size, resample
    source exactly once into delivery space and record that fact.
    """
    root = args.workspace_root.resolve()
    source = workspace_path(args.source, root, must_exist=True)
    contract_path = workspace_path(args.size_contract, root, must_exist=True)
    output, request_root = prepare_output(args.output, root)
    require_source(source, root, request_root)
    require_source(contract_path, root, request_root)
    raw = json.loads(contract_path.read_text(encoding="utf-8"))
    if raw.get("schema_version") == "wxian.decomposition-work-surface.v2":
        require(raw.get("source_image") == workspace_relative(source, root),
                "decomposition size record is bound to another source image")
        require(raw.get("source_sha256") == sha256_file(source),
                "decomposition size record source hash is stale")
        value = raw.get("size_contract")
    else:
        value = raw
    require(isinstance(value, dict), "size contract record is invalid")
    with Image.open(source) as opened:
        opened.load(); image = opened.convert("RGBA")
    contract = validate_size_contract(value, source_size=image.size)
    delivery = contract["delivery_canvas"]
    delivery_size = (int(delivery["width"]), int(delivery["height"]))
    if image.size == delivery_size:
        result = image.copy(); mode = "source_exact"
    else:
        result = image.resize(delivery_size, Image.Resampling.LANCZOS); mode = "explicit_delivery_resample"
    save_png(result, output)
    return {
        "status": "success", "operation": "prepare-delivery-reference",
        "source_image": workspace_relative(source, root), "source_sha256": sha256_file(source),
        "source_size": list(image.size), "delivery_size": list(delivery_size), "mode": mode,
        "size_contract": workspace_relative(contract_path, root), "size_contract_sha256": sha256_file(contract_path),
        "output": workspace_relative(output, root), "output_sha256": sha256_file(output),
    }

def project_work_to_delivery_command(args: argparse.Namespace) -> dict:
    root = args.workspace_root.resolve()
    source = workspace_path(args.source, root, must_exist=True)
    contract_path = workspace_path(args.size_contract, root, must_exist=True)
    output, request_root = prepare_output(args.output, root)
    require_source(source, root, request_root)
    require_source(contract_path, root, request_root)
    value = json.loads(contract_path.read_text(encoding="utf-8"))
    if value.get("schema_version") == "wxian.decomposition-work-surface.v2":
        value = value.get("size_contract")
    require(isinstance(value, dict), "size contract record is invalid")
    contract = validate_size_contract(value)
    surface = contract["work_surfaces"][0]
    delivery = contract["delivery_canvas"]
    with Image.open(source) as opened:
        opened.load()
        image = opened.convert("RGBA")
    require(image.size == (int(surface["width"]), int(surface["height"])), "work result size does not match work surface")
    content = image.crop((0, 0, int(surface["content_width"]), int(surface["content_height"])))
    delivery_size = (int(delivery["width"]), int(delivery["height"]))
    if content.size != delivery_size:
        content = content.resize(delivery_size, Image.Resampling.LANCZOS)
    save_png(content, output)
    return {
        "status": "success", "operation": "project-work-to-delivery",
        "source": workspace_relative(source, root), "source_sha256": sha256_file(source),
        "size_contract": workspace_relative(contract_path, root), "size_contract_sha256": sha256_file(contract_path),
        "output": workspace_relative(output, root), "output_sha256": sha256_file(output),
        "delivery_size": list(delivery_size),
    }


def alpha_audit_command(args: argparse.Namespace) -> dict:
    root = args.workspace_root.resolve()
    layer = workspace_path(args.layer, root, must_exist=True)
    report = workspace_path(args.report, root)
    request_root = request_root_from_work(report, root)
    require(not report.exists(), f"report already exists: {report}")
    require_source(layer, root, request_root)
    with Image.open(layer) as opened:
        opened.load()
        source_mode = opened.mode
        has_alpha = "A" in opened.getbands() or "transparency" in opened.info
        rgba = opened.convert("RGBA")
    require(has_alpha, "layer has no alpha channel/transparency information")
    alpha = rgba.getchannel("A")
    extrema = alpha.getextrema()
    bbox = alpha.getbbox()
    require(bbox is not None and extrema[1] > 0, "layer is fully transparent")
    require(extrema[0] < 255, "layer is fully opaque; transparent layer expected")
    hist = alpha.histogram()
    total = rgba.width * rgba.height
    transparent = hist[0]
    opaque = hist[255]
    semitransparent = total - transparent - opaque
    value = {
        "layer": workspace_relative(layer, root),
        "sha256": sha256_file(layer),
        "size": list(rgba.size),
        "source_mode": source_mode,
        "has_alpha": True,
        "alpha_min": extrema[0],
        "alpha_max": extrema[1],
        "transparent_pixels": transparent,
        "opaque_pixels": opaque,
        "semitransparent_pixels": semitransparent,
        "transparent_ratio": transparent / total,
        "opaque_ratio": opaque / total,
        "semitransparent_ratio": semitransparent / total,
        "bbox": list(bbox),
        "status": "passed",
    }
    report.parent.mkdir(parents=True, exist_ok=True)
    report.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"status": "success", "operation": "alpha-audit", "report": workspace_relative(report, root), **value}


def source_lock_command(args: argparse.Namespace) -> dict:
    root = args.workspace_root.resolve()
    source = workspace_path(args.source, root, must_exist=True)
    carrier = workspace_path(args.alpha_carrier, root, must_exist=True)
    output, request_root = prepare_output(args.output, root)
    for path in (source, carrier):
        require_source(path, root, request_root)
    src = _load_rgba(source)
    alpha_source = _load_rgba(carrier)
    require(src.size == alpha_source.size, "source and alpha-carrier sizes differ")
    carrier_alpha = alpha_source.getchannel("A")
    require(carrier_alpha.getbbox() is not None and carrier_alpha.getextrema()[0] < 255,
            "alpha-carrier must contain a non-empty transparent extraction")
    combined_alpha = ImageChops.multiply(src.getchannel("A"), carrier_alpha)
    result = src.copy()
    result.putalpha(combined_alpha)
    save_png(result, output)
    return {
        "status": "success", "operation": "source-lock",
        "source": workspace_relative(source, root), "source_sha256": sha256_file(source),
        "alpha_carrier": workspace_relative(carrier, root), "alpha_carrier_sha256": sha256_file(carrier),
        "output": workspace_relative(output, root), "output_sha256": sha256_file(output),
        "size": list(result.size), "bbox": list(combined_alpha.getbbox()) if combined_alpha.getbbox() else None,
    }


def merge_reconstruction_command(args: argparse.Namespace) -> dict:
    root = args.workspace_root.resolve()
    visible_path = workspace_path(args.visible, root, must_exist=True)
    reconstruction_path = workspace_path(args.reconstruction, root, must_exist=True)
    output, request_root = prepare_output(args.output, root)
    for path in (visible_path, reconstruction_path):
        require_source(path, root, request_root)
    visible = _load_rgba(visible_path)
    reconstruction = _load_rgba(reconstruction_path)
    require(visible.size == reconstruction.size, "visible and reconstruction sizes differ")
    va = visible.getchannel("A")
    ra = reconstruction.getchannel("A")
    require(va.getbbox() is not None, "visible layer is empty")
    require(ra.getbbox() is not None, "reconstruction layer is empty")
    # Remove reconstruction contribution wherever authoritative visible pixels exist.
    inv_va = ImageChops.invert(va)
    reconstruction_only = reconstruction.copy()
    reconstruction_only.putalpha(ImageChops.multiply(ra, inv_va))
    merged = reconstruction_only.copy()
    merged.alpha_composite(visible)
    save_png(merged, output)
    hidden_alpha = reconstruction_only.getchannel("A")
    return {
        "status": "success", "operation": "merge-reconstruction",
        "visible": workspace_relative(visible_path, root), "visible_sha256": sha256_file(visible_path),
        "reconstruction": workspace_relative(reconstruction_path, root), "reconstruction_sha256": sha256_file(reconstruction_path),
        "output": workspace_relative(output, root), "output_sha256": sha256_file(output),
        "size": list(merged.size),
        "visible_bbox": list(va.getbbox()) if va.getbbox() else None,
        "reconstructed_only_bbox": list(hidden_alpha.getbbox()) if hidden_alpha.getbbox() else None,
    }


def mask_union_command(args: argparse.Namespace) -> dict:
    root = args.workspace_root.resolve()
    layer_paths = [workspace_path(value, root, must_exist=True) for value in args.layers]
    output, request_root = prepare_output(args.output, root)
    require(layer_paths, "mask-union requires at least one layer")
    alphas: list[Image.Image] = []
    size: tuple[int, int] | None = None
    for path in layer_paths:
        require_source(path, root, request_root)
        rgba = _load_rgba(path)
        if size is None:
            size = rgba.size
        require(rgba.size == size, "all mask-union layers must share the same canvas")
        alphas.append(rgba.getchannel("A"))
    union = alphas[0]
    for alpha in alphas[1:]:
        union = ImageChops.lighter(union, alpha)
    if args.expand:
        kernel = args.expand * 2 + 1
        require(kernel <= 255, "expand is too large")
        union = union.filter(ImageFilter.MaxFilter(kernel))
    if args.feather:
        union = union.filter(ImageFilter.GaussianBlur(args.feather))
    require(union.getbbox() is not None, "mask-union result is empty")
    mask_rgba = Image.new("RGBA", union.size, (255, 255, 255, 0))
    mask_rgba.putalpha(union)
    save_png(mask_rgba, output)
    return {
        "status": "success", "operation": "mask-union",
        "layers": [workspace_relative(path, root) for path in layer_paths],
        "layer_sha256": [sha256_file(path) for path in layer_paths],
        "expand": args.expand, "feather": args.feather,
        "output": workspace_relative(output, root), "output_sha256": sha256_file(output),
        "size": list(union.size), "bbox": list(union.getbbox()) if union.getbbox() else None,
    }


def patch_clean_plate_command(args: argparse.Namespace) -> dict:
    root = args.workspace_root.resolve()
    source_path = workspace_path(args.source, root, must_exist=True)
    generated_path = workspace_path(args.generated, root, must_exist=True)
    mask_path = workspace_path(args.mask, root, must_exist=True)
    output, request_root = prepare_output(args.output, root)
    for path in (source_path, generated_path, mask_path):
        require_source(path, root, request_root)
    source = _load_rgba(source_path)
    generated = _load_rgba(generated_path)
    mask_rgba = _load_rgba(mask_path)
    require(source.size == generated.size == mask_rgba.size, "source/generated/mask sizes differ")
    mask = mask_rgba.getchannel("A")
    require(mask.getbbox() is not None, "clean-plate patch mask is empty")
    result = Image.composite(generated, source, mask)
    save_png(result, output)
    return {
        "status": "success", "operation": "patch-clean-plate",
        "source": workspace_relative(source_path, root), "source_sha256": sha256_file(source_path),
        "generated": workspace_relative(generated_path, root), "generated_sha256": sha256_file(generated_path),
        "mask": workspace_relative(mask_path, root), "mask_sha256": sha256_file(mask_path),
        "output": workspace_relative(output, root), "output_sha256": sha256_file(output),
        "size": list(result.size), "patch_bbox": list(mask.getbbox()) if mask.getbbox() else None,
    }


def regions_mask_command(args: argparse.Namespace) -> dict:
    root = args.workspace_root.resolve()
    regions_path = workspace_path(args.regions_json, root, must_exist=True)
    output, request_root = prepare_output(args.output, root)
    require_source(regions_path, root, request_root)
    match = re.fullmatch(r"([1-9]\d*)x([1-9]\d*)", args.size.strip().lower())
    require(match is not None, "size must be WIDTHxHEIGHT")
    width, height = map(int, match.groups())
    raw = json.loads(regions_path.read_text(encoding="utf-8"))
    regions = raw.get("regions") if isinstance(raw, dict) else raw
    require(isinstance(regions, list), "regions JSON must be an array or {regions:[...]}")
    mask = Image.new("L", (width, height), 255 if args.mode == "exclude" else 0)
    draw = ImageDraw.Draw(mask)
    fill = 0 if args.mode == "exclude" else 255
    for index, item in enumerate(regions):
        bbox = item.get("bbox") if isinstance(item, dict) else item
        require(isinstance(bbox, list) and len(bbox) == 4, f"region[{index}] must be [x,y,w,h] or {{bbox:[...]}}")
        require(all(isinstance(v, int) and not isinstance(v, bool) for v in bbox), f"region[{index}] bbox must be integers")
        x, y, w, h = bbox
        require(x >= 0 and y >= 0 and w > 0 and h > 0 and x + w <= width and y + h <= height, f"region[{index}] outside canvas")
        draw.rectangle((x, y, x + w - 1, y + h - 1), fill=fill)
    if args.expand:
        kernel = args.expand * 2 + 1
        require(kernel <= 255, "expand is too large")
        mask = mask.filter(ImageFilter.MaxFilter(kernel) if args.mode == "include" else ImageFilter.MinFilter(kernel))
    if args.feather:
        mask = mask.filter(ImageFilter.GaussianBlur(args.feather))
    rgba = Image.new("RGBA", mask.size, (255, 255, 255, 0)); rgba.putalpha(mask)
    save_png(rgba, output)
    return {
        "status": "success", "operation": "regions-mask", "mode": args.mode,
        "regions_json": workspace_relative(regions_path, root), "regions_sha256": sha256_file(regions_path),
        "output": workspace_relative(output, root), "output_sha256": sha256_file(output),
        "size": [width, height], "region_count": len(regions),
    }


def ownership_audit_command(args: argparse.Namespace) -> dict:
    root = args.workspace_root.resolve()
    manifest_path = workspace_path(args.manifest, root, must_exist=True)
    overlap_output, request_root = prepare_output(args.overlap_output, root)
    hole_output = workspace_path(args.hole_output, root)
    report = workspace_path(args.report, root)
    for path in (hole_output, report):
        require(request_root_from_work(path, root) == request_root and not path.exists(), "ownership outputs must be new files in the same request work directory")
        path.parent.mkdir(parents=True, exist_ok=True)
    require_source(manifest_path, root, request_root)
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    canvas_size = manifest.get("delivery_canvas_size")
    require(isinstance(canvas_size, list) and len(canvas_size) == 2 and all(isinstance(v, int) and v > 0 for v in canvas_size), "manifest delivery_canvas_size invalid")
    layers = manifest.get("layers")
    require(isinstance(layers, list) and layers, "manifest layers missing")
    threshold = int(args.threshold)
    require(0 <= threshold <= 254, "threshold must be 0..254")
    coverage = Image.new("L", tuple(canvas_size), 0)
    overlap_binary = Image.new("L", tuple(canvas_size), 0)
    audited = 0
    for entry in layers:
        if not isinstance(entry, dict) or not entry.get("primary_pixel_owner"):
            continue
        mask_value = str(entry.get("source_visible_mask", "")).strip()
        require(mask_value, f"primary owner layer missing source_visible_mask: {entry.get('layer_id')}")
        mask_path = stored_workspace_path(mask_value, root, must_exist=True)
        require_source(mask_path, root, request_root)
        mask_rgba = _load_rgba(mask_path)
        require(mask_rgba.size == tuple(canvas_size), f"source_visible_mask canvas mismatch: {entry.get('layer_id')}")
        alpha = mask_rgba.getchannel("A")
        binary = alpha.point(lambda v: 255 if v > threshold else 0, mode="L")
        # Ownership is categorical: detect duplicate source-visible ownership before
        # unioning this layer. Using L masks avoids Pillow ImageChops mode limits
        # while preserving an exact overlap/hole diagnostic.
        duplicate = ImageChops.multiply(coverage, binary)
        overlap_binary = ImageChops.lighter(overlap_binary, duplicate)
        coverage = ImageChops.lighter(coverage, binary)
        audited += 1
    require(audited > 0, "ownership audit found no primary owner masks")
    overlap_pixels = sum(overlap_binary.histogram()[1:])
    holes = ImageChops.invert(coverage)
    hole_pixels = sum(holes.histogram()[1:])
    for img, path in ((overlap_binary, overlap_output), (holes, hole_output)):
        rgba = Image.new("RGBA", img.size, (255, 255, 255, 0)); rgba.putalpha(img); save_png(rgba, path)
    result = {
        "status": "passed" if overlap_pixels == 0 and hole_pixels == 0 else "failed",
        "operation": "ownership-audit", "threshold": threshold, "primary_owner_layer_count": audited,
        "overlap_pixels": overlap_pixels, "hole_pixels": hole_pixels,
        "overlap_bbox": list(overlap_binary.getbbox()) if overlap_binary.getbbox() else None,
        "hole_bbox": list(holes.getbbox()) if holes.getbbox() else None,
        "overlap_output": workspace_relative(overlap_output, root), "overlap_sha256": sha256_file(overlap_output),
        "hole_output": workspace_relative(hole_output, root), "hole_sha256": sha256_file(hole_output),
    }
    report.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    result["report"] = workspace_relative(report, root); result["report_sha256"] = sha256_file(report)
    return result


def crop_command(args: argparse.Namespace) -> dict:
    root = args.workspace_root.resolve()
    layer_path = workspace_path(args.layer, root, must_exist=True)
    output, request_root = prepare_output(args.output, root)
    require_source(layer_path, root, request_root)
    layer = _load_rgba(layer_path)
    bbox = layer.getchannel("A").getbbox()
    require(bbox is not None, "cannot crop a fully transparent layer")
    padding = max(0, int(args.padding))
    x0 = max(0, bbox[0] - padding)
    y0 = max(0, bbox[1] - padding)
    x1 = min(layer.width, bbox[2] + padding)
    y1 = min(layer.height, bbox[3] + padding)
    crop_box = (x0, y0, x1, y1)
    save_png(layer.crop(crop_box), output)
    value = {
        "source_layer": workspace_relative(layer_path, root), "source_sha256": sha256_file(layer_path),
        "source_canvas_size": list(layer.size), "visible_bbox": list(bbox),
        "crop_bbox": list(crop_box), "anchor": [x0, y0], "padding": padding,
        "output": workspace_relative(output, root), "output_sha256": sha256_file(output),
        "crop_size": [x1 - x0, y1 - y0],
    }
    record.parent.mkdir(parents=True, exist_ok=True)
    record.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"status": "success", "operation": "crop", "record": workspace_relative(record, root), **value}


def finalize_editable_master_command(args: argparse.Namespace) -> dict:
    """Create the only PSD-embeddable original from a verified final layer crop."""
    root = args.workspace_root.resolve()
    layer = workspace_path(args.layer, root, must_exist=True)
    output, request_root = prepare_output(args.output, root)
    record = workspace_path(args.record_output, root)
    require(not record.exists(), f"output already exists: {record}")
    require(request_root_from_work(record, root) == request_root, "master receipt must stay in the same request work directory")
    record.parent.mkdir(parents=True, exist_ok=True)
    final = request_root / "work" / "final"
    originals = (final / "originals").resolve()
    provider = (originals / "provider").resolve()
    require(output.parent == originals, "editable master output must be directly inside work/final/originals/")
    require_source(layer, root, request_root)
    raw_paths = [workspace_path(value, root, must_exist=True) for value in args.provider_original]
    require(raw_paths, "at least one selected provider original is required")
    for raw in raw_paths:
        require(provider in raw.parents, "provider original must be inside work/final/originals/provider/")
        require_source(raw, root, request_root)
    x, y, width, height = args.bbox
    require(x >= 0 and y >= 0 and width > 0 and height > 0, "bbox must be [x,y,w,h] with positive size")
    require(0.0 < args.minimum_visible_coverage_ratio <= 1.0,
            "minimum-visible-coverage-ratio must be in (0,1]")
    image = _load_rgba(layer)
    require(x + width <= image.width and y + height <= image.height, "bbox exceeds final layer canvas")
    alpha = image.getchannel("A").point(lambda value: 255 if value >= 16 else 0)
    alpha_bbox = alpha.getbbox()
    require(alpha_bbox is not None, "final layer has no visible alpha at threshold 16")
    require(alpha_bbox[0] >= x and alpha_bbox[1] >= y and alpha_bbox[2] <= x + width and alpha_bbox[3] <= y + height,
            "final layer alpha escapes declared bbox")
    master = image.crop((x, y, x + width, y + height))
    visible_pixels = sum(value >= 16 for value in master.getchannel("A").getdata())
    require(visible_pixels >= math.ceil(width * height * args.minimum_visible_coverage_ratio),
            "final layer visible coverage is below analyzed minimum")
    save_png(master, output)
    sources = []
    for raw in raw_paths:
        with Image.open(raw) as opened:
            opened.load()
            raw_size = list(opened.size)
        sources.append({"file": workspace_relative(raw, root), "sha256": sha256_file(raw), "size": raw_size})
    value = {
        "status": "success", "operation": "finalize-editable-master-v1", "layer_id": args.layer_id,
        "file": workspace_relative(output, root), "sha256": sha256_file(output), "size": [width, height],
        "provider_originals": sources,
        "derivation": {"operation": "delivery_bbox_crop_v1", "source_canvas_file": workspace_relative(layer, root),
                       "source_canvas_sha256": sha256_file(layer), "crop_bbox": [x, y, width, height]},
        "minimum_visible_coverage_ratio": args.minimum_visible_coverage_ratio,
        "visible_pixel_count": visible_pixels,
    }
    record.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    value["record"] = workspace_relative(record, root)
    return value


def doctor_command() -> dict:
    source = Image.new("RGBA", (64, 48), (20, 30, 40, 255))
    carrier = Image.new("RGBA", source.size, (255, 255, 255, 0))
    alpha = carrier.getchannel("A")
    ImageDraw.Draw(alpha).rectangle((8, 8, 31, 31), fill=255)
    carrier.putalpha(alpha)
    locked = source.copy()
    locked.putalpha(ImageChops.multiply(source.getchannel("A"), carrier.getchannel("A")))
    require(locked.getchannel("A").getbbox() == (8, 8, 32, 32), "source-lock alpha check failed")
    reconstruction = Image.new("RGBA", source.size, (100, 110, 120, 0))
    recon_alpha = reconstruction.getchannel("A")
    ImageDraw.Draw(recon_alpha).rectangle((4, 4, 39, 39), fill=255)
    reconstruction.putalpha(recon_alpha)
    inv = ImageChops.invert(locked.getchannel("A"))
    reconstruction_only = reconstruction.copy()
    reconstruction_only.putalpha(ImageChops.multiply(reconstruction.getchannel("A"), inv))
    merged = reconstruction_only.copy()
    merged.alpha_composite(locked)
    require(merged.getpixel((10, 10))[:3] == source.getpixel((10, 10))[:3], "visible source authority check failed")
    require(merged.getpixel((5, 5))[3] > 0, "hidden reconstruction merge check failed")
    image_plan = plan_size_contract((1920, 1080), skill=SKILL_IMAGE, model="gpt-image-2.5-sunburst")
    ui_plan = plan_size_contract((1366, 768), skill=SKILL_UI, model="gpt-image-2.5-sunburst")
    image_work = image_plan["work_surfaces"][0]
    ui_work = ui_plan["work_surfaces"][0]
    require((image_work["width"], image_work["height"]) == (1920, 1088), "1x work padding contract failed")
    require((ui_work["content_width"], ui_work["content_height"]) == (2732, 1536), "UI 2x content contract failed")
    require((ui_work["width"], ui_work["height"]) == (2736, 1536), "UI work alignment contract failed")
    buffer = io.BytesIO()
    merged.save(buffer, format="PNG")
    buffer.seek(0)
    with Image.open(buffer) as check:
        check.load()
        require(check.mode == "RGBA" and check.size == source.size, "PNG round-trip failed")
    return {
        "status": "ready",
        "tool": "layer_assets",
        "capabilities": [
            "size-contract-v2", "ui-prefer-2x-work", "delivery-source-preservation", "native-alpha-audit", "source-pixel-lock",
            "hidden-reconstruction-merge", "occlusion-mask-union", "clean-plate-patch",
            "deterministic-crop-anchor", "mask-extract", "alpha-preview",
            "gray-review-export", "regions-mask", "source-visible-ownership-audit", "finalize-editable-master-v1", "manifest-recompose", "baseline-hash-guard", "pixel-diff"
        ],
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("doctor")

    prepare_work = sub.add_parser("prepare-work-surface")
    prepare_work.add_argument("--source", required=True)
    prepare_work.add_argument("--output", required=True)
    prepare_work.add_argument("--record-output", required=True)
    prepare_work.add_argument("--profile", choices=("image", "game-ui"), default="image")
    prepare_work.add_argument("--model", default="gpt-image-2.5-sunburst")
    prepare_work.add_argument("--delivery", help="optional explicit delivery WIDTHxHEIGHT; default preserves source")
    prepare_work.add_argument("--preferred-work-scale", type=float)

    delivery_ref = sub.add_parser("prepare-delivery-reference")
    delivery_ref.add_argument("--source", required=True)
    delivery_ref.add_argument("--size-contract", required=True)
    delivery_ref.add_argument("--output", required=True)

    project_work = sub.add_parser("project-work-to-delivery")
    project_work.add_argument("--source", required=True)
    project_work.add_argument("--size-contract", required=True)
    project_work.add_argument("--output", required=True)

    alpha_audit = sub.add_parser("alpha-audit")
    alpha_audit.add_argument("--layer", required=True)
    alpha_audit.add_argument("--report", required=True)

    source_lock = sub.add_parser("source-lock")
    source_lock.add_argument("--source", required=True)
    source_lock.add_argument("--alpha-carrier", required=True)
    source_lock.add_argument("--output", required=True)

    merge = sub.add_parser("merge-reconstruction")
    merge.add_argument("--visible", required=True)
    merge.add_argument("--reconstruction", required=True)
    merge.add_argument("--output", required=True)

    mask_union = sub.add_parser("mask-union")
    mask_union.add_argument("--layers", nargs="+", required=True)
    mask_union.add_argument("--output", required=True)
    mask_union.add_argument("--expand", type=int, default=0)
    mask_union.add_argument("--feather", type=float, default=0.0)

    patch = sub.add_parser("patch-clean-plate")
    patch.add_argument("--source", required=True)
    patch.add_argument("--generated", required=True)
    patch.add_argument("--mask", required=True)
    patch.add_argument("--output", required=True)

    regions = sub.add_parser("regions-mask")
    regions.add_argument("--regions-json", required=True)
    regions.add_argument("--size", required=True)
    regions.add_argument("--mode", choices=("include", "exclude"), default="include")
    regions.add_argument("--expand", type=int, default=0)
    regions.add_argument("--feather", type=float, default=0.0)
    regions.add_argument("--output", required=True)

    ownership = sub.add_parser("ownership-audit")
    ownership.add_argument("--manifest", required=True)
    ownership.add_argument("--overlap-output", required=True)
    ownership.add_argument("--hole-output", required=True)
    ownership.add_argument("--report", required=True)
    ownership.add_argument("--threshold", type=int, default=16)

    crop = sub.add_parser("crop")
    crop.add_argument("--layer", required=True)
    crop.add_argument("--output", required=True)
    crop.add_argument("--record-output", required=True)
    crop.add_argument("--padding", type=int, default=16)

    master = sub.add_parser("finalize-editable-master")
    master.add_argument("--layer", required=True)
    master.add_argument("--provider-original", action="append", required=True)
    master.add_argument("--bbox", nargs=4, type=int, required=True, metavar=("X", "Y", "WIDTH", "HEIGHT"))
    master.add_argument("--minimum-visible-coverage-ratio", type=float, required=True)
    master.add_argument("--output", required=True)
    master.add_argument("--record-output", required=True)
    master.add_argument("--layer-id", required=True)

    # Deterministic extraction and review utilities.
    extract = sub.add_parser("extract")
    extract.add_argument("--source", required=True)
    extract.add_argument("--mask", required=True)
    extract.add_argument("--source-canvas-output", required=True)
    extract.add_argument("--component-output")
    extract.add_argument("--record-output", required=True)
    extract.add_argument("--layer-id", required=True)
    extract.add_argument("--z-order", type=int, required=True)
    preview = sub.add_parser("preview")
    preview.add_argument("--layer", required=True)
    preview.add_argument("--output", required=True)
    gray = sub.add_parser("gray-export")
    gray.add_argument("--layer", required=True)
    gray.add_argument("--output", required=True)
    recompose = sub.add_parser("recompose")
    recompose.add_argument("--manifest", required=True)
    recompose.add_argument("--output", required=True)
    compare = sub.add_parser("compare")
    compare.add_argument("--source", required=True)
    compare.add_argument("--recomposed", required=True)
    compare.add_argument("--evaluation-mask", help="optional full-canvas alpha/L mask limiting fidelity scoring to source-visible pixels")
    compare.add_argument("--diff-output", required=True)
    compare.add_argument("--report", required=True)

    for command in (prepare_work, delivery_ref, project_work, alpha_audit, source_lock, merge, mask_union, patch, regions, ownership, crop, master,
                    extract, preview, gray, recompose, compare):
        command.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        handlers = {
            "prepare-work-surface": prepare_work_surface_command,
            "prepare-delivery-reference": prepare_delivery_reference_command,
            "project-work-to-delivery": project_work_to_delivery_command,
            "alpha-audit": alpha_audit_command,
            "source-lock": source_lock_command,
            "merge-reconstruction": merge_reconstruction_command,
            "mask-union": mask_union_command,
            "patch-clean-plate": patch_clean_plate_command,
            "regions-mask": regions_mask_command,
            "ownership-audit": ownership_audit_command,
            "crop": crop_command,
            "finalize-editable-master": finalize_editable_master_command,
            "extract": extract_command,
            "preview": preview_command,
            "gray-export": gray_export_command,
            "recompose": recompose_command,
            "compare": compare_command,
        }
        result = doctor_command() if args.command == "doctor" else handlers[args.command](args)
    except (LayerError, OSError, json.JSONDecodeError, ValueError) as exc:
        print(json.dumps({"status": "blocked", "reason": str(exc)}, ensure_ascii=False))
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
