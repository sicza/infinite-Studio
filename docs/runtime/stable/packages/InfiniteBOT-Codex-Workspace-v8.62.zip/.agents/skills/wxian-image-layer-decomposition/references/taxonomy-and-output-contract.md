# Composite Image Layer Taxonomy & Output Contract

## 1. Scope

接受：

```text
kv_layer_decompose
banner_layer_decompose
poster_layer_decompose
key_art_layer_decompose
character_layer_decompose
scene_layer_decompose
effect_layer_decompose
logo_layer_decompose
mixed_composite_layer_decompose
```

不接受 HUD / Game UI screenshot component decomposition；即使画面同时含场景与 UI，也路由独立 Game UI Primary。

## 2. Layer Types

```text
background-clean
background-depth
midground-environment
foreground-environment
hero-subject
supporting-character
npc-group
vehicle
building
prop
shadow
reflection
effect
text-logo-overlay
decoration-overlay
```

`hero-subject` 可以代表 interaction-bound subject unit，不等于只含人物身体。

## 3. Acquisition Strategy

```text
source_asset
source_locked_extract
source_locked_reconstruct
clean_plate_patch
model_native_alpha
verified_mask_extract
unrecoverable
```

优先顺序：

```text
真实源资产
> Source Lock + 模型 Alpha
> Source Lock + 隐藏区重建
> 模型原生 Alpha
> 纯模型重画
```

## 4. Analysis Graphs + Layer Plan v5


### Pre-prompt Graph Schemas

三个分析文件不是说明性附件，而是机器绑定的生成前证据：

```json
{
  "schema_version": "wxian.kv-layer-graph.v1",
  "status": "READY",
  "source_sha256": "...",
  "work_sha256": "...",
  "work_canvas_size": [3840, 2160],
  "nodes": [
    {"node_id": "L300_HERO_A", "kind": "interaction-bound-subject", "depth_band": "SUBJECT", "bbox": [880,360,1180,1500]}
  ],
  "edges": [
    {"type": "behind", "from": "L000_BG", "to": "L300_HERO_A"}
  ]
}
```

```json
{
  "schema_version": "wxian.kv-occlusion-graph.v1",
  "status": "READY",
  "source_sha256": "...",
  "edges": [
    {"from": "L300_HERO_A", "to": "L000_BG"}
  ]
}
```

```json
{
  "schema_version": "wxian.kv-interaction-graph.v1",
  "status": "READY",
  "source_sha256": "...",
  "clusters": [
    {
      "cluster_id": "IC_HERO_A",
      "primary_subject": "hero_A",
      "members": ["hero_A", "weapon_A", "carried_object_A"],
      "binding_reasons": ["held", "carried/direct-action-unit"]
    }
  ]
}
```

机器约束：Layer Graph 的最终 layer node 必须与 Layer Plan 的 bbox/depth 一致；Occlusion Graph 必须与 `occludes/occluded_by` 完全一致；`hero-subject` 必须绑定 `interaction_cluster_id`，其 `interaction_members` 必须与 Interaction Graph cluster 完全一致。仅写了文件名或 Hash、但内容与计划不一致，不算 `Graph before Prompt`。

`work/layer-plan.json`：

```json
{
  "schema_version": "wxian.kv-layer-plan.v6",
  "status": "READY",
  "source_image": "requests/.../input/kv.png",
  "source_sha256": "...",
  "work_source": "requests/.../work/source-work.png",
  "work_sha256": "...",
  "work_canvas_size": [3840, 2160],
  "default_model": "gpt-image-2.5-sunburst",
  "downstream_intent": "light-parallax",
  "analysis_artifacts": {
    "layer_graph": {"path": "requests/.../work/layer-graph.json", "sha256": "..."},
    "occlusion_graph": {"path": "requests/.../work/occlusion-graph.json", "sha256": "..."},
    "interaction_graph": {"path": "requests/.../work/interaction-graph.json", "sha256": "..."}
  },
  "relationships": [
    {"type": "occludes", "from": "L500_FG", "to": "L300_HERO"},
    {"type": "interaction_bound", "from": "hero", "to": "carried_crate"}
  ],
  "layers": []
}
```

### relationship.type

允许：

```text
occludes
in_front_of
behind
belongs_to
interaction_bound
receives_shadow_from
reflects
emits_effect
```

关系的 `from/to` 可以引用 layer_id，也可以引用 interaction member id；如果引用 layer_id，必须存在。

## 5. Layer Item

每层至少：

```json
{
  "layer_id": "L300_HERO_A",
  "name": "hero A interaction unit",
  "layer_type": "hero-subject",
  "depth_band": "SUBJECT",
  "z_order": 300,
  "strategy": "source_locked_reconstruct",
  "source_bbox_hint": [880, 360, 1180, 1500],
  "anchor_hint": [880, 360],
  "includes": ["hero A", "held weapon", "carried object"],
  "excludes": ["other characters", "environment", "unrelated FX"],
  "interaction_cluster_id": "IC_HERO_A",
  "interaction_members": ["hero_A", "weapon_A", "carried_object_A"],
  "bound_assets": [],
  "occluded_by": ["L500_FG_BRANCH"],
  "occludes": ["L200_MG_ENV"],
  "primary_pixel_owner": true,
  "visible_region_policy": "source_locked",
  "reconstruction_scope": "occluded parts plus motion-safe margin",
  "motion_margin_px": 32,
  "minimum_visible_coverage_ratio": 0.01,
  "motion_envelope_px": {"left": 96, "top": 48, "right": 160, "bottom": 32},
  "reconstruction_confidence": "high",
  "reconstruction_provenance": ["source-visible anatomy", "official character reference"],
  "blend_mode": "normal",
  "blend_mode_hint": "normal",
  "api_calls": []
}
```

### Coordinate and motion hints

- `source_bbox_hint=[x,y,w,h]` uses delivery-canvas coordinates and must stay inside the canvas.
- `anchor_hint=[x,y]` is the deterministic crop placement anchor and must equal the bbox top-left.
- `motion_envelope_px={left,top,right,bottom}` describes directional exposure expected from planned movement/parallax.
- `motion_margin_px` is an additional seam/safety margin; it is not a substitute for directional motion evidence.
- `minimum_visible_coverage_ratio` is the analysis-time lower bound for visible alpha pixels at threshold 16 divided by `bbox` area. It must be in `(0,1]`; a final layer below it is rejected before PSD export.

### Graph binding

`analysis_artifacts` binds the pre-prompt Layer / Occlusion / Interaction graph files by path + SHA256 **and validates their schemas/semantic consistency**. Relationship endpoints must resolve to a declared `layer_id`, `interaction_member`, or `bound_asset`; `occludes` endpoints must be layer IDs. Layer bbox/depth, occlusion edges and interaction cluster membership must agree across graph and plan. Only a graph set that satisfies these bindings is valid generation input.

## 6. API Call Item

每个模型 Pass：

```json
{
  "id": "visible",
  "mode": "image_to_image_edit",
  "model": "gpt-image-2.5-sunburst",
  "prompt_path": "requests/.../work/api-prompts/L300_HERO_A__visible.txt",
  "output_path": "requests/.../work/final/originals/provider/L300_HERO_A__visible.png",
  "base_image": "requests/.../work/source-work.png",
  "reference_images": [],
  "parameters": {
    "size": "3840x2160",
    "quality": "max",
    "background": "transparent",
    "moderation": "auto",
    "output_format": "png"
  }
}
```

最深背景 clean pass 可以 `background=opaque`。

## 7. Final Manifest

Final output layout、mandatory artifacts 与 `wxian.kv-final-layer-manifest.v2` 的**唯一规范定义**位于 [layer-execution-contracts.md](layer-execution-contracts.md) 的 `Output contract` / `Final completion contract`。

本文件只定义 taxonomy、plan 与分析语义；不得在这里维护第二份 Final Manifest 字段清单。Final Manifest 必须完整保留当前 Layer Plan Authority，并由 `delivery_gate.py` 校验；禁止使用历史字段名（例如 `full_canvas_file`）替代当前 canonical `file / sha256 / crop_file / crop_sha256` 合同。

## 8. Coordinate Contract

- 所有 full-canvas 同尺寸、同 origin `(0,0)`；
- crops 只从通过 QA 的 full-canvas 确定性裁切；
- `bbox=[x,y,w,h]` 绑定回 full-canvas；
- anchor 不能由裁切过程随意变化；
- z_order 唯一。

## 9. Ownership Contract

source-visible 像素采用唯一 Primary Owner：

- 普通连续地面归属于一个环境 owner；
- 天空归属于一个 clean/background owner；
- interaction-bound 对象归属于其主体单元；
- 可见文字归属于其正式文字/overlay owner；
- 粒子、辉光等独立效果归属于对应 FX owner。

跨层视觉影响通过 relationship / blend hint 表达。
