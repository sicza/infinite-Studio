#!/usr/bin/env python3
"""Compile and execute a finite GPT Image batch for composite-image decomposition."""
from __future__ import annotations
import os as _bytecode_guard_os, sys as _bytecode_guard_sys
_bytecode_guard_sys.dont_write_bytecode = True
_bytecode_guard_os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys
from pathlib import Path
from typing import Any

LIB = Path(__file__).resolve().parents[3] / "lib"
if str(LIB) not in sys.path:
    sys.path.insert(0, str(LIB))
from decomposition_size import validate_size_contract, SKILL_IMAGE

SCHEMA = "wxian.kv-layer-plan.v6"
LAYER_GRAPH_SCHEMA = "wxian.kv-layer-graph.v1"
OCCLUSION_GRAPH_SCHEMA = "wxian.kv-occlusion-graph.v1"
INTERACTION_GRAPH_SCHEMA = "wxian.kv-interaction-graph.v1"
GENERATION_SCHEMA = "wxian.generation-plan.v1"
PRIMARY_SKILL = "wxian-image-layer-decomposition"
PROMPT_MANIFEST_SCHEMA = "wxian.kv-layer-prompt-manifest.v1"
RECONSTRUCTION_STRATEGIES = {"source_locked_reconstruct", "clean_plate_patch", "model_native_alpha"}
ALLOWED_MODES = {"text_to_image", "reference_to_image", "image_to_image_edit"}
ALLOWED_MODELS = {"gpt-image-2.5-sunburst", "gpt-image-2.5-flare", "gpt-image-2"}
ALLOWED_LAYER_TYPES = {
    "background-clean", "background-depth", "midground-environment", "foreground-environment",
    "hero-subject", "supporting-character", "npc-group", "vehicle", "building", "prop",
    "shadow", "reflection", "effect", "text-logo-overlay", "decoration-overlay",
}
ALLOWED_DECOMPOSITION_PROFILES = {"kv-depth", "generic-composite"}
ALLOWED_DEPTH_BANDS = {"BG_DEEP", "BG_NEAR", "MG_ENV", "MG_STRUCT", "SUPPORT", "SUBJECT", "FG_ENV", "FX", "OVERLAY"}
ALLOWED_STRATEGIES = {
    "source_asset", "source_locked_extract", "source_locked_reconstruct", "clean_plate_patch",
    "model_native_alpha", "verified_mask_extract", "unrecoverable",
}
ALLOWED_CONFIDENCE = {"high", "medium", "low", "none"}
ALLOWED_VISIBLE_POLICIES = {"source_locked", "source_asset", "model_native", "none"}
ALLOWED_BLEND_HINTS = {"normal", "multiply", "screen", "additive"}
ALLOWED_RELATIONSHIPS = {"occludes", "in_front_of", "behind", "belongs_to", "interaction_bound", "receives_shadow_from", "reflects", "emits_effect"}


class BatchError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise BatchError(message)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def workspace_path(value: str | Path, root: Path, *, must_exist: bool = False) -> Path:
    candidate = Path(value)
    if not candidate.is_absolute():
        candidate = root / candidate
    path = candidate.resolve()
    root = root.resolve()
    require(path == root or root in path.parents, f"path escapes Workspace: {value}")
    if must_exist:
        require(path.is_file(), f"file does not exist: {value}")
    return path


def workspace_relative(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def find_work_root(path: Path, root: Path) -> Path:
    relative = path.resolve().relative_to(root.resolve())
    lower = [part.lower() for part in relative.parts]
    require("requests" in lower and "work" in lower, "plan must be inside requests/.../work/")
    work_index = lower.index("work", lower.index("requests") + 1)
    return root.resolve().joinpath(*relative.parts[: work_index + 1])


def load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise BatchError(f"invalid JSON at {path}: line {exc.lineno}, column {exc.colno}") from exc
    require(isinstance(value, dict), f"JSON root must be object: {path}")
    return value


def stable_json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2, sort_keys=False) + "\n"


def write_idempotent(path: Path, content: str, *, force: bool) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_text(encoding="utf-8") == content:
            return
        require(force, f"refusing to overwrite changed file without --force: {path}")
    path.write_text(content, encoding="utf-8")


def _validate_bbox(value: Any, layer_id: str, canvas: list[int]) -> None:
    require(isinstance(value, list) and len(value) == 4, f"source_bbox_hint must be [x,y,w,h]: {layer_id}")
    require(all(isinstance(x, int) and not isinstance(x, bool) for x in value), f"source_bbox_hint must be integers: {layer_id}")
    x, y, w, h = value
    require(x >= 0 and y >= 0 and w > 0 and h > 0, f"source_bbox_hint requires non-negative origin and positive size: {layer_id}")
    require(x + w <= canvas[0] and y + h <= canvas[1], f"source_bbox_hint exceeds delivery canvas: {layer_id}")


def _validate_anchor(value: Any, bbox: list[int], layer_id: str) -> None:
    require(isinstance(value, list) and len(value) == 2, f"anchor_hint must be [x,y]: {layer_id}")
    require(all(isinstance(x, int) and not isinstance(x, bool) for x in value), f"anchor_hint must be integer pixels: {layer_id}")
    require(value == bbox[:2], f"anchor_hint must equal source bbox top-left for deterministic crop placement: {layer_id}")


def _validate_motion_envelope(value: Any, layer_id: str) -> None:
    require(isinstance(value, dict), f"motion_envelope_px must be an object: {layer_id}")
    require(set(value) == {"left", "top", "right", "bottom"}, f"motion_envelope_px keys must be left/top/right/bottom: {layer_id}")
    require(all(isinstance(v, int) and not isinstance(v, bool) and v >= 0 for v in value.values()),
            f"motion_envelope_px values must be non-negative integers: {layer_id}")


def _validate_graph_edge(edge: Any, label: str, *, allowed_types: set[str] | None = None) -> tuple[str, str, str | None]:
    require(isinstance(edge, dict), f"{label} edge must be an object")
    expected = {"from", "to"} if allowed_types is None else {"type", "from", "to"}
    require(set(edge) == expected, f"{label} edge fields must be {sorted(expected)}")
    source = edge.get("from"); target = edge.get("to")
    require(isinstance(source, str) and source.strip() and isinstance(target, str) and target.strip(),
            f"{label} edge endpoints must be non-empty strings")
    require(source != target, f"{label} edge cannot self-reference: {source}")
    if allowed_types is None:
        return source, target, None
    relation = edge.get("type")
    require(relation in allowed_types, f"{label} edge has invalid type={relation}")
    return source, target, str(relation)


def _validate_analysis_artifacts(value: Any, work: Path, root: Path, *, source_sha: str, work_sha: str, delivery_canvas: list[int]) -> dict[str, Any]:
    require(isinstance(value, dict), "analysis_artifacts must be an object")
    required = {"layer_graph", "occlusion_graph", "interaction_graph"}
    require(set(value) == required, f"analysis_artifacts must contain exactly {sorted(required)}")
    resolved: dict[str, Path] = {}
    parsed: dict[str, dict[str, Any]] = {}
    for key in sorted(required):
        item = value[key]
        require(isinstance(item, dict) and set(item) == {"path", "sha256"}, f"analysis_artifacts.{key} must contain path/sha256")
        path = workspace_path(str(item.get("path", "")), root, must_exist=True)
        require(find_work_root(path, root) == work, f"analysis_artifacts.{key} must be inside current request work/")
        require(str(item.get("sha256", "")) == sha256_file(path), f"analysis_artifacts.{key} sha256 is stale")
        resolved[key] = path
        parsed[key] = load_json(path)

    layer_graph = parsed["layer_graph"]
    require(layer_graph.get("schema_version") == LAYER_GRAPH_SCHEMA, f"layer_graph schema must be {LAYER_GRAPH_SCHEMA}")
    require(layer_graph.get("status") == "READY", "layer_graph must be READY")
    require(layer_graph.get("source_sha256") == source_sha and layer_graph.get("work_sha256") == work_sha,
            "layer_graph source/work binding is stale")
    require(layer_graph.get("delivery_canvas_size") == delivery_canvas, "layer_graph delivery_canvas_size mismatch")
    nodes = layer_graph.get("nodes")
    require(isinstance(nodes, list) and nodes, "layer_graph nodes must be non-empty")
    node_map: dict[str, dict[str, Any]] = {}
    for idx, node in enumerate(nodes):
        require(isinstance(node, dict), f"layer_graph.nodes[{idx}] must be an object")
        require(set(node) == {"node_id", "kind", "depth_band", "bbox"},
                f"layer_graph.nodes[{idx}] fields must be node_id/kind/depth_band/bbox")
        node_id = node.get("node_id")
        require(isinstance(node_id, str) and node_id.strip() and node_id not in node_map, f"invalid/duplicate layer_graph node_id at index={idx}")
        require(isinstance(node.get("kind"), str) and node.get("kind").strip(), f"layer_graph node kind missing: {node_id}")
        require(node.get("depth_band") in ALLOWED_DEPTH_BANDS, f"layer_graph node depth_band invalid: {node_id}")
        _validate_bbox(node.get("bbox"), node_id, delivery_canvas)
        node_map[node_id] = node
    layer_edges = layer_graph.get("edges", [])
    require(isinstance(layer_edges, list), "layer_graph edges must be an array")
    parsed_layer_edges: set[tuple[str, str, str]] = set()
    layer_edge_types = ALLOWED_RELATIONSHIPS - {"occludes", "interaction_bound"}
    for idx, edge in enumerate(layer_edges):
        source, target, relation = _validate_graph_edge(edge, f"layer_graph.edges[{idx}]", allowed_types=layer_edge_types)
        require(source in node_map and target in node_map, f"layer_graph edge endpoint is not a declared node: {source}->{target}")
        parsed_layer_edges.add((str(relation), source, target))

    occlusion_graph = parsed["occlusion_graph"]
    require(occlusion_graph.get("schema_version") == OCCLUSION_GRAPH_SCHEMA, f"occlusion_graph schema must be {OCCLUSION_GRAPH_SCHEMA}")
    require(occlusion_graph.get("status") == "READY", "occlusion_graph must be READY")
    require(occlusion_graph.get("source_sha256") == source_sha, "occlusion_graph source binding is stale")
    occlusion_edges = occlusion_graph.get("edges")
    require(isinstance(occlusion_edges, list), "occlusion_graph edges must be an array")
    parsed_occlusion: set[tuple[str, str]] = set()
    for idx, edge in enumerate(occlusion_edges):
        source, target, _ = _validate_graph_edge(edge, f"occlusion_graph.edges[{idx}]")
        require(source in node_map and target in node_map, f"occlusion_graph endpoint is not a layer_graph node: {source}->{target}")
        parsed_occlusion.add((source, target))

    interaction_graph = parsed["interaction_graph"]
    require(interaction_graph.get("schema_version") == INTERACTION_GRAPH_SCHEMA, f"interaction_graph schema must be {INTERACTION_GRAPH_SCHEMA}")
    require(interaction_graph.get("status") == "READY", "interaction_graph must be READY")
    require(interaction_graph.get("source_sha256") == source_sha, "interaction_graph source binding is stale")
    clusters = interaction_graph.get("clusters")
    require(isinstance(clusters, list), "interaction_graph clusters must be an array")
    cluster_map: dict[str, dict[str, Any]] = {}
    member_to_cluster: dict[str, str] = {}
    for idx, cluster in enumerate(clusters):
        require(isinstance(cluster, dict), f"interaction_graph.clusters[{idx}] must be an object")
        require(set(cluster) == {"cluster_id", "primary_subject", "members", "binding_reasons"},
                f"interaction_graph.clusters[{idx}] fields invalid")
        cluster_id = cluster.get("cluster_id")
        require(isinstance(cluster_id, str) and cluster_id.strip() and cluster_id not in cluster_map, f"invalid/duplicate interaction cluster at index={idx}")
        primary = cluster.get("primary_subject")
        members = cluster.get("members")
        reasons = cluster.get("binding_reasons")
        require(isinstance(primary, str) and primary.strip(), f"interaction cluster primary_subject missing: {cluster_id}")
        require(isinstance(members, list) and members and all(isinstance(x, str) and x.strip() for x in members), f"interaction cluster members invalid: {cluster_id}")
        require(len(set(members)) == len(members) and primary in members, f"interaction cluster members must be unique and include primary_subject: {cluster_id}")
        require(isinstance(reasons, list) and reasons and all(isinstance(x, str) and x.strip() for x in reasons), f"interaction cluster binding_reasons invalid: {cluster_id}")
        for member in members:
            require(member not in member_to_cluster, f"interaction member belongs to multiple clusters: {member}")
            member_to_cluster[member] = cluster_id
        cluster_map[cluster_id] = cluster

    return {
        "paths": resolved, "layer_nodes": node_map, "layer_edges": parsed_layer_edges,
        "occlusion_edges": parsed_occlusion, "interaction_clusters": cluster_map,
        "interaction_member_to_cluster": member_to_cluster,
    }


def _validate_bound_media(value: Any, work: Path, root: Path, *, label: str) -> None:
    if value in (None, "", []):
        return
    items = value if isinstance(value, list) else [value]
    require(all(isinstance(item, str) and item.strip() for item in items), f"{label} must be a path or path array")
    for item in items:
        path = workspace_path(item, root, must_exist=True)
        require(find_work_root(path, root) == work, f"{label} must stay inside current request work/: {item}")


def validate_plan(plan_path: Path, root: Path) -> tuple[dict[str, Any], Path, list[dict[str, Any]]]:
    plan = load_json(plan_path)
    require(plan.get("schema_version") == SCHEMA, f"layer plan schema must be {SCHEMA}")
    require(plan.get("status") == "READY", "layer plan must be READY")
    work = find_work_root(plan_path, root)
    require(plan_path.parent.resolve() == work, "layer-plan.json must live directly in current work/")

    state_path = work.parent / "state.json"
    require(state_path.is_file(), "request state.json is missing")
    state = load_json(state_path)
    require(state.get("primary_skill") == PRIMARY_SKILL,
            f"request primary_skill must be {PRIMARY_SKILL}")

    source = workspace_path(str(plan.get("source_image", "")), root, must_exist=True)
    source_sha = sha256_file(source)
    require(str(plan.get("source_sha256", "")) == source_sha, "layer plan source_sha256 is stale")
    try:
        from PIL import Image
        with Image.open(source) as opened:
            opened.load(); decoded_source_size = list(opened.size)
    except ImportError as exc:
        raise BatchError("Pillow is required to validate decomposition sizes") from exc
    source_canvas = plan.get("source_canvas_size")
    require(source_canvas == decoded_source_size, "source_canvas_size must exactly match decoded source")
    size_contract = plan.get("size_contract")
    require(isinstance(size_contract, dict), "size_contract is required")
    try:
        validate_size_contract(size_contract, source_size=tuple(decoded_source_size))
    except ValueError as exc:
        raise BatchError(str(exc)) from exc
    require(size_contract.get("skill") == SKILL_IMAGE, "size_contract skill mismatch")
    delivery = size_contract["delivery_canvas"]
    delivery_canvas = [int(delivery["width"]), int(delivery["height"])]
    require(plan.get("delivery_canvas_size") == delivery_canvas, "delivery_canvas_size does not match size_contract")
    work_surface = size_contract["work_surfaces"][0]
    canvas = [int(work_surface["width"]), int(work_surface["height"])]
    require(plan.get("work_canvas_size") == canvas, "work_canvas_size does not match size_contract")
    expected_size = f"{canvas[0]}x{canvas[1]}"
    work_value = str(plan.get("work_source", "")).strip()
    work_image = workspace_path(work_value, root, must_exist=True)
    require(work == find_work_root(work_image, root), "work_source must be inside current request work/")
    with Image.open(work_image) as opened:
        opened.load()
        require(opened.size == tuple(canvas), f"work_source size {opened.size[0]}x{opened.size[1]} does not match plan {expected_size}")
    work_sha = str(plan.get("work_sha256", "")).strip()
    require(work_sha and work_sha == sha256_file(work_image), "layer plan work_sha256 is missing or stale")
    require(str(plan.get("downstream_intent", "")).strip(), "downstream_intent is required")
    require(plan.get("decomposition_profile") in ALLOWED_DECOMPOSITION_PROFILES,
            "decomposition_profile must be kv-depth or generic-composite")
    analysis = _validate_analysis_artifacts(
        plan.get("analysis_artifacts"), work, root, source_sha=source_sha, work_sha=work_sha, delivery_canvas=delivery_canvas
    )

    relationships = plan.get("relationships", [])
    require(isinstance(relationships, list), "relationships must be an array")
    for idx, relation in enumerate(relationships):
        require(isinstance(relation, dict) and set(relation) == {"type", "from", "to"},
                f"relationships[{idx}] must contain type/from/to only")
        require(relation.get("type") in ALLOWED_RELATIONSHIPS, f"invalid relationship type at index={idx}")
        require(all(isinstance(relation.get(k), str) and relation.get(k).strip() for k in ("from", "to")),
                f"relationship from/to must be non-empty strings at index={idx}")
        require(relation["from"] != relation["to"], f"relationship cannot self-reference at index={idx}")

    layers = plan.get("layers")
    require(isinstance(layers, list) and layers, "layer plan requires non-empty layers")
    layer_ids: set[str] = set()
    call_ids: set[str] = set()
    outputs: set[str] = set()
    compiled: list[dict[str, Any]] = []

    z_orders: set[int] = set()
    pending_occlusion: dict[str, list[str]] = {}
    pending_occludes: dict[str, list[str]] = {}
    required_layer_fields = {
        "layer_id", "name", "layer_type", "depth_band", "z_order", "strategy",
        "source_bbox_hint", "anchor_hint", "includes", "excludes", "interaction_members", "bound_assets", "occluded_by", "occludes",
        "primary_pixel_owner", "visible_region_policy", "reconstruction_scope", "minimum_visible_coverage_ratio", "motion_margin_px", "motion_envelope_px",
        "reconstruction_confidence", "reconstruction_provenance", "blend_mode", "blend_mode_hint", "api_calls",
    }
    for layer_index, layer in enumerate(layers):
        require(isinstance(layer, dict), f"layers[{layer_index}] must be object")
        missing = required_layer_fields - set(layer)
        require(not missing, f"layer is missing required fields {sorted(missing)}: index={layer_index}")
        layer_id = str(layer.get("layer_id", "")).strip()
        require(layer_id and layer_id not in layer_ids, f"layer_id missing or duplicate: {layer_id!r}")
        layer_ids.add(layer_id)
        require(str(layer.get("name", "")).strip(), f"layer name missing: {layer_id}")
        require(layer.get("layer_type") in ALLOWED_LAYER_TYPES, f"invalid layer_type: {layer_id}")
        require(layer.get("depth_band") in ALLOWED_DEPTH_BANDS, f"invalid depth_band: {layer_id}")
        _validate_bbox(layer.get("source_bbox_hint"), layer_id, delivery_canvas)
        _validate_anchor(layer.get("anchor_hint"), layer["source_bbox_hint"], layer_id)
        graph_node = analysis["layer_nodes"].get(layer_id)
        require(graph_node is not None, f"layer_id is missing from layer_graph nodes: {layer_id}")
        require(graph_node["bbox"] == layer["source_bbox_hint"], f"layer_graph bbox disagrees with layer plan: {layer_id}")
        require(graph_node["depth_band"] == layer.get("depth_band"), f"layer_graph depth_band disagrees with layer plan: {layer_id}")
        _validate_motion_envelope(layer.get("motion_envelope_px"), layer_id)
        z = layer.get("z_order")
        require(isinstance(z, int) and not isinstance(z, bool) and z not in z_orders, f"z_order must be unique integer: {layer_id}")
        z_orders.add(z)
        strategy = str(layer.get("strategy", ""))
        require(strategy in ALLOWED_STRATEGIES, f"invalid strategy={strategy}: {layer_id}")
        require(layer.get("blend_mode") == "normal", f"only normal blend_mode is currently deterministic: {layer_id}")
        require(layer.get("blend_mode_hint") in ALLOWED_BLEND_HINTS, f"invalid blend_mode_hint: {layer_id}")
        require(layer.get("reconstruction_confidence") in ALLOWED_CONFIDENCE, f"invalid reconstruction_confidence: {layer_id}")
        require(layer.get("visible_region_policy") in ALLOWED_VISIBLE_POLICIES, f"invalid visible_region_policy: {layer_id}")
        require(isinstance(layer.get("primary_pixel_owner"), bool), f"primary_pixel_owner must be boolean: {layer_id}")
        minimum_coverage = layer.get("minimum_visible_coverage_ratio")
        require(isinstance(minimum_coverage, (int, float)) and not isinstance(minimum_coverage, bool)
                and 0.0 < float(minimum_coverage) <= 1.0,
                f"minimum_visible_coverage_ratio must be a number in (0,1]: {layer_id}")
        margin = layer.get("motion_margin_px")
        require(isinstance(margin, int) and not isinstance(margin, bool) and margin >= 0, f"motion_margin_px must be >=0 integer: {layer_id}")
        for field in ("includes", "excludes", "interaction_members", "bound_assets", "occluded_by", "occludes", "reconstruction_provenance"):
            value = layer.get(field)
            require(isinstance(value, list) and all(isinstance(x, str) and x.strip() for x in value),
                    f"{field} must be an array of non-empty strings: {layer_id}")
        require(layer["includes"], f"includes must identify the layer owner content: {layer_id}")
        cluster_id = layer.get("interaction_cluster_id")
        require(isinstance(cluster_id, str), f"interaction_cluster_id must be a string: {layer_id}")
        if layer.get("layer_type") == "hero-subject":
            require(cluster_id, f"hero-subject requires interaction_cluster_id: {layer_id}")
            cluster = analysis["interaction_clusters"].get(cluster_id)
            require(cluster is not None, f"hero-subject references unknown interaction cluster: {layer_id}:{cluster_id}")
            require(layer["interaction_members"] == cluster["members"], f"hero-subject interaction_members must exactly match interaction graph cluster: {layer_id}")
        else:
            require(not cluster_id or cluster_id in analysis["interaction_clusters"], f"unknown interaction_cluster_id: {layer_id}:{cluster_id}")
        if layer.get("reconstruction_confidence") in {"high", "medium", "low"}:
            require(layer["reconstruction_provenance"], f"reconstruction confidence requires provenance: {layer_id}")
        pending_occlusion[layer_id] = list(layer["occluded_by"])
        pending_occludes[layer_id] = list(layer["occludes"])
        calls = layer.get("api_calls", [])
        require(isinstance(calls, list), f"api_calls must be array: {layer_id}")
        call_names = {str(call.get("id", "")).strip() for call in calls if isinstance(call, dict)}
        if strategy == "source_locked_extract":
            require("visible" in call_names, f"source_locked_extract requires a visible pass: {layer_id}")
        elif strategy == "source_locked_reconstruct":
            require({"visible", "reconstruct"}.issubset(call_names),
                    f"source_locked_reconstruct requires visible + reconstruct passes: {layer_id}")
        elif strategy == "clean_plate_patch":
            require("clean" in call_names, f"clean_plate_patch requires a clean pass: {layer_id}")
        elif strategy == "model_native_alpha":
            require(bool(calls), f"model_native_alpha requires at least one model pass: {layer_id}")
        elif strategy in {"source_asset", "verified_mask_extract", "unrecoverable"}:
            require(not calls, f"strategy={strategy} must not declare model API calls: {layer_id}")
        for call_index, call in enumerate(calls):
            require(isinstance(call, dict), f"api_calls[{call_index}] must be object: {layer_id}")
            local_id = str(call.get("id", "")).strip()
            require(local_id, f"API call id missing: {layer_id}")
            global_id = f"{layer_id}__{local_id}"
            require(global_id not in call_ids, f"duplicate API call id: {global_id}")
            call_ids.add(global_id)
            mode = str(call.get("mode", "")).strip()
            require(mode in ALLOWED_MODES, f"unsupported mode for {global_id}: {mode}")
            model = str(call.get("model") or plan.get("default_model") or "gpt-image-2.5-sunburst").strip()
            require(model in ALLOWED_MODELS, f"unsupported GPT image model for {global_id}: {model}")
            prompt_path = workspace_path(str(call.get("prompt_path", "")), root, must_exist=True)
            require(find_work_root(prompt_path, root) == work, f"Prompt outside current request: {global_id}")
            output_path = workspace_path(str(call.get("output_path", "")), root)
            provider_originals = (work / "final" / "originals" / "provider").resolve()
            require(provider_originals in output_path.parents,
                    f"provider output must be inside work/final/originals/provider/: {global_id}")
            output_rel = workspace_relative(output_path, root)
            require(output_rel not in outputs, f"duplicate API output: {output_rel}")
            outputs.add(output_rel)
            parameters = call.get("parameters")
            require(isinstance(parameters, dict), f"parameters must be object: {global_id}")
            require(str(parameters.get("size", "")) == expected_size,
                    f"all model passes must use work surface {expected_size}: {global_id}")
            require(str(parameters.get("output_format", "")).lower() == "png",
                    f"layer passes must output PNG: {global_id}")
            background = str(parameters.get("background", "")).lower()
            require(background in {"transparent", "opaque"}, f"background must be transparent or opaque: {global_id}")
            require(str(parameters.get("quality", "")).lower() in {"low", "medium", "high", "xhigh", "max", "auto"},
                    f"invalid quality: {global_id}")
            if strategy in {"source_locked_extract", "source_locked_reconstruct", "model_native_alpha"}:
                require(background == "transparent", f"strategy={strategy} requires transparent output: {global_id}")
            if strategy == "clean_plate_patch" and local_id == "clean":
                require(background == "opaque", f"clean_plate_patch clean pass requires opaque output: {global_id}")

            request: dict[str, Any] = {
                "api_profile": "gpt",
                "mode": mode,
                "model": model,
                "prompt_path": workspace_relative(prompt_path, root),
                "output_path": output_rel,
                "parameters": parameters,
            }
            for optional in ("reference_images", "base_image", "mask_image"):
                if optional in call and call[optional] not in (None, "", []):
                    request[optional] = call[optional]
            _validate_bound_media(request.get("reference_images"), work, root, label=f"reference_images for {global_id}")
            _validate_bound_media(request.get("mask_image"), work, root, label=f"mask_image for {global_id}")
            if mode == "image_to_image_edit":
                base = str(request.get("base_image", "")).strip()
                require(base, f"image_to_image_edit requires base_image: {global_id}")
                base_path = workspace_path(base, root, must_exist=True)
                require(base_path == work_image, f"image_to_image_edit must bind work_source as base_image: {global_id}")
            if mode == "reference_to_image":
                require(bool(request.get("reference_images")), f"reference_to_image requires reference_images: {global_id}")

            compiled.append({
                "id": global_id,
                "status": "READY",
                "api_profile": "gpt",
                "mode": mode,
                "model": model,
                "prompt_path": request["prompt_path"],
                "prompt_sha256": sha256_file(prompt_path),
                "output_path": output_rel,
                "parameters": parameters,
                **({"reference_images": request["reference_images"]} if "reference_images" in request else {}),
                **({"base_image": request["base_image"]} if "base_image" in request else {}),
                **({"mask_image": request["mask_image"]} if "mask_image" in request else {}),
                "_request": request,
            })
    for layer_id, occluders in pending_occlusion.items():
        require(layer_id not in occluders, f"layer cannot occlude itself: {layer_id}")
        unknown = sorted(set(occluders) - layer_ids)
        require(not unknown, f"occluded_by references unknown layer(s) {unknown}: {layer_id}")
    for layer_id, targets in pending_occludes.items():
        require(layer_id not in targets, f"layer cannot occlude itself: {layer_id}")
        unknown = sorted(set(targets) - layer_ids)
        require(not unknown, f"occludes references unknown layer(s) {unknown}: {layer_id}")
        for target in targets:
            require(layer_id in pending_occlusion.get(target, []),
                    f"occlusion graph is not reciprocal: {layer_id} occludes {target} but target.occluded_by omits {layer_id}")
    for layer_id, sources in pending_occlusion.items():
        for source in sources:
            require(layer_id in pending_occludes.get(source, []),
                    f"occlusion graph is not reciprocal: {layer_id}.occluded_by={source} but source.occludes omits {layer_id}")
    known_entities = set(layer_ids)
    for layer in layers:
        known_entities.update(layer["interaction_members"])
        known_entities.update(layer["bound_assets"])
    for relation in relationships:
        require(relation["from"] in known_entities, f"relationship references unknown from endpoint: {relation['from']}")
        require(relation["to"] in known_entities, f"relationship references unknown to endpoint: {relation['to']}")
        if relation["type"] == "occludes":
            require(relation["from"] in layer_ids and relation["to"] in layer_ids,
                    "occludes relationship endpoints must be layer_id values")
    layer_relations = {(r["type"], r["from"], r["to"]) for r in relationships}
    planned_occlusion = {(source, target) for source, targets in pending_occludes.items() for target in targets}
    require(planned_occlusion == analysis["occlusion_edges"],
            f"occlusion_graph must exactly match layer plan occlusion edges: graph={sorted(analysis['occlusion_edges'])} plan={sorted(planned_occlusion)}")
    for source, target in planned_occlusion:
        require(("occludes", source, target) in layer_relations,
                f"relationships must include occludes edge {source}->{target}")
    for relation, source, target in analysis["layer_edges"]:
        require((relation, source, target) in layer_relations,
                f"layer_graph edge must be present in plan relationships: {relation}:{source}->{target}")
    for relation, source, target in layer_relations:
        if relation in (ALLOWED_RELATIONSHIPS - {"occludes", "interaction_bound"}) and source in layer_ids and target in layer_ids:
            require((relation, source, target) in analysis["layer_edges"],
                    f"plan layer relationship must be present in layer_graph: {relation}:{source}->{target}")
        if relation == "interaction_bound":
            source_cluster = analysis["interaction_member_to_cluster"].get(source)
            target_cluster = analysis["interaction_member_to_cluster"].get(target)
            require(source_cluster is not None and source_cluster == target_cluster,
                    f"interaction_bound endpoints must belong to the same interaction graph cluster: {source}->{target}")
    require(compiled, "layer plan contains no API calls")
    return plan, work, compiled




def load_local_module(path: Path, module_name: str, label: str):
    require(path.is_file(), f"{label} unavailable: {path}")
    spec = importlib.util.spec_from_file_location(module_name, path)
    require(spec is not None and spec.loader is not None, f"{label} unavailable: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def plan_requires_reconstruction(plan: dict[str, Any]) -> bool:
    layers = plan.get("layers", [])
    return any(isinstance(layer, dict) and layer.get("strategy") in RECONSTRUCTION_STRATEGIES for layer in layers)


def source_contract(plan_path: Path, plan: dict[str, Any], root: Path) -> dict[str, Any]:
    source = workspace_path(str(plan.get("source_image", "")), root, must_exist=True)
    work_image = workspace_path(str(plan.get("work_source", "")), root, must_exist=True)
    return {
        "layer_plan_path": workspace_relative(plan_path, root),
        "layer_plan_sha256": sha256_file(plan_path),
        "source_image_path": workspace_relative(source, root),
        "source_sha256": sha256_file(source),
        "work_source_path": workspace_relative(work_image, root),
        "work_sha256": sha256_file(work_image),
        "source_canvas_size": plan["source_canvas_size"],
        "delivery_canvas_size": plan["delivery_canvas_size"],
        "work_canvas_size": plan["work_canvas_size"],
        "size_contract": plan["size_contract"],
    }


def _request_identity(root: Path, request: Path) -> dict[str, Any]:
    module = load_local_module(root / ".agents" / "lib" / "request_identity.py", "wxian_request_identity", "request identity")
    try:
        return module.identity(root, request)
    except Exception as exc:
        raise BatchError(str(exc)) from exc


def _visual_contract_module(root: Path):
    lib = root / ".agents" / "lib"
    if str(lib) not in sys.path:
        sys.path.insert(0, str(lib))
    return load_local_module(lib / "visual_contracts.py", "wxian_visual_contracts", "visual contracts")


def prepare_contract(plan_path: Path, root: Path, *, force: bool = False) -> dict[str, Any]:
    plan, work, compiled = validate_plan(plan_path, root)
    if not plan_requires_reconstruction(plan):
        return {
            "status": "not_required",
            "operation": "prepare-contract",
            "reason": "layer plan contains no reconstruction strategy",
            "network_called": False,
        }
    request = work.parent
    request_md = request / "request.md"
    state_path = request / "state.json"
    require(request_md.is_file(), "prepare-contract requires request.md")
    require(state_path.is_file(), "prepare-contract requires state.json")
    ident = _request_identity(root, request)
    contract = source_contract(plan_path, plan, root)

    entries: list[dict[str, Any]] = []
    package_parts = [
        "# Composite Image Layer Prompt Package",
        "",
        f"layer_plan: {contract['layer_plan_path']}",
        f"layer_plan_sha256: {contract['layer_plan_sha256']}",
        f"source_sha256: {contract['source_sha256']}",
        f"work_sha256: {contract['work_sha256']}",
        "",
    ]
    for item in compiled:
        prompt_path = workspace_path(item["prompt_path"], root, must_exist=True)
        prompt_sha = sha256_file(prompt_path)
        entries.append({
            "item_id": item["id"],
            "prompt_path": workspace_relative(prompt_path, root),
            "prompt_sha256": prompt_sha,
        })
        package_parts += [
            f"## {item['id']}",
            "",
            f"prompt_path: {workspace_relative(prompt_path, root)}",
            f"prompt_sha256: {prompt_sha}",
            "",
            prompt_path.read_text(encoding="utf-8").rstrip(),
            "",
        ]
    package_path = work / "layer-prompt-package.md"
    write_idempotent(package_path, "\n".join(package_parts).rstrip() + "\n", force=force)

    manifest = {
        "schema_version": PROMPT_MANIFEST_SCHEMA,
        "primary_skill": PRIMARY_SKILL,
        **contract,
        "prompt_package_path": workspace_relative(package_path, root),
        "prompt_package_sha256": sha256_file(package_path),
        "entries": entries,
    }
    manifest_path = work / "layer-prompt-manifest.json"
    write_idempotent(manifest_path, stable_json(manifest), force=force)

    authority_trace = [{
        "role": "current_request",
        "path": workspace_relative(request_md, root),
        "sha256": sha256_file(request_md),
    }]
    source_lock = work / "source-lock.json"
    if source_lock.is_file():
        authority_trace.append({
            "role": "source_lock",
            "path": workspace_relative(source_lock, root),
            "sha256": sha256_file(source_lock),
        })
    source_path = workspace_path(contract["source_image_path"], root, must_exist=True)
    source_role = "request_input" if (request / "input").resolve() in source_path.resolve().parents else "other_authority"
    authority_trace += [
        {"role": source_role, "path": contract["source_image_path"], "sha256": contract["source_sha256"]},
        {"role": "other_authority", "path": contract["layer_plan_path"], "sha256": contract["layer_plan_sha256"]},
        {"role": "other_authority", "path": workspace_relative(manifest_path, root), "sha256": sha256_file(manifest_path)},
    ]
    visual_spec = {
        "schema_version": "sicza.visual-spec.v2",
        **ident,
        "profile_id": "visual.transform.reconstruction.v1",
        "mode": "TRANSFORM",
        "task_kind": "still",
        "authority_trace": authority_trace,
        "narrative_trace": None,
        "intent": {"primary": "reconstruct editable composite-image layers while preserving the source composition and visible evidence"},
        "truth_protection": {"protect": [
            "source-visible RGB, geometry, camera, crop and identity are authoritative",
            "generated content is limited to declared hidden/reconstructed regions",
        ]},
        "world_space": {"space": "preserve the source depth and occlusion relationships encoded by the layer plan"},
        "performance": {},
        "projection": {"camera": "do not change source camera, perspective, framing, scale or relative placement"},
        "appearance": {"surface": "match source material, lighting and rendering; do not restyle visible evidence"},
        "image_structure": {"hierarchy": "preserve the source composition and layer ownership graph"},
        "image_formation": {"edges": "native alpha with source-locked visible edges; reconstruction only where evidence is absent"},
        "graphic": {},
        "identity": {"lock": "preserve all source-visible subject, prop, logo and typography identity"},
        "channel_roles": {},
        "motion": None,
        "change_set": {
            "protect": ["all source-visible regions outside declared reconstruction masks"],
            "change": ["only declared hidden regions required by the layer plan and motion-safe completion"],
            "avoid": ["redesign, recrop, relayout, identity drift, duplicate pixel ownership"],
        },
        "success_condition": [
            "source-visible regions remain source-locked after deterministic merge",
            "reconstructed regions remain bounded by the layer plan and can recompose without holes or duplicate ownership",
        ],
        "unresolved": [],
    }
    visual_spec_path = work / "visual-spec.json"
    write_idempotent(visual_spec_path, stable_json(visual_spec), force=force)

    compiler_profile = "image.gpt-image.v1"
    prompt_pack = root / ".agents" / "skills" / "wxian-image-production" / "references" / "prompt-packs" / "gpt-image-2.md"
    require(prompt_pack.is_file(), "GPT Image prompt pack is missing")
    binding = {
        "schema_version": "sicza.prompt-binding.v2",
        **ident,
        "visual_spec_path": workspace_relative(visual_spec_path, root),
        "visual_spec_sha256": sha256_file(visual_spec_path),
        "narrative_semantic_checksum": None,
        "prompt_path": workspace_relative(package_path, root),
        "prompt_sha256": sha256_file(package_path),
        "compiler_profile": compiler_profile,
        "adapter_family": "gpt-image",
        "prompt_pack_path": workspace_relative(prompt_pack, root),
        "prompt_pack_sha256": sha256_file(prompt_pack),
    }
    binding_path = work / "prompt-binding.json"
    write_idempotent(binding_path, stable_json(binding), force=force)

    visual = _visual_contract_module(root)
    try:
        visual.validate_visual_spec(root, visual_spec_path)
        visual.validate_prompt_binding(root, binding_path)
    except Exception as exc:
        raise BatchError(str(exc)) from exc
    return {
        "status": "success",
        "operation": "prepare-contract",
        "visual_spec": workspace_relative(visual_spec_path, root),
        "visual_spec_sha256": sha256_file(visual_spec_path),
        "prompt_binding": workspace_relative(binding_path, root),
        "prompt_binding_sha256": sha256_file(binding_path),
        "prompt_manifest": workspace_relative(manifest_path, root),
        "prompt_manifest_sha256": sha256_file(manifest_path),
        "prompt_count": len(entries),
        "network_called": False,
    }


def build(plan_path: Path, root: Path, *, force: bool = False) -> dict[str, Any]:
    _, work, compiled = validate_plan(plan_path, root)
    public_items: list[dict[str, Any]] = []
    request_files: list[str] = []
    for item in compiled:
        request = item.pop("_request")
        request_path = work / "api-requests" / f"{item['id']}.json"
        write_idempotent(request_path, stable_json(request), force=force)
        request_files.append(workspace_relative(request_path, root))
        public_items.append(item)
    generation_plan = {
        "schema_version": GENERATION_SCHEMA,
        "primary_skill": PRIMARY_SKILL,
        "status": "READY",
        "source_contract": source_contract(plan_path, load_json(plan_path), root),
        "items": public_items,
    }
    generation_path = work / "generation-plan.json"
    write_idempotent(generation_path, stable_json(generation_plan), force=force)
    return {
        "status": "success",
        "operation": "build",
        "layer_plan": workspace_relative(plan_path, root),
        "generation_plan": workspace_relative(generation_path, root),
        "generation_plan_sha256": sha256_file(generation_path),
        "item_count": len(public_items),
        "request_files": request_files,
        "network_called": False,
    }


def _successful_existing(output: Path) -> bool:
    receipt = output.with_name(output.name + ".call.json")
    if not output.is_file() or not receipt.is_file():
        return False
    try:
        value = load_json(receipt)
    except BatchError:
        return False
    return value.get("status") == "success" and value.get("output_sha256") == sha256_file(output)


def run(plan_path: Path, root: Path, mode: str, *, force_build: bool = False) -> dict[str, Any]:
    build_result = build(plan_path, root, force=force_build)
    generation_plan = load_json(workspace_path(build_result["generation_plan"], root, must_exist=True))
    api_script = root / ".agents" / "skills" / "image-generation-api" / "scripts" / "generation_api.py"
    require(api_script.is_file(), "image-generation-api executor is missing")
    results: list[dict[str, Any]] = []
    blocked = False
    api_module = load_local_module(api_script, "wxian_generation_api_batch", "image-generation-api") if mode == "dry-run" else None
    for item in generation_plan["items"]:
        request_path = find_work_root(plan_path, root) / "api-requests" / f"{item['id']}.json"
        output = workspace_path(item["output_path"], root)
        if _successful_existing(output):
            results.append({"id": item["id"], "status": "skipped_existing_verified", "output": item["output_path"]})
            continue
        require(not output.exists(), f"output exists without a matching success receipt: {item['output_path']}")
        if mode == "dry-run":
            try:
                payload = api_module.dry_run_request_file(request_path, root)
                returncode = 0
            except (api_module.ApiError, OSError) as exc:
                payload = {"status": "blocked", "reason": str(exc), "network_called": False}
                returncode = 1
            entry = {"id": item["id"], "returncode": returncode, "result": payload}
        else:
            command = [sys.executable, str(api_script), mode, "--request", str(request_path), "--workspace-root", str(root)]
            completed = subprocess.run(command, text=True, capture_output=True)
            try:
                payload = json.loads(completed.stdout) if completed.stdout.strip() else {}
            except json.JSONDecodeError:
                payload = {"status": "blocked", "reason": "generation_api returned non-JSON output", "stdout": completed.stdout[-2000:]}
            entry = {"id": item["id"], "returncode": completed.returncode, "result": payload}
            if completed.stderr.strip():
                entry["stderr"] = completed.stderr[-2000:]
            returncode = completed.returncode
        results.append(entry)
        if returncode != 0:
            blocked = True
            break
    return {
        "status": "blocked" if blocked else "success",
        "operation": f"run:{mode}",
        "item_count": len(generation_plan["items"]),
        "results": results,
        "network_called": mode == "invoke" and any(
            isinstance(entry.get("result"), dict) and entry["result"].get("network_called")
            for entry in results
        ),
    }


def doctor() -> dict[str, Any]:
    require(PRIMARY_SKILL == "wxian-image-layer-decomposition", "primary skill constant changed")
    require(SCHEMA == "wxian.kv-layer-plan.v6", "layer plan schema changed")
    require(ALLOWED_DECOMPOSITION_PROFILES == {"kv-depth", "generic-composite"}, "decomposition profiles changed")
    require({"interaction_bound", "behind"}.issubset(ALLOWED_RELATIONSHIPS), "relationship contract missing interaction_bound/behind")
    require(GENERATION_SCHEMA == "wxian.generation-plan.v1", "generation plan schema changed")
    require("image_to_image_edit" in ALLOWED_MODES, "edit mode missing")
    require("gpt-image-2.5-sunburst" in ALLOWED_MODELS, "Sunburst missing")
    return {
        "status": "ready",
        "tool": "layer_batch",
        "capabilities": ["kv-depth", "generic-composite", "graph-schema-binding", "graph-plan-consistency", "interaction-cluster-binding", "interaction-endpoint-validation", "bbox-anchor-contract", "motion-envelope-contract", "visual-reconstruction-contract", "prompt-manifest-binding", "source-contract-binding", "finite-plan-compile", "generation-plan-binding", "per-pass-request-build", "sequential-dry-run", "resume-verified-output"],
        "network_called": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("doctor")
    prepare_parser = sub.add_parser("prepare-contract")
    prepare_parser.add_argument("--plan", type=Path, required=True)
    prepare_parser.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])
    prepare_parser.add_argument("--force", action="store_true")
    build_parser = sub.add_parser("build")
    build_parser.add_argument("--plan", type=Path, required=True)
    build_parser.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])
    build_parser.add_argument("--force", action="store_true")
    run_parser = sub.add_parser("run")
    run_parser.add_argument("--plan", type=Path, required=True)
    run_parser.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])
    run_parser.add_argument("--mode", choices=("dry-run", "invoke"), required=True)
    run_parser.add_argument("--force-build", action="store_true")
    args = parser.parse_args()
    try:
        if args.command == "doctor":
            result = doctor()
        else:
            root = args.workspace_root.resolve()
            plan = workspace_path(args.plan, root, must_exist=True)
            if args.command == "prepare-contract":
                result = prepare_contract(plan, root, force=args.force)
            elif args.command == "build":
                result = build(plan, root, force=args.force)
            else:
                result = run(plan, root, args.mode, force_build=args.force_build)
    except (BatchError, OSError, subprocess.SubprocessError) as exc:
        print(json.dumps({"status": "blocked", "reason": str(exc)}, ensure_ascii=False))
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("status") != "blocked" else 1


if __name__ == "__main__":
    raise SystemExit(main())
