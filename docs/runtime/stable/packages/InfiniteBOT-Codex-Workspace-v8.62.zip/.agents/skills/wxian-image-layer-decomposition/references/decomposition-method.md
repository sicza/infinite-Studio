# KV / Banner 深度拆层方法

## 1. 方法论

扁平 KV 拆层不是“按名词分类”，而是恢复一个被压平的视觉图：

```text
camera / projection
→ depth evidence
→ occlusion graph
→ interaction graph
→ independent-control units
→ pixel ownership
→ layer plan
```

语义分类必须最后发生。先套“角色/场景/建筑/载具”会产生天空、地面、载具和阴影重复。

## 2. Layer / Occlusion / Interaction Graph

### Layer Graph

节点代表候选可交付层；边可以是：

```text
in_front_of / behind
belongs_to
receives_shadow_from
reflects
emits_effect
```

### Occlusion Graph

每个节点至少记录：

```text
occludes
occluded_by
overlap_boundary
required_reveal_region
```

### Interaction Graph

主体聚类不看“是不是载具”，只看是否与角色构成同一交互单元。关系包括但不限于：

```text
held
worn
carried
mounted
driven
controlled
pushed
pulled
dragged
tethered
lifted
embraced
physically_connected
functionally_connected
narratively_inseparable
anchored_effect
```

如果一个对象脱离角色后会破坏当前动作、接触点、叙事关系或控制关系，默认与角色同属 `interaction_bound_subject_unit`。

仅空间靠近、普通前后遮挡、同一光照不算 interaction binding。

## 3. Depth Bands

```text
BG_DEEP   最深天空 / 地平线 / 极远景
BG_NEAR   远景地形 / 植被 / 城市轮廓
MG_ENV    中景自然环境
MG_STRUCT 中景人工结构
SUPPORT   配角 / NPC / 独立辅助单位
SUBJECT   交互主体单元
FG_ENV    近景遮挡环境
FX        烟 / 火 / 粒子 / 辉光 / 体积效果
OVERLAY   LOGO / 标题 / 营销图形
```

这些只是深度/语义标签，不要求一带一层。

## 4. External Evidence 是辅助，不是依赖

如运行环境有现成能力，可使用：

```text
relative depth map
semantic / instance segmentation
alpha matting
known source assets
character turnarounds / vehicle sheets / environment concepts
```

用途：给深度、轮廓、隐藏结构更多证据。

限制：

- depth map 可能误判艺术透视；
- segmentation 不知道最终控制粒度；
- mask 不等于真实 alpha；
- 源 KV 的可见构图事实保持最高 Authority；外部 Evidence 仅补充深度、分割与材质判断。

这些工具是可选辅助；没有工具时继续依据源图视觉关系完成分析。

## 5. Interaction-bound Subject Unit

主体单位定义：

> 角色 + 与该角色发生直接交互、共同构成单一动作/表演/叙事单元的对象。

默认纳入：

```text
服饰 / 身体附件 / 手持装备
抱持 / 背负 / 扛举 / 拖拽 / 推动 / 牵引对象
骑乘 / 驾驶 / 操控对象
通过绳索、机械、能量或功能连接的伴生对象
与动作系统锚定、拆开会失去语义的专属效果
```

默认排除：

```text
只是靠近的车辆/建筑/道具
普通环境烟雾和光照
路过 NPC
仅仅在角色前/后的独立对象
```

只有明确下游需求 + 可靠隐藏结构 Evidence 同时成立，才继续拆 interaction unit 内部成员。

## 6. 环境唯一归属

环境像素采用唯一归属模型：


- `background-clean` 是完整最深底板；
- 中景/前景环境只有需要独立视差才抽离；
- 抽离后下层 clean plate 必须补齐；
- 建筑只带结构不可分地台/基座/桥面；
- 普通连续地面只归一个 owner。

## 7. Visible / Reconstructed / Speculative

每层区域必须区分：

```text
SOURCE_VISIBLE       源图可见证据
RECONSTRUCTED        被遮挡但有证据可补
SPECULATIVE          无充分证据但下游必须存在
```

推荐组合：

```text
SOURCE_VISIBLE RGB   <- 原图 source lock
RECONSTRUCTED RGB    <- GPT Image 2.5 Sunburst
SPECULATIVE RGB      <- GPT Image 2.5 Sunburst + manifest 明示低置信
```

`RECONSTRUCTED` 与 `SPECULATIVE` 按各自 provenance 与 confidence 表达，不使用 source-visible 像素恢复语义。

## 8. Motion-safe Completion

补全面积：

```text
当前遮挡区域
+ 预计位移/视差会暴露区域
+ seam safety margin
```

如果只做轻量视差，不需要把整个人背面、整栋建筑背面、整座城市无限补全。

## 9. Primary Pixel Ownership

每个普通可见像素最多一个 Primary Owner。

典型冲突：

```text
地面 -> background-clean vs building
天空 -> background-clean vs background-depth
interaction-bound object -> subject unit vs independent object layer
粒子 -> subject vs effect
文字 -> background vs overlay
影子 -> subject vs receiver vs shadow layer
```

解决顺序：先确定 Primary Owner，再按需要建立 relationship / blend hint 描述的派生影响层。

## 10. Shadow / Reflection / FX

### Shadow

- 随主体移动：独立 shadow 或 interaction unit 附属；
- 固定环境阴影：留接收面。

### Reflection

- 随主体变化：可独立；
- 固定环境反射：留环境。

### FX

烟、火、辉光、速度线等不能从扁平合成图严格反推出真实原始 Alpha。允许使用模型原生 Alpha 重建，并标：

```text
acquisition = model_native_alpha
blend_mode_hint = normal | screen | additive | multiply
```

## 11. 粒度停止规则

当继续拆分会导致以下任一情况时停止：

- 隐藏结构不可可靠补全；
- 接触点会破坏；
- 下游没有独立控制价值；
- Alpha/边缘质量显著下降；
- 只剩原子碎片而非可用资产。

目标是最小“可控单元”，不是最大图层数量。
