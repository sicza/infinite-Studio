#!/usr/bin/env python3
"""Resident finalization test for Decomposition Contract V2 + Smart Object PSD delivery."""
from __future__ import annotations
import os as _os, sys as _sys
_sys.dont_write_bytecode=True; _os.environ['PYTHONDONTWRITEBYTECODE']='1'
import argparse, hashlib, importlib.util, json, shutil, tempfile
from pathlib import Path
from types import SimpleNamespace
from PIL import Image
HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[3]
def mod(p,n):
 s=importlib.util.spec_from_file_location(n,p); assert s and s.loader; m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
batch=mod(HERE/'layer_batch.py','kv_batch_finalization_v2')
gate=mod(HERE/'delivery_gate.py','kv_delivery_finalization_v2')
finalizer=mod(ROOT/'.agents/lib/deterministic_layer_finalization.py','kv_finalizer_v2')
assets=mod(HERE/'layer_assets.py','kv_assets_finalization_v2')
size=mod(ROOT/'.agents/lib/decomposition_size.py','kv_size_v2')
psd=mod(ROOT/'.agents/skills/wxian-layered-psd-export/scripts/psd_export.py','kv_psd_v2')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def wj(p,v): p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def rel(p): return p.resolve().relative_to(ROOT.resolve()).as_posix()
def expect_block(fn,label):
 try: fn()
 except Exception as exc: return str(exc)
 raise AssertionError(f'negative fixture unexpectedly passed: {label}')
def build_psd(f):
 for p in (f['final']/'layered.psd',f['final']/'layered.preview.png',f['final']/'layered-psd.json'):
  if p.exists(): p.unlink()
 return psd.build(ROOT,f['mfp'],f['final']/'layered.psd',f['final']/'layered-psd.json')
def refresh_qa(f):
 q=json.loads(f['qap'].read_text(encoding='utf-8')); q['layer_manifest_sha256']=sha(f['mfp']); q['ownership_audit_sha256']=sha(f['ownp']); q['recomposition_sha256']=sha(f['rec']); q['recomposition_diff_sha256']=sha(f['diffp']); wj(f['qap'],q)
def make_fixture(req):
 inp=req/'input'; work=req/'work'; final=work/'final'; prompts=work/'api-prompts'
 inp.mkdir(parents=True); (req/'output').mkdir(); final.mkdir(parents=True); prompts.mkdir()
 wj(req/'state.json',{'primary_skill':'wxian-image-layer-decomposition','status':'active','revision':1}); (req/'request.md').write_text('resident KV v2 finalization selftest\n',encoding='utf-8')
 src=inp/'kv.png'; Image.new('RGBA',(1024,1024),(32,48,64,255)).save(src)
 contract=size.plan_size_contract((1024,1024),skill=size.SKILL_IMAGE,model='gpt-image-2.5-sunburst')
 surface=contract['work_surfaces'][0]; assert [surface['width'],surface['height']]==[1024,1024]
 work_src=work/'source-work.png'; shutil.copy2(src,work_src)
 delivery_ref=final/'delivery-reference.png'; shutil.copy2(src,delivery_ref)
 lg=work/'layer-graph.json'; og=work/'occlusion-graph.json'; ig=work/'interaction-graph.json'
 wj(lg,{'schema_version':'wxian.kv-layer-graph.v1','status':'READY','source_sha256':sha(src),'work_sha256':sha(work_src),'delivery_canvas_size':[1024,1024],'nodes':[{'node_id':'L000_BG','kind':'environment','depth_band':'BG_DEEP','bbox':[0,0,1024,1024]}],'edges':[]})
 wj(og,{'schema_version':'wxian.kv-occlusion-graph.v1','status':'READY','source_sha256':sha(src),'edges':[]})
 wj(ig,{'schema_version':'wxian.kv-interaction-graph.v1','status':'READY','source_sha256':sha(src),'clusters':[]})
 prompt=prompts/'visible.txt'; prompt.write_text('extract visible source pixels',encoding='utf-8')
 params={'size':'1024x1024','quality':'max','background':'transparent','moderation':'auto','output_format':'png'}
 layer={'layer_id':'L000_BG','name':'background','layer_type':'background-clean','depth_band':'BG_DEEP','z_order':0,'strategy':'source_locked_extract','source_bbox_hint':[0,0,1024,1024],'anchor_hint':[0,0],'includes':['environment'],'excludes':[],'interaction_cluster_id':'','interaction_members':[],'bound_assets':[],'occluded_by':[],'occludes':[],'primary_pixel_owner':True,'visible_region_policy':'source_locked','reconstruction_scope':'visible only','minimum_visible_coverage_ratio':1.0,'motion_margin_px':0,'motion_envelope_px':{'left':0,'top':0,'right':0,'bottom':0},'reconstruction_confidence':'none','reconstruction_provenance':[],'blend_mode':'normal','blend_mode_hint':'normal','api_calls':[{'id':'visible','mode':'image_to_image_edit','prompt_path':rel(prompt),'output_path':rel(final/'originals/provider/L000_BG__visible.png'),'base_image':rel(work_src),'parameters':params}]}
 plan={'schema_version':'wxian.kv-layer-plan.v6','status':'READY','decomposition_profile':'kv-depth','source_image':rel(src),'source_sha256':sha(src),'source_canvas_size':[1024,1024],'delivery_canvas_size':[1024,1024],'work_source':rel(work_src),'work_sha256':sha(work_src),'work_canvas_size':[1024,1024],'size_contract':contract,'default_model':'gpt-image-2.5-sunburst','downstream_intent':'editable','analysis_artifacts':{'layer_graph':{'path':rel(lg),'sha256':sha(lg)},'occlusion_graph':{'path':rel(og),'sha256':sha(og)},'interaction_graph':{'path':rel(ig),'sha256':sha(ig)}},'relationships':[],'layers':[layer]}
 pp=work/'layer-plan.json'; wj(pp,plan); batch.validate_plan(pp,ROOT); shutil.copy2(lg,final/'layer-graph.json')
 lp=final/'layers/L000_BG.png'; cp=final/'crops/L000_BG.png'; mp=final/'masks/L000_BG.png'; master=final/'originals/L000_BG.png'; raw=final/'originals/provider/L000_BG__visible.png'
 for p in (lp,cp,mp,master,raw): p.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2(work_src,raw)
 shutil.copy2(delivery_ref,lp); shutil.copy2(delivery_ref,cp); Image.new('RGBA',(1024,1024),(255,255,255,255)).save(mp)
 receipt=final/'master-receipts/L000_BG.json'
 master_value=assets.finalize_editable_master_command(SimpleNamespace(workspace_root=ROOT,layer=rel(lp),provider_original=[rel(raw)],bbox=[0,0,1024,1024],minimum_visible_coverage_ratio=1.0,output=rel(master),record_output=rel(receipt),layer_id='L000_BG'))
 entry={'layer_id':'L000_BG','name':'background','status':'passed','layer_type':'background-clean','depth_band':'BG_DEEP','z_order':0,'file':rel(lp),'sha256':sha(lp),'output_mode':'delivery-canvas','anchor':[0,0],'bbox':[0,0,1024,1024],'dependencies':[],'blend_mode':'normal','blend_mode_hint':'normal','primary_pixel_owner':True,'source_visible_mask':rel(mp),'source_visible_mask_sha256':sha(mp),'source_visible_region_source_locked':True,'reconstructed_region_present':False,'reconstruction_confidence':'none','reconstruction_provenance':[],'minimum_visible_coverage_ratio':1.0,'motion_envelope_px':{'left':0,'top':0,'right':0,'bottom':0},'motion_margin_px':0,'interaction_members':[],'qa_status':'PASS','crop_file':rel(cp),'crop_sha256':sha(cp),'editable_master':{'file':master_value['file'],'sha256':master_value['sha256'],'size':master_value['size'],'scale_vs_delivery':1.0,'provenance':'source_preserved','derivation':master_value['derivation'],'provider_originals':master_value['provider_originals']}}
 mf={'schema_version':'wxian.kv-final-layer-manifest.v2','status':'READY','decomposition_skill':'wxian-image-layer-decomposition','layer_plan_path':rel(pp),'layer_plan_sha256':sha(pp),'source_image':rel(src),'source_sha256':sha(src),'source_canvas_size':[1024,1024],'delivery_canvas_size':[1024,1024],'delivery_reference_image':rel(delivery_ref),'delivery_reference_sha256':sha(delivery_ref),'layer_graph_path':rel(final/'layer-graph.json'),'layer_graph_sha256':sha(final/'layer-graph.json'),'layers':[entry]}; mfp=final/'layer-manifest.json'; wj(mfp,mf)
 overlap=final/'ownership-overlap.png'; holes=final/'ownership-holes.png'
 actual,overlap_map,holes_map=finalizer.ownership_maps([mp],(1024,1024),16)
 finalizer.alpha_mask_rgba(overlap_map).save(overlap)
 finalizer.alpha_mask_rgba(holes_map).save(holes)
 own={'status':'passed','operation':'ownership-audit',**actual,'overlap_output':rel(overlap),'overlap_sha256':sha(overlap),'hole_output':rel(holes),'hole_sha256':sha(holes)}; ownp=final/'ownership-audit.json'; wj(ownp,own)
 rec=final/'recomposition.png'; shutil.copy2(delivery_ref,rec); metrics,diffimg=finalizer.diff_artifacts(finalizer.load_rgba(delivery_ref),finalizer.load_rgba(rec),None); diffpng=final/'recomposition-diff.png'; diffimg.save(diffpng)
 diff={'source':rel(delivery_ref),'source_sha256':sha(delivery_ref),'recomposed':rel(rec),'recomposed_sha256':sha(rec),'diff':rel(diffpng),'diff_sha256':sha(diffpng),'evaluation_mask':None,'evaluation_mask_sha256':None,'mean_absolute_channel_difference':metrics['mean_absolute_channel_difference'],'changed_bbox':metrics['changed_bbox'],'pixel_identical':metrics['pixel_identical'],'professional_visual_review_required':True}; diffp=final/'recomposition-diff.json'; wj(diffp,diff)
 qa={'schema_version':'wxian.kv-layer-qa.v1','status':'PASS','layer_manifest_path':rel(mfp),'layer_manifest_sha256':sha(mfp),'ownership_audit_path':rel(ownp),'ownership_audit_sha256':sha(ownp),'recomposition_path':rel(rec),'recomposition_sha256':sha(rec),'recomposition_diff_path':rel(diffp),'recomposition_diff_sha256':sha(diffp),'reviewed_layer_ids':['L000_BG']}
 for k in ('source_visible_fidelity_review','alpha_boundary_review','geometry_review','occlusion_review','interaction_integrity_review'): qa[k]='PASS'
 qap=final/'layer-qa.json'; wj(qap,qa)
 return locals()
def main():
 argparse.ArgumentParser().parse_args(); st=psd.backend_status(ROOT)
 if st.get('status')!='ready': print(json.dumps({'status':'blocked','tool':'kv-finalization-selftest','reason':st.get('reason'),'pre_psd_contract':'not_executed'},ensure_ascii=False)); return 2
 parent=ROOT/'requests/image-layer-decomposition'; parent.mkdir(parents=True,exist_ok=True); req=Path(tempfile.mkdtemp(prefix='【20260921】99-KVTEST-v858-',dir=parent)); results={}
 try:
  f=make_fixture(req); build_psd(f); good=gate.validate(ROOT,req); assert good['layer_count']==1; results['positive']='PASS'
  saved=f['mfp'].read_bytes(); mf=json.loads(saved); mf['layers'][0]['sha256']='0'*64; wj(f['mfp'],mf); refresh_qa(f); results['stale_layer_hash']='BLOCK' if 'sha256 mismatch' in expect_block(lambda:gate.validate(ROOT,req),'stale layer hash') else 'BLOCK'
  f['mfp'].write_bytes(saved); refresh_qa(f)
  mf=json.loads(f['mfp'].read_text(encoding='utf-8')); mf['layers'][0]['editable_master']['provider_originals']=[]; wj(f['mfp'],mf); refresh_qa(f); expect_block(lambda:gate.validate(ROOT,req),'missing provider original lineage'); results['missing_provider_original_lineage']='BLOCK'
  f['mfp'].write_bytes(saved); refresh_qa(f)
  mf=json.loads(f['mfp'].read_text(encoding='utf-8')); mf['layers'][0]['editable_master']['scale_vs_delivery']=2.0; wj(f['mfp'],mf); refresh_qa(f); expect_block(lambda:gate.validate(ROOT,req),'wrong normal master scale'); results['wrong_master_scale']='BLOCK'
  f['mfp'].write_bytes(saved); refresh_qa(f)
  receipt=f['final']/'layered-psd.json'; receipt_bytes=receipt.read_bytes(); receipt.unlink(); expect_block(lambda:gate.validate(ROOT,req),'missing PSD receipt'); results['missing_psd_receipt']='BLOCK'; receipt.write_bytes(receipt_bytes)
  print(json.dumps({'status':'ready','tool':'kv-finalization-selftest','results':results,'network_called':False},ensure_ascii=False)); return 0
 finally:
  shutil.rmtree(req,ignore_errors=True)
  for p in (parent,parent.parent):
   try:p.rmdir()
   except OSError:pass
if __name__=='__main__': raise SystemExit(main())
