#!/usr/bin/env python3
"""Cross-module qualification for KV reconstruction contracts.

Validates Visual Spec/Prompt Binding for reconstruction plans and source-only extraction
behavior without network access.
"""
from __future__ import annotations
import os as _bytecode_guard_os, sys as _bytecode_guard_sys
_bytecode_guard_sys.dont_write_bytecode = True
_bytecode_guard_os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
import uuid
from pathlib import Path

from PIL import Image

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


batch = load_module(HERE / "layer_batch.py", "kv_layer_batch_integration")
gate = load_module(
    ROOT / ".agents" / "skills" / "workspace-governance" / "scripts" / "workspace_gate.py",
    "kv_workspace_gate_integration",
)
API = ROOT / ".agents" / "skills" / "image-generation-api" / "scripts" / "generation_api.py"
size_mod = load_module(ROOT / ".agents" / "lib" / "decomposition_size.py", "kv_decomposition_size_integration")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def call_api(request_path: Path) -> tuple[int, dict]:
    completed = subprocess.run(
        [sys.executable, str(API), "dry-run", "--request", str(request_path), "--workspace-root", str(ROOT)],
        text=True, capture_output=True, timeout=60,
    )
    try:
        payload = json.loads(completed.stdout)
    except json.JSONDecodeError as exc:
        raise AssertionError(f"generation_api returned non-JSON output: {completed.stdout[-1000:]} {completed.stderr[-1000:]}") from exc
    return completed.returncode, payload


def main() -> int:
    user_root = ROOT / "user"
    user_manifest = user_root / "manifest.json"
    had_user_root = user_root.exists()
    original_user_manifest = user_manifest.read_bytes() if user_manifest.is_file() else None
    parent = ROOT / "requests" / "image-layer-decomposition"
    try:
        # The production regression must exercise the enabled lifecycle.  An
        # absent/disabled user store only proves the explicit skip path.
        user_root.mkdir(parents=True, exist_ok=True)
        write_json(user_manifest, {"version": 1, "enabled": True, "skills": []})
        parent.mkdir(parents=True, exist_ok=True)
        request = parent / f"kv-integration-selftest-{uuid.uuid4().hex[:12]}"
        request.mkdir(parents=True, exist_ok=False)
        inp = request / "input"
        work = request / "work"
        prompts = work / "api-prompts"
        inp.mkdir(parents=True)
        prompts.mkdir(parents=True)
        (request / "output").mkdir(parents=True)
        write_json(request / "state.json", {
            "primary_skill": "wxian-image-layer-decomposition", "status": "active", "revision": 1,
        })
        (request / "request.md").write_text(
            "Decompose this KV into editable layers. Preserve source-visible pixels and reconstruct only hidden regions.\n",
            encoding="utf-8",
        )
        # Exercise the same Personal Context lifecycle as a real governed request.
        # When Personal Layer is enabled this resolves context and writes the
        # primary-skill consumption receipt; when disabled it is an explicit skip.
        gate.maybe_refresh_personal_context(ROOT, request)
        personal = gate.consume_personal_context(
            ROOT, request.relative_to(ROOT).as_posix(), "wxian-image-layer-decomposition"
        )
        context_path = work / "personal-context.json"
        receipt_path = work / "personal-execution.json"
        assert personal.get("status") == "loaded", personal
        context = json.loads(context_path.read_text(encoding="utf-8"))
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
        assert context.get("execution_status") == "loaded", context
        assert context.get("execution_binding") == "wxian-image-layer-decomposition", context
        assert receipt.get("status") == "consumed", receipt
        assert receipt.get("consumer") == "wxian-image-layer-decomposition", receipt
        assert receipt.get("consumer_source") == "explicit-command-argument", receipt
        source = inp / "kv.png"
        canonical = work / "source-work.png"
        Image.new("RGBA", (1024, 1024), (32, 48, 64, 255)).save(source)
        Image.open(source).save(canonical)
        size_contract = size_mod.plan_size_contract((1024, 1024), skill=size_mod.SKILL_IMAGE, model="gpt-image-2.5-sunburst")
        source_rel = source.relative_to(ROOT).as_posix()
        canonical_rel = canonical.relative_to(ROOT).as_posix()
        write_json(work / "source-lock.json", {"required_sources": [source_rel]})

        layer_graph = work / "layer-graph.json"
        occlusion_graph = work / "occlusion-graph.json"
        interaction_graph = work / "interaction-graph.json"
        write_json(layer_graph, {
            "schema_version": "wxian.kv-layer-graph.v1", "status": "READY",
            "source_sha256": sha(source), "work_sha256": sha(canonical),
            "delivery_canvas_size": [1024, 1024],
            "nodes": [{"node_id": "L000_BG", "kind": "environment", "depth_band": "BG_DEEP", "bbox": [0, 0, 1024, 1024]}],
            "edges": [],
        })
        write_json(occlusion_graph, {
            "schema_version": "wxian.kv-occlusion-graph.v1", "status": "READY",
            "source_sha256": sha(source), "edges": [],
        })
        write_json(interaction_graph, {
            "schema_version": "wxian.kv-interaction-graph.v1", "status": "READY",
            "source_sha256": sha(source), "clusters": [],
        })
        graph_files = {
            "layer_graph": {"path": layer_graph.relative_to(ROOT).as_posix(), "sha256": sha(layer_graph)},
            "occlusion_graph": {"path": occlusion_graph.relative_to(ROOT).as_posix(), "sha256": sha(occlusion_graph)},
            "interaction_graph": {"path": interaction_graph.relative_to(ROOT).as_posix(), "sha256": sha(interaction_graph)},
        }
        prompt = prompts / "clean.txt"
        prompt.write_text("Remove foreground subject evidence and reconstruct only hidden environment; do not alter visible source regions.\n", encoding="utf-8")
        prompt_rel = prompt.relative_to(ROOT).as_posix()
        params_opaque = {"size": "1024x1024", "quality": "max", "background": "opaque", "moderation": "auto", "output_format": "png"}
        params_alpha = {**params_opaque, "background": "transparent"}
        layer = {
            "layer_id": "L000_BG", "name": "clean background", "layer_type": "background-clean", "depth_band": "BG_DEEP", "z_order": 0,
            "strategy": "clean_plate_patch", "source_bbox_hint": [0, 0, 1024, 1024], "anchor_hint": [0, 0],
            "includes": ["environment"], "excludes": ["foreground subject"], "interaction_cluster_id": "", "interaction_members": [], "bound_assets": [],
            "occluded_by": [], "occludes": [], "primary_pixel_owner": True, "visible_region_policy": "source_locked",
            "reconstruction_scope": "hidden region only", "minimum_visible_coverage_ratio": 0.01, "motion_margin_px": 16,
            "motion_envelope_px": {"left": 16, "top": 16, "right": 16, "bottom": 16},
            "reconstruction_confidence": "medium", "reconstruction_provenance": ["adjacent visible environment"],
            "blend_mode": "normal", "blend_mode_hint": "normal",
            "api_calls": [{
                "id": "clean", "mode": "image_to_image_edit", "prompt_path": prompt_rel,
                "output_path": (work / "final" / "originals" / "provider" / "L000_BG__clean.png").relative_to(ROOT).as_posix(),
                "base_image": canonical_rel, "parameters": params_opaque,
            }],
        }
        plan = {
            "schema_version": "wxian.kv-layer-plan.v6", "status": "READY",
            "source_image": source_rel, "source_sha256": sha(source),
            "work_source": canonical_rel, "work_sha256": sha(canonical),
            "source_canvas_size": [1024, 1024], "delivery_canvas_size": [1024, 1024],
            "work_canvas_size": [1024, 1024], "size_contract": size_contract,
            "default_model": "gpt-image-2.5-sunburst", "downstream_intent": "light-parallax", "decomposition_profile": "kv-depth",
            "analysis_artifacts": graph_files, "relationships": [], "layers": [layer],
        }
        plan_path = work / "layer-plan.json"
        write_json(plan_path, plan)

        # Reconstructed plan is detected by the current governance schema.
        assert gate.request_has_reconstructed_layers(request) is True
        built = batch.build(plan_path, ROOT, force=True)
        req = ROOT / built["request_files"][0]
        code, payload = call_api(req)
        assert code != 0 and payload.get("status") == "blocked" and "visual-spec.json" in payload.get("reason", ""), payload

        prepared = batch.prepare_contract(plan_path, ROOT, force=True)
        assert prepared["status"] == "success"
        built = batch.build(plan_path, ROOT, force=True)
        req = ROOT / built["request_files"][0]
        code, payload = call_api(req)
        assert code == 0 and payload.get("status") == "ready_for_call", payload
        binding = payload.get("visual_reconstruction_binding", {})
        assert binding.get("status") == "required" and binding.get("layer_plan_sha256") == sha(plan_path), binding

        # The API must reject both a missing and a forged execution receipt.
        # This proves the successful dry run above actually crossed the
        # enabled Personal Context gate instead of only preparing a Context.
        original_receipt = receipt_path.read_bytes()
        receipt_path.unlink()
        code, payload = call_api(req)
        assert code != 0 and payload.get("status") == "blocked" and "personal-execution.json" in payload.get("reason", ""), payload
        receipt_path.write_bytes(original_receipt)
        forged_receipt = json.loads(original_receipt.decode("utf-8"))
        forged_receipt["consumer"] = "forged-primary-skill"
        write_json(receipt_path, forged_receipt)
        code, payload = call_api(req)
        assert code != 0 and payload.get("status") == "blocked" and "consumer" in payload.get("reason", ""), payload
        receipt_path.write_bytes(original_receipt)

        # Source-only extraction uses the source-extraction path without a reconstruction Visual Contract.
        for name in ("visual-spec.json", "prompt-binding.json", "layer-prompt-manifest.json", "layer-prompt-package.md"):
            (work / name).unlink(missing_ok=True)
        plan["layers"][0]["strategy"] = "source_locked_extract"
        plan["layers"][0]["visible_region_policy"] = "source_locked"
        plan["layers"][0]["reconstruction_scope"] = "visible only"
        plan["layers"][0]["motion_margin_px"] = 0
        plan["layers"][0]["motion_envelope_px"] = {"left": 0, "top": 0, "right": 0, "bottom": 0}
        plan["layers"][0]["reconstruction_confidence"] = "none"
        plan["layers"][0]["reconstruction_provenance"] = []
        plan["layers"][0]["api_calls"] = [{
            "id": "visible", "mode": "image_to_image_edit", "prompt_path": prompt_rel,
            "output_path": (work / "final" / "originals" / "provider" / "L000_BG__visible.png").relative_to(ROOT).as_posix(),
            "base_image": canonical_rel, "parameters": params_alpha,
        }]
        write_json(plan_path, plan)
        assert gate.request_has_reconstructed_layers(request) is False
        prepared = batch.prepare_contract(plan_path, ROOT, force=True)
        assert prepared["status"] == "not_required"
        built = batch.build(plan_path, ROOT, force=True)
        req = ROOT / built["request_files"][0]
        code, payload = call_api(req)
        assert code == 0 and payload.get("status") == "ready_for_call", payload
        assert payload.get("visual_reconstruction_binding", {}).get("status") == "not_required", payload

        print(json.dumps({
            "status": "ready", "tool": "kv-layer-integration-selftest",
            "positive": 4, "negative": 3, "network_called": False,
        }, ensure_ascii=False))
        return 0
    finally:
        if "request" in locals():
            shutil.rmtree(request, ignore_errors=True)
        if original_user_manifest is None:
            user_manifest.unlink(missing_ok=True)
            if not had_user_root:
                shutil.rmtree(user_root, ignore_errors=True)
        else:
            user_manifest.write_bytes(original_user_manifest)


if __name__ == "__main__":
    raise SystemExit(main())
