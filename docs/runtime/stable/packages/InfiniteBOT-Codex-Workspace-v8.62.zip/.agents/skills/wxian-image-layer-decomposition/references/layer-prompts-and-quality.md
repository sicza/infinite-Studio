# KV / Banner Layer Prompt & Quality Rules

## 1. Prompt 结构

每个 Pass 只做一件事：

```text
TASK
TARGET
INTERACTION MEMBERS
KEEP
REMOVE
VISIBLE vs COMPLETE
OCCLUDERS
RECONSTRUCTION BOUNDARY
POSITION / SCALE / PERSPECTIVE LOCK
ALPHA SEMANTIC
NO REDESIGN
```

尺寸、quality、format、background 属于 API 参数，不靠 Prompt 反复强调。

## 2. Visible Alpha

```text
Extract only [TARGET UNIT] from the input key art.
Keep the exact original on-canvas position, scale, perspective, pose, visible silhouette, materials and visible proportions.
The target unit includes [INTERACTION MEMBERS].
Exclude [NON TARGETS], all unrelated environment, other characters, unrelated props, text/logo and unrelated effects.
This pass is only for the currently visible region. Do not invent hidden anatomy or hidden geometry.
Every non-target pixel must be transparent. Do not draw a gray/white/checkerboard/background plate.
Preserve natural soft alpha on hair, fur, translucent edges and motion-blurred boundaries where actually visible.
```

该 Pass 的 RGB 不是最终 Authority；主要取 Alpha，再 Source Lock 原 RGB。

## 3. Interaction-bound Subject Reconstruction

```text
Reconstruct only [SUBJECT UNIT] as one complete interaction-bound asset on transparent background.
The unit consists of [PERSON/CREATURE] together with [OBJECTS CURRENTLY HELD/WORN/CARRIED/MOUNTED/DRIVEN/CONTROLLED/PUSHED/PULLED/TETHERED/CONNECTED/ANCHORED].
Treat these members as one action/performance unit. Do not separate them simply because they belong to different object categories.
Preserve identity, face, hair, body proportions, costume construction, object design, pose, contact points, camera perspective, original on-canvas scale and placement.
Reconstruct only the regions hidden by [OCCLUDERS], extending only through [MOTION SAFE MARGIN].
Hidden reconstruction must follow visible anatomy/geometry, material, lighting direction and perspective.
Remove every unrelated object, environment, character, text/logo and effect.
Do not recenter, enlarge, beautify, redesign, change pose, change costume, or invent a new scene.
```

## 4. Independent Support / Vehicle / Prop

仅当它不属于任何 interaction-bound subject unit 才独立：

```text
Extract only [INDEPENDENT UNIT].
Preserve original scale, perspective, orientation, design, visible materials and on-canvas position.
Complete only the hidden geometry required by the planned motion margin.
Do not include any person/object already owned by another interaction-bound subject unit.
Transparent background; no environment, generic ground, UI or text.
```

## 5. Building / Structure

```text
Extract only [STRUCTURE].
Include only permanently attached structural base, steps, bridge deck, platform or fixed construction that must move with it.
Do not include ordinary continuous terrain.
Preserve exact perspective, scale, material, weathering, lighting and original position.
Reconstruct only surfaces hidden by named occluders and only through the planned reveal margin.
Transparent background; no unrelated environment, characters, vehicles, text or FX.
```

## 6. Clean Plate

```text
Create a clean environment plate from the input key art.
Preserve the exact camera, horizon, perspective, visible terrain, sky, water, vegetation, material, color and lighting in all already-visible environment regions.
Remove [UPPER LAYERS].
Reconstruct only the environment that would continue behind the removed objects and only where the removal exposes missing content.
Use adjacent geometry, texture, perspective and light as evidence.
Do not add new focal props, characters, structures or decorative inventions.
Do not recompose or restyle the already-visible environment.
```

正式 clean plate 必须再用 source-preserving patch，只采用模型填洞区域。

## 7. Foreground Environment

```text
Extract only [FOREGROUND OCCLUDER].
Keep exact original on-canvas position, scale, silhouette and visible material.
Do not include subjects/background behind it.
Transparent background.
```

## 8. Shadow / Reflection / FX

### Shadow

```text
Isolate only the specified shadow contribution associated with [OWNER].
Preserve its apparent on-canvas footprint, softness and intensity relationship.
Transparent background. No owner object or receiver surface pixels.
```

### FX

```text
Isolate only [SMOKE/FLAME/GLOW/PARTICLES/ENERGY].
Preserve apparent position, direction, scale, hue and intensity distribution.
Output continuous soft alpha with no solid backdrop.
```

无法恢复真实 Alpha 时标 `model_native_alpha`，不要声称是源 Alpha。

## 9. Text / Logo

模型只负责 Alpha 分割，不重写可见文字：

```text
Isolate only the existing title/logo/graphic overlay exactly at its original position.
Do not alter wording, glyph shapes, logo geometry, spacing, outline, material, shadow or glow.
Remove every non-overlay object.
Transparent background.
```

最终 RGB 优先 Source Lock。

## 10. QA

### Alpha

在 checkerboard / black / white / #808080 检查：

- 真 Alpha；
- 无伪棋盘格；
- 无灰/白/黑边；
- 软边连续；
- 无非目标污染；
- 无裁断。

### Reconstruction

隐藏区：

```text
结构连续
接触点连续
透视连续
材质连续
光向连续
只在允许 reveal 区域新增
```

### Recomposition

- 可见主体不漂；
- 无双轮廓；
- 无双地面/天空；
- 无双影/双辉光；
- interaction-bound unit 接触点恢复；
- 前后遮挡恢复；
- Logo/文字未被模型重写；
- 新生成内容只出现在源图没有证据的隐藏区。
