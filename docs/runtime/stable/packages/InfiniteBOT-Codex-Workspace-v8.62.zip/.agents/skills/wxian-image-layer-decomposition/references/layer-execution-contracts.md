# KV / Banner 图层执行、合成与失败续做

## 1. Output contract

本文件是 `wxian-image-layer-decomposition` 的**唯一人类可读 Final Output Contract Authority**。`SKILL.md` 与其它 Reference 只做摘要或语义说明，不得维护第二份 Final 目录或 Manifest 字段清单。

机器 Authority 为 `scripts/delivery_gate.py` 与共享 `.agents/lib/deterministic_layer_finalization.py`。若本文与机器 Gate 不一致，必须视为 Contract Drift 并修复，不能任选其一执行。

### 1.1 Pre-final / execution work

```text
work/source-work.png                 # provider-legal work surface
work/decomposition-size.json          # source/work/delivery + transforms when persisted
work/layer-analysis.md
work/layer-graph.json
work/occlusion-graph.json
work/interaction-graph.json
work/layer-plan.json
work/api-prompts/
work/layer-prompt-package.md       # reconstruction plan only
work/layer-prompt-manifest.json    # reconstruction plan only
work/visual-spec.json              # reconstruction plan only
work/prompt-binding.json           # reconstruction plan only
work/generation-plan.json          # includes source_contract
work/api-requests/
work/final/originals/provider/     # Provider 原始响应；每个选中的 API pass 的不可变原始证据
work/final/originals/<layer_id>.png # 批准的 PSD 原件：由 final full-canvas layer 按 bbox 确定性裁切，PSD 唯一可嵌入的 source
work/intermediate/                 # source-lock / masks / merge 中间件
```

### 1.2 Mandatory final pack

```text
work/final/layers/full-canvas/<layer_id>.png
work/final/layers/crops/<layer_id>.png
work/final/layer-manifest.json
work/final/layer-graph.json
work/final/ownership-audit.json
work/final/ownership-overlap.png
work/final/ownership-holes.png
work/final/recomposition.png
work/final/recomposition-diff.png
work/final/recomposition-diff.json
work/final/layer-qa.json
work/final/layered.psd
work/final/layered.preview.png
work/final/layered-psd.json
```

Primary Pixel Owner 的 `source_visible_mask` 也是 mandatory final artifact；实际路径由 `layer-manifest.json` 绑定，不建立第二套固定命名。若 `recomposition-diff.json` 绑定 evaluation mask，该 mask 同样属于正式交付证据。上述 Gate-required 文件必须进入 active `delivery-manifest.json`。

`layered.psd` 由独立 `$wxian-layered-psd-export` 消费 Final Manifest 生成。PSD document canvas 等于 `delivery_canvas`；每个 layer 是 Embedded Smart Object，其 `editable_master`、hash、intrinsic size 与 delivery-space bbox/transform 必须可代码回读验证。普通拆图的默认 `editable_master` 为 1× bbox。不存在 raster PSD fallback。

生产与回读只能使用：

```bash
python .agents/skills/wxian-layered-psd-export/scripts/psd_export.py build \
  --workspace-root <workspace-root> \
  --manifest work/final/layer-manifest.json \
  --output work/final/layered.psd \
  --receipt work/final/layered-psd.json

python .agents/skills/wxian-layered-psd-export/scripts/psd_export.py verify \
  --workspace-root <workspace-root> \
  --receipt work/final/layered-psd.json
```

`layered.preview.png` 是由同一 exporter 从 manifest/master 确定性生成的 1× document composite。

### 1.3 Optional QA views

```text
work/final/previews/
```

`previews/`、灰/黑/白/棋盘背景预览只用于人工 QA convenience，**不是 delivery Authority，也不是 completion mandatory artifact**。正式图层 Authority 是 Manifest 绑定的 delivery-space RGBA PNG + `editable_master` + geometry；full-canvas PNG 用于确定性回合成，PSD Smart Object 使用 editable master。

## 2. Source / Work / Delivery Size Contract

源图尺寸是输入事实；模型工作尺寸只服务 provider 合法性；最终交付尺寸默认保持源图。普通拆图默认 prefer 1× work，尺寸对齐优先 padding，不得默认升 4K，也不得让模型 work surface 静默改写最终 PSD 尺寸。

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py prepare-work-surface ^
  --source <source> ^
  --output <work/source-work.png> ^
  --record-output <work/decomposition-size.json> ^
  --profile image ^
  --model gpt-image-2.5-sunburst ^
  --workspace-root .
```

Plan / Generation API 必须同时绑定 `source_canvas_size`、`delivery_canvas_size`、`work_canvas_size` 与完整 `size_contract`。Source-visible RGB 回写必须从原始 source/delivery reference 取像素，不能把缩小后的模型工作图重新放大冒充原始像素。

随后直接从原始 source 建立 delivery-space Reference；禁止从 work surface 回投影生成此 Reference：

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py prepare-delivery-reference ^
  --source <source> ^
  --size-contract <work/decomposition-size.json> ^
  --output <work/final/delivery-reference.png> ^
  --workspace-root .
```

默认 `delivery=source` 时保持 source RGB 像素；只有用户显式要求不同 delivery 尺寸时才从原 source 单次重采样。Final Gate 会从原 source 重新计算 expected delivery reference 并逐像素比对，因此错误 Reference + 自报 hash 无法通过。

## 3. Native Alpha Output QA

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py alpha-audit ^
  --layer <generated-transparent.png> ^
  --report <work/...alpha.json> ^
  --workspace-root .
```

透明输出必须 RGBA 且存在透明像素。

## 4. Source Pixel Lock

将 Image 2.5 的透明提取仅作为 Alpha carrier，把源图 RGB 锁回：

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py source-lock ^
  --source <work/final/delivery-reference.png> ^
  --alpha-carrier <visible-alpha.png> ^
  --output <work/intermediate/Lxxx-visible-locked.png> ^
  --workspace-root .
```

这一步的价值：可见区保持源画面，而不是接受模型重画后的近似 RGB。

## 5. Hidden Reconstruction Merge

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py merge-reconstruction ^
  --visible <work/intermediate/Lxxx-visible-locked.png> ^
  --reconstruction <work/final/originals/provider/Lxxx-reconstruct.png> ^
  --output <work/final/layers/full-canvas/Lxxx.png> ^
  --workspace-root .
```

合并逻辑：

```text
visible Alpha 覆盖区 → visible/source RGB 为 Authority
仅 reconstruction 独有 Alpha 区 → 模型补全
```

## 6. Clean Plate Patch

先把所有应从背景移除对象的 visible-alpha 合成 occupancy mask：

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py mask-union ^
  --layers <visible-a.png> <visible-b.png> ... ^
  --output <work/intermediate/background-occlusion-mask.png> ^
  --expand 6 ^
  --feather 2 ^
  --workspace-root .
```

再只用模型候选补洞：

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py patch-clean-plate ^
  --source <work/final/delivery-reference.png> ^
  --generated <work/final/originals/provider/L000-background-clean.png> ^
  --mask <work/intermediate/background-occlusion-mask.png> ^
  --output <work/final/layers/full-canvas/L000_BACKGROUND_CLEAN.png> ^
  --workspace-root .
```

这样未遮挡环境保持源像素，只有需要移除/补全的区域来自模型。

## 7. Crop Derivative

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py crop ^
  --layer <full-canvas-layer.png> ^
  --output <component-crop.png> ^
  --record-output <crop-record.json> ^
  --padding 16 ^
  --workspace-root .
```

crop 只由通过 QA 的 full-canvas 图层确定性裁切产生。

## 8. Preview / Gray Review

## 8.1 Approved PSD Original

每个 API layer 完成 source-lock / merge 后，必须以**计划阶段固定的 bbox**生成 PSD 原件；不得按偶然 Alpha bbox 再猜测位置，也不得把 Provider 的整张 work-surface 直接缩放进 PSD。

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py finalize-editable-master ^
  --layer <work/final/layers/full-canvas/L300_HERO.png> ^
  --provider-original <work/final/originals/provider/L300_HERO__visible.png> ^
  --bbox <x> <y> <width> <height> ^
  --minimum-visible-coverage-ratio <analysis value> ^
  --output <work/final/originals/L300_HERO.png> ^
  --record-output <work/final/master-receipts/L300_HERO.json> ^
  --layer-id L300_HERO ^
  --workspace-root .
```

该命令阻断 bbox 外可见 Alpha、空内容和低于分析覆盖下限的 layer。将 receipt 的 `provider_originals` 与 `derivation` 原样写入 Final Manifest 的 `editable_master`；Gate 会独立重算，不接受手写替代。

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py preview --layer <layer.png> --output <preview.png>
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py gray-export --layer <layer.png> --output <gray.png>
```

灰底只是审阅衍生，不是拆层方法。

## 9. Batch API

Agent 完成 `layer-plan.json` 与每个 Prompt 后：

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_batch.py prepare-contract --plan <work/layer-plan.json> --workspace-root .
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_batch.py build --plan <work/layer-plan.json> --workspace-root .
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_batch.py run --plan <work/layer-plan.json> --workspace-root . --mode dry-run
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_batch.py run --plan <work/layer-plan.json> --workspace-root . --mode invoke
```

`prepare-contract` 对 reconstructed plan 是强制门禁，生成 `visual-spec.json / prompt-binding.json / layer-prompt-manifest.json` 并绑定当前 layer-plan、source/work/delivery size contract 和逐 Pass Prompt SHA。纯 source-only extraction 返回 `not_required`。

`build` 创建有限 generation-plan 与 API request，并写入 `source_contract`；Image API 会在每次 request preflight 时验证 plan/source/work/delivery hash 与 reconstructed Visual Contract。`dry-run` 复用单一进程离线验证整批 request，不要求 credential；`invoke` 才允许联网。`run` 不改 Prompt，不改参数，不自动重试内容性失败。

## 10. Source-visible Ownership Audit

Final manifest 中每个 `primary_pixel_owner=true` 的层都要提供 `source_visible_mask`（full-canvas RGBA mask）。然后：

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py ownership-audit ^
  --manifest <work/final/layer-manifest.json> ^
  --overlap-output <work/final/ownership-overlap.png> ^
  --hole-output <work/final/ownership-holes.png> ^
  --report <work/final/ownership-audit.json> ^
  --workspace-root .
```

如果某些区域（例如文字 strip、无 ground-truth 的 hidden completion）不应参与像素比较，先用 `regions-mask` 从 bbox 列表建立 evaluation mask：

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py regions-mask ^
  --regions-json <work/evaluation-exclusions.json> ^
  --size <WIDTHxHEIGHT> ^
  --mode exclude ^
  --expand 2 ^
  --feather 1 ^
  --output <work/final/evaluation-mask.png> ^
  --workspace-root .
```

## 11. Recompose

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py recompose ^
  --manifest <work/final/layer-manifest.json> ^
  --output <work/final/recomposition.png> ^
  --workspace-root .
```

然后：

```powershell
python .agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py compare ^
  --source <work/final/delivery-reference.png> ^
  --recomposed <work/final/recomposition.png> ^
  --diff-output <work/final/recomposition-diff.png> ^
  --report <work/final/recomposition-diff.json> ^
  --evaluation-mask <work/final/evaluation-mask.png> ^
  --workspace-root .
```

像素差异报告只是定位工具；最终仍要实际视觉检查。

## 12. Failure Continuation

单层失败：

```text
记录 layer/pass
保留其他已通过层
只重做失败 pass
重跑受依赖的 source-lock/merge/clean-plate/recomposition
```

API 超时、远端状态未知时遵守 image-generation-api 的 `remote_state_unknown` 规则，不自动再次收费提交。

## 13. Final completion contract

正式 `promote` 由 `scripts/delivery_gate.py` 验证，不接受只有通用 `delivery-manifest.json` 的完成声明。

### `wxian.kv-final-layer-manifest.v2`

根字段：

```text
schema_version / status
layer_plan_path / layer_plan_sha256
decomposition_skill
source_image / source_sha256 / source_canvas_size
delivery_canvas_size
delivery_reference_image / delivery_reference_sha256
layer_graph_path / layer_graph_sha256
layers[]
```

每个 `layers[]` 至少绑定：

```text
layer_id / status / layer_type / depth_band / z_order
file / sha256 / output_mode / anchor / bbox / dependencies
blend_mode / blend_mode_hint
primary_pixel_owner
source_visible_mask / source_visible_mask_sha256
source_visible_region_source_locked
reconstructed_region_present
reconstruction_confidence / reconstruction_provenance
motion_envelope_px / motion_margin_px / interaction_members
qa_status
crop_file / crop_sha256
editable_master.file / editable_master.sha256 / editable_master.size
editable_master.scale_vs_delivery (=1.0) / editable_master.provenance (`source_preserved | ai_reconstructed | ai_upscaled | deterministic_resample | mixed`)
editable_master.provider_originals[] (selected API output file / sha256 / work-canvas size)
editable_master.derivation (delivery_bbox_crop_v1 / source_canvas_file / source_canvas_sha256 / crop_bbox)
minimum_visible_coverage_ratio
```

Final layer set 必须与当前 `layer-plan.json` 完全一致；任何 `unrecoverable` layer 都不能作为 completed request 晋升。Gate 必须从当前 source/plan/layer/mask bytes 重算 Source Lock、ownership、recomposition 与 diff；report/QA 中的 PASS、pixel diff 数值或 hash 只能作为绑定记录，不能替代重新计算。

### `wxian.kv-layer-qa.v1`

必须 `status=PASS` 并 SHA 绑定：

```text
layer-manifest
ownership-audit
recomposition
recomposition-diff
```

同时显式记录全部 layer 已被 review，并令以下项为 `PASS`：

```text
source_visible_fidelity_review
alpha_boundary_review
geometry_review
occlusion_review
interaction_integrity_review
```

所有正式 layer/crop/mask/manifest/graph/QA/recomposition/PSD 资产必须进入 active `delivery-manifest.json`；否则 `workspace-governance promote` 必须 BLOCK。
