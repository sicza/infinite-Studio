# GPT Image 2.5 Layer Reconstruction Workflow

## 1. Default model

正式精确编辑默认 `gpt-image-2.5-sunburst`。Flare 只用于快速预览或经过真实同案例 A/B 后确认可替代。

## 2. Parameters

```text
model            gpt-image-2.5-sunburst
quality          low | medium | high | xhigh | max | auto
size             auto | WIDTHxHEIGHT
background       auto | opaque | transparent
output_format    png | jpeg | webp
moderation       auto | low
n                1
```

透明层：

```text
background=transparent
output_format=png
```

4K 是 size，不是 quality 别名。正式高保真层默认 `quality=max`。

## 3. Canonical size

- 宽高均为 16 的倍数；
- 比例 1:3–3:1；
- 每边不超过 3840 px；
- 总像素数 655,360–8,294,400；
- 总像素数超过 3,686,400（2560×1440）属于实验性高分辨率区域；
- 所有 Pass 明确绑定同一 delivery coordinate system；模型调用使用各自已登记的 provider-legal work surface。

## 4. Use image edit

默认 `image_to_image_edit`，以 source-work 提供：

```text
identity
composition
position
scale
projection
material
lighting
occlusion context
```

## 5. Native transparency

API 请求负责 Alpha；Prompt 负责语义：

```text
only target asset
all other pixels transparent
no solid backdrop
no checkerboard
no scenery unless owned by target
```

返回后必须程序检查真实 Alpha。

## 6. Two-pass reconstruction

### Pass A: visible

只获取当前可见 Alpha，不补隐藏结构。

### Pass B: reconstruct

只在 named occluders 后补全，并遵守 motion-safe margin。

### Merge

```text
source RGB under visible Alpha
+
model RGB only in reconstruction-only Alpha
```

## 7. Clean plate

模型生成 clean candidate 后，正式底板必须通过 occupancy/reveal mask patch：

```text
source visible environment unchanged
model only fills removed-object holes / reveal margin
```

## 8. Reference images

允许正式角色三视图/载具设定/建筑概念图作为 reference，但每张必须声明职责：

```text
source-work = current appearance / composition / placement
reference A = hidden costume structure
reference B = mechanical identity
```

不能“combine all references”导致身份串扰。

## 9. Mask semantics

如果 API 支持 mask，可用于缩小编辑范围，但不能把模型 mask 当像素级几何 Authority。GPT Image 2.5 的 mask 是 prompt-guided edit guidance，模型可能不会逐像素严格服从 mask 形状。

正式规则：

```text
provider mask = generation guidance
visible-region authority = source-work
final geometry boundary = deterministic alpha / occupancy / reveal mask
formal merge = source-lock / deterministic patch
```

因此无论 provider mask 是否存在，最终仍通过 source-lock / deterministic patch 保证未授权区域的源像素不被模型覆盖。
