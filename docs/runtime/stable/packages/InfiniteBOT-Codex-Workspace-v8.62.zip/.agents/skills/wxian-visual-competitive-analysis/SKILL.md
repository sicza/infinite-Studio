---
name: wxian-visual-competitive-analysis
description: 海外手游发行美术/视觉包装竞品分析。基于项目 Visual Baseline、当前包装或真实项目资产，与用户提供或互联网检索得到的竞品 KV、Banner、Campaign、商店包装及其他发行视觉交叉分析，提炼可迁移的视觉机制与专业实现，并转译、发散为自身项目可生产的新方向。用于美术竞品、视觉竞品、包装竞品及基于竞品反哺自身 KV/Banner/Campaign；纯商业、收入、下载、市场规模等竞品研究使用 wxian-conducting-internet-research，具体成品设计/生产使用对应视觉生产 Skill。
---

# 海外手游发行美术竞品分析

进入前执行 `$workspace-governance consume-personal-context --request <request> --consumer wxian-visual-competitive-analysis`；阻断则停止。

## 目标

执行：

**自身项目 × 竞品包装 → Compare → Extract → Transfer → Expand → 可生产的新视觉可能**

结果必须反哺当前包装、KV / Banner / Campaign、已有视觉资产、新资产需求或下一轮视觉探索。

## 1. 输入模式

### 主动互联网研究

用户未提供充分竞品资料时：

1. 读取项目事实、Visual Baseline、Current Packaging、目标市场和当前问题；
2. 调用 `$wxian-conducting-internet-research`，在当前 request 内完成竞品发现、真实视觉素材获取、用途/来源核验和必要背景补全；
3. 回看真实素材，由本 Skill 完成 Compare → Extract → Transfer → Expand。

优先研究 KV、Banner、Campaign Visual、Version / Season / Event / Anniversary / Collaboration Visual；按问题补 Store、Gameplay、广告、ICON、角色宣传或其他包装。

竞品可因用户/产品幻想、题材、视觉路线接近，某类包装解法优秀，或能打开新的项目方向而入选。新增竞品已很少改变主要判断时停止扩展。

### 用户资料分析

用户已提供竞品素材时：

1. 读取、识别并按用途/案例归类全部资料；用户提供广告、PV、Gameplay 录屏等视频时，在当前 request 内调用 `$wxian-video-source-analysis`，先形成可验证时间线、关键帧和事实/推断边界，不要求用户手动截图；
2. 围绕当前问题选择代表案例、优秀解法、重复模式、异常差异和高相关案例深挖；
3. 资料或判断标准存在关键缺口时，定向调用 `$wxian-conducting-internet-research` 补全；
4. 回到用户原始素材继续分析。

不要求逐图输出；未选中的素材继续作为证据背景。

## 2. 自身侧事实

优先读取 Workspace 已有：Visual Baseline、Current Packaging、KV / Banner / Campaign、角色与场景资产、产品定位、Gameplay、目标市场、已有竞品结论和当前问题。

- **Visual Baseline**：项目已确认的视觉事实、身份与基础约束。

本 Skill 作为 primary request 时，Baseline receipt 固定为 `work/baseline-consumption.json`，machine key=`visual-competitive-analysis`。Visual Director 在本 Skill 中是 `diagnostic-advisory`：用于把抽象判断落到可见机制，不强制伪造生产型 Visual Spec/Visual Gate。
- **Current Packaging**：当前如何把项目内容包装给用户。

主要比较 **Current Packaging × Competitor Packaging**；Visual Baseline 负责约束迁移是否符合项目身份。

Current Packaging 的执行不足不得写成 Visual Baseline 缺陷。

若尚无可比较的 Current Packaging，以 Visual Baseline、真实项目资产和产品卖点作为自身侧参照；没有自身可比方案证据时不判定 `Gap`。

## 3. 竞品证据

目标市场明确时，优先使用该市场实际出现的竞品包装；其他市场素材只作为补充案例。目标市场未明确时允许全球探索，但输出必须保留样本地区与渠道范围。

来源优先级：

1. 官方网站、News、Event、Update；
2. 官方社媒、官方视频；
3. 官方 Press Kit、新闻稿、合作页面；
4. 专业 Creative / 广告 / ASO 平台；
5. 其他公开资料。

历史视觉搜索结合：`key art / promotional art / campaign / banner / launch / anniversary / season / update / event / collaboration / character / wallpaper / official art`，必要时加入目标市场当地语言。

历史 ICON、历史商店截图与完整 ASO Timeline 仅在影响当前判断或已有可靠专业数据源时研究。

### 证据权限

- **画面证据**：支持构图、镜头、主体关系、色彩、光影、情绪、信息层级、视觉动线等直接可观察判断。
- **用途证据**：Brand KV、Campaign、市场、UA、版本、渠道任务等必须由可靠来源和上下文支持。

没有真实图片/视频帧证据，不做画面级判断。二手图片用途无法确认时，只分析画面；视频广告中的演绎镜头不能自动证明真实 Gameplay，除非视频本身提供足够可验证玩法证据。

### Research 交接

辅助研究至少交回：

- 竞品/案例身份；
- 可直接查看的真实视觉素材或可靠素材位置；
- 可确认的来源、时间、市场、渠道/用途上下文；
- 与当前视觉问题的相关性；
- 会限制判断的关键未知项。

不新增第二 request 或固定证据表。Research 负责发现和验证证据；本 Skill 必须基于真实素材完成专业判断。

## 4. 信息补全

以下缺口会影响结论时必须补证据：素材版本/Campaign、角色/场景/玩法/卖点、Gameplay 关系、重点包装原因、案例代表性、判断参照、当前市场/渠道状态。

- 事实缺口 → 补事实；
- 判断标准缺口 → 补案例、参照和上下文。

补充后仍无法确认时标记 `Unknown`，缩小结论范围。

## 5. Compare → Extract → Transfer → Expand

构图、镜头、景别、角色、动作、表情、场景、光影、色彩、材质、特效、排版、空间、叙事、信息层级等按需用于解释关键判断，不逐项填表。

当“为什么成立”仍停留在抽象形容词时，可调用 `$sicza-visual-director DIAGNOSE` 作为分析词典，把答案落到 `WORLD/SPACE / PERFORMANCE / PROJECTION / APPEARANCE / IMAGE STRUCTURE / IMAGE FORMATION / PERCEPTION / IDENTITY / GRAPHIC` 中真正有因果作用的机制。它不建立第二套竞品评分，也不得替代自身侧事实、竞品证据或传播任务判断。

### Compare

在同一个视觉/传播问题上比较：

- 双方在卖什么；
- 用户第一眼需要理解什么；
- 什么承担视觉核心；
- 视觉是在展示人物、世界、事件、关系、Gameplay，还是传递信息/建立记忆；
- 双方解决同一任务的核心差异是什么。

先确认任务层差异，再用具体美术实现解释差异。

### Extract

提炼两层：

- **方法层**：竞品解决了什么问题、为什么成立、可复用机制是什么；
- **实现层**：真正有生产价值的构图、镜头、主体关系、叙事、色彩、光影、信息组织等实现。

执行**去皮机制测试**：去掉竞品专属 IP、角色、剧情、世界观物件和独占符号，保留可迁移的视觉机制与专业实现。换成自身角色、世界和产品内容后仍成立，才进入 Transfer。

视觉解法的有效性以可观察传播任务为准，重点判断：表达清晰度、产品绑定、记忆锚点、资产利用。没有可靠效果数据时，不把视觉判断写成 CTR、CVR、ROAS、下载、收入或投放效果结论。

### Transfer

将方法层和实现层放回自身 Visual Baseline、Current Packaging、人物、场景、世界观、Gameplay、产品卖点和真实资产，形成：

- `Existing Asset`：已有资产的新用法；
- `Repackaging`：已有资产的新包装、叙事、关系或表现方式；
- `New Asset Opportunity`：基于项目真实设定/产品内容，值得新增生产的视觉资产。

只能依赖竞品专属内容成立的方向不迁移。

### Expand

从已完成的 Transfer 继续生成项目化视觉命题。每个方向必须：

- 基于项目真实设定、产品内容或合理可生产的新资产；
- 与项目定位成立；
- 相比 Current Packaging 增加新的视觉可能；
- 明确到可以进入下一轮方案探索；
- 不是简单换角色、背景、颜色、皮肤或抽象概念排列。

## 6. 单案例与多案例

单案例可形成 `Case Insight`，包括真实差异、问题、机制、实现、迁移和新方向；不得由单案例推导市场规律。

多案例用于判断同一问题的不同解法、跨竞品重复方法、同质化、标杆、少见有效解法和项目适配机会。

样本规则：

- 竞品是观察单位，图片不是投票单位；
- 同一竞品大量相似素材不增加市场权重；
- 搜索结果数量不等于市场占比；
- 同一素材重复转载只算一个案例；
- 传播任务、使用环境或用户阶段不可比的素材不直接归纳为同一规律。

## 7. 自身侧结论

- `Gap`：存在可比较的自身方案，竞品在同一问题上解决得更好；
- `Untapped Opportunity`：项目已有相关资产，但 Current Packaging 尚未充分利用；
- `New Possibility`：竞品启发的新包装方法；
- `New Asset Opportunity`：值得新增生产的视觉资产；
- `Unknown`：自身证据不足。

没有看到某种自身方案，不等于项目没有。

## 8. 洞察门与输出

核心洞察必须能回答：

1. 与自身当前做法/事实的真实差异是什么；
2. 竞品解决了什么问题；
3. 为什么成立，关键视觉实现是什么；
4. 去掉竞品专属外壳后，可复用方法是什么；
5. 进入自身项目后，会形成什么具体新可能。

无法回答时继续分析、补证据或删除。

“有冲击力、主体突出、层次丰富、色彩统一、高级、商业、品质、符合海外审美、值得参考、可以借鉴”只有在继续回答**为什么成立、如何实现、与自身有何差异、具体如何使用**时才保留。

最终结果按任务组织，优先保留：真实差异、有效机制、专业实现、项目化转译、未利用资产、新资产机会、新视觉方向、不应借鉴项，以及多竞品中的规律/标杆/同质化。

作为 primary request 时写入：

- `work/final/visual-competitive-analysis.md`
- `work/final/visual-competitive-analysis.html`
- `work/final-review.md`
- `work/delivery-manifest.json`

Markdown 是内部权威内容源；默认调用 `$wxian-html-delivery` 生成对外互动 HTML，把全部实际用于结论的代表证据图内嵌到对应案例与结论旁。若分析产生项目化概念验证图，则逐项通过 `$image-generation-api` 生成到 `work/final/originals/`，在 HTML 中绑定各自完整 Prompt 与调用回执；竞品截图和网页证据图保持 `evidence` 身份，不进入生成原图目录。默认 active 外部交付仅为 `interactive_html` 与存在时的全部 `generated_original`，再由 `$workspace-governance promote` 发布。

交付接入：必须调用 `$wxian-html-delivery`，并由 `$workspace-governance promote` 验证。

Visual Baseline 不由竞品分析直接修改；超出当前表达但不违反项目事实的结论标记为探索方向。具体 KV、Banner、Campaign 成品设计与生产交给对应专业 Skill。

## 完成条件

完成时，竞品中的具体视觉解法已经被验证、拆解、转译，并形成自身项目新的、具体的、可生产视觉可能。
