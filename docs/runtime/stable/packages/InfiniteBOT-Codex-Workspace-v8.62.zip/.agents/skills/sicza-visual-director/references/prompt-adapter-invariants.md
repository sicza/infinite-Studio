# Shared Prompt Adapter Invariants

本文件是 Workspace 内 Prompt Compilation 的共享稳定约束。Provider 的真实模型 ID、endpoint、参数、上传能力与运行可用性仍由现有 API Runtime / 用户当前执行环境负责；本文件不定义 API。

## 唯一上游

Prompt 只能消费：

1. 当前 Codex Authority；
2. 可选 `work/narrative-visual-contract.json`；
3. canonical `work/visual-spec.json`；
4. 已裁定职责的 Reference Contract；
5. 当前业务 Skill 的合法 domain delta。

不得从 Prompt 反向创造上游事实。

## 不变量

1. **Visual Spec first**：先通过 `.agents/skills/workspace-governance/config/visual-contracts/visual-spec-schema.json`。
2. **Relationship before decoration**：人物/物体关系、动作、空间、构图早于风格形容词。
3. **Reference role isolation**：身份、动作/镜头、环境、渲染、真实 Logo/UI 等职责必须可追溯，不做“综合参考”。
4. **Preserve / Change explicit**：编辑任务明确保护项、变化项、必要联动与禁止新增。
5. **No quality incantation**：`masterpiece / 8K / ultra detailed / cinematic / premium` 不承担结构、材质、清晰度或身份机制。
6. **Parameters outside semantic prompt**：seed、steps、CFG、路径、Hash、resolution/API 字段不混入画面语义；除非用户明确要一份包含参数的外部执行配置。
7. **No capability invention**：不知道当前 Provider/Workflow 能力时不发明私有语法、参数或容量。
8. **Prompt binding**：进入正式执行链的 Prompt 必须绑定 `work/visual-spec.json` 的 SHA-256，生成 `work/prompt-binding.json`。
9. **Compilation loss returns**：Visual Spec 正确而 Prompt 丢失关键关系时修 Prompt；若 Visual Spec 本身未闭合则回 Visual 层。
10. **Provider delta only**：业务 Skill 的 Provider adapter 只能补 domain projection，不复制另一套通用 Provider 规则。

## Provider Dialect Authority

通用图片 Prompt 方言以 `wxian-image-production/references/prompt-packs/` 为共享来源：

- GPT Image family → `gpt-image-2.md`
- Gemini / Nano Banana → `gemini-image.md`
- ComfyUI / Diffusion → `comfyui-diffusion.md`
- 未指定 Provider → `generic-natural-language.md`

其他业务 Skill 只维护自己的 domain delta，并引用上述共享方言。

Seedance 等视频模型使用其专用视频 Prompt Pack，但仍服从本文件的上游、绑定和不新增事实约束。
