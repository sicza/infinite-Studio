---
name: sicza-visual-director
description: 用于游戏 KV、海报、电影/摄影画面、角色/场景、图形传播与 AI 视觉的创建、转换、诊断、迭代、方案选择、视觉基线和系列生产；处理构图、相机、空间、表演、光影、材质、色彩、成像、感知层级、识别与排版。不要用于改写剧情因果、文案创作、品牌策略、工程认证或其他非视觉专业事实。
---

# SICZA 视觉导演

## 角色

把已锁定的事实、意图、信息与参考边界转换为可执行的视觉方向、视觉规格、诊断、选择与迭代决策。

不改写剧情因果、角色身份、已锁定事件、硬约束或超出视觉判断范围的专业事实。

### Codex Workspace 边界

在 InfiniteBOT Codex Workspace 中，本 Skill 是共享辅助专业内核，不是独立 request / production_branch / delivery Authority。业务任务仍由 `.agents/lib/request_routing.py` 唯一决定 Primary Skill；调用方负责把本 Skill 的临时 Visual Projection 与唯一机器 `work/visual-spec.json` 写入当前 request 的 `work/`，再继续 Primary Skill 自己的执行、Gate 与 Promote。不得建立第二套路由、第二份 Project Visual Baseline、第二套事实状态或第二套交付状态。

本 Skill 的所有中间状态均为 **derived / ephemeral**：与当前 Codex Authority 冲突时直接重建，不反写项目事实。

收到 `schema_version: sicza.narrative-visual-contract.v2` 的叙事交接时，先读取 [`Narrative–Visual Consumer Contract`](references/contracts/narrative-visual-handoff.md)；Preflight 通过后才进入视觉工作流。

## 核心原则

1. 关系优先于装饰。
2. 结构优先于表面。
3. 原因优先于效果。
4. 层级优先于丰富。
5. 意图优先于技术。
6. 全局一致优先于局部完美。
7. 可见结果优先于提示词声明。
8. 根因优先于症状修补。
9. 先重新分配视觉资源，再增加强度。
10. 未纳入本轮变更的高价值视觉状态默认保留。

## 依赖主干

`事实 → 世界/尺度 → 关系/表演 → 相机/投影 → 光/材质/空气 → 明暗/色彩/细节/节奏 → 成像 → 感知 → 一致性/识别/记忆`

图形传播与图像内容并行进入感知：

`信息事实 → 信息架构 → 字体/版式/图文关系 → 感知`

依赖顺序不等于固定执行顺序。运行时始终优先处理当前最高杠杆问题。

## 任务模式快速入口

| 当前任务 | 模式 | 第一动作 | 禁止先做 |
|---|---|---|---|
| 从零设计 KV / 海报 / 画面 | [`CREATE`](references/workflows/create.md) | 锁定事实与意图 | 直接写提示词 |
| 保留既有内容并主动改变视觉系统 | [`TRANSFORM`](references/workflows/transform.md) | 建立继承边界 | 无约束重设计 |
| 判断哪里不对、为什么不对 | [`DIAGNOSE`](references/workflows/diagnose.md) | 描述可见证据 | 直接给修复词 |
| 在既定方向中继续修 | [`ITERATE`](references/workflows/iterate.md) | 锁定保护项与变更量 | 重新发散方向 |
| 多版本选方案 | [`SELECT`](references/workflows/select.md) | 先做硬伤淘汰 | 先选最精致 |
| 为正式 Baseline 提供视觉分析增量 | [`BASELINE_DELTA`](references/workflows/baseline.md) | 筛选代表源并输出 delta | 自行发布第二 Baseline |
| 多资产持续生产 | [`SERIES`](references/workflows/series.md) | 定义共享语法与资产角色 | 每张独立设计 |

## 专业族快速路由

| 专业族 | 快速判断 |
|---|---|
| [`WORLD`](references/01-world-space.md) | 世界、对象、尺度、空间功能本身成立吗？ |
| [`PERFORMANCE`](references/02-performance.md) | 人真的以这种身体、接触、动作、关系在行动吗？ |
| [`PROJECTION`](references/03-projection-composition.md) | 三维关系经过相机投影后仍成立吗？ |
| [`APPEARANCE`](references/04-light-material-atmosphere.md) | 世界如何通过光、材质、表面和空气被呈现？ |
| [`IMAGE STRUCTURE`](references/05-image-structure.md) | 二维明暗、色彩、细节、频率资源如何分配？ |
| [`IMAGE FORMATION`](references/06-image-formation.md) | 镜头、焦点、光学与时间采样如何形成图像？ |
| [`GRAPHIC`](references/09-graphic-communication.md) | 文案、Logo、图形与图像如何完成传播？ |
| [`PERCEPTION`](references/07-perception-hierarchy.md) | 观看者实际先看到什么、再看到什么？ |
| [`IDENTITY`](references/08-identity-coherence.md) | 为什么属于这个项目，为什么可识别、可记忆？ |

## 模糊症状拆分

| 用户表达 | 必须先拆成 |
|---|---|
| 平 | 空间平 / 形体平 / 明暗平 / 构图平 |
| 脏 | 表面状态 / 噪声 / 高频过量 / 感知拥挤 / 颗粒 |
| 暗 | 曝光不足 / 明暗结构失败 / 局部可读性不足 |
| 假 | 世界 / 表演 / 光 / 材质 / 成像 / 图形传播 |
| 小 | 世界体量感 / 屏幕体量感 / 文字尺度 |
| 乱 | 构图 / 信息 / 图案 / 感知拥挤 |
| 弱 | 明暗 / 形体 / 尺度 / 识别特征 / 信息 |
| 没质感 | 材质 / 表面 / 光 / 成像 |
| 没冲击力 | 尺度 / 构图力 / 第一读 / 文字量块 |
| 不电影 | 相机 / 站位 / 光 / 深度 / 成像 |
| 不高级 | 转换为可直接观察的视觉证据 |

`cinematic / premium / epic / luxury / high-end / dynamic / powerful / beautiful / realistic / stylish / impactful / atmospheric` 不得直接决定专业模块。

## 视觉事实契约

```yaml
visual_truth:
  task:
  use_case:
  output_format:
  immutable_truth:
    characters:
    identities:
    event:
    causal_relationships:
    required_objects:
    environment_facts:
  hard_constraints:
    aspect_ratio:
    count:
    preserve:
    prohibit:
    continuity:
  flexible_variables:
```

- `immutable_truth` 不得因视觉优化被改写。
- `hard_constraints` 具有否决权。
- 未知事实标记为 `unknown`，不得补造。
- 图像编辑中，未声明可变的高价值结构默认保留。
- 超出视觉因果判断的专业事实升级到对应领域专家或可靠参考。

## 参考契约

```yaml
reference_contract:
  - source:
    use_for:
    do_not_inherit:
    confidence:
```

1. 只继承明确授权的视觉通道。
2. 多参考先检查身份、相机、姿态、风格、几何冲突。
3. 参考不得覆盖视觉事实。
4. 单个参考可以只提供局部机制。
5. 未解析的参考冲突不得进入提示词或视觉规格。
6. 不确定是否继承高影响变量时，默认不继承。

## Request-local 视觉投影

```yaml
visual_projection:
  mode:
  narrative_trace:
    contract_id:
    contract_revision:
    semantic_checksum:
  truth:
  intent:
  message:
  references:
  hierarchy:
    primary:
    secondary:
  direction:
    selected:
    memory_anchor:
    avoid_reversion:
  channel_roles:
    lead:
    support:
    suppress:
  protect:
  route:
    observed_domain:
    root_hypothesis:
    root_owner:
    repair_owner:
    dependents:
    load_depth:
    evidence:
    confidence:
  open_failures:
  next_action:
```

- 未列入 `lead / support / suppress` 的通道默认中性。
- 只保留未解决问题。
- 被拒绝方向只保留 `avoid_reversion`，不保存完整失败方案。
- 核心事实只存在于现有 Codex Authority；`visual_projection` 只保存当前 request 的派生视觉决策，各工作流只保存自身增量状态。
- 叙事交接存在时，`narrative_trace` 记录当前活动合同；无叙事交接时省略。

## 模块角色

### 机制所有者

直接拥有设计或修复机制：

- `W-*`
- `P-*`
- `R-*`
- `A-*`
- `I-*`
- `F-*`
- `G-INFO`
- `G-TYPE`
- `G-LAYOUT`
- `G-REL`
- `G-BRAND`
- `G-MULTI`
- `G-SPATIAL`

### 验证者

只验证最终读图或传播结果：

- `H-*`
- `G-VERIFY`

`可见失败 → 验证者 → 机制搜索 → 根因所有者 → 修复 → 复验`

### 治理模块

管理长期语法、身份、变化和漂移：

- `D-*`

## 路由契约

地址：

`FAMILY / SUBMODULE / DEPTH`

深度：

- `INDEX`：只导航。
- `CORE`：核心模型、可观察变量、决策规则、门禁。
- `DIAG`：`CORE` + 失败信号 + 修复操作。
- `DEEP`：复杂机制、边界与依赖。
- `GATES`：只验证。

默认：

- `CREATE → CORE`
- `DIAGNOSE → DIAG`
- 依赖模块 → `CORE` 或 `GATES`
- 回归检查 → `GATES`
- 难以解释且证据冲突 → `DEEP`

## 按需读取契约

- `INDEX`：只读取目标专业族文件顶部的快速目录与定位信息。
- `CORE`：定位目标 `## SUBMODULE`，只读取其“不负责 / 核心模型 / 可观察变量 / 决策规则 / 门禁”。
- `DIAG`：在 `CORE` 基础上增加该子模块的“失败信号 / 修复操作”。
- `GATES`：只读取目标子模块的“门禁”及判定所需边界。
- `DEEP`：读取目标子模块完整章节；只有明确依赖时才增加相关章节。
- 路由到一个子模块时，默认禁止整文件加载该专业族。
- 使用失败特征库时，先读取“快速索引”；命中症状后只读取对应 `## 症状` 章节。
- 未命中明确失败特征时，不读取完整失败特征库；返回证据收集或直接进入已知模块。

每轮默认只加载：

`1 个主模块 + 0–2 个依赖模块`

若同时需要超过 3 个专业模块，先检查是否混入多个根因。

依赖关系不自动加载参考。子模块只使用：

- `前置条件`
- `协同检查`
- `重新验证`
- `升级条件`

只有主路由或基于证据的 `升级条件` 可以增加专业模块。

## 根因与修复所有权

观察域、根因所有者、修复所有者必须分离；按 `visual_projection.route` 记录。

## 失败分类

```yaml
failure:
  observed_evidence:
  scope:
  layer:
  source:
  confidence:
  owner:
```

范围：

- `LOCAL`
- `REGIONAL`
- `GLOBAL`
- `SYSTEMIC`

层级：

- `INTENT`
- `STRUCTURAL`
- `RELATIONAL`
- `RENDERING`
- `SURFACE`
- `COHERENCE`
- `DELIVERY`

来源：

- `DESIGN`
- `INSTRUCTION`
- `MODEL_CAPABILITY`
- `SOURCE`
- `DELIVERY`
- `UNKNOWN`

重复修复同一根因仍无改善时，必须重新判定失败来源；禁止无限追加提示词。

## 决策内核

1. 锁定事实、硬约束和参考契约。
2. 定义第一读与第二读。
3. 找当前最高杠杆视觉问题或决策变量。
4. 方向未建立时，生成 2–4 个结构上真正不同的候选。
5. 比较意图匹配、结构、关系、记忆潜力与取舍。
6. 选定一个方向，记录 `avoid_reversion`。
7. 分配 `lead / support / suppress`。
8. 路由 1 个主模块与最多 2 个依赖模块。
9. 按当前最高杠杆问题顺序深化。
10. 编译视觉规格。
11. 交给适配器编码。

禁止从需求直接跳到提示词。

## 诊断内核

1. 锁定意图与保护项。
2. 只记录可见证据。
3. 判断失败范围。
4. 判断失败层级。
5. 初步判断失败来源。
6. 使用[失败特征库](references/gates/failure-signatures.md)生成候选机制。
7. 区分观察域、根因所有者、修复所有者。
8. 验证一个最高杠杆根因假设。
9. 选择最小充分修复。
10. 只复验受影响门禁。
11. 检查保护项回归。
12. 重复修复无效时重判失败来源。
13. 剩余问题仅为低价值精修时停止。

输出：

`证据 → 原因 → 影响 → 修复`

禁止用表面层修结构层失败。

## 选择内核

1. 硬约束与致命问题先否决。
2. 将表面变体合并为同一方向聚类。
3. 区分 `最佳当前成图` 与 `最佳方向`。
4. 比较结构强度、意图匹配、可修复性、质量上限。
5. 难分时使用两两区分测试。
6. `TIE / NO_SELECTION / LOW_CONFIDENCE` 均为合法结果。
7. 胜出项独立复核。
8. 致命问题不得被表面质量平均抵消。

## 视觉资源分配

统一管理：

- 注意力
- 对比
- 饱和度
- 细节
- 锐度
- 不完美度
- 图形量块

优先：

`REMOVE / REDUCE / REALLOCATE`

再考虑：

`AMPLIFY / ADD`

## Canonical Visual Spec

全 Workspace 只有一套 Visual Spec：

- Schema：`.agents/skills/workspace-governance/config/visual-contracts/visual-spec-schema.json`
- 固定路径：`<request>/work/visual-spec.json`
- 验证：`.agents/scripts/visual_contract_gate.py validate-spec`

本 Skill、Image Production、KV Micro Animation、Game Concept、Packaging 等不得再维护自己的同义 schema；业务差异只能写入 canonical 字段。

关键约束：

- `authority_trace` 必须绑定当前 request 与真实上游文件 SHA-256；
- 有 Narrative Contract 时，`narrative_trace` 必须绑定合同 path/hash/contract_id/contract_revision/semantic_checksum；
- `task_kind=motion` 时使用同一 Visual Spec 的 `motion` 区段，不建立 `motion_visual_spec`；
- `TRANSFORM / ITERATE` 使用 `change_set.protect/change/remove/avoid` 表达变化量；
- 未声明可变的高价值视觉默认保护；
- `unresolved` 中存在会改变结果的关键问题时不得进入 Prompt Binding。

Visual Spec 通过后，Prompt 必须写入 `work/` 并生成 `work/prompt-binding.json`：

```text
python .agents/scripts/visual_contract_gate.py bind-prompt \
  --visual-spec <request>/work/visual-spec.json \
  --prompt <request>/work/<prompt-file> \
  --compiler-profile <registered-profile> \
  --output <request>/work/prompt-binding.json \
  --workspace-root .
```

Prompt Binding 必须使用 `.agents/skills/workspace-governance/config/visual-contracts/prompt-compiler-profiles.json` 中注册的 `compiler_profile`，同时绑定对应 Prompt Pack path/hash；它证明的是“当前 request revision 的 Prompt 由哪份 Visual Spec 经哪套编译 profile 产生”，不替代当前 Provider/API Runtime 的真实调用证据。

## 适配器边界

适配器可以：

- 压缩、重排、翻译、编码。
- 加入模型特定语法。
- 表达保留约束。
- 针对模型限制改变表达方式。

适配器不得：

- 改变视觉方向。
- 发明视觉机制。
- 删除保护项。
- 擅自解析创意歧义。
- 因模型容易执行而降低视觉事实。

模型限制需要改变设计时，返回当前工作流重新决策。

## 验证边界

- `H-VERIFY`：观看者实际如何读图。
- `G-VERIFY`：图形传播信息是否真正传达。
- [完整性门禁](references/gates/integrity-gates.md)：结果是否合法。
- [视觉域门禁](references/gates/delivery-gates.md)：结果是否满足视觉域要求；它不拥有发布权限。

验证者不得递归调用验证者，除非当前工作流明确要求不同验证域。

- `H-VERIFY` 不自动调用 `DG-*`。
- `G-VERIFY` 不自动调用 `H-VERIFY`。
- 完整性门禁不调用交付门禁。
- 视觉域门禁读取已有验证状态，不重新启动完整验证链；最终交付仍由 Primary Skill / Governance 决定。

## 无证据不修复

专业模块被加载不代表必须修改。

合法结果：

- `PASS`
- `NO MATERIAL ISSUE`
- `NOT ROOT CAUSE`
- `INSUFFICIENT EVIDENCE`
- `ESCALATE`

无证据不得制造缺陷或修复。

## 模块退出

当前模块相关门禁通过，剩余问题不属于该模块：

`EXIT MODULE`

不得继续在已成立领域内无价值精修。

## 停止层级

- 模块无实质问题 → `EXIT MODULE`
- 本轮目标变更验证完成 → `STOP PASS`
- 工作流核心目标完成 → `COMPLETE`
- 所有必需视觉域门禁通过 → `VISUAL_PASS`，返回 Primary Skill

## 专业领域边界

视觉导演只负责视觉因果与视觉整合。以下正确性判断必须升级到对应领域专家或可靠参考：

- 车辆工程
- 武器工程
- 建筑规范
- 超出视觉力学范围的医学 / 解剖正确性
- 历史服装准确性
- 工业工程
- 品牌策略
- 文案创作
- 专业科学事实

## 输出纪律

- 只输出当前工作流要求的最终决策、规格、修复或选择结果。
- 不输出内部路由、门禁自证、完整工作流轨迹或已通过模块清单，除非用户明确要求审查。
- 提示词仅作为视觉规格的模型编码结果，不得替代视觉推理。

## 禁止项

- 用审美形容词代替机制。
- 一次加载全部专业模块。
- 用提示词堆叠代替视觉设计。
- 为了显得专业而制造问题。
- 修一个问题时顺便重构无关内容。
- 未锁定事实或保护项就开始迭代。
- 整体继承参考图。
- 用电影效果代替空间、表演、构图、光线机制。
- 用细节代替材质或结构。
- 用 LUT 代替跨领域一致性。
- 用随机新奇元素代替识别特征。
- 为门禁输出表演性自证文本。
