# DIAGNOSE

## 入口

定位可见问题、根因和最小充分修复。

只保存：

```yaml
workflow_state:
  diagnose:
    scope:
    layer:
    source:
```

## 1. 锁定意图与保护项

读取 `visual_projection`。

## 2. 证据优先

只记录可直接观察的关系。

合格：

- 主体右肩与背景墙明度和边缘密度近似
- 驾驶员手腕方向与方向盘接触轴冲突
- 后轮轴线与可见悬挂支撑不对齐

禁止把以下词直接当证据：

- 不电影
- 姿态怪
- 车不好
- 不高级

## 3. 判断范围

- `LOCAL`
- `REGIONAL`
- `GLOBAL`
- `SYSTEMIC`

## 4. 判断失败层级

- `INTENT`
- `STRUCTURAL`
- `RELATIONAL`
- `RENDERING`
- `SURFACE`
- `COHERENCE`
- `DELIVERY`

## 5. 判断失败来源

- `DESIGN`
- `INSTRUCTION`
- `MODEL_CAPABILITY`
- `SOURCE`
- `DELIVERY`
- `UNKNOWN`

证据不足时保持 `UNKNOWN`。

## 6. 匹配失败特征

读取 `../gates/failure-signatures.md` 顶部“快速索引”。

命中症状后，只读取对应 `## 症状` 章节；未命中时不展开完整失败特征库。

失败特征只生成候选机制，不直接决定根因。

## 7. 建立根因假设

默认保留 1 个最高杠杆根因。

证据无法区分时最多保留 2 个竞争假设。

```yaml
root_hypothesis:
  claim:
  owner:
  evidence:
  predicted_effect:
  confidence:
```

## 8. 反事实验证

根因不确定时问：

`如果只修这个变量，主要症状应该明显改善吗？`

按需使用：

- 去除模糊
- 去除色彩
- 去除纹理
- 轮廓测试
- 缩略图测试
- 去除特效
- 去除标题
- 中性光照

## 9. 路由专业模块

主模块 → `DIAG`

依赖模块 → `CORE / GATES`

默认：

`1 个主模块 + 0–2 个依赖模块`

## 10. 专业模块结果

合法：

- `CONFIRMED`
- `PASS`
- `NOT ROOT CAUSE`
- `INSUFFICIENT EVIDENCE`
- `ESCALATE`

`NOT ROOT CAUSE` → `EXIT MODULE`

## 11. 修复

选择最小充分修复。

优先考虑：

`REMOVE → REDUCE → REALLOCATE → REPOSITION → RESTRUCTURE → ADD`

```yaml
repair:
  change:
  preserve:
  do_not_change:
  expected_result:
  blast_radius:
```

## 12. 复验

只复验：

- 失败门禁
- 受影响的下游门禁
- 保护项

`目标 PASS + 保护项 FAIL = FAIL`

## 13. 重判失败来源

同一根因已经修正，但多次执行仍重复失败时，重新判断：

- `INSTRUCTION`
- `MODEL_CAPABILITY`
- `SOURCE`

必要时改变执行策略：

- 局部区域编辑
- 蒙版
- 参考锁定
- 分阶段生成
- 更换模型
- 合成

禁止无限追加提示词。

## 14. 优先级

### P0 致命问题

- 事实错误
- 身份错误
- 不可能结构
- 严重动作 / 接触错误
- 致命读图失败
- 必需信息失败
- 重大一致性破坏

### P1 高价值问题

- 层级
- 尺度
- 材质可信度
- 表演
- 深度
- 差异性

### P2 可选精修

只影响低价值表面或微观一致性，不阻止交付。

## 15. 输出

简单任务：

```text
核心问题：
证据：
根因：
怎么改：
必须保留：
```

多问题：

`P0 / P1 / P2 + 证据 → 原因 → 修复`

不为格式凑满等级。

## 16. 完成

满足：

- 无未解决 P0
- 核心意图可读
- 保护项完整
- 无高杠杆未解决根因
- 剩余问题仅为 P2
- 下一步修复的回归风险不低于预期收益

→ `COMPLETE`

## 禁止

- 审美词代替证据
- 症状直接变提示词
- 下游效果修上游结构
- 所有问题都归因提示词或模型
- 专业模块被加载后强行找问题
- 同时列大量同优先级问题
