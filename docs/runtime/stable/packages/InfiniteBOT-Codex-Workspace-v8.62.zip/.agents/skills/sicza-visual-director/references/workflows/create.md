# CREATE

## 入口

从零建立视觉方向。

读取：

- `visual_projection`
- 视觉事实契约
- 参考契约
- 项目基线（存在时）

只保存：

```yaml
workflow_state:
  create:
    hypotheses:
    selected_direction:
```

## 1. 锁定事实与传播信息

锁定：

- 不可变事实
- 硬约束
- 参考权限
- 必需信息
- 必需图形传播内容

存在文字、Logo、日期、CTA 时，提前运行 `G-INFO`。

## 2. 定义视觉意图

```yaml
intent:
  primary_read:
  secondary_read:
  intended_relationship:
  desired_viewer_position:
  desired_energy_state:
  memory_priority:
```

审美形容词必须转换为可观察关系。

## 3. 定义核心视觉关系

明确：

`主体与什么形成什么关系`

可包括：

- 角色与世界
- 角色与角色
- 主体与威胁
- 身体与力量
- 图像与标题
- 孤立与群体
- 正常秩序与异常

去掉色彩、材质、特效后，核心关系仍应成立。

## 4. 找最高杠杆决策

不按固定工种顺序。

优先决定最能改变整体方向的变量，例如：

- `W-SCALE`
- `P-BLOCK`
- `R-CAM`
- `R-COMP`
- `G-REL`
- `D-SIGN`
- `A-LIGHT`

## 5. 形成方向候选

方向未明确时生成 2–4 个结构上真正不同的候选。

```yaml
direction:
  core_relationship:
  dominant_mechanism:
  camera_spatial_strategy:
  composition_strategy:
  hierarchy_strategy:
  graphic_strategy:
  memory_anchor:
  tradeoff:
```

禁止用颜色、天气、粒子、耀斑、轻微服装变化伪造方向差异。

### 方向差异门禁

删除色彩、材质、特效后，各候选仍应明显不同。

## 6. 选择方向

比较：

- 事实匹配
- 意图匹配
- 核心视觉关系强度
- 结构清晰度
- 记忆潜力
- 图形传播兼容性
- 执行风险
- 取舍

选定后停止平行深化其他方向。

更新：

- `direction.selected`
- `direction.memory_anchor`
- `direction.avoid_reversion`

## 7. 锁定保护项

只记录已成立且后续不得被破坏的高价值关系：

- 身份
- 核心关系
- 相机
- 尺度
- 识别轮廓
- 负空间
- 图形传播区域

## 8. 分配视觉通道角色

显式记录：

- `lead`
- `support`
- `suppress`

其余默认中性。

## 9. 专业模块深化

每轮默认：

`1 个主模块 + 0–2 个依赖模块`

`CREATE` 默认使用 `CORE` 深度。

先解决相关结构，再按需要进入：

- `APPEARANCE`
- `IMAGE STRUCTURE`
- `IMAGE FORMATION`

存在图形传播时：

`G-INFO → G-TYPE / G-LAYOUT / G-REL → 必要 G-*`

旗舰视觉需要强化项目差异时：

`D-CATEGORY → D-SIGN → D-MEM`

## 10. 分配视觉资源

优先：

`REMOVE / REDUCE / REALLOCATE`

再考虑：

`AMPLIFY / ADD`

控制：

- 注意力
- 对比
- 饱和度
- 细节
- 锐度
- 不完美度
- 图形量块

## 11. 验证

按实际变化激活：

- `H-VERIFY`
- `G-VERIFY`

验证失败时回溯机制所有者，不重新发散方向。

## 12. Canonical Visual Spec

写入当前 request 的唯一 `work/visual-spec.json`，`mode=CREATE`。只填写高杠杆控制项；字段以 `.agents/skills/workspace-governance/config/visual-contracts/visual-spec-schema.json` 为准，不在本工作流定义第二套 schema。

删除：

- 通用形容词
- 重复复述
- 不影响结果的默认项
- 装饰性冗余文本

## 13. 适配器

适配器只编码视觉规格，不新增方向或视觉机制。

## 14. 完成

满足：

- 事实完整
- 方向已选定
- 核心视觉关系清楚
- 无未解决结构阻塞
- 层级稳定
- 保护项已建立
- 必需传播信息成立
- 视觉规格足够执行

→ `COMPLETE`

## 禁止

- 从需求直接跳提示词
- 用颜色或特效制造假方向
- 所有通道同时主导
- 先做表面再补结构
- “电影感”自动等于广角、景深、颗粒、耀斑
- 文案最后塞入剩余空间
- 一次加载全部专业模块
- 方向已选定后继续无限发散
