# ITERATE

## 入口

在既定方向中进行局部修复和受控优化。

只保存：

```yaml
workflow_state:
  iterate:
    locked:
    protected:
    open:
    delta:
    success_condition:
```

## 1. 读取已接受状态

读取：

- 已选方向
- 核心意图
- 层级
- 记忆锚点
- 保护项
- 未解决问题
- 下一动作

不重新解析完整项目。

## 2. 定义变更边界

```yaml
iteration_boundary:
  locked:
  protected:
  open:
```

- `LOCKED`：不得变化。
- `PROTECTED`：允许必要微调，但不能损害核心作用。
- `OPEN`：本轮允许主动修改。

## 3. 定义变更量

```yaml
iteration_delta:
  current_failure:
  desired_change:
  success_condition:
  non_goals:
```

## 4. 选择模式

### 严格补丁

只修指定范围；只扩展到真实修复所必需的邻近依赖。

### 受控优化

在既定方向内修一个高价值关系。

### 回归修复

优先恢复上一已接受状态中被破坏的内容。

### 方向重开

满足任一条件时升级 `CREATE`：

- 当前方向无法满足核心意图
- P0 无法在当前方向内修复
- 用户明确要求重做
- 影响范围已经接近重设计

## 5. 确认根因

根因已确认且证据未变化，可使用 `GATES` 快速复核；否则进入 `DIAGNOSE`。

## 6. 评估影响范围

- `B0 MICRO`
- `B1 LOCAL`
- `B2 REGIONAL`
- `B3 GLOBAL`
- `B4 DIRECTIONAL`

默认优先 `B0–B2`。

`B4` 通常升级 `CREATE`。

## 7. 最小充分变更

优先考虑：

`REMOVE → REDUCE → REALLOCATE → REPOSITION → RESTRUCTURE → ADD → REGENERATE`

## 8. Canonical Visual Spec

继续更新当前 request 的唯一 `work/visual-spec.json`，`mode=ITERATE`。本轮 delta 只写 `change_set.protect / change / remove / avoid` 与受影响控制字段；未声明的高价值视觉默认保留。Schema 以 `.agents/skills/workspace-governance/config/visual-contracts/visual-spec-schema.json` 为准。

## 9. 执行边界

```yaml
execution_boundary:
  must_preserve:
  may_adjust:
  must_not_redesign:
```

“只改手”可以联动修正手腕、前臂、肘和肩，但不得扩张到无关相机、光照或世界结构。

## 10. 每轮只处理一个因果簇

禁止一轮同时修互不相关的：

- 手部
- 光照
- 色彩
- 背景
- 颗粒

顺序修复，逐轮验证。

## 11. 验证目标

结果：

- `PASS`
- `PARTIAL`
- `FAIL`
- `UNVERIFIABLE`

先确认目标变更，再检查回归。

## 12. 回归检查

只检查 `locked + protected`。

严重度：

- `R0`：无回归
- `R1`：轻微回归
- `R2`：实质回归
- `R3`：致命回归

`R2 / R3` 默认拒绝当前结果。

结果：

- 接受
- 带轻微问题接受
- 拒绝
- 回滚

只有已接受版本可以成为下一轮基线。

## 13. 漂移检查

连续多轮或出现“越来越不像”时运行：

`D-DRIFT / GATES`

不保存完整历史，只保留已接受状态与 `avoid_reversion`。

## 14. 重判失败来源

重复失败时重判：

- `INSTRUCTION`
- `MODEL_CAPABILITY`
- `SOURCE`

模型限制不得改写视觉事实；改变执行策略。

## 15. 变更预算

- `LOW`
- `MEDIUM`
- `HIGH`

`HIGH` 时检查是否应升级 `CREATE`。

## 16. 停止本轮

目标变更 `PASS` 且无实质回归：

→ `STOP PASS`

## 17. 完成

满足：

- 目标变更已经解决
- 无实质回归
- 核心意图完整
- 保护项完整
- 无 P0
- 剩余问题仅为 P2
- 下一步变更的漂移风险不低于预期收益

→ `COMPLETE`

## 输出

执行前：

```text
本轮只改：
必须保留：
不要动：
成功标准：
```

执行后：

```text
本轮已修：
保留正常：
仍需处理：
```

## 禁止

- 小修变整体优化
- 每轮重开方向
- 完整重写提示词代替局部补丁
- 被拒绝版本继续作为基线
- 连续失败仍只增加提示词
- 用模型限制改写事实
- P2 自动触发新一轮
