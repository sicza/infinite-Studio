# Narrative–Visual Consumer Contract

## 唯一输入合同

只消费：

`<request>/work/narrative-visual-contract.json`

Schema：`.agents/skills/workspace-governance/config/visual-contracts/narrative-visual-contract-schema.json`。

进入视觉工作流前必须执行：

```text
python .agents/scripts/visual_contract_gate.py validate-narrative --file <request>/work/narrative-visual-contract.json --workspace-root .
```

仅 `result=READY` 可继续。

## Preflight

检查：

1. Authority path/hash 未漂移；
2. `semantic_checksum` 与机器重算一致；
3. selected moment/window 足以确定视觉时相；
4. `must_show / may_show / must_not_imply` 不冲突；
5. 关键叙事关系存在可见证明义务；
6. 当前输出格式能在不改变上游 Authority 的前提下表达要求。

失败只允许返回：`NEED_UPSTREAM / NEED_DOMAIN / PRESENTATION_UNSATISFIABLE`，并由当前 Primary Skill 记录为 `work/visual-return.json`；不得创建第二 request。

## 映射到 Visual Spec

Narrative Contract 不复制成第二份 Visual State。它只绑定到 canonical `work/visual-spec.json`：

```text
protected_narrative_truth + must_show + must_not_imply
→ visual_spec.truth_protection

selected_moment_or_windows + causal_evidence
→ visual_spec.intent / performance / world_space

audience_information
→ visual_spec.intent / channel_roles / projection

continuity_obligations
→ visual_spec.truth_protection / motion / change_set
```

同时写入：

`visual_spec.narrative_trace = {path, sha256, contract_id, revision, semantic_checksum}`。

## Visual 可派生范围

Visual Director 可以决定：

- 世界与尺度的视觉实现；
- Blocking、身体、接触、表情、视线；
- 相机、投影、构图、遮挡；
- 光、材质、表面、空气；
- 明暗、色彩、细节频率；
- 焦点、景深、时间/运动采样；
- Graphic Communication；
- 项目视觉身份与感知层级。

不得修改 Narrative Contract 或上游 Authority。

## Revision

同一合同更高 revision 到达后：重新验证合同，只重算受影响的 Visual Spec 字段；核心时刻/关系/结果变化导致方向失效时重新 CREATE。旧合同 hash 不得继续绑定新 Prompt。

## 编译损失

Prompt 不能完整表达 Visual Spec 时属于 `COMPILATION_LOSS`，写 `work/visual-return.json` 并回 Prompt Compilation；只有上游语义本身不可满足时才返回 `NEED_UPSTREAM / PRESENTATION_UNSATISFIABLE`。
