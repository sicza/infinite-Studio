# BASELINE_DELTA

## 目标

为 `$wxian-visual-baselines` 提供视觉分析增量，不建立、发布或更新第二份 Baseline。

正式 Baseline Authority、Schema、revision、publication receipt 与 publish/complete gate 全部属于 `wxian-visual-baselines`。

## 输入

- 当前项目素材与正式来源清单；
- source authority / quality / representativeness / contamination boundary；
- `$wxian-visual-baselines` 当前要求的分析范围。

## 分析

按需使用 Visual Director 专业模块提取：

- 跨源稳定视觉关系；
- 可生成语法候选；
- 身份/记忆锚点候选；
- 允许变化；
- 禁止漂移候选；
- 例外与未知领域；
- 证据强度与反例。

不要把重复对象、单张图特性、偶然特效或色板直接升级成项目规则。

## 输出

只返回 `baseline_delta`：

```yaml
baseline_delta:
  scope:
  evidence_sources:
  invariant_candidates:
  grammar_candidates:
  identity_candidates:
  allowed_variation_candidates:
  forbidden_drift_candidates:
  exceptions:
  undefined_domains:
  confidence:
```

该结构只供 `$wxian-visual-baselines` 消费。它不是 project Baseline，不进入 `project/baselines/`，不拥有 publish 状态。

## 验证

至少检查：

- 可生成性：规则能指导新作品，不要求复制旧图；
- 非克隆：同项目可有不同构图/镜头/关系；
- 可判别性：候选规则能区分项目身份；
- 反例：是否存在高权威来源直接否定该规则；
- 证据：每个强候选都能回到来源。

## 禁止

- 自行生成 `visual_baseline` 并发布；
- 修改正式 Baseline revision；
- 平均全部历史图；
- 单图过拟合；
- 把例外升级为不变量；
- 对未知领域补造规则。
