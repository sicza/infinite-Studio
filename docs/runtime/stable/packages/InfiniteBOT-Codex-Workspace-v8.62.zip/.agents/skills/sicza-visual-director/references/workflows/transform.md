# TRANSFORM

## 入口

在明确继承边界下改变已有视觉系统。

适用于：

- 2D → 3D
- 写实化 / 风格化
- 日景 → 夜景
- 完好 → 废弃
- 16:9 → 9:16 / 1:1 / 4:5
- 参考风格迁移
- 重渲染
- 平台适配

只保存：

```yaml
workflow_state:
  transform:
    inheritance:
    target_channels:
```

## 1. 分析源状态

只提取与当前任务相关的：

- 不可变事实
- 高价值视觉
- 结构关系
- 风格特征
- 图形传播元素
- 源缺陷
- 不确定项

区分：

`SOURCE FACT ≠ SOURCE DEFECT`

## 2. 建立继承矩阵

每个高影响通道只允许：

- `PRESERVE`
- `ADAPT`
- `REBUILD`
- `REMOVE`

```yaml
inheritance:
  identity:
  pose:
  camera:
  composition:
  environment_geometry:
  lighting:
  material:
  image_formation:
  graphic:
```

## 3. 定义目标变化通道

不能只写“3D / 写实 / 夜景 / 电影感”。

必须明确哪些视觉机制发生变化。

```yaml
transform_target:
  target_identity:
  target_style_profile:
  target_channels:
  forbidden_changes:
  target_use_case:
```

## 4. 判断裁切还是重构构图

画幅或平台变化时先判断：

### 裁切

仅当裁切后核心关系、人数、动作、尺度、记忆锚点仍完整。

### 重构构图

裁切会破坏核心关系时，受控重构屏幕空间关系。

优先保护：

- 事实
- 身份
- 核心关系
- 必需对象
- 必需传播信息

## 5. 扩图

扩图必须延续真实世界：

- 空间拓扑
- 透视
- 地面 / 建筑连续性
- 光照
- 材质
- 空气介质
- 世界状态

优先路由：

`W-TOPO / W-BRIDGE / R-CAM / A-CONT`

## 6. 身份锁定

角色相关转换按需锁定：

```yaml
identity_lock:
  face:
  head_shape:
  hairstyle:
  body_proportion:
  costume:
  signature:
  weapon:
```

只锁身份所需变量，不把无关姿态、光照、环境一起锁死。

## 7. 参考迁移

每张参考只提供明确授权的通道。

例如：

```yaml
reference_contract:
  source_image:
    use_for:
      - identity
      - composition
      - pose
  style_reference:
    use_for:
      - material
      - lighting
      - detail_philosophy
    do_not_inherit:
      - identity
      - camera
      - composition
      - environment
```

禁止整体继承风格参考。

## 8. 高频转换规则

### 2D → 3D

默认：

- 内容 → `PRESERVE`
- 身份 → `PRESERVE`
- 主构图 → `PRESERVE`
- 相机 → `PRESERVE`
- 姿态 → `PRESERVE`
- 几何 → 根据源证据重建
- 材质 → `REBUILD`
- 光照 → `REBUILD / ADAPT`
- 表面 → `REBUILD`
- 成像 → `REBUILD`

不得为了“3D 合理”擅自普通化原始设计意图。

### 日景 → 夜景

重新建立：

- 光源
- 实际灯具
- 阴影
- 曝光
- 色彩
- 可见性
- 材质响应
- 空气介质

禁止只压暗加蓝。

### 完好 → 废弃

优先：

`W-STATE + W-SYSTEM + A-SURFACE`

禁止只叠加锈迹和污渍。

### 多语言

保留信息层级，不保留原语言文字几何。

`G-MULTI + G-TYPE + G-LAYOUT`

## 9. 路由变化通道

只加载真正发生变化的专业模块。

例：

- 2D → 3D：`A-MAT / A-LIGHT / I-DETAIL`
- 16:9 → 9:16：`R-COMP / R-CAM / G-REL`（有文字时）
- 日景 → 夜景：`A-LIGHT / A-EXPOSURE / I-COLOR`

## 10. Canonical Visual Spec

写入当前 request 的唯一 `work/visual-spec.json`，`mode=TRANSFORM`。变化量统一写入 `change_set.protect / change / remove / avoid`，并只填写受影响的专业控制字段与 `success_condition`；Schema 以 `.agents/skills/workspace-governance/config/visual-contracts/visual-spec-schema.json` 为准。

## 11. 双重验证

### 源保真

先检查：

- 身份
- 人数
- 姿态 / 动作
- 相机
- 核心构图
- 必需对象
- 必需图形传播内容

### 目标转换成功

再检查目标通道是否真正改变。

| 源保真 | 目标转换 | 结果 |
|---|---|---|
| `PASS` | `PASS` | 接受 |
| `PASS` | `FAIL` | 目标转换失败 |
| `FAIL` | `PASS` | 保真失败 |
| `FAIL` | `FAIL` | 拒绝 |

目标转换成功不能补偿源保真失败。

## 12. 模式升级

以下情况升级 `CREATE`：

- 核心视觉关系改变
- 故事关系改变
- 主相机概念改变
- 世界概念重做
- 记忆锚点重做

只改一个局部问题时降级 `ITERATE`。

## 13. 完成

满足：

- 源保真 PASS
- 目标转换 PASS
- 硬约束 PASS
- 无 P0 回归
- 目标变化清楚
- 继续修改的源漂移风险不低于收益

→ `COMPLETE`

## 禁止

- 风格转换变整图重设计
- 整体继承参考
- 画幅变化机械裁切关键内容
- 质量升级变风格替换
- 日景转夜景只加蓝
- 废弃化只加污损纹理
- 2D → 3D 只加高光和纹理
- 目标风格漂亮就忽略源身份漂移
