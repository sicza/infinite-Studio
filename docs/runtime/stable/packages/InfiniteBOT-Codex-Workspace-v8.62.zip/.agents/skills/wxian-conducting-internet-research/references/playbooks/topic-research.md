# Playbook — 主题研究

用于方法、标准、技术实践、Prompt、工程模式、学术主题，或“怎样做 X 才算好？”这类问题。

搜索前先判断问题类型；最佳实践、当前技术行为、学术证据与规范性标准需要不同的证据路径。

## 1. 分类 Topic Question

### A. 最佳实践 / 方法研究
示例：
- 一个优秀的 workspace instruction file 应该具备什么？
- Agent capability guide 应该怎样组织？
- 哪些 Prompt Pattern 在真实实践中有效？

目标：提炼可迁移原则，而不是复制一个热门实现。

### B. 当前技术 / 产品实践
示例：
- 当前推荐的 Context Engineering 方法是什么？
- 这个 Framework 现在还支持 Feature X 吗？
- 最新版本改变了什么？

目标：确认现在真实成立的事实，并识别已经过时的历史建议。

### C. 学术 / 研究文献
示例：
- 最近论文对 Agent Memory 有什么结论？
- 哪种 Retrieval 方法表现最好，在什么假设下成立？

目标：综合原始研究，而不是串联多篇博客摘要。

### D. 概念 / 标准 / 规范性研究
示例：
- 相关官方规范明确要求什么？
- 某个 Protocol/Standard 术语如何定义？

目标：区分规范性要求与生态习惯。

## 2. 最佳实践研究路径

主题允许时，至少覆盖四层证据：

```text
Normative / official guidance
→ maintained implementation examples
→ practitioner usage
→ failure reports / critiques / edge cases
```

### 规范层（Normative Layer）
搜索：
- 官方规范；
- Maintainer Documentation；
- 原作者指导；
- Design Rationale。

明确区分“必须”与“推荐”。

### 实现层（Implementation Layer）
搜索：
- 持续维护的仓库；
- 真实项目文件；
- 活跃工具中的示例；
- Release Template / Reference Implementation。

检查真实实践是否与规范指导一致。

### 实践者层（Practitioner Layer）
搜索：
- 有经验 Maintainer 的分享；
- Issue Discussion；
- 真实 Workflow 复盘；
- 多个无关联项目反复出现的惯例。

热度只作为 Discovery Signal。多个独立上下文反复出现，比单纯 Stars/Likes 更有价值。

### 失败层（Failure Layer）
主动搜索：
- “doesn’t work”；
- 混淆/误用；
- Issue Reports；
- Migration Pain；
- Prompt/Skill Failure；
- 过长、被忽略或失效的 Instruction File。

失败案例通常能暴露隐藏约束，把模糊建议变成真正可执行的规则。

## 3. 提炼可迁移原则

对每条候选 Best Practice，回答：

1. 它是标准强制要求，还是仅仅常见？
2. 是否出现在多个独立实现中？
3. 是否存在解释“为什么有效”的机制？
4. 它具体防止什么失败？
5. 在什么上下文下会失去价值？
6. 对目标版本/工具而言现在仍然有效吗？

高质量输出应区分：

```text
REQUIRED
RECOMMENDED
COMMON PRACTICE
CONTEXT-DEPENDENT
ANTI-PATTERN
```

最终综合中保持这些类别独立。

## 4. 当前技术研究路径

加载 `freshness-and-current-state.md`。

按以下顺序搜索：

```text
current official docs
→ changelog/release notes
→ maintained source/examples/tests
→ current issues/discussions
→ recent practitioner evidence
→ older material only for historical context
```

对每项重要技术记录版本适用性。推荐旧模式前，显式搜索 Deprecation/Migration 相关术语。

## 5. 学术 / 文献研究路径

优先原始论文，而不是摘要。

对每篇重要论文/结果，至少记录：

- research question/hypothesis；
- method 与 experimental setting；
- dataset/benchmark；
- baseline comparison；
- main result；
- relevant ablations；
- 作者明确写出的 limitations；
- 对用户场景的 external validity；
- 后续 replication/contradiction/follow-up；
- implementation availability。

### 文献发现
使用：
- 原始论文数据库/搜索；
- Conference/Journal/arXiv 页面；
- Author/Project Page；
- Citation Trail；
- Benchmark/Project Repository；
- 后续引用或挑战该结果的论文。

### 文献质量检查
判断“最好”时同时看 Benchmark Context、Methodology、Limitations 与 Follow-up Evidence：

- 是否使用同一 Benchmark 和 Metric？
- Model/Data/Budget 是否可比？
- 差异是否具有统计意义？
- 结果是否被复现？
- Benchmark 是否污染或过窄？
- 技术是否能离开原实验条件继续有效？

明确区分：

```text
paper reports X
vs
this implies X will work for the user
```

第二种结论需要显式的 Transfer Reasoning。

## 6. 共识映射

对方法/技术主题，把结论整理成：

- **strong consensus** —— 规范性支持，或多个独立来源反复支持；
- **emerging practice** —— 有前景，但尚未广泛验证；
- **contested** —— 存在可信争议或高度依赖上下文；
- **obsolete/deprecated** —— 已被当前行为取代；
- **unknown** —— 证据不足。

## 7. 搜索诊断

### 只出现通用博客摘要
转向官方文档、原作者、持续维护仓库、Issue Discussion 和原始论文。

### 很多示例复制同一个 Template
追踪源头；降低独立样本数；寻找无关联实现。

### 建议互相冲突
检查版本、Runtime、Problem Context，以及一方是否属于 Normative、另一方是否只是 Experiential。

### 最新文章仍在重复旧建议
验证 Event/Effective Date 和当前版本。文章发布时间新，不等于内容当前有效。

## 8. 综合输出

高质量 Topic Research 应包含：

1. 权威来源真正要求什么；
2. 高质量真实实现稳定地做了什么；
3. 哪些实践存在分歧，以及为什么；
4. 已知 Failure Modes；
5. 哪些原则可迁移；
6. 哪些 Recommendation 是当前有效，哪些只是历史做法；
7. Confidence 与尚未解决的争议。

最终产出一个由最强证据支撑、可以复用的方法，而不是案例堆叠。
