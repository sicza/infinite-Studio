# Playbook — 实体研究

用于研究单个 IP、游戏、产品、公司、品牌、人物、项目、平台或组织。

先确认这个 Entity 到底是什么、哪些部分会影响决策，以及哪些是稳定身份、哪些依赖上下文。

## 1. 分析前先解决 Identity

建立身份边界：

```text
canonical name
aliases / localized names / former names
owner / parent / publisher / operator
product or franchise hierarchy
versions / services / regional variants
current vs discontinued forms
```

全球 Entity 中，如果官方名、本地化名、旧名、罗马化名称会实质影响召回率，就必须纳入搜索。

### 身份问题

- 用户提到的是 Franchise、单一产品、服务、地区版本，还是 Campaign？
- Ownership/Operator 是否发生过变化？
- 对当前任务来说，Remake/Remaster/Spin-off/Adaptation 是否可以视为同一分析层级？
- 用户关注的是当前 Entity 状态，还是完整历史 lineage？

先稳定身份边界，再进入深度分析。

## 2. 从决策反推 Facet

只研究会改变用户决策的 Facet。

常见 Facet：

- 起源/历史；
- 当前 Ownership/Operation；
- 核心 Portfolio/Works；
- 产品/功能架构；
- Identity/Brand DNA；
- 角色/产品/功能；
- Audience/User Needs；
- 市场/地区分布；
- Visual Identity；
- 生态/授权/合作；
- 技术/商业模式；
- 当前状态与近期变化；
- 约束/争议；
- 可比较 Entity。

如果研究目标是联动设计，优先研究稳定身份、反复出现的核心资产、视觉/叙事母题、媒体生态、地区命名、受众预期与已验证的合作模式。

## 3. 需要完整 Portfolio 时建立 Entity Universe

分开不同分析层级：

```text
CORE / CANONICAL
MAJOR DERIVATIVE
SPIN-OFF
REMAKE / REMASTER
ADAPTATION
REGIONAL VERSION / SERVICE
DISCONTINUED / LEGACY
ADJACENT / LICENSED
```

标签可随 Entity 调整，但不同相关对象必须保留不同证据角色。

例如：IP 的真人改编作品可能能证明品牌传播范围，却未必能证明核心游戏视觉语言；软件项目中的旧 Fork 可以证明历史状态，却不能代表当前实现。

## 4. 区分 Stable Identity 与 Mutable Expression

对品牌/IP/Entity，显式拆分：

### 稳定身份（Stable Identity）
跨时间/市场/表达形式反复存在：
- 核心承诺/功能；
- 重复母题；
- 标志性角色/功能；
- 独特机制/仪式；
- 持续存在的叙事或品牌张力；
- 可识别视觉编码。

### 可变表达（Mutable Expression）
会随版本/地区/渠道变化：
- 美术风格；
- Campaign；
- 当前产品组合；
- 运营方；
- Pricing；
- 技术栈；
- 受众侧重点。

用于设计/策略时，以 Stable Identity 作为迁移基础；把 Campaign-specific Style 视为上下文证据。

## 5. Core Asset / Capability 识别

只有多个独立证据反复支持时，才把某个资产视为 Core：

- 出现在多个主要作品/产品中；
- 被官方品牌材料持续前置；
- 跨时代/改编仍然保留；
- 受众/社区可以独立识别；
- 承载独特符号/机制价值；
- 本地化后仍然成立。

对候选资产/能力分类：

- `CORE` —— 中央、稳定、长期存在；
- `SIGNATURE` —— 高识别度，但适用范围更窄；
- `CONTEXTUAL` —— 只适用于某个时期/产品；
- `PERIPHERAL` —— 对 Identity 的证据较弱。

没有定义好的测量方法时使用定性标签，不输出伪百分比。

## 6. 按 Facet 选择来源策略

| Facet | 强来源路径 |
|---|---|
| identity/ownership | Owner/Publisher/Company 页面、财报/备案、官方 Franchise Material |
| portfolio/history | 官方 Catalog、Release Archive、Platform/Store Record |
| current state | 当前 Docs/Store/Operator/Release Notes |
| design/visual | 原始素材、Press Kit、Campaign Page |
| creator intent | Interview、Talk、Design Note |
| audience perception | Forum/Review/Community，作为 perception evidence |
| controversy/failure | 官方回应 + 可信报道 + 必要时的用户证据 |

能够恢复时，决策关键历史优先使用 Primary/Authoritative Source；Fan Wiki 主要作为 Discovery/Supporting Source。

## 7. 当前状态与历史状态

当前状态重要时加载 `freshness-and-current-state.md`。

明确分开：

```text
Historically true
Currently true
Changed / superseded
Unknown current status
```

如果一份 Entity Research 把 2018 年 Ownership、2022 年产品行为和 2026 年当前 Recommendation 混在一起却没有时间标签，这份研究不可靠。

## 8. 地区分析

多市场 Entity 检查：

- 本地化名称；
- 地区运营/发行主体；
- 产品/服务可用性；
- 不同内容/Catalog；
- 视觉本地化；
- 法律/文化约束；
- Audience Positioning。

当市场覆盖会影响结论时，使用地区/服务特定证据验证实际存在状态。

## 9. Synthesis

最终 Entity Model 应能回答：

1. 这个 Entity 到底是什么？
2. 哪些部分稳定且属于 Core？
3. 哪些部分只是上下文性或正在变化？
4. 哪些地区/版本边界会影响分析？
5. 哪些证据真正影响用户决策？
6. 用户应该保留、利用、舍弃或继续调查什么？

用于设计时，以 **identity constraints + opportunity space** 结束，而不是停在历史介绍。
