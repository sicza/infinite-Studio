# 缺口搜索

## 综合前必须做 Gap Review

Gap Review 要回答：

> 还有什么缺失、薄弱或矛盾的区域，可能改变最终答案？

## Gap 类型

- 缺失研究问题；
- 缺失地区/语言；
- 缺失时间段；
- 缺失别名/本地化名称；
- 缺失来源族；
- 未验证 Candidate；
- 薄弱或过期的 decision-critical fact；
- 日期/地区/版本冲突；
- 缺失视觉素材；
- 可能存在重复/来源 lineage 问题；
- 尚未测试的反例；
- 用户明确要求的维度没有进入结果；
- 样本彼此相关性太高，无法支撑当前 Pattern。

## 按决策影响排序 Gap

不是每个缺失细节都值得再做一轮搜索。

使用三档：

- **P0 — decision blocker：** 可能翻转 inclusion、count、recommendation 或 current-state conclusion；
- **P1 — material：** 可能明显改变置信度或重要 Pattern；
- **P2 — contextual：** 有帮助，但大概率不会改变决策。

优先搜索 P0，再处理 P1。Focused/Standard 中，P2 可以保留为 unknown。

## 定向 Gap Search

下一轮搜索必须来自 Gap Diagnosis，而不是重新回到原始大主题。

例如：

- 韩国覆盖缺失 → 本地化名称 + 韩国运营方 + 韩语来源；
- 活动页失效 → 精确活动标题 + 年份 + Archive + 官方社媒；
- “不存在”很可疑 → 替代同义词 + negative search + 运营历史；
- 同一 KV 被重复使用 → 母素材/CDN/Press Kit lineage 调查；
- 技术建议可能过期 → 当前文档 + Changelog + 持续维护实现；
- Pattern 只来自一家 Publisher → 补独立 Publisher/市场，或降低 Pattern Strength。

## 反向搜索（Negative Search）

主动寻找会推翻或复杂化当前结论的证据。

例如：

- 当前证据说日本被排除 → 主动搜索 `Japan collaboration`；
- 搜 rerun/return/second-wave 等词；
- 搜旧产品名/本地化名称；
- 对技术“最佳实践”搜索 `deprecated`、`removed`、`migration`；
- 竞品发现过窄时搜索社区中的“similar to X”；
- 主动找反驳当前视觉/市场 Pattern 的案例。

## 缺口搜索循环

```text
Gap
→ 诊断可能原因
→ 定向修改 Query/Source
→ new fact / candidate / conflict / no result
→ 更新 Research Map
→ 重新判断决策影响
```

如果 Gap Search 暴露新的 alias/operator/source family，它可能打开新的搜索空间，而不是立刻关闭该 Gap。

## Core Mode 何时停止

Focused/Standard 可以在以下条件满足时停止：

- REQUIRED 问题已经足够支持决策；
- decision-critical facts 已验证，或限制已明确；
- P0 与重要 P1 gaps 已经搜索；
- 冲突证据已解决或被保留；
- 剩余 unknown 不太可能改变主结论；
- 最终答案没有宣称穷举完整性。

当新增来源不太可能再改变决策、置信度或必要覆盖时停止。

Exhaustive 任务使用独立的 Closure Protocol。
