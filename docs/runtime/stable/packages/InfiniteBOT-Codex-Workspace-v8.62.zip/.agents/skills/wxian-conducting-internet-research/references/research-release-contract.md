# 研究交付契约

## 面向用户的最低要求

1. **先回答决策问题。** 开头直接给出这次研究要支持的结论、比较结果或 Recommendation。
2. **Decision-critical facts 可追溯。** 会实质影响 inclusion、timing、region、classification、comparison、pattern 或 recommendation 的事实必须有可用来源/引用支持。
3. **区分认知层级。** 保留 sourced fact、synthesis、inference 与 recommendation 的区别。
4. **保留当前状态语义。** Current/latest Claim 在重要时保留已验证的 as-of/版本/日期。
5. **案例证据可追溯。** 列表/表格中的重要案例保持与证据绑定。
6. **显式呈现重要不确定性。** Unknown、Conflict、Blocked Region、弱视觉素材、无法访问的一手来源，如果会影响决策就必须可见。
7. **约束 Recommendation。** 说明机制、适用条件、风险与重要反证。
8. **内部机制保持内部。** 除非用户要求可追溯细节，否则不向用户暴露实现层术语。

## 认知层级标签

```text
FACT — 外部来源直接支持的状态或记录
OBSERVATION / PATTERN — 基于已识别证据或样本形成的综合
INFERENCE — 来源没有直接陈述、但有依据的推理解释
RECOMMENDATION — 针对用户上下文提出的行动建议
```

## 引用位置

证据紧邻其支持的 Claim。案例密集型研究中，对每个重要案例或紧密成组的案例分别引用。每条 Citation 必须只证明它真实能够证明的内容。

## 交付状态

- `COMPLETE_WITHIN_PROTOCOL` —— 所选协议的全部 REQUIRED obligation 已满足。
- `PARTIAL_WITH_LIMITATIONS` —— 答案仍然有用，但重要 REQUIRED 区域仍不确定或被阻塞。
- `BLOCKED` —— 证据或能力限制导致核心决策无法获得可靠答案。

如果枚举代码会降低用户可读性，在最终回答中使用自然语言表达。

## 最终交付检查

- Decision-critical facts 可追溯。
- Current claims 对目标决策足够新。
- Patterns 来自独立证据，而不是重复副本。
- Inferences 与 Recommendations 能与 sourced facts 明确区分。
- 重要冲突与限制保持可见。
- Recommendations 可执行，并且受证据边界约束。
