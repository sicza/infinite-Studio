# 穷举式研究协议（Exhaustive Research Protocol）

用于完整性要求、历史全量清单、严格枚举/计数，或等价的“全部案例”任务。

## 1. 定义 Universe Semantics

### 封闭宇宙（Closed Universe）
存在可信 Registry/List 可以定义完整总体。将每个 Scope 内条目与该权威来源逐项对齐。

### 开放宇宙（Open Universe）
互联网本身就是搜索宇宙。完成意味着：Required Search Protocol 已闭环、Material Discovery 已被继续追踪、剩余限制已明确。

Open Universe 的“完整”必须使用带协议边界的表达。

## 2. 冻结 Enumeration Unit

在大规模枚举前，先定义计数单元与 Dedupe Key。

通用 Collaboration Unit：

```text
Partner A × Partner B × Host Product/Program/Context × Market/Operating Context × Collaboration Instance
```

Game/Live-service Specialization：

```text
Source IP × Host Product × Regional Service × Collaboration Wave
```

Campaign Component、Article、Asset 与 Local Crop 默认作为属性/子项；只有请求定义的 Unit 要求它们独立时才单独记录。

## 3. 建立 Sparse Search Obligations

只建立 Scope 真正要求的 Coverage Obligation。

```yaml
- id: JP-historical-official
  scope: Japan historical collaborations
  language: ja
  source_families: [owner, operator, official-social, archive]
  status: NOT_STARTED
```

状态：

```text
NOT_STARTED
SEARCHING
FOUND
NO_RESULT
BLOCKED
CLOSED
```

`FOUND` 仍然可能产生新的 Obligation。

## 4. 划分搜索空间

使用真正独立的覆盖空间，例如：

- Region；
- Time Band；
- Operator/Service；
- Source Family；
- Product Family。

执行批次与搜索语义分开：一个 Worker 可以处理多个 Obligation；一个 Obligation 也可能需要多次 Search Attempt。

## 5. 当“没有结果”会影响完整性时记录 Search Attempt

对支撑完整性或 No-result Conclusion 的 Obligation，保留：

```yaml
query: ...
language: ...
source_family: ...
result: FOUND | NO_RESULT | BLOCKED
new_material_discovery: ...
```

只记录足以解释 Closure 的关键 Search Attempt。

## 6. Material Discovery 后重新打开

Material Discovery 包括：

- 新 Candidate/Case；
- 新 Alias/Localized Name；
- 新 Regional Operator；
- 新 Source Family/Archive；
- 新 Relevant Time Period；
- 新 Required Gap。

重新打开受影响 Obligation，并更新 Research Map。

## 7. 反向搜索

主动搜索可能改变当前边界或暴露遗漏的证据：

- 被认为排除的 Region 实际包含；
- 更早/更晚 Wave；
- 旧产品名/本地化名称；
- 第二个 Regional Operator；
- 尚未使用的 Collaboration Synonym；
- 反对当前 No-result Conclusion 的 Counterexample。

## 8. Closure Pass（闭环检查）

对每个 Required Open-universe Partition：

1. 完成 Discovery 与 Verification；
2. 处理 High-priority Gap；
3. 最后一次 Material Discovery 后执行定向 Closure Pass；
4. 如果 Closure 又产生 Material Discovery，重新打开并继续；
5. 最终状态为 `CLOSED`、`BLOCKED` 或仍保持 Open。

## 9. Decision-critical Completion

- 已验证/有足够证据支持的 Required Fact → 可以进入 Complete；
- 未解决但非关键 Fact → 作为 Limitation；
- Required 且 unresolved/blocked/conflicted 的 Fact → 根据决策影响进入 `PARTIAL_WITH_LIMITATIONS` 或 `BLOCKED`。

## 10. Final Verification

检查：

- Duplicate Identity；
- Region Include/Exclude；
- Wave/Rerun Distinction；
- Date Semantics；
- Same-origin Evidence；
- 尚未搜索的 Obligation；
- 过早使用 `NO_RESULT`；
- Same-parent Visual Asset；
- 最后一次 Material Discovery 后是否执行 Closure。

高复杂度任务有条件时使用 Fresh-context Reviewer。

## 11. 交付状态

- `COMPLETE_WITHIN_PROTOCOL` —— 每个 Required Protocol Obligation 都已满足。
- `PARTIAL_WITH_LIMITATIONS` —— 结果仍然有用，但重要 Required 区域仍受阻或不确定。
- `BLOCKED` —— 限制使核心研究目标无法获得可靠答案。

列出所有重要 Limitation 与未解决 Unknown。
