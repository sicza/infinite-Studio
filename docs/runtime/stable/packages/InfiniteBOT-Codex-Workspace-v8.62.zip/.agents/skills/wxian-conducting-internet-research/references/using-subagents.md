# 使用 Subagent 做研究

Main Agent 负责 Research Brief、分区逻辑、标准化、decision-critical verification、综合分析与最终 Recommendation。

## 什么时候拆 Shard

按真正独立的边界拆分，例如：

- 使用不同语言/运营方的地区；
- 竞品批次；
- 时间段；
- 独立来源族；
- 大型实体组合；
- 文献综述、历史归档恢复、技术实现、视觉素材搜索等 Specialist 任务。

强依赖顺序的工作保留在 Main Agent 中。

## Worker 角色

### Research Shard
搜索一个独立范围，并在 discovery 与 verification 中始终保留 `LEAD` 与 `FACT` 的边界。

### Specialist
处理方法要求高的子问题，例如学术文献、视觉素材 lineage、历史 Archive、技术实现或领域特定来源分析。

### Review Agent
使用新上下文寻找遗漏、证据错误、重复、过期结论与过度声明，再把发现返回 Main Agent 处理。

## Task Packet（任务包）

```yaml
research_goal: ...
decision_to_support: ...
shard_scope: ...
excluded_scope: ...
known_aliases: [...]
required_questions: [...]
required_source_families: [...]
languages_or_local_names: [...]
decision_critical_facts: [...]
known_risks: [...]
forbidden_conclusions:
  - global completeness
  - final recommendation
return_contract: ShardResult
```

需要时加入路径特定规则，例如联动计数单元或视觉素材等级。

## ShardResult（分片结果）

```yaml
scope_completed: ...
languages_used: [...]
searches_attempted: [...]
findings:
  - statement: ...
    type: FACT | LEAD | UNKNOWN | CONFLICT
    decision_critical: true | false
    source: ...
    evidence_note: ...
    fitness: DIRECT | STRONG | LIMITED | DISCOVERY_ONLY
    confidence: HIGH | MEDIUM | LOW | UNKNOWN
candidates: [...]
aliases_discovered: [...]
conflicts: [...]
gaps: [...]
follow_up_needed: [...]
```

规则：

- `FACT` 必须带 source。
- Decision-critical `FACT` 必须带 evidence note。
- `LEAD` 在验证前保持为 Lead。
- `UNKNOWN` 在新证据解决前保持 Unknown。
- 最终 Recommendation 始终由 Main Agent 负责。
- 单个 Shard 的置信度只代表一条推理链，不构成独立交叉验证。

## Partition 粒度

按有意义的独立工作批量拆分：

- 全球联动搜索可按 Japan / Korea / China / SEA / NA-EU；
- Shortlist 后每个 Verification Shard 处理 3–5 个竞品；
- 论文按子主题或时间段；
- 视觉素材按 Campaign Family 或地区。

对异常复杂或高风险对象分配独立 Specialist。

## 合并协议

计数或综合前：

1. 统一别名与 Canonical Identity；
2. 去重同一案例的翻译/本地化表示；
3. 追踪同源来源；
4. 解决母视觉素材与衍生素材关系；
5. 保留地区/时间/版本差异；
6. 保留冲突；
7. 检查 decision-critical evidence；
8. 把 unresolved gaps 合并回中央 Research Map。

## 重新派发条件

结果暴露新的重要未解决搜索空间时重新派发：

- 新 operator、alias 或 source family；
- 需要深度验证的高价值 Candidate；
- 冲突证据；
- 薄弱 decision-critical evidence；
- 缺失地区/时间 Partition；
- 未解决视觉 lineage；
- 实质挑战当前综合结论的文献簇。

## 无 Subagent Runtime

保留同样的逻辑分区，改为串行执行。只有缺少独立 Review 会实质影响完整性或置信度时，才在结果中说明该限制。
