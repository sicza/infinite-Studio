# 综合与建议

把已验证研究转换成受证据约束的决策支持。

使用推理阶梯：

```text
FACT
→ OBSERVATION
→ PATTERN
→ IMPLICATION
→ RECOMMENDATION
```

建议必须经过完整推理链形成。

## 定义

- **FACT** —— 有外部证据支持的陈述。
- **OBSERVATION** —— 一个或多个事实/素材直接呈现出的现象。
- **PATTERN** —— 在足够独立的证据中反复出现的关系。
- **IMPLICATION** —— 该 Pattern 对用户决策意味着什么。
- **RECOMMENDATION** —— 在用户约束下提出的行动方案。

推断语言保持明确，例如“表明”“与……一致”“在这些案例中”，不要把分析包装成历史事实。

## Pattern 阈值看独立性，而不是原始数量

在把某个现象称为 Pattern 前，先问：

1. 有多少个**独立**样本支持它？
2. 它们来自不同母素材/来源源头/公司/市场，还是同一来源的衍生物？
3. Pattern 是否跨多个相关上下文出现，还是只存在于一个小簇？
4. 是否存在有意义的反例？
5. 表面 Pattern 是否可能只是 Selection Bias？

同一张 KV 的 10 个本地化裁切不是 10 个独立视觉样本。重复同一篇 Press Release 的 5 篇文章，也不是 5 次独立事实确认。

## Pattern 强度

使用定性强度，避免伪精确：

- **STRONG** —— 在多个独立且相关的上下文中重复出现，反证有限；
- **MODERATE** —— 在多个上下文中可见，但样本量、范围或反例限制确定性；
- **TENTATIVE** —— 来自小样本、相关样本或不完整样本的合理信号；
- **CONTRADICTED/MIXED** —— 证据明显指向不同方向。

当 Pattern 会影响 Recommendation 时，说明其判断依据。

## 偏差检查

综合前检查：

- **source bias** —— 样本过度来自同一发行商/网站/社区；
- **region bias** —— 单一市场主导样本；
- **recency bias** —— 易搜索的新材料遮蔽历史实践；
- **survivorship bias** —— 只有成功或被保存的案例仍然可见；
- **selection bias** —— 只收集视觉突出或知名案例；
- **availability bias** —— 把容易找到的证据误认为代表性证据；
- **platform/version bias** —— 把不同平台/版本上下文当成可直接比较；
- **language bias** —— 把英语互联网误当成全球互联网。

无法修正 Bias 时，收窄 Claim。

## Outlier 与负向证据

在赋予权重前先分类 Outlier：

- 噪声；
- 不同上下文；
- 证明 Pattern 是条件性的证据；
- Opportunity Space；
- 反对当前综合结论的证据。

高价值设计机会常常来自理解“为什么少数案例能以不同方式成立”，而不是只复制多数模式。

## 可迁移性检查

推荐某个 Pattern 前，检查它能否迁移到用户上下文：

- 用户需求/受众是否相同？
- 产品机制或承载界面是否相似？
- IP/品牌约束是否接近？
- 市场/格式是否相似？
- 制作资源是否足够？
- 是否存在法律/授权/技术约束？
- 真正产生价值的是机制，还是只有视觉形式？

区分：

- **copy** —— 很少合适；
- **adapt** —— 机制可迁移，但需要上下文调整；
- **benchmark** —— 可作为质量标杆，不是直接方案；
- **reject** —— 反复失败，或与用户约束冲突。

## Recommendation 构造

一个有效 Recommendation 应包含：

```text
Action / direction
+ evidence-backed reason
+ conditions under which it works
+ risks / counterevidence
+ confidence
```

示例结构：

> 当宿主系统能够把客方角色映射成用户熟悉的系统角色时，优先考虑“身份替换式整合”，而不是简单并排放置双方 Logo。多个彼此独立的联动案例表明，更深的宿主系统整合通常能提升双 IP 的一致性。由于最强案例主要集中在角色驱动型游戏中，因此该建议置信度为中等。

## 伪精确

只有评分模型、维度和计算方式明确且合理时，才使用数值分数或数值置信度。

证据本身是定性的，就使用定性优先级。

## 置信度（Confidence） Propagation

Recommendation 的置信度受支持链中最薄弱的关键环节约束；Tentative Pattern 只能产生 Tentative Recommendation。

## 综合质量检查

交付前回答：

- 哪些事实一旦错误，这条 Recommendation 就会失败？
- 当前“Pattern”是否真的来自独立证据？
- 哪个反例最可能推翻它？
- Recommendation 是否能迁移到用户上下文？
- 答案是否缩小了用户的决策空间，还是只做了研究摘要？
