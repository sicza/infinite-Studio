# Playbook — 对比研究

用于竞品、替代方案、Benchmark、Shortlist、Selection，或“我们应该向谁学习？”这类问题。

先定义竞争/选择逻辑，再广泛发现 Candidate，有意识地筛选，深挖 Shortlist，最后把结果综合成更小、更清晰的决策空间。

## 1. 写出 Comparison Thesis

先明确为什么这些 Candidate 值得比较。

可能维度：

- 相同用户需求；
- 相同受众；
- 相同核心玩法/功能；
- 相同平台/分发界面；
- 相同商业模式或用户支出竞争；
- 相同市场/地区；
- 相同 Use Case/Workflow；
- Aspirational Quality/Capability；
- Visual/Design Benchmark。

示例：

> 一个准备做联动 Campaign 的产品，既可能需要直接产品竞品，也可能需要单独寻找联动包装更强的视觉 Benchmark。两者应作为不同 Comparison Role 处理。

## 2. 定义 Candidate Role

- **DIRECT** —— 争夺同一用户/问题/上下文；
- **INDIRECT** —— 争夺邻近需求/注意力/支出；
- **ASPIRATIONAL** —— 展示目标能力或品质；
- **FUNCTIONAL_BENCHMARK** —— 对某个机制/功能有学习价值；
- **VISUAL_BENCHMARK** —— 对呈现方式/美术方向有学习价值。

同一个 Candidate 可以同时承担多个 Role，但只保留一个 Canonical Record。

## 3. 从独立路径生成 Candidate Universe

通过多个彼此独立的 Discovery Path 建立 Candidate Universe。

使用多种 Discovery Surface：

### 问题 / 用户路径
- 还有什么在解决同一个用户问题？
- 还有什么在争夺同一批时间/支出？

### 类别 / 功能路径
- 相同 Genre/Function/Workflow；
- Store/Platform Category；
- 官方类别页面。

### 市场路径
- 目标地区的主要产品；
- 英文全球来源容易漏掉的本地领先者。

### 社区路径
- “similar to X”；
- Switching/Comparison Discussion；
- 用户替代方案。

### 质量 / 奖项路径
- Award/Ranking/Editorial List 只用于 Discovery。

### 视觉 / Aspirational 路径
- 即使不是直接竞品，也定义了用户质量预期的产品。

Candidate 来自不同 Discovery Mechanism 时，Candidate Universe 更可信。

## 4. 深挖前先 Screening

从 Comparison Thesis 推导 Screening Questions。常见维度：

- 用户重合；
- Use-case 重合；
- 核心 Mechanic/Function 重合；
- 市场重合；
- 商业模式相关性；
- 战略相关性；
- 证据可获得性；
- Novelty/Learning Value。

没有真正合理的评分模型时，使用定性标签。

示例：

```text
HIGH relevance — 直接影响同一个决策
MEDIUM — 在一个重要维度上是有效 Benchmark
LOW — 只有表面相似，或可迁移性很弱
```

只对 Screening 后的 Shortlist 做 Deep Dive。

## 5. 深挖 Shortlist

对每个选中 Candidate 回答同一套核心问题，使比较建立在统一维度上，而不是零散案例：

```text
为什么它可比？
它服务什么用户/问题？
核心 Proposition/Mechanism 是什么？
真正 Distinctive 的地方是什么？
什么证据证明这些行为？
哪里做得好？
哪里失败或存在 Trade-off？
哪些部分可以迁移到我们的上下文？
哪些部分无法迁移？
```

再根据 Route 增加专业维度，例如 Monetization、Gameplay Loop、Campaign System、Visual Identity、Onboarding、Creator Workflow 等。

## 6. 区分 Similarity 与 Learning Value

一个强 Comparator 可能表面上并不相似，但机制上非常值得学习。

检查：

- Candidate 真正提供的是 Mechanism Learning，还是只有 Aesthetic Inspiration？
- 成功是否依赖我们能够复制的 Capability？
- 上下文是否可比？
- 是否因为某个 Market Leader 最容易被看到，就过度拟合它？

Visual/Aspirational-only Benchmark 与真正竞争结论分开标记。

## 7. 比较 Pattern，而不是只做横向表格

完成 Deep Dive 后，寻找：

- **table stakes** —— 几乎所有重要玩家都必须具备；
- **clusters** —— 常见战略原型；
- **differentiators** —— 只有部分玩家真正拥有的能力；
- **trade-offs** —— 某种收益对应的代价；
- Failure Patterns；
- Underserved Needs；
- White Space；
- 不值得复制的误导性 Benchmark。

使用独立证据。来自同一 Publisher 的 5 个产品可以说明 Publisher Pattern，不自动说明 Market Pattern。

## 8. White Space 分析

用以下问题验证 White Space：

1. “没人做”是真实空白，还是搜索缺口？
2. 这个需求真的有价值吗？
3. 是否存在导致其缺失的结构性原因？
4. 用户实际有能力执行吗？
5. 这种差异化能持续，还是很容易被复制？

分类：

- validated opportunity；
- plausible opportunity；
- unexplained absence；
- likely bad idea / constraint-driven absence。

## 9. 搜索诊断

### Candidate List 被全球知名品牌主导
转向目标市场、本地 Store 和本地语言 Comparison。

### 所有 Candidate 看起来都很像
重新检查 Competition Thesis；按用户需求/功能发现 Candidate，而不是按审美相似度。

### Candidate 太多
收紧 Screening；只深挖真正可能改变决策的对象。

### Shortlist 缺少强证据
替换弱 Candidate，而不是用更多叙事去弥补证据不足。

## 10. 综合分析

有价值的 Comparative Research 应缩小决策空间：

- 哪些 Candidate 最重要，以及为什么；
- 每个 Candidate 承担什么 Comparison Role；
- Table Stakes vs Differentiators；
- 可迁移 Mechanism；
- White-space Opportunities；
- Pitfalls 与 Anti-patterns；
- 剩余不确定性。

最终输出应该把下一步决策压缩成一组更小、且有证据支持的选择。
