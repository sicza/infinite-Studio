# 理解研究意图

把简短或含糊的请求转化为内部 Research Brief，使它能够预测“一个真正有用的答案必须包含什么”。

## 先推断；只有必要时才提问

尽可能从用户请求、已有上下文和明显含义中直接确定：

- **subject** —— 要研究什么；
- **decision_to_support** —— 用户研究后要决定、设计、选择、构建或理解什么；
- **route(s)** —— topic/entity/comparative/event/visual/hybrid；
- **depth** —— focused/standard/exhaustive；
- **scope** —— 地区、时间、平台/媒介、包含项/排除项；
- **freshness** —— 当前状态、历史状态或混合；
- **evidence sensitivity** —— 哪些事实一旦错误会改变结论；
- **deliverable** —— 聊天回答还是长期维护的正式产物。

只有缺失信息会改变搜索空间或决策时才提问。能够通过研究获得的事实直接去研究。

## Research Brief

Brief 保持轻量并仅用于内部执行：

```yaml
brief_version: 1
subject: ...
decision_to_support: ...
routes: [...]
depth: FOCUSED | STANDARD | EXHAUSTIVE
scope:
  regions: [...]
  time_range: ...
  platforms_media: [...]
  inclusions: [...]
  exclusions: [...]
freshness: CURRENT | HISTORICAL | MIXED
visual_required: true | false
artifact_required: true | false
decision_critical_questions: [...]
```

把 Brief 写成与决策绑定、可以直接执行的研究目标，而不是对研究主题的同义改写。

## 把请求转换成决策模型

内部回答：

1. **最终要做什么决策？**
2. **什么证据会改变这个决策？**
3. **哪些内容即使省略也不会改变决策？**
4. **哪些信息一旦错误或缺失，会让最终答案产生误导？**

示例：

### “研究这个 IP”
可能的真实目的包括品牌概览、联动设计准备、商业尽调、视觉研究或系列时间线。优先从上下文判断最可能的决策；只有不同解释会实质改变研究路径时，才提出一个高价值问题。

### “找全球 5 个手游竞品”
`Global` 描述的是地理范围，“5 个”描述的是聚焦交付数量。这**不**意味着需要穷举式研究。

### “把历史所有联动尽量找全”
完整性本身是交付目标，因此触发 Exhaustive Protocol。

## 路径选择

- **TOPIC_RESEARCH** —— 方法、标准、实践、论文、Prompt、工程知识。
- **ENTITY_RESEARCH** —— IP、游戏、产品、公司、品牌、人物、项目。
- **COMPARATIVE_RESEARCH** —— 竞品、替代方案、标杆、选择比较。
- **EVENT_RELATIONSHIP_RESEARCH** —— 联动、合作、发布、上线、事件与时间线。
- **ASSET_VISUAL_RESEARCH** —— KV、Banner、UI、网站、Campaign、设计系统。
- **HYBRID_RESEARCH** —— 当一种研究结果需要继续供给另一种研究时组合多条路径。

需要多条路径时使用 Hybrid Research；有依赖关系的路径按顺序执行，例如 Entity → Event/Collaboration → Visual，或 Comparative → Visual 深挖。

## 深度选择

- **FOCUSED** —— 用少量已验证证据回答一个窄范围决策，不做完整性声明。
- **STANDARD** —— 默认模式，系统覆盖主要相关维度与来源族。
- **EXHAUSTIVE** —— 用户明确要求全部、历史完整、全量、尽可能找全，或严格计数依赖搜索闭环。

深度只改变研究投入，不改变事实标准。Focused 可以使用更少案例，但案例本身仍然需要有效证据。

## 范围变化

如果用户在研究过程中改变范围，应对 Brief 版本化，而不是静默覆盖：

```yaml
brief_version: 2
parent_version: 1
change_reason: "增加韩国和视觉研究"
affected_scope: [regions, visual]
```

保留仍然有效的研究结果，重新打开受影响的研究空间，只使依赖变化范围的结论失效。

## 质量检查

搜索前，Brief 应该能够回答：

- 为什么要做这次研究？
- 什么样的答案才真正有用？
- 哪些事实最不能出错？
- 哪些维度是必须的，哪些只是有趣？
- 用户明确**不需要**什么？

Brief 必须把用户请求转化为一个在执行上明显不同的研究计划。
