# Playbook — 事件 / 关系研究

用于联动、合作、发布、上线、授权、Campaign、收购、历史事件，或连接多个 Entity 的时间线研究。

重建：**谁在什么产品/服务/市场、什么时间做了什么，以及什么证据能够证明。**

## 1. 需要计数时先定义 Event Unit

可能维度：

```text
participating entities
× product/service
× region/service
× event/campaign wave
```

只使用对用户研究目的真正构成“独立事件”的维度。

文章、社媒帖、素材、Campaign Component 和本地化文案，默认都是某个 Event 的证据或组成部分；只有用户定义的 Unit 要求它们独立时才单独计数。

## 2. 重建 Lifecycle

很多事件包含多个时间节点：

```text
rumor/tease
announcement
registration/preorder
launch/start
active period
shop/exchange window
rerun/relaunch
end
regional release
```

分别保留每种 Lifecycle Date。

来源日期冲突时，先检查它们是否指向不同 Lifecycle Stage。

## 3. 解决参与方与运营上下文

对每个 Event 验证：

- 精确参与 Entity；
- 产品/服务/版本；
- Owner/Publisher/Operator；
- Region/Market；
- Platform；
- First Run vs Rerun；
- “Global”标签是否真的覆盖目标市场。

不同市场执行情况存在差异时，分别验证地区实际执行。

## 4. 搜索路径

```text
generic relationship discovery
→ exact participant/event names
→ owner/participant official sources
→ product/operator/regional pages
→ precise event/campaign page
→ official social/press archive
→ historical archive
→ local-language searches
→ negative/gap searches
```

条件允许时搜索关系双方的证据。一方删除的材料，另一方可能仍然保留。

## 5. 关系深度

对于 Partnership/Collaboration，区分“宣布关系”和“真实整合”：

- 只有 Branding/Mention；
- Content Addition；
- Product/Mechanic Integration；
- Identity/System Integration；
- Long-term Strategic Relationship。

Relationship Depth 必须根据已验证的真实执行分类，而不是根据营销形容词。

## 6. Regional Semantics

显式解析：

- global campaign；
- international version；
- global server；
- all supported markets；
- region-specific operator；
- `global excluding X`；
- region not served。

根据 Service/Region Evidence 语义判断市场是否实际包含。

## 7. Historical Reconstruction

旧事件研究：

- 搜索旧产品名/运营方名称；
- 搜精确 Campaign Title + Year；
- 使用官方 News Index / Social Archive；
- 使用 Web Archive/Cache；
- 证据无法恢复时，把缺失细节保留为 Unknown。

无法恢复的 Timeline Date 保持 Unknown。

## 8. Synthesis

分别整理：

- Relationship 是否真实存在；
- 精确地区执行；
- Lifecycle/Timing；
- Mechanics/Components；
- Assets；
- Recurrence/Reruns；
- Strategic Pattern。

Relationship Pattern 必须基于独立 Event，而不是同一个 Event 的多篇报道。
