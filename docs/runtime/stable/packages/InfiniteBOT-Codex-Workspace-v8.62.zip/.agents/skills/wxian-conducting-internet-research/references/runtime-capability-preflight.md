# Runtime 能力预检

根据 Research Map，只检查当前任务实际需要的能力。

| 能力 | 何时需要 | Fallback |
|---|---|---|
| Web Search | 需要开放互联网 discovery | 使用现有来源访问能力；否则把受影响搜索空间标记为 blocked |
| Page Fetch/Read | 需要页面级验证 | 使用替代原始来源/Archive；Snippet 保持为 Lead |
| Image Search/Inspection | 需要视觉分析 | 恢复官方素材；否则限制或省略精确视觉 Claim |
| Archive Access | 历史/失效页面对结论重要 | 使用官方社媒、Publisher/Operator Archive、允许使用的 Cache/Mirror；保留 Unknown |
| Subagents/Fresh Context | 独立搜索空间或独立复核重要 | 串行执行各 Partition；必要时说明限制 |
| Durable File State | 启用 Artifact Protocol | 使用运行时最强的可追溯序列化形式；Freeze/Durable 语义需要可靠持久化 |
| Citation Support | 需要机器可寻址引用 | 在可支持格式中保留 source title、URL/locator 与 evidence note |

能力缺口改变执行方式，不改变研究范围。使用可用的最强 Fallback，再把受影响 obligation 分类为 satisfied、limited 或 blocked。
