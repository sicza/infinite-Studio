# Playbook — 视觉研究

用于 KV、Campaign Art、Banner、UI、Poster、Website、Store Creative、Brand Visual、Visual System 或 Design Pattern Research。

识别素材角色、视觉机制、样本独立性与可迁移的设计启示。

## 1. 先确认 Asset，再做分析

精确视觉 Claim 必须建立在可验证、且正确绑定到 Campaign/Entity/Version/Region 的素材上。

使用简单等级：

- **V3** —— 官方原始/高质量一手视觉；Role 清晰；
- **V2** —— 官方高质量宣传素材；Role 歧义较小；
- **V1** —— Thumbnail/Screenshot/Crop/二次转载；只能做有限观察；
- **V0** —— 没有可验证素材；不做精确视觉分析。

视觉结论的精度不能超过 Asset Grade。

## 2. 先识别 Asset Role

只在素材真实承担的 Campaign Role 中进行比较。

可能 Role：

```text
HERO / MAIN KV
EVENT / CAMPAIGN KV
CHARACTER KEY ART
SOCIAL ANNOUNCEMENT
STORE / APP CREATIVE
BANNER / PERFORMANCE AD
UI / IN-PRODUCT PROMO
PRESS / MEDIA ASSET
SECONDARY / LOCALIZED ADAPTATION
```

Role 决定设计目标；Performance Banner、Hero KV、Store Asset 与 Localized Adaptation 都应该按自身职责评估。

## 3. Asset 搜索路径

搜索：

- 官方 Campaign/Event Page；
- 官方社媒原始帖；
- Press/Media Kit；
- Owner/Operator Asset/CDN Link；
- App/Store Update Creative；
- Publisher/Operator Archive；
- Archived Page 及页面素材；
- Regional Variant。

只有 Screenshot/Repost 时，记录限制，并收窄 Typography、Color、Crop 与 Intended Role 相关 Claim。

## 4. Asset Lineage（素材谱系）

分类关系：

```text
ORIGINAL
SAME
LOCALIZED
CROP
ADAPTATION
UNKNOWN
```

计数 Creative Sample 前先确认 Parent Lineage。

常见信号：
- 相同角色 Pose/Render；
- 相同背景 Geometry；
- 相同特效/Lighting；
- 只有 Logo/Copy/Crop 改变；
- 条件允许时比较相同 CDN/Hash；
- 官方页面之间的关系。

5 个 Localized Crop 可以是 5 个 Distribution Asset，但仍然只有 1 个 Creative Concept。

## 5. 按顺序分析

### 阶段 A — 构图机制
识别：

- Focal Point；
- Camera/Visual Axis；
- Dominant Geometry；
- Depth Layer；
- Motion Direction；
- Negative Space；
- Balance/Symmetry；
- Crowd vs Single-hero Structure。

需要时给构图机制命名，例如 Confrontation、Diagonal Charge、Centered Hero、Split-world、Ring/Portal Framing、Ensemble Wedge，或其他清晰普通语言描述。

### 阶段 B — 视觉层级与归属
检查：

- 第一眼、第二眼、第三眼分别看到什么？
- 哪个 IP/Brand 占据 Center/Focal Position？
- Host World 还是 Guest Character 更主导？
- Logo/Title/CTA 与焦点层级是什么关系？
- Branding 是辅助 Illustration，还是与 Illustration 争夺注意力？

只有存在明确测量方法时，才使用数值化 IP-share Claim。

### 阶段 C — 视觉语言
检查：

- Color Ownership 与 Contrast；
- Lighting Direction 与 Separation；
- Material/Effect Language；
- Environment/World Cue；
- Typography Integration；
- Symbolic Prop/Icon；
- Character Silhouette/Pose；
- Host vs Guest Visual-code Fusion。

核心问题：**去掉 Logo 后，这个 Collaboration 还能否通过角色/世界/视觉编码被识别？**

### 阶段 D — 整合机制
对 Collaboration/Brand Work，判断：

- Side-by-side Collage；
- Shared World；
- Host-style Reinterpretation；
- Guest-style Takeover；
- Identity Substitution；
- Role/Class/Mechanic Mapping；
- Narrative/Environment Integration。

### 阶段 E — Campaign 系统
存在多套协同素材时，把 Campaign 作为一个系统分析。

条件允许时追踪：

```text
Hero KV
→ horizontal/vertical adaptations
→ social cards
→ banners
→ store assets
→ character cards
→ in-game UI/event pages
→ rerun refresh
```

判断核心视觉概念能否跨 Format 生存，还是离开 Main Canvas 就失效。

### 阶段 F — 本地化
比较地区版本：

- Copy Density；
- Logo Placement；
- Censorship/Regulatory Change；
- Crop/Layout Change；
- Local Platform/CTA Requirement；
- Character Emphasis 是否改变；
- 是不同 Parent Creative，还是简单 Adaptation。

## 6. Failure Tests

只在它们能回答设计问题时使用：

### Remove-logo Recognition
移除 Logo 后，双方 IP 是否仍能通过角色/世界/视觉编码被识别？

### Crop Resilience
核心 Idea 能否在 4:5、1:1、9:16、Banner Crop 中保留？

### Replace-character Test
如果把中央 Guest Character 换成一个无关角色，Concept 是否仍然独特？如果仍然成立，这个 Idea 可能过度依赖角色身份本身，而缺乏真正整合机制。

### Gameplay/System Mapping
Creative 是否传达玩家真实要做什么/得到什么，还是只宣布“有联动”？

### Identity Balance
是否一方 IP 完全压过另一方？这种失衡是否符合该 Campaign Role 的目标？

## 7. 跨案例比较

提炼 Pattern 前，先按以下维度标准化 Sample：

- Asset Role；
- Parent Creative Lineage；
- Region；
- Campaign Wave；
- Host/Guest Relationship；
- Format。

跨案例比较前，先按 Role 与 Parent Lineage 统一 Hero KV、Store Banner 与 Localized Crop。

Pattern Questions：

- 哪些 Composition Mechanism 在独立 Parent Creative 中反复出现？
- 哪些 Integration Mechanism 能产生最强的双 IP 一致性？
- 哪些 Idea 在不同 Format 下最稳健？
- 哪些方法高频但 Generic？
- 哪些 Regional Adaptation 实质提升清晰度？
- 哪些 Rerun 真正刷新 Creative，哪些只是重新发布？

## 8. 把研究转成 Design Opportunity

使用综合阶梯：

```text
Verified asset observations
→ independent cross-case pattern
→ why the mechanism works
→ applicability to the user’s product/IP
→ concrete design opportunity
```

Recommendation 应明确说明**机制**、实现含义与约束。

弱：
> 使用更强的构图和更多 IP 氛围。

更好：
> 把 Guest Character 映射到用户熟悉的 Host Role/Class，并让 Host-system Prop/Environment 承载 Guest Visual Code，使联动看起来属于同一个世界，而不是两张角色 Cutout 并排。Hero KV 保留一个绝对主焦点角色，再使用模块化 Secondary Asset 承载更完整的角色阵容。

## 9. 结果记录

对每个重要案例分别记录：

- Campaign/Event Fact；
- Asset Source 与 Grade；
- Asset Role；
- Parent Lineage；
- Visual Observation；
- Interpretation；
- Cross-case Significance。

Asset 很弱或无法获得时，明确说明，并停止继续输出精确视觉 Claim。
