# Optional Playbook — 市场格局研究

当问题关注的是一个 Market/Category Ecosystem，而不是短名单竞品时使用。

所有定量 Claim 必须与可获得的市场证据强度和定义匹配。

## 1. 定义 Market Boundary

明确：

- Category/Product Definition；
- Geography；
- Customer Segment；
- Platform/Channel；
- Time Period；
- 如果需要量化，明确 Revenue/Usage/Activity Metric。

没有分母与定义的市场数字没有意义。

## 2. 建立 Landscape

可能维度：

- Segment；
- Major Player；
- Substitute/Adjacent Category；
- Distribution/Platform Context；
- Business Model/Pricing；
- Growth/Decline Signal；
- Regulation/Policy；
- Technology Shift；
- 当前 Entry/Exit/Ownership Change。

## 3. 定量证据类别

明确区分：

- 官方测量统计；
- 公司财报/已披露数字；
- 可靠研究机构估算；
- Model-based Estimate；
- 公司 Marketing Claim；
- Qualitative Inference。

不同 Market Definition 的数字保持分开；Model Estimate 与 Measured Fact 必须分别标记。

## 4. 来源路径

根据主题使用：

- Government/Regulatory/Statistical Agency；
- Company Filing/Earnings；
- Platform/Operator Data；
- 可靠 Research Firm；
- Trade Association；
- Academic/Industry Study；
- Specialist Media；
- 无法获得完整数据时的 Paid Database Metadata。

研究当前市场状态时加载 `freshness-and-current-state.md`。

## 5. 交叉校验

数字不一致时检查：

- Market Definition；
- Geography；
- Gross vs Net Revenue；
- Bookings vs Revenue；
- User vs Account vs Device；
- Time Period/Currency；
- Methodology/Sample；
- Modeled vs Observed Data。

只有定义、时间段和分母兼容时，才合并定量估算。

## 6. Synthesis

有效 Market Landscape 应区分：

- Measured Facts；
- Directional Signals；
- Structural Drivers；
- Uncertainty/Data Gaps；
- 对用户决策的 Implication。

如果只有公开信号，就明确称为“Public-signal Landscape”，不要包装成经过测量的 Market Estimate。
