# 时效性与当前状态研究

当答案依赖**现在真实是什么**、什么是**最新/最近**，或历史实践今天是否仍然适用时使用。

## Freshness 属于具体 Claim

“最近发布”不自动等于“当前有效”；旧页面也可能准确描述一个稳定事实。时效性必须根据被陈述的对象判断。

常见可变化 Claim：

- 产品可用性；
- 所有权/领导层；
- 软件行为/版本支持；
- 政策/法规；
- 价格；
- 日程/事件；
- 当前文档；
- 市场/玩家状态；
- 推荐的技术实践。

## 区分多种时间语义

需要时分别记录：

- `published_at` —— 来源发布时间；
- `updated_at` —— 来源修订时间；
- `effective_at` —— 规则/行为开始生效的时间；
- `observed_at` —— 实现/结果实际被观察到的时间；
- `as_of` —— 当前状态 Claim 适用到哪一天。

选择与 Claim 语义真正匹配的时间字段。

## 当前状态验证路径

对可变化的技术/产品事实：

```text
current official docs
→ current release notes/changelog
→ maintained code/examples/tests
→ current issue/discussion when behavior is ambiguous
→ practitioner evidence for real-world behavior
```

对组织/所有权/可用性：

```text
current official page/filing/operator/store
→ current announcement
→ reputable current reporting
```

对政策/法规：

```text
current authoritative legal/regulatory text
→ official guidance
→ expert interpretation if needed
```

## 版本适用性

“当前最佳实践”必须有当前适用性证据。

软件/技术研究至少确认：

- 产品/库/模型版本；
- 来源对应的日期/版本范围；
- 行为是否已 deprecated、removed、renamed 或被 superseded；
- 当前官方示例是否仍然采用该实践。

显式搜索：

```text
[topic] current docs
[feature] deprecated
[feature] release notes
[feature] migration
[feature] removed / changed
```

## “Latest”研究

用户要求 latest/recent/current 时：

1. 确定相关时间窗口；
2. 按**事件/生效时间**排序，而不只看文章发布时间；
3. 验证最新 Candidate 是否真的是最新的实质变化；
4. 区分“关于旧事件的新文章”和“真正的新事件”；
5. 相对时间容易误导时，使用具体日期。

## 时效性冲突

旧官方文档与当前实现冲突时：

- 检查文档是否过期；
- 检查版本范围；
- 当前状态 Claim 优先采用当前权威行为；
- 历史行为单独保留，不在缺少上下文时简单宣布某个来源“错误”。

## 当前状态交付规则

高置信度的 current-state Claim，需要证据覆盖一个合理的变化窗口，或有本次当前状态验证。

如果无法获得当前证据：

> 明确写出最后已验证日期与限制，而不是把历史证据包装成当前事实。
