# Sub-Playbook — 联动 / 合作研究

当任务涉及 Collaboration、Crossover、Partnership、Licensing Activation、Co-branded Campaign 或 Collaboration Design 时，与 Event/Relationship Research 一起加载。

## 1. 定义 Collaboration Unit

通用基础单元：

```text
Partner A
× Partner B
× Host Product / Program / Context
× Market / Operating Context
× Collaboration Instance
```

根据领域解释这些字段：

- `Host Product / Program / Context` 可以是游戏、产品线、Campaign、服务、事件、影视作品、零售项目、平台或其他执行载体。
- `Market / Operating Context` 可以是国家/地区、Service/Operator、Channel、Edition；如果合作不按市场拆分，则使用 `NOT_APPLICABLE`。
- `Collaboration Instance` 用于区分首次、续作、复刻、Season、Wave 或研究目的需要区分的独立执行。

子项/属性可以包括 Campaign Component、Product/Item、Mechanic、Time Window、Asset、Announcement 与 Localization。

文章、素材、SKU 和媒体投放默认是某个 Collaboration Instance 的子项/属性，除非请求明确把它们定义成独立记录。

### 游戏 / Live-service 特化

对游戏/IP 联动历史，一个常用特化单元是：

```text
Source IP / Brand
× Host Product
× Regional Service
× Collaboration Wave
```

只有 Regional Service 与 Wave 真的是 Host Product 的实际属性时才使用。

## 2. Discovery 词汇

组合搜索：

- 双方 Partner 的本地化名称；
- collaboration/crossover/partnership/licensing/co-brand 同义词；
- 与媒介匹配的 event/campaign/collection/limited-time 术语；
- 必要时加入 market/operator/channel 名称；
- 年份区间；
- 存在重复执行可能时加入 rerun/return/second-wave 术语；
- Scope 涉及时加入 game、card、retail、offline、film、apparel、merchandise、platform、service 等媒介词。

搜索双方生态。一方可能保存品牌/授权证据，Host 一方则更可能保存运营细节。

## 3. 最低验证要求

对每个纳入的 Collaboration Instance，验证会影响决策的字段：

- 双方主体/合作身份；
- Host Product/Program/Context；
- 适用时的 Market/Operating Context；
- 相关日期/周期语义；
- 适用时区分 First Run vs Repeat Execution；
- Source Evidence。

Mechanics、Characters、Products、Rewards、Campaign Claims 或 Visual Assets 需要各自证据；“合作存在”不能自动证明所有执行细节。

## 4. 联动整合深度

用户需要设计/策略洞察时，分类的是**整合机制**，而不只是 Partner 是否出现。

一个实用的定性阶梯：

- **L0 — Co-branding：** Logo/并排宣传；几乎没有 Host-system Integration。
- **L1 — Content insertion：** Guest Content/Product/Skin/Asset 被加入，但重新解释有限。
- **L2 — Visual-language transformation：** Host Campaign 主动采用 Partner 可识别的视觉编码、环境、母题或包装语言。
- **L3 — Identity substitution：** Partner Identity 被映射进 Host 的 Role、Class、Product、Format、Ritual 或用户熟悉的 Interaction Structure。
- **L4 — World/system integration：** Collaboration 实质改变 Host Experience、Environment、Mechanic、Progression、Narrative、Retail/Service Flow 或长期系统行为。

把它作为分析 Lens 使用，并保留不确定性。

## 5. Campaign 组件分析

只选择与具体媒介相关的 Component：

```text
hero / announcement creative
products / characters / skins / items
world / environment / spatial changes
mechanics / participation loop
story / quests / content
commerce / rewards / collection structure
social / community activation
offline / physical execution
channel / market localization
rerun / sequel packaging
```

## 6. 视觉整合

如果用户要求视觉研究，单独加载 Visual Research。比较 Creative Pattern 前，先验证 Asset 与 Parent Lineage。

区分：

- Collaboration Instance Count；
- Distribution Asset Count；
- Independent Parent Creative Sample Count。

这些数量通常并不相等。

## 7. 常见陷阱

- Partner Announcement ≠ 已执行的 Collaboration Detail；
- Host Product/Program ≠ Market Context ≠ Collaboration Instance ≠ Asset；
- `Global` ≠ 每个 Market/Channel；
- Announcement Date ≠ Execution Start；
- Repeat Execution 可能复用内容，却改变 Packaging；
- 同一 Parent Creative 可能跨市场/渠道重复出现；
- Digital、Physical、Offline、Service、Media、Retail Execution 可能需要分不同 Bucket；
- 没找到案例不能证明全球不存在。

## 8. Pattern 综合

有价值的问题：

- 哪些 Partner/Context Category 反复出现？
- 哪些 Integration Depth 最常见，哪些对决策最有价值？
- 哪类 Host Structure 最能有效吸收 Partner Identity？
- Repeat Execution 中什么被复用，什么被刷新？
- 哪些 Market/Channel Adaptation 实质改变呈现或参与方式？
- 哪些 Motif/Mechanism 已经过度使用？
- 哪些未探索机会有可信依据？

区分**高频**与**有效**。某种模式常见，可能只是因为便宜或容易执行，并不意味着战略价值最高。

## 9. Exhaustive 任务

对“全部/历史/完整”Collaboration Request，始终加载 `../protocols/exhaustive-research.md`。按照领域真实运营维度切分 Partition——地区、Channel、Operator/Service、Time Band、Partner Family 或 Source Family——并在最后一次 Material Discovery 后执行 Closure。
