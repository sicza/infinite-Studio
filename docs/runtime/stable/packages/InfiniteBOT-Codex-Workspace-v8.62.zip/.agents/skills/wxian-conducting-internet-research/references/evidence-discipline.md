# 证据纪律

## 证据必须针对具体 Claim

在 Claim 层级判断证据：

> 这条证据是否直接支持“这个对象/版本/地区/时间条件下的这条陈述”？

## 轻量证据等级

- **E3 — Direct primary：** 能精确证明该陈述的官方/原始/所有者/运营方/文档证据。
- **E2 — Strong：** 可靠第一方或高质量来源，推断距离很短。
- **E1 — Limited/discovery：** 二手、间接、不完整、过期或仅适用于特定上下文的证据。
- **E0 — Unsupported：** 没有可用证据；不能进入事实陈述。

这些等级用于定性辅助，不是通用数值评分模型。

## 事实状态

需要时使用四种语义状态：

- `FACT` —— 对当前任务而言已经获得足够支持；
- `LEAD` —— 有可能为真，但尚未验证；
- `UNKNOWN` —— 必要信息仍未解决；
- `CONFLICT` —— 可靠证据之间存在冲突。

在新证据解决之前，`LEAD` 与 `UNKNOWN` 必须保持原状态。

## Claim 粒度

只在会影响决策的层级结构化证据。

- **decision-critical fact：** 明确陈述 + source + evidence note + confidence + 必要时的 freshness；
- **supporting fact：** 通常可追溯引用即可，除非存在争议；
- **background context：** 对结论有实质帮助时引用；Core Mode 不要求单独建立 Ledger。

## 证据匹配度（Evidence Fitness）

需要时，用简单的 Claim-fit 描述：

- `DIRECT` —— 来源直接陈述/展示该 Claim；
- `STRONG` —— 存在很小且可辩护的推断；
- `LIMITED` —— 间接、局部或过期；
- `DISCOVERY_ONLY` —— 适合作为线索，不足以证明。

Fitness 属于“来源与具体 Claim 的关系”，不是来源本身的永久属性。

## 置信度（Confidence）

除非任务本身有真实评分模型，否则使用定性置信度：

- HIGH；
- MEDIUM；
- LOW；
- UNKNOWN。

置信度取决于：

- evidence fitness；
- 来源距离；
- freshness；
- conflict 状态；
- 推断距离；
- 综合结论所依赖样本的独立性。

置信度向下游只能保持或降低：

```text
Evidence → Fact → Observation → Pattern → Implication → Recommendation
```

## 独立证据

追踪可能的源头与依赖关系；同一篇 Press Release 的多个转载只能算一个证据源头。

论文、Benchmark 报告和视觉素材同样如此：同一源头的多个衍生版本，除非存在实质性差异，否则只算一个独立样本。

## 冲突证据

综合时保留重要的负向与冲突证据。

对冲突分类：

- 真正冲突；
- 不同版本/地区/时间；
- 不同指标/定义；
- 来源质量差异；
- 样本/上下文差异。

无法解决时保留 `CONFLICT`，并降低下游置信度。

## “不存在”类 Claim

“没搜到”首先是在描述搜索协议，不自动等于现实中不存在。

合格表达：
> 在已搜索的地区、语言、时间段和来源族范围内，没有发现可验证案例。

强“不存在”结论需要封闭/权威可枚举的研究宇宙，或等价强度的证据。

## 证据充分性检查

Decision-critical fact 进入综合前，回答：

1. 具体 Claim 是什么？
2. 哪条证据支持它？
3. 为什么这条证据适合证明这个 Claim？
4. 对该 Claim 而言是否足够新？
5. 最强的合理反解释是什么？
6. 如果这个事实被改写，会不会改变用户决策？

如果第 6 项为“会”，而前 5 项很弱，则继续研究，或在交付中明确限制。
