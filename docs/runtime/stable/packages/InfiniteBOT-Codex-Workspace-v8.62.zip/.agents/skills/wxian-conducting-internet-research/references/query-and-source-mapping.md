# 查询与来源映射

通过改变词汇、语言、来源族、运营主体、归档路径与证据路径，建立一个尽量提高召回率的搜索空间。

## 建立 Vocabulary Graph

在反复搜索之前，先为研究对象生成词汇网络：

- 官方/标准名称；
- 本地化名称；
- 别名/旧名称；
- 缩写；
- 罗马化/音译；
- 产品/版本/服务器/运营方名称；
- 事件/类别同义词；
- 地区名称；
- 历史术语；
- 实践者常用、但营销材料未必使用的邻近术语。

示例 Vocabulary Graph：

```text
canonical name / localized name / former name / romanization
collaboration / crossover / partnership / localized equivalents
```

把别名理解成图，而不是列表：运营方页面可能暴露一个本地产品名；本地产品名可能暴露旧 Campaign 名；旧 Campaign 名又可能把搜索带到历史归档。

## 查询族（Query Families）

按不同检索目的使用不同查询族：

1. **broad discovery** —— 学习词汇与候选宇宙；
2. **localized discovery** —— 找回地区特定材料；
3. **exact-phrase verification** —— 活动/产品/标题 + 日期/地区；
4. **domain-constrained search** —— owner/operator/docs/repo；
5. **source-family search** —— 论文、GitHub、Issues、论坛、Press Kit；
6. **historical search** —— 年份区间、旧名称、归档术语；
7. **asset search** —— KV、Press Kit、Campaign 图片、CDN、商店素材；
8. **negative/counterexample search** —— 主动搜索反对当前结论的证据；
9. **version/current-state search** —— Release Notes、Changelog、更新文档、当前可用状态。

选择真正能够回答当前 Research Map 问题的 Query Family。

## 查询结构

一个有效查询通常组合 2–4 个语义组件：

```text
[entity/alias] + [relationship/topic] + [region/version/year] + [source/asset term]
```

例如：

```text
"localized product name" collaboration 2019
site:official-domain.example exact event title
"workspace instruction file" official specification examples
"agent framework" evaluation failure prompt injection
```

早期 discovery 保持宽；当词汇和候选对象趋于稳定后，再逐步增加约束。

## 来源地图（Source Map）

把研究问题映射到不同来源族，而不是假设存在一个对所有问题通用的来源等级。

常见来源族：

- 所有者/发行商/开发者/运营方官网；
- 官方文档/规范/Changelog；
- 持续维护的仓库/Releases/Issues/Discussions；
- 原始学术论文/预印本/补充材料；
- 后续论文/复现/Benchmark；
- 新闻稿/Press Kit；
- 平台/商店页面；
- 监管机构/政府/统计机构；
- 可靠的专业媒体；
- 历史归档/缓存；
- 社区讨论、Reddit、论坛、实践者文章；
- 图片/CDN/素材归档。

## 来源族三角验证

有策略地利用不同来源族：

- **规范性事实** → 官方规范/文档；
- **真实实现** → 持续维护的代码/示例；
- **真实失败** → Issues/论坛/Postmortem；
- **历史状态** → 历史官方归档；
- **当前状态** → 当前文档/Release Notes/可用性页面；
- **认知/体验** → 用户/实践者证据；
- **视觉证据** → 原始/高质量素材。

三个来自同一来源族的页面，仍然只能提供狭窄视角。

## 本地语言充分性

多地区研究中，应使用能够实质提高召回率的语言。优先：

- 官方运营语言；
- 产品/IP 的本地化名称；
- 地区运营方使用的语言；
- 该市场主流专业/社区语言。

针对目标地区/运营方，只搜索那些能实质改善召回率的语言和本地化名称。

## 自适应搜索诊断

每完成一个有意义的搜索块，先诊断失败模式，再决定下一步搜索路径。

### 症状：大量重复结果，没有新候选
可能问题：查询词汇已经饱和。

下一步：
- 切换来源族；
- 切换地区/运营方；
- 按历史归档/年份切分；
- 搜索此前发现的精确标题；
- 停止没有信息增益的表面改写。

### 症状：某地区完全没有结果
可能问题：当地名称或运营方错误，而不是真正不存在。

下一步：
- 先确认地区产品/运营主体；
- 搜本地语言商店/社媒/运营方页面；
- 搜替代罗马化/本地化名称；
- 之后才能考虑 `NO_RESULT`。

### 症状：只有第三方报道
可能问题：第一方来源隐藏、失效或索引很差。

下一步：
- 从报道中抽取精确活动/产品/标题/日期；
- 用精确短语搜索 owner/operator 域名；
- 搜官方社媒/Press Archive；
- 尝试 Archive/Cache；
- 第三方页面只保留为 discovery 或 fallback evidence。

### 症状：官方页面彼此冲突
用精确活动名、生命周期术语、地区/服务与来源族特定查询拆解日期冲突。

下一步：
- 拆分语义：announcement/start/end/rerun；
- 拆分 region/platform/service；
- 比较页面发布时间/更新时间；
- 检查时区/本地化；
- 搜更精确的地区运营方来源。

### 症状：技术主题被旧资料主导
可能问题：时效性/版本错位。

下一步：
- 当前官方文档；
- Changelog/Release Notes；
- 持续维护仓库中的当前示例；
- Deprecated/Removed 术语；
- 当前实践者报告。

### 症状：找到视觉页面，但图片质量不足
下一步：
- 检查 Press Kit/Media Kit；
- 跟随 CDN/源图引用；
- 查官方社媒原始帖；
- 查商店/更新素材；
- 查归档页面中的素材。

## 查询扩展循环

```text
Result
→ 判断真正新增了什么
→ alias/operator/year/source family/candidate/conflict
→ 更新 Research Map
→ 根据诊断选择下一类搜索路径
```

只有新信息可能实质改变覆盖率、验证结果或综合结论时，才继续扩展查询。
