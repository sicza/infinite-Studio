# 研究产物协议（Artifact Research Protocol）

用于长期维护的 HTML/XLSX/Structured Markdown Dataset、Research Archive，或未来需要重新生成/持续更新的研究产物。

## 1. 保持唯一事实源

维护一个 Research Dataset，承载 Artifact 所需的事实、案例、Claim 与 Asset。

HTML、XLSX、Presentation Table、Chart 和 Report View 都只消费这个 Dataset。Primary 研究 request 的 HTML 统一由 `$wxian-html-delivery` 生成；页面不得在 Dataset 外新增事实或结论。

## 2. 验证 Dataset Candidate

检查：

- 必要时存在稳定 ID/Key；
- Duplicate Case；
- Region Include/Exclude 一致性；
- Date Semantics；
- Decision-critical Fact 的 Evidence Link；
- 适用时的 Visual Asset Binding/Lineage；
- Unknown/Conflict Representation；
- Aggregate Count 与底层 Record 一致。

## 3. 冻结 Snapshot

```text
Dataset Candidate vN
→ Dataset Validation
→ Freeze Snapshot vN
→ Generate Outputs from vN
```

Frozen Snapshot 不可变。

## 4. 输出一致性检查

每个 Output 都必须可追溯到它所消费的 Frozen Dataset Version。

检查：

- Intended Scope 已完整进入 Output；
- Count 与 Dataset 一致；
- Date、Region、Classification 未被展示层改写；
- Unknown 与 Limitation 仍然可见；
- Visual Asset 绑定到正确 Record/Campaign；
- Featured Example 符合声明的 Selection Logic。

## 5. 失败处理

### 仅视图层失败

```text
same frozen dataset vN
→ regenerate or repair view
→ rerun output consistency check
```

### 底层数据失败

```text
keep frozen vN unchanged
→ create dataset candidate vN+1
→ repair source data
→ invalidate dependent analysis/statistics
→ validate dataset candidate
→ freeze vN+1
→ regenerate outputs
```

## 6. 依赖失效传播

```text
fact / date / region / classification / asset lineage / evidence strength changes
→ observation
→ pattern
→ implication
→ recommendation
→ statistics / featured selections / views
```

重新计算前，先把依赖对象标记为 Stale。

## 7. Artifact 交付

满足以下条件后发布：

- 底层 Research Release State 对用户目标可接受；
- Output Consistency Check 已通过 Frozen Snapshot 校验。

如果底层研究是 `PARTIAL_WITH_LIMITATIONS`，在 Artifact 中同样显式保留该状态。

HTML 必须为离线单文件并内嵌全部展示图片。实际生成的示意图同时保留在 `work/final/originals/`，绑定各自完整 Prompt 与调用回执；网页截图、竞品图和档案证据保持 `evidence` 身份及来源，不进入生成原图目录。
