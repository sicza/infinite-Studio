# 搜索与验证

## 核心区分

**Discovery** 负责发现可能的答案；**Verification** 决定哪些内容可以作为事实陈述。两者是概念阶段，不要求必须由不同 Agent 执行。

同一个 Research Shard 可以同时完成两者，但必须保持状态边界：

```text
LEAD / CANDIDATE
→ 获取证据
→ 对陈述进行验证
→ FACT | UNKNOWN | CONFLICT
```

## Discovery：最大化有效召回

Discovery 不只是找页面，还要主动发现：

- 候选对象/案例；
- 精确名称/标题；
- 别名/本地化名称；
- 运营方/所有者；
- 年份/时间窗口；
- 来源族；
- 视觉素材；
- 版本术语；
- 冲突证据；
- 初始 Research Map 中的缺口。

第三方来源、搜索结果、社区帖子、索引、数据库、推荐清单都可以用于 discovery；只有获得匹配证据后，相关陈述才能升级为事实。

## Verification：证明真正重要的陈述

对每个 decision-critical lead，逐步逼近最有能力证明这个**具体陈述**的来源。

典型路径：

```text
lead
→ owner / maintainer / operator / original paper
→ 精确页面/文档/release/event post
→ 相关段落/日期/版本/素材
→ fact + evidence note + confidence
```

验证发生在 statement level，而不是 page level。一个页面可能对某条事实构成强证据，对另一条事实却只能构成弱证据。

## 决策关键事实验证

如果某个事实发生变化会改变以下任一结果，它就是 decision-critical：

- inclusion/exclusion；
- 案例数量；
- 日期/地区/版本；
- 竞品分类；
- 当前适用性；
- 视觉结论；
- Pattern；
- Recommendation。

Decision-critical fact 必须有明确 source + evidence note。若该事实来自 Shard，Main Agent 必须检查其证据，或触发第二次验证。

## 证据 Sufficiency Questions

把一个事实标记为 verified 前，回答：

1. 这个来源是否针对同一个 subject/version/region？
2. 它是否真的支持这个语义明确的陈述？
3. 对这个陈述而言，证据是否足够新？
4. 推断距离是否足够短，并且被明确说明？
5. 因为该事实存在争议或影响很大，是否需要另一条独立来源？

按证据匹配度与独立性判断充分性：一条精确的一手来源可能已经足够；五篇转载仍可能只有一个证据源头。

## 搜索摘要

搜索引擎摘要只用于 discovery，除非已经打开并检查底层来源。摘要可能过期、截断、自动生成，或脱离页面上下文。

## 来源降级路径（Source Fallback）

理想来源不可用时，降低置信度，而不是静默用次级来源替代确定性。

典型 fallback：

```text
精确一手来源
→ 第一方归档 / 持续维护来源
→ 第一方社媒 / Press Release / Release Notes
→ Web Archive / Cache
→ 可靠专业来源
→ 社区/二手线索
```

Fallback 顺序依赖具体 claim。对“用户体验问题”，社区来源可能比新闻稿更有效；对“官方是否上线”，它则更弱。

## 搜索诊断 → 下一步动作

### 结果反复重复，没有新增信息
等价查询已经饱和时，改变信息结构：
- 来源族；
- 语言；
- 地区/运营方；
- 时间段；
- 精确标题；
- Archive；
- 邻近术语。

### 已找到 Candidate，但缺少精确事实
围绕缺失事实搜索，而不是继续搜索整个主题：
- 精确活动标题 + 日期；
- 运营方 + Campaign；
- 版本 + 行为；
- Release Notes + 改动功能；
- 论文标题 + Supplement/Appendix。

### 第一方页面失效
恢复证据来源链：
- 官方 Archive/Index；
- owner/operator 社媒；
- Press Release；
- Web Archive/Cache；
- 精确页面标题搜索；
- 能保留缺失细节的可靠二手来源。

最强可用证据仍不足时，把事实保持为 partial/unknown。

### 搜索被 SEO 摘要主导
转向 primary/normative/implementation 来源：
- 官方文档；
- 原作者/维护者；
- GitHub 源码/Issues；
- 原始论文；
- 监管/财报；
- 精确活动/运营方页面。

### 当前结论只找到旧证据
使用 `freshness-and-current-state.md`；搜索当前文档、Release Notes、近期可用性、所有权状态和明确的 Deprecation。

## 冲突

可靠来源发生冲突时：

1. 检查它们是否指向不同地区/平台/版本；
2. 拆开时间语义：announcement/start/rerun/end；
3. 检查发布时间/更新时间；
4. 检查某个来源是否只是引用另一个来源；
5. 优先选择与 claim 更匹配、距离底层事件/系统更近的证据；
6. 仍然无法解决时，明确保留冲突。

通过来源匹配度、时间语义、范围和独立性解决冲突，而不是选择“故事更顺”的版本。

## 验证停止条件

当新增来源已经不太可能改变这个事实对用户决策的状态时，可以停止验证。以下情况继续：

- 证据间接；
- 来源冲突；
- 事实影响重大；
- Claim 属于当前/可变化状态；
- 来源可能过期；
- 精确范围/语义仍不清楚。
