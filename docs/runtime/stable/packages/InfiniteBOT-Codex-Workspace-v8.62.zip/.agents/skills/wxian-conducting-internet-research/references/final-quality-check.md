# 最终质量检查

## 覆盖范围

1. 检查 Research Map 要求的别名、语言、地区、来源族、时间段、运营方、版本和媒介类型。
2. 确认每个 REQUIRED 研究问题都进入最终综合。
3. 区分“同源重复导致的结果饱和”和“真正完成覆盖”。
4. 当前状态研究中，确认最新证据确实是当前有效且适配目标版本。

## 证据

5. 找出最薄弱的 decision-critical fact，确认它的证据是否足够。
6. 把转载与 Syndicated Copies 归并到共同源头。
7. 搜索摘要、首页、榜单和社区帖只能承担其真实证据角色。
8. 明确保留可信冲突。
9. 把限定范围的“未发现”与“不存在”Claim 分开。

## 一致性

10. 解决不同地区/本地化名称下的重复案例。
11. 区分 announcement、start、rerun、end 和 regional release 日期。
12. 严格执行市场 include/exclude 语义。
13. 区分 product、service、wave、campaign component 和 asset 单元。
14. 把每个视觉素材绑定到正确 Campaign/版本/地区。
15. 同一母创意的裁切/本地化版本默认只算一个独立创意样本，除非 Adaptation 存在实质性差异。

## 综合分析

16. 确认 Pattern 的强度与独立样本数量相匹配。
17. 检查来源、Publisher、地区、时期、语言与选择偏差。
18. 纳入重要 Outlier 与 Counterevidence。
19. 区分相关/共现与因果关系。
20. 把案例转化为可迁移机制，而不是表面模仿。
21. Recommendation Confidence 不得高于上游证据/分析置信度。
22. 确保答案真正缩小用户的决策空间。

## 独立复核

对 Exhaustive 或高风险研究，有条件时使用 Fresh-context Reviewer。否则由 Main Agent 执行同一套检查，并在缺少独立复核会实质影响完整性或置信度时说明限制。

## 上游变化后重新计算

```text
fact / region / time / classification / asset lineage / evidence / sample membership 发生变化
→ 依赖的 observation / pattern / implication / recommendation / statistic = STALE
→ 重新计算
→ 重新执行受影响的质量检查
```
