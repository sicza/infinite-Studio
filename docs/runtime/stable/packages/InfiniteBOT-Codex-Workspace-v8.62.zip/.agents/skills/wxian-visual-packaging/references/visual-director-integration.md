# Visual Director Integration for Packaging

`wxian-visual-packaging` 拥有商业命题、包装主轴、模块策略、方向池、推荐与 Production Brief。`sicza-visual-director` 只深化已成立方向，不拥有第二方向 Authority 或发布状态。

## Direction → Canonical Visual Spec

每个进入生产验证的方向先锁：

`主承诺 → 项目证明 → 第一读 → 决定性关系/展示机制 → 记忆锚点 → 模块转译`

需要真正落到视觉执行时统一写当前 request 的 `work/visual-spec.json`，Schema 为 `.agents/skills/workspace-governance/config/visual-contracts/visual-spec-schema.json`。不在 Packaging 内维护第二套 Visual Spec。

常见模块：

- KV：`CREATE`；
- ICON：`R-SHAPE / I-* / H-MULTISCALE / D-SIGN / D-MEM`；
- LOGO：`G-TYPE / G-LAYOUT / G-BRAND / D-SIGN / D-MEM`；最终矢量字形仍不交给生成模型做 Authority；
- Store：单张 `CREATE`，整套 `SERIES`。

## Packaging Authority Guard

Visual Director 不得：

- 改写商业卖点或虚构玩法；
- 把竞品表层转成项目事实；
- 用“更酷”推翻已批准主轴；
- 把不同载体的阅读距离和任务做成同一构图复制；
- 产出第二套方向评分体系。

## Hard Gate → Scorecard

视觉域先输出符合 `.agents/skills/workspace-governance/config/visual-contracts/visual-gate-result-schema.json` 的证据。存在 `VISUAL_BLOCK / NEED_UPSTREAM / NEED_DOMAIN` 时不得进入高分比较；通过后再由 `$wxian-visual-scorecard` 数值比较。
