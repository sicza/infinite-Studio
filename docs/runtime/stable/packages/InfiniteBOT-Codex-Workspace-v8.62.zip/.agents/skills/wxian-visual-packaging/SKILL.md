---
name: wxian-visual-packaging
description: 为 LOGO、App ICON、KV 主视觉和 App Store/Google Play 商店图建立项目专属包装主轴、独立方向池、证据化筛选与可执行 Production Brief。用于视觉包装策划、品牌升级、KV/Store 方向探索或跨模块统一；普通单次生图不调用。
---

# 视觉包装

进入前执行 `$workspace-governance consume-personal-context --request <request> --consumer wxian-visual-packaging`；阻断则停止。


新建用户需求先由 `$workspace-demand-intake` 按本类型最小 Contract 收集并锁定输入；本 Skill 不重复追问 Intake 已知字段，也不把自身专业判断转嫁给用户。
开始或继续本 Skill 前必须通过 **Project Visual Baseline freshness preflight**；`$workspace-governance` 会在 request 新建、续接、返修和 Promote 时执行 `workspace_init.py visual-check`。这个 CLI 只检查正式 Baseline 是否与当前视觉输入/项目事实同步，不代表完整 per-request Visual Production Gate；若返回 `needs_visual_baseline`，先刷新 Baseline，不得继续消费旧规则。

把商业目标转成项目专属、彼此独立且可制作验证的视觉方向；方向差异必须来自核心创意结构。

商业命题与模块 Authority 仍由本 Skill 决定；每个候选方向在进入 Prompt/验证前，读取 `references/visual-director-integration.md`，用 `$sicza-visual-director` 把方向转成结构化 Visual Spec，并用其 Integrity/Delivery Gates 检查空间、表演、投影、光材质、感知、身份与图形传播。Visual Director 不负责替本 Skill 发明商业卖点、模块策略或品牌命题。

## 输入与读取

只读取会改变当前包装判断的内容：当前 `request.md/input/`、项目资料、正式 Baseline 的 `index.json` 与必要章节、用户指定 Reference。关键图片必须实际查看。

正式 Baseline 存在时：

1. 先读 `project/baselines/index.json`，再读 Baseline 的项目视觉画像、当前产出图谱、Baseline Floor 与创新空间；
2. 已有 Family 只是高概率起点，不是方向白名单；当前命题需要更好解时可以走 `novel-direction`；
3. 只记录本次真实使用的 Family / Floor / Character / Reference 与覆盖项到 `work/baseline-consumption.json`；本 Skill 的 Baseline machine key 固定为 `visual-packaging`（`"consumer": "visual-packaging"`、`--consumer-name visual-packaging`），不得写 Skill 名。按 `$wxian-visual-baselines` 验证。

中间专业事实写入 `work/visual-packaging/`；最终可交付文件写 `work/final/`。

## 1. 锁定包装问题

生成 `packaging-brief.md`，只保留会改变设计的事实：模块范围、商业目标、受众/渠道/地区、真实规格和文案、项目识别锚点、真实卖点、必须素材、Reference 职责、保持项、禁止项、未知。

核心事实冲突或缺失到无法确定主承诺时才 BLOCKED；其余未知采用保守假设并显式标注。

## 2. 建立共享主轴

读取 [direction-and-reference-reasoning.md](references/direction-and-reference-reasoning.md)，得到唯一 `packaging-axis.md`：

```text
商业目标/受众欲望
→ 一个主承诺
→ 项目自己的证明
→ 第一视觉认知
→ 图形母题与力量关系
→ 轮廓 / 色彩角色 / 材质 / 光向 / 字体行为 / 空间动势
→ 各载体如何转译
```

KV 可以承担视觉母版，但 LOGO、ICON、Store 只能继承识别基因，不能机械复制构图。遮住项目名后仍像任意同类产品，主轴不成立。

## 3. Reference 只提取机制

对真正采用的 Reference，只记录：第一眼机制、抽象机制、解决本项目哪个问题、如何用本项目资产重建、主动舍弃什么、具体改变了哪个决定。没有改变决定的 Reference 不进入工作集。

不得继承竞品角色、装备、UI、剧情、品牌符号或表层题材。

## 4. 方向池

读取 [module-methods.md](references/module-methods.md)；KV 额外读取 [kv-method.md](references/kv-method.md)。

**包装策划默认 LOGO / ICON / KV 各 10 个独立方向；Store 对每个已证实主卖点默认 10 个方向。** 用户指定数量时遵从。这个数量只属于本 Skill，普通图片制作不得因此自动进入 10 方向探索。

先发散多于目标数量的核心主张，再淘汰同构和不可制作项。每个保留方向必须至少说明：

- 一句话核心主张与商业任务；
- 第一眼主体关系/决定性瞬间/展示机制；
- 项目识别锚点和记忆机制；
- 构图、色彩、材质、字体、光向的关键决定；
- Reference 继承与舍弃；
- 制作路径、Prompt 边界、后处理依赖、风险；
- 它继承的 Baseline Family / 必须满足的 Floor，或当前事实来源；若为新方向，说明为何现有 Family 不足。

只换地点、天气、镜头、颜色、材质、装饰不算新方向。

模块专业门禁以 references 为准，关键红线：

- **LOGO**：先字形骨架/黑白结构，再材质；小尺寸仍可读；正式旧 LOGO 不交模型重画。
- **ICON**：一个第一主体或极清楚主次；约 60px 仍可辨认；不能是 KV 硬裁或随机 AI 头像。
- **KV**：两股力量争夺明确，主角不可逆动作改变平衡，画面有可见因果证据；任意两方向在核心剧情、冲突机制、主角动作、角色关系、瞬间类型、记忆机制中三项高度相同即同构。
- **Store**：每张只证明一个真实卖点；图序有钩子→玩法/成长/社交/奖励等递进；不得虚构玩法。

## 5. 比较与推荐

需要正式评分、跨候选排序或红线/封顶判断时调用 `$wxian-visual-scorecard`；本 Skill 不再维护第二套重复评分卡。

先淘汰红线和同构，再推荐真正通过者。源能力的默认目标仍是每模块前 5；不足 5 个不凑数。每个推荐写清：为何最能证明目标、与其他方向的本质差异、主要风险、需要验证的问题、仍可调整边界。

## 6. 生成验证

方向池的数量不等于生图数量。根据不确定性选择足以证明推荐关系的方向形成完整 Prompt，写入 `work/generation-plan.json` 后直接交 `$image-generation-api`；实际生成的每张原图保存到 `work/final/originals/`，并保留与 Prompt Hash 一一绑定的调用回执。用户指定全部方向出图时全部执行；未指定时优先验证主推方向和会改变决策的关键备选，不为填满 10 个方向制造重复图片。

验证图必须实际查看：

- 方向成立、模型局部失败 → 最多针对性重试 1 次；同类失败再次出现且没有新证据时停止该方向，不继续调用模型；
- Prompt 漏掉已成立关系 → 回 Prompt；
- 中心事件/主张/项目事实错误 → 回方向或主轴；
- 真实尺寸失败 → 回模块结构。

验证图只证明方向，不自动成为商业成品。

## 7. Production Brief 与交付

读取 [review-and-delivery.md](references/review-and-delivery.md)。生成真正需要的最终文件：

```text
work/final/packaging-proposal.md
work/final/packaging-prompts.md        # 仅有模型制作任务时
work/final/production-brief.md         # 用户确认方向或明确授权自动选择后
```

Production Brief 必须让下一位制作人员无需重新决定核心概念：最终方向、决定性画面/结构、项目资产、Reference 职责、规格、准确文案、多语言/安全区、真实 LOGO/ICON 保护、KV 裁切、Store 图序、后处理依赖、禁止项、验收标准，以及本次真正应用的 Baseline Floor / Family，或新方向相对既有先验的突破点。

读取 [html-report.md](references/html-report.md) 并调用 `$wxian-html-delivery`，从已闭合 Proposal、真实验证图与逐图完整 Prompt 渲染单文件 `work/final/visual-packaging.html`。每张生成验证图必须以图片标题绑定生成它的完整 Prompt，二者在同一卡片内展示、可展开和复制；每张图使用唯一 Prompt 路径和唯一 Prompt 内容，不得用摘要、关键词、“同上”、复制 Prompt 文件或跨图复用 Prompt 代替。HTML 不创建新方向、不把 Markdown 套皮冒充设计。

交付接入：必须调用 `$wxian-html-delivery`，并由 `$workspace-governance promote` 验证。

实际检查最终文件后写最小 `work/final-review.md` 与 `work/delivery-manifest.json`。默认 active 外部交付为 `interactive_html` 与全部 `generated_original`；其他 Markdown/JSON 保留为内部权威文件。由 `$workspace-governance promote` 发布并立即完成。用户评分与偏好由 `$workspace-user-feedback` 在 Promote 后登记和处理，不是完成门禁。

## 反馈与并行

返修按：`症状 → 根因 → 影响范围(local|stage|system) → patch|regenerate|rewrite`。每轮必须记录新的证据或改变被证伪的假设；结构、主轴、角色关系、信息层级的首次同类失败回到最早错误阶段重写，第二次仍无进展则阻断并返回缺失条件，不继续扩大回退范围。

子 Agent 只用于互不依赖的模块/候选研究、固定输入的 Reference 分析或独立评分；主 Agent 统一主轴、同构判断、最终推荐和跨模块一致性。
