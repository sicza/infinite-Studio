#!/usr/bin/env python3
"""Build and validate self-contained interactive HTML reports."""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import mimetypes
import os
import re
import sys
import tempfile
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

LIB = Path(__file__).resolve().parents[3] / "lib"
if str(LIB) not in sys.path:
    sys.path.insert(0, str(LIB))
from atomic_io import atomic_write_text

SCHEMA = "wxian.html-delivery.v1"
REPORT_TYPES = {
    "game-concept-lab",
    "visual-packaging",
    "visual-competitive-analysis",
    "internet-research",
}
PRIMARY_REPORT_TYPES = {
    "sicza-game-concept-lab": "game-concept-lab",
    "wxian-visual-packaging": "visual-packaging",
    "wxian-visual-competitive-analysis": "visual-competitive-analysis",
    "wxian-conducting-internet-research": "internet-research",
}
DIRECT_IMAGE_CALLERS = {
    "sicza-game-concept-lab": "concept-generation",
    "wxian-visual-packaging": "packaging-validation",
    "wxian-visual-competitive-analysis": "competitive-visualization",
    "wxian-conducting-internet-research": "research-visualization",
}
GENERATION_CALL_SCHEMA = "wxian.generation-call.v3"
SERVICE_REQUEST_ID_STATUSES = {"provided", "provider_not_supplied"}
GENERATION_EXECUTOR = ".agents/skills/image-generation-api/scripts/generation_api.py"
LAYOUTS = {"feature", "gallery", "comparison", "matrix", "narrative", "sources"}
RECOMMENDATIONS = {"primary", "alternate", "evidence", "neutral"}
ORIGINS = {"generated", "evidence"}
HEX = re.compile(r"^#[0-9a-fA-F]{6}$")
ID = re.compile(r"^[a-z0-9][a-z0-9_-]{0,63}$")
OBVIOUS_EXTERNAL_COPY = (
    "作为一个ai", "希望这对你有帮助", "希望这对您有帮助", "以下是为你",
    "以下是为您", "根据我最后的训练", "仅供参考，请自行判断", "仅供参考",
    "需要注意的是", "值得注意的是", "总而言之", "综上所述", "毋庸置疑",
    "可以看出", "从某种意义上说", "在当今这个", "赋能", "全面提升",
)


class HtmlDeliveryError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise HtmlDeliveryError(message)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def contrast_ratio(first: str, second: str) -> float:
    def luminance(value: str) -> float:
        channels = [int(value[index:index + 2], 16) / 255 for index in (1, 3, 5)]
        linear = [channel / 12.92 if channel <= .04045 else ((channel + .055) / 1.055) ** 2.4
                  for channel in channels]
        return .2126 * linear[0] + .7152 * linear[1] + .0722 * linear[2]
    low, high = sorted((luminance(first), luminance(second)))
    return (high + .05) / (low + .05)


def load_json(path: Path, label: str) -> dict[str, Any]:
    require(path.is_file(), f"{label} is missing: {path}")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise HtmlDeliveryError(f"{label} is invalid UTF-8 JSON: {exc}") from exc
    require(isinstance(value, dict), f"{label} must be an object")
    return value


def bounded(root: Path, value: str, *, exist: bool = True) -> Path:
    require(isinstance(value, str) and value.strip(), "path must be a non-empty string")
    candidate = Path(value.strip())
    require(not candidate.is_absolute(), "paths must be Workspace-relative")
    target = (root / candidate).resolve()
    try:
        target.relative_to(root.resolve())
    except ValueError as exc:
        raise HtmlDeliveryError(f"path escapes Workspace: {value}") from exc
    if exist:
        require(target.is_file(), f"file is missing: {value}")
    return target


def find_request(path: Path, root: Path) -> Path:
    requests = (root / "requests").resolve()
    for parent in [path.resolve(), *path.resolve().parents]:
        try:
            rel = parent.relative_to(requests)
        except ValueError:
            continue
        if len(rel.parts) == 2:
            return parent
    raise HtmlDeliveryError("manifest must be inside requests/<type>/<request>/")


def text_values(report: dict[str, Any]) -> list[str]:
    values = [report.get("title", ""), report.get("summary", ""), report.get("project_name", "")]
    visual = report.get("visual_system", {})
    values.extend([visual.get("theme_name", ""), visual.get("rationale", "")])
    for section in report.get("sections", []):
        values.extend([section.get("title", ""), section.get("lead", "")])
        for item in section.get("items", []):
            values.extend([item.get("title", ""), item.get("summary", "")])
            values.extend(item.get("body", []))
    for media in report.get("media", []):
        values.extend([media.get("title", ""), media.get("alt", ""), media.get("caption", "")])
    return [str(value) for value in values if value]


def validate_report(root: Path, manifest_path: Path) -> tuple[dict[str, Any], Path, list[dict[str, Any]]]:
    report = load_json(manifest_path, "HTML report manifest")
    request = find_request(manifest_path, root)
    state = load_json(request / "state.json", "request state")
    primary = str(state.get("primary_skill", "")).strip()
    require(primary in PRIMARY_REPORT_TYPES, "request primary_skill is not eligible for HTML delivery")
    require(report.get("schema_version") == SCHEMA, "HTML report schema_version mismatch")
    require(report.get("report_type") in REPORT_TYPES, "unsupported report_type")
    require(report.get("report_type") == PRIMARY_REPORT_TYPES[primary],
            f"report_type does not match request primary_skill={primary}")
    for field in ("title", "summary"):
        require(isinstance(report.get(field), str) and report[field].strip(), f"{field} is required")
    visual = report.get("visual_system")
    require(isinstance(visual, dict), "visual_system must be an object")
    for field in ("theme_name", "rationale", "canvas", "surface", "ink", "muted", "accent", "accent_alt"):
        require(isinstance(visual.get(field), str) and visual[field].strip(), f"visual_system.{field} is required")
    for field in ("canvas", "canvas_alt", "surface", "ink", "muted", "accent", "accent_alt", "line"):
        if field in visual:
            require(bool(HEX.fullmatch(visual[field])), f"visual_system.{field} must be #RRGGBB")
    readable_pairs = tuple(
        (background, foreground)
        for background in ("canvas", "canvas_alt", "surface")
        for foreground in ("ink", "muted", "accent_alt")
    ) + (("accent", "canvas"),)
    for background, foreground in readable_pairs:
        background_value = visual.get(background, "#141a22" if background == "canvas_alt" else None)
        foreground_value = visual.get(foreground)
        require(contrast_ratio(background_value, foreground_value) >= 4.5,
                f"visual_system contrast is below 4.5:1 for {foreground} on {background}")
    require(visual.get("density", "balanced") in {"airy", "balanced", "dense"}, "invalid visual_system.density")
    require(visual.get("shape", "measured") in {"sharp", "measured", "soft"}, "invalid visual_system.shape")

    sections = report.get("sections")
    require(isinstance(sections, list) and sections, "sections must be a non-empty array")
    section_ids: set[str] = set()
    referenced_media: set[str] = set()
    for sidx, section in enumerate(sections):
        require(isinstance(section, dict), f"sections[{sidx}] must be an object")
        sid = section.get("id")
        require(isinstance(sid, str) and ID.fullmatch(sid) and sid not in section_ids,
                f"sections[{sidx}].id must be unique lowercase slug")
        section_ids.add(sid)
        require(isinstance(section.get("title"), str) and section["title"].strip(), f"sections[{sidx}].title is required")
        require(section.get("layout") in LAYOUTS, f"sections[{sidx}].layout is invalid")
        items = section.get("items")
        require(isinstance(items, list) and items, f"sections[{sidx}].items must be non-empty")
        if section.get("layout") == "matrix":
            require(len(items) >= 2, f"matrix section {sid} must compare at least two candidates")
        item_ids: set[str] = set()
        for iidx, item in enumerate(items):
            require(isinstance(item, dict), f"sections[{sidx}].items[{iidx}] must be an object")
            iid = item.get("id")
            require(isinstance(iid, str) and ID.fullmatch(iid) and iid not in item_ids,
                    f"item id must be unique in section: {iid!r}")
            item_ids.add(iid)
            require(isinstance(item.get("title"), str) and item["title"].strip(), f"item {iid} title is required")
            require(isinstance(item.get("summary"), str) and item["summary"].strip(), f"item {iid} summary is required")
            require(item.get("recommendation", "neutral") in RECOMMENDATIONS, f"item {iid} recommendation is invalid")
            require(isinstance(item.get("body", []), list) and all(isinstance(x, str) for x in item.get("body", [])),
                    f"item {iid} body must be a string array")
            require(isinstance(item.get("media_ids", []), list), f"item {iid} media_ids must be an array")
            require(isinstance(item.get("tags", []), list) and all(isinstance(x, str) for x in item.get("tags", [])),
                    f"item {iid} tags must be a string array")
            if item.get("source_url"):
                parsed = urlparse(str(item["source_url"]))
                require(parsed.scheme == "https" and bool(parsed.netloc), f"item {iid} source_url must be HTTPS")
            referenced_media.update(str(x) for x in item.get("media_ids", []))

    media = report.get("media", [])
    require(isinstance(media, list), "media must be an array")
    media_ids: set[str] = set()
    media_paths: set[str] = set()
    generated_prompt_paths: set[str] = set()
    generated_prompt_hashes: set[str] = set()
    hydrated: list[dict[str, Any]] = []
    originals = (request / "work" / "final" / "originals").resolve()
    for index, item in enumerate(media):
        require(isinstance(item, dict), f"media[{index}] must be an object")
        mid = item.get("id")
        require(isinstance(mid, str) and ID.fullmatch(mid) and mid not in media_ids, f"media[{index}].id is invalid or duplicate")
        media_ids.add(mid)
        require(item.get("origin") in ORIGINS, f"media {mid} origin is invalid")
        for field in ("source", "title", "alt", "caption"):
            require(isinstance(item.get(field), str) and item[field].strip(), f"media {mid}.{field} is required")
        require(isinstance(item.get("tags", []), list) and all(isinstance(x, str) for x in item.get("tags", [])),
                f"media {mid}.tags must be a string array")
        if item.get("source_url"):
            parsed = urlparse(str(item["source_url"]))
            require(parsed.scheme == "https" and bool(parsed.netloc), f"media {mid} source_url must be HTTPS")
        require(item["source"] not in media_paths, f"duplicate media source: {item['source']}")
        media_paths.add(item["source"])
        source = bounded(root, item["source"])
        require(source.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp", ".gif"}, f"unsupported media type: {item['source']}")
        prompt = None
        prompt_path_value = item.get("prompt_path")
        if item["origin"] == "generated":
            try:
                source.relative_to(originals)
            except ValueError as exc:
                raise HtmlDeliveryError(f"generated media must be in request work/final/originals: {item['source']}") from exc
            require(isinstance(prompt_path_value, str) and prompt_path_value.strip(), f"generated media {mid} requires prompt_path")
            prompt_path = bounded(root, prompt_path_value)
            prompt = prompt_path.read_text(encoding="utf-8")
            require(prompt.strip(), f"generated media {mid} prompt is empty")
            prompt_rel = prompt_path.relative_to(root).as_posix()
            prompt_hash = sha256_file(prompt_path)
            require(prompt_rel not in generated_prompt_paths,
                    f"generated media {mid} reuses another image Prompt path: {prompt_rel}")
            require(prompt_hash not in generated_prompt_hashes,
                    f"generated media {mid} reuses another image Prompt content")
            generated_prompt_paths.add(prompt_rel)
            generated_prompt_hashes.add(prompt_hash)
            call_path = source.with_name(source.name + ".call.json")
            call = load_json(call_path, f"generation call for {mid}")
            require(call.get("schema_version") == GENERATION_CALL_SCHEMA,
                    f"generated media {mid} call receipt schema mismatch")
            require(call.get("status") == "success", f"generated media {mid} call status is not success")
            require(call.get("network_called") is True, f"generated media {mid} lacks a completed network call")
            require(isinstance(call.get("http_status"), int) and 200 <= call["http_status"] < 300,
                    f"generated media {mid} lacks a successful HTTP response")
            service_request_id_status = call.get("service_request_id_status")
            require(service_request_id_status in SERVICE_REQUEST_ID_STATUSES,
                    f"generated media {mid} service request id status is invalid")
            if service_request_id_status == "provided":
                require(isinstance(call.get("service_request_id"), str) and call["service_request_id"].strip(),
                        f"generated media {mid} lacks a declared service request id")
                require(isinstance(call.get("service_request_id_source"), str) and call["service_request_id_source"].strip(),
                        f"generated media {mid} lacks a service request id source")
            else:
                require(call.get("service_request_id") is None and call.get("service_request_id_source") is None,
                        f"generated media {mid} claims provider_not_supplied with a service request id")
            for field in ("request_payload_sha256", "response_sha256"):
                require(isinstance(call.get(field), str) and re.fullmatch(r"[0-9a-f]{64}", call[field]),
                        f"generated media {mid} {field} is invalid")
            executor = call.get("executor_binding")
            require(isinstance(executor, dict) and set(executor) == {"path", "sha256"},
                    f"generated media {mid} executor binding is invalid")
            require(executor.get("path") == GENERATION_EXECUTOR,
                    f"generated media {mid} executor path mismatch")
            executor_path = bounded(root, GENERATION_EXECUTOR)
            require(executor.get("sha256") == sha256_file(executor_path),
                    f"generated media {mid} executor hash mismatch")
            require(call.get("api_profile") in {"gemini", "gpt"}, f"generated media {mid} API profile is invalid")
            require(call.get("mode") in {"text_to_image", "reference_to_image", "image_to_image_edit"},
                    f"generated media {mid} mode is invalid")
            require(isinstance(call.get("model"), str) and call["model"].strip(),
                    f"generated media {mid} model is missing")
            require(isinstance(call.get("parameters"), dict), f"generated media {mid} parameters are missing")
            require(call.get("output_path") == source.relative_to(root).as_posix(), f"generated media {mid} output_path mismatch")
            require(call.get("output_sha256") == sha256_file(source), f"generated media {mid} output hash mismatch")
            require(call.get("prompt_path") == prompt_rel, f"generated media {mid} prompt_path mismatch")
            require(call.get("prompt_source_sha256") == prompt_hash, f"generated media {mid} prompt source hash mismatch")
            require(call.get("prompt_sha256") == prompt_hash, f"generated media {mid} prompt hash mismatch")
            binding = call.get("generation_plan_binding")
            require(isinstance(binding, dict), f"generated media {mid} lacks generation plan binding")
            require(binding.get("primary_skill") == primary,
                    f"generated media {mid} generation plan primary_skill mismatch")
            require(binding.get("execution_class") == DIRECT_IMAGE_CALLERS[primary],
                    f"generated media {mid} generation execution class mismatch")
            plan_path = bounded(root, str(binding.get("path", "")))
            require(binding.get("sha256") == sha256_file(plan_path),
                    f"generated media {mid} generation plan hash mismatch")
            plan = load_json(plan_path, f"generation plan for {mid}")
            require(set(plan) == {"schema_version", "primary_skill", "status", "items"},
                    f"generated media {mid} generation plan fields are invalid")
            require(plan.get("schema_version") == "wxian.generation-plan.v1" and plan.get("status") == "READY",
                    f"generated media {mid} generation plan is not READY")
            require(plan.get("primary_skill") == primary, f"generated media {mid} plan primary_skill mismatch")
            items = plan.get("items")
            require(isinstance(items, list), f"generated media {mid} generation plan items are invalid")
            matches = [entry for entry in items if isinstance(entry, dict) and entry.get("id") == binding.get("item_id")]
            require(len(matches) == 1, f"generated media {mid} generation plan item binding is not unique")
            plan_item = matches[0]
            require(plan_item.get("status") == "READY", f"generated media {mid} generation plan item is not READY")
            for key, expected in {
                "api_profile": call.get("api_profile"), "mode": call.get("mode"), "model": call.get("model"),
                "prompt_path": call.get("prompt_path"), "prompt_sha256": call.get("prompt_sha256"),
                "output_path": call.get("output_path"), "parameters": call.get("parameters"),
            }.items():
                require(plan_item.get(key) == expected, f"generated media {mid} plan/call mismatch: {key}")
        else:
            require(not prompt_path_value, f"evidence media {mid} must not claim a generation Prompt")
        mime = mimetypes.guess_type(source.name)[0] or "application/octet-stream"
        hydrated.append({
            **item,
            "tags": item.get("tags", []),
            "source_sha256": sha256_file(source),
            "prompt": prompt,
            "prompt_sha256": prompt_hash if prompt_path_value else None,
            "data_uri": f"data:{mime};base64,{base64.b64encode(source.read_bytes()).decode('ascii')}",
        })
    require(referenced_media <= media_ids, f"section items reference unknown media ids: {sorted(referenced_media - media_ids)}")
    require(media_ids <= referenced_media, f"media is not placed in any section: {sorted(media_ids - referenced_media)}")
    hero_media_id = report.get("hero_media_id")
    if media_ids:
        require(isinstance(hero_media_id, str) and hero_media_id in media_ids,
                "hero_media_id must identify one registered media item when media is present")
    else:
        require(hero_media_id in (None, ""), "hero_media_id must be omitted when the report has no media")
    if originals.is_dir():
        actual_originals = {
            path.relative_to(root).as_posix() for path in originals.rglob("*")
            if path.is_file() and not path.name.endswith(".call.json")
        }
        generated = {item["source"] for item in media if item["origin"] == "generated"}
        require(actual_originals == generated,
                f"originals directory and generated media differ: missing={sorted(actual_originals-generated)}, extra={sorted(generated-actual_originals)}")
    folded = "\n".join(text_values(report)).casefold()
    hits = sorted(term for term in OBVIOUS_EXTERNAL_COPY if term in folded)
    require(not hits, f"external copy contains obvious assistant/defensive phrasing: {hits}")
    return report, request, hydrated


def render_html_text(report: dict[str, Any], hydrated: list[dict[str, Any]]) -> str:
    payload = {**report, "media": hydrated}
    encoded = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    encoded = encoded.replace("&", "\\u0026").replace("<", "\\u003c").replace(">", "\\u003e")
    template = Path(__file__).resolve().parents[1] / "assets" / "report-master.html"
    require(template.is_file(), "report master template is missing")
    html = template.read_text(encoding="utf-8")
    html = html.replace("__REPORT_TITLE__", report["title"].replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))
    html = html.replace("__REPORT_TYPE__", report["report_type"])
    html = html.replace("__REPORT_DATA__", encoded)
    require("__REPORT_" not in html, "unresolved report template token")
    return html


def render(root: Path, manifest_path: Path, output: Path) -> dict[str, Any]:
    report, request, hydrated = validate_report(root, manifest_path)
    expected_parent = (request / "work" / "final").resolve()
    require(output.resolve().parent == expected_parent, "HTML output must be directly inside request work/final/")
    require(output.suffix.lower() == ".html", "HTML output must use .html")
    html = render_html_text(report, hydrated)
    atomic_write_text(output, html, newline="\n")
    return {"status": "built", "html": output.relative_to(root).as_posix(), "sha256": sha256_file(output),
            "media_count": len(hydrated), "generated_original_count": sum(x["origin"] == "generated" for x in hydrated)}


def embedded_report(html_path: Path) -> dict[str, Any]:
    text = html_path.read_text(encoding="utf-8")
    match = re.search(r'<script id="report-data" type="application/json">(.*?)</script>', text, re.S)
    require(match is not None, "HTML lacks embedded report-data")
    try:
        value = json.loads(match.group(1))
    except json.JSONDecodeError as exc:
        raise HtmlDeliveryError(f"embedded report-data is invalid: {exc}") from exc
    require(isinstance(value, dict), "embedded report-data must be an object")
    return value


def validate_html(root: Path, manifest_path: Path, html_path: Path) -> dict[str, Any]:
    report, request, hydrated = validate_report(root, manifest_path)
    require(html_path.is_file(), "HTML output is missing")
    require(html_path.resolve().parent == (request / "work" / "final").resolve(), "HTML output is outside request work/final/")
    text = html_path.read_text(encoding="utf-8")
    require(text == render_html_text(report, hydrated),
            "HTML bytes differ from the deterministic manifest/template render")
    require(not re.search(r'<(?:script|img|link)\b[^>]+(?:src|href)\s*=\s*["\']https?://', text, re.I),
            "HTML contains a remote runtime asset")
    for token in (
        "prefers-reduced-motion", ":focus-visible", "<dialog", "data-lightbox", "data-copy", "compareTray",
        "data-density", "decision-matrix", "origin-badge", "renderMatrix", "text-only", "prompt-linkage",
    ):
        require(token in text, f"HTML interaction/accessibility contract missing: {token}")
    require("empty-media" not in text, "HTML must not render decorative empty-media placeholders")
    embedded = embedded_report(html_path)
    require(embedded.get("schema_version") == SCHEMA and embedded.get("report_type") == report["report_type"],
            "embedded report identity mismatch")
    expected = {item["id"]: item for item in hydrated}
    actual = {item.get("id"): item for item in embedded.get("media", []) if isinstance(item, dict)}
    require(set(actual) == set(expected), "embedded media set differs from manifest")
    for mid, item in expected.items():
        embedded_item = actual[mid]
        require(embedded_item.get("source_sha256") == item["source_sha256"], f"embedded media hash mismatch: {mid}")
        require(str(embedded_item.get("data_uri", "")).startswith("data:image/"), f"media is not image data URI: {mid}")
        require(embedded_item.get("prompt") == item["prompt"], f"embedded Prompt mismatch: {mid}")
        require(embedded_item.get("prompt_sha256") == item["prompt_sha256"], f"embedded Prompt hash mismatch: {mid}")
    return {"status": "passed", "html": html_path.relative_to(root).as_posix(), "sha256": sha256_file(html_path),
            "media_count": len(actual), "generated_original_count": sum(x["origin"] == "generated" for x in hydrated),
            "all_images_embedded": True, "all_generated_prompts_bound": True}


def doctor() -> dict[str, Any]:
    png = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl2nWQAAAAASUVORK5CYII=")
    with tempfile.TemporaryDirectory(prefix="html-delivery-") as td:
        root = Path(td)
        request = root / "requests" / "game-concept-lab" / "case"
        originals = request / "work" / "final" / "originals"
        prompts = request / "work" / "prompts"
        manifest_dir = request / "work" / "html-delivery"
        originals.mkdir(parents=True)
        prompts.mkdir(parents=True)
        manifest_dir.mkdir(parents=True)
        (request / "state.json").write_text(json.dumps({
            "primary_skill": "sicza-game-concept-lab", "status": "active", "revision": 1,
        }), encoding="utf-8")
        source = originals / "direction-a.png"
        source.write_bytes(png)
        prompt = prompts / "direction-a.txt"
        prompt.write_text("A complete scene prompt with a visible subject and action.\n", encoding="utf-8")
        source_b = originals / "direction-b.png"
        source_b.write_bytes(png)
        prompt_b = prompts / "direction-b.txt"
        prompt_b.write_text("A distinct complete scene prompt with a rival subject and different action.\n", encoding="utf-8")
        source_rel = source.relative_to(root).as_posix()
        prompt_rel = prompt.relative_to(root).as_posix()
        source_b_rel = source_b.relative_to(root).as_posix()
        prompt_b_rel = prompt_b.relative_to(root).as_posix()
        parameters = {"size": "1:1", "quality": "4k"}
        plan = {
            "schema_version": "wxian.generation-plan.v1", "primary_skill": "sicza-game-concept-lab",
            "status": "READY", "items": [{
                "id": "direction-a", "status": "READY", "api_profile": "gemini",
                "mode": "text_to_image", "model": "gemini-3.1-flash-image-preview",
                "prompt_path": prompt_rel, "prompt_sha256": sha256_file(prompt),
                "output_path": source_rel, "parameters": parameters,
            }, {
                "id": "direction-b", "status": "READY", "api_profile": "gemini",
                "mode": "text_to_image", "model": "gemini-3.1-flash-image-preview",
                "prompt_path": prompt_b_rel, "prompt_sha256": sha256_file(prompt_b),
                "output_path": source_b_rel, "parameters": parameters,
            }],
        }
        plan_path = request / "work" / "generation-plan.json"
        plan_path.write_text(json.dumps(plan, ensure_ascii=False), encoding="utf-8")
        fixture_executor = root / GENERATION_EXECUTOR
        fixture_executor.parent.mkdir(parents=True, exist_ok=True)
        fixture_executor.write_text("# deterministic generation executor fixture\n", encoding="utf-8")
        call = {
            "schema_version": GENERATION_CALL_SCHEMA,
            "status": "success", "network_called": True, "http_status": 200,
            "service_request_id": "fixture-request-001",
            "service_request_id_status": "provided",
            "service_request_id_source": "header:x-request-id",
            "request_payload_sha256": hashlib.sha256(b"fixture request").hexdigest(),
            "response_sha256": hashlib.sha256(b"fixture response").hexdigest(),
            "executor_binding": {
                "path": GENERATION_EXECUTOR,
                "sha256": sha256_file(fixture_executor),
            },
            "api_profile": "gemini",
            "mode": "text_to_image", "model": "gemini-3.1-flash-image-preview", "parameters": parameters,
            "output_path": source_rel, "output_sha256": sha256_file(source),
            "prompt_path": prompt_rel, "prompt_sha256": sha256_file(prompt),
            "prompt_source_sha256": sha256_file(prompt),
            "generation_plan_binding": {
                "path": plan_path.relative_to(root).as_posix(), "sha256": sha256_file(plan_path),
                "primary_skill": "sicza-game-concept-lab", "execution_class": "concept-generation",
                "item_id": "direction-a",
            },
        }
        source.with_name(source.name + ".call.json").write_text(json.dumps(call), encoding="utf-8")
        call_b = json.loads(json.dumps(call))
        call_b.update({
            "service_request_id": None,
            "service_request_id_status": "provider_not_supplied",
            "service_request_id_source": None,
            "output_path": source_b_rel,
            "output_sha256": sha256_file(source_b),
            "prompt_path": prompt_b_rel,
            "prompt_sha256": sha256_file(prompt_b),
            "prompt_source_sha256": sha256_file(prompt_b),
        })
        call_b["generation_plan_binding"]["item_id"] = "direction-b"
        source_b.with_name(source_b.name + ".call.json").write_text(json.dumps(call_b), encoding="utf-8")
        report = {
            "schema_version": SCHEMA, "report_type": "game-concept-lab", "title": "方向测试",
            "summary": "三个方向中，A 的玩法关系最清楚。", "project_name": "测试项目",
            "hero_media_id": "a-image",
            "visual_system": {"theme_name": "信号灯下的工业夜景", "rationale": "高对比色来自玩法反馈。",
                              "canvas": "#101318", "surface": "#191f28", "ink": "#f5f2e8", "muted": "#b6bdc8",
                              "accent": "#ff6b3d", "accent_alt": "#78d6c6", "shape": "measured"},
            "sections": [{"id": "direction-a", "title": "方向 A", "lead": "动作直接改变场景状态。",
                          "layout": "feature", "items": [{"id": "a", "title": "机械闸门", "summary": "玩家切断压力管线打开逃生通道。",
                          "body": ["红色压力表在操作后归零。", "安全测试 </SCRIPT><script>alert(1)</script>"],
                          "media_ids": ["a-image"], "tags": ["玩法"], "recommendation": "primary"}]},
                         {"id": "direction-matrix", "title": "方向横向比较", "lead": "候选作为列直接对比。",
                          "layout": "matrix", "items": [
                              {"id": "matrix-a", "title": "方向 A", "summary": "压力操作更直接。",
                               "body": ["切断管线", "开启闸门"], "media_ids": ["a-image"],
                               "tags": ["操作"], "recommendation": "primary"},
                              {"id": "matrix-b", "title": "方向 B", "summary": "追逐关系更鲜明。",
                               "body": ["诱导守卫", "改变路线"], "media_ids": ["b-image"],
                               "tags": ["追逐"], "recommendation": "alternate"}
                          ]},
                         {"id": "gallery-test", "title": "图集分支", "lead": "验证同类内容浏览。",
                          "layout": "gallery", "items": [{"id": "gallery-a", "title": "图集条目", "summary": "图集使用卡片结构。",
                          "body": [], "media_ids": ["b-image"], "tags": ["图集"], "recommendation": "alternate"}]},
                         {"id": "comparison-test", "title": "并列分支", "lead": "验证并列选择。",
                          "layout": "comparison", "items": [
                              {"id": "compare-a", "title": "并列 A", "summary": "强调操作反馈。", "body": [], "media_ids": [], "tags": [], "recommendation": "primary"},
                              {"id": "compare-b", "title": "并列 B", "summary": "强调追逐压力。", "body": [], "media_ids": [], "tags": [], "recommendation": "alternate"}]},
                         {"id": "narrative-test", "title": "叙事分支", "lead": "验证有序说明。",
                          "layout": "narrative", "items": [{"id": "step-a", "title": "先切断管线", "summary": "第一步改变压力状态。",
                          "body": [], "media_ids": [], "tags": [], "recommendation": "neutral"}]},
                         {"id": "sources-test", "title": "来源分支", "lead": "验证紧凑索引。",
                          "layout": "sources", "items": [{"id": "source-a", "title": "测试来源", "summary": "当前为确定性自测来源。",
                          "body": [], "media_ids": [], "tags": [], "recommendation": "evidence"}]}],
            "media": [{"id": "a-image", "source": source_rel, "origin": "generated", "title": "机械闸门主画面",
                       "alt": "角色站在泄压后的机械闸门前", "caption": "画面证明操作与通道开启的因果关系。", "tags": ["玩法"], "prompt_path": prompt_rel},
                      {"id": "b-image", "source": source_b_rel, "origin": "generated", "title": "守卫追逐主画面",
                       "alt": "守卫沿着另一条路线追逐角色", "caption": "画面证明诱导与路线变化的因果关系。", "tags": ["追逐"], "prompt_path": prompt_b_rel}],
        }
        manifest = manifest_dir / "report.json"
        manifest.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")
        output = request / "work" / "final" / "report.html"
        built = render(root, manifest, output)
        checked = validate_html(root, manifest, output)
        pristine_html = output.read_text(encoding="utf-8")
        require("</SCRIPT>" not in pristine_html and "<script>alert(1)</script>" not in pristine_html,
                "JSON script-break payload was not escaped")
        density_checks: dict[str, str] = {}
        for density in ("airy", "dense"):
            density_report = json.loads(json.dumps(report))
            density_report["visual_system"]["density"] = density
            manifest.write_text(json.dumps(density_report, ensure_ascii=False), encoding="utf-8")
            density_output = request / "work" / "final" / f"report-{density}.html"
            render(root, manifest, density_output)
            validate_html(root, manifest, density_output)
            require(embedded_report(density_output).get("visual_system", {}).get("density") == density,
                    f"density branch was not embedded: {density}")
            density_checks[density] = "PASS"
            density_output.unlink()
        manifest.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")

        packaging_plan = json.loads(json.dumps(plan))
        packaging_plan["primary_skill"] = "wxian-visual-packaging"
        plan_path.write_text(json.dumps(packaging_plan, ensure_ascii=False), encoding="utf-8")
        packaging_plan_hash = sha256_file(plan_path)
        packaging_call = json.loads(json.dumps(call))
        packaging_call["generation_plan_binding"].update({
            "sha256": packaging_plan_hash,
            "primary_skill": "wxian-visual-packaging",
            "execution_class": "packaging-validation",
        })
        packaging_call_b = json.loads(json.dumps(call_b))
        packaging_call_b["generation_plan_binding"].update({
            "sha256": packaging_plan_hash,
            "primary_skill": "wxian-visual-packaging",
            "execution_class": "packaging-validation",
        })
        source.with_name(source.name + ".call.json").write_text(json.dumps(packaging_call), encoding="utf-8")
        source_b.with_name(source_b.name + ".call.json").write_text(json.dumps(packaging_call_b), encoding="utf-8")
        (request / "state.json").write_text(json.dumps({
            "primary_skill": "wxian-visual-packaging", "status": "active", "revision": 1,
        }), encoding="utf-8")
        packaging_report = json.loads(json.dumps(report))
        packaging_report["report_type"] = "visual-packaging"
        manifest.write_text(json.dumps(packaging_report, ensure_ascii=False), encoding="utf-8")
        packaging_output = request / "work" / "final" / "visual-packaging.html"
        packaging_build = render(root, manifest, packaging_output)
        packaging_validate = validate_html(root, manifest, packaging_output)
        packaging_output.unlink()
        plan_path.write_text(json.dumps(plan, ensure_ascii=False), encoding="utf-8")
        source.with_name(source.name + ".call.json").write_text(json.dumps(call), encoding="utf-8")
        source_b.with_name(source_b.name + ".call.json").write_text(json.dumps(call_b), encoding="utf-8")
        (request / "state.json").write_text(json.dumps({
            "primary_skill": "sicza-game-concept-lab", "status": "active", "revision": 1,
        }), encoding="utf-8")
        manifest.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")

        negatives: dict[str, str] = {}
        def must_block(name: str, fn) -> None:
            try:
                fn()
            except HtmlDeliveryError:
                negatives[name] = "BLOCK"
            else:
                raise HtmlDeliveryError(f"doctor failed to block {name}")

        output.write_text(pristine_html.replace("</body>", "</SCRIPT><script>alert(2)</script></body>"), encoding="utf-8")
        must_block("uppercase_script_injection", lambda: validate_html(root, manifest, output))
        output.write_text(pristine_html.replace("三个方向中，A 的玩法关系最清楚。", "结论已被替换。"), encoding="utf-8")
        must_block("conclusion_tamper", lambda: validate_html(root, manifest, output))
        marker = base64.b64encode(png).decode("ascii")
        output.write_text(pristine_html.replace(marker, ("A" if marker[0] != "A" else "B") + marker[1:], 1), encoding="utf-8")
        must_block("data_uri_tamper", lambda: validate_html(root, manifest, output))
        output.write_text(pristine_html, encoding="utf-8")

        fake_call = json.loads(json.dumps(call))
        fake_call["network_called"] = False
        source.with_name(source.name + ".call.json").write_text(json.dumps(fake_call), encoding="utf-8")
        must_block("fake_call_receipt", lambda: validate_report(root, manifest))
        source.with_name(source.name + ".call.json").write_text(json.dumps(call), encoding="utf-8")

        fabricated_call = json.loads(json.dumps(call))
        fabricated_call.pop("service_request_id")
        source.with_name(source.name + ".call.json").write_text(json.dumps(fabricated_call), encoding="utf-8")
        must_block("fabricated_network_receipt", lambda: validate_report(root, manifest))
        source.with_name(source.name + ".call.json").write_text(json.dumps(call), encoding="utf-8")

        wrong_tags = json.loads(json.dumps(report))
        wrong_tags["sections"][0]["items"][0]["tags"] = "not-an-array"
        manifest.write_text(json.dumps(wrong_tags, ensure_ascii=False), encoding="utf-8")
        must_block("item_tags_type", lambda: validate_report(root, manifest))
        wrong_tags = json.loads(json.dumps(report))
        wrong_tags["media"][0]["tags"] = "not-an-array"
        manifest.write_text(json.dumps(wrong_tags, ensure_ascii=False), encoding="utf-8")
        must_block("media_tags_type", lambda: validate_report(root, manifest))
        low_contrast = json.loads(json.dumps(report))
        low_contrast["visual_system"]["accent"] = low_contrast["visual_system"]["canvas"]
        manifest.write_text(json.dumps(low_contrast, ensure_ascii=False), encoding="utf-8")
        must_block("accent_canvas_contrast", lambda: validate_report(root, manifest))
        low_contrast = json.loads(json.dumps(report))
        low_contrast["visual_system"]["muted"] = low_contrast["visual_system"]["canvas"]
        manifest.write_text(json.dumps(low_contrast, ensure_ascii=False), encoding="utf-8")
        must_block("muted_canvas_contrast", lambda: validate_report(root, manifest))
        low_contrast = json.loads(json.dumps(report))
        low_contrast["visual_system"]["canvas_alt"] = low_contrast["visual_system"]["ink"]
        manifest.write_text(json.dumps(low_contrast, ensure_ascii=False), encoding="utf-8")
        must_block("canvas_alt_ink_contrast", lambda: validate_report(root, manifest))
        manifest.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")

        source.unlink()
        must_block("missing_original", lambda: validate_report(root, manifest))
        source.write_bytes(png)

        escaped = json.loads(json.dumps(report))
        escaped["media"][0]["source"] = "../outside.png"
        manifest.write_text(json.dumps(escaped, ensure_ascii=False), encoding="utf-8")
        must_block("output_path_escape", lambda: validate_report(root, manifest))

        disguised = json.loads(json.dumps(report))
        disguised["media"][0]["origin"] = "evidence"
        disguised["media"][0].pop("prompt_path")
        manifest.write_text(json.dumps(disguised, ensure_ascii=False), encoding="utf-8")
        must_block("evidence_as_generated_original", lambda: validate_report(root, manifest))

        wrong_type = json.loads(json.dumps(report))
        wrong_type["report_type"] = "visual-packaging"
        manifest.write_text(json.dumps(wrong_type, ensure_ascii=False), encoding="utf-8")
        must_block("primary_report_type_mismatch", lambda: validate_report(root, manifest))

        wrong_hero = json.loads(json.dumps(report))
        wrong_hero["hero_media_id"] = "missing-media"
        manifest.write_text(json.dumps(wrong_hero, ensure_ascii=False), encoding="utf-8")
        must_block("unknown_hero_media", lambda: validate_report(root, manifest))

        manifest.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")
        pristine_plan = plan_path.read_text(encoding="utf-8")
        plan_path.write_text(pristine_plan + "\n", encoding="utf-8")
        must_block("generation_plan_hash_drift", lambda: validate_report(root, manifest))
        plan_path.write_text(pristine_plan, encoding="utf-8")

        broken = json.loads(json.dumps(report))
        broken["media"][0]["prompt_path"] = "requests/game-concept-lab/case/work/prompts/missing.txt"
        manifest.write_text(json.dumps(broken, ensure_ascii=False), encoding="utf-8")
        must_block("missing_generated_prompt", lambda: validate_report(root, manifest))
        shared_prompt = json.loads(json.dumps(report))
        shared_prompt["media"][1]["prompt_path"] = prompt_rel
        manifest.write_text(json.dumps(shared_prompt, ensure_ascii=False), encoding="utf-8")
        must_block("shared_generated_prompt_path", lambda: validate_report(root, manifest))
        prompt_b_text = prompt_b.read_text(encoding="utf-8")
        prompt_b.write_text(prompt.read_text(encoding="utf-8"), encoding="utf-8")
        manifest.write_text(json.dumps(report, ensure_ascii=False), encoding="utf-8")
        must_block("shared_generated_prompt_content", lambda: validate_report(root, manifest))
        prompt_b.write_text(prompt_b_text, encoding="utf-8")
        single_matrix = json.loads(json.dumps(report))
        single_matrix["sections"][1]["items"] = single_matrix["sections"][1]["items"][:1]
        manifest.write_text(json.dumps(single_matrix, ensure_ascii=False), encoding="utf-8")
        must_block("single_candidate_matrix", lambda: validate_report(root, manifest))
        return {"status": "passed", "build": built, "validate": checked,
                "layout_branches": sorted(LAYOUTS), "density_checks": density_checks,
                "visual_packaging_generated_output": {
                    "build": packaging_build, "validate": packaging_validate,
                },
                "negative_checks": negatives}


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    build_parser = sub.add_parser("build")
    validate_parser = sub.add_parser("validate")
    sub.add_parser("doctor")
    for item in (build_parser, validate_parser):
        item.add_argument("--manifest", required=True)
        item.add_argument("--workspace-root", default=".")
    build_parser.add_argument("--output", required=True)
    validate_parser.add_argument("--html", required=True)
    args = parser.parse_args()
    try:
        if args.command == "doctor":
            result = doctor()
        else:
            root = Path(args.workspace_root).resolve()
            manifest = bounded(root, args.manifest)
            if args.command == "build":
                result = render(root, manifest, bounded(root, args.output, exist=False))
            else:
                result = validate_html(root, manifest, bounded(root, args.html))
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except HtmlDeliveryError as exc:
        print(json.dumps({"status": "blocked", "reason": str(exc)}, ensure_ascii=False, indent=2))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
