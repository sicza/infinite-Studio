# Report manifest contract

`work/html-delivery/report.json` 是 HTML 的唯一结构化输入。

## 顶层

- `schema_version`: 固定 `wxian.html-delivery.v1`
- `report_type`: `game-concept-lab | visual-packaging | visual-competitive-analysis | internet-research`
- `report_type` 必须与 `state.json.primary_skill` 固定映射：`sicza-game-concept-lab → game-concept-lab`、`wxian-visual-packaging → visual-packaging`、`wxian-visual-competitive-analysis → visual-competitive-analysis`、`wxian-conducting-internet-research → internet-research`。
- `title`: 对外标题
- `summary`: 首屏直接结论，不能是“本报告将……”
- `project_name`: 可选；有真实项目名时填写
- `hero_media_id`: 有媒体时必填，必须指向最能证明首屏结论的一项；无媒体时省略
- `visual_system`: 必填，见下文
- `sections`: 至少一个模块
- `media`: 可空；有图片时逐张登记

## visual_system

必填：`theme_name / rationale / canvas / surface / ink / muted / accent / accent_alt`。颜色使用 6 位十六进制。可选：

- `canvas_alt`
- `line`
- `display_font`
- `body_font`
- `density`: `airy | balanced | dense`
- `shape`: `sharp | measured | soft`

字体默认使用离线系统字体栈。若项目提供有合法使用权的本地字体，可将字体转成 data URI 后写入最终 HTML；不得链接远端字体。

## sections

每个 section：

- `id`: 页面内唯一 slug
- `title`
- `lead`: 可选的一段直接说明
- `layout`: `feature | gallery | comparison | matrix | narrative | sources`
- `items`: 至少一个

每个 item：

- `id`, `title`
- `summary`: 一句可独立理解的结论
- `body`: 0–8 条具体内容
- `media_ids`: 可空
- `tags`: 可空，用于筛选
- `recommendation`: `primary | alternate | evidence | neutral`
- `source_url`: 可选，只有真实公开 HTTPS 来源时填写

`layout` 不是装饰标签：`feature` 用于一个主结论与重点作品，`gallery` 用于同类方向浏览，`comparison` 用于并列选择，`matrix` 渲染为候选横向展开的真实对比表，`narrative` 表达有顺序的行动或论证，`sources` 使用紧凑索引。`matrix` 至少包含两个 item，每个 item 代表一个被比较候选：标题成为列头，`summary`、`body`、图片和标签分别成为对比行；不得把 A/B/C 文案塞进同一个维度单元格冒充横向矩阵。没有媒体的 item 只渲染正文，不制造空白图片框。

## media

每张图片：

- `id`
- `source`: Workspace 相对路径
- `origin`: `generated | evidence`
- `title`
- `alt`: 描述图中可见内容，不能写“图片”
- `caption`: 说明它证明什么
- `tags`: 可空
- `prompt_path`: `origin=generated` 时必填，指向该图实际调用的完整 Prompt
- `source_url`: `origin=evidence` 时可选；只接受真实公开 HTTPS 来源

生成图约束：

- `source` 必须位于当前 request 的 `work/final/originals/`。
- 同名 `<image>.<ext>.call.json` 必须使用 `wxian.generation-call.v3`，绑定当前 Generation API 执行器 Hash，并携带成功 HTTP 状态、请求 payload Hash 与响应 Hash；服务提供 request id 时必须记录 `service_request_id_status=provided`、真实 ID 与来源，服务未提供时必须显式记录 `service_request_id_status=provider_not_supplied` 且 ID/来源均为 null。`api_profile / mode / model / parameters / output_path / output_sha256 / prompt_path / prompt_sha256 / prompt_source_sha256` 必须与当前文件和 Prompt 一致。该合同用于阻断缺字段、自报布尔值、状态矛盾或旧执行器回执，不伪造远端 request id，也不把本地可编辑 JSON 宣称为不可伪造的远端证明。
- 调用回执的 `generation_plan_binding` 必须绑定当前 request 的 `work/generation-plan.json` 路径、Hash、Primary、execution class 和唯一 item id；该 item 的 Profile、Mode、Model、参数、Prompt、输出路径与 Hash 必须与回执逐项相等。
- HTML 中的 Prompt 必须逐字来自 `prompt_path`，不得二次摘要。
- 每张生成图使用唯一 `prompt_path`，且完整 Prompt 内容 Hash 也不得与另一张生成图重复；不得用复制文件、`同上`、公共 Prompt 或一个 Prompt 对应多张图来绕过一图一 Prompt。

## 对外 HTML

构建器把 manifest 和媒体内容写进 `<script id="report-data" type="application/json">`，图片使用 data URI，JSON 中的 `< > &` 统一安全转义。页面不得从网络读取运行资源。页面显式显示媒体身份，首屏只使用 `hero_media_id` 指定的媒体。`validate` 会从当前 manifest、模板、原图和 Prompt 重新确定性渲染，并要求 HTML 字节完全一致；构建后改结论、替换 data URI 或注入脚本都会失败。
