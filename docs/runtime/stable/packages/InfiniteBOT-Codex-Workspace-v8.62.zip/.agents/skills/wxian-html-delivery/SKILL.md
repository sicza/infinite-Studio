---
name: wxian-html-delivery
description: 将游戏概念、视觉包装、视觉竞品分析和互联网调研的已完成内容制作成项目化、可交互、离线可打开的单文件 HTML，并把实际生成的原图与完整 Prompt 一一绑定。用于上述 Primary Skill 的最终展示与交付，不负责重新研究、改写专业结论或决定创意方向。
---

# 互动 HTML 交付

本 Skill 是共享辅助能力，不创建第二 request，不改变 Primary Skill、专业判断或完成 Authority。调用方先完成自己的研究、方向、Prompt、生成和审查，再把真实内容写入 `work/html-delivery/report.json`，由本 Skill 渲染和验证。

## 交付目标

每个适用 request 对外只保留两类核心产物：

1. `work/final/originals/` 中的全部实际生成原图；没有生图时不制造空文件或占位图。
2. 一个 `work/final/*.html` 单文件报告。报告离线可打开，所有展示图片、字体和运行所需数据均内嵌，不依赖 CDN、远端脚本或同目录资源。

研究或竞品报告中使用的证据图也必须内嵌进 HTML，但只有真实生成结果进入 `originals/`。不得把缩略图、网页截图或压缩预览冒充生成原图。

## Authority

- 调用方拥有事实、结论、方向、数量、Prompt 和推荐关系。
- `$image-generation-api` 拥有真实调用与媒体回执。
- 本 Skill 拥有信息架构、项目风格映射、HTML 交互、资源内嵌与展示完整性。
- HTML 只能呈现已经闭合的内容，不在渲染阶段新增角色、卖点、证据、市场结论或 Prompt 约束。

## 执行

1. 读取当前用户要求、Project Brief、适用 Visual Baseline、调用方最终内容与真实图片。
2. 按 [report-profiles.md](references/report-profiles.md) 选择报告类型、模块和数量表达。数量由业务 Skill 决定，本 Skill 不补齐虚假条目。
3. 按 [visual-system.md](references/visual-system.md) 从当前项目提取视觉语言，写入 `report.json.visual_system`。没有项目视觉事实时，从本次主题建立一套明确但克制的视觉方向，并在 `rationale` 中说明依据。
4. 按 [external-copy.md](references/external-copy.md) 完成对外文案编辑。Prompt 保持原文，不参与文案润色。
5. 每张 `origin=generated` 的媒体必须指向 `work/final/originals/` 中的真实原图，并提供 `prompt_path`。同名 `.call.json` 必须证明真实网络调用、generation plan item、Primary、Profile、Mode、Model、参数、输出与 Prompt 的完整绑定。
6. 运行：

```powershell
python .agents/skills/wxian-html-delivery/scripts/html_delivery.py build \
  --manifest <request>/work/html-delivery/report.json \
  --output <request>/work/final/<report-name>.html \
  --workspace-root .
```

正式交付必经 Promote 时，`$workspace-governance promote` 是 `html_delivery.py validate` 的唯一 blocking caller；直接运行 `validate` 只用于显式诊断。非 Promote consumer 若合法消费 HTML，必须在自己的唯一 completion boundary 调用一次 validator，不能无 Gate 完成。

7. 在桌面与移动视口实际打开 HTML，检查图片、层级、展开/收起、筛选、复制 Prompt、对比台、灯箱、键盘焦点、长文本、横向溢出和窄屏阅读顺序。修复后交给对应唯一 completion authority。

## `report.json` 最小合同

完整字段见 [report-contract.md](references/report-contract.md)。核心结构：

```json
{
  "schema_version": "wxian.html-delivery.v1",
  "report_type": "game-concept-lab",
  "title": "项目标题",
  "summary": "读者首先需要知道的结论",
  "hero_media_id": "最能证明首页结论的媒体 ID",
  "visual_system": {
    "theme_name": "项目视觉方向",
    "rationale": "该视觉系统与项目事实的关系",
    "canvas": "#101318",
    "surface": "#191f28",
    "ink": "#f5f2e8",
    "muted": "#b6bdc8",
    "accent": "#ff6b3d",
    "accent_alt": "#78d6c6"
  },
  "sections": [],
  "media": []
}
```

## 硬性标准

- 单文件 HTML；CSS、JavaScript、图片、可选字体全部内嵌。
- 语义化 HTML、可见键盘焦点、有效 `alt`、`prefers-reduced-motion`、无意外横向滚动。
- 交互必须真实可用；至少包括目录导航、媒体筛选、图片灯箱。存在两项以上可比较方向时启用对比台；存在 Prompt 时启用展开和复制。
- 每张生成图与自己的完整 Prompt 一一对应，图片卡必须直接写明对应关系，并以图片标题标识该 Prompt 生成哪张图；不能截断、摘要、引用“同上”、多图共用一个 Prompt 或只放关键词。完整 Prompt 可展开、复制，打印时自动展开。
- 首屏直接呈现本次最重要的结论或作品，不使用通用大标题加白卡网格冒充设计。
- 有媒体时必须显式指定 `hero_media_id`，不得依赖文件顺序偶然决定首屏；没有媒体时省略该字段。
- `feature / gallery / comparison / matrix / narrative / sources` 必须形成不同的信息结构：矩阵用真实表格，叙事用序列，来源用紧凑索引，纯文字项不生成空媒体占位。
- 每张媒体在页面上明确显示“生成原图”或“证据素材”；`density` 必须实际改变段落与卡片节奏，不能只停留在 Manifest。
- 页面视觉必须来自当前项目或当前主题；换成邻近项目仍完全成立时，判定为未完成。
- 不展示内部路径、Hash、Gate 名、模型自述、过程辩解和面向执行者的防御性说明。来源、限制和风险用正常对外语言表达。
- 不用装饰动画掩盖内容缺失。交互移除后不损失信息；打印时所有核心内容和完整 Prompt 可见。

## 完成边界

`build` 成功只证明已生成页面；`validate` 会从当前模板、manifest、原图与 Prompt 确定性重建页面并要求字节一致，同时验证生成图/Prompt/真实调用回执的完整绑定。最终设计质量仍以真实桌面/移动渲染与调用方专业复核为准。

实现基线参考 `effective-html` commit `d95debbaef15af1d201fc6c10c77cf92b524a0d6` 的单文件、自包含、响应式、可访问与浏览器实测原则；视觉皮肤必须由当前项目事实决定，不复制参考项目的固定样式。
