# Failure Patterns — 真实高风险错误

只有 Audit 发现风险或实际生成反复失败时读取。

| Failure | 根因 | 修复 |
|---|---|---|
| KV 被默认当 Frame 0 | Placement 泄漏 | 重新确定 START/PASS/END |
| Ending 从 KV 开始又回 KV | 没做 Backward Reconstruction | 建立 Video Start / Pre-KV State |
| Peak 自动等于 End | Dramatic Position 与 Placement 混淆 | Peak 可 PASS_THROUGH 或 END |
| Asset Lock 变成 Pose Lock | 身份/状态混淆 | 锁 Asset，State 允许合法变化 |
| 已有道具重新取出 | START State Continuity 丢失 | 从当前持有状态继续 |
| 道具凭空出现 | Prop 归属连续性丢失 | 建立来源与状态路径 |
| END/PASS 强制关键道具从 0 秒始终可见 | 把 START 的道具规则泛化 | 保持身份/归属连续，允许有合理遮挡/低位/进入 KV 的路径 |
| 只有头发/火焰/镜头微动 | 没有 Primary Dramatic Change | 重写完整因果事件 |
| 动作过度克制 | 把可执行性当保守度 | 在连续性护栏内提高表演强度 |
| 多角色各演各的 | 没有单一主因果链 | 确立 Primary Change，其他为 Reaction |
| 高潮只有一个光效 | 把高潮当特效 | 使用 synchronized payoffs |
| 普通 KV 被强制 Hero 化 | 错用 Worthiness 硬门禁 | 改用 Causal Integration Gate |
| 所有题材被塞进固定分类 | Driver 枚举化 | 用自然语言定义 Primary Dramatic Change |
| 世界观/产品/情绪被战斗化 | Action 偏置 | 从当前变化本身构造升级 |
| 人脸稳定但像贴图 | Identity Lock 锁死表情 | 编译 Expression Freedom |
| END 最后机械摆回 KV | 缺少自然状态路径 | 让动作轨迹直接形成 KV |
| Prompt 越改越长 | 经验变成补丁墙 | 规则留在 Skill，Prompt 选择性编译 |
