# Reference Binding — 上传 KV 在 Seedance 中扮演什么角色

## 原则

本 Skill 输出**语义参考角色**，不假装知道用户当前 Seedance 入口一定有哪些 UI 控件。

## START_VISUAL_REFERENCE
对应 START。

Prompt 语义：
> 从上传 KV 当前已经成立的姿态、空间关系和画面状态直接启动。

若实际入口支持首帧绑定，可用首帧；否则用参考图 + 明确起始语义。

## STORY_KEYFRAME_REFERENCE
对应 PASS_THROUGH。

Prompt 语义：
> 视频先从合理前置状态开始，在 KV_TARGET_WINDOW 自然形成/经过上传 KV 中的姿态、空间关系和关键状态，然后继续剧情。

禁止把 KV 声明为首帧。

## FINAL_VISUAL_TARGET
对应 END。

Prompt 语义：
> 从合理前置状态开始，通过连续动作和因果，最终自然形成上传 KV 的主体姿态、道具位置、空间关系与核心构图。

若实际入口支持尾帧/结束画面绑定，可用于尾部目标；否则用参考图 + 明确最终目标语义。

禁止为了 END 反而把 KV 绑定为起始状态。

## Hard Fail
- Placement=END 但 Prompt 把 KV 当首帧
- Placement=PASS_THROUGH 但 0 秒完全复制 KV
- Placement=START 却没有从 KV 当前状态启动
- Prompt 的素材角色与设计中的 Placement 不一致
