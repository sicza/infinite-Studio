# Narrative / Visual Integration for 5s KV Micro Animation

微动画不维护 `motion_visual_spec`。Narrative 与 Motion 都编译进全 Workspace 唯一 `work/visual-spec.json`。

## 1. Authority 顺序

```text
current request / KV observed facts / locked user intent
→ Narrative route
→ [需要时] work/narrative-visual-contract.json
→ Project Visual Baseline + References
→ sicza-visual-director
→ work/visual-spec.json (task_kind=motion)
→ Seedance Prompt Compilation
→ work/prompt-binding.json
→ 当前 KV Micro Animation 执行与验证
```

Baseline 不进入 Narrative Solver。

## 2. Narrative owns

- `VIDEO_START_STATE / KV_STATE / FINAL_STATE` 的客观状态；
- Trigger、前置条件、状态变化、结果与持续后果；
- 角色知道/不知道什么；
- 物体归属、路径、伤势/受力/机械条件；
- KV 是 Start / Pass-through / End 的哪种叙事时相；
- 观众必须看懂、可延迟、必须隐藏的信息。

## 3. Visual Director owns

- Blocking、身体、接触、视线、表演可见性；
- 相机几何、镜头运动、景别、透视、遮挡与构图；
- 光、材质、表面、空气如何随事件响应；
- 明暗/色彩/细节/节奏分配；
- 焦点、景深、运动模糊、光学/时间采样；
- 第一读/第二读与项目视觉身份。

Seedance Prompt 只编码两层已锁决定。

## 4. Narrative Route

- `NONE`：Logo、产品、环境等纯视觉运动，没有叙事状态歧义；
- `HANDOFF_ONLY`：起终点/事件已完全锁定，只需要 R09 定义观看者证明义务；
- `SOLVE`：关键事件没有合法前置/结果、角色知识不成立、物体/车辆/门/道路/伤势跳变、首尾帧之间缺状态桥；
- `REPAIR`：已有状态链互相矛盾或无法连续生成。

常见最小组合：`R01 + R09`；角色选择追加 R02；多人关系追加 R03；身体/车辆追加 R04；物体/路径追加 R05。

## 5. Narrative Contract

实质叙事统一使用：

`<request>/work/narrative-visual-contract.json`

其中 `selected_moment_or_windows / protected_narrative_truth / must_show / may_show / must_not_imply / audience_information / causal_evidence / continuity_obligations` 由 Visual Director 只读消费。

## 6. Motion in Canonical Visual Spec

`work/visual-spec.json` 必须：

- `task_kind = motion`；
- `motion` 非空；
- `truth_protection` 保护 KV 身份、叙事事实、必须显示/不得暗示和连续义务；
- `performance / world_space / projection / appearance / image_formation` 描述可见执行机制；
- `change_set` 明确 protect/change/remove/avoid；
- 有 Narrative Contract 时绑定完整 `narrative_trace`。

`motion` 只放 Motion 专属高杠杆字段，例如：

- primary_dramatic_change
- start_state_visibility
- climax_window
- final_state_visibility
- camera_motion
- composition_evolution
- synchronized_payoffs

不得建立第二套 Motion Visual Spec schema。

## 7. 5 秒预算

- 0–1s：Trigger 或变化开始可读；
- 1–3s：主状态变化持续并增强关系；
- 3–5s：一个主高潮完成，人物/环境/光效/镜头可同步响应，但属于同一因果链。

强度可以来自距离、开启、揭示、选择、关系、情绪、系统、环境或产品状态；不默认战斗、爆炸、追逐。

## 8. Prompt Binding

最终 Prompt 逐句反查：

`Prompt → work/visual-spec.json → [可选] Narrative Contract / KV observed fact`

任何重要动作、物体、镜头目标或状态变化找不到上游来源，删除或回上游补定义。

Prompt 文件生成后必须产生 `work/prompt-binding.json` 并通过 `.agents/scripts/visual_contract_gate.py validate-binding`。`compiler_profile` 只能使用 `.agents/skills/workspace-governance/config/visual-contracts/prompt-compiler-profiles.json` 中当前 Seedance profile，不能用自由文本 adapter 名代替。
