# Seedance Prompt Compilation — Narrative Contract + Canonical Visual Spec → Executable Prompt

## 目标

Prompt 只编码当前 KV 已经成立的 `Narrative Contract/State Delta + canonical Visual Spec.motion + Reference Role`。不把 Skill 方法论复制给模型，不在 Prompt 阶段补故事漏洞。

## 1. 先选 Prompt Pack

每次读取 `prompt-packs/seedance-2-0-core.md`，再按 `REFERENCE_ROLE` 只读取一个：

- `START_VISUAL_REFERENCE` → `prompt-packs/seedance-start-visual.md`
- `STORY_KEYFRAME_REFERENCE` → `prompt-packs/seedance-story-keyframe.md`
- `FINAL_VISUAL_TARGET` → `prompt-packs/seedance-final-target.md`

素材角色与 `KV_TIME_PLACEMENT` 必须一致。

## 2. 编译输入

至少包含：

```text
SOURCE_ASPECT_RATIO
REFERENCE_ROLE
ASSET_INVARIANTS
VIDEO_START_STATE
KV_STATE
FINAL_STATE
PRIMARY_DRAMATIC_CHANGE
KV_TARGET_WINDOW (if pass-through)
END_MODE (if end)
Canonical Visual Spec.motion
Camera Level
```

存在 Narrative Contract 时同时保护 `semantic_checksum / protected_narrative_truth / must_show / must_not_imply`。

## 3. Output Spec

写明 5 秒、单段连续叙事镜头、输出画幅语义。分辨率、seed、API mode 等继续放 API 请求，不混进导演 Prompt；只有“首帧/中段关键帧/尾部目标”的素材语义进入 Prompt。

## 4. Continuity

资产身份与状态变化分开：

- 锁脸、体型、服装、道具身份、世界资产；
- 不锁死姿态、表情、接触、镜头；
- 每个状态变化都要有可观察连续路径；
- 关键道具必须有归属和进入/离开路径；
- 空间前后、距离、遮挡、支撑、接触不能随镜头跳变。

## 5. Timeline

按 0–1 / 1–3 / 3–5 编译，但写的是状态变化，不是三个独立镜头。

每段至少包含：`谁/什么改变 → 怎么改变 → 对谁/什么产生结果 → 观众看见什么证据`。

## 6. Performance / Physicality

有人物时只编译当前事件所需：重心、手脚占用、接触、视线、脸部变化、呼吸、反作用与 follow-through。不要用“natural motion / expressive”替代具体表演。

车辆/机械/门/平台/武器等需要写清控制点、连接、支撑、运动轴和受力结果；不能只写“moves realistically”。

## 7. Camera / Composition

从 Visual Spec 编译：相机位置、景别变化、透视、运动方向、主体占屏、遮挡、前中远景和高潮时的阅读关系。

镜头变化只能强化 Primary Dramatic Change。保持单段连续镜头，不为“电影感”加入无因果摇移、环绕、变焦和切镜。

## 8. Light / Material / Atmosphere / Image Formation

只编译会帮助状态变化可读的响应：光源变化、阴影、反射、表面、空气、焦点、景深、运动模糊、颗粒/耀斑。它们必须是 Secondary Reinforcement，不得代替事件。

## 9. Perception / Identity

保证第一读始终围绕主状态变化；高潮可以增加视觉强度，但不能让粒子、亮斑、多人脸或文字抢掉主事件。保持源 KV 的项目视觉语法与身份锚点，不因运镜自动切换美术风格。

## 10. Selective Avoid

只写当前图高概率失败：错误角色版本、额外肢体、关键道具漂移、车辆/结构穿插、错误文字、无依据新增角色等。禁止通用长负向墙。

## 11. Lint

逐句反查：

`Prompt → work/visual-spec.json → Narrative Contract / KV observed fact`

任何无法追溯的重要动作、道具、状态、镜头目标或视觉效果必须删除或回上游修复。
