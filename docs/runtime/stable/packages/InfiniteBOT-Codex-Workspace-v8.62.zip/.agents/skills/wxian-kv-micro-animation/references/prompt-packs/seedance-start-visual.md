# Seedance Pack — START_VISUAL_REFERENCE

适用：`KV_TIME_PLACEMENT=START`。

## Binding

上传 KV 是视频 0 秒已经成立的画面状态。真实生产优先映射 `image_to_video_first_frame`。

## Prompt 必须表达

- 从 KV 当前姿态、空间、道具归属、接触和构图逻辑直接启动；
- 0 秒已经成立的动作不能重新执行；
- 第一秒内出现新的 Trigger / 状态变化；
- 镜头可从 KV 机位自然启动并随事件改变，但不能无理由跳位；
- 3–5 秒发展到新的 Peak/Result，不要求回到 KV。

## Hard Fail

- “先摆成 KV 姿势再开始”；
- 把 KV 当中途/尾帧目标；
- 为了稳定几乎不改变角色状态，只做头发/粒子/镜头推拉。
