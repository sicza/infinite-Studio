# Seedance Pack — FINAL_VISUAL_TARGET

适用：`KV_TIME_PLACEMENT=END`。

## Binding

上传 KV 是最终应自然形成的状态。若有明确且合法的首帧图，真实生产可映射 `image_to_video_first_last_frame`；只有 KV 一张时按当前 API 能力选择不把 KV 错绑为首帧的模式，并在 Prompt 中保持 Final Target 语义。

## Prompt 必须表达

- 从与 KV 明确不同但因果合法的前置状态开始；
- 每一步都缩小到 Final State 的状态差，但不是几何插值；
- 高潮事件本身造成 KV 中的姿态、物体位置、空间关系或环境状态；
- 最后 0.3–0.8 秒只允许自然余势，不做最后一刻突然校正构图；
- `PEAK_END` 直接以高潮形成 KV；`RESOLVED_END` 允许高潮后短促余势形成 KV。

## Hard Fail

- 把 KV 作为首帧然后“回到 KV”；
- 最后一刻硬切/吸附/变形到 KV；
- 关键道具或角色为了匹配尾帧凭空出现。
