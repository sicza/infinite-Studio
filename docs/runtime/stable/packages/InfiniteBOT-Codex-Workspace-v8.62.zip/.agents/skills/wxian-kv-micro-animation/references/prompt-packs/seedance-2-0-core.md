# Seedance 2.0 Core Prompt Pack

输入必须是已经成立的 `Narrative Contract/State Delta + canonical Visual Spec.motion + Reference Role`。本文件不负责重新决定剧情或镜头方向。

## 编译顺序

1. **Output / continuity context**：5 秒、单段连续镜头、目标画幅语义；
2. **Reference binding**：上传 KV 是 Start Visual / Story Keyframe / Final Visual Target；
3. **Protected truth**：角色/资产身份、服装、道具、空间、世界事实；
4. **Primary Dramatic Change**：5 秒唯一主状态变化；
5. **Performance / blocking / contact**：人物与物体如何连续行动；
6. **Timeline**：0–1 / 1–3 / 3–5；
7. **Camera / composition evolution**：镜头怎样服务状态变化；
8. **Light / material / atmosphere response**：只写与事件同步的可见响应；
9. **Image formation**：焦点、景深、运动采样、颗粒/耀斑等只在必要时使用；
10. **Perception / identity**：高潮时第一读仍正确，项目视觉语言不漂移；
11. **Task-specific avoid**：只关闭当前高风险失败。

## 时间轴写法

每段都写“状态 + 动作 + 可见结果”，不要写抽象强度。

- `0–1s`：Trigger 或主变化立刻可读；
- `1–3s`：距离、力量、揭示、关系、系统、情绪或环境状态持续改变；
- `3–5s`：一个主高潮完成，人物/环境/光效/镜头可以同步兑现，但不能分裂成多个主事件。

## Performance

身份稳定不等于表情/姿态静止。人物可根据事件连续改变视线、眉眼、嘴角、呼吸、肩颈、重心和手部动作；所有变化必须与状态变化同因果。

## Camera

镜头必须说明它如何帮助看懂：距离、方向、体量、接触、揭示或高潮。禁止先写复杂运镜再让故事适配运镜。

## Visual Response

光、材质、烟尘、粒子、布料、反射、环境运动都是 Secondary Reinforcement；没有 Primary Change 时不能靠这些元素假装“有剧情”。

## Ending

禁止倒放、硬切复位、无理由吸回 KV、高潮后机械停住摆 Pose。结尾必须是状态变化的自然结果。
