---
name: wxian-kv-micro-animation
description: 将静态 KV、海报、Banner 或商店图重构为 5 秒 Seedance 2.0 剧情微动画设计与完整 Prompt；用于“让这张 KV 动起来/补全前后剧情/做5秒微动画”。真实视频文件由 wxian-image-production 执行，本 Skill 不替代通用长视频制作。
---

# KV 微动画

进入前执行 `$workspace-governance consume-personal-context --request <request> --consumer wxian-kv-micro-animation`；阻断则停止。

## Overview

把静态 KV 当成一个被冻结的 **Dramatic Keyframe**。

目标不是给画面添加零散微动，而是：

> 读懂这一瞬间的状态与因果 → 用最小 request-local Narrative Contract 闭合状态变化 → 判断它在 5 秒故事里的时间位置 → 由视觉导演设计可见表演、空间、镜头和成像 → 编译成可直接给 Seedance 2.0 使用的完整自然语言 Prompt。

本 Skill 保持 5 秒微动画的专业编排与交付 Authority；`$sicza-causal-narrative-runtime` 只解决事件/状态/角色知识/物体连续性，`$sicza-visual-director` 只解决这些事实如何通过 Blocking、Camera、Composition、Light/Material、Image Formation 与 Perception 被看见。读取 `references/narrative-visual-integration.md` 执行两者的最小接入。

**KV 是故事证据，不自动等于视频首帧，也不自动等于高潮或尾帧。**


## Workspace 接入

本 Skill 可以作为独立 primary request，也可以作为 `$wxian-image-production` 的视频前置专业能力。调用方必须明确 `execution_mode`：`prompt_only | production_video`。

- 用户只要 **5 秒微动画剧情设计 / Seedance Prompt**：`execution_mode=prompt_only`，本 Skill 为 primary；完成后写 `work/final/micro-animation.md`、`work/final-review.md`、`work/delivery-manifest.json`，由 `$workspace-governance promote` 发布。
- 用户要 **真实视频文件**：`execution_mode=production_video`，`$wxian-image-production` 为 primary。本 Skill 一次完成静态 KV 读图、剧情、时间位置、镜头策略、素材角色与 Seedance Prompt，写入调用方指定的 `work/micro-animation/` 后立即返回生产 Skill继续 API；不在中途增加用户确认。
- 项目 Workspace 中必须消费当前正式 Baseline 的角色/品牌身份与最低线；Baseline 是项目先验和底线，不是剧情上限。当前 KV 的真实可见事实优先于历史视觉先验。

独立 `prompt_only` request 的 canonical Baseline receipt 固定为 `work/baseline-consumption.json`，machine key=`kv-micro-animation`；作为 image-production 内部前置能力时沿用调用方当前 request 的 `image-production` receipt，不另建第二份 Baseline Authority。

## When to Use

适用于：
- 静态 KV / 海报 / 商店图 / Banner → 5 秒剧情微动画
- “让这张图动起来，但要有完整故事”
- “补全这一帧之前发生了什么”
- “发生什么之后形成/停在这张 KV”
- “从这张 KV 继续发展到新的高潮”
- “写 Seedance 2.0 图生视频提示词 / 微动画 prompt”

不适用于：
- 与现有 KV 无关的从零视频创作
- 长视频、多场景、多镜头脚本
- 只要 Live Photo / 循环微动
- 泛用 Seedance 教程

## Input Contract

必需：
- 1 张可读取的静态 KV

默认：
- 5 秒
- 单段连续叙事镜头
- 用户未指定画幅时沿用源 KV 宽高比，不追问
- 原 KV 的角色/资产身份、场景、世界观与整体美术是视觉基线
- 最终输出完整自然语言 Prompt，不输出精简版

可选：
- 用户指定目标画幅
- 使用场景
- 剧情倾向
- 镜头自由度

执行模式：
- `prompt_only`：只交付剧情设计/Prompt。
- `production_video`：Prompt 是真实 Seedance 视频生产的内部前置产物；专业决策由 Skill 自动收敛，不追加 Camera 确认。

没有图片时停止，不猜图。

## Core Workflow

### Phase 1 — READ

读取 `references/kv-reading.md`。

产出内部状态：
- `OBSERVED / INFERRED / UNKNOWN`
- `SOURCE_ASPECT_RATIO`
- `ASSET_INVARIANTS`
- `KV_STATE`
- 可见的前因线索、后续线索、戏剧变化潜力

这一阶段不写剧情。

### Phase 2 — POSITION

读取 `references/timeline-placement.md`。

确定：
- `DRAMATIC_POSITION`
- `KV_TIME_PLACEMENT`：START / PASS_THROUGH / END
- `KV_TARGET_WINDOW`（PASS_THROUGH 时）
- `END_MODE`（END 时：PEAK_END / RESOLVED_END）

然后读取 `references/reference-binding.md`，生成与 Placement 一致的 `REFERENCE_ROLE`。

### Phase 3 — RECONSTRUCT

读取 `references/narrative-reconstruction.md`。

内部至少生成 3 个真正不同的 Story Candidate。

每个 Candidate 必须建立：
- `PRIMARY_DRAMATIC_CHANGE`：这 5 秒里究竟什么在持续变化、增强、完成或兑现
- `VIDEO_START_STATE`
- `PRE_KV_STATE`（需要时）
- `KV_STATE`
- `POST_KV_STATE`（需要时）
- Trigger / Development / Escalation / Climax / Final State

候选先通过 **KV Causal Integration Gate**，再比较叙事强度与 Seedance 可执行性。

遇到非典型题材或无法定义升级方式时，读取 `references/dramatic-change-patterns.md`。其中只是常见模式，不是封闭分类。

### Phase 3.5 — NARRATIVE / VISUAL CONTRACT

读取 `references/narrative-visual-integration.md`。对胜出 Candidate 建立最小状态变化链；存在实质性 Narrative State Delta 时调用 `$sicza-causal-narrative-runtime` 的必要模块并由 R09 生成叙事—视觉合同。随后调用 `$sicza-visual-director`，把合同或已锁静态事实写入唯一 `work/visual-spec.json`（`task_kind=motion`）并机器验证。Seedance Prompt 编译后必须生成 `work/prompt-binding.json`；不得在 Prompt 阶段重新发明故事、相机逻辑或角色关系。

### Phase 4 — CONTINUITY

读取 `references/continuity-control.md`。

检查：
- Asset Identity 全程稳定
- Pose/State 允许变化，但每次变化都有合法路径
- START 不重新执行 0 秒已经成立的动作
- PASS_THROUGH / END 能从合理前置状态自然形成 KV
- 人脸身份稳定，但表情和身体表演不被锁死

### Phase 5 — CAMERA

读取 `references/camera-freedom.md`。

Agent 根据 KV、故事和 Placement 在 Level 1/2/3 中选择最合适的镜头自由度。

- `execution_mode=production_video`：直接锁定推荐 Level 并进入 Phase 6；用户已经指定 Level 时按用户值执行。镜头自由度属于专业执行决策，不中断真实视频生产。
- `execution_mode=prompt_only`：用户已经指定 Level 时直接执行；用户未指定时，在交付最终 Prompt 前只询问这一项。

只有无法判断且会改变核心剧情或素材角色的事实缺口才阻塞；普通镜头选择由 Skill 自己收敛。

### Phase 6 — DIRECT

使用已在用户实际 Seedance 项目中验证有效的主节奏作为默认叙事预算：
- **0–1s：起势 / 建立变化**
- **1–3s：事件与戏剧张力明显升级**
- **3–5s：进入高潮区并推进到最终动作落点**

这是节奏骨架，不是动作模板。

“升级”必须来自当前故事的 `PRIMARY_DRAMATIC_CHANGE`，可能是动作、距离、揭示、关系、情绪、系统激活、空间打开、产品功能、环境变化等，不得默认战斗化。

高潮遵循：
> **One Dramatic Climax + Multiple Synchronized Payoffs**

即一个主戏剧高潮，可以让人物表演、资产动作、环境、光效、镜头等在同一因果下同步兑现。

### Phase 7 — AUDIT

先运行主规则自检；发现风险时读取 `references/failure-patterns.md`。

Hard Fail：
- Story Candidate 无法自然生成/经过当前 KV State
- KV State 与 Video Start State 混淆
- Reference Role 与 Placement 冲突
- 关键资产无来源出现/消失/换身份
- 多个互不相关主事件并行
- 只有元素微动，没有事件因果
- 为求稳定把剧情压成动态壁纸
- 非战斗题材被无依据战斗化
- 最后一段无理由提前泄力或机械摆回 KV

失败则内部重写，不输出失败版本。

### Phase 8 — COMPILE

读取 `references/seedance-prompt-compilation.md`。

从已锁 Narrative/Visual Spec 编译：
1. 输出规格与 Reference Binding
2. Protected Truth / Asset Identity / State Continuity
3. Performance、Blocking、Contact 与 Gaze（适用时）
4. 0–1 / 1–3 / 3–5 连续状态变化
5. Camera Geometry / Motion / Composition 与空间可读性
6. Lighting / Material / Atmosphere / Image Formation 的连续变化
7. Primary Dramatic Change 与一个主高潮的同步兑现
8. Perception Hierarchy、项目身份与本图特有失败预防
9. 只保留当前任务必要的模型指令，不复制方法论

### Phase 9 — LINT

交付前必须确认：
- 5 秒内发生了一件完整可读的事
- 有起势、明显升级、主戏剧高潮
- KV 的时间位置和素材参考角色明确
- KV 与故事因果自然整合，而不是硬塞进时间轴
- Asset Identity 稳定，State Transition 连续
- 人物不会因为“稳定”而失去表情和表演
- 镜头符合已锁定的 Camera Level
- 结尾符合 START / PASS_THROUGH / END 的逻辑
- Prompt 可直接复制使用

## Failure Fallback Table

| 触发条件 | 一线修复 | 仍失败兜底 |
|---|---|---|
| 没有可读取图片 | 停止并要求用户提供 KV | 不猜图、不写通用 prompt |
| 无法判断 `SOURCE_ASPECT_RATIO` | 从实际文件尺寸或用户上传信息读取 | 仍不可读则要求重新上传图片 |
| Candidate 无法自然生成/经过 `KV_STATE` | 淘汰该 Candidate；Phase 3 每轮生成 3 个新候选，总计最多 2 轮 | 第二轮必须改变已记录的因果假设；同类失败仍复现则停止并返回缺失条件，不继续生成 |
| `KV_TIME_PLACEMENT` 与 `REFERENCE_ROLE` 冲突 | 回到 Phase 2 重判 Placement，再重跑 `reference-binding.md` | 不输出混合绑定版本 |
| START 方案重新执行 0 秒已成立动作 | 改为从 KV 当前状态继续发展 | 若必须补前因，则改判 PASS_THROUGH / END |
| PASS_THROUGH / END 一开始复制 KV | 重建 `VIDEO_START_STATE` 与 `PRE_KV_STATE` | 无法建立连续路径则淘汰该 Placement |
| 关键道具凭空出现/消失 | 回到 Phase 4 建立道具归属和进入路径 | 无法建立路径则删掉该动作设计 |
| Primary Change 变成战斗/爆炸偏置 | 读取 `dramatic-change-patterns.md`，用当前画面证据重定义变化 | 非战斗题材禁止无依据引入敌人/攻击 |
| 只有头发、火焰、粒子、镜头微动 | 回到 Phase 3 重建事件因果和高潮 | 不能补出事件时停止输出，说明 KV 缺少可用戏剧线索 |
| Camera Level 导致空间关系丢失 | 降一级镜头自由度并重写 Camera Direction | 仍不稳定则锁 Level 1 |
| Prompt 变成补丁墙 | 回到 Phase 8 做 Selective Compilation | 删除与当前图无关的防错条款 |

## Anti-patterns / 不要做什么

- 不要把 KV 默认当成首帧、尾帧或高潮。
- 不要把“锁资产身份”写成“全程锁死姿态和表情”。
- 不要为了稳定把剧情压成动态壁纸。
- 不要只写头发、火焰、粒子、布料、光效和镜头推拉。
- 不要无依据加入敌人、怪物、攻击、爆炸、追逐或新角色。
- 不要让多个角色各演各的，必须服务一条主因果链。
- 不要让关键道具凭空出现、消失、穿模或换归属。
- 不要在 END/PASS_THROUGH 中把 KV 误写成起始状态。
- 不要在最后机械摆回 KV、倒放复位、硬切复位。
- 不要把整套 Skill 方法论复制进最终 Prompt；只编译当前图真正需要的信息。

## Hard Rules

1. **KV 是一个静态故事瞬间，不是默认首帧、默认尾帧或默认高潮。**
2. **Asset Invariants 与 KV State 必须分开；锁身份，不锁死姿态。**
3. **Dramatic Position、KV Time Placement、KV Target Window 是不同决策。**
4. **START 才允许 Video Start State = KV State。**
5. **PASS_THROUGH / END 必须能够从前置状态自然形成 KV。**
6. **任何候选都必须通过 KV Causal Integration Gate：故事必须能够因果连续地解释并生成/经过这张 KV。**
7. **“这张 KV 为什么值得被定格”是 Hero/Peak/广告主视觉的质量加分项，不是所有普通过渡瞬间的硬门禁。**
8. **PRIMARY_DRAMATIC_CHANGE 用自然语言定义；Common Driver Patterns 只是参考，不是枚举。**
9. **一个主事件、一条主因果链、一个主戏剧高潮；允许多个同步视觉兑现。**
10. **不要为了稳定牺牲剧情张力。**
11. **不凭空增加核心角色、核心道具或改写核心世界观。**
12. **Reference Role 必须与 Placement 一致；END/PASS_THROUGH 不得误绑定成起始状态。**
13. **用户未指定画幅时沿用源 KV 比例，不追问。**
14. **真实视频生产由 Skill 自动锁定镜头自由度；Prompt-only 在用户未指定时保留一次 Camera 确认。**
15. **最终交付必须是完整自然语言 Prompt。**

## Reference Loading Map

### Phase-scoped — 首次进入对应阶段时读取
- 接入叙事/视觉合同时 → `references/narrative-visual-integration.md`
- Phase 1 读 KV 时 → `references/kv-reading.md`
- Phase 2 判定时间位置时 → `references/timeline-placement.md` 与 `references/reference-binding.md`
- Phase 3 重构事件时 → `references/narrative-reconstruction.md`
- Phase 4 连续性建模时 → `references/continuity-control.md`
- Phase 8 编译最终 Prompt 时 → `references/seedance-prompt-compilation.md`

这些文件仍是各自专业判断的唯一规则源，但不得在任务开始时一次性预读；返修只重读实际回退阶段及其下游发生变化的 Reference。

### Conditional
- 进入 Camera Gate，或需要重新判断镜头预算 → `references/camera-freedom.md`
- 无法自然定义“这 5 秒究竟什么在变化” → `references/dramatic-change-patterns.md`
- Audit 发现风险或反复失败 → `references/failure-patterns.md`
- 需要参考推导方式 → `references/examples.md`

### Evaluation
- 达尔文评分或回归测试时使用 `test-prompts.json`。
- `test-prompts.json` 只用于验证 skill 效果，不参与正常用户任务输出。

**Reference 是专业判断的单一事实源。SKILL.md 只定义流程与不可违反的总规则；具体判断以对应 Reference 为准，不在 SKILL.md 复制第二套细则。**

## Output Contract

正常最终输出只包含以下结构，不展示内部事实表、状态图、候选比较和 Audit：

```markdown
## 微动画设计
- **剧情核心：** 5 秒完整发生了什么
- **主戏剧变化：** 这一段里什么在持续增强/完成/兑现
- **KV 戏剧位置：** Opening / Mid-story / Peak / Ending
- **KV 时间位置：** Start / Pass-through / End
- **高潮：** 主戏剧高潮
- **镜头：** 已锁定的 Level + 实际策略

## Seedance 素材使用
- **输出画幅：** 源比例或用户指定比例
- **KV 参考角色：** Start Visual / Story Keyframe / Final Visual Target

## Seedance 2.0 完整提示词
[完整自然语言 Prompt，可直接复制使用]
```
