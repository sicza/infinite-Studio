# Seedance Pack — STORY_KEYFRAME_REFERENCE

适用：`KV_TIME_PLACEMENT=PASS_THROUGH`。

## Binding

上传 KV 是故事中段必须自然经过的关键视觉状态，不是首帧。真实生产映射 `reference_to_video`；Prompt 必须明确 Target Window。

## Prompt 必须表达

- `VIDEO_START_STATE` 与 KV 的可见差异；
- 通过哪些连续动作/关系变化在 Target Window 形成 KV；
- KV 出现时哪些空间、接触、视线、道具和构图关系必须可识别；
- 经过 KV 后事件继续发展到真正结果；
- 镜头在经过 KV 时自然形成对应空间关系，不做突然“对齐参考图”。

## Hard Fail

- 0 秒直接复制 KV；
- 到 Target Window 突然吸附成 KV；
- 经过 KV 后重新摆回原状态；
- 把 Reference 当风格图而丢失其中的故事状态。
