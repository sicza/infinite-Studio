# Dramatic Change Patterns — 常见模式，不是分类表

## 用法

只有当 Agent 难以回答“这 5 秒究竟什么在持续变化”时读取本文件。

**先用自然语言定义 PRIMARY_DRAMATIC_CHANGE，再用这些模式辅助检查。不要强迫故事归入某一类。**

常见模式包括但不限于：

| Pattern | “升级”通常意味着 | 高潮可能是什么 |
|---|---|---|
| Action / Motion | 速度、力度、位移、技巧提高 | 突围、命中、极限动作、完成动作 |
| Threat / Pressure | 风险距离、压迫、不可避免性增强 | 威胁逼近极值、关键应对 |
| Discovery / Reveal | 未知信息逐步显露 | 真相/空间/对象完整出现 |
| Activation / System | 联动范围、能量、功能逐级启动 | 系统全链路工作 |
| Transformation | 状态/形态连续变化 | 转变完成 |
| Emotion / Relationship | 心理或关系的可见变化加深 | 决心、信任、和解、恐惧、胜利等兑现 |
| Environment | 风、雨、沙、浪、生态、灯光等状态提高 | 环境波峰或巨变 |
| Product / Feature | 核心功能逐步被看懂 | 功能完成并产生结果 |
| Ritual / Ceremony | 步骤、参与、象征意义逐步完成 | 点火、开启、完成仪式 |
| Puzzle / Construction | 信息/结构逐步拼合 | 解锁、拼合、建成 |
| Performance | 节奏、身体动作、舞台反馈增强 | 完整动作/Pose/节拍峰值 |
| Comedy / Gag | 误会或连锁反应扩大 | 笑点兑现 |

也可以完全不使用以上模式，只要 Primary Dramatic Change 可见、可执行、能形成起势→升级→高潮。

## Anti-Bias

没有画面证据或用户要求时，禁止为了“有高潮”自动加入：
- 敌人
- 攻击
- 爆炸
- 追逐
- 新怪物

高潮可以是 Reveal、关系变化、完成、激活、环境峰值、喜剧兑现、Pose 等。
