# Timeline Placement — KV 在 5 秒里位于哪里

## 三个独立决策

### DRAMATIC_POSITION
描述 KV 在隐含故事中的语义位置，不直接决定它在 5 秒里的时间点：
- **Opening**：事件/动作正准备开始，主要变化尚未真正展开。
- **Mid-story**：事件已经进行，当前状态明显是过程中的一环。
- **Peak**：当前画面本身处在视觉或戏剧强度的高点。
- **Ending**：当前状态更像事件结果、完成态或余势中的最终定格。

分类依据来自姿态、受力、空间关系、状态完成度和画面信息，不因为“KV 通常很漂亮”就默认 Peak/Ending。

### KV_TIME_PLACEMENT
执行位置：START / PASS_THROUGH / END。

### KV_TARGET_WINDOW
PASS_THROUGH 时具体在何时经过：Early / Mid / Peak。

不要把三者合并。

## START

0 秒就是 KV_STATE。

适合：
- KV 明显是准备/起势状态
- KV 已处于持续事件中，向后发展最自然
- 用户明确要求从当前图开始

结构：
> KV → Change → Escalation → New Peak/Result

START 中已经成立的动作不能重新执行。

## PASS_THROUGH

0 秒从 PRE_KV_STATE 开始，中途自然形成/经过 KV_STATE，再继续。

适合：
- KV 是进行时关键状态
- 需要同时补前因和后果
- KV 是高潮中的一帧但不是最终画面

Target Window：
- **Early**：较早的触发/发现状态
- **Mid**：事件中段
- **Peak**：3–5 秒高潮区中的关键帧

时间窗是叙事预算，不要求机械卡点。

## END

完整事件最终自然形成 KV_STATE。

适合：
- KV 明显是动作结果/最终 Hero Moment
- 用户要求“发生什么之后停在这张 KV”

### PEAK_END
KV 本身就是最终高潮：
> Pre-KV → Escalation → Crescendo → KV Peak

### RESOLVED_END
KV 是高潮之后的结果状态：
> Pre-KV → Escalation → Climax → Residual Motion → KV

最后可以自然收束，但必须保留余势，不能完全静止后再摆回 KV。

## Selection Test

依次问：
1. 从 KV 继续是否已经足够完整？若是，优先 START。
2. 是否必须看到前因才能解释 KV？若是，考虑 PASS_THROUGH / END。
3. KV 之后还有比当前状态更自然的结果/高潮吗？若有，PASS_THROUGH；若没有且 KV 是结果，END。

Peak 不自动等于 END；普通过渡瞬间也不需要被强行 Hero 化。
