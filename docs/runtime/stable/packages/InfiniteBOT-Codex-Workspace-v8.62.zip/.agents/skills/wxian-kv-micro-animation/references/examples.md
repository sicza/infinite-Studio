# Examples — 只展示推导方式

## A. 高速追逐 KV（START）

KV 已处于追逐中，角色/载具/武器关系已成立。

- Placement：START
- Primary Dramatic Change：追逐压力不断增大并进入极限应对
- 0–1：从已有高速状态直接启动
- 1–3：驾驶、角色反应、机车/环境同步升级
- 3–5：一个追逐高潮，车辆、人物、能量/烟尘、镜头同步兑现

错误：重新启动车、重新拿出已持有武器；高潮后主动泄力再回 KV。

## B. 举盾 Hero KV（END）

KV：角色单膝跪地、盾牌高举、冲击光照亮人物。

- Placement：END / PEAK_END
- Video Start：角色仍在移动，盾牌位置较低
- Primary Dramatic Change：正面威胁迅速逼近，角色从移动转为正面承受冲击
- 0–1：发现威胁
- 1–3：急停下沉并举盾
- 3–5：冲击达到峰值，动作轨迹自然形成 KV

Asset 一直稳定；Pose 是故事形成的。

## C. 探索过渡 KV（PASS_THROUGH）

KV：人物推开遗迹大门，身体探入一半。它不是整段故事最 Hero 的一帧。

- Placement：PASS_THROUGH / Mid
- Primary Dramatic Change：封闭空间逐步被打开并揭示地下城市
- 0–1：人物接近门缝，发现内部异常光线
- 1–3：推门并自然经过 KV 的半进入状态
- 3–5：门完全打开，地下城市完整 Reveal 成为高潮

这个 Candidate 通过 Causal Integration Gate，因为故事自然生成 KV；不需要证明 KV 是全片最值得定格的一帧。

## D. 关系变化 KV（非枚举驱动）

KV：两个人隔桌相视，一人伸出手，另一人尚未回应。

Primary Dramatic Change：
> 两人的关系从戒备逐渐转向信任。

故事可以通过眼神、呼吸、手部距离、身体姿态和环境安静程度推进，不需要敌人、爆炸或强动作。
