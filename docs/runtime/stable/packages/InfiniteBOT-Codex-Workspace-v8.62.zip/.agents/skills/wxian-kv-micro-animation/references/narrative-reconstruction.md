# Narrative Reconstruction — 补全被冻结瞬间的完整故事

## 核心问题

不是“给图加什么动作”，而是：

> 什么变化使这一帧产生？这一帧之后还需要什么变化才能完成事件？

## 1. PRIMARY_DRAMATIC_CHANGE

为每个候选用一句自然语言定义：

> **这 5 秒里，什么在持续变化、增强、完成或兑现？**

示例：
- “追逐压力不断逼近，最终迫使主车极限突围”
- “封闭空间逐步被打开，最终揭示地下城市”
- “两个人从戒备逐渐转向信任”
- “失效机械逐级恢复，最终完全启动”
- “舞者从蓄势进入完整动作并落到最终 Pose”

不要求归入固定枚举。

## 2. Backward Reconstruction

Placement 为 PASS_THROUGH / END 时建立 `PRE_KV_STATE`：

1. 从 KV 姿势/状态寻找最短合理前置动作。
2. 从受力、视线、空间关系判断直接原因。
3. 只向前推 1–2 个必要状态，不无限编设定。
4. 验证 `PRE_KV_STATE → KV_STATE` 物理/空间/道具连续。

## 3. Forward Reconstruction

Placement 为 START / PASS_THROUGH 时寻找：
- 未完成动作
- 尚未解决的目标/关系
- 正在变化的系统/环境
- 即将揭示/接触/完成的对象

再建立：
> Current/KV State → Development → Escalation → Peak/Result

## 4. Story Candidate

内部至少 3 个候选。差异必须是故事机制不同，而不是换措辞。

每个候选记录：
- Primary Dramatic Change
- Placement / Target Window
- Video Start State
- Trigger
- Pre-KV Chain（需要时）
- KV Moment
- Post-KV Chain（需要时）
- Dramatic Climax
- Final State

## 5. KV CAUSAL INTEGRATION GATE — 硬门禁

每个候选必须回答：

> **这条因果链能否自然、连续地生成或经过当前 KV 的具体状态？**

检查：
- 人为什么形成当前姿势/视线？
- 道具为什么在当前位置？
- 车辆/产品/场景为什么处于当前状态？
- 主体为什么形成当前空间关系？
- 这一帧在故事中具体承担什么作用？

任何一项只能靠“最后突然复位/摆 Pose/无解释出现”解决 → Candidate 淘汰。

## 6. KV MOMENT VALUE — 条件质量项

当 KV 明显是 Hero / Peak / 广告主视觉时，再问：

> 为什么这一帧值得被定格？故事是否强化了它的角色、世界、玩法或产品价值？

这是质量加分项，不是普通过渡帧的普遍硬门禁。

## 7. Candidate Selection

通过 Causal Integration Gate 后比较：
- Narrative Fit
- Backward/Forward Causality
- Dramatic Escalation
- Climax Strength
- KV Moment Value（适用时）
- Continuity
- Seedance Feasibility

Seedance Feasibility 不是“越少动作越好”。在资产稳定、状态连续的前提下，不要选择明显更平庸的方案只因为它更保守。

## 8. Story Budget

默认：
- 1 个 Primary Event
- 1 条 Main Causal Chain
- 1 个 Dramatic Climax

高潮可以有多个同步兑现：人物、资产、环境、光效、镜头等一起服务同一个高潮。

## 9. 5 秒节奏

默认：
- **0–1s：起势**——变化立即成立
- **1–3s：升级**——Primary Dramatic Change 明显推进
- **3–5s：高潮区**——主要变化兑现并推到最终动作落点

RESOLVED_END 可以在高潮后保留短促余势自然形成 KV，但不能变成等待。
