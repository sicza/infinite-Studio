---
name: wxian-delivery-audit
description: 对高风险交付做独立语义冷审，或对已完成、返工、异常需求做证据化复盘；检查状态、真实文件、manifest、反馈回流与项目规则是否一致，并只从真实证据提出回流节点或可复用规则候选。按需调用，不是普通任务必经流程。
---

# 独立交付审计

独立核对 request 状态、真实文件、manifest、lineage、反馈与交付结果是否一致。

## 触发

以下任一情况才值得调用：

- 多文件/多尺寸/多语言/套图交付；
- 同一产物已返修多轮；
- 状态与真实文件有疑点；
- 高价值正式交付；
- 用户明确要求独立复查；
- 用户要求复盘已完成、返工或异常需求，解释问题证据、正确回流节点或可沉淀规则。

普通单文件、低风险且主 Skill 已完成真实检查时不强制调用。

## 最小读取

默认只读当前请求：`request.md`、`state.json`、`work/final-review.md`、`work/delivery-manifest.json`、`output/manifest.json`、当前活动 revision 的真实文件，以及当前反馈/根因记录（若有）。

只有某个发现无法判断时才继续读取对应 Baseline Floor / Family / 身份卡或上游专业产物；不通读历史、不重新做整套视觉策划。

## 审计顺序

1. **状态真实性**：`completed` 是否真的存在可用 output；active/revision 是否一致。
2. **交付一致性**：delivery manifest、output manifest、真实文件 Hash 以及 `role/locale/size` 是否一致；`wxian-image-production` 一律复跑与 Promote 相同的 `delivery_gate.py`，由 `production_branch` 决定契约；完整新图确认 `base → localized model edit → resized operation → placement/composite operation → final` 的真实边 lineage、默认地区 LOGO placement 与 no-logo 例外证据都没有被绕过。缺件、空文件、角色/语言/尺寸漂移、伪造 final 或旧 revision 混入必须指出。
3. **审核真实性**：`final-review.md` 声称检查的对象是否就是当前实际文件；不能用旧图审核结论覆盖新图。
4. **反馈闭环**：存在 must-fix/结构性反馈时，是否真正进入本 revision；不能只改状态或说明文字。
5. **项目规则**：只有任务实际使用 Baseline 时，核对 Baseline Hash、消费模式、实际 Family / Floor / Character 与产物决定是否一致；`novel-direction` 不能被当成违规，只需证明项目身份与 Floor 未失守。
6. **专业缺口**：若发现的是审美/视觉质量问题，指出应调用 `$wxian-visual-scorecard` 或返回具体生产 Skill，本 Skill 不重新发明评分标准。

## 输出

写 `work/delivery-audit.md`，冷审与复盘共用一份短输出，不另造 Review 状态机。只包含：

```text
status: passed | passed_with_findings | blocked
scope: 实际检查对象
findings: 按 blocking / material / minor 排序，每项带真实证据
return_to: governance | image-production | layer-decomposition | visual-packaging | none
```

没有问题时只返回简短通过结论。若多轮返修暴露了可复用的流程/项目规则，可附 `reusable_rule_candidate`，但必须引用当前真实证据；它只是候选，不自动修改 Baseline、Skill 或 `.agents/`。

`blocked` 只用于会导致错误/缺失交付的真实问题；改进空间但不破坏交付一致性的内容不能伪装成阻断。

需要机械校验 manifest/hash 时运行：

```powershell
python .agents/skills/wxian-delivery-audit/scripts/delivery_audit.py --request <request-dir> --workspace-root .
```

脚本只检查客观一致性；语义判断仍由本 Skill 完成。
