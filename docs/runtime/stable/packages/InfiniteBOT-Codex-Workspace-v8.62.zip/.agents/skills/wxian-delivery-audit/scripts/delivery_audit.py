#!/usr/bin/env python3
from __future__ import annotations
import os as _bytecode_guard_os, sys as _bytecode_guard_sys
_bytecode_guard_sys.dont_write_bytecode = True
_bytecode_guard_os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
import argparse, hashlib, json, subprocess, sys
from pathlib import Path


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding='utf-8'))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--request', type=Path, required=True)
    ap.add_argument('--workspace-root', type=Path, default=Path.cwd())
    a = ap.parse_args()
    root = a.workspace_root.resolve()
    req = (root / a.request).resolve() if not a.request.is_absolute() else a.request.resolve()
    try:
        req.relative_to(root)
    except ValueError:
        print(json.dumps({'status':'blocked','findings':['request outside workspace']}, ensure_ascii=False)); return 1
    findings=[]
    required=[req/'state.json', req/'work/final-review.md', req/'work/delivery-manifest.json', req/'output/manifest.json']
    for p in required:
        if not p.is_file() or p.stat().st_size == 0:
            findings.append(f'missing_or_empty:{p.relative_to(root).as_posix()}')
    if findings:
        print(json.dumps({'status':'blocked','findings':findings}, ensure_ascii=False, indent=2)); return 1
    state=load(req/'state.json'); out=load(req/'output/manifest.json'); work=load(req/'work/delivery-manifest.json')
    if state.get('status') != 'completed': findings.append('state_not_completed')
    revision=state.get('revision')
    if out.get('active_revision') != revision: findings.append('active_revision_mismatch')
    work_files=work.get('files') if isinstance(work,dict) else None
    if not isinstance(work_files,list) or not work_files:
        findings.append('work_manifest_files_missing')
        expected=[]
    else:
        expected=[]
        for item in work_files:
            if not isinstance(item,dict) or not item.get('active'):
                continue
            rel=str(item.get('source','')); p=(root/rel).resolve() if rel and not Path(rel).is_absolute() else Path(rel)
            try: p.relative_to(req/'work')
            except ValueError: findings.append(f'work_source_outside_request:{rel}'); continue
            if not p.is_file() or p.stat().st_size == 0:
                findings.append(f'missing_work_source:{rel}'); continue
            actual=sha256(p)
            if item.get('sha256') != actual: findings.append(f'work_hash_mismatch:{rel}')
            expected.append((str(item.get('role','')),str(item.get('locale','')),str(item.get('size','')),actual))
    files=out.get('files')
    actual_lineage=[]
    if not isinstance(files,list) or not files: findings.append('manifest_files_missing')
    else:
        for item in files:
            if not isinstance(item,dict): findings.append('invalid_file_record'); continue
            rel=str(item.get('path',''))
            p=(root/rel).resolve() if rel and not Path(rel).is_absolute() else Path(rel)
            try: p.relative_to(req)
            except ValueError: findings.append(f'file_outside_request:{rel}'); continue
            if not p.is_file() or p.stat().st_size == 0: findings.append(f'missing_output:{rel}'); continue
            actual_hash=sha256(p)
            if item.get('sha256') != actual_hash: findings.append(f'hash_mismatch:{rel}')
            actual_lineage.append((str(item.get('role','')),str(item.get('locale','')),str(item.get('size','')),actual_hash))
    if sorted(expected) != sorted(actual_lineage): findings.append('delivery_lineage_mismatch')
    if state.get('primary_skill') == 'wxian-image-production':
        gate=Path(__file__).resolve().parents[2]/'wxian-image-production/scripts/delivery_gate.py'
        cp=subprocess.run([sys.executable,str(gate),'--request',req.relative_to(root).as_posix(),'--workspace-root',str(root)],capture_output=True,text=True,encoding='utf-8')
        if cp.returncode != 0:
            try:
                detail=json.loads(cp.stdout).get('reason','delivery gate failed')
            except json.JSONDecodeError:
                detail='delivery gate failed'
            findings.append(f'production_lineage_invalid:{detail}')
    expected_review=out.get('final_review_sha256')
    if expected_review and expected_review != sha256(req/'work/final-review.md'):
        findings.append('final_review_hash_mismatch')
    status='passed' if not findings else 'blocked'
    print(json.dumps({'status':status,'findings':findings},ensure_ascii=False,indent=2))
    return 0 if not findings else 1

if __name__ == '__main__':
    raise SystemExit(main())
