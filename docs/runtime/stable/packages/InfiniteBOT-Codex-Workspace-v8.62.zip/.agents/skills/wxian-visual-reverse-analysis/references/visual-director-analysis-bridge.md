# Visual Director Analysis Bridge

用于单图逆向分析的结构化观察词典。事实仍以真实图像为准。

优先检查：

1. `WORLD/SPACE`：主体在哪里、尺度参照、前中后景、拓扑和遮挡；
2. `PERFORMANCE`：姿态、重心、接触、视线、动作因果；
3. `PROJECTION`：镜头高度/距离/方向、透视、裁切、消失线、构图压力；
4. `APPEARANCE`：主辅光、明暗边界、材质响应、表面与空气；
5. `IMAGE STRUCTURE`：value/color/detail/negative-space 的分配；
6. `IMAGE FORMATION`：焦点、景深、运动、镜头/后期可见特征；
7. `PERCEPTION`：第一读点、第二读点、缩略图可读性、信息抑制；
8. `IDENTITY/COHERENCE`：哪些是项目身份、哪些只是一次性风格信号；
9. `GRAPHIC`：文案、LOGO、UI、图形与主体的层级和关系。

每条输出仍必须落回：`可见事实 → 专业判断 → 可迁移机制/不确定项`。禁止只写模块名或抽象审美词。
