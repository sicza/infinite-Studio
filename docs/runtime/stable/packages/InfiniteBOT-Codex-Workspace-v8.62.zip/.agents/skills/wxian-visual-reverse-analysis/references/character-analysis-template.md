# 单图逆向视觉解构：{image_name}

## 1. 源绑定

source_path: `project/...`
source_sha256: `<sha256>`
source_kind: `character|reference|game-screenshot|other-asset`
source_label: `<源文件 stem>`
character_id: `<stable-id|none>`
identity_authority: `canonical-character-asset|reference-only|none`
image_type:
analysis_purpose:
dimensions:
evidence_role: `canonical-identity`
provenance: `project canonical asset`
authority_scope: `identity only`
analysis_contract_version: `2`
analysis_contract_sha256: `<contract hash>`
reverse_analysis_skill_version: `<runtime version>`
visual_grounding_gate_version: `2`

## 2. 故事性画面描述

## 3. 核心主题、构图与镜头

### 3.1 主题、主体与信息层级
### 3.2 视觉焦点与画面动线
### 3.3 构图、主体位置与占比
### 3.4 镜头、透视与裁切
### 3.5 文字、LOGO、UI 与包装区域

## 4. 视觉风格与质感

### 4.1 画风与渲染方式
### 4.2 材质、纹理、边缘与细节密度
### 4.3 色彩面积、明度、冷暖与对比
### 4.4 光源因果、投影、反射与后期

## 5. 角色动作与神态

## 6. 角色身份反推

identity_label: `<角色源必须等于 source_label；其他写 none>`
character_id: `<角色源 stable-id；其他写 none>`
identity_authority: `canonical-character-asset|reference-only|none`
face_shape_skin:
eyes_brows:
hair_structure_color:
outfit_silhouette:
equipment_signature:

### 6.1 永久身份锚点
### 6.2 当前形态锚点
### 6.3 允许变化与禁止漂移
### 6.4 最高价值垫图锚点

- <角色源 3–6 条；其他图写 not_applicable>

## 7. 远景、中景与近景

### 7.1 远景
### 7.2 中景
### 7.3 近景

## 8. 可复用中文正向 Phrase

- <角色图 6–12 条；其他图 8–16 条；每条只写本图真实可见的对象、机制和结果>

## 9. 完整中文正向反推提示词

## 10. 单图可复用价值

## 11. 事实、判断与不确定项

### 11.1 可见事实
### 11.2 专业判断
### 11.3 不确定项

## 12. 上层 Skill 可用摘要

### 12.1 可进入项目风格索引的候选项
### 12.2 只能作为单图参考的特征
### 12.3 不得进入项目级标准的内容
