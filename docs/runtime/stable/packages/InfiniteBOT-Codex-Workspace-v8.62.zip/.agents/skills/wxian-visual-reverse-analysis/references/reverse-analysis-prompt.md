# 固定识图任务

只分析当前打开的一张真实图片。

先判断 source_kind：

- character：提取身份锁、当前形态、必须保持、可变项、禁止混用和垫图锚点；
- reference / game-screenshot / other-asset：提取视觉钩子、叙事/玩法可读性、构图/镜头/空间、色光/材质、UI/包装、可迁移视觉机制与不可继承边界；禁止输出角色身份章节。

任何结论都必须能指向当前图可见内容。不要用“高级、电影感、细节丰富”代替具体视觉机制。

Reference/KV 必须先完成盲重建，再写迁移结论。正文必须逐项记录主体图谱、位置与占比、遮挡、动作/视线/道具方向、远中近景、镜头与透视、文字/UI 的准确位置、色彩面积和主光因果，并把“可见事实 / 专业判断 / 不确定项”分开。若只读正文无法恢复谁、在哪里、做什么、朝哪、与什么发生关系以及第一/第二读点，则本次分析失败，不能用通用形容词补齐。


## 视觉机制覆盖检查

Reference/KV 分析结束前，用 Visual Director 的九类观察轴做**缺口检查而不是填表**：`WORLD/SPACE / PERFORMANCE / PROJECTION / APPEARANCE / IMAGE STRUCTURE / IMAGE FORMATION / PERCEPTION / IDENTITY / GRAPHIC`。只补当前图真实存在且会改变下游复现的机制；每项仍写成“可见事实 → 专业判断 → 可迁移机制/不确定项”。
