# Reference Analysis: {image_name}

## 1. 源绑定
source_path: `project/...`
source_sha256: `<sha256>`
source_kind: `reference|game-screenshot|other-asset`
source_label: `<stem>`
character_id: `none`
identity_authority: `reference-only|none`
evidence_role: `external-reference|historical-project-output|gameplay-evidence|unknown`
provenance: `<where this image came from; do not infer from visual style>`
authority_scope: `<what this source may prove>`
dimensions: `<WxH>`
analysis_contract_version: `2`
analysis_contract_sha256: `<contract hash>`
reverse_analysis_skill_version: `<runtime version>`
visual_grounding_gate_version: `2`

## 2. 故事性画面描述
story:
blind_reconstruction: <只读本分析时，能复述谁/在哪里/做什么/朝哪/与什么发生关系/第一读点/第二读点>

## 3. 核心主题、构图与镜头
### 3.1 主题、主体与信息层级
subject_map: <逐个列出主体、道具、UI/文字及其职责>
focal_hierarchy: <第一读、第二读、第三读，并说明可见依据>
### 3.2 视觉焦点与画面动线
visual_route: <视线从哪里进入，经由哪些对象，落到哪里>
### 3.3 构图、主体位置与占比
composition_coordinates: <主体所在象限/相对中心、占画比例、前后遮挡与裁切>
### 3.4 镜头、透视与裁切
camera: <景别、机位高度、视角、透视/消失点、焦平面、裁切>
### 3.5 文字、LOGO、UI 与包装区域
text_ui: <文字/数字/Logo/UI 的准确位置、方向、大小、与场景的空间关系>

## 4. 视觉风格与质感
### 4.1 画风与渲染方式
rendering:
### 4.2 材质、纹理、边缘与细节密度
material_fx:
### 4.3 色彩面积、明度、冷暖与对比
color_light:
### 4.4 光源因果、投影、反射与后期
light_causality: <主光方向、轮廓光、阴影、雾/反射/动态模糊的可见证据；制作方式不确定时标未知>
finish:

## 5. 角色动作与场景关系
actions: <逐个主体的姿态、手部/武器方向、视线、运动方向和相互关系>
environment_role: <环境如何承担路径、尺度、玩法或叙事信息>

## 6. 远景、中景与近景
### 6.1 远景
### 6.2 中景
### 6.3 近景

## 7. 可复用中文正向 Phrase
- <8–16 条；每条必须是当前图具体对象/空间关系 → 视觉机制 → 可见结果>

## 8. 完整中文正向反推提示词
positive_prompt:

## 9. 单图可复用价值
transferable_mechanisms: <哪些方法可迁移，必须保留因果>
best_for:
avoid_when:

## 10. 不可继承与边界
identity_boundary:
do_not_inherit:
single_image_only:

## 11. 事实、判断与不确定项
### 11.1 可见事实
### 11.2 专业判断
### 11.3 不确定项

## 12. 上层 Skill 可用摘要
family_candidates:
production_use:
authority_boundary:
