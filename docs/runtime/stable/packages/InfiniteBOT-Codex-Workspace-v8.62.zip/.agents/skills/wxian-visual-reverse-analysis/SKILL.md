---
name: wxian-visual-reverse-analysis
description: 对单张真实图片做用途特异的逆向视觉解构。角色资产只解决身份锁定；KV/Banner/Reference 只解决视觉钩子、构图、镜头、叙事、色光、玩法/UI叠层、包装与可迁移机制。禁止用同一套角色模板分析所有图片。
---

# 单图视觉反推

进入前执行 `$workspace-governance consume-personal-context --request <request> --consumer wxian-visual-reverse-analysis`；阻断则停止。


新建用户需求先由 `$workspace-demand-intake` 按本类型最小 Contract 收集并锁定输入；本 Skill 不重复追问 Intake 已知字段，也不把自身专业判断转嫁给用户。
一次只打开并分析一张真实目标图：Baseline 内由 Source Manifest 指定；独立 request 由当前 `request/input/` 与 Source Lock 指定。多图需求逐张完成后再汇总，不得从 contact sheet 批量套写。若输入对象本身是视频，不把它强塞进单图模板：独立“分析视频”路由 `$wxian-video-source-analysis`；本 Skill 作为其他 request 的图片反推能力时，可消费 `$wxian-video-source-analysis` 已验证的代表帧。

## 1. 先判断图片职责

### character
目标不是“描述好看”，而是建立可用于生成的一致性身份锁：

- 脸型/肤色、眼睛/眉形、发型结构与发色分区；
- 年龄感、体型和比例；
- 服装大形/长度/开合/层次与主辅色块；
- 标志配件、武器、装备连接；
- 身体与服装外轮廓；
- 必须保持 / 可变 / 禁止混用；
- 3–6 个最高价值垫图锚点；
- 结论必须足以支持后续角色卡对 canonical 原图做二次核验。

使用 [character-analysis-template.md](references/character-analysis-template.md)。

### reference / game-screenshot / other-asset
目标不是识别人是谁，而是提取“这张图为什么成立、哪些机制值得迁移”。至少回答：

- 第一眼钩子是什么；
- 故事或玩法信息如何被一帧看懂；
- 主体、UI/数字/道具、环境的优先级；
- 镜头、透视、前中后景和动线；
- 色彩、光源、材质、烟火/粒子/速度等完成语言；
- 文案、LOGO、UI 的位置和占比；
- 8–16 条图像特异的可迁移视觉机制；
- 什么只能借方法，不能继承身份、品牌、角色、文案或一次性细节；
- 一段可直接拼进生产 Prompt 的正向视觉组件。

使用 [reference-analysis-template.md](references/reference-analysis-template.md)。Reference 必须达到“盲重建”标准：只读分析正文，另一位 Agent 应能恢复谁/在哪里/做什么/朝哪/空间如何延伸/第一与第二读点。**Reference 不再填写“角色身份反推”，但必须填写主体图谱、动作关系、远中近景、可见事实/专业判断/不确定项和完整反推 Prompt。**

对 reference / KV / game-screenshot / other-asset 的结构化解构，额外读取 `references/visual-director-analysis-bridge.md`，以 `$sicza-visual-director DIAGNOSE` 的模块语言组织**可观察机制**。该调用只帮助辨认空间、表演、投影、光材质、图像结构/形成、感知与身份/图形关系，不允许把逆向分析变成重新设计，也不允许用模块术语替代真实图像证据。

## 2. 源绑定

两类模板的第一节都必须精确绑定：

```text
source_path:
source_sha256:
source_kind:
source_label:
character_id:
identity_authority:
dimensions:
evidence_role:
provenance:
authority_scope:
analysis_contract_version:
analysis_contract_sha256:
reverse_analysis_skill_version:
visual_grounding_gate_version:
```

- `character` → `identity_authority: canonical-character-asset`
- `reference` → `identity_authority: reference-only`
- 其他 → `none`

Reference 中即使出现与项目角色相似的人，也不能成为项目角色身份来源。

## 3. 可迁移视觉机制

每条必须写成“**具体对象/空间关系 → 视觉机制 → 可见结果**”，不能只写抽象形容词。

合格：

```text
前景摩托前轮以超近景放大并向画外切出，配合道路消失线把速度轴压向画面深处，使追逐感在缩略图仍然成立
红蓝半透明数值牌卡在人物逃跑路径中央，以互补高亮色把“选择/收益”玩法从复杂城市背景中分离出来
巨型圆盘占据画面约三分之二，人物缩到下方作为比例尺，让谜题本体先于角色成为点击钩子
```

不合格：

```text
电影感强
高级写实
画面有冲击力
角色互动丰富
```

## 4. 失败边界

以下任一成立即重做：

- Reference 仍套用角色分析章节；
- 场景/KV 没有写镜头、层级、空间、视觉钩子、动作关系、远中近景和可迁移机制；
- 多张图只替换角色名、场景名或形容词；
- 描述与真实图像明显错绑；
- 把 Reference 角色、LOGO、文案或品牌当成项目事实；
- 输出很长，但下游仍不知道“这张图具体能拿来做什么”。
- 只把通用句式换了几个主体名，Swap Test 仍可套到另一张图。
- 缺少可见事实与专业判断的边界，或把制作方式猜测写成事实。

## 5. 输出与交付

### 作为 Baseline 内部能力

当调用方是 `$wxian-visual-baselines` 时，分析文件写入调用方指定的 `work/single-analysis/**`，并通过：

```bash
python .agents/skills/wxian-visual-baselines/scripts/baseline_gate.py validate-single-analysis --request <baseline-request> --analysis <analysis-path> --workspace-root .
```

本 Skill 不创建第二 request、不写自己的 delivery manifest、不 Promote；由 Baseline 主 Skill继续聚合和发布。

### 作为独立用户需求

当当前 request 的 `primary_skill=wxian-visual-reverse-analysis` 时：

1. 最终分析只保留一份，写入 `work/final/reverse-analysis.md`；多张目标图时每张独立分析后在同一文件中按源图分节，不套写。
2. `work/final-review.md` 只核对：目标图绑定/Hash、图片职责、事实与判断是否分离、可迁移机制是否图像特异、是否误继承 Reference 身份/品牌。
3. `work/delivery-manifest.json` 至少把 `work/final/reverse-analysis.md` 作为 active 文件，`role=reverse_analysis`，Hash 必须真实匹配。
4. 由 `$workspace-governance promote` 发布。不得调用 Baseline 的 `validate-single-analysis` 充当 standalone completion gate。
