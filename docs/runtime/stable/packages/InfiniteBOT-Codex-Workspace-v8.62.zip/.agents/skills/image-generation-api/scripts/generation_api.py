#!/usr/bin/env python3
"""Execute explicitly configured Gemini, GPT Images, or Seedance requests."""

from __future__ import annotations
import os as _bytecode_guard_os, sys as _bytecode_guard_sys
_bytecode_guard_sys.dont_write_bytecode = True
_bytecode_guard_os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import argparse
import base64
import binascii
import getpass
import hashlib
import io
import importlib.util
import ipaddress
import json
import re
import mimetypes
import os
import re
import stat
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.request
import uuid
from pathlib import Path

LIB = Path(__file__).resolve().parents[3] / 'lib'
if str(LIB) not in sys.path:
    sys.path.insert(0, str(LIB))
from project_materials import indexed_project_source
from production_contract import ProductionContractError, production_branch, validate_source_lock
from gpt_image_contract import (
    DEFAULT_GPT_IMAGE_MODEL,
    GPT_BACKGROUNDS,
    GPT_IMAGE_2,
    GPT_IMAGE_25_FLARE,
    GPT_IMAGE_25_MODELS,
    GPT_IMAGE_25_SUNBURST,
    GPT_IMAGE_MODELS,
    GPT_MODERATIONS,
    GPT_OUTPUT_FORMATS,
    default_parameters as gpt_default_parameters,
    model_scoped_text_applies,
    resolve_gpt_request,
    validate_resolved_gpt_request,
    validate_gpt_model,
    validate_gpt_quality,
    validate_gpt_size,
)
from presentation_contract import PresentationError, carrier_receipt, require_clean_prompt
from typing import Any, Callable
from urllib.parse import quote, urljoin, urlparse

SKILL_ROOT = Path(__file__).resolve().parents[1]
WORKSPACE_ROOT = SKILL_ROOT.parents[2]
DEFAULT_CONFIG = SKILL_ROOT / "config" / "api-runtime.json"
DEFAULT_CREDENTIAL_STORE = ".agents/runtime/credentials.json"
CREDENTIAL_FIELD = "generation_api_key"
PROFILE_NAMES = ("gemini", "gpt", "seedance")
CURRENT_GEMINI_IMAGE_MODEL = "gemini-3.1-flash-image-preview"
GEMINI_ASPECT_RATIOS = {"1:1", "3:2", "2:3", "3:4", "4:3", "4:5", "5:4", "9:16", "16:9", "21:9"}
DEFAULT_SEEDANCE_RESOLUTION = "1080p"
DEFAULT_SEEDANCE_GENERATE_AUDIO = True
IMAGE_MODES = {"text_to_image", "reference_to_image", "image_to_image_edit"}
VIDEO_MODES = {
    "text_to_video",
    "image_to_video_first_frame",
    "image_to_video_first_last_frame",
    "reference_to_video",
}
DIRECT_IMAGE_CALLERS = {
    "sicza-game-concept-lab": "concept-generation",
    "wxian-visual-packaging": "packaging-validation",
    "wxian-visual-competitive-analysis": "competitive-visualization",
    "wxian-conducting-internet-research": "research-visualization",
    "wxian-image-layer-decomposition": "kv-layer-reconstruction",
    "wxian-game-ui-layer-decomposition": "game-ui-layer-reconstruction",
}
CALL_RECEIPT_SCHEMA = "wxian.generation-call.v3"
SERVICE_REQUEST_ID_STATUSES = {"provided", "provider_not_supplied"}
LAYER_SOURCE_CONTRACT_FIELDS = {"layer_plan_path", "layer_plan_sha256", "source_image_path", "source_sha256", "work_source_path", "work_sha256", "source_canvas_size", "delivery_canvas_size", "work_canvas_size", "size_contract"}
KV_RECONSTRUCTION_STRATEGIES = {"source_locked_reconstruct", "clean_plate_patch", "model_native_alpha"}
KV_PROMPT_MANIFEST_SCHEMA = "wxian.kv-layer-prompt-manifest.v1"
UI_RECONSTRUCTION_STRATEGIES = {"scene_clean_patch", "control_reconstruct", "text_strip_reconstruct", "model_native_alpha"}
UI_PROMPT_MANIFEST_SCHEMA = "wxian.game-ui-layer-prompt-manifest.v1"


class ApiError(RuntimeError):
    pass


class ApiTimeout(ApiError):
    pass


class AmbiguousRemoteState(ApiError):
    pass


class PollingPaused(ApiError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ApiError(message)


def load_local_module(path: Path, module_name: str, label: str):
    """Load one Workspace-local gate module without mutating project runtime state."""
    require(path.is_file(), f"{label} unavailable")
    spec = importlib.util.spec_from_file_location(module_name, path)
    require(spec is not None and spec.loader is not None, f"{label} unavailable")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path, label: str = "JSON") -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ApiError(f"{label} file not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ApiError(f"invalid {label} at line {exc.lineno}, column {exc.colno}") from exc
    require(isinstance(value, dict), f"{label} root must be an object")
    return value


def validate_url(value: str, *, allow_insecure_http: bool, label: str) -> str:
    parsed = urlparse(value)
    require(parsed.scheme in {"http", "https"} and bool(parsed.hostname), f"{label} must be an absolute HTTP(S) URL")
    require(parsed.username is None and parsed.password is None, f"{label} must not contain credentials")
    if parsed.scheme == "http" and not allow_insecure_http:
        host = str(parsed.hostname)
        try:
            loopback = ipaddress.ip_address(host).is_loopback
        except ValueError:
            loopback = host.lower() == "localhost"
        require(loopback, f"{label} requires HTTPS unless allow_insecure_http is explicitly enabled")
    return value


def validate_relative_path(value: Any, field: str, placeholder: str | None = None) -> str:
    text = str(value or "").strip()
    require(bool(text), f"profile requires {field}")
    parsed = urlparse(text)
    require(not parsed.scheme and not parsed.netloc and not text.startswith("//"), f"{field} must be relative to base_url")
    if placeholder:
        require(placeholder in text, f"{field} must contain {placeholder}")
    return text


def load_config_root(path: Path) -> dict[str, Any]:
    value = read_json(path, "API runtime config")
    require(set(value) == {"connection", "profiles", "limits"},
            "API runtime config contains missing or unnecessary fields")
    connection = value.get("connection")
    require(isinstance(connection, dict), "API runtime config requires connection")
    require(set(connection) == {"base_url", "auth_mode", "credential_store", "allow_insecure_http"},
            "connection contains missing or unnecessary fields")
    profiles = value.get("profiles")
    require(isinstance(profiles, dict), "API runtime config requires profiles")
    require(set(profiles) == set(PROFILE_NAMES), "profiles must contain exactly gemini, gpt, and seedance")
    base_url = str(connection.get("base_url", "")).strip()
    require(bool(base_url), "connection.base_url is empty")
    allow_insecure = connection.get("allow_insecure_http", False)
    require(isinstance(allow_insecure, bool), "connection.allow_insecure_http must be boolean")
    base_url = validate_url(base_url, allow_insecure_http=allow_insecure, label="connection.base_url")
    auth_mode = str(connection.get("auth_mode", "")).strip()
    credential_store = str(connection.get("credential_store", "")).strip()
    require(auth_mode in {"bearer", "x-goog-api-key"}, "connection.auth_mode must be bearer or x-goog-api-key")
    require(credential_store == DEFAULT_CREDENTIAL_STORE, f"connection.credential_store must be {DEFAULT_CREDENTIAL_STORE}")
    limits = value.get("limits")
    require(isinstance(limits, dict), "limits must be an object")
    limit_fields = {"media_download_timeout_seconds", "max_json_bytes", "max_image_bytes", "max_video_bytes"}
    require(set(limits) == limit_fields, "limits contains missing or unnecessary fields")
    clean_limits: dict[str, int] = {}
    for field in limit_fields:
        raw = limits[field]
        require(isinstance(raw, int) and not isinstance(raw, bool) and raw > 0, f"limits.{field} must be a positive integer")
        clean_limits[field] = raw
    return {
        "connection": {
            "base_url": base_url,
            "auth_mode": auth_mode,
            "credential_store": credential_store,
            "allow_insecure_http": allow_insecure,
        },
        "profiles": value["profiles"],
        "limits": clean_limits,
    }


def load_profile(root: dict[str, Any], name: str) -> dict[str, Any]:
    require(name in PROFILE_NAMES, f"unsupported api_profile: {name}")
    raw = root["profiles"].get(name)
    require(isinstance(raw, dict), f"missing profile: {name}")
    expected_protocol = {
        "gemini": "openai-images-gemini",
        "gpt": "openai-images",
        "seedance": "seedance-videos",
    }[name]
    protocol = str(raw.get("protocol", "")).strip()
    require(protocol == expected_protocol, f"{name}.protocol must be {expected_protocol}")
    default_model = str(raw.get("default_model", "")).strip()
    require(bool(default_model), f"{name}.default_model is empty")
    if name == "gemini":
        require(default_model == CURRENT_GEMINI_IMAGE_MODEL,
                f"gemini.default_model must be {CURRENT_GEMINI_IMAGE_MODEL}")
    elif name == "gpt":
        require(default_model == DEFAULT_GPT_IMAGE_MODEL,
                f"gpt.default_model must be {DEFAULT_GPT_IMAGE_MODEL}")
    connection = root["connection"]
    profile: dict[str, Any] = {
        "name": name,
        "protocol": protocol,
        "base_url": connection["base_url"],
        "default_model": default_model,
        "auth_mode": connection["auth_mode"],
        "credential_store": connection["credential_store"],
        "allow_insecure_http": connection["allow_insecure_http"],
    }
    if name == "gemini":
        require(set(raw) == {"protocol", "generation_path", "edit_path", "default_model", "request_timeout_seconds"},
                "gemini profile contains missing or unnecessary fields")
        profile["generation_path"] = validate_relative_path(raw.get("generation_path"), "gemini.generation_path")
        profile["edit_path"] = validate_relative_path(raw.get("edit_path"), "gemini.edit_path")
        require(profile["generation_path"] == "/v1/images/generations",
                "gemini.generation_path must be /v1/images/generations")
        require(profile["edit_path"] == "/v1/images/edits",
                "gemini.edit_path must be /v1/images/edits")
        timeout = raw.get("request_timeout_seconds")
        require(isinstance(timeout, int) and not isinstance(timeout, bool) and timeout >= 600,
                "gemini.request_timeout_seconds must be at least 600")
        profile["request_timeout_seconds"] = timeout
    elif name == "gpt":
        require(set(raw) == {"protocol", "generation_path", "edit_path", "default_model", "request_timeout_seconds"},
                "gpt profile contains missing or unnecessary fields")
        profile["generation_path"] = validate_relative_path(raw.get("generation_path"), "gpt.generation_path")
        profile["edit_path"] = validate_relative_path(raw.get("edit_path"), "gpt.edit_path")
        timeout = raw.get("request_timeout_seconds")
        require(isinstance(timeout, int) and not isinstance(timeout, bool) and timeout >= 600,
                "gpt.request_timeout_seconds must be at least 600")
        profile["request_timeout_seconds"] = timeout
    else:
        require(set(raw) == {"protocol", "submit_path", "query_path", "default_model",
                             "poll_interval_seconds", "poll_slice_attempts", "poll_total_attempts",
                             "submit_timeout_seconds", "query_timeout_seconds"},
                "seedance profile contains missing or unnecessary fields")
        profile["submit_path"] = validate_relative_path(raw.get("submit_path"), "seedance.submit_path")
        profile["query_path"] = validate_relative_path(raw.get("query_path"), "seedance.query_path", "{task_id}")
        for field, default in (("poll_interval_seconds", 20), ("poll_slice_attempts", 15),
                               ("poll_total_attempts", 360),
                               ("submit_timeout_seconds", 180), ("query_timeout_seconds", 60)):
            value = raw.get(field, default)
            require(isinstance(value, int) and not isinstance(value, bool) and value > 0, f"seedance.{field} must be a positive integer")
            profile[field] = value
        require(profile["poll_slice_attempts"] <= profile["poll_total_attempts"],
                "seedance.poll_slice_attempts cannot exceed poll_total_attempts")
    profile.update(root["limits"])
    return profile


def credential_store_path(store: str) -> Path:
    require(store == DEFAULT_CREDENTIAL_STORE, f"credential store must be {DEFAULT_CREDENTIAL_STORE}")
    path = (WORKSPACE_ROOT / store).resolve()
    runtime_root = (WORKSPACE_ROOT / ".agents" / "runtime").resolve()
    require(path.parent == runtime_root, "credential store must live in .agents/runtime")
    return path


def credential_value(store: str) -> str:
    path = credential_store_path(store)
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return ""
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ApiError(f"invalid credential store: {path}") from exc
    require(isinstance(raw, dict) and set(raw) == {CREDENTIAL_FIELD},
            f"credential store must contain exactly {CREDENTIAL_FIELD}")
    value = str(raw.get(CREDENTIAL_FIELD, "")).strip()
    return value


def harden_credential_store(path: Path) -> None:
    try:
        os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)
    except OSError:
        pass
    if sys.platform != "win32":
        return
    username = os.environ.get("USERNAME", "").strip()
    if not username:
        return
    subprocess.run(
        ["icacls", str(path), "/inheritance:r", "/grant:r", f"{username}:F"],
        check=False, capture_output=True, text=True, encoding="utf-8", errors="replace",
    )


def persist_user_credential(store: str, value: str) -> Path:
    require(bool(value), "API key is empty")
    path = credential_store_path(store)
    path.parent.mkdir(parents=True, exist_ok=True)
    encoded = (json.dumps({CREDENTIAL_FIELD: value}, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    atomic_write(path, encoded)
    harden_credential_store(path)
    return path


def workspace_path(value: Any, root: Path, *, must_exist: bool = False) -> Path:
    require(bool(str(value or "").strip()), "path is required")
    candidate = Path(str(value))
    if not candidate.is_absolute():
        candidate = root / candidate
    resolved = candidate.resolve()
    root = root.resolve()
    require(resolved == root or root in resolved.parents, f"path escapes Workspace: {value}")
    if must_exist:
        require(resolved.is_file(), f"input file not found: {value}")
    return resolved


def workspace_relative(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def require_work_path(path: Path, root: Path) -> None:
    parts = [part.lower() for part in path.resolve().relative_to(root.resolve()).parts]
    require("requests" in parts and "work" in parts, "request and output must be inside the current request work directory")


def find_work_root(path: Path, root: Path) -> Path:
    relative = path.resolve().relative_to(root.resolve())
    lowered = [part.lower() for part in relative.parts]
    require("requests" in lowered and "work" in lowered, "path must be inside a request work directory")
    work_index = lowered.index("work", lowered.index("requests") + 1)
    return root.resolve().joinpath(*relative.parts[: work_index + 1])


def require_source_path(path: Path, root: Path, current_work: Path) -> None:
    resolved=path.resolve(); request_root=current_work.parent
    request_input=request_root/'input'
    allowed=(resolved==request_input or request_input in resolved.parents or resolved==current_work or current_work in resolved.parents)
    if not allowed:
        allowed=indexed_project_source(root.resolve(),resolved)
    require(allowed, "image sources must be current request input/work or current indexed project materials")

def validate_reference_plan_match(root: Path, current_work: Path, references: list[Path], excluded: list[Path] | None = None) -> None:
    request_root=current_work.parent
    gate_path=Path(__file__).resolve().parents[2]/"wxian-image-production"/"scripts"/"request_reference_gate.py"
    mod=load_local_module(gate_path,"wxian_request_reference_gate","reference gate")
    try:
        excluded_rel={workspace_relative(item,root) for item in (excluded or []) if item is not None}
        result=mod.validate_plan(root,request_root,excluded_rel)
    except Exception as exc:
        raise ApiError(str(exc)) from exc
    expected=sorted(str(item) for item in result.get("must_upload",[]))
    actual=sorted(workspace_relative(item, root) for item in references)
    require(actual == expected, f"reference_images must exactly match reference-plan must_upload; expected={expected}, actual={actual}")


def validate_ip_character_handoff(
    root: Path,
    current_work: Path,
    api_profile: str,
    mode: str,
    references: list[Path],
    base_image: Path | None,
) -> dict[str, Any] | None:
    """Bind an optional Game Concept Lab IP handoff to the real API request.

    The handoff is optional for ordinary image work.  Once any IP-character
    contract exists, however, the whole preflight/handoff chain becomes
    mandatory and the Mother References must be the provider-input prefix.
    """
    names = (
        "ip-character-system.json",
        "ip-character-binding.json",
        "ip-character-preflight.json",
        "ip-character-handoff.json",
    )
    candidates = [current_work, current_work / "concept-lab"]
    active = [folder for folder in candidates if any((folder / name).exists() for name in names)]
    require(len(active) <= 1, "IP Character contracts must exist in exactly one work location")
    if not active:
        return None
    folder = active[0]
    paths = {name: folder / name for name in names}
    missing = [workspace_relative(path, root) for path in paths.values() if not path.is_file()]
    require(not missing, "incomplete IP Character production contract: " + ", ".join(missing))

    preflight = read_json(paths["ip-character-preflight.json"], "IP Character preflight")
    handoff = read_json(paths["ip-character-handoff.json"], "IP Character handoff")
    require(preflight.get("status") == "PASS", "IP Character production preflight did not PASS")
    require(handoff.get("status") == "READY", "IP Character provider handoff is not READY")
    provider_map = {"gpt": "gpt-image", "gemini": "gemini-nano-banana"}
    require(handoff.get("provider") == provider_map.get(api_profile),
            "IP Character handoff provider does not match api_profile")
    require(handoff.get("execution_mode") == mode,
            "IP Character handoff execution_mode does not match API mode")

    contract_binding = handoff.get("contract_binding")
    require(isinstance(contract_binding, dict), "IP Character handoff contract_binding is missing")
    require(contract_binding.get("system_sha256") == sha256_file(paths["ip-character-system.json"]),
            "IP Character system changed after handoff compilation")
    require(contract_binding.get("binding_sha256") == sha256_file(paths["ip-character-binding.json"]),
            "IP Character binding changed after handoff compilation")

    inputs = handoff.get("image_conditioning_inputs")
    require(isinstance(inputs, list) and inputs, "IP Character handoff has no image_conditioning_inputs")
    mother_prefix = [item.get("provider_workspace_path") for item in inputs if isinstance(item, dict)]
    require(len(mother_prefix) == len(inputs) and all(isinstance(item, str) and item for item in mother_prefix),
            "IP Character handoff contains invalid provider paths")
    actual_refs = [workspace_relative(path, root) for path in references]
    require(actual_refs[:len(mother_prefix)] == mother_prefix,
            "API reference_images must preserve the IP Mother Reference prefix and order")
    for item, path in zip(inputs, references):
        require(item.get("sha256") == sha256_file(path),
                f"IP Mother Reference changed after handoff compilation: {workspace_relative(path, root)}")

    execution = handoff.get("execution_contract")
    require(isinstance(execution, dict) and execution.get("mode") == mode,
            "IP Character handoff execution contract is invalid")
    edit_target = execution.get("edit_target")
    if mode == "image_to_image_edit":
        require(base_image is not None and isinstance(edit_target, dict),
                "IP Character edit handoff requires the bound base image")
        require(edit_target.get("provider_workspace_path") == workspace_relative(base_image, root),
                "API base_image does not match the IP Character edit target")
        require(edit_target.get("sha256") == sha256_file(base_image),
                "IP Character edit target changed after handoff compilation")
    else:
        require(base_image is None and edit_target is None,
                "reference_to_image IP Character handoff must not contain an edit target")

    evidence = handoff.get("provider_runtime_evidence")
    runtime_binding = evidence.get("runtime_binding") if isinstance(evidence, dict) else None
    require(isinstance(runtime_binding, dict), "IP Character handoff lacks provider runtime evidence")
    producer = Path(__file__).resolve().parents[2] / "wxian-image-production" / "scripts" / "provider_reference_contract_test.py"
    gate = Path(__file__).resolve().parents[2] / "wxian-image-production" / "scripts" / "request_reference_gate.py"
    current_binding = {
        "producer_sha256": sha256_file(producer),
        "generation_api_sha256": sha256_file(Path(__file__).resolve()),
        "request_reference_gate_sha256": sha256_file(gate),
    }
    require(runtime_binding == current_binding, "IP Character provider runtime changed after handoff compilation")
    return {
        "path": workspace_relative(paths["ip-character-handoff.json"], root),
        "sha256": sha256_file(paths["ip-character-handoff.json"]),
        "character_id": handoff.get("character_id"),
        "system_version": handoff.get("system_version"),
        "provider": handoff.get("provider"),
        "execution_mode": mode,
        "mother_reference_count": len(mother_prefix),
    }


def validate_api_branch(branch: str, api_profile: str, mode: str) -> None:
    if branch in {"visual-brief-only","prompt-only","prompt-review-only","composite"}:
        raise ApiError(f"production_branch={branch} must not call image/video generation API")
    if branch == "video":
        require(api_profile == "seedance" and mode in VIDEO_MODES,"video branch requires Seedance video mode")
        return
    require(api_profile in {"gemini","gpt"} and mode in IMAGE_MODES,f"production_branch={branch} requires Gemini/GPT image mode")
    if branch in {"image-edit","resize","localization","postprocess-chain"}:
        require(mode == "image_to_image_edit",f"production_branch={branch} may call the image API only through image_to_image_edit")


def _validate_layer_source_contract(root: Path, current_work: Path, plan: dict[str, Any], primary_skill: str) -> dict[str, Any]:
    value = plan.get("source_contract")
    require(isinstance(value, dict) and set(value) == LAYER_SOURCE_CONTRACT_FIELDS,
            "layer generation plan requires exact source_contract binding")
    plan_path = workspace_path(value["layer_plan_path"], root, must_exist=True)
    require(find_work_root(plan_path, root) == current_work, "layer source_contract plan belongs to another request")
    require(value["layer_plan_sha256"] == sha256_file(plan_path), "layer source_contract plan hash is stale")
    layer_plan = read_json(plan_path, "layer source plan")
    expected_schema = {
        "wxian-image-layer-decomposition": "wxian.kv-layer-plan.v6",
        "wxian-game-ui-layer-decomposition": "wxian.game-ui-layer-plan.v4",
    }[primary_skill]
    require(layer_plan.get("schema_version") == expected_schema,
            f"layer source plan schema must be {expected_schema}")
    source = workspace_path(value["source_image_path"], root, must_exist=True)
    work_image = workspace_path(value["work_source_path"], root, must_exist=True)
    require(value["source_sha256"] == sha256_file(source), "layer source image hash is stale")
    require(value["work_sha256"] == sha256_file(work_image), "layer work image hash is stale")
    require(layer_plan.get("source_image") == value["source_image_path"], "layer plan/source_contract source path mismatch")
    require(layer_plan.get("source_sha256") == value["source_sha256"], "layer plan/source_contract source hash mismatch")
    require(layer_plan.get("work_source") == value["work_source_path"], "layer plan/source_contract work path mismatch")
    require(layer_plan.get("work_sha256") == value["work_sha256"], "layer plan/source_contract work hash mismatch")
    for key in ("source_canvas_size", "delivery_canvas_size", "work_canvas_size", "size_contract"):
        require(layer_plan.get(key) == value[key], f"layer plan/source_contract {key} mismatch")
    return dict(value)


def validate_direct_generation_plan(root: Path, current_work: Path, request: dict[str, Any],
                                    primary_skill: str) -> dict[str, Any]:
    """Bind a non-image-production Primary to a finite, reviewable image batch."""
    require(primary_skill in DIRECT_IMAGE_CALLERS,
            f"primary_skill={primary_skill} is not allowed to call the generation API directly")
    require(request.get("api_profile") in {"gemini", "gpt"},
            f"primary_skill={primary_skill} may call image profiles only")
    require(request.get("mode") in IMAGE_MODES,
            f"primary_skill={primary_skill} may call image modes only")
    plan_path = current_work / "generation-plan.json"
    plan = read_json(plan_path, "direct generation plan")
    layer_primary = primary_skill in {"wxian-image-layer-decomposition", "wxian-game-ui-layer-decomposition"}
    expected_top = {"schema_version", "primary_skill", "status", "items", "source_contract"} if layer_primary else {"schema_version", "primary_skill", "status", "items"}
    require(set(plan) == expected_top,
            f"generation-plan.json fields are invalid for primary_skill={primary_skill}")
    require(plan["schema_version"] == "wxian.generation-plan.v1", "generation plan schema mismatch")
    require(plan["primary_skill"] == primary_skill, "generation plan primary_skill mismatch")
    require(plan["status"] == "READY", "generation plan must be READY")
    source_binding = _validate_layer_source_contract(root, current_work, plan, primary_skill) if layer_primary else None
    require(isinstance(plan["items"], list) and plan["items"], "generation plan items must be non-empty")
    required = {"id", "status", "api_profile", "mode", "model", "prompt_path", "prompt_sha256", "output_path", "parameters"}
    optional = {"reference_images", "base_image", "mask_image"}
    matches: list[dict[str, Any]] = []
    seen_ids: set[str] = set()
    seen_outputs: set[str] = set()
    for index, item in enumerate(plan["items"]):
        require(isinstance(item, dict) and required <= set(item) and set(item) <= required | optional,
                f"generation plan item[{index}] fields are invalid")
        item_id = str(item["id"]).strip()
        require(item_id and item_id not in seen_ids, f"generation plan item id is empty or duplicate: {item_id!r}")
        seen_ids.add(item_id)
        output_path = str(item["output_path"])
        require(output_path not in seen_outputs, f"generation plan output_path is duplicate: {output_path}")
        seen_outputs.add(output_path)
        prompt_path = workspace_path(item["prompt_path"], root, must_exist=True)
        require(find_work_root(prompt_path, root) == current_work, f"generation plan Prompt is outside current request: {item_id}")
        require(item["prompt_sha256"] == sha256_file(prompt_path), f"generation plan Prompt hash mismatch: {item_id}")
        request_shape = {
            key: request.get(key, [] if key == "reference_images" else "")
            for key in ("api_profile", "mode", "model", "prompt_path", "output_path", "parameters",
                        "reference_images", "base_image", "mask_image")
        }
        item_shape = {
            key: item.get(key, [] if key == "reference_images" else "")
            for key in request_shape
        }
        if item_shape == request_shape:
            require(item["status"] == "READY", f"generation plan item is not READY: {item_id}")
            matches.append(item)
    require(len(matches) == 1, "API request must match exactly one READY generation plan item")
    selected = matches[0]
    output = workspace_path(selected["output_path"], root)
    originals = (current_work / "final" / "originals").resolve()
    require(originals in output.parents, "direct generation output must be inside work/final/originals/")
    result = {
        "path": workspace_relative(plan_path, root),
        "sha256": sha256_file(plan_path),
        "primary_skill": primary_skill,
        "execution_class": DIRECT_IMAGE_CALLERS[primary_skill],
        "item_id": selected["id"],
    }
    if source_binding is not None:
        result["source_contract"] = source_binding
    return result


def validate_kv_reconstruction_contract(root: Path, current_work: Path, request: dict[str, Any],
                                        generation_plan_binding: dict[str, Any] | None) -> dict[str, Any] | None:
    if not isinstance(generation_plan_binding, dict) or generation_plan_binding.get("primary_skill") != "wxian-image-layer-decomposition":
        return None
    source_binding = generation_plan_binding.get("source_contract")
    require(isinstance(source_binding, dict), "KV generation binding lacks source_contract")
    layer_plan_path = workspace_path(source_binding["layer_plan_path"], root, must_exist=True)
    plan = read_json(layer_plan_path, "KV layer plan")
    layers = plan.get("layers", [])
    requires = any(isinstance(layer, dict) and layer.get("strategy") in KV_RECONSTRUCTION_STRATEGIES for layer in layers)
    if not requires:
        return {"status": "not_required", "reason": "source-only KV plan"}

    visual = load_local_module(root / ".agents" / "lib" / "visual_contracts.py", "wxian_generation_visual_contracts", "visual contracts")
    spec_path = current_work / "visual-spec.json"
    binding_path = current_work / "prompt-binding.json"
    manifest_path = current_work / "layer-prompt-manifest.json"
    require(spec_path.is_file(), "KV reconstruction requires work/visual-spec.json")
    require(binding_path.is_file(), "KV reconstruction requires work/prompt-binding.json")
    require(manifest_path.is_file(), "KV reconstruction requires work/layer-prompt-manifest.json")
    try:
        spec = visual.validate_visual_spec(root, spec_path)
        binding = visual.validate_prompt_binding(root, binding_path)
    except Exception as exc:
        raise ApiError(str(exc)) from exc
    require(spec.get("profile_id") == "visual.transform.reconstruction.v1" and spec.get("mode") == "TRANSFORM",
            "KV reconstruction Visual Spec must use visual.transform.reconstruction.v1 TRANSFORM")
    manifest = read_json(manifest_path, "KV layer prompt manifest")
    required_fields = {"schema_version", "primary_skill", *LAYER_SOURCE_CONTRACT_FIELDS, "prompt_package_path", "prompt_package_sha256", "entries"}
    require(set(manifest) == required_fields, "KV layer prompt manifest fields are invalid")
    require(manifest["schema_version"] == KV_PROMPT_MANIFEST_SCHEMA, "KV layer prompt manifest schema mismatch")
    require(manifest["primary_skill"] == "wxian-image-layer-decomposition", "KV layer prompt manifest primary_skill mismatch")
    for key in LAYER_SOURCE_CONTRACT_FIELDS:
        require(manifest[key] == source_binding[key], f"KV layer prompt manifest source binding mismatch: {key}")
    package_path = workspace_path(manifest["prompt_package_path"], root, must_exist=True)
    require(find_work_root(package_path, root) == current_work, "KV layer prompt package belongs to another request")
    require(manifest["prompt_package_sha256"] == sha256_file(package_path), "KV layer prompt package hash is stale")
    require(binding.get("prompt_path") == manifest["prompt_package_path"], "Prompt Binding must bind the KV layer prompt package")
    require(binding.get("prompt_sha256") == manifest["prompt_package_sha256"], "Prompt Binding KV prompt package hash mismatch")
    require(binding.get("visual_spec_sha256") == sha256_file(spec_path), "KV Prompt Binding Visual Spec hash is stale")

    entries = manifest.get("entries")
    require(isinstance(entries, list) and entries, "KV layer prompt manifest entries must be non-empty")
    by_id: dict[str, dict[str, Any]] = {}
    for index, entry in enumerate(entries):
        require(isinstance(entry, dict) and set(entry) == {"item_id", "prompt_path", "prompt_sha256"},
                f"KV layer prompt manifest entry[{index}] fields are invalid")
        item_id = str(entry["item_id"]).strip()
        require(item_id and item_id not in by_id, f"KV layer prompt manifest item_id missing/duplicate: {item_id!r}")
        prompt_path = workspace_path(entry["prompt_path"], root, must_exist=True)
        require(find_work_root(prompt_path, root) == current_work, f"KV manifest Prompt belongs to another request: {item_id}")
        require(entry["prompt_sha256"] == sha256_file(prompt_path), f"KV manifest Prompt hash is stale: {item_id}")
        by_id[item_id] = entry
    generation_plan = read_json(current_work / "generation-plan.json", "direct generation plan")
    plan_prompt_map = {str(item["id"]): (str(item["prompt_path"]), str(item["prompt_sha256"])) for item in generation_plan["items"]}
    manifest_prompt_map = {item_id: (str(entry["prompt_path"]), str(entry["prompt_sha256"])) for item_id, entry in by_id.items()}
    require(manifest_prompt_map == plan_prompt_map, "KV prompt manifest must exactly bind every generation-plan Prompt")
    active = by_id.get(str(generation_plan_binding.get("item_id", "")))
    require(active is not None, "active KV generation item is missing from layer prompt manifest")
    require(active["prompt_path"] == request.get("prompt_path"), "active KV request Prompt differs from layer prompt manifest")
    return {
        "status": "required",
        "visual_spec_path": workspace_relative(spec_path, root),
        "visual_spec_sha256": sha256_file(spec_path),
        "prompt_binding_path": workspace_relative(binding_path, root),
        "prompt_binding_sha256": sha256_file(binding_path),
        "prompt_manifest_path": workspace_relative(manifest_path, root),
        "prompt_manifest_sha256": sha256_file(manifest_path),
        "layer_plan_path": source_binding["layer_plan_path"],
        "layer_plan_sha256": source_binding["layer_plan_sha256"],
    }


def validate_ui_reconstruction_contract(root: Path, current_work: Path, request: dict[str, Any],
                                        generation_plan_binding: dict[str, Any] | None) -> dict[str, Any] | None:
    if not isinstance(generation_plan_binding, dict) or generation_plan_binding.get("primary_skill") != "wxian-game-ui-layer-decomposition":
        return None
    source_binding = generation_plan_binding.get("source_contract")
    require(isinstance(source_binding, dict), "UI generation binding lacks source_contract")
    plan_path = workspace_path(source_binding["layer_plan_path"], root, must_exist=True)
    plan = read_json(plan_path, "UI layer plan")
    layers = plan.get("layers", [])
    requires = any(isinstance(layer, dict) and layer.get("strategy") in UI_RECONSTRUCTION_STRATEGIES for layer in layers)
    if not requires:
        return {"status": "not_required", "reason": "source-only UI plan"}

    visual = load_local_module(root / ".agents" / "lib" / "visual_contracts.py", "ui_generation_visual_contracts", "visual contracts")
    spec_path = current_work / "visual-spec.json"
    binding_path = current_work / "prompt-binding.json"
    manifest_path = current_work / "ui-layer-prompt-manifest.json"
    require(spec_path.is_file(), "UI reconstruction requires work/visual-spec.json")
    require(binding_path.is_file(), "UI reconstruction requires work/prompt-binding.json")
    require(manifest_path.is_file(), "UI reconstruction requires work/ui-layer-prompt-manifest.json")
    try:
        spec = visual.validate_visual_spec(root, spec_path)
        binding = visual.validate_prompt_binding(root, binding_path)
    except Exception as exc:
        raise ApiError(str(exc)) from exc
    require(spec.get("profile_id") == "visual.transform.reconstruction.v1" and spec.get("mode") == "TRANSFORM",
            "UI reconstruction Visual Spec must use visual.transform.reconstruction.v1 TRANSFORM")
    manifest = read_json(manifest_path, "UI layer prompt manifest")
    required_fields = {"schema_version", "primary_skill", "prompt_package_path", "prompt_package_sha256", "source_contracts", "entries"}
    require(set(manifest) == required_fields, "UI layer prompt manifest fields are invalid")
    require(manifest["schema_version"] == UI_PROMPT_MANIFEST_SCHEMA, "UI layer prompt manifest schema mismatch")
    require(manifest["primary_skill"] == "wxian-game-ui-layer-decomposition", "UI layer prompt manifest primary_skill mismatch")
    contracts = manifest.get("source_contracts")
    require(isinstance(contracts, list) and contracts, "UI layer prompt manifest source_contracts must be non-empty")
    require(any(isinstance(item, dict) and all(item.get(key) == source_binding[key] for key in LAYER_SOURCE_CONTRACT_FIELDS)
                for item in contracts), "UI layer prompt manifest does not bind the active Screen source contract")
    package_path = workspace_path(manifest["prompt_package_path"], root, must_exist=True)
    require(find_work_root(package_path, root) == current_work, "UI layer prompt package belongs to another request")
    require(manifest["prompt_package_sha256"] == sha256_file(package_path), "UI layer prompt package hash is stale")
    require(binding.get("prompt_path") == manifest["prompt_package_path"], "Prompt Binding must bind the UI layer prompt package")
    require(binding.get("prompt_sha256") == manifest["prompt_package_sha256"], "Prompt Binding UI prompt package hash mismatch")
    require(binding.get("visual_spec_sha256") == sha256_file(spec_path), "UI Prompt Binding Visual Spec hash is stale")

    entries = manifest.get("entries")
    require(isinstance(entries, list) and entries, "UI layer prompt manifest entries must be non-empty")
    by_id: dict[str, dict[str, Any]] = {}
    for index, entry in enumerate(entries):
        required_entry = {"item_id", "prompt_path", "prompt_sha256", "layer_plan_path", "layer_plan_sha256"}
        require(isinstance(entry, dict) and set(entry) == required_entry,
                f"UI layer prompt manifest entry[{index}] fields are invalid")
        item_id = str(entry["item_id"]).strip()
        require(item_id and item_id not in by_id, f"UI layer prompt manifest item_id missing/duplicate: {item_id!r}")
        prompt_path = workspace_path(entry["prompt_path"], root, must_exist=True)
        entry_plan = workspace_path(entry["layer_plan_path"], root, must_exist=True)
        require(find_work_root(prompt_path, root) == current_work, f"UI manifest Prompt belongs to another request: {item_id}")
        require(find_work_root(entry_plan, root) == current_work, f"UI manifest plan belongs to another request: {item_id}")
        require(entry["prompt_sha256"] == sha256_file(prompt_path), f"UI manifest Prompt hash is stale: {item_id}")
        require(entry["layer_plan_sha256"] == sha256_file(entry_plan), f"UI manifest plan hash is stale: {item_id}")
        by_id[item_id] = entry
    generation_plan = read_json(current_work / "generation-plan.json", "direct generation plan")
    for item in generation_plan["items"]:
        item_id = str(item["id"])
        entry = by_id.get(item_id)
        require(entry is not None, f"active UI generation item is missing from layer prompt manifest: {item_id}")
        require((entry["prompt_path"], entry["prompt_sha256"]) == (item["prompt_path"], item["prompt_sha256"]),
                f"UI layer prompt manifest differs from generation-plan Prompt: {item_id}")
    active = by_id.get(str(generation_plan_binding.get("item_id", "")))
    require(active is not None, "active UI generation item is missing from layer prompt manifest")
    require(active["prompt_path"] == request.get("prompt_path"), "active UI request Prompt differs from layer prompt manifest")
    return {
        "status": "required",
        "visual_spec_path": workspace_relative(spec_path, root),
        "visual_spec_sha256": sha256_file(spec_path),
        "prompt_binding_path": workspace_relative(binding_path, root),
        "prompt_binding_sha256": sha256_file(binding_path),
        "prompt_manifest_path": workspace_relative(manifest_path, root),
        "prompt_manifest_sha256": sha256_file(manifest_path),
        "layer_plan_path": source_binding["layer_plan_path"],
        "layer_plan_sha256": source_binding["layer_plan_sha256"],
    }

def validate_execution_contract(root: Path, current_work: Path,
                                request: dict[str, Any]) -> tuple[str, dict[str, Any] | None]:
    state = read_json(current_work.parent / "state.json", "request state")
    primary_skill = str(state.get("primary_skill", "")).strip()
    if primary_skill == "wxian-image-production":
        try:
            branch = production_branch(current_work.parent)
            validate_source_lock(root, current_work.parent)
        except ProductionContractError as exc:
            raise ApiError(str(exc)) from exc
        return branch, None
    validate_source_lock(root, current_work.parent)
    binding = validate_direct_generation_plan(root, current_work, request, primary_skill)
    return binding["execution_class"], binding

def validate_visual_variant_lock(root: Path, current_work: Path, production_branch_value: str) -> None:
    if production_branch_value != "new-generation":
        return
    lock=current_work/"requirement-lock.md"
    if not lock.is_file():
        return
    text=lock.read_text(encoding="utf-8")
    m=re.search(r"(?m)^source_demand_type:\s*(.+?)\s*$",text)
    if not m:
        return
    source_type=m.group(1).strip()
    variant_match=re.search(r"(?m)^visual_variant:\s*(.+?)\s*$",text)
    require(variant_match is not None,"source_demand_type requires visual_variant in requirement-lock.md")
    props_match=re.search(r"(?m)^has_real_props:\s*(true|false)\s*$",text,re.I)
    has_props=props_match is not None and props_match.group(1).lower()=="true"
    gameplay_ref=False
    plan_path=current_work/"reference-plan.json"
    if plan_path.is_file():
        try:
            plan=json.loads(plan_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise ApiError(f"invalid reference-plan.json: {exc}") from exc
        gameplay_ref=any(
            isinstance(item,dict) and item.get("role")=="gameplay" and item.get("use")=="must_upload"
            for item in plan.get("sources",[])
        ) if isinstance(plan,dict) else False
    resolver_path=Path(__file__).resolve().parents[2]/"wxian-image-production"/"scripts"/"visual_variant_resolver.py"
    mod=load_local_module(resolver_path,"wxian_visual_variant","visual variant resolver")
    try:
        expected=mod.resolve(source_type,has_props,gameplay_ref)
    except Exception as exc:
        raise ApiError(str(exc)) from exc
    if expected.get("status")=="passed":
        require(variant_match.group(1).strip()==expected.get("visual_variant"),
                f"visual_variant mismatch for {source_type}: expected {expected.get('visual_variant')}")
        if expected.get("visual_variant")=="store_artwork":
            store_gate=Path(__file__).resolve().parents[2]/"wxian-image-production"/"scripts"/"store_artwork_gate.py"
            store_mod=load_local_module(store_gate,"wxian_store_artwork_gate","store artwork gate")
            try:
                store_result=store_mod.validate(root,current_work.parent,require_visual_requirement=True)
            except Exception as exc:
                raise ApiError(str(exc)) from exc
            require(store_result.get("status")=="passed",f"store artwork gate failed: {store_result}")


def image_mime(path: Path) -> str:
    mime = mimetypes.guess_type(path.name)[0]
    require(mime in {"image/png", "image/jpeg", "image/webp"}, f"unsupported image type: {path.name}")
    return str(mime)


def image_part(path: Path) -> dict[str, Any]:
    return {"inline_data": {"mime_type": image_mime(path), "data": base64.b64encode(path.read_bytes()).decode("ascii")}}


def validate_media_url(value: Any, field: str, allow_insecure_http: bool) -> str:
    text = str(value or "").strip()
    require(bool(text), f"{field} is required")
    return validate_url(text, allow_insecure_http=allow_insecure_http, label=field)


def seedance_source_url(value: Any, field: str, root: Path, current_work: Path, allow_insecure_http: bool) -> tuple[str, dict[str, str]]:
    text = str(value or "").strip()
    require(text and not Path(text).is_absolute(), f"{field} must be a Workspace-relative path")
    source = workspace_path(text, root, must_exist=True)
    require_source_path(source, root, current_work)
    image_mime(source)
    sidecar = source.with_name(source.name + ".call.json")
    require(sidecar.is_file(), f"{field} has no generation call record with reusable remote media URL: {text}")
    record = read_json(sidecar, f"{field} call record")
    url = record.get("remote_media_url")
    require(isinstance(url, str) and bool(url.strip()),
            f"{field} has no reusable remote_media_url; local uploaded media needs a real upload bridge before Seedance can consume it")
    resolved = validate_media_url(url, f"{field}.remote_media_url", allow_insecure_http)
    return resolved, {"path": workspace_relative(source, root), "sha256": sha256_file(source)}


def validate_prompt_path(request: dict[str, Any], root: Path, current_work: Path, model: str) -> tuple[str, dict[str, str]]:
    value = str(request.get("prompt_path", "")).strip()
    require(value and not Path(value).is_absolute(), "request requires Workspace-relative prompt_path")
    path = workspace_path(value, root, must_exist=True)
    require(path.is_file(), "prompt_path must point to a file")
    require(current_work == path or current_work in path.parents, "prompt_path must be inside current request work")
    try:
        prompt = path.read_text(encoding="utf-8").strip()
    except UnicodeDecodeError as exc:
        raise ApiError("prompt_path must be UTF-8 text") from exc
    require(bool(prompt), "prompt_path is empty")
    require(len(prompt) <= 50000, "prompt exceeds 50000 characters")
    # Complete-visual contract: the authored prompt must describe the picture, not
    # the carrier slot, and must not simulate the carrier's canvas. This is the
    # single place every model request's prompt text passes through.
    try:
        require_clean_prompt(prompt, label=f"prompt {workspace_relative(path, root)}")
    except PresentationError as exc:
        # The API owns its own blocked contract: a presentation violation is a
        # normal pre-network refusal, not an internal crash.
        raise ApiError(str(exc)) from exc
    personal_context_path = current_work / "personal-context.json"
    manifest_path = root / "user" / "manifest.json"
    manifest_enabled = False
    manifest_hash = None
    if manifest_path.is_file():
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ApiError("user/manifest.json must be valid UTF-8 JSON") from exc
        require(isinstance(manifest, dict) and isinstance(manifest.get("enabled", False), bool),
                "user/manifest.json enabled must be a boolean")
        manifest_enabled = bool(manifest.get("enabled", False))
        manifest_hash = sha256_file(manifest_path)
    if manifest_enabled:
        require(personal_context_path.is_file(),
                "Personal Layer is enabled but current request has no personal-context.json")
        receipt_path = current_work / "personal-execution.json"
        require(receipt_path.is_file(),
                "Personal Layer is enabled but current request has no personal-execution.json")
    personal_binding = {"enabled": False, "preference_count": 0, "skill_count": 0}
    if personal_context_path.is_file():
        try:
            context = json.loads(personal_context_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise ApiError("personal-context.json must be valid UTF-8 JSON") from exc
        require(isinstance(context, dict) and context.get("status") == "ready",
                "personal-context.json is not ready")
        require(manifest_enabled, "stale personal-context.json cannot be used while Personal Layer is disabled")
        require(context.get("manifest_sha256") == manifest_hash,
                "personal-context.json manifest hash is stale; resolve Personal Layer again")
        receipt = read_json(receipt_path, "Personal execution receipt")
        state = read_json(current_work.parent / "state.json", "request state")
        require(receipt.get("status") == "consumed" and receipt.get("consumer") == state.get("primary_skill"),
                "personal-execution.json consumer does not match current primary_skill")
        require(receipt.get("consumer_source") == "explicit-command-argument",
                "personal-execution.json was not issued by an explicit Primary Skill consumer call")
        require(context.get("execution_binding") == state.get("primary_skill"),
                "personal-context.json execution binding does not match current primary_skill")
        require(receipt.get("request") == workspace_relative(current_work.parent, root)
                and receipt.get("revision") == state.get("revision"),
                "personal-execution.json request revision binding is stale")
        require(receipt.get("context_sha256") == sha256_file(personal_context_path),
                "personal-execution.json is missing or stale")
        require(receipt.get("manifest_sha256") == manifest_hash,
                "personal-execution.json manifest hash is stale")
        preferences_path = root / "user" / "preferences.md"
        require(preferences_path.is_file() and context.get("preferences_sha256") == sha256_file(preferences_path),
                "personal-context.json preferences hash is stale")
        require(context.get("execution_status") == "loaded",
                "Personal Layer was resolved but not loaded for execution")
        preferences = context.get("preferences", [])
        personal_skills = context.get("personal_skills", [])
        require(isinstance(preferences, list), "personal-context.json preferences are invalid")
        require(isinstance(personal_skills, list), "personal-context.json personal_skills is invalid")
        for item in personal_skills:
            require(isinstance(item, dict) and item.get("path") and item.get("sha256"),
                    "Personal Skill execution evidence is incomplete")
            skill_path = workspace_path(str(item["path"]), root, must_exist=True)
            require(sha256_file(skill_path) == item["sha256"],
                    f"Personal Skill changed after execution binding: {item['path']}")
        # Model-scoped preferences must be removed before compiling the shared
        # execution context; filtering only suffix extraction still leaks them
        # into non-target provider payloads.
        applicable_preferences = []
        for value in preferences:
            text = str(value)
            if not model_scoped_text_applies(text, model):
                continue
            applicable_preferences.append(value)
        compiled = ["\n\n[PERSONAL_EXECUTION_CONTEXT]"]
        if applicable_preferences:
            compiled.append("User preferences (must apply):")
            compiled.extend(f"- {str(item)}" for item in applicable_preferences)
        if personal_skills:
            compiled.append("Loaded Personal Skills (explicitly applied):")
            for item in personal_skills:
                skill_path = workspace_path(str(item["path"]), root, must_exist=True)
                body = skill_path.read_text(encoding="utf-8").strip()
                require(bool(body), f"loaded Personal Skill is empty: {item['path']}")
                compiled.append(f"\n--- {item['path']} sha256={item['sha256']} ---")
                compiled.append(body)
        if applicable_preferences or personal_skills:
            compiled.append("[/PERSONAL_EXECUTION_CONTEXT]")
            prompt = prompt + "\n" + "\n".join(compiled)
        suffixes = []
        for value in applicable_preferences:
            text = str(value)
            match = re.search(r"(?:must end with|末尾加上|结尾加上)\s*([^\s，。,.;；]+)", text, re.IGNORECASE)
            if match:
                suffixes.append(match.group(1))
        if suffixes:
            prompt = prompt.rstrip() + " " + suffixes[-1]
        personal_binding = {"enabled": True, "preference_count": len(applicable_preferences),
                            "skill_count": len(personal_skills), "context_sha256": sha256_file(personal_context_path)}
    return prompt, {"path": workspace_relative(path, root), "sha256": sha256_file(path),
                    "personal_binding": personal_binding}


def validate_request(request: dict[str, Any], root: Path, current_work: Path, profile: dict[str, Any],
                     *, allow_seedance_resume: bool = False) -> dict[str, Any]:
    api_profile = str(request.get("api_profile", "")).strip()
    require(api_profile == profile["name"], "request api_profile does not match selected profile")
    mode = str(request.get("mode", "")).strip()
    common_fields = {"api_profile", "mode", "prompt_path", "model", "output_path", "parameters"}
    profile_fields = (
        {"reference_images", "base_image", "mask_image"} if api_profile in {"gemini", "gpt"} else
        {"first_frame_url", "last_frame_url", "reference_images", "reference_videos",
         "first_frame_source", "last_frame_source", "reference_image_sources"}
    )
    require(set(request) <= common_fields | profile_fields,
            f"request contains unsupported fields: {', '.join(sorted(set(request) - common_fields - profile_fields))}")
    branch, generation_plan_binding = validate_execution_contract(root, current_work, request)
    validate_api_branch(branch,api_profile,mode)
    validate_visual_variant_lock(root,current_work,branch)
    visual_reconstruction_binding = validate_kv_reconstruction_contract(root, current_work, request, generation_plan_binding)
    if visual_reconstruction_binding is None:
        visual_reconstruction_binding = validate_ui_reconstruction_contract(root, current_work, request, generation_plan_binding)
    model = str(request.get("model") or profile["default_model"]).strip()
    require(bool(model), "model is required")
    if api_profile == "gemini":
        require(model == CURRENT_GEMINI_IMAGE_MODEL,
                f"Gemini image model must be {CURRENT_GEMINI_IMAGE_MODEL}")
    elif api_profile == "gpt":
        try:
            validate_gpt_model(model)
        except ValueError as exc:
            raise ApiError(str(exc)) from exc
    prompt, prompt_source = validate_prompt_path(request, root, current_work, model)
    output_value = str(request.get("output_path", ""))
    require(output_value and not Path(output_value).is_absolute(), "output_path must be Workspace-relative")
    output = workspace_path(output_value, root)
    require_work_path(output, root)
    require(find_work_root(output, root) == current_work, "output_path must be in the same request work directory as the request JSON")
    require(not output.exists(), f"output already exists: {output}")
    record = output.with_name(output.name + ".call.json")
    attempt = output.with_name(output.name + ".attempt.json")
    require(not record.exists(), f"call record already exists: {record}")
    require(not attempt.exists() or (allow_seedance_resume and api_profile == "seedance"),
            f"unresolved call attempt exists: {attempt}")
    parameters = request.get("parameters", {})
    require(isinstance(parameters, dict), "parameters must be an object")
    if api_profile == "gpt":
        request_source = current_work.parent / "request.md"
        require(request_source.is_file(), "GPT request requires current request.md intent source")
        request_text = request_source.read_text(encoding="utf-8")
        specialist_layer_call = bool(
            isinstance(generation_plan_binding, dict)
            and generation_plan_binding.get("primary_skill") in {"wxian-image-layer-decomposition", "wxian-game-ui-layer-decomposition"}
        )
        try:
            if specialist_layer_call:
                # Layer decomposition is a professional image-edit workflow: its finite
                # generation plan owns the model/quality decision unless the user named
                # an exact GPT Image model. This prevents the generic Flare default from
                # silently downgrading Sunburst reconstruction.
                lower_request = request_text.casefold()
                explicit_model = None
                for candidate in (GPT_IMAGE_25_SUNBURST, GPT_IMAGE_25_FLARE, GPT_IMAGE_2):
                    if candidate in lower_request:
                        explicit_model = candidate
                        break
                if explicit_model is not None:
                    require(model == explicit_model,
                            f"layer generation model bypasses explicit user model: expected {explicit_model}, got {model}")
                actual = {**gpt_default_parameters(model), **parameters}
                size = str(actual.get("size", "")).lower()
                quality = str(actual.get("quality", "")).lower()
                background = str(actual.get("background", "")).lower()
                moderation = str(actual.get("moderation", "")).lower()
                output_format = str(actual.get("output_format", "")).lower()
                validate_gpt_size(model, size)
                validate_gpt_quality(model, quality)
                require(background in GPT_BACKGROUNDS, f"unsupported background={background} for {model}")
                require(moderation in GPT_MODERATIONS, f"unsupported moderation={moderation} for {model}")
                require(output_format in GPT_OUTPUT_FORMATS, f"unsupported output_format={output_format} for {model}")
                require(background != "transparent" or output_format in {"png", "webp"},
                        "transparent background requires png or webp")
                gpt_resolution = {
                    "api_profile": "gpt",
                    "model": model,
                    "parameters": actual,
                    "resolution_source": "specialist_generation_plan",
                }
            else:
                gpt_resolution = validate_resolved_gpt_request(
                    request_text,
                    model,
                    parameters,
                    aspect_ratio=None if mode == "image_to_image_edit" else "1:1",
                )
        except (ValueError, ApiError) as exc:
            raise ApiError(str(exc)) from exc
        parameters = dict(gpt_resolution["parameters"])
        gpt_intent_binding = {
            "request_path": workspace_relative(request_source, root),
            "request_sha256": sha256_file(request_source),
            "resolved": gpt_resolution,
            "resolved_sha256": hashlib.sha256(
                json.dumps(gpt_resolution, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
            ).hexdigest(),
        }
    else:
        gpt_intent_binding = None
    common = {
        "api_profile": api_profile,
        "mode": mode,
        "prompt": prompt,
        "prompt_source": prompt_source,
        "model": model,
        "parameters": parameters,
        "output": output,
        "record": record,
        "attempt": attempt,
        "workspace_root": root,
        "gpt_intent_binding": gpt_intent_binding,
        "generation_plan_binding": generation_plan_binding,
        "visual_reconstruction_binding": visual_reconstruction_binding,
    }
    if api_profile in {"gemini", "gpt"}:
        require(mode in IMAGE_MODES, f"unsupported image mode: {mode}")
        refs_raw = request.get("reference_images", [])
        require(isinstance(refs_raw, list), "reference_images must be an array")
        require(all(isinstance(item, str) and item and not Path(item).is_absolute() for item in refs_raw),
                "reference_images must use Workspace-relative paths")
        references = [workspace_path(item, root, must_exist=True) for item in refs_raw]
        base_value = str(request.get("base_image", ""))
        mask_value = str(request.get("mask_image", ""))
        require(not base_value or not Path(base_value).is_absolute(), "base_image must be Workspace-relative")
        require(not mask_value or not Path(mask_value).is_absolute(), "mask_image must be Workspace-relative")
        base_image = workspace_path(base_value, root, must_exist=True) if base_value else None
        mask_image = workspace_path(mask_value, root, must_exist=True) if mask_value else None
        for item in [*references, base_image, mask_image]:
            if item is not None:
                require_source_path(item, root, current_work)
                image_mime(item)
        if not (isinstance(generation_plan_binding, dict)
                and generation_plan_binding.get("primary_skill") in {"wxian-image-layer-decomposition", "wxian-game-ui-layer-decomposition"}):
            validate_reference_plan_match(root, current_work, references, [item for item in (base_image, mask_image) if item is not None])
        else:
            # The flattened screenshot/KV is the reconstruction carrier, not an open-ended generation reference.
            # Each decomposition skill binds every actual provider input in its finite generation plan.
            require(all(require_source_path(item, root, current_work) is None for item in references),
                    "layer decomposition reference validation failed")
        if mode == "text_to_image":
            require(not references and base_image is None and mask_image is None,
                    "text_to_image must not include source images; use reference_to_image or image_to_image_edit")
        elif mode == "reference_to_image":
            require(bool(references), "reference_to_image requires reference_images")
            require(base_image is None and mask_image is None, "reference_to_image accepts reference_images only")
        else:
            require(base_image is not None, "image_to_image_edit requires base_image")
        if mask_image is not None:
            require(api_profile == "gpt", "mask_image is supported only for GPT Image edits")
            require(mode == "image_to_image_edit" and base_image is not None,
                    "mask_image requires GPT image_to_image_edit with base_image")
            require(model in GPT_IMAGE_25_MODELS,
                    "mask_image requires GPT Image 2.5 in this Workspace")
            require(image_mime(mask_image) == image_mime(base_image),
                    "GPT edit image and mask must use the same image format")
            require(mask_image.stat().st_size < 50 * 1024 * 1024 and base_image.stat().st_size < 50 * 1024 * 1024,
                    "GPT edit image and mask must each be under 50MB")
            try:
                from PIL import Image
                with Image.open(base_image) as base_opened, Image.open(mask_image) as mask_opened:
                    base_opened.load(); mask_opened.load()
                    require(base_opened.size == mask_opened.size,
                            "GPT edit image and mask must have the same dimensions")
                    require("A" in mask_opened.getbands() or "transparency" in mask_opened.info,
                            "GPT edit mask must contain an alpha channel")
            except ImportError as exc:
                raise ApiError("Pillow is required to validate GPT edit masks") from exc
        ip_character_binding = validate_ip_character_handoff(
            root, current_work, api_profile, mode, references, base_image
        )
        images_for_edit = ([base_image] if base_image is not None else []) + references
        if api_profile == "gemini":
            require(len(images_for_edit) <= 14, "Gemini 3 image workflow supports at most 14 total input images")
            require(output.suffix.lower() == ".png", "Gemini output_path must use .png")
        else:
            require(len(images_for_edit) <= 16, "GPT Images edits supports at most 16 input images")
            require(output.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"},
                    "image output must use png, jpg, jpeg, or webp")
        return {
            **common,
            "references": references,
            "base_image": base_image,
            "mask_image": mask_image,
            "ip_character_binding": ip_character_binding,
        }

    require(mode in VIDEO_MODES, f"unsupported video mode: {mode}")
    allow_http = profile["allow_insecure_http"]
    first_url = request.get("first_frame_url")
    first_source = request.get("first_frame_source")
    require(not (first_url and first_source), "use either first_frame_url or first_frame_source, not both")
    last_url = request.get("last_frame_url")
    last_source = request.get("last_frame_source")
    require(not (last_url and last_source), "use either last_frame_url or last_frame_source, not both")
    source_evidence: dict[str, Any] = {"first_frame_source": None, "last_frame_source": None, "reference_image_sources": []}
    if first_source:
        first_frame, source_evidence["first_frame_source"] = seedance_source_url(first_source, "first_frame_source", root, current_work, allow_http)
    else:
        first_frame = validate_media_url(first_url, "first_frame_url", allow_http) if first_url else None
    if last_source:
        last_frame, source_evidence["last_frame_source"] = seedance_source_url(last_source, "last_frame_source", root, current_work, allow_http)
    else:
        last_frame = validate_media_url(last_url, "last_frame_url", allow_http) if last_url else None
    media: dict[str, list[str]] = {}
    for field in ("reference_images", "reference_videos"):
        raw = request.get(field, [])
        require(isinstance(raw, list), f"{field} must be an array")
        media[field] = [validate_media_url(item, field, allow_http) for item in raw]
    source_refs = request.get("reference_image_sources", [])
    require(isinstance(source_refs, list), "reference_image_sources must be an array")
    for item in source_refs:
        url, evidence = seedance_source_url(item, "reference_image_sources", root, current_work, allow_http)
        media["reference_images"].append(url)
        source_evidence["reference_image_sources"].append(evidence)
    require(len(media["reference_images"]) <= 9, "Seedance supports at most 9 reference images")
    require(len(media["reference_videos"]) <= 3, "Seedance supports at most 3 reference videos")
    if mode == "text_to_video":
        require(not first_frame and not last_frame and not any(media.values()), "text_to_video must not include reference media")
    if mode == "image_to_video_first_frame":
        require(bool(first_frame), "first_frame_url is required")
        require(not last_frame and not any(media.values()), "first-frame mode accepts only first_frame_url")
    if mode == "image_to_video_first_last_frame":
        require(bool(first_frame and last_frame), "first_frame_url and last_frame_url are required")
        require(not any(media.values()), "first-last mode accepts only first_frame_url and last_frame_url")
    if mode == "reference_to_video":
        require(any(media.values()), "reference_to_video requires at least one reference image/video URL")
        require(not first_frame and not last_frame, "reference_to_video must not include first/last frame fields")
    require(not last_frame or first_frame, "last_frame_url requires first_frame_url")
    require(output.suffix.lower() in {".mp4", ".webm", ".mov"}, "video output must use mp4, webm, or mov")
    return {**common, "first_frame": first_frame, "last_frame": last_frame, "source_evidence": source_evidence, **media}

def multipart(fields: dict[str, str], images: list[tuple[str, Path]]) -> tuple[bytes, str]:
    boundary = f"generation-api-{uuid.uuid4().hex}"
    buffer = io.BytesIO()
    for name, value in fields.items():
        buffer.write(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode("utf-8"))
    for name, path in images:
        buffer.write(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"; filename="{path.name}"\r\nContent-Type: {image_mime(path)}\r\n\r\n'.encode("utf-8"))
        buffer.write(path.read_bytes())
        buffer.write(b"\r\n")
    buffer.write(f"--{boundary}--\r\n".encode("ascii"))
    return buffer.getvalue(), f"multipart/form-data; boundary={boundary}"


def gpt_payload(validated: dict[str, Any]) -> tuple[bytes, str]:
    params = validated["parameters"]
    allowed = {"size", "quality", "background", "moderation", "output_format", "output_compression"}
    unknown = sorted(set(params) - allowed)
    require(not unknown, f"unsupported GPT parameters: {', '.join(unknown)}")
    model = validated["model"]
    defaults = gpt_default_parameters(model)
    size = str(params.get("size", defaults["size"]))
    quality = str(params.get("quality", defaults["quality"]))
    background = str(params.get("background", defaults["background"]))
    moderation = str(params.get("moderation", defaults["moderation"]))
    output_format = str(params.get("output_format", defaults["output_format"])).lower()
    try:
        validate_gpt_size(model, size)
        validate_gpt_quality(model, quality)
    except ValueError as exc:
        raise ApiError(str(exc)) from exc
    require(background in GPT_BACKGROUNDS, "unsupported GPT background")
    require(moderation in GPT_MODERATIONS, "unsupported GPT moderation")
    require(output_format in GPT_OUTPUT_FORMATS, "unsupported GPT output_format")
    require(not (background == "transparent" and output_format == "jpeg"),
            "transparent GPT output requires png or webp")
    suffix_format = "jpeg" if validated["output"].suffix.lower() in {".jpg", ".jpeg"} else validated["output"].suffix.lower().lstrip(".")
    require(output_format == suffix_format, "GPT output_format must match output_path extension")
    fields: dict[str, str] = {
        "model": model,
        "prompt": validated["prompt"],
        "size": size,
        "quality": quality,
        "background": background,
        "moderation": moderation,
        "output_format": output_format,
        "n": "1",
    }
    if "output_compression" in params:
        compression = params["output_compression"]
        require(isinstance(compression, int) and not isinstance(compression, bool) and 0 <= compression <= 100,
                "GPT output_compression must be an integer from 0 to 100")
        require(output_format in {"jpeg", "webp"}, "GPT output_compression is only valid for jpeg/webp")
        fields["output_compression"] = str(compression)
    images = ([validated["base_image"]] if validated["base_image"] else []) + validated["references"]
    if validated["mode"] == "text_to_image":
        body: dict[str, Any] = dict(fields)
        body["n"] = 1
        if "output_compression" in body:
            body["output_compression"] = params["output_compression"]
        return json.dumps(body, ensure_ascii=False).encode("utf-8"), "application/json"
    image_fields = [("image", path) for path in images]
    if validated.get("mask_image") is not None:
        image_fields.append(("mask", validated["mask_image"]))
    return multipart(fields, image_fields)


def gemini_payload(validated: dict[str, Any]) -> tuple[bytes, str]:
    """Build the gateway's OpenAI-compatible Gemini Images request.

    text_to_image uses JSON /images/generations. Reference and edit modes use
    multipart /images/edits with repeated image fields. The first image in
    image_to_image_edit is the authoritative base image, followed by explicit
    reference images from reference-plan.json.
    """
    params = validated["parameters"]
    allowed = {"size", "quality"}
    unknown = sorted(set(params) - allowed)
    require(not unknown, f"unsupported Gemini parameters: {', '.join(unknown)}")
    size = str(params.get("size", "1:1"))
    quality = str(params.get("quality", "4k")).lower()
    require(size in GEMINI_ASPECT_RATIOS, "unsupported Gemini size/aspect ratio")
    require(quality == "4k", "Gemini quality must be 4k")
    require(validated["output"].suffix.lower() == ".png", "Gemini output_path must use .png")
    fields = {
        "model": validated["model"],
        "prompt": validated["prompt"],
        "size": size,
        "quality": quality,
        "n": "1",
    }
    if validated["mode"] == "text_to_image":
        body = {**fields, "n": 1}
        return json.dumps(body, ensure_ascii=False).encode("utf-8"), "application/json"
    images = ([validated["base_image"]] if validated["base_image"] else []) + validated["references"]
    require(bool(images), "Gemini reference/edit request requires at least one input image")
    return multipart(fields, [("image", path) for path in images])


def seedance_payload(validated: dict[str, Any]) -> tuple[bytes, str]:
    params = validated["parameters"]
    allowed = {"ratio", "resolution", "duration", "generate_audio", "seed", "watermark", "return_last_frame"}
    unknown = sorted(set(params) - allowed)
    require(not unknown, f"unsupported Seedance parameters: {', '.join(unknown)}")
    ratio = str(params.get("ratio", "adaptive"))
    resolution = str(params.get("resolution", DEFAULT_SEEDANCE_RESOLUTION))
    duration = params.get("duration", 5)
    generate_audio = params.get("generate_audio", DEFAULT_SEEDANCE_GENERATE_AUDIO)
    watermark = params.get("watermark", False)
    return_last_frame = params.get("return_last_frame", False)
    seed = params.get("seed", None)
    require(ratio in {"16:9", "4:3", "1:1", "3:4", "9:16", "21:9", "adaptive"}, "unsupported Seedance ratio")
    require(resolution in {"480p", "720p", "1080p"}, "unsupported Seedance resolution")
    require(isinstance(duration, (int, float)) and not isinstance(duration, bool) and duration > 0, "Seedance duration must be a positive number")
    require(isinstance(generate_audio, bool) and isinstance(watermark, bool) and isinstance(return_last_frame, bool),
            "Seedance generate_audio, watermark, and return_last_frame must be boolean")
    if seed is not None:
        require(isinstance(seed, (int, float)) and not isinstance(seed, bool), "Seedance seed must be a number")
    if validated["model"] == "doubao-seedance-2-0-fast-260128":
        require(resolution != "1080p", "Seedance 2.0 Fast does not support 1080p")
    content: list[dict[str, Any]] = []
    for url in validated["reference_images"]:
        content.append({"type": "image_url", "image_url": {"url": url}, "role": "reference_image"})
    for url in validated["reference_videos"]:
        content.append({"type": "video_url", "video_url": {"url": url}, "role": "reference_video"})
    if validated["first_frame"]:
        content.append({"type": "image_url", "image_url": {"url": validated["first_frame"]}, "role": "first_frame"})
    if validated["last_frame"]:
        content.append({"type": "image_url", "image_url": {"url": validated["last_frame"]}, "role": "last_frame"})
    metadata: dict[str, Any] = {
        "resolution": resolution,
        "ratio": ratio,
        "duration": duration,
        "generate_audio": generate_audio,
        "watermark": watermark,
        "return_last_frame": return_last_frame,
    }
    if seed is not None:
        metadata["seed"] = seed
    if content:
        metadata["content"] = content
    body = {
        "model": validated["model"],
        "prompt": validated["prompt"],
        "metadata": metadata,
    }
    return json.dumps(body, ensure_ascii=False).encode("utf-8"), "application/json"


def configured_endpoint(profile: dict[str, Any], path_key: str, *, model: str = "", task_id: str = "") -> str:
    path = str(profile[path_key]).replace("{model}", quote(model, safe="")).replace("{task_id}", quote(task_id, safe=""))
    # Gateways commonly configure the shared base as either host-only or host + /v1.
    # Do not duplicate a version prefix when a profile path already contains it.
    base = profile["base_url"].rstrip("/")
    base_path = urlparse(base).path.rstrip("/")
    path_clean = "/" + path.lstrip("/")
    if base_path.endswith("/v1") and path_clean.startswith("/v1/"):
        base = base[:-3].rstrip("/")
    combined = urljoin(base + "/", path_clean.lstrip("/"))
    return validate_url(combined, allow_insecure_http=profile["allow_insecure_http"], label="endpoint")


def url_origin(value: str) -> tuple[str, str, int]:
    parsed = urlparse(value)
    require(bool(parsed.hostname), "URL must contain a host")
    try:
        port = parsed.port or (443 if parsed.scheme.lower() == "https" else 80)
    except ValueError as exc:
        raise ApiError("URL contains an invalid port") from exc
    return parsed.scheme.lower(), str(parsed.hostname).lower(), port


class SameOriginRedirectHandler(urllib.request.HTTPRedirectHandler):
    def __init__(self, origin: tuple[str, str, int]) -> None:
        super().__init__()
        self.origin = origin

    def redirect_request(self, req: Any, fp: Any, code: int, msg: str, headers: Any, newurl: str) -> urllib.request.Request | None:
        require(url_origin(newurl) == self.origin, "HTTP redirect left the API origin")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class SafeMediaRedirectHandler(urllib.request.HTTPRedirectHandler):
    def __init__(self, allow_insecure_http: bool) -> None:
        super().__init__()
        self.allow_insecure_http = allow_insecure_http

    def redirect_request(self, req: Any, fp: Any, code: int, msg: str, headers: Any, newurl: str) -> urllib.request.Request | None:
        validate_url(newurl, allow_insecure_http=self.allow_insecure_http, label="media redirect URL")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def auth_headers(mode: str, key: str) -> dict[str, str]:
    if mode == "bearer":
        return {"Authorization": f"Bearer {key}"}
    if mode == "x-goog-api-key":
        return {"x-goog-api-key": key}
    raise ApiError("unsupported auth mode")


def http_json(method: str, url: str, *, body: bytes | None, content_type: str | None, headers: dict[str, str], timeout: int, max_bytes: int) -> tuple[dict[str, Any], dict[str, str], int]:
    request_headers = {"Accept": "application/json", "User-Agent": "codex-generation-api/1", **headers}
    if content_type:
        request_headers["Content-Type"] = content_type
    request = urllib.request.Request(url, data=body, method=method, headers=request_headers)
    opener = urllib.request.build_opener(SameOriginRedirectHandler(url_origin(url)))
    try:
        with opener.open(request, timeout=timeout) as response:
            actual = response.headers.get_content_type().lower()
            require(actual == "application/json", f"API returned unsupported content type: {actual}")
            data = response.read(max_bytes + 1)
            if len(data) > max_bytes:
                raise ApiError(
                    f"API response exceeds size limit: {len(data)} bytes > limits.max_json_bytes={max_bytes}. "
                    "Request a smaller size, or output_format=jpeg for the same resolution, "
                    "or raise limits.max_json_bytes in the api-runtime config."
                )
            value = json.loads(data.decode("utf-8"))
            require(isinstance(value, dict), "API response root must be an object")
            return value, {key.lower(): val for key, val in response.headers.items()}, int(response.status)
    except urllib.error.HTTPError as exc:
        raise ApiError(f"API returned HTTP {exc.code}") from exc
    except urllib.error.URLError as exc:
        reason = str(exc.reason)
        if isinstance(exc.reason, TimeoutError) or "timed out" in reason.lower():
            raise ApiTimeout("API response timed out") from exc
        raise ApiError(f"network request failed: {reason}") from exc
    except TimeoutError as exc:
        raise ApiTimeout("API response timed out") from exc
    except (json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise ApiError("API response was not valid JSON") from exc


def decode_base64(value: str) -> bytes:
    try:
        return base64.b64decode(value, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise ApiError("API returned invalid image base64") from exc


def find_image(value: Any) -> tuple[bytes | None, str | None]:
    if isinstance(value, str):
        if value.startswith("data:image/"):
            header, sep, payload = value.partition(",")
            require(sep and ";base64" in header.lower(), "API returned unsupported image data URI")
            return decode_base64(payload), None
        if value.startswith(("http://", "https://")):
            return None, value
    elif isinstance(value, dict):
        for key in ("b64_json", "image_base64"):
            if isinstance(value.get(key), str) and value[key]:
                return decode_base64(value[key]), None
        for key in ("data_uri", "image_data_uri"):
            raw = value.get(key)
            if isinstance(raw, str) and raw.startswith("data:image/"):
                header, sep, payload = raw.partition(",")
                require(sep and ";base64" in header.lower(), "API returned unsupported image data URI")
                return decode_base64(payload), None
        for key in ("inline_data", "inlineData"):
            part = value.get(key)
            if isinstance(part, dict) and isinstance(part.get("data"), str):
                return decode_base64(part["data"]), None
        for key in ("url", "fileUri", "file_uri"):
            candidate = value.get(key)
            if isinstance(candidate, str) and candidate.startswith(("http://", "https://")):
                return None, candidate
        for key in ("fileData", "file_data"):
            part = value.get(key)
            if isinstance(part, dict):
                candidate = part.get("fileUri") or part.get("file_uri")
                if isinstance(candidate, str) and candidate.startswith(("http://", "https://")):
                    return None, candidate
        # Some OpenAI-compatible gateways return a raw data URI as a string field.
        for candidate in value.values():
            if isinstance(candidate, str) and candidate.startswith("data:image/"):
                header, sep, payload = candidate.partition(",")
                require(sep and ";base64" in header.lower(), "API returned unsupported image data URI")
                return decode_base64(payload), None
        for child in value.values():
            data, url = find_image(child)
            if data is not None or url is not None:
                return data, url
    elif isinstance(value, list):
        for child in value:
            data, url = find_image(child)
            if data is not None or url is not None:
                return data, url
    return None, None



def find_openai_images_result(value: Any) -> tuple[bytes | None, str | None]:
    """Parse OpenAI-compatible Images responses, preferring data[].url over data[].b64_json."""
    require(isinstance(value, dict), "Images API response root must be an object")
    data = value.get("data")
    require(isinstance(data, list) and bool(data), "Images API response contains no data items")
    for item in data:
        if isinstance(item, dict):
            url = item.get("url")
            if isinstance(url, str) and url.startswith(("http://", "https://")):
                return None, url
    for item in data:
        if isinstance(item, dict):
            raw = item.get("b64_json")
            if isinstance(raw, str) and raw:
                return decode_base64(raw), None
    raise ApiError("Images API response contains neither data[].url nor data[].b64_json")

def find_video_url(value: Any) -> str | None:
    if isinstance(value, dict):
        direct = value.get("video_url")
        if isinstance(direct, str) and direct.startswith(("http://", "https://")):
            return direct
        if isinstance(direct, dict) and isinstance(direct.get("url"), str):
            return direct["url"]
        for child in value.values():
            found = find_video_url(child)
            if found:
                return found
    elif isinstance(value, list):
        for child in value:
            found = find_video_url(child)
            if found:
                return found
    return None


def download_binary(url: str, profile: dict[str, Any], max_bytes: int, accepted_types: set[str]) -> tuple[bytes, str]:
    validate_url(url, allow_insecure_http=profile["allow_insecure_http"], label="media URL")
    request = urllib.request.Request(url, headers={"User-Agent": "codex-generation-api/1"})
    opener = urllib.request.build_opener(SafeMediaRedirectHandler(profile["allow_insecure_http"]))
    try:
        with opener.open(request, timeout=profile["media_download_timeout_seconds"]) as response:
            content_type = response.headers.get_content_type().lower()
            require(content_type in accepted_types, f"download returned unsupported content type: {content_type}")
            data = response.read(max_bytes + 1)
            if len(data) > max_bytes:
                raise ApiError(
                    f"downloaded media exceeds size limit: {len(data)} bytes > limit {max_bytes}; "
                    "raise limits.max_image_bytes or limits.max_video_bytes in the api-runtime config."
                )
            require(bool(data), "downloaded media is empty")
            return data, content_type
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError) as exc:
        raise ApiError("media download failed") from exc


def inspect_image(data: bytes) -> dict[str, Any]:
    try:
        from PIL import Image
    except ImportError as exc:
        raise ApiError("Pillow is not installed") from exc
    try:
        with Image.open(io.BytesIO(data)) as image:
            image.load()
            has_alpha = "A" in image.getbands() or "transparency" in image.info
            alpha_min = alpha_max = None
            if has_alpha:
                alpha_min, alpha_max = image.convert("RGBA").getchannel("A").getextrema()
            return {
                "width": image.width, "height": image.height, "format": str(image.format or "").lower(),
                "mode": image.mode, "has_alpha": has_alpha, "alpha_min": alpha_min, "alpha_max": alpha_max,
            }
    except Exception as exc:
        raise ApiError("API output is not a readable image") from exc


def validate_image_dimensions(validated: dict[str, Any], inspection: dict[str, Any]) -> None:
    width, height = int(inspection["width"]), int(inspection["height"])
    params = validated["parameters"]
    if validated["api_profile"] == "gpt":
        size = str(params.get("size", "auto"))
        if size != "auto":
            expected_width, expected_height = (int(item) for item in size.split("x"))
            require((width, height) == (expected_width, expected_height), f"API returned {width}x{height}, expected {size}")
        return
    quality = str(params.get("quality", "4k")).lower()
    require(quality == "4k", "Gemini quality must be 4k")
    require(max(width, height) >= 3800, f"API returned {width}x{height}, below requested 4k threshold")
    ratio_text = str(params.get("size", "1:1"))
    ratio_width, ratio_height = (int(item) for item in ratio_text.split(":"))
    expected_ratio = ratio_width / ratio_height
    actual_ratio = width / height
    require(abs(actual_ratio - expected_ratio) / expected_ratio <= 0.03, f"API returned aspect ratio {width}:{height}, expected {ratio_text}")


def inspect_video_container(data: bytes) -> str:
    if len(data) >= 12 and data[4:8] == b"ftyp":
        return "mp4-family"
    if data.startswith(b"\x1aE\xdf\xa3"):
        return "webm"
    raise ApiError("API output is not a recognized MP4/MOV or WebM container")


def atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        temp.write_bytes(data)
        os.replace(temp, path)
    finally:
        if temp.exists():
            temp.unlink()


def configure_runtime(path: Path) -> dict[str, Any]:
    raw = read_json(path, "API runtime config")
    connection = raw.setdefault("connection", {})
    profiles = raw.setdefault("profiles", {})
    # The shared gateway and non-secret defaults live in this JSON file. The
    # first-session interaction collects only the real credential.
    require(str(connection.get("base_url", "")).strip(), "config.connection.base_url must be set before API key configuration")
    require(str(connection.get("auth_mode", "")).strip(), "config.connection.auth_mode must be set before API key configuration")
    require(str(connection.get("credential_store", "")).strip(), "config.connection.credential_store must be set before API key configuration")
    require(isinstance(connection.get("allow_insecure_http", False), bool), "config.connection.allow_insecure_http must be boolean")
    for name in PROFILE_NAMES:
        profile = profiles.setdefault(name, {})
        require(str(profile.get("default_model", "")).strip(), f"config.profiles.{name}.default_model must be set before API key configuration")
    secret = getpass.getpass("Generation API key (local hidden input): ").strip()
    require(bool(secret), "API key is empty")
    encoded = (json.dumps(raw, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    temp = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        temp.write_bytes(encoded)
        validated_root = load_config_root(temp)
        for name in PROFILE_NAMES:
            load_profile(validated_root, name)
        credential_path = persist_user_credential(validated_root["connection"]["credential_store"], secret)
        os.replace(temp, path)
    finally:
        if temp.exists():
            temp.unlink()
    return {
        "status": "configured",
        "config": str(path),
        "base_url": validated_root["connection"]["base_url"],
        "auth_mode": validated_root["connection"]["auth_mode"],
        "credential_store": validated_root["connection"]["credential_store"],
        "credential_present": True,
        "credential_value_exposed": False,
        "credential_path": str(credential_path),
        "credential_persisted": True,
        "profiles": {name: {"default_model": load_profile(validated_root, name)["default_model"]} for name in PROFILE_NAMES},
        "online_verified": False,
    }


def summarize(validated: dict[str, Any], endpoint: str) -> dict[str, Any]:
    prompt_bytes = validated["prompt"].encode("utf-8")
    result = {
        "api_profile": validated["api_profile"],
        "endpoint_path": urlparse(endpoint).path,
        "mode": validated["mode"],
        "model": validated["model"],
        "prompt_sha256": hashlib.sha256(prompt_bytes).hexdigest(),
        "prompt_path": validated["prompt_source"]["path"],
        "prompt_source_sha256": validated["prompt_source"]["sha256"],
        "personal_binding": validated["prompt_source"].get("personal_binding", {"enabled": False, "preference_count": 0, "skill_count": 0}),
        "prompt_length": len(validated["prompt"]),
        "parameters": validated["parameters"],
        "output_path": workspace_relative(validated["output"], validated["workspace_root"]),
        "generation_plan_binding": validated.get("generation_plan_binding"),
        "visual_reconstruction_binding": validated.get("visual_reconstruction_binding"),
        # The carrier receipt is computed on every validated prompt; persisting it here
        # is what makes it machine evidence instead of a value nobody reads.
        "presentation": carrier_receipt(validated["prompt"]),
    }
    if validated["api_profile"] in {"gemini", "gpt"}:
        result.update({
            "reference_count": len(validated["references"]),
            "reference_images": [workspace_relative(path, validated["workspace_root"]) for path in validated["references"]],
            "reference_sha256": [hashlib.sha256(path.read_bytes()).hexdigest() for path in validated["references"]],
            "has_base_image": validated["base_image"] is not None,
            "base_image": workspace_relative(validated["base_image"], validated["workspace_root"]) if validated["base_image"] else None,
            "base_image_sha256": hashlib.sha256(validated["base_image"].read_bytes()).hexdigest() if validated["base_image"] else None,
            "has_mask_image": validated["mask_image"] is not None,
            "mask_image_sha256": hashlib.sha256(validated["mask_image"].read_bytes()).hexdigest() if validated["mask_image"] else None,
            "ip_character_binding": validated.get("ip_character_binding"),
        })
        if validated["api_profile"] == "gpt":
            result["gpt_intent_binding"] = validated.get("gpt_intent_binding")
    else:
        result.update({
            "has_first_frame": bool(validated["first_frame"]),
            "has_last_frame": bool(validated["last_frame"]),
            "reference_image_count": len(validated["reference_images"]),
            "reference_video_count": len(validated["reference_videos"]),
            "source_evidence": validated.get("source_evidence", {}),
        })
    return result


def check_configuration(path: Path, selected: str | None) -> tuple[dict[str, Any], bool]:
    try:
        root = load_config_root(path)
    except ApiError as exc:
        return {
            "status": "blocked",
            "config": str(path.resolve()),
            "connection": {
                "status": "blocked",
                "reason": str(exc),
                "credential_value_exposed": False,
                "network_called": False,
            },
            "profiles": {},
            "online_verified": False,
        }, False
    connection = root["connection"]
    credential_present = bool(credential_value(connection["credential_store"]))
    connection_status: dict[str, Any] = {
        "status": "ready" if credential_present else "blocked",
        "base_url": connection["base_url"],
        "auth_mode": connection["auth_mode"],
        "credential_store": connection["credential_store"],
        "credential_present": credential_present,
        "credential_value_exposed": False,
        "network_called": False,
    }
    if not credential_present:
        connection_status["reason"] = f"credential store is missing or empty: {connection['credential_store']}"
    names = (selected,) if selected else PROFILE_NAMES
    statuses: dict[str, Any] = {}
    ready = credential_present
    for name in names:
        try:
            profile = load_profile(root, name)
            entry = {
                "status": "ready",
                "protocol": profile["protocol"],
                "default_model": profile["default_model"],
                "network_called": False,
            }
            for key in ("generation_path", "edit_path", "submit_path", "query_path"):
                if key in profile:
                    entry[key] = profile[key]
            statuses[name] = entry
        except ApiError as exc:
            ready = False
            statuses[name] = {"status": "blocked", "reason": str(exc), "credential_value_exposed": False, "network_called": False}
    return {
        "status": "ready" if ready else "blocked",
        "config": str(path.resolve()),
        "connection": connection_status,
        "profiles": statuses,
        "online_verified": False,
    }, ready


def image_endpoint(profile: dict[str, Any], validated: dict[str, Any]) -> str:
    key = "generation_path" if validated["mode"] == "text_to_image" else "edit_path"
    return configured_endpoint(profile, key)


def extract_service_request_id(headers: dict[str, str], response: dict[str, Any]) -> tuple[str | None, str | None]:
    """Return a provider trace id without mistaking media item ids for request ids."""
    candidates: list[tuple[str, Any]] = [
        ("header:x-request-id", headers.get("x-request-id")),
        ("header:request-id", headers.get("request-id")),
        ("header:x-goog-request-id", headers.get("x-goog-request-id")),
        ("response:id", response.get("id")),
        ("response:request_id", response.get("request_id")),
        ("response:requestId", response.get("requestId")),
    ]
    for container_name in ("metadata", "meta", "request_metadata"):
        container = response.get(container_name)
        if isinstance(container, dict):
            for field in ("request_id", "requestId", "id"):
                candidates.append((f"response:{container_name}.{field}", container.get(field)))
    for source, value in candidates:
        if isinstance(value, str) and value.strip():
            return value.strip(), source
    return None, None


def invoke_image(profile: dict[str, Any], validated: dict[str, Any], key: str) -> dict[str, Any]:
    endpoint = image_endpoint(profile, validated)
    body, content_type = gemini_payload(validated) if profile["name"] == "gemini" else gpt_payload(validated)
    try:
        validated["network_called"] = True
        response, headers, status = http_json(
            "POST", endpoint, body=body, content_type=content_type,
            headers=auth_headers(profile["auth_mode"], key), timeout=profile["request_timeout_seconds"], max_bytes=profile["max_json_bytes"],
        )
    except ApiTimeout as exc:
        raise AmbiguousRemoteState(
            f"image request exceeded {profile['request_timeout_seconds']}s; remote generation state is unknown"
        ) from exc
    require(200 <= status < 300, f"image API returned non-success HTTP status: {status}")
    service_request_id, service_request_id_source = extract_service_request_id(headers, response)
    service_request_id_status = "provided" if service_request_id else "provider_not_supplied"
    request_payload_sha256 = hashlib.sha256(body).hexdigest()
    response_sha256 = hashlib.sha256(
        json.dumps(response, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    validated["response_evidence"] = {
        "http_status": status,
        "service_request_id": service_request_id,
        "service_request_id_status": service_request_id_status,
        "service_request_id_source": service_request_id_source,
        "request_payload_sha256": request_payload_sha256,
        "response_sha256": response_sha256,
    }
    executor_path = Path(__file__).resolve()
    image_data, image_url = find_openai_images_result(response)
    if image_data is None:
        image_data, _ = download_binary(
            str(image_url), profile, profile["max_image_bytes"],
            {"image/png", "image/jpeg", "image/webp", "application/octet-stream"},
        )
    inspection = inspect_image(image_data)
    validate_image_dimensions(validated, inspection)
    expected = str(validated["parameters"].get("output_format", validated["output"].suffix.lstrip("."))).lower()
    expected = "jpeg" if expected in {"jpg", "jpeg"} else expected
    actual = "jpeg" if inspection["format"] in {"jpg", "jpeg"} else inspection["format"]
    require(expected in {"png", "jpeg", "webp"}, "unsupported expected image format")
    require(actual == expected, f"API returned {actual}, expected {expected}")
    if validated["api_profile"] == "gpt" and str(validated["parameters"].get("background", "")).lower() == "transparent":
        require(expected in {"png", "webp"}, "transparent GPT output must use PNG or WebP")
        require(bool(inspection.get("has_alpha")), "API returned no alpha channel for background=transparent")
        require(inspection.get("alpha_min") is not None and int(inspection["alpha_min"]) < 255,
                "API returned a fully opaque image for background=transparent")
        require(inspection.get("alpha_max") is not None and int(inspection["alpha_max"]) > 0,
                "API returned a fully transparent image")
    atomic_write(validated["output"], image_data)
    return {
        "schema_version": CALL_RECEIPT_SCHEMA,
        "status": "success", **summarize(validated, endpoint), "http_status": status,
        "service_request_id": service_request_id,
        "service_request_id_status": service_request_id_status,
        "service_request_id_source": service_request_id_source,
        "request_payload_sha256": request_payload_sha256,
        "response_sha256": response_sha256,
        "executor_binding": {
            "path": workspace_relative(executor_path, validated["workspace_root"]),
            "sha256": sha256_file(executor_path),
        },
        "remote_media_url": image_url if isinstance(image_url, str) else None,
        "output_sha256": hashlib.sha256(image_data).hexdigest(), "file_size_bytes": len(image_data),
        **inspection, "credential_persisted": False, "network_called": True,
    }


def invoke_seedance(profile: dict[str, Any], validated: dict[str, Any], key: str,
                    attempt_state: dict[str, Any], persist_attempt: Callable[[], None]) -> dict[str, Any]:
    endpoint = configured_endpoint(profile, "submit_path")
    task_id = attempt_state.get("task_id")
    if task_id is not None:
        require(isinstance(task_id, str) and bool(task_id.strip()),
                "existing Seedance attempt has an invalid task id")
    headers: dict[str, str] = {}
    submit_status = attempt_state.get("submit_http_status")
    if not isinstance(task_id, str) or not task_id.strip():
        body, content_type = seedance_payload(validated)
        try:
            validated["network_called"] = True
            response, headers, submit_status = http_json(
                "POST", endpoint, body=body, content_type=content_type,
                headers=auth_headers(profile["auth_mode"], key), timeout=profile["submit_timeout_seconds"], max_bytes=profile["max_json_bytes"],
            )
        except ApiTimeout as exc:
            raise AmbiguousRemoteState(
                f"Seedance submit exceeded {profile['submit_timeout_seconds']}s; remote task creation state is unknown"
            ) from exc
        task_id = response.get("id") or response.get("task_id")
        require(isinstance(task_id, str) and bool(task_id.strip()), "Seedance submit response contains no task id")
        task_id = task_id.strip()
        attempt_state.update({
            "status": "polling",
            "task_id": task_id,
            "submit_http_status": submit_status,
        "service_request_id": headers.get("x-request-id") or headers.get("request-id") or attempt_state.get("service_request_id"),
            "poll_count": 0,
        })
        persist_attempt()
    else:
        task_id = task_id.strip()
        validated["network_called"] = True
    final_response: dict[str, Any] | None = None
    final_status = "timeout"
    query_http_status: int | None = None
    raw_poll_count = attempt_state.get("poll_count", 0)
    require(type(raw_poll_count) is int, "Seedance poll_count must be an integer")
    poll_count = raw_poll_count
    require(0 <= poll_count < profile["poll_total_attempts"], "Seedance polling exhausted total attempt limit")
    slice_attempts = min(profile["poll_slice_attempts"], profile["poll_total_attempts"] - poll_count)
    for _ in range(slice_attempts):
        if profile["poll_interval_seconds"] > 0:
            time.sleep(profile["poll_interval_seconds"])
        query_url = configured_endpoint(profile, "query_path", task_id=task_id)
        poll_count += 1
        attempt_state["poll_count"] = poll_count
        try:
            query, _, query_http_status = http_json(
                "GET", query_url, body=None, content_type=None,
                headers=auth_headers(profile["auth_mode"], key), timeout=profile["query_timeout_seconds"], max_bytes=profile["max_json_bytes"],
            )
        except ApiTimeout:
            attempt_state.update({"status": "polling", "last_task_status": "query_timeout"})
            persist_attempt()
            continue
        state = str(query.get("status", "")).lower()
        attempt_state.update({"status": "polling", "last_task_status": state,
                              "query_http_status": query_http_status})
        persist_attempt()
        if state == "succeeded":
            final_response = query
            final_status = state
            break
        if state in {"failed", "expired", "cancelled"}:
            raise ApiError(f"Seedance task ended with status: {state}")
        require(state in {"queued", "running", "processing", "pending"}, f"Seedance returned unknown task status: {state or 'missing'}")
    if final_response is None:
        if poll_count >= profile["poll_total_attempts"]:
            raise ApiError("Seedance polling exhausted total attempt limit")
        raise PollingPaused(
            f"Seedance task is still pending after this polling slice; resume the same request ({poll_count}/{profile['poll_total_attempts']})"
        )
    content = final_response.get("content") if isinstance(final_response, dict) else None
    video_url = content.get("video_url") if isinstance(content, dict) else None
    require(isinstance(video_url, str) and video_url.startswith(("http://", "https://")), "Seedance success response contains no content.video_url")
    last_frame_url = content.get("last_frame_url") if isinstance(content, dict) else None
    if validated["parameters"].get("return_last_frame", False):
        require(isinstance(last_frame_url, str) and last_frame_url.startswith(("http://", "https://")),
                "Seedance return_last_frame=true but response contains no content.last_frame_url")
    video_data, content_type = download_binary(
        str(video_url), profile, profile["max_video_bytes"],
        {"video/mp4", "video/webm", "video/quicktime", "application/octet-stream"},
    )
    container = inspect_video_container(video_data)
    expected_container = "webm" if validated["output"].suffix.lower() == ".webm" else "mp4-family"
    require(container == expected_container, f"video container {container} does not match output extension")
    atomic_write(validated["output"], video_data)
    return {
        "status": "success", **summarize(validated, endpoint), "submit_http_status": submit_status,
        "query_http_status": query_http_status, "service_request_id": headers.get("x-request-id") or headers.get("request-id"),
        "task_id": task_id, "task_status": final_status, "media_content_type": content_type, "container": container,
        "last_frame_url": last_frame_url if isinstance(last_frame_url, str) else None,
        "output_sha256": hashlib.sha256(video_data).hexdigest(), "file_size_bytes": len(video_data),
        "credential_persisted": False, "network_called": True,
    }


def doctor() -> dict[str, Any]:
    pixel = base64.b64decode("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=")
    inspection = inspect_image(pixel)
    require(inspection["has_alpha"] is True and inspection["alpha_min"] == 255, "opaque-alpha inspection failed")
    try:
        from PIL import Image
        transparent_buffer = io.BytesIO()
        transparent_test = Image.new("RGBA", (2, 1), (255, 0, 0, 0))
        transparent_test.putpixel((1, 0), (255, 0, 0, 255))
        transparent_test.save(transparent_buffer, format="PNG")
        transparent_inspection = inspect_image(transparent_buffer.getvalue())
        require(transparent_inspection["has_alpha"] is True and transparent_inspection["alpha_min"] == 0
                and transparent_inspection["alpha_max"] == 255, "transparent-alpha inspection failed")
    except ImportError as exc:
        raise ApiError("Pillow is not installed") from exc
    require(DIRECT_IMAGE_CALLERS.get("wxian-image-layer-decomposition") == "kv-layer-reconstruction",
            "KV layer reconstruction direct generation binding is missing")
    require(DIRECT_IMAGE_CALLERS.get("wxian-game-ui-layer-decomposition") == "game-ui-layer-reconstruction",
            "game UI layer reconstruction direct generation binding is missing")
    encoded = base64.b64encode(pixel).decode("ascii")
    require(find_image({"data": [{"b64_json": encoded}]})[0] == pixel, "GPT response parser failed")
    require(find_image({"candidates": [{"content": {"parts": [{"inline_data": {"data": encoded}}]}}]})[0] == pixel, "Gemini response parser failed")
    require(find_image({"data": [f"data:image/png;base64,{encoded}"]})[0] == pixel, "GPT data URI parser failed")
    require(find_image({"fileData": {"fileUri": "https://example.test/image.png"}})[1] == "https://example.test/image.png", "Gemini fileUri parser failed")
    require(find_video_url({"content": [{"type": "video_url", "video_url": {"url": "https://example.test/out.mp4"}}]}) == "https://example.test/out.mp4", "Seedance response parser failed")
    seedance_resume_profile = {
        "base_url": "https://provider.example", "submit_path": "/v1/videos",
        "query_path": "/v1/videos/{task_id}", "allow_insecure_http": False,
        "poll_slice_attempts": 15, "poll_total_attempts": 360,
    }
    for invalid_attempt in (
        {"task_id": " ", "status": "polling", "poll_count": 0},
        {"task_id": "task-valid", "status": "polling", "poll_count": "0"},
    ):
        try:
            invoke_seedance(seedance_resume_profile, {"network_called": False}, "test-key", invalid_attempt, lambda: None)
        except ApiError:
            pass
        else:
            raise ApiError("malformed Seedance resume state was accepted")
    require(CURRENT_GEMINI_IMAGE_MODEL == "gemini-3.1-flash-image-preview", "current Gemini image model constant is stale")
    require(DEFAULT_GPT_IMAGE_MODEL == GPT_IMAGE_25_FLARE, "current GPT image default is stale")
    generic = resolve_gpt_request("请用gpt生图", aspect_ratio="1:1")
    require(generic["model"] == GPT_IMAGE_25_FLARE, "generic GPT generation must route to Flare")
    require(generic["parameters"] == {"size": "2880x2880", "quality": "max", "background": "opaque", "moderation": "auto", "output_format": "png"},
            "generic GPT Image 2.5 defaults are stale")
    image2 = resolve_gpt_request("请用image2生图", aspect_ratio="16:9")
    require(image2["model"] == GPT_IMAGE_2 and image2["parameters"]["size"] == "3840x2160" and image2["parameters"]["quality"] == "high",
            "image2 routing contract failed")
    image25 = resolve_gpt_request("请用image2.5生图", aspect_ratio="4:3")
    require(image25["model"] == GPT_IMAGE_25_SUNBURST and image25["parameters"]["size"] == "3264x2448",
            "image2.5 routing contract failed")
    four_k = resolve_gpt_request("gpt生图，高清 4K PNG透明底", aspect_ratio="16:9")
    require(four_k["model"] == GPT_IMAGE_25_SUNBURST and four_k["parameters"]["quality"] == "max",
            "4K/high-fidelity routing contract failed")
    require(four_k["parameters"]["size"] == "3840x2160" and four_k["parameters"]["background"] == "transparent"
            and four_k["parameters"]["output_format"] == "png", "4K transparent PNG defaults failed")
    try:
        validate_resolved_gpt_request("gpt生图，高清 4K PNG透明底", GPT_IMAGE_25_FLARE, {}, aspect_ratio="16:9")
    except ValueError:
        pass
    else:
        raise ApiError("hand-authored GPT request bypassed the resolved model")
    # 4K is a size request, not a quality alias. Explicit legal quality overrides remain legal.
    low_4k = validate_resolved_gpt_request(
        "gpt生图，高清 4K PNG透明底", GPT_IMAGE_25_SUNBURST,
        {**four_k["parameters"], "quality": "low"}, aspect_ratio="16:9",
    )
    require(low_4k["parameters"]["quality"] == "low", "4K incorrectly forced a quality tier")
    for ratio, expected in {"1:1": "2880x2880", "16:9": "3840x2160", "4:3": "3264x2448", "9:16": "2160x3840", "3:4": "2448x3264"}.items():
        require(resolve_gpt_request("gpt生图", aspect_ratio=ratio)["parameters"]["size"] == expected,
                f"GPT Image 2.5 ratio default failed: {ratio}")
    special_ratio = resolve_gpt_request("gpt生图 21:9")
    require(special_ratio["parameters"]["size"] == "3808x1632", "custom GPT Image 2.5 ratio resolution failed")
    image2_special_ratio = resolve_gpt_request("image2生图 21:9")
    require(image2_special_ratio["model"] == GPT_IMAGE_2 and image2_special_ratio["parameters"]["size"] == "3808x1632",
            "gpt-image-2 custom ratio resolution failed")
    image2_special_size = resolve_gpt_request("image2生图 2048x1152")
    require(image2_special_size["parameters"]["size"] == "2048x1152",
            "gpt-image-2 custom size resolution failed")
    explicit_overrides = validate_resolved_gpt_request(
        "gpt生图", GPT_IMAGE_25_FLARE,
        {"size": "2048x1152", "quality": "high", "background": "auto", "moderation": "low", "output_format": "webp"},
        aspect_ratio="1:1",
    )
    require(explicit_overrides["parameters"] == {
        "size": "2048x1152", "quality": "high", "background": "auto", "moderation": "low", "output_format": "webp"
    }, "valid explicit GPT parameter overrides were not preserved")
    require(model_scoped_text_applies("GPT-IMAGE-2 only", GPT_IMAGE_2), "gpt-image-2 scoped preference was dropped")
    require(not model_scoped_text_applies("GPT-IMAGE-2 only", GPT_IMAGE_25_FLARE), "gpt-image-2 preference leaked to GPT Image 2.5")
    require(model_scoped_text_applies("IMAGE2.5 only", GPT_IMAGE_25_SUNBURST), "GPT Image 2.5 scoped preference was dropped")
    for bad_model, bad_size, bad_quality in [
        (GPT_IMAGE_25_FLARE, "3856x2160", "max"),
        (GPT_IMAGE_25_FLARE, "1000x1000", "max"),
        (GPT_IMAGE_2, "3840x2176", "high"),
        (GPT_IMAGE_2, "1024x1024", "xhigh"),
    ]:
        try:
            validate_gpt_size(bad_model, bad_size)
            validate_gpt_quality(bad_model, bad_quality)
        except ValueError:
            pass
        else:
            raise ApiError(f"invalid GPT contract was accepted: {bad_model} {bad_size} {bad_quality}")
    with tempfile.TemporaryDirectory() as temp_dir:
        source = Path(temp_dir) / "source.png"
        source.write_bytes(pixel)
        receipt_root = Path(temp_dir) / "receipt-workspace"
        receipt_output = receipt_root / "requests" / "image-generation" / "receipt-case" / "work" / "output.png"
        receipt_prompt = receipt_root / "requests" / "image-generation" / "receipt-case" / "work" / "prompt.txt"
        receipt_prompt.parent.mkdir(parents=True, exist_ok=True)
        receipt_prompt.write_text("draw one pixel", encoding="utf-8")
        receipt_validated = {
            "api_profile": "gpt", "mode": "text_to_image", "model": GPT_IMAGE_25_FLARE,
            "prompt": "draw one pixel", "prompt_source": {
                "path": workspace_relative(receipt_prompt, receipt_root), "sha256": sha256_file(receipt_prompt),
            },
            "parameters": {"size": "auto", "quality": "max", "background": "opaque", "moderation": "auto", "output_format": "png"},
            "output": receipt_output, "workspace_root": receipt_root,
            "references": [], "base_image": None, "mask_image": None,
            "generation_plan_binding": None, "visual_reconstruction_binding": None,
            "ip_character_binding": None, "gpt_intent_binding": None,
        }
        receipt_profile = {
            "name": "gpt", "base_url": "https://provider.example", "generation_path": "/v1/images/generations",
            "edit_path": "/v1/images/edits", "auth_mode": "bearer", "allow_insecure_http": False,
            "request_timeout_seconds": 10,
            "max_json_bytes": 1024 * 1024, "max_image_bytes": 1024 * 1024,
        }
        encoded_pixel = base64.b64encode(pixel).decode("ascii")
        original_http_json = globals()["http_json"]
        original_workspace_relative = globals()["workspace_relative"]
        def fixture_workspace_relative(path: Path, root: Path) -> str:
            try:
                return original_workspace_relative(path, root)
            except ValueError:
                require(path.resolve() == Path(__file__).resolve(), "fixture path escaped its workspace")
                return ".agents/skills/image-generation-api/scripts/generation_api.py"
        try:
            globals()["workspace_relative"] = fixture_workspace_relative
            response_template = {"data": [{"b64_json": encoded_pixel}]}
            globals()["http_json"] = lambda *_args, **_kwargs: (response_template, {"x-request-id": "header-id"}, 200)
            provided_receipt = invoke_image(receipt_profile, receipt_validated, "test-key")
            require(provided_receipt["service_request_id_status"] == "provided"
                    and provided_receipt["service_request_id"] == "header-id"
                    and provided_receipt["service_request_id_source"] == "header:x-request-id",
                    "header request id evidence was not preserved")
            receipt_output.unlink()
            nested_response = {"metadata": {"request_id": "nested-id"}, "data": [{"b64_json": encoded_pixel}]}
            globals()["http_json"] = lambda *_args, **_kwargs: (nested_response, {}, 200)
            nested_receipt = invoke_image(receipt_profile, receipt_validated, "test-key")
            require(nested_receipt["service_request_id"] == "nested-id"
                    and nested_receipt["service_request_id_source"] == "response:metadata.request_id",
                    "nested request id evidence was not preserved")
            receipt_output.unlink()
            globals()["http_json"] = lambda *_args, **_kwargs: (response_template, {}, 200)
            absent_receipt = invoke_image(receipt_profile, receipt_validated, "test-key")
            require(absent_receipt["status"] == "success" and absent_receipt["service_request_id"] is None
                    and absent_receipt["service_request_id_status"] == "provider_not_supplied"
                    and absent_receipt["service_request_id_source"] is None
                    and absent_receipt["network_called"] is True,
                    "valid image without provider request id was not accepted with explicit evidence status")
            receipt_output.unlink()
            globals()["http_json"] = lambda *_args, **_kwargs: ({"data": []}, {}, 200)
            try:
                invoke_image(receipt_profile, receipt_validated, "test-key")
            except ApiError:
                evidence = receipt_validated.get("response_evidence")
                require(isinstance(evidence, dict) and evidence.get("http_status") == 200
                        and evidence.get("service_request_id_status") == "provider_not_supplied"
                        and isinstance(evidence.get("response_sha256"), str),
                        "failed media response did not retain response evidence")
            else:
                raise ApiError("image response without media was accepted")
        finally:
            globals()["http_json"] = original_http_json
            globals()["workspace_relative"] = original_workspace_relative
        image_request = {
            "mode": "image_to_image_edit", "model": GPT_IMAGE_25_FLARE, "prompt": "keep composition",
            "parameters": {"output_format": "png"}, "base_image": source,
            "references": [], "mask_image": None, "output": Path(temp_dir) / "output.png",
        }
        gpt_body, gpt_type = gpt_payload(image_request)
        require(gpt_type.startswith("multipart/form-data; boundary="), "GPT edit payload is not multipart")
        require(b'name="image"' in gpt_body and b'name="prompt"' in gpt_body, "GPT edit multipart fields are incomplete")
        require(b'name="quality"\r\n\r\nmax' in gpt_body and b'name="background"\r\n\r\nopaque' in gpt_body,
                "GPT Image 2.5 payload defaults are incorrect")
        mask = Path(temp_dir) / "mask.png"
        try:
            from PIL import Image
            mask_img = Image.new("RGBA", (1, 1), (255, 255, 255, 0))
            mask_img.save(mask, format="PNG")
        except ImportError as exc:
            raise ApiError("Pillow is not installed") from exc
        masked_body, masked_type = gpt_payload({**image_request, "model": GPT_IMAGE_25_SUNBURST, "mask_image": mask})
        require(masked_type.startswith("multipart/form-data; boundary=") and b'name="mask"' in masked_body,
                "GPT Image 2.5 edit mask was not emitted as multipart mask")
        gpt_generate_request = {**image_request, "mode": "text_to_image", "base_image": None}
        gpt_generate_body, gpt_generate_type = gpt_payload(gpt_generate_request)
        gpt_generate_json = json.loads(gpt_generate_body.decode("utf-8"))
        require(gpt_generate_type == "application/json" and gpt_generate_json["model"] == GPT_IMAGE_25_FLARE,
                "GPT Image 2.5 generation payload model is incorrect")
        require(gpt_generate_json["quality"] == "max" and gpt_generate_json["background"] == "opaque"
                and gpt_generate_json["output_format"] == "png", "GPT Image 2.5 generation payload defaults failed")
        try:
            gpt_payload({**gpt_generate_request, "output": Path(temp_dir) / "output.webp",
                         "parameters": {"output_format": "webp", "output_compression": 101}})
        except ApiError:
            pass
        else:
            raise ApiError("GPT output_compression above 100 was accepted")
        intent_root = Path(temp_dir) / "intent-workspace"
        intent_request = intent_root / "requests" / "image-generation" / "case"
        intent_work = intent_request / "work"
        (intent_work / "api-requests").mkdir(parents=True)
        (intent_request / "request.md").write_text("gpt生图，4K PNG透明底，16:9", encoding="utf-8")
        (intent_request / "state.json").write_text(
            json.dumps({"primary_skill": "wxian-image-production", "status": "active", "revision": 1}),
            encoding="utf-8",
        )
        intent_prompt = intent_work / "prompt.txt"
        intent_prompt.write_text("draw a test image", encoding="utf-8")
        original_hooks = {
            "production_branch": globals()["production_branch"],
            "validate_source_lock": globals()["validate_source_lock"],
            "validate_visual_variant_lock": globals()["validate_visual_variant_lock"],
            "validate_prompt_path": globals()["validate_prompt_path"],
            "validate_reference_plan_match": globals()["validate_reference_plan_match"],
            "validate_ip_character_handoff": globals()["validate_ip_character_handoff"],
        }
        globals()["production_branch"] = lambda _request: "new-generation"
        globals()["validate_source_lock"] = lambda _root, _request: None
        globals()["validate_visual_variant_lock"] = lambda _root, _work, _branch: None
        globals()["validate_prompt_path"] = lambda _request, _root, _work, _model: (
            "draw a test image", {"path": "requests/image-generation/case/work/prompt.txt", "sha256": sha256_file(intent_prompt)}
        )
        globals()["validate_reference_plan_match"] = lambda _root, _work, _refs, _base: None
        globals()["validate_ip_character_handoff"] = lambda _root, _work, _profile, _mode, _refs, _base: None
        try:
            base_intent_request = {
                "api_profile": "gpt", "mode": "text_to_image",
                "prompt_path": "requests/image-generation/case/work/prompt.txt",
                "output_path": "requests/image-generation/case/work/output.png",
                "parameters": {"size": "3840x2160", "quality": "max", "background": "transparent",
                               "moderation": "auto", "output_format": "png"},
            }
            try:
                validate_request({**base_intent_request, "model": GPT_IMAGE_25_FLARE}, intent_root, intent_work,
                                 {"name": "gpt", "default_model": DEFAULT_GPT_IMAGE_MODEL})
            except ApiError:
                pass
            else:
                raise ApiError("validate_request accepted a GPT model-routing bypass")
            bound = validate_request({**base_intent_request, "model": GPT_IMAGE_25_SUNBURST}, intent_root, intent_work,
                                     {"name": "gpt", "default_model": DEFAULT_GPT_IMAGE_MODEL})
            require(bound["gpt_intent_binding"]["request_sha256"] == sha256_file(intent_request / "request.md"),
                    "validate_request did not bind GPT intent to request.md")
        finally:
            globals().update(original_hooks)
        direct_root = Path(temp_dir) / "direct-workspace"
        direct_request = direct_root / "requests" / "game-concept-lab" / "case"
        direct_work = direct_request / "work"
        direct_prompt = direct_work / "prompts" / "direction-a.txt"
        direct_output = direct_work / "final" / "originals" / "direction-a.png"
        direct_prompt.parent.mkdir(parents=True)
        direct_output.parent.mkdir(parents=True)
        direct_prompt.write_text("A complete direction-specific concept prompt.\n", encoding="utf-8")
        direct_call = {
            "api_profile": "gemini", "mode": "text_to_image",
            "model": CURRENT_GEMINI_IMAGE_MODEL,
            "prompt_path": direct_prompt.relative_to(direct_root).as_posix(),
            "output_path": direct_output.relative_to(direct_root).as_posix(),
            "parameters": {"size": "1:1", "quality": "4k"},
        }
        direct_plan = {
            "schema_version": "wxian.generation-plan.v1",
            "primary_skill": "sicza-game-concept-lab", "status": "READY",
            "items": [{"id": "direction-a", "status": "READY",
                       **direct_call, "prompt_sha256": sha256_file(direct_prompt)}],
        }
        (direct_work / "generation-plan.json").write_text(
            json.dumps(direct_plan, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        direct_binding = validate_direct_generation_plan(
            direct_root, direct_work, direct_call, "sicza-game-concept-lab"
        )
        require(direct_binding["item_id"] == "direction-a" and direct_binding["execution_class"] == "concept-generation",
                "direct generation plan did not bind the concept request")
        direct_prompt.write_text("tampered after plan\n", encoding="utf-8")
        try:
            validate_direct_generation_plan(direct_root, direct_work, direct_call, "sicza-game-concept-lab")
        except ApiError:
            pass
        else:
            raise ApiError("direct generation plan accepted a tampered Prompt")
        direct_prompt.write_text("direct concept prompt\n", encoding="utf-8")
        direct_plan["items"][0]["prompt_sha256"] = sha256_file(direct_prompt)
        (direct_work / "generation-plan.json").write_text(
            json.dumps(direct_plan, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        try:
            validate_direct_generation_plan(direct_root, direct_work, direct_call, "unknown-primary")
        except ApiError:
            pass
        else:
            raise ApiError("unknown Primary caller bypassed the direct generation allowlist")
        escaped_call = {**direct_call, "output_path": (direct_work / "escaped.png").relative_to(direct_root).as_posix()}
        escaped_plan = json.loads(json.dumps(direct_plan))
        escaped_plan["items"][0]["output_path"] = escaped_call["output_path"]
        (direct_work / "generation-plan.json").write_text(
            json.dumps(escaped_plan, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        try:
            validate_direct_generation_plan(direct_root, direct_work, escaped_call, "sicza-game-concept-lab")
        except ApiError:
            pass
        else:
            raise ApiError("direct generation output escaped work/final/originals")
        gemini_request = {**image_request, "mode": "text_to_image", "model": CURRENT_GEMINI_IMAGE_MODEL,
                          "parameters": {"size": "16:9", "quality": "4k"}, "base_image": None, "references": [], "mask_image": None}
        gemini_body, gemini_type = gemini_payload(gemini_request)
        gemini_json = json.loads(gemini_body.decode("utf-8"))
        require(gemini_type == "application/json", "Gemini payload content type is incorrect")
        require(gemini_json == {"model": CURRENT_GEMINI_IMAGE_MODEL, "prompt": "keep composition", "size": "16:9", "quality": "4k", "n": 1},
                "Gemini OpenAI-compatible generations payload mapping failed")
        gemini_ref_request = {**image_request, "mode": "reference_to_image", "model": CURRENT_GEMINI_IMAGE_MODEL,
                              "parameters": {"size": "16:9", "quality": "4k"}, "base_image": None, "references": [source], "mask_image": None}
        gemini_ref_body, gemini_ref_type = gemini_payload(gemini_ref_request)
        require(gemini_ref_type.startswith("multipart/form-data; boundary="), "Gemini reference payload is not multipart")
        require(b'name="image"' in gemini_ref_body and b'name="prompt"' in gemini_ref_body and b'gemini-3.1-flash-image-preview' in gemini_ref_body,
                "Gemini reference multipart fields are incomplete")
        gemini_edit_request = {**gemini_ref_request, "mode": "image_to_image_edit", "base_image": source, "references": []}
        gemini_edit_body, gemini_edit_type = gemini_payload(gemini_edit_request)
        require(gemini_edit_type.startswith("multipart/form-data; boundary="), "Gemini edit payload is not multipart")
        require(gemini_edit_body.count(b'name="image"') == 1, "Gemini edit must send the base image exactly once")
    video_request = {
        "model": "test-video", "prompt": "camera moves forward", "parameters": {"ratio": "16:9", "duration": 5},
        "reference_images": [], "reference_videos": [],
        "first_frame": "https://example.test/first.png", "last_frame": None,
    }
    seedance_body, seedance_type = seedance_payload(video_request)
    seedance_json = json.loads(seedance_body.decode("utf-8"))
    require(seedance_type == "application/json", "Seedance payload content type is incorrect")
    require(seedance_json["prompt"] == "camera moves forward", "Seedance prompt must be top-level")
    require(seedance_json["metadata"].get("resolution") == DEFAULT_SEEDANCE_RESOLUTION, "Seedance default resolution contract failed")
    require(seedance_json["metadata"].get("generate_audio") is DEFAULT_SEEDANCE_GENERATE_AUDIO, "Seedance default audio contract failed")
    require("content" not in seedance_json, "Seedance content must not be top-level")
    require(seedance_json["metadata"]["content"][0].get("role") == "first_frame", "Seedance first-frame mapping failed")
    require(all(item.get("type") != "text" for item in seedance_json["metadata"]["content"]), "Seedance metadata.content must not contain text")
    require(inspect_video_container(b"\x00\x00\x00\x18ftypisomtest") == "mp4-family", "MP4 container check failed")
    require(inspect_video_container(b"\x1aE\xdf\xa3test") == "webm", "WebM container check failed")
    reference_gate_path = Path(__file__).resolve().parents[2] / "wxian-image-production" / "scripts" / "request_reference_gate.py"
    reference_gate_module = load_local_module(reference_gate_path, "wxian_request_reference_gate_doctor", "reference gate")
    require(callable(getattr(reference_gate_module, "validate_plan", None)), "reference gate validate_plan is unavailable")
    with tempfile.TemporaryDirectory() as temp_dir:
        config_path = Path(temp_dir) / "api-runtime.json"
        config_path.write_text(json.dumps({
            "connection": {
                "base_url": "https://gateway.example.test",
                "auth_mode": "bearer",
                "credential_store": ".agents/runtime/credentials.json",
                "allow_insecure_http": False,
            },
            "profiles": {
                "gemini": {
                    "protocol": "openai-images-gemini",
                    "generation_path": "/v1/images/generations",
                    "edit_path": "/v1/images/edits",
                    "default_model": "gemini-3.1-flash-image-preview",
                    "request_timeout_seconds": 600,
                },
                "gpt": {
                    "protocol": "openai-images",
                    "generation_path": "/v1/images/generations",
                    "edit_path": "/v1/images/edits",
                    "default_model": GPT_IMAGE_25_FLARE,
                    "request_timeout_seconds": 600,
                },
                "seedance": {
                    "protocol": "seedance-videos",
                    "submit_path": "/v1/videos",
                    "query_path": "/v1/videos/{task_id}",
                    "default_model": "seedance-test",
                    "poll_interval_seconds": 20,
                    "poll_slice_attempts": 15,
                    "poll_total_attempts": 360,
                    "submit_timeout_seconds": 180,
                    "query_timeout_seconds": 60,
                },
            },
            "limits": {
                "media_download_timeout_seconds": 180,
                "max_json_bytes": 10485760,
                "max_image_bytes": 104857600,
                "max_video_bytes": 1073741824,
            },
        }), encoding="utf-8")
        config_root = load_config_root(config_path)
        loaded_profiles = [load_profile(config_root, name) for name in PROFILE_NAMES]
        require(loaded_profiles[0]["request_timeout_seconds"] == 600 and loaded_profiles[1]["request_timeout_seconds"] == 600,
                "image request timeout contract is stale")
        require(loaded_profiles[2]["submit_timeout_seconds"] == 180 and loaded_profiles[2]["query_timeout_seconds"] == 60,
                "Seedance timeout contract is stale")
        require(len({profile["base_url"] for profile in loaded_profiles}) == 1, "profiles do not share one base URL")
        require(len({profile["credential_store"] for profile in loaded_profiles}) == 1, "profiles do not share one credential store")
        endpoint_profile = loaded_profiles[1]
        endpoint_profile["base_url"] = "https://gateway.example.test/v1"
        endpoint_profile["generation_path"] = "/v1/images/generations"
        require(configured_endpoint(endpoint_profile, "generation_path", model="image") == "https://gateway.example.test/v1/images/generations", "base URL version prefix was duplicated")
        gemini_profile = loaded_profiles[0]
        gemini_profile["base_url"] = "https://gateway.example.test/v1"
        require(image_endpoint(gemini_profile, {"mode": "text_to_image"}) == "https://gateway.example.test/v1/images/generations",
                "Gemini text_to_image endpoint must use /v1/images/generations")
        require(image_endpoint(gemini_profile, {"mode": "reference_to_image"}) == "https://gateway.example.test/v1/images/edits",
                "Gemini reference_to_image endpoint must use /v1/images/edits")
        require(image_endpoint(gemini_profile, {"mode": "image_to_image_edit"}) == "https://gateway.example.test/v1/images/edits",
                "Gemini image_to_image_edit endpoint must use /v1/images/edits")
    lifecycle_path = WORKSPACE_ROOT / ".agents/skills/wxian-image-production/scripts/gpt_image_lifecycle_test.py"
    lifecycle_spec = importlib.util.spec_from_file_location("generation_api_gpt_lifecycle_test", lifecycle_path)
    require(lifecycle_spec is not None and lifecycle_spec.loader is not None, "GPT image lifecycle regression is unavailable")
    lifecycle = importlib.util.module_from_spec(lifecycle_spec)
    lifecycle_spec.loader.exec_module(lifecycle)
    require(lifecycle.run(WORKSPACE_ROOT).get("status") == "passed", "GPT image lifecycle regression failed")
    return {
        "status": "ready", "tool": "generation_api",
        "local_checks": [
            "gpt-response", "gpt-edit-multipart", "gemini-generations-json", "gemini-reference-multipart", "gemini-edit-multipart",
            "seedance-response", "seedance-metadata-payload", "seedance-resume-state-validation", "timeout-contract", "video-container", "image-decode", "dynamic-gate-loader", "shared-connection", "gemini-model-contract", "gemini-mode-endpoint-routing",
            "gpt-model-routing", "gpt-2.5-defaults", "gpt-2.5-custom-size-boundaries", "gpt-model-specific-quality",
            "gpt-image-2-custom-sizes", "gpt-explicit-parameter-overrides", "gpt-intent-bypass-blocked",
            "gpt-intent-call-binding", "gpt-output-compression-boundary", "gpt-lifecycle-tamper-and-intent-bypass",
            "image-request-id-header-evidence", "image-request-id-nested-evidence",
            "image-request-id-provider-not-supplied-success", "image-missing-media-failure-evidence",
            "direct-generation-plan-binding", "kv-and-ui-layer-direct-generation-binding", "layer-source-contract-binding", "kv-reconstruction-visual-contract-binding", "gpt-image-2.5-mask-edit", "transparent-alpha-inspection", "direct-generation-prompt-tamper-blocked",
            "direct-generation-unknown-caller-blocked", "direct-generation-output-escape-blocked",
        ],
        **inspection, "network_called": False,
    }


def dry_run_request_file(request_path: Path, root: Path, config_path: Path | None = None) -> dict[str, Any]:
    """Validate one generation request and build its provider payload without network I/O.

    This is the reusable batch entry. It intentionally performs the same request,
    source-lock, direct-generation, visual-contract and provider-payload validation
    as the CLI dry-run path, but avoids re-importing the full Runtime once per layer.
    """
    root = root.resolve()
    request_path = workspace_path(request_path, root, must_exist=True)
    require_work_path(request_path, root)
    current_work = find_work_root(request_path, root)
    require(request_path.parent == current_work / "api-requests",
            "generation request JSON must be in the current request work/api-requests directory")
    request = read_json(request_path, "generation request")
    api_profile = str(request.get("api_profile", "")).strip()
    require(api_profile in PROFILE_NAMES, "request requires api_profile: gemini, gpt, or seedance")
    effective_config = (config_path or DEFAULT_CONFIG).resolve()
    config_root = load_config_root(effective_config)
    profile = load_profile(config_root, api_profile)
    validated = validate_request(request, root, current_work, profile)
    if api_profile == "seedance":
        endpoint = configured_endpoint(profile, "submit_path")
        body, _ = seedance_payload(validated)
    else:
        endpoint = image_endpoint(profile, validated)
        body, _ = gemini_payload(validated) if api_profile == "gemini" else gpt_payload(validated)
    credential_present = bool(credential_value(profile["credential_store"]))
    result = {
        "status": "ready_for_call", **summarize(validated, endpoint),
        "payload_bytes": len(body), "credential_present": credential_present,
        "credential_used": False, "network_called": False,
    }
    if not credential_present:
        result["credential_note"] = f"invoke will require credential store: {profile['credential_store']}"
    return result


def main() -> int:
    network_called = False
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("doctor")
    configure = sub.add_parser("configure")
    configure.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    check = sub.add_parser("check-config")
    check.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    check.add_argument("--profile", choices=PROFILE_NAMES)
    resolve = sub.add_parser("resolve-gpt")
    source = resolve.add_mutually_exclusive_group(required=True)
    source.add_argument("--request-text")
    source.add_argument("--request-text-file", type=Path)
    resolve.add_argument("--aspect-ratio", default="1:1")
    resolve.add_argument("--size")
    resolve.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])
    for name in ("dry-run", "invoke"):
        command = sub.add_parser(name)
        command.add_argument("--request", type=Path, required=True)
        command.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
        command.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])
    args = parser.parse_args()
    try:
        if args.command == "doctor":
            result = doctor()
            ok = True
        elif args.command == "configure":
            result = configure_runtime(args.config.resolve())
            ok = True
        elif args.command == "check-config":
            result, ok = check_configuration(args.config.resolve(), args.profile)
        elif args.command == "resolve-gpt":
            if args.request_text_file:
                root = args.workspace_root.resolve()
                source_path = workspace_path(args.request_text_file, root, must_exist=True)
                require(source_path.is_file(), "request text source must be a file")
                request_text = source_path.read_text(encoding="utf-8")
            else:
                request_text = args.request_text
            try:
                result = resolve_gpt_request(request_text, aspect_ratio=args.aspect_ratio, explicit_size=args.size)
            except ValueError as exc:
                raise ApiError(str(exc)) from exc
            result = {"status": "resolved", **result, "network_called": False, "files_written": False}
            ok = True
        else:
            root = args.workspace_root.resolve()
            request_path = workspace_path(args.request, root, must_exist=True)
            if args.command == "dry-run":
                # Offline contract/payload validation. Credentials are inspected only for
                # readiness reporting; they are neither required nor consumed.
                result = dry_run_request_file(request_path, root, args.config.resolve())
                ok = True
            else:
                require_work_path(request_path, root)
                current_work = find_work_root(request_path, root)
                require(request_path.parent == current_work / "api-requests",
                        "generation request JSON must be in the current request work/api-requests directory")
                request = read_json(request_path, "generation request")
                api_profile = str(request.get("api_profile", "")).strip()
                require(api_profile in PROFILE_NAMES, "request requires api_profile: gemini, gpt, or seedance")
                config_root = load_config_root(args.config.resolve())
                profile = load_profile(config_root, api_profile)
                validated = validate_request(request, root, current_work, profile,
                                             allow_seedance_resume=api_profile == "seedance")
                if api_profile == "seedance":
                    endpoint = configured_endpoint(profile, "submit_path")
                else:
                    endpoint = image_endpoint(profile, validated)
                key = credential_value(profile["credential_store"])
                require(bool(key), f"credential store is missing: {profile['credential_store']}")
                request_sha256 = sha256_file(request_path)
                if validated["attempt"].is_file():
                    attempt = read_json(validated["attempt"], "generation attempt")
                    existing_task_id = attempt.get("task_id")
                    require(api_profile == "seedance" and isinstance(existing_task_id, str)
                            and bool(existing_task_id.strip())
                            and attempt.get("status") in {"polling", "polling_pending"},
                            "unresolved call attempt cannot be resumed safely")
                    existing_poll_count = attempt.get("poll_count")
                    require(type(existing_poll_count) is int and 0 <= existing_poll_count < profile["poll_total_attempts"],
                            "unresolved call attempt has invalid Seedance poll_count")
                    require(attempt.get("request_path") == workspace_relative(request_path, root)
                            and attempt.get("request_sha256") == request_sha256,
                            "generation attempt does not match the current request")
                else:
                    attempt = {
                        "status": "in_flight",
                        **summarize(validated, endpoint),
                        "request_path": workspace_relative(request_path, root),
                        "request_sha256": request_sha256,
                        "network_called": True,
                        "credential_value_exposed": False,
                        "retry_safe": False,
                    }
                def persist_attempt() -> None:
                    atomic_write(validated["attempt"], (json.dumps(attempt, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
                persist_attempt()
                try:
                    result = invoke_seedance(profile, validated, key, attempt, persist_attempt) if api_profile == "seedance" else invoke_image(profile, validated, key)
                    network_called = bool(result.get("network_called"))
                    atomic_write(validated["record"], (json.dumps(result, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
                    validated["attempt"].unlink(missing_ok=True)
                    ok = True
                except AmbiguousRemoteState as exc:
                    network_called = bool(validated.get("network_called"))
                    attempt["status"] = "remote_state_unknown"
                    attempt["reason"] = str(exc)
                    attempt["retry_safe"] = False
                    atomic_write(validated["attempt"], (json.dumps(attempt, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
                    raise
                except PollingPaused as exc:
                    network_called = True
                    attempt["status"] = "polling_pending"
                    attempt["reason"] = str(exc)
                    attempt["retry_safe"] = False
                    persist_attempt()
                    raise
                except (ApiError, OSError) as exc:
                    attempt["status"] = "failed"
                    attempt["reason"] = str(exc)
                    network_called = bool(validated.get("network_called"))
                    attempt["network_called"] = network_called
                    attempt["retry_safe"] = not network_called
                    if isinstance(validated.get("response_evidence"), dict):
                        attempt["response_evidence"] = validated["response_evidence"]
                    atomic_write(validated["attempt"], (json.dumps(attempt, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
                    raise
    except AmbiguousRemoteState as exc:
        result = {"status": "blocked", "reason": str(exc), "remote_state": "unknown", "retry_safe": False,
                  "network_called": network_called}
        ok = False
    except PollingPaused as exc:
        result = {"status": "pending", "reason": str(exc), "remote_state": "pending", "retry_safe": False,
                  "network_called": True}
        ok = False
    except (ApiError, OSError) as exc:
        result = {"status": "blocked", "reason": str(exc), "network_called": network_called}
        ok = False
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
