---
name: image-generation-api
description: 执行已经由专业 Skill 确定的 Gemini 图片、GPT Images 图片生成/编辑或 Seedance 视频请求。只负责配置、参数校验、真实调用、媒体保存和调用记录；不理解需求、不改 Prompt、不做审美判断。
---

# 图像 / 视频 API 执行

只执行调用 Skill 已确定的 Prompt、Reference、模型与参数；不修改专业判断。`wxian-image-production` 请求的 dry-run/invoke 读取当前 request `requirement-lock.md` 的 `production_branch` 并校验 source-lock/业务分支/Reference plan；受约束 direct caller（如 KV/UI 拆层）改为校验当前 `source-lock + generation-plan binding`，不得伪造 production branch。关键证据缺失即阻塞。

## 配置

非敏感 API 配置位于 `config/api-runtime.json`。API Key 位于 `.agents/runtime/credentials.json`，字段为 `generation_api_key`。普通初始化不检查或提示 Key；显式 `api-check` 在 Windows 可调用 `.agents/scripts/configure_api_key_windows.ps1`，macOS / Linux 返回本地隐藏输入命令。后续调用每次读取当前文件值；`dry-run` 不联网、不使用 Key，因此允许在缺 Key 环境完成合同与 payload 验证；真实 `invoke` 在缺 Key 时仍于联网前阻断。

```text
gemini   → OpenAI-compatible Images 生成/参考/编辑（Gemini）
gpt      → OpenAI-compatible Images 生成/编辑
seedance → Seedance 视频提交/轮询/下载
```

Key 轮换直接编辑 `.agents/runtime/credentials.json` 的 `generation_api_key`，或通过 Workspace Bootstrap 运行 `api-check`。调用记录只保存凭据状态。

```powershell
.agents\scripts\workspace_bootstrap.cmd api-check
python .agents/skills/image-generation-api/scripts/generation_api.py configure
python .agents/skills/image-generation-api/scripts/generation_api.py check-config
python .agents/skills/image-generation-api/scripts/generation_api.py check-config --profile gemini
```

`check-config` 不联网，只证明本地配置完整。真实调用成功才证明当时端点可用。

## 最小请求契约

API 请求放在当前请求 `work/api-requests/`。**Prompt 只保存一次**：调用方把最终 Prompt 写成 UTF-8 文本，例如 `work/api-prompts/main.txt`，请求只引用 `prompt_path`。

```json
{
  "api_profile": "gemini",
  "mode": "reference_to_image",
  "prompt_path": "requests/.../work/api-prompts/main.txt",
  "reference_images": ["project/source/character/nora.png"],
  "output_path": "requests/.../work/generated/main.png",
  "parameters": {"size": "16:9", "quality": "4k"}
}
```

只保留调用真正需要的字段：

- `api_profile`
- `mode`
- `prompt_path`
- `output_path`
- `parameters`
- 可选 `model`
- 当前模式需要的图片路径或媒体 URL

不重复 Prompt，不维护 `prompt_source.anchor`、素材 provenance、网络/费用授权证据账本。执行器从真实文件自动计算 Prompt/输入/输出 Hash 并写调用记录。

本地图片只允许来自当前请求 `input/` / `work/` 或 `project/` 下的真实项目原始资料；`project/baselines/`、其他 request 输出和 Workspace 外路径禁止作为素材。`reference_images` 还必须与当前 request `work/reference-plan.json` 的 `must_upload` 集合完全一致；编辑底图使用 `base_image`，不混进 Reference。

当前 request 一旦存在 `work/ip-character-*` 或 `work/concept-lab/ip-character-*` 长期角色契约，生图前必须已有同目录且绑定当前 system/binding、Provider、Mode 与 Runtime Hash 的 `ip-character-preflight.json` 和 `ip-character-handoff.json`。API 会强制 Mother Reference 成为 `reference_images` 的原序前缀；文件漂移、漏传、重排、Provider/Mode 不符或 edit target 不符均在联网前阻断。

## 图片模式

### Gemini

Gemini 保留完整三种图片模式，transport 统一到当前网关的 OpenAI-compatible Images 家族：

```text
text_to_image
POST /v1/images/generations
Content-Type: application/json

reference_to_image / image_to_image_edit
POST /v1/images/edits
Content-Type: multipart/form-data
```

共同字段：

```text
model   = gemini-3.1-flash-image-preview
prompt  = 最终 Prompt
size    = 目标比例，例如 9:16
quality = 4k
n       = 1
```

`reference_to_image` 把 `reference-plan.json` 中所有 `must_upload` 图片按顺序作为重复 `image` part 上传；`image_to_image_edit` 先上传 `base_image`，再上传 `must_upload` Reference。角色身份锁、玩法锁与 Reference provenance 不因 API transport 改变而降级。Gemini 当前不发送 `mask`；局部修改通过 base/reference + 明确编辑指令完成。单次 Gemini 3 图片工作流最多接受 14 个图片输入；Reference Plan 仍应按角色身份/玩法/构图/风格职责最小化选择，不为了凑满上限而上传无关图片。

`parameters` 只允许 `size`、`quality`，其中 `quality` 必须为 `4k`。不要再调用 `generateContent`、`/v1beta/models/...`，不要再使用旧 `resolution/aspect_ratio` 字段。

### GPT Images

无参考图走 `POST /v1/images/generations`；有参考图或编辑走 `POST /v1/images/edits` multipart。支持三种图片模式。参数按当前 Provider 契约使用：`size`、`quality`、`background`、`moderation`、`output_format`、可选 `output_compression`；`n=1` 固定由执行器发送。Workspace 的模型级默认值与用户词义路由如下，不直接照搬 Provider 的 `auto` 默认。

当前支持 `gpt-image-2`、`gpt-image-2.5-sunburst`、`gpt-image-2.5-flare`。`gpt` Profile 默认模型是 `gpt-image-2.5-flare`。构造 GPT 请求前必须先解析当前用户原话：

```powershell
python .agents/skills/image-generation-api/scripts/generation_api.py resolve-gpt --request-text "<当前用户相关原话>" --aspect-ratio <已锁定比例>
```

明确像素时追加 `--size WIDTHxHEIGHT`。执行器会从当前 `request.md` 重算结果并绑定其 Hash 到调用记录；手写模型/参数不一致时联网前阻断。

路由优先级：出现“高清 / 高精度 / 4K / PNG / PNG透明底 / transparent”等高保真或透明输出要求时一律 `gpt-image-2.5-sunburst`；否则 `image2.5生图` 默认 Sunburst，`image2生图` 使用 `gpt-image-2`，普通“GPT生图”默认 `gpt-image-2.5-flare`。显式 `gpt-image-2.5-sunburst/flare` 名称可直接选择，但高保真触发词仍优先切到 Sunburst。

GPT Image 2.5 默认 `quality=max`、`background=opaque`、`output_format=png`。**4K/尺寸与 quality 是独立参数**：用户要求 4K 时解析合法的大尺寸 canvas，但不把 4K 强行映射成 `xhigh`；若用户未另行指定质量，2.5 仍用 `max`。透明底固定 `background=transparent`，且格式只能是 PNG/WebP。默认值可被用户的显式合法参数覆盖，但不得覆盖透明底与格式等显式约束。仅给比例时，GPT Image 2/2.5 都默认使用 `1:1→2880x2880`、`16:9→3840x2160`、`4:3→3264x2448`、`9:16→2160x3840`、`3:4→2448x3264`；其他比例按 16 的倍数、1:3–3:1、单边≤3840、总像素 655,360–8,294,400 的边界求最大合法尺寸。明确尺寸优先，但必须满足同一边界。

`gpt-image-2` 的最高质量为 `high`，不接受 `max` 或 `xhigh`；其尺寸与 2.5 共用上述自定义尺寸边界。高保真触发词仍按前述优先级升级到 Sunburst。

上述 2.5 参数边界核对自 OpenAI 官方 Image generation 文档：<https://developers.openai.com/api/docs/guides/image-generation>（2026-09-14）。模型与参数属于易变 Runtime 事实；官方约束变化时先更新共享 `gpt_image_contract.py` 及回归，再修改说明。

`edits` 最多 16 张 `image`。GPT Image 2.5 的 `image_to_image_edit` 支持可选 `mask_image`：mask 与第一张被编辑图必须同格式、同尺寸、各自 <50MB，mask 必须包含 Alpha；mask 只作为编辑引导，仍需清晰 Prompt。Gemini 仍不发送 mask。响应必须优先读取 `data[].url`，没有 URL 才读取 `data[].b64_json`。

官方文档还定义了独立的 GPT 多轮绘图 `POST /v1/responses`；当前 Codex Workspace 的 API request contract 没有完整会话输入，因此本 Profile **不伪装成已接入 Responses**。需要该能力时应独立增加明确的 multi-turn request contract，而不是把 `/v1/responses` 混入当前直连图片调用。

### Reference 规则

- `text_to_image`：Gemini / GPT 均可；
- `reference_to_image`：Gemini / GPT 均可，至少一个 `reference_images`；
- `image_to_image_edit`：Gemini / GPT 均可，必须 `base_image`，可带 Reference；GPT Image 2.5 可附 `mask_image`，Gemini 不可。

专业 Skill 已确定哪些图是身份锁、构图参考或编辑底图；API 层不重新选择。

## 专业 Skill 直接生成计划

`sicza-game-concept-lab`、`wxian-visual-packaging`、`wxian-visual-competitive-analysis`、`wxian-conducting-internet-research`、`wxian-image-layer-decomposition` 与 `wxian-game-ui-layer-decomposition` 可以在当前 request 内直接调用图片 Profile，无需改路由为 `wxian-image-production`。调用前必须写入 `work/generation-plan.json`：

```json
{
  "schema_version": "wxian.generation-plan.v1",
  "primary_skill": "sicza-game-concept-lab",
  "status": "READY",
  "items": [
    {
      "id": "direction-a",
      "status": "READY",
      "api_profile": "gemini",
      "mode": "text_to_image",
      "model": "gemini-3.1-flash-image-preview",
      "prompt_path": "requests/.../work/prompts/direction-a.txt",
      "prompt_sha256": "<sha256>",
      "output_path": "requests/.../work/final/originals/direction-a.png",
      "parameters": {"size": "1:1", "quality": "4k"}
    }
  ]
}
```

每次 API request 必须精确匹配其中一个 `READY` item；Prompt Hash、Profile、Mode、Model、参数、Reference 与输出路径任一漂移都在联网前阻断。输出只能进入当前 request 的 `work/final/originals/`。调用记录写入 `generation_plan_binding`，供 `$wxian-html-delivery` 复核逐图 Prompt 和原图。


## 运行超时

Gemini / GPT 图像生成与编辑是同步长请求，单次等待上限固定为 600 秒。达到上限时结果状态为 `remote_state_unknown`，保留同名 `.attempt.json`，当前请求不自动重复提交；新的调用只能在远端状态被确认或明确进入新的生成轮次后创建。

Seedance 创建请求单次等待 180 秒；提交成功立即把 task id 写入同名 `.attempt.json`。每个进程只执行配置的有限 polling slice，任务仍未结束时返回 `pending`；再次 invoke 同一 request 时只恢复既有 task 的 GET，不重复 POST，并受跨恢复总轮数上限约束。任务查询单次等待 60 秒，媒体下载单次等待 180 秒。

## Seedance

支持：

```text
text_to_video
image_to_video_first_frame
image_to_video_first_last_frame
reference_to_video
```

创建固定 `POST /v1/videos`，查询固定 `GET /v1/videos/{id}`；轮询间隔 20 秒，最多 360 次。`prompt` 必须在顶层；`resolution / ratio / duration / generate_audio / watermark / return_last_frame / seed / content` 必须写入 `metadata`，`metadata.content` 禁止 text 项。

模型：

```text
Seedance 2.0      → doubao-seedance-2-0-260128
Seedance 2.0 Fast → doubao-seedance-2-0-fast-260128
Seedance 2.0 Mini → doubao-seedance-2-0-mini-260615
```

参数：`ratio`、`resolution`、`duration`、`generate_audio`、`watermark`、`return_last_frame`、可选 `seed`。Seedance 2.0 默认 `resolution=1080p`、`generate_audio=true`；调用方未显式覆盖时使用该默认值。Reference 模式最多 9 张图、3 个视频；首尾帧模式最多首/尾各 1 张并禁止参考视频。Fast 不支持 1080p，显式切换 Fast 时必须使用 480p/720p。成功状态必须为 `succeeded`，成片读取 `content.video_url`；若 `return_last_frame=true`，同时要求 `content.last_frame_url`。

Seedance 底层仍消费 HTTP(S) 媒体 URL。真实视频生产可以直接传当前 Workspace 中由 Gemini/GPT 刚生成的图片路径：执行器读取同名 `.call.json` 的 `remote_media_url`，验证本地 Hash 后映射为 `first_frame` 或 `reference_image`；因此“生图 → 这张图做微动画”无需人工复制 URL。纯用户上传的本地图片如果没有可复用远端 URL，当前资料未提供 OSS 上传接口契约，执行器保持阻塞，不伪造上传能力。

## 执行

先做本地结构预检：

```powershell
python .agents/skills/image-generation-api/scripts/generation_api.py dry-run --request <request.json> --workspace-root .
```

真实调用：

```powershell
python .agents/skills/image-generation-api/scripts/generation_api.py invoke --request <request.json> --workspace-root .
```

用户要求生成/编辑/视频制作即是该业务动作的执行意图；是否需要平台级确认由实际运行环境处理，本 Workspace 不再复制一套文本授权证明。

执行器不自动换 Profile、模型或 Prompt，不覆盖已有输出。默认 Profile 由调用它的专业 Skill 决定；API 层不再次询问用户。成功记录实际 Profile、端点路径、模型、模式、Prompt Hash、输入 Hash、参数、输出 Hash/尺寸或任务 ID，不保存 Key。图片服务提供 request id 时记录其真实值与来源；服务未提供时记录 `service_request_id=null`、`service_request_id_status=provider_not_supplied`，以成功 HTTP、请求/响应 Hash、输出 Hash 与执行器绑定构成可审计证据，不伪造 ID，也不丢弃已经通过媒体校验的结果。联网后的失败保留 `.attempt.json` 并标记真实 `network_called` / `retry_safe`；只有已绑定 task id 且 request Hash 未变的 Seedance attempt 可以恢复轮询，其他 attempt 不自动重试。

## 成功边界

API 成功只证明技术调用成功：

- 图片必须可解码、格式/尺寸/比例符合请求；
- 视频必须任务成功且真实媒体已下载。

调用方仍必须实际查看结果并执行专业门禁。GPT 请求 `background=transparent` 时，执行器还会验证返回 PNG/WebP 确实存在 Alpha 且不是整张全不透明/全透明；画出来的棋盘格不能冒充透明 PNG。鉴权、网络、参数、能力、内容安全、解析、下载失败时返回真实错误；不得创建 Mock/占位媒体或宣布专业交付完成。
