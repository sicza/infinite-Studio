# Brand Production Card Schema 1

有 `project/assets/logos/**` 时必须生成 `work/project-visual-standard/brand-profile.md`。

```text
# Brand Production Card
brand_profile_schema: 1
brand_name:
brand_name_visible_text:

## 1. Visual Identity
wordmark_structure:
typography_shape:
color_material:
symbol_motifs:
silhouette:
protected_details:

## 2. Usage Lock
- 使用 canonical Logo 原文件，不让生成模型重画正式 Logo
- ...

## 3. Canonical Logo Assets
logo_locale: en
logo_path: project/assets/logos/英语.png
logo_sha256: <sha256>
```

`brand_name` 应优先读取 Logo 中真实可见的品牌名。只有确实不可读时才能保留未知，不允许用“项目多语种正式 Logo”代替品牌名。
