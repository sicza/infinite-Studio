# Character Production Verification

```text
verification_schema: 1
character_id:
source_asset_path:
source_sha256:
analysis_path:
analysis_sha256:
profile_path:
profile_sha256:
verification_result: passed

## 1. Re-checked Visual Identity
face_hair_check:
outfit_silhouette_check:
palette_check:
equipment_check:
signature_detail_check:

## 2. Mismatch Resolution
mismatches: none
resolution: none
```

生成角色卡以后重新打开 canonical 原图核对。若发现错项，不要记录成“已知偏差”后继续发布；先修改角色卡，再重新生成 verification，最终必须 `mismatches: none`。
