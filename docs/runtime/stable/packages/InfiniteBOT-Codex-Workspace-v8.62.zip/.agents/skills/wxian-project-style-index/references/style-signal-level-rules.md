# 项目视觉信号等级

## A — 权威

用户当前明确要求、正式项目文本，或真实 canonical 项目资产对其自身身份/版本直接证明的内容。

角色立绘可以 A 级证明“这个角色长什么样”，Logo 可以 A 级证明“这个品牌标识长什么样”；它们不能因此证明项目玩法、剧情、活动家族或所有画面的统一构图。

## B — 多源稳定

至少 3 个不同源 Hash、同范围、相互独立的项目证据稳定重复，且没有同级反例。可建立项目默认规则或 project-evidence family。

同图裁切、压缩、换文案、同模板变体只算一个独立源。

## C — Reference Playbook

`project/references/**` 只能建立方法库。Reference >24 时必须先 100% Census，再按视觉 Cluster 深度选源；是否完整深挖由 `reference_playbook_status` 明示：

- `established`：全部 curated Reference 已深度分析；
- `partial`：全量 Census 已覆盖，但大型 Reference 池只对 Cluster 代表图做深度分析；
- `none`：没有 curated Reference。

`partial` 不代表不可用，只表示下游应把它当覆盖完整、深度抽样的方法库，而不是“所有 Reference 已逐图深挖”。

## D — 不进入正式标准

不可观察、画面外设定、身份脑补、偶发瑕疵、模型错误或不影响生产的猜测。

## 身份状态分离

正式 Baseline 分别声明：

```text
character_identity_status
brand_identity_status
reference_playbook_status
```

不能再用一个总 `visual_identity_status` 把“角色已建立、品牌未知、Reference 欠覆盖”混成同一个 `established`。

## 历史先验与 Floor 分离

多源稳定重复只证明“这是当前项目常见做法”，不自动证明“未来必须这样做”。正式 Baseline 必须把两类信号分开：

- **Historical Prior**：当前产出中高频出现的 Family、构图、镜头、色光、叙事或包装机制，用于提高一稿命中率；可以被当前真实需求突破。
- **Baseline Floor**：角色/品牌身份、项目最低识别、质量/可读性、真实资产与权限边界等，低于即不像项目或不可交付。

禁止把“出现次数多”直接升级为 Floor。新方向没有命中任何 Historical Prior 不构成失败；只要项目事实、身份与 Floor 成立，它就是合法候选。
