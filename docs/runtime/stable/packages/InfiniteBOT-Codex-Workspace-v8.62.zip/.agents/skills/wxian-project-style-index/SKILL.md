---
name: wxian-project-style-index
description: Baseline 辅助身份工具。只根据已验证 canonical 角色/Logo 与正式单图分析生成、校验 Character Production Card、Character Verification 和 Brand Production Card。它不拥有项目级视觉综合判断，不生成最终 Project Visual Baseline，不负责 Family、Visual DNA、Floor 或任务路由。
---

# Project Identity Card Helper

本 Skill 只服务 `$wxian-visual-baselines` 的身份层。

## 允许做

- 根据 canonical 角色原图 + 正式角色分析生成 `character-profiles/<id>.md`；
- 重新打开角色原图，生成 `character-verifications/<id>.md`；
- 根据 canonical Logo 生成 `brand-profile.md`；
- 校验角色/品牌卡与 source hash、analysis hash、profile hash 的绑定。

## 禁止做

- 不生成 `aggregation.md`；
- 不生成 `visual-synthesis.md`；
- 不生成 `project-visual-standard.md`；
- 不根据 Reference 定义项目身份；
- 不创建或判断 Visual Family；
- 不归纳项目 Visual DNA；
- 不判断 Historical Prior / Baseline Floor；
- 不替 `$wxian-visual-baselines` 做项目级综合。

角色 Production Card 使用 `references/character-production-card.md`；角色二次核验使用 `references/character-verification-template.md`；Brand Card 使用 `references/brand-production-card.md`。

项目级视觉综合必须回到 `$wxian-visual-baselines` 主 Skill 完成。
