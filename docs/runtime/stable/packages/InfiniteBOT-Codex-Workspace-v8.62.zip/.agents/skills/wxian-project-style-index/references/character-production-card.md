# Character Production Card Schema 3

```text
character_profile_schema: 3
character_id:
identity_label:
source_asset_path:
source_sha256:
formal_analysis_path:
analysis_sha256:

## 1. Identity Lock
face_shape_skin:
eyes_brows:
hair_structure_color:
body_silhouette:
outfit_silhouette:
palette:
equipment:
signature_details:

## 2. Must Preserve
- <至少 5 条>

## 3. Flexible
- <至少 2 条>

## 4. Never Mix
- <至少 3 条>

## 5. Generation Anchor
positive_identity_prompt:
reference_instruction:
```

不要用“气质自信、眼神明亮、电影感”替代可见身份结构。脸、眼、发、服装轮廓、装备连接与标志细节要能直接反查 canonical 原图。
