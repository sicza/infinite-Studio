# Screen Analysis & Granularity

## 1. 先判断页面用途

Agent 先回答：

```text
这是什么页面？
玩家在这里做什么？
哪些是游戏世界？
哪些是固定屏幕 UI？
哪些是挂在世界对象上的 UI？
哪些区域是 panel/modal？
哪些模块可能跨页面复用？
```

典型页面：

```text
city/map
building detail
battle
inventory
shop
hero detail
settings
modal/event
mixed scene + panel
pure UI screen
```

## 2. Screen Structure Map

结构化节点比自然语言“看起来像按钮”更可靠。

节点字段：

```text
node_id
role
space
bbox
parent / children
interactive
independent_visibility
independent_motion
reusable
occludes_scene
observed_state
contains_text
```

正式 map 使用 `schema_version=wxian.game-ui-screen-map.v1`，并绑定 source/work SHA256、`screen_id`、`scene_present` 与 delivery canvas。parent/children 必须双向一致且无环。

## 3. Balanced Control-level 默认

### 应独立

- 独立点击；
- 独立显示/隐藏；
- 独立移动；
- 不同功能模块；
- 未来明显会独立替换/复用。

### 不应默认拆

- 按钮内部 icon/label/badge；
- 气泡内部 icon + 气泡底；
- quest/chat 内的普通文字；
- 纯装饰性小线条/边框。

## 4. Coarse / Balanced / Fine / Atomic

```text
coarse    模块组
balanced  完整控件（默认）
fine      子控件，但保持工程意义
atomic    图标/底板/角标/字分离，仅显式要求
```

如果 layer plan 在 balanced 模式下出现大量 `icon-only`, `badge-only`, `label-only`，应判过碎并回退合并。

## 5. Common vs Local

多截图时：

```text
COMMON = 同视觉结构、同功能、可共享
LOCAL  = 当前页面独有
VARIANT = 同一控件不同观察状态
```

同一 Top HUD 不应每张图生成一次。


## 6. UI Occlusion Graph

正式 `ui-occlusion-graph.json` 使用：

```json
{
  "schema_version": "wxian.game-ui-occlusion-graph.v1",
  "screen_id": "city_01",
  "edges": [
    {"from": "UI_TOP_HUD", "to": "SCENE"},
    {"from": "UI_BADGE", "to": "UI_BUTTON"}
  ]
}
```

`SCENE` 是唯一特殊 endpoint。其它 endpoint 必须是最终 layer_id。Layer Plan 的 `occluded_by / occludes / occludes_scene` 必须和该图一致。

## Screen Map → Layer Plan Binding Gate

`Screen Structure Map` 不是分析旁注。正式 `ui-layer-plan` 必须机器绑定它：

- `source_node_ids` 必须全部存在；
- 一个 screen-map node 对应一个正式交付 owner；
- 交付层在同一 hierarchy branch 选择 parent 或 descendant 其中一个粒度；
- `bbox_hint` 必须等于所绑定 source nodes 的 bbox union；
- `space`、`contains_text`、`occludes_scene` 必须与 source-node evidence 一致；
- 用户选择更粗粒度时应选择 parent/module；选择更细粒度时选择 children/control，不能 parent + children 同时交付。

这使 `balanced` 不再只是 Prompt 约定，而成为结构层级约束。
