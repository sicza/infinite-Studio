# UI Execution & QA

## Output contract

本文件是 `wxian-game-ui-layer-decomposition` 的**唯一人类可读 Final Output Contract Authority**。`SKILL.md` 与其它 Reference 只做摘要或语义说明，不得维护第二份 Final 目录或 Manifest 字段清单。

机器 Authority 为 `scripts/delivery_gate.py`、`scripts/ui_layer_batch.py` 与共享 `.agents/lib/deterministic_layer_finalization.py`。若本文与机器 Gate 不一致，必须视为 Contract Drift 并修复。

### Request-level authority / execution work

```text
work/source-work.png                    # default prefer 2× provider-legal work surface
work/ui-analysis.md
work/screen-structure-map.json
work/ui-occlusion-graph.json
work/ui-layer-plan.json                  # primary Screen plan
work/<additional-screen-plan>.json       # additional Screen plans when present
work/common-asset-registry.json          # reusable master / variant authority when required
work/ui-screen-plan-index.json           # request-level completion scope authority
work/screen-plan-records/<screen_id>.json
work/generation-plan.json
work/ui-prompts/
work/api-requests/
work/final/originals/                    # Provider original outputs; not delivery authority
work/intermediate/
```

### Per-Screen mandatory final pack

`ui_layer_batch.py` 决定每个 Screen 的唯一 `final_dir`：

```text
primary plan named ui-layer-plan.json  -> work/final/
additional Screen plan                 -> work/final/screens/<screen_id>/
```

每个已登记 Screen 的 `<final_dir>` 必须包含：

```text
<final_dir>/scene/scene-clean.png
<final_dir>/ui/full-canvas/<layer_id>.png
<final_dir>/ui/crops/<layer_id>.png
<final_dir>/screen-structure-map.json
<final_dir>/ui-layer-manifest.json
<final_dir>/recomposition.png
<final_dir>/ui-qa.json
<final_dir>/layered.psd
<final_dir>/layered.preview.png
<final_dir>/layered-psd.json
```

每个 Screen 的 `layered.psd` 由独立 `$wxian-layered-psd-export` 从该 Screen 的 `ui-layer-manifest.json` 编译。PSD document canvas 保持 `delivery_canvas`（默认 source 1×）；每个正式 layer 是 Embedded Smart Object，UI `editable_master` 默认严格为 delivery bbox 的 2×，并以 transform 映射回 1× document geometry。不存在 raster PSD fallback。

```bash
python .agents/skills/wxian-layered-psd-export/scripts/psd_export.py build \
  --workspace-root <workspace-root> \
  --manifest <final_dir>/ui-layer-manifest.json \
  --output <final_dir>/layered.psd \
  --receipt <final_dir>/layered-psd.json

python .agents/skills/wxian-layered-psd-export/scripts/psd_export.py verify \
  --workspace-root <workspace-root> \
  --receipt <final_dir>/layered-psd.json
```

Exporter 自己生成 1× layer preview 与 document composite，并代码回读 embedded master bytes/hash、intrinsic size、Smart Object transform、document canvas 与 layer count。

若 Screen Plan 含 `common` / `variant` layer，对应 READY master 由 `common-asset-registry.json` 绑定，正式 master PNG/hash 与每个 placement 同样进入 active `delivery-manifest.json`。Request-level `ui-screen-plan-index.json` 与全部 `screen-plan-records/*.json` 也是 completion mandatory evidence。

### Optional QA views

```text
<final_dir>/previews/
```

Preview 仅用于人工审阅，不是 UI asset Authority，也不是 completion mandatory artifact。正式 UI component 必须由 Manifest 绑定 delivery-space PNG、2× editable master 与 geometry；Scene Clean Plate 必须满足机器 Gate 的非透明 Scene contract。

## Execution

```text
ui_layer_batch.py build
ui_layer_batch.py run --mode dry-run
ui_layer_batch.py run --mode invoke
ui_layer_batch.py register-common --plan <master-plan> --reuse-key <key> --asset <final-alpha.png>
```

`generation-plan.json` 通过 `source_contract` 绑定当前 plan/source/work/delivery Size Contract 与 SHA。`dry-run` 复用同一 Image API Runtime 批量做离线 contract/payload validation；`invoke` 才联网。

先对各 Screen 执行 `build` 以登记 request-level Screen Index，再执行 `prepare-contract`。只要任一 Screen 含重建策略，聚合合同必须覆盖全部已登记 Screen 的 Plan 与逐 Pass Prompt；API preflight 与 Governance completion 均重新验证，缺失或陈旧时 fail closed。纯提取 request 不强制创建视觉重建合同。

多截图属于同一 decomposition request 时，`common-asset-registry.json` 负责跨 Screen Plan 去重。第一次 common/variant 是 master；后续相同 reuse key 只建立 placement。复用 master 进入 `invoke` 前必须 READY，READY asset 必须是 `work/final/` 下带 Alpha 的 PNG 并绑定 SHA256。

`ui-screen-plan-index.json` + `screen-plan-records/*.json` 负责 request-level completion scope。每个 build 成功的 Screen 都必须注册；Final Gate 同时扫描 index 与 record set，任何 scope truncation 都 BLOCK。每个 Screen 必须有自己的 final Scene / manifest / QA / recomposition；额外 Screen 默认写入 `work/final/screens/<screen_id>/`。


## Shared deterministic reconstruction core

UI Skill 与 KV Skill **只共享确定性图像基础设施，不共享拆层判断逻辑**。每个 Screen 必须先用共享 `prepare-delivery-reference` 直接从原始 source 建立 delivery-space Reference；2× work surface 只能用于模型分析/生成，不能作为 source-visible RGB 回写来源。以下操作复用：

```text
../wxian-image-layer-decomposition/scripts/layer_assets.py

alpha-audit
source-lock
merge-reconstruction
mask-union
patch-clean-plate
crop
preview
recompose
compare
```

UI 的 Screen Structure / granularity / text / reuse 决策仍只由本 Skill 决定。

GPT Image 2.5 edit mask 只用于**缩小模型编辑注意范围**，不是像素级几何 Authority。即使 provider 接受 mask，正式 source-visible 保真与 clean-plate 边界仍必须由 deterministic `source-lock` / `patch-clean-plate` 合成保证。

## Alpha QA

所有透明 UI：

```text
RGBA
alpha_min < 255
alpha_max > 0
no painted checkerboard
no solid gray/white/black backdrop
clean edge on black/white/#808080/checkerboard previews
```

## Scene QA

- UI bbox 下的 scene 有内容；
- 原本未被 UI 覆盖的 scene 不被大幅重画；
- 没有把 UI icon/文字残留进 scene；
- world-ui 移除后下方 scene 连续。

## Granularity QA

balanced 模式出现以下情况应警告：

```text
大量 icon-only
badge-only
text-only
border-only
single decorative atom
```

如果一个 layer 包含多个明显独立点击项，也应警告过粗。

## Recomposition QA

- bbox placement 正确；
- 模块间距和原图一致；
- z-order 正确；
- scene 不留空洞；
- 没有重复 UI；
- 文字低优先时忽略普通文字像素差，但不能影响布局结构。

## Final completion contract

正式 `promote` 由 `scripts/delivery_gate.py` 验证。通用 delivery manifest 本身不等于 UI Layer Pack 完成。

### `wxian.game-ui-final-layer-manifest.v2`

根字段至少包括：

```text
schema_version / status
ui_layer_plan_path / ui_layer_plan_sha256
decomposition_skill
source_image / source_sha256 / source_canvas_size
delivery_canvas_size
delivery_reference_image / delivery_reference_sha256
screen_structure_map_path / screen_structure_map_sha256
common_asset_registry_path / common_asset_registry_sha256
layers[]
```

每个 layer 必须保留当前 Plan Authority：

```text
layer_id / layer_type / space / z_order
file / sha256 / bbox / anchor / source_node_ids
reuse_scope / reuse_key / variant_of
contains_text / text_policy / observed_state
status / qa_status
crop_file / crop_sha256       # scene-clean 为 null；UI 层必须有 crop
editable_master.file / editable_master.sha256 / editable_master.size
editable_master.scale_vs_delivery (=2.0) / editable_master.provenance (`source_preserved | ai_reconstructed | ai_upscaled | deterministic_resample | mixed`)
```

每个 Screen 的 Final layer set 与其 hash-bound UI Plan 完全一致。request-level Screen Index 中登记的全部 Screen 分别完成独立 final pack。若 Plan 存在 common/variant layer，对应 `common-asset-registry.json` master 在交付时为 `READY`，正式 PNG 具有 Alpha 且 SHA 匹配。

Gate 从当前 final layer bytes 确定性重算 full-canvas recomposition，并逐像素核对正式 `recomposition.png`；同时检查 Scene opacity、source/delivery reference hash 与 source-diff 阈值。`ui-qa.json` 保存专业视觉 review 结论。

### `wxian.game-ui-qa.v1`

必须 `status=PASS`，SHA 绑定 final manifest 与 recomposition，并覆盖全部 layer。以下项必须显式 `PASS`：

```text
scene_complete_review
alpha_boundary_review
geometry_review
granularity_review
text_policy_review
observed_state_review
no_duplicate_ui_review
structure_binding_review
```

Completion 的 active `delivery-manifest.json` 覆盖 Scene、全部 UI full-canvas/crop、READY common assets、screen structure map、每屏 final manifest/QA/recomposition/PSD、`ui-screen-plan-index.json` 与全部 screen-plan record。
