#!/usr/bin/env python3
"""Final delivery gate for game-UI screenshot decomposition.

Validates every registered Screen from current request-level plans and final layer bytes.
Machine-addressable facts are recomputed deterministically; ui-qa.json carries professional
visual review conclusions.
"""
from __future__ import annotations
import os as _bytecode_guard_os, sys as _bytecode_guard_sys
_bytecode_guard_sys.dont_write_bytecode = True
_bytecode_guard_os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
import argparse, hashlib, importlib.util, json
from pathlib import Path
from typing import Any
from PIL import Image

PRIMARY='wxian-game-ui-layer-decomposition'
MANIFEST_SCHEMA='wxian.game-ui-final-layer-manifest.v2'
QA_SCHEMA='wxian.game-ui-qa.v1'

class DeliveryError(ValueError): pass

def require(c,m):
    if not c: raise DeliveryError(m)

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def bounded(root,v,exist=False):
    p=Path(v); p=(root/p if not p.is_absolute() else p).resolve(); root=root.resolve()
    require(p==root or root in p.parents,f'path escapes Workspace: {v}')
    if exist: require(p.is_file(),f'file missing: {v}')
    return p

def rel(root,p): return Path(p).resolve().relative_to(root.resolve()).as_posix()

def load(p):
    p=Path(p); require(p.is_file(),f'JSON missing: {p}')
    try:v=json.loads(p.read_text(encoding='utf-8'))
    except json.JSONDecodeError as e: raise DeliveryError(f'invalid JSON: {p}: {e}') from e
    require(isinstance(v,dict),f'JSON root must be object: {p}'); return v

def module(path,name):
    s=importlib.util.spec_from_file_location(name,path); require(s and s.loader,f'cannot load {path}')
    m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m

def png(path,alpha_required=False,alpha_nontrivial=False,canvas=None):
    with Image.open(path) as im:
        im.load(); require(im.format=='PNG',f'formal artifact must be PNG: {path.name}')
        if canvas: require(im.size==canvas,f'canvas mismatch: {path.name}')
        if alpha_required:
            require('A' in im.getbands(),f'UI asset must have alpha: {path.name}')
            ext=im.getchannel('A').getextrema(); require(ext and ext[1]>0,f'UI asset alpha invalid: {path.name}')
            if alpha_nontrivial:
                require(ext[0]<255,f'UI asset must retain transparent pixels: {path.name}')
        return im.size

def reqfile(root,work,pv,hv,label):
    p=bounded(root,pv,True); require(work==p or work in p.parents,f'{label} outside request work')
    require(isinstance(hv,str) and sha(p)==hv,f'{label} hash mismatch'); return p


def _validate_screen(root:Path, work:Path, batch:Any, finalizer:Any, psd:Any, record:dict[str,Any]) -> tuple[set[str],dict[str,Any]]:
    plan_path=bounded(root,record['ui_layer_plan_path'],True)
    plan,plan_work,_=batch.validate_plan(plan_path,root)
    require(plan_work.resolve()==work.resolve(),f"screen belongs to another request: {record['screen_id']}")
    require(record==batch._screen_record(plan_path,plan,work,root),f"screen record stale: {record['screen_id']}")
    final=bounded(root,record['final_dir']); require(final.is_dir(),f"screen final directory missing: {record['screen_id']}")
    canvas=tuple(plan['delivery_canvas_size']); source=bounded(root,plan['source_image'],True); source_sha=sha(source)

    screen_work=bounded(root,plan['screen_structure_map'],True); screen_final=final/'screen-structure-map.json'
    require(screen_final.is_file() and sha(screen_final)==sha(screen_work),f"final screen structure map must preserve analysis evidence: {record['screen_id']}")
    mf_path=final/'ui-layer-manifest.json'; mf=load(mf_path)
    require(mf.get('schema_version')==MANIFEST_SCHEMA and mf.get('status')=='READY',f"UI final manifest invalid: {record['screen_id']}")
    require(mf.get('ui_layer_plan_path')==rel(root,plan_path) and mf.get('ui_layer_plan_sha256')==sha(plan_path),f"UI final manifest plan binding stale: {record['screen_id']}")
    require(mf.get('decomposition_skill')==PRIMARY,f"UI final manifest decomposition_skill mismatch: {record['screen_id']}")
    require(mf.get('source_image')==plan['source_image'] and mf.get('source_sha256')==source_sha,f"UI final manifest source binding stale: {record['screen_id']}")
    require(mf.get('source_canvas_size')==plan['source_canvas_size'],f"UI final manifest source canvas mismatch: {record['screen_id']}")
    require(mf.get('delivery_canvas_size')==list(canvas),f"UI final manifest delivery canvas mismatch: {record['screen_id']}")
    delivery_ref=reqfile(root,work,mf.get('delivery_reference_image',''),mf.get('delivery_reference_sha256',''),f"UI delivery reference {record['screen_id']}")
    png(delivery_ref,canvas=canvas)
    source_path=bounded(root,plan['source_image'],True)
    delivery_image=finalizer.require_delivery_reference(source_path,delivery_ref,canvas,f"UI delivery reference {record['screen_id']}")
    require(mf.get('screen_structure_map_path')==rel(root,screen_final) and mf.get('screen_structure_map_sha256')==sha(screen_final),f"UI final manifest screen-map binding stale: {record['screen_id']}")

    pmap={x['layer_id']:x for x in plan['layers']}; require(all(x.get('strategy')!='unrecoverable' for x in plan['layers']),f"unrecoverable UI layer cannot be promoted complete: {record['screen_id']}")
    scene_ids=[k for k,v in pmap.items() if v['layer_type']=='scene-clean']; require(len(scene_ids)==1,f"UI final delivery requires exactly one scene-clean layer: {record['screen_id']}"); scene_id=scene_ids[0]
    layers=mf.get('layers'); require(isinstance(layers,list) and layers,f"UI final manifest layers missing: {record['screen_id']}")
    ids=[x.get('layer_id') for x in layers if isinstance(x,dict)]; require(len(ids)==len(layers) and set(ids)==set(pmap) and len(set(ids))==len(ids),f"UI final manifest must contain exactly all planned layers: {record['screen_id']}")
    expected={rel(root,mf_path),rel(root,screen_final)}; layer_files:dict[str,Path]={}
    for e in layers:
        lid=e['layer_id']; p=pmap[lid]
        required={'layer_id','status','layer_type','space','z_order','file','sha256','bbox','anchor','source_node_ids','reuse_scope','reuse_key','variant_of','contains_text','text_policy','observed_state','qa_status','crop_file','crop_sha256','editable_master'}
        require(required<=set(e),f'UI final layer fields missing: {lid}')
        require(e['status']=='passed' and e['qa_status']=='PASS',f'UI layer not passed: {lid}')
        for k in ('layer_type','space','z_order','source_node_ids','reuse_scope','reuse_key','variant_of','contains_text','text_policy','observed_state'):
            require(e[k]==p[k],f'UI final layer disagrees with plan {k}: {lid}')
        require(e['bbox']==p['bbox_hint'] and e['anchor']==p['anchor_hint'],f'UI final geometry disagrees with plan: {lid}')
        f=reqfile(root,work,e['file'],e['sha256'],f'UI layer {lid}'); layer_files[lid]=f
        png(f,alpha_required=(lid!=scene_id),alpha_nontrivial=(lid!=scene_id),canvas=canvas); expected.add(rel(root,f))
        master=e['editable_master']; require(isinstance(master,dict),f'editable_master invalid: {lid}')
        mfile=reqfile(root,work,str(master.get('file','')),str(master.get('sha256','')),f'UI editable master {lid}')
        msize=png(mfile,alpha_required=(lid!=scene_id)); require(list(msize)==master.get('size'),f'UI editable master size mismatch: {lid}')
        require(abs(float(master.get('scale_vs_delivery',0))-2.0)<1e-6,f'UI editable master must be 2x: {lid}')
        require(list(msize)==[e['bbox'][2]*2,e['bbox'][3]*2],f'UI editable master intrinsic size must equal bbox×2: {lid}')
        require(master.get('provenance') in {'source_preserved','ai_reconstructed','ai_upscaled','deterministic_resample','mixed'},f'UI editable master provenance invalid: {lid}')
        expected.add(rel(root,mfile))
        if lid==scene_id:
            require(e['crop_file'] in (None,'') and e['crop_sha256'] in (None,''),'scene-clean crop fields must be null')
        else:
            crop=reqfile(root,work,e['crop_file'],e['crop_sha256'],f'UI crop {lid}'); png(crop,alpha_required=True); expected.add(rel(root,crop))

    scene_entry=next(x for x in layers if x['layer_id']==scene_id)
    require(scene_entry['file']==rel(root,final/'scene/scene-clean.png'),f"scene-clean must use canonical final scene path: {record['screen_id']}")
    finalizer.require_scene_not_transparent(finalizer.load_rgba(layer_files[scene_id]),f"UI scene-clean {record['screen_id']}")

    reusable=[x for x in plan['layers'] if x.get('reuse_scope') in {'common','variant'}]
    registry_path=work/'common-asset-registry.json'
    if reusable:
        require(registry_path.is_file(),'reusable UI requires common-asset-registry.json'); reg=batch._validate_registry_value(load(registry_path),work,root)
        for layer in reusable:
            key=layer['reuse_key']; require(key in reg['assets'],f'reuse registry missing key: {key}'); ent=reg['assets'][key]
            require(ent['status']=='READY',f'common asset not READY at delivery: {key}')
            asset=bounded(root,ent['master_asset_path'],True); require(ent['master_asset_sha256']==sha(asset),f'common asset hash stale: {key}'); png(asset,alpha_required=True); expected.add(rel(root,asset))
            require(any(p.get('screen_id')==plan['screen_id'] and p.get('layer_id')==layer['layer_id'] for p in ent['placements']),f'common registry placement missing for {plan["screen_id"]}:{layer["layer_id"]}')
        require(mf.get('common_asset_registry_path')==rel(root,registry_path) and mf.get('common_asset_registry_sha256')==sha(registry_path),f"UI final manifest registry binding stale: {record['screen_id']}")
        expected.add(rel(root,registry_path))
    else:
        require(mf.get('common_asset_registry_path') in (None,''),f"UI final manifest common registry binding must be null: {record['screen_id']}")

    # Recomposition authority is derived from the current final layer bytes.
    recomp=final/'recomposition.png'; png(recomp,canvas=canvas)
    recomposed=finalizer.compose_full_canvas([(int(e['z_order']),layer_files[e['layer_id']]) for e in layers],canvas)
    finalizer.require_pixel_equal(recomposed,recomp,f"UI recomposition {record['screen_id']}")
    source=delivery_image
    evaluation_mask=finalizer.build_text_evaluation_mask(plan['layers'],canvas)
    metrics=finalizer.diff_metrics(source,recomposed,evaluation_mask)
    finalizer.require_not_catastrophic(metrics,f"UI recomposition {record['screen_id']}")

    qa_path=final/'ui-qa.json'; qa=load(qa_path)
    require(qa.get('schema_version')==QA_SCHEMA and qa.get('status')=='PASS',f"UI QA must PASS: {record['screen_id']}")
    require(qa.get('ui_layer_manifest_path')==rel(root,mf_path) and qa.get('ui_layer_manifest_sha256')==sha(mf_path),f"UI QA manifest binding stale: {record['screen_id']}")
    require(qa.get('recomposition_path')==rel(root,recomp) and qa.get('recomposition_sha256')==sha(recomp),f"UI QA recomposition binding stale: {record['screen_id']}")
    require(set(qa.get('reviewed_layer_ids',[]))==set(pmap),f"UI QA must review every layer: {record['screen_id']}")
    for k in ('scene_complete_review','alpha_boundary_review','geometry_review','granularity_review','text_policy_review','observed_state_review','no_duplicate_ui_review','structure_binding_review'):
        require(qa.get(k)=='PASS',f'UI QA review not PASS: {k}')
    expected|={rel(root,delivery_ref),rel(root,recomp),rel(root,qa_path)}

    psd_path=final/'layered.psd'; preview_path=final/'layered.preview.png'; psd_receipt_path=final/'layered-psd.json'
    psd_receipt=load(psd_receipt_path)
    require(psd_receipt.get('source_manifest')==rel(root,mf_path),f"UI PSD receipt must bind the final layer manifest: {record['screen_id']}")
    require(psd_receipt.get('psd')==rel(root,psd_path),f"UI PSD receipt must bind the Screen layered.psd: {record['screen_id']}")
    require(psd_receipt.get('preview')==rel(root,preview_path),f"UI PSD receipt must bind the Screen layered.preview.png: {record['screen_id']}")
    psd.verify(root,psd_receipt_path)
    expected|={rel(root,psd_path),rel(root,preview_path),rel(root,psd_receipt_path)}
    return expected, {'screen_id':plan['screen_id'],'layer_count':len(layers),'changed_pixel_ratio':metrics['changed_pixel_ratio'],'mean_absolute_channel_difference':metrics['mean_absolute_channel_difference']}


def validate(root,request,delivery_sources=None):
    state=load(request/'state.json'); require(state.get('primary_skill')==PRIMARY,'wrong primary_skill')
    work=request/'work'; require(work.is_dir(),'request work missing')
    batch=module(root/'.agents/skills/wxian-game-ui-layer-decomposition/scripts/ui_layer_batch.py','ui_batch_gate')
    finalizer=module(root/'.agents/lib/deterministic_layer_finalization.py','deterministic_layer_finalization_ui')
    psd=module(root/'.agents/skills/wxian-layered-psd-export/scripts/psd_export.py','smart_object_psd_ui_gate')
    index=batch.validate_screen_index(work,root); index_path=work/'ui-screen-plan-index.json'
    expected={rel(root,index_path)}; screen_results=[]
    for entry in index['screens']:
        record_path=bounded(root,entry['record_path'],True); expected.add(rel(root,record_path)); record=load(record_path)
        screen_expected,result=_validate_screen(root,work,batch,finalizer,psd,record); expected|=screen_expected; screen_results.append(result)
    require(len(screen_results)==len(index['screens']) and screen_results,'request-level UI delivery did not validate every indexed screen')
    # If common assets exist, every recorded placement must target a screen that is part of this completed request.
    registry_path=work/'common-asset-registry.json'
    if registry_path.is_file():
        reg=batch._validate_registry_value(load(registry_path),work,root); indexed={x['screen_id'] for x in screen_results}
        for key,asset in reg['assets'].items():
            placement_screens={p.get('screen_id') for p in asset['placements']}
            require(placement_screens<=indexed,f'common asset registry references uncompleted/unindexed screen(s): {key}')
    if delivery_sources is not None:
        missing=expected-delivery_sources; require(not missing,f'UI delivery-manifest omits required final artifacts: {sorted(missing)}')
    return {'status':'ready','screen_count':len(screen_results),'layer_count':sum(x['layer_count'] for x in screen_results),'required_delivery_files':len(expected),'screens':screen_results}


def main()->int:
    ap=argparse.ArgumentParser(); ap.add_argument('--request',required=True); ap.add_argument('--workspace-root',type=Path,default=Path.cwd()); ap.add_argument('--delivery-manifest')
    a=ap.parse_args()
    try:
        root=a.workspace_root.resolve(); request=bounded(root,a.request); require(request.is_dir(),'request directory missing')
        sources=None
        if a.delivery_manifest:
            dm=load(bounded(root,a.delivery_manifest,True)); sources={str(x.get('source')) for x in dm.get('files',[]) if isinstance(x,dict) and x.get('active') is True}
        out=validate(root,request,sources); print(json.dumps(out,ensure_ascii=False)); return 0
    except Exception as e:
        print(json.dumps({'status':'blocked','reason':str(e)},ensure_ascii=False)); return 1

if __name__=='__main__': raise SystemExit(main())
