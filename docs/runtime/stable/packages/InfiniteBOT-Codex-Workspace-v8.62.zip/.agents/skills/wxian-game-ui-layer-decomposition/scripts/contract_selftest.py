#!/usr/bin/env python3
from __future__ import annotations
import os as _bytecode_guard_os, sys as _bytecode_guard_sys
_bytecode_guard_sys.dont_write_bytecode = True
_bytecode_guard_os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import copy
import hashlib
import importlib.util
import json
import shutil
import tempfile
import subprocess
import sys
from pathlib import Path

from PIL import Image

HERE = Path(__file__).resolve().parent
RUNTIME_ROOT = HERE.parents[3]
SPEC = importlib.util.spec_from_file_location("ui_layer_batch", HERE / "ui_layer_batch.py")
assert SPEC and SPEC.loader
mod = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(mod)
SIZE_SPEC = importlib.util.spec_from_file_location("decomposition_size", RUNTIME_ROOT / ".agents" / "lib" / "decomposition_size.py")
assert SIZE_SPEC and SIZE_SPEC.loader
size_mod = importlib.util.module_from_spec(SIZE_SPEC)
SIZE_SPEC.loader.exec_module(size_mod)


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    assert spec and spec.loader
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def expect_block(plan: dict, plan_path: Path, root: Path, label: str) -> str:
    write_json(plan_path, plan)
    try:
        mod.validate_plan(plan_path, root)
    except mod.BatchError as exc:
        return str(exc)
    raise AssertionError(f"negative fixture unexpectedly passed: {label}")


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="ui-layer-contract-") as td:
        root = Path(td)
        shutil.copytree(RUNTIME_ROOT / ".agents", root / ".agents")
        request = root / "requests" / "game-ui-layer-decomposition" / "case"
        inp = request / "input"; work = request / "work"; output = request / "output"
        inp.mkdir(parents=True); work.mkdir(parents=True); output.mkdir(parents=True)
        write_json(request / "state.json", {"primary_skill": "wxian-game-ui-layer-decomposition", "status": "active", "revision": 1})
        source = inp / "screen.png"; canonical = work / "source-work.png"
        Image.new("RGBA", (1024, 1024), (50, 70, 90, 255)).save(source)
        size_contract = size_mod.plan_size_contract((1024, 1024), skill=size_mod.SKILL_UI, model="gpt-image-2.5-sunburst")
        work_surface = size_contract["work_surfaces"][0]
        assert [work_surface["width"], work_surface["height"]] == [2048, 2048]
        Image.open(source).convert("RGBA").resize((work_surface["content_width"], work_surface["content_height"]), Image.Resampling.LANCZOS).save(canonical)
        screen_id = "city_01"
        screen_map = {
            "schema_version": "wxian.game-ui-screen-map.v1", "screen_id": screen_id, "scene_present": True,
            "source_sha256": sha(source), "work_sha256": sha(canonical), "delivery_canvas_size": [1024, 1024],
            "nodes": [
                {"node_id": "scene", "role": "game-world", "space": "scene", "bbox": [0,0,1024,1024], "parent": None, "children": [],
                 "interactive": False, "independent_visibility": False, "independent_motion": False, "reusable": False, "occludes_scene": False,
                 "observed_state": "visible", "contains_text": False},
                {"node_id": "top_hud", "role": "top-hud", "space": "screen-ui", "bbox": [0,0,1024,160], "parent": None, "children": [],
                 "interactive": False, "independent_visibility": True, "independent_motion": False, "reusable": True, "occludes_scene": True,
                 "observed_state": "notification", "contains_text": True},
            ],
        }
        screen_map_path = work / "screen-structure-map.json"; write_json(screen_map_path, screen_map)
        occ = {"schema_version": "wxian.game-ui-occlusion-graph.v1", "screen_id": screen_id,
               "edges": [{"from": "UI_TOP_HUD", "to": "SCENE"}]}
        occ_path = work / "ui-occlusion-graph.json"; write_json(occ_path, occ)
        prompts = work / "ui-prompts"; prompts.mkdir()
        (prompts / "scene.txt").write_text("Remove all UI and complete only hidden game scene regions.\n", encoding="utf-8")
        (prompts / "hud.txt").write_text("Reconstruct the complete HUD without ordinary text on transparent background.\n", encoding="utf-8")
        canonical_rel = canonical.relative_to(root).as_posix()
        params_scene = {"size": "2048x2048", "quality": "max", "background": "opaque", "moderation": "auto", "output_format": "png"}
        params_ui = {**params_scene, "background": "transparent"}
        base = {
            "schema_version": "wxian.game-ui-layer-plan.v4", "status": "READY",
            "source_image": source.relative_to(root).as_posix(), "source_sha256": sha(source),
            "work_source": canonical_rel, "work_sha256": sha(canonical),
            "source_canvas_size": [1024,1024], "delivery_canvas_size": [1024,1024],
            "work_canvas_size": [2048,2048], "size_contract": size_contract,
            "screen_id": screen_id, "scene_present": True,
            "screen_structure_map": screen_map_path.relative_to(root).as_posix(), "screen_structure_map_sha256": sha(screen_map_path),
            "ui_occlusion_graph": occ_path.relative_to(root).as_posix(), "ui_occlusion_graph_sha256": sha(occ_path),
            "screen_type": "city_scene_with_hud", "granularity_mode": "balanced", "default_text_policy": "strip-and-fill",
            "default_model": "gpt-image-2.5-sunburst",
            "layers": [
                {"layer_id": "SCENE_CLEAN", "name": "clean scene", "layer_type": "scene-clean", "space": "scene", "group": "scene", "z_order": 0,
                 "strategy": "scene_clean_patch", "transparent": False, "source_node_ids": ["scene"], "contains_text": False, "text_regions": [],
                 "text_policy": "ignore", "observed_state": "visible", "observed_in_screens": [screen_id], "other_states": "not_observed",
                 "bbox_hint": [0,0,1024,1024], "anchor_hint": [0,0], "occluded_by": [], "occludes": [], "occludes_scene": False,
                 "independent_control": False, "reuse_scope": "screen-local", "reuse_key": None, "variant_of": None,
                 "includes": ["game world"], "excludes": ["all UI"], "completion_scope": "fill all UI-covered scene regions",
                 "api_calls": [{"id": "clean", "mode": "image_to_image_edit", "prompt_path": (prompts/"scene.txt").relative_to(root).as_posix(),
                                "output_path": (work/"final"/"originals"/"SCENE_CLEAN__clean.png").relative_to(root).as_posix(),
                                "base_image": canonical_rel, "parameters": params_scene}]},
                {"layer_id": "UI_TOP_HUD", "name": "top HUD", "layer_type": "hud-group", "space": "screen-ui", "group": "top", "z_order": 500,
                 "strategy": "text_strip_reconstruct", "transparent": True, "source_node_ids": ["top_hud"], "contains_text": True,
                 "text_regions": [[120,30,600,80]], "text_policy": "strip-and-fill", "observed_state": "notification",
                 "observed_in_screens": [screen_id], "other_states": "not_observed", "bbox_hint": [0,0,1024,160], "anchor_hint": [0,0],
                 "occluded_by": [], "occludes": [], "occludes_scene": True, "independent_control": True,
                 "reuse_scope": "common", "reuse_key": "common.top_hud", "variant_of": None,
                 "includes": ["complete top HUD", "icons", "badges"], "excludes": ["scene", "ordinary text"],
                 "completion_scope": "complete control silhouette; strip ordinary text",
                 "api_calls": [{"id": "reconstruct", "mode": "image_to_image_edit", "prompt_path": (prompts/"hud.txt").relative_to(root).as_posix(),
                                "output_path": (work/"final"/"originals"/"UI_TOP_HUD__reconstruct.png").relative_to(root).as_posix(),
                                "base_image": canonical_rel, "parameters": params_ui}]},
            ],
        }
        plan_path = work / "ui-layer-plan.json"; write_json(plan_path, base)
        plan, _, compiled = mod.validate_plan(plan_path, root)
        assert plan["schema_version"].endswith("v4") and len(compiled) == 2

        bad = copy.deepcopy(base); bad["layers"][1]["bbox_hint"] = [900,0,200,100]
        assert "exceeds delivery canvas" in expect_block(bad, plan_path, root, "bbox overflow")
        bad = copy.deepcopy(base); bad["layers"][1]["strategy"] = "control_extract"; bad["layers"][1]["api_calls"][0]["id"] = "visible"
        assert "strip-and-fill requires text_strip_reconstruct" in expect_block(bad, plan_path, root, "text strategy")
        bad = copy.deepcopy(base); bad["layers"][1]["other_states"] = ["hover"]
        assert "must remain not_observed" in expect_block(bad, plan_path, root, "invented state")
        bad = copy.deepcopy(base); bad["screen_structure_map_sha256"] = "0" * 64
        assert "screen_structure_map_sha256 is stale" in expect_block(bad, plan_path, root, "stale screen map")
        bad = copy.deepcopy(base); bad["layers"] = [bad["layers"][1]]
        assert "requires exactly one scene-clean" in expect_block(bad, plan_path, root, "scene master missing")
        bad = copy.deepcopy(base); bad["layers"][1]["api_calls"][0]["base_image"] = source.relative_to(root).as_posix()
        assert "must bind work_source" in expect_block(bad, plan_path, root, "wrong edit base")
        bad = copy.deepcopy(base); bad["layers"][1]["bbox_hint"] = [0,0,1000,160]
        assert "must equal the union" in expect_block(bad, plan_path, root, "screen map bbox disagreement")
        bad = copy.deepcopy(base)
        duplicate = copy.deepcopy(bad["layers"][1]); duplicate["layer_id"] = "UI_TOP_HUD_DUP"; duplicate["z_order"] = 501
        duplicate["reuse_scope"] = "screen-local"; duplicate["reuse_key"] = None
        duplicate["api_calls"][0]["output_path"] = (work/"final"/"originals"/"UI_TOP_HUD_DUP__reconstruct.png").relative_to(root).as_posix()
        bad["layers"].append(duplicate)
        assert "claimed by multiple layers" in expect_block(bad, plan_path, root, "duplicate screen node ownership")

        # Cross-screen common-asset registry: first screen becomes master, second screen reuses it.
        write_json(plan_path, base)
        first_build = mod.build(plan_path, root, force=True)
        assert first_build["item_count"] == 2
        assert {item["id"] for item in mod.load_json(root / first_build["generation_plan"])["items"]} == {
            "city_01__SCENE_CLEAN__clean", "city_01__UI_TOP_HUD__reconstruct"
        }
        first_index = mod.validate_screen_index(work, root)
        assert [entry["screen_id"] for entry in first_index["screens"]] == ["city_01"]
        first_binding = next(item for item in first_build["reuse_bindings"] if item["reuse_key"] == "common.top_hud")
        assert first_binding["role"] == "master" and first_binding["status"] == "PLANNED"

        source2 = inp / "screen-2.png"; canonical2 = work / "source-work-2.png"
        Image.new("RGBA", (1024, 1024), (55, 75, 95, 255)).save(source2); Image.open(source2).convert("RGBA").resize((2048,2048), Image.Resampling.LANCZOS).save(canonical2)
        screen2 = copy.deepcopy(screen_map); screen2["screen_id"] = "city_02"; screen2["source_sha256"] = sha(source2); screen2["work_sha256"] = sha(canonical2)
        screen_map2_path = work / "screen-structure-map-2.json"; write_json(screen_map2_path, screen2)
        occ2 = copy.deepcopy(occ); occ2["screen_id"] = "city_02"
        occ2_path = work / "ui-occlusion-graph-2.json"; write_json(occ2_path, occ2)
        (prompts / "scene2.txt").write_text("Remove all UI and complete only hidden game scene regions for screen two.\n", encoding="utf-8")
        plan2 = copy.deepcopy(base)
        plan2["screen_id"] = "city_02"; plan2["source_image"] = source2.relative_to(root).as_posix(); plan2["source_sha256"] = sha(source2)
        plan2["work_source"] = canonical2.relative_to(root).as_posix(); plan2["work_sha256"] = sha(canonical2)
        plan2["screen_structure_map"] = screen_map2_path.relative_to(root).as_posix(); plan2["screen_structure_map_sha256"] = sha(screen_map2_path)
        plan2["ui_occlusion_graph"] = occ2_path.relative_to(root).as_posix(); plan2["ui_occlusion_graph_sha256"] = sha(occ2_path)
        for layer in plan2["layers"]:
            layer["observed_in_screens"] = ["city_02"]
            for call in layer["api_calls"]:
                call["base_image"] = canonical2.relative_to(root).as_posix()
        plan2["layers"][0]["api_calls"][0]["prompt_path"] = (prompts/"scene2.txt").relative_to(root).as_posix()
        plan2["layers"][0]["api_calls"][0]["output_path"] = (work/"final"/"originals"/"SCENE_CLEAN_2__clean.png").relative_to(root).as_posix()
        plan2["layers"][1]["api_calls"][0]["output_path"] = (work/"final"/"originals"/"UI_TOP_HUD_2__reconstruct.png").relative_to(root).as_posix()
        plan2_path = work / "ui-layer-plan-2.json"; write_json(plan2_path, plan2)
        second_build = mod.build(plan2_path, root, force=True)
        assert second_build["item_count"] == 1
        assert {item["id"] for item in mod.load_json(root / second_build["generation_plan"])["items"]} == {
            "city_02__SCENE_CLEAN__clean"
        }
        second_index = mod.validate_screen_index(work, root)
        assert {entry["screen_id"] for entry in second_index["screens"]} == {"city_01", "city_02"}
        registry_after_two = mod._validate_registry_value(mod.load_json(work / "common-asset-registry.json"), work, root)
        common_entry = registry_after_two["assets"]["common.top_hud"]
        assert common_entry["master_screen_id"] == "city_01"
        assert {(p["screen_id"], p["layer_id"]) for p in common_entry["placements"]} == {("city_01", "UI_TOP_HUD"), ("city_02", "UI_TOP_HUD")}
        second_binding = next(item for item in second_build["reuse_bindings"] if item["reuse_key"] == "common.top_hud")
        assert second_binding["role"] == "reuse" and second_binding["status"] == "PLANNED"
        try:
            mod.run(plan2_path, root, "invoke", force_build=True)
        except mod.BatchError as exc:
            assert "master to be READY" in str(exc)
        else:
            raise AssertionError("invoke accepted a reused common asset whose master was not READY")

        opaque_candidate = work / "final" / "master-no-alpha.png"; opaque_candidate.parent.mkdir(parents=True, exist_ok=True)
        Image.new("RGB", (1024, 160), (100, 120, 140)).save(opaque_candidate)
        try:
            mod.register_common(plan_path, root, "common.top_hud", opaque_candidate, force=True)
        except mod.BatchError as exc:
            assert "alpha channel" in str(exc)
        else:
            raise AssertionError("common master registration accepted a PNG without alpha")

        master_candidate = work / "final" / "master-candidate.png"; master_candidate.parent.mkdir(parents=True, exist_ok=True)
        Image.new("RGBA", (1024, 160), (100, 120, 140, 220)).save(master_candidate)
        registered = mod.register_common(plan_path, root, "common.top_hud", master_candidate, force=True)
        assert registered["status"] == "success" and registered["master_asset_sha256"] == sha(Path(root / registered["master_asset_path"]))
        second_ready = mod.build(plan2_path, root, force=True)
        ready_binding = next(item for item in second_ready["reuse_bindings"] if item["reuse_key"] == "common.top_hud")
        assert ready_binding["role"] == "reuse" and ready_binding["status"] == "READY" and second_ready["item_count"] == 1

        # The public prepare-contract CLI must aggregate every registered Screen,
        # and the Image API must reject reconstructed UI calls until it exists.
        (request / "request.md").write_text("Decompose both game UI screens into editable layers.\n", encoding="utf-8")
        write_json(work / "source-lock.json", {
            "required_sources": [source.relative_to(root).as_posix(), source2.relative_to(root).as_posix()]
        })
        # Exercise the governed Personal Context lifecycle before the real API seam.
        # This mirrors production: resolve -> consume -> personal-execution receipt.
        gate = load_module(
            root / ".agents" / "skills" / "workspace-governance" / "scripts" / "workspace_gate.py",
            "ui_workspace_gate_contract",
        )
        gate.maybe_refresh_personal_context(root, request)
        personal = gate.consume_personal_context(
            root, request.relative_to(root).as_posix(), "wxian-game-ui-layer-decomposition"
        )
        assert personal.get("status") in {"loaded", "skipped"}, personal

        api = root / ".agents" / "skills" / "image-generation-api" / "scripts" / "generation_api.py"
        cli = root / ".agents" / "skills" / "wxian-game-ui-layer-decomposition" / "scripts" / "ui_layer_batch.py"
        generation = mod.load_json(root / second_ready["generation_plan"])
        active_id = generation["items"][0]["id"]
        api_request = work / "api-requests" / f"{active_id}.json"
        missing = subprocess.run([sys.executable, str(api), "dry-run", "--request", str(api_request), "--workspace-root", str(root)], text=True, capture_output=True)
        assert missing.stdout.strip(), (missing.returncode, missing.stderr)
        missing_payload = json.loads(missing.stdout)
        assert missing.returncode != 0 and "visual-spec.json" in missing_payload.get("reason", "")
        prepared_cli = subprocess.run([sys.executable, str(cli), "prepare-contract", "--plan", str(plan2_path), "--workspace-root", str(root), "--force"], text=True, capture_output=True)
        assert prepared_cli.returncode == 0, (prepared_cli.stdout, prepared_cli.stderr)
        prepared_payload = json.loads(prepared_cli.stdout)
        assert prepared_payload["status"] == "success" and prepared_payload["screen_count"] == 2 and prepared_payload["prompt_count"] == 4
        manifest = mod.load_json(work / "ui-layer-prompt-manifest.json")
        assert len(manifest["source_contracts"]) == 2 and len(manifest["entries"]) == 4
        accepted = subprocess.run([sys.executable, str(api), "dry-run", "--request", str(api_request), "--workspace-root", str(root)], text=True, capture_output=True)
        assert accepted.stdout.strip(), (accepted.returncode, accepted.stderr)
        accepted_payload = json.loads(accepted.stdout)
        assert accepted.returncode == 0 and accepted_payload.get("status") == "ready_for_call", accepted_payload
        assert accepted_payload.get("visual_reconstruction_binding", {}).get("status") == "required"
        manifest["entries"] = [entry for entry in manifest["entries"] if entry["item_id"] != active_id]
        write_json(work / "ui-layer-prompt-manifest.json", manifest)
        tampered = subprocess.run([sys.executable, str(api), "dry-run", "--request", str(api_request), "--workspace-root", str(root)], text=True, capture_output=True)
        assert tampered.stdout.strip(), (tampered.returncode, tampered.stderr)
        tampered_payload = json.loads(tampered.stdout)
        assert tampered.returncode != 0 and any(
            phrase in tampered_payload.get("reason", "")
            for phrase in ("missing from layer prompt manifest", "must exactly bind every generation-plan Prompt", "authority hash mismatch")
        ), tampered_payload

        bad2 = copy.deepcopy(plan2); bad2["layers"][1]["bbox_hint"] = [0,0,1000,160]
        screen2_bad = copy.deepcopy(screen2); screen2_bad["nodes"][1]["bbox"] = [0,0,1000,160]
        bad_screen_path = work / "screen-structure-map-2-bad.json"; write_json(bad_screen_path, screen2_bad)
        bad2["screen_structure_map"] = bad_screen_path.relative_to(root).as_posix(); bad2["screen_structure_map_sha256"] = sha(bad_screen_path)
        bad2_path = work / "ui-layer-plan-2-bad.json"; write_json(bad2_path, bad2)
        try:
            mod.build(bad2_path, root, force=True)
        except mod.BatchError as exc:
            assert "visual signature changed" in str(exc)
        else:
            raise AssertionError("common reuse_key accepted an incompatible cross-screen signature")

        # Explicit variant lineage: a visually different HUD must name the common master
        # rather than silently reusing or inventing an unrelated asset family.
        screen3 = copy.deepcopy(screen2); screen3["screen_id"] = "city_03"
        screen3["nodes"][1]["observed_state"] = "selected"
        screen3_path = work / "screen-structure-map-3.json"; write_json(screen3_path, screen3)
        occ3 = copy.deepcopy(occ2); occ3["screen_id"] = "city_03"
        occ3_path = work / "ui-occlusion-graph-3.json"; write_json(occ3_path, occ3)
        plan3 = copy.deepcopy(plan2)
        plan3["screen_id"] = "city_03"
        plan3["screen_structure_map"] = screen3_path.relative_to(root).as_posix(); plan3["screen_structure_map_sha256"] = sha(screen3_path)
        plan3["ui_occlusion_graph"] = occ3_path.relative_to(root).as_posix(); plan3["ui_occlusion_graph_sha256"] = sha(occ3_path)
        for layer in plan3["layers"]:
            layer["observed_in_screens"] = ["city_03"]
        plan3["layers"][1]["observed_state"] = "selected"
        plan3["layers"][1]["reuse_scope"] = "variant"
        plan3["layers"][1]["reuse_key"] = "common.top_hud.selected"
        plan3["layers"][1]["variant_of"] = "common.top_hud"
        plan3["layers"][1]["api_calls"][0]["output_path"] = (work/"final"/"originals"/"UI_TOP_HUD_3__reconstruct.png").relative_to(root).as_posix()
        plan3_path = work / "ui-layer-plan-3.json"; write_json(plan3_path, plan3)
        third_build = mod.build(plan3_path, root, force=True)
        variant_binding = next(item for item in third_build["reuse_bindings"] if item["reuse_key"] == "common.top_hud.selected")
        assert variant_binding["role"] == "variant-master" and variant_binding["variant_of"] == "common.top_hud" and third_build["item_count"] == 2

        bad_variant = copy.deepcopy(plan3)
        bad_variant["layers"][1]["reuse_key"] = "common.top_hud.unknown"
        bad_variant["layers"][1]["variant_of"] = "common.missing"
        bad_variant_path = work / "ui-layer-plan-variant-bad.json"; write_json(bad_variant_path, bad_variant)
        try:
            mod.build(bad_variant_path, root, force=True)
        except mod.BatchError as exc:
            assert "unknown master" in str(exc)
        else:
            raise AssertionError("variant accepted an unknown common master lineage")

    print(json.dumps({"status": "ready", "tool": "ui-layer-contract-selftest", "positive": 8, "negative": 14, "network_called": False}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
