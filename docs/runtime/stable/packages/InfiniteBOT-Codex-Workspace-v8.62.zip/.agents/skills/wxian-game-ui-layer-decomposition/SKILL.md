---
name: wxian-game-ui-layer-decomposition
description: 将游戏运行截图恢复为完整 Scene Clean Plate、Screen-space UI、World-space UI 与跨截图可复用资产，并保留 bbox/anchor/z-order/状态/复用元数据，使各 Screen 可独立重组。使用 Screen Structure Map、控件级拆分、遮挡补全、文字策略、request-level Screen Index、GPT Image 2.5 重建与确定性 Final Gate。KV/Banner 景深拆层路由到 wxian-image-layer-decomposition。
---

# Game UI Screenshot Layer Reconstruction

进入前执行：

```text
$workspace-governance consume-personal-context --request <request> --consumer wxian-game-ui-layer-decomposition
```

新需求由 `$workspace-demand-intake` 建立 `request_type=game-ui-layer-decomposition`。

## Scope

输入：真实游戏界面截图，可为单 Screen 或同一 request 的多 Screen 集合。

输出：

```text
完整无 UI Scene Clean Plate
合理粒度的 Screen-space UI assets
World-space UI / interaction indicators
bbox / anchor / z-order / group / reuse metadata
Observed State 与 text policy
可重新拼回各原截图的 Layer Asset Pack
```

默认拆分粒度为完整可独立控制的 control/widget；同一控件内部 icon / label / badge 作为一个资产单元。多 Screen 中结构一致的组件使用 request-level common master/variant reuse。

## Authority / Owners

```text
Source screenshot              原始 composition、viewport、可见 scene、UI geometry/style/state Authority
Size Contract V2               source / 2× preferred work / 1× delivery 与 transform Authority
Screen Structure Map           页面结构与 node hierarchy Authority
UI Occlusion Graph             scene/UI 遮挡关系 Authority
ui-layer-plan.json             单 Screen 生成与资产契约 Authority
Common Asset Registry          request-level reuse master / variant Authority
UI Screen Plan Index           request-level 完成范围 Authority
final UI manifest              单 Screen 正式资产索引 Authority
machine finalization           hash / scene validity / recomposition / diff / delivery membership
ui-qa.json                     Alpha、粒度、文字、状态、视觉质量 review
workspace-governance           promote / completion owner
```

## Required References

页面分析与粒度：

- [screen-analysis-and-granularity.md](references/screen-analysis-and-granularity.md)
- [ui-taxonomy-and-manifest.md](references/ui-taxonomy-and-manifest.md)

遮挡、Scene 与 Prompt：

- [occlusion-and-clean-plate.md](references/occlusion-and-clean-plate.md)
- [prompt-and-text-policy.md](references/prompt-and-text-policy.md)

执行、资产与 QA：

- [execution-and-qa.md](references/execution-and-qa.md)

其中 `execution-and-qa.md` 是 Final Output layout / mandatory artifacts / request-level completion scope / final manifest schema 的唯一人类可读 Authority；`ui-taxonomy-and-manifest.md` 不维护第二份 Final Manifest。其它 Reference 按对应专业规则分工维护。

## Execution

### 1. Screen Analysis

每个 Screen 先建立：

```text
work/ui-analysis.md
work/screen-structure-map.json
work/ui-occlusion-graph.json
work/ui-layer-plan.json
```

Screen Structure Map 记录：

```text
screen_type / scene_present
module hierarchy
space = scene | screen-ui | world-ui
bbox / parent / children
interactive / independent_visibility / independent_motion
reusable / occludes_scene
observed_state / contains_text
```

Layer Plan 通过 source/work/delivery Size Contract、SHA 和 source-node binding 连接 Screen Structure Map 与 UI Occlusion Graph。

### 2. Granularity / Space / State

默认 `granularity_mode=balanced`，以“独立显示、交互、运动、替换、复用价值”决定 control/widget 边界。

空间分类：

```text
scene
screen-ui
world-ui
```

Observed State 只记录截图中实际出现的状态；未观察状态写 `other_states=not_observed`。

普通数值、任务文案、聊天文字和按钮 label 默认：

```text
text_priority = low
text_policy = strip-and-fill
```

Logo、图形化字标等按 [prompt-and-text-policy.md](references/prompt-and-text-policy.md) 选择 `retain-source` 或 `preserve-visual`。

### 3. Occlusion Completion

Scene Clean Plate 是完整无 UI 的游戏世界底图。UI/world-ui 占用区由模型补全；未被覆盖的 scene 区域保持 source-visible Authority。

独立输出且被子件遮挡的 UI base/panel 同样完成隐藏区域。具体补全与 Provider mask 规则由 [occlusion-and-clean-plate.md](references/occlusion-and-clean-plate.md) 定义。

### 4. Multi-screen Reuse / Completion Scope

多 Screen request 使用：

```text
work/common-asset-registry.json
work/ui-screen-plan-index.json
work/screen-plan-records/<screen_id>.json
```

规则：

```text
common master   reuse_scope=common
variant master  reuse_scope=variant, variant_of=<common-master-key>
screen local    reuse_scope=screen-local
```

第一次出现的 common/variant 建立 master；后续 Screen 引用 master/variant placement。每个 Screen 仍保有独立 Plan、Scene、Final Manifest、QA 与 recomposition。

`ui_layer_batch.py` 是 per-Screen `final_dir` 的机器 Authority：主计划 `ui-layer-plan.json` 使用 `work/final/`；额外 Screen 使用 `work/final/screens/<screen_id>/`。`ui-screen-plan-index.json` 中登记的全部 Screen 构成 request-level Completion Scope。

### 5. Build / Provider Execution

```text
python .agents/skills/wxian-game-ui-layer-decomposition/scripts/ui_layer_batch.py build --plan <work/ui-layer-plan.json> --workspace-root .
python .agents/skills/wxian-game-ui-layer-decomposition/scripts/ui_layer_batch.py prepare-contract --plan <work/ui-layer-plan.json> --workspace-root .
python .agents/skills/wxian-game-ui-layer-decomposition/scripts/ui_layer_batch.py run --plan <work/ui-layer-plan.json> --workspace-root . --mode dry-run
python .agents/skills/wxian-game-ui-layer-decomposition/scripts/ui_layer_batch.py run --plan <work/ui-layer-plan.json> --workspace-root . --mode invoke
```

存在重建策略时，`prepare-contract` 聚合当前 request 的全部 Screen Prompt，生成 `visual-spec.json`、`prompt-binding.json`、`ui-layer-prompt-package.md` 与 `ui-layer-prompt-manifest.json`。Image API 对每次重建调用重新验证当前 Screen source contract、逐 Prompt Hash 与聚合合同；纯提取 Screen 返回 `not_required`。完成时 Governance 还要求绑定正式交付图的 `visual-gate-result.json` 为 `VISUAL_PASS`。

Common/variant master 完成专业 QA 后登记：

```text
python .agents/skills/wxian-game-ui-layer-decomposition/scripts/ui_layer_batch.py register-common --plan <master-screen-plan.json> --reuse-key <reuse-key> --asset <work/final/...png> --workspace-root .
```

`dry-run` 执行本地 contract/preflight；`invoke` 执行实际 Provider 调用。单层失败只重做该层与受其依赖的下游资产。

### 6. Asset Finalization / QA

按 [execution-and-qa.md](references/execution-and-qa.md) 生成每个 Screen 的：

```text
scene/scene-clean.png
ui/full-canvas/*.png
ui/crops/*.png
screen-structure-map.json
ui-layer-manifest.json
recomposition.png
ui-qa.json
```

专业 QA 覆盖：

```text
Scene completeness
Alpha / edge quality
control granularity
geometry / placement
text policy
Observed State
structure binding
visual recomposition quality
```

机器 finalization 独立验证：

```text
Screen Index / record / plan hashes
source / work / delivery size contract / structure-map hashes
final layer geometry and plan semantics
Scene opacity
common master readiness and hashes
z-order recomposition bytes
per-Screen layered PSD readback: 1× document canvas / Smart Object embedded master / transform / hash / composite
source-diff metrics with text evaluation mask
formal delivery membership
```

## Final Completion

`workspace-governance promote` 在 `primary_skill=wxian-game-ui-layer-decomposition` 时调用 `scripts/delivery_gate.py`。

每个 Screen 的正式完成要求：

```text
ui-layer-manifest schema = wxian.game-ui-final-layer-manifest.v2, status=READY
screen-structure-map 与 analysis Authority hash 一致
Scene + UI layer set 与当前 Plan 完全一致
recomposition 与当前 final layers 精确一致
layered PSD 文档等于 delivery_canvas；每层为 Embedded Smart Object，默认 2× editable master 映射回 1× delivery bbox
ui-qa schema = wxian.game-ui-qa.v1, status=PASS
```

Request-level 完成要求：

```text
UI Screen Plan Index 与 screen-plan records 一致
Index 中每个 Screen 均完成独立 final pack
Common/variant master 为 READY 且正式 PNG/hash 有效
所有 Screen 的 scene/UI/common/manifest/QA/recomposition/PSD 与 Screen Index evidence 进入 active delivery-manifest.json
```

`ui-qa.json` 负责专业视觉 review；machine finalization 负责可确定计算的事实，两者共同满足 Completion Gate。

每个 Screen 的 `layered.psd` / `layered.preview.png` / `layered-psd.json` 由独立 `$wxian-layered-psd-export` 生产，禁止手写 PSD 或手写收据：

```bash
python .agents/skills/wxian-layered-psd-export/scripts/psd_export.py build \
  --workspace-root <workspace-root> \
  --manifest <final_dir>/ui-layer-manifest.json \
  --output <final_dir>/layered.psd \
  --receipt <final_dir>/layered-psd.json

python .agents/skills/wxian-layered-psd-export/scripts/psd_export.py verify \
  --workspace-root <workspace-root> \
  --receipt <final_dir>/layered-psd.json
```

游戏 UI 默认 prefer 2× model work 与 2× `editable_master`；PSD document / recomposition / full-canvas layers 默认仍保持 1× source delivery 尺寸。Smart Object 在 document 中通过 transform 映射回 delivery bbox。

Gate 与交付自检使用同一回读校验器，因此手写产物无法通过 Completion。完整契约见 `references/execution-and-qa.md`。

## Boundary / Routing

KV / Banner / Poster / Key Art 的前中后景、主体和环境深度拆层使用 `$wxian-image-layer-decomposition`。
