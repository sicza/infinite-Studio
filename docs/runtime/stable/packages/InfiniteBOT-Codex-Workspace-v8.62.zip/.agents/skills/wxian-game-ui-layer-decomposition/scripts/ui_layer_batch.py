#!/usr/bin/env python3
"""Compile and execute a finite GPT Image batch for game-UI screenshot layer reconstruction."""
from __future__ import annotations
import os as _bytecode_guard_os, sys as _bytecode_guard_sys
_bytecode_guard_sys.dont_write_bytecode = True
_bytecode_guard_os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import argparse
import hashlib
import importlib.util
import json
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

LIB = Path(__file__).resolve().parents[3] / "lib"
if str(LIB) not in sys.path:
    sys.path.insert(0, str(LIB))
from decomposition_size import validate_size_contract, SKILL_UI
from atomic_io import atomic_write_text

SCHEMA = "wxian.game-ui-layer-plan.v4"
COMMON_REGISTRY_SCHEMA = "wxian.game-ui-common-asset-registry.v1"
SCREEN_INDEX_SCHEMA = "wxian.game-ui-screen-plan-index.v1"
SCREEN_RECORD_SCHEMA = "wxian.game-ui-screen-plan-record.v1"
GENERATION_SCHEMA = "wxian.generation-plan.v1"
PROMPT_MANIFEST_SCHEMA = "wxian.game-ui-layer-prompt-manifest.v1"
PRIMARY_SKILL = "wxian-game-ui-layer-decomposition"
ALLOWED_MODES = {"text_to_image", "reference_to_image", "image_to_image_edit"}
ALLOWED_MODELS = {"gpt-image-2.5-sunburst", "gpt-image-2.5-flare", "gpt-image-2"}
ALLOWED_LAYER_TYPES = {
    "scene-clean", "hud-group", "ui-module", "ui-control", "ui-base", "navigation",
    "modal-panel", "detail-panel", "quest-bar", "chat-bar", "world-indicator",
    "world-bubble", "decoration",
}
ALLOWED_SPACES = {"scene", "screen-ui", "world-ui"}
ALLOWED_STRATEGIES = {
    "scene_clean_patch", "control_extract", "control_reconstruct", "text_strip_reconstruct",
    "source_asset", "model_native_alpha", "unrecoverable",
}
ALLOWED_TEXT_POLICIES = {"strip-and-fill", "retain-source", "preserve-visual", "ignore"}
ALLOWED_REUSE_SCOPES = {"common", "screen-local", "variant"}
ALLOWED_GRANULARITY = {"coarse", "balanced", "fine", "atomic"}


class BatchError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise BatchError(message)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def workspace_path(value: str | Path, root: Path, *, must_exist: bool = False) -> Path:
    candidate = Path(value)
    if not candidate.is_absolute():
        candidate = root / candidate
    path = candidate.resolve()
    root = root.resolve()
    require(path == root or root in path.parents, f"path escapes Workspace: {value}")
    if must_exist:
        require(path.is_file(), f"file does not exist: {value}")
    return path


def workspace_relative(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def find_work_root(path: Path, root: Path) -> Path:
    relative = path.resolve().relative_to(root.resolve())
    lower = [part.lower() for part in relative.parts]
    require("requests" in lower and "work" in lower, "plan must be inside requests/.../work/")
    work_index = lower.index("work", lower.index("requests") + 1)
    return root.resolve().joinpath(*relative.parts[: work_index + 1])


def load_local_module(path: Path, module_name: str, label: str):
    require(path.is_file(), f"{label} unavailable: {path}")
    spec = importlib.util.spec_from_file_location(module_name, path)
    require(spec is not None and spec.loader is not None, f"{label} unavailable: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise BatchError(f"invalid JSON at {path}: line {exc.lineno}, column {exc.colno}") from exc
    require(isinstance(value, dict), f"JSON root must be object: {path}")
    return value


def stable_json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2, sort_keys=False) + "\n"


def plan_requires_reconstruction(plan: dict[str, Any]) -> bool:
    reconstructing = {"scene_clean_patch", "control_reconstruct", "text_strip_reconstruct", "model_native_alpha"}
    return any(isinstance(layer, dict) and layer.get("strategy") in reconstructing for layer in plan.get("layers", []))


def write_idempotent(path: Path, content: str, *, force: bool) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.read_text(encoding="utf-8") == content:
            return
        require(force, f"refusing to overwrite changed file without --force: {path}")
    path.write_text(content, encoding="utf-8")


def _validate_bbox(value: Any, layer_id: str, canvas: list[int]) -> None:
    require(isinstance(value, list) and len(value) == 4, f"bbox_hint must be [x,y,w,h]: {layer_id}")
    require(all(isinstance(x, int) and not isinstance(x, bool) for x in value), f"bbox_hint must be integers: {layer_id}")
    x, y, w, h = value
    require(w > 0 and h > 0 and x >= 0 and y >= 0, f"bbox_hint must have non-negative origin and positive size: {layer_id}")
    require(x + w <= canvas[0] and y + h <= canvas[1], f"bbox_hint exceeds delivery canvas: {layer_id}")


def _bbox_union(boxes: list[list[int]]) -> list[int]:
    require(bool(boxes), "bbox union requires at least one box")
    x0 = min(box[0] for box in boxes); y0 = min(box[1] for box in boxes)
    x1 = max(box[0] + box[2] for box in boxes); y1 = max(box[1] + box[3] for box in boxes)
    return [x0, y0, x1 - x0, y1 - y0]


def _is_ancestor(ancestor: str, descendant: str, nodes: dict[str, dict[str, Any]]) -> bool:
    current = nodes[descendant].get("parent")
    seen: set[str] = set()
    while current is not None:
        require(current not in seen, "screen map parent chain contains cycle")
        seen.add(current)
        if current == ancestor:
            return True
        current = nodes[current].get("parent")
    return False


def _validate_text_regions(value: Any, layer_id: str, canvas: list[int], bbox: list[int]) -> None:
    require(isinstance(value, list), f"text_regions must be an array: {layer_id}")
    bx, by, bw, bh = bbox
    for index, region in enumerate(value):
        require(isinstance(region, list) and len(region) == 4, f"text_regions[{index}] must be [x,y,w,h]: {layer_id}")
        require(all(isinstance(x, int) and not isinstance(x, bool) for x in region), f"text_regions[{index}] must be integers: {layer_id}")
        x, y, w, h = region
        require(x >= bx and y >= by and w > 0 and h > 0 and x + w <= bx + bw and y + h <= by + bh,
                f"text_regions[{index}] must stay inside bbox_hint: {layer_id}")
        require(x + w <= canvas[0] and y + h <= canvas[1], f"text_regions[{index}] exceeds canvas: {layer_id}")


def _validate_bound_media(value: Any, work: Path, root: Path, *, label: str) -> None:
    if value in (None, "", []):
        return
    items = value if isinstance(value, list) else [value]
    require(all(isinstance(item, str) and item.strip() for item in items), f"{label} must be a path or path array")
    for item in items:
        path = workspace_path(item, root, must_exist=True)
        require(find_work_root(path, root) == work, f"{label} must stay inside current request work/: {item}")


def _validate_screen_map(path: Path, expected_sha: str, source_sha: str, work_sha: str, delivery_canvas: list[int]) -> dict[str, Any]:
    require(expected_sha == sha256_file(path), "screen_structure_map_sha256 is stale")
    value = load_json(path)
    require(value.get("schema_version") == "wxian.game-ui-screen-map.v1", "screen structure map schema mismatch")
    require(value.get("source_sha256") == source_sha, "screen structure map source_sha256 mismatch")
    require(value.get("work_sha256") == work_sha, "screen structure map work_sha256 mismatch")
    require(value.get("delivery_canvas_size") == delivery_canvas, "screen structure map delivery canvas mismatch")
    require(isinstance(value.get("screen_id"), str) and value["screen_id"].strip(), "screen structure map screen_id missing")
    require(isinstance(value.get("scene_present"), bool), "screen structure map scene_present must be boolean")
    nodes = value.get("nodes")
    require(isinstance(nodes, list) and nodes, "screen structure map requires nodes")
    node_ids: set[str] = set()
    by_id: dict[str, dict[str, Any]] = {}
    for index, node in enumerate(nodes):
        require(isinstance(node, dict), f"screen map nodes[{index}] must be object")
        required = {"node_id", "role", "space", "bbox", "parent", "children", "interactive",
                    "independent_visibility", "independent_motion", "reusable", "occludes_scene",
                    "observed_state", "contains_text"}
        missing = required - set(node)
        require(not missing, f"screen map node missing fields {sorted(missing)} at index={index}")
        node_id = str(node["node_id"]).strip()
        require(node_id and node_id not in node_ids, f"screen map node_id missing/duplicate: {node_id!r}")
        node_ids.add(node_id); by_id[node_id] = node
        require(node["space"] in ALLOWED_SPACES, f"screen map invalid space: {node_id}")
        _validate_bbox(node["bbox"], f"screen-map:{node_id}", delivery_canvas)
        require(node["parent"] is None or (isinstance(node["parent"], str) and node["parent"].strip()), f"screen map invalid parent: {node_id}")
        require(isinstance(node["children"], list) and all(isinstance(x, str) and x.strip() for x in node["children"]), f"screen map invalid children: {node_id}")
        for key in ("interactive", "independent_visibility", "independent_motion", "reusable", "occludes_scene", "contains_text"):
            require(isinstance(node[key], bool), f"screen map {key} must be boolean: {node_id}")
        require(isinstance(node["observed_state"], str) and node["observed_state"].strip(), f"screen map observed_state missing: {node_id}")
    for node_id, node in by_id.items():
        parent = node["parent"]
        if parent is not None:
            require(parent in by_id, f"screen map parent not found: {node_id}->{parent}")
            require(node_id in by_id[parent]["children"], f"screen map parent/child mismatch: {parent}->{node_id}")
        for child in node["children"]:
            require(child in by_id, f"screen map child not found: {node_id}->{child}")
            require(by_id[child]["parent"] == node_id, f"screen map child/parent mismatch: {node_id}->{child}")
    visiting: set[str] = set(); visited: set[str] = set()
    def visit(node_id: str) -> None:
        require(node_id not in visiting, f"screen structure hierarchy contains cycle at {node_id}")
        if node_id in visited:
            return
        visiting.add(node_id)
        for child in by_id[node_id]["children"]:
            visit(child)
        visiting.remove(node_id); visited.add(node_id)
    for node_id in by_id:
        visit(node_id)
    return value


def _validate_occlusion_graph(path: Path, expected_sha: str, screen_id: str) -> dict[str, Any]:
    require(expected_sha == sha256_file(path), "ui_occlusion_graph_sha256 is stale")
    value = load_json(path)
    require(value.get("schema_version") == "wxian.game-ui-occlusion-graph.v1", "UI occlusion graph schema mismatch")
    require(value.get("screen_id") == screen_id, "UI occlusion graph screen_id mismatch")
    edges = value.get("edges")
    require(isinstance(edges, list), "UI occlusion graph edges must be array")
    for index, edge in enumerate(edges):
        require(isinstance(edge, dict) and set(edge) == {"from", "to"}, f"UI occlusion edge[{index}] must contain from/to")
        require(all(isinstance(edge[k], str) and edge[k].strip() for k in ("from", "to")), f"UI occlusion edge[{index}] endpoints invalid")
        require(edge["from"] != edge["to"], f"UI occlusion edge[{index}] cannot self-reference")
    return value


def source_contract(plan_path: Path, plan: dict[str, Any], root: Path) -> dict[str, Any]:
    source = workspace_path(str(plan.get("source_image", "")), root, must_exist=True)
    work_image = workspace_path(str(plan.get("work_source", "")), root, must_exist=True)
    return {
        "layer_plan_path": workspace_relative(plan_path, root),
        "layer_plan_sha256": sha256_file(plan_path),
        "source_image_path": workspace_relative(source, root),
        "source_sha256": sha256_file(source),
        "work_source_path": workspace_relative(work_image, root),
        "work_sha256": sha256_file(work_image),
        "source_canvas_size": plan["source_canvas_size"],
        "delivery_canvas_size": plan["delivery_canvas_size"],
        "work_canvas_size": plan["work_canvas_size"],
        "size_contract": plan["size_contract"],
    }


def _request_identity(root: Path, request: Path) -> dict[str, Any]:
    module = load_local_module(root / ".agents" / "lib" / "request_identity.py", "ui_request_identity", "request identity")
    try:
        return module.identity(root, request)
    except Exception as exc:
        raise BatchError(str(exc)) from exc


def _visual_contract_module(root: Path):
    lib = root / ".agents" / "lib"
    if str(lib) not in sys.path:
        sys.path.insert(0, str(lib))
    return load_local_module(lib / "visual_contracts.py", "ui_visual_contracts", "visual contracts")


def _ui_plan_paths(work: Path, active: Path) -> list[Path]:
    paths = {active.resolve()}
    paths.update(path.resolve() for path in work.glob("ui-layer-plan*.json") if path.is_file())
    return sorted(paths, key=lambda path: path.name.casefold())


def prepare_contract(plan_path: Path, root: Path, *, force: bool = False) -> dict[str, Any]:
    active_plan, work, _ = validate_plan(plan_path, root)
    plans: list[tuple[Path, dict[str, Any], list[dict[str, Any]]]] = []
    for path in _ui_plan_paths(work, plan_path):
        plan, plan_work, compiled = validate_plan(path, root)
        require(plan_work == work, "UI contract plan belongs to another request")
        plans.append((path, plan, compiled))
    if not any(plan_requires_reconstruction(plan) for _, plan, _ in plans):
        return {"status": "not_required", "operation": "prepare-contract", "reason": "UI plans contain no reconstruction strategy", "network_called": False}

    request = work.parent
    request_md = request / "request.md"
    require(request_md.is_file(), "prepare-contract requires request.md")
    ident = _request_identity(root, request)
    entries: list[dict[str, Any]] = []
    package = ["# Game UI Layer Prompt Package", ""]
    contracts: list[dict[str, Any]] = []
    seen_ids: set[str] = set()
    for path, plan, compiled in plans:
        contract = source_contract(path, plan, root)
        contracts.append(contract)
        package += [f"## Screen {plan['screen_id']}", "", f"layer_plan: {contract['layer_plan_path']}", f"layer_plan_sha256: {contract['layer_plan_sha256']}", ""]
        for item in compiled:
            item_id = str(item["id"])
            require(item_id not in seen_ids, f"UI Prompt item id must be unique across Screens: {item_id}")
            seen_ids.add(item_id)
            prompt_path = workspace_path(item["prompt_path"], root, must_exist=True)
            entry = {
                "item_id": item_id,
                "prompt_path": workspace_relative(prompt_path, root),
                "prompt_sha256": sha256_file(prompt_path),
                "layer_plan_path": contract["layer_plan_path"],
                "layer_plan_sha256": contract["layer_plan_sha256"],
            }
            entries.append(entry)
            package += [f"### {item_id}", "", f"prompt_path: {entry['prompt_path']}", f"prompt_sha256: {entry['prompt_sha256']}", "", prompt_path.read_text(encoding="utf-8").rstrip(), ""]
    package_path = work / "ui-layer-prompt-package.md"
    write_idempotent(package_path, "\n".join(package).rstrip() + "\n", force=force)
    manifest = {
        "schema_version": PROMPT_MANIFEST_SCHEMA,
        "primary_skill": PRIMARY_SKILL,
        "prompt_package_path": workspace_relative(package_path, root),
        "prompt_package_sha256": sha256_file(package_path),
        "source_contracts": contracts,
        "entries": entries,
    }
    manifest_path = work / "ui-layer-prompt-manifest.json"
    write_idempotent(manifest_path, stable_json(manifest), force=force)

    authority_trace = [{"role": "current_request", "path": workspace_relative(request_md, root), "sha256": sha256_file(request_md)}]
    authority_trace += [{"role": "other_authority", "path": item["layer_plan_path"], "sha256": item["layer_plan_sha256"]} for item in contracts]
    authority_trace.append({"role": "other_authority", "path": workspace_relative(manifest_path, root), "sha256": sha256_file(manifest_path)})
    visual_spec = {
        "schema_version": "sicza.visual-spec.v2", **ident,
        "profile_id": "visual.transform.reconstruction.v1", "mode": "TRANSFORM", "task_kind": "still",
        "authority_trace": authority_trace, "narrative_trace": None,
        "intent": {"primary": "reconstruct editable game UI Screens while preserving observed layout, hierarchy, states and source-visible evidence"},
        "truth_protection": {"protect": ["observed UI hierarchy, geometry, state and source-visible appearance are authoritative", "generated pixels are limited to declared extraction and occlusion-completion work"]},
        "world_space": {"space": "preserve the Screen Structure Map split between scene, screen-ui and world-ui"},
        "performance": {}, "projection": {"camera": "preserve source camera, viewport, perspective and UI projection"},
        "appearance": {"surface": "match source UI and scene rendering without redesigning observed components"},
        "image_structure": {"hierarchy": "preserve Screen Structure Map ownership, z-order and control grouping"},
        "image_formation": {"edges": "native alpha for UI layers; source lock outside declared completion regions"},
        "graphic": {}, "identity": {"lock": "preserve observed icon, logo, typography and control identity"}, "channel_roles": {}, "motion": None,
        "change_set": {"protect": ["all observed source-visible regions outside declared completion masks"], "change": ["only extraction alpha and declared hidden scene/UI completion"], "avoid": ["invented states, relayout, restyling, duplicate controls and cross-Screen drift"]},
        "success_condition": ["every registered Screen remains independently recomposable", "all reconstructed regions remain bounded by the Screen plan and professional review"],
        "unresolved": [],
    }
    spec_path = work / "visual-spec.json"
    write_idempotent(spec_path, stable_json(visual_spec), force=force)
    prompt_pack = root / ".agents" / "skills" / "wxian-image-production" / "references" / "prompt-packs" / "gpt-image-2.md"
    require(prompt_pack.is_file(), "GPT Image prompt pack is missing")
    binding = {
        "schema_version": "sicza.prompt-binding.v2", **ident,
        "visual_spec_path": workspace_relative(spec_path, root), "visual_spec_sha256": sha256_file(spec_path),
        "narrative_semantic_checksum": None,
        "prompt_path": workspace_relative(package_path, root), "prompt_sha256": sha256_file(package_path),
        "compiler_profile": "image.gpt-image.v1", "adapter_family": "gpt-image",
        "prompt_pack_path": workspace_relative(prompt_pack, root), "prompt_pack_sha256": sha256_file(prompt_pack),
    }
    binding_path = work / "prompt-binding.json"
    write_idempotent(binding_path, stable_json(binding), force=force)
    visual = _visual_contract_module(root)
    try:
        visual.validate_visual_spec(root, spec_path)
        visual.validate_prompt_binding(root, binding_path)
    except Exception as exc:
        raise BatchError(str(exc)) from exc
    return {
        "status": "success", "operation": "prepare-contract",
        "active_screen": active_plan["screen_id"], "screen_count": len(plans), "prompt_count": len(entries),
        "visual_spec": workspace_relative(spec_path, root), "visual_spec_sha256": sha256_file(spec_path),
        "prompt_binding": workspace_relative(binding_path, root), "prompt_binding_sha256": sha256_file(binding_path),
        "prompt_manifest": workspace_relative(manifest_path, root), "prompt_manifest_sha256": sha256_file(manifest_path),
        "network_called": False,
    }


def _safe_reuse_key(value: str) -> str:
    clean = re.sub(r"[^A-Za-z0-9._-]+", "-", value.strip()).strip("-.")
    require(bool(clean), f"reuse_key cannot be converted to a safe asset name: {value!r}")
    return clean


def _common_signature(layer: dict[str, Any]) -> str:
    bbox = layer["bbox_hint"]
    payload = {
        "layer_type": layer["layer_type"],
        "space": layer["space"],
        "strategy": layer["strategy"],
        "transparent": layer["transparent"],
        "contains_text": layer["contains_text"],
        "text_policy": layer["text_policy"],
        "observed_state": layer["observed_state"],
        "size": [bbox[2], bbox[3]],
        "includes": layer["includes"],
        "excludes": layer["excludes"],
    }
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()




def _safe_screen_id(value: str) -> str:
    clean = re.sub(r"[^A-Za-z0-9._-]+", "-", value.strip()).strip("-.")
    require(bool(clean), f"screen_id cannot be converted to a safe path: {value!r}")
    return clean


def _screen_index_path(work: Path) -> Path:
    return work / "ui-screen-plan-index.json"


def _screen_records_dir(work: Path) -> Path:
    return work / "screen-plan-records"


def final_dir_for_plan(plan_path: Path, plan: dict[str, Any], work: Path) -> Path:
    if plan_path.name == "ui-layer-plan.json":
        return work / "final"
    return work / "final" / "screens" / _safe_screen_id(str(plan["screen_id"]))


def _screen_record(plan_path: Path, plan: dict[str, Any], work: Path, root: Path) -> dict[str, Any]:
    final_dir = final_dir_for_plan(plan_path, plan, work)
    return {
        "schema_version": SCREEN_RECORD_SCHEMA,
        "screen_id": str(plan["screen_id"]),
        "ui_layer_plan_path": workspace_relative(plan_path, root),
        "ui_layer_plan_sha256": sha256_file(plan_path),
        "source_image": str(plan["source_image"]),
        "source_sha256": str(plan["source_sha256"]),
        "work_source": str(plan["work_source"]),
        "work_sha256": str(plan["work_sha256"]),
        "screen_structure_map": str(plan["screen_structure_map"]),
        "screen_structure_map_sha256": str(plan["screen_structure_map_sha256"]),
        "final_dir": workspace_relative(final_dir, root),
    }


def _validate_screen_record(value: dict[str, Any], work: Path, root: Path) -> dict[str, Any]:
    required = {"schema_version","screen_id","ui_layer_plan_path","ui_layer_plan_sha256","source_image","source_sha256",
                "work_source","work_sha256","screen_structure_map","screen_structure_map_sha256","final_dir"}
    require(set(value) == required, "screen plan record fields are invalid")
    require(value.get("schema_version") == SCREEN_RECORD_SCHEMA, "screen plan record schema mismatch")
    screen_id = str(value.get("screen_id", "")).strip(); require(bool(screen_id), "screen plan record screen_id missing")
    plan_path = workspace_path(value["ui_layer_plan_path"], root, must_exist=True)
    require(plan_path.parent.resolve() == work.resolve(), "screen plan record plan must live directly in work/")
    require(value["ui_layer_plan_sha256"] == sha256_file(plan_path), f"screen plan record plan hash stale: {screen_id}")
    plan, plan_work, _ = validate_plan(plan_path, root)
    require(plan_work.resolve() == work.resolve() and plan["screen_id"] == screen_id, f"screen plan record binding stale: {screen_id}")
    expected = _screen_record(plan_path, plan, work, root)
    require(value == expected, f"screen plan record does not match current plan: {screen_id}")
    return value


def validate_screen_index(work: Path, root: Path) -> dict[str, Any]:
    path = _screen_index_path(work)
    require(path.is_file(), "request-level ui-screen-plan-index.json is required")
    value = load_json(path)
    require(set(value) == {"schema_version","request_work","screens"}, "screen plan index fields are invalid")
    require(value.get("schema_version") == SCREEN_INDEX_SCHEMA, "screen plan index schema mismatch")
    require(value.get("request_work") == workspace_relative(work, root), "screen plan index belongs to another request")
    screens = value.get("screens"); require(isinstance(screens, list) and screens, "screen plan index requires at least one screen")
    record_dir = _screen_records_dir(work)
    require(record_dir.is_dir(), "screen plan record directory is missing")
    record_paths = sorted(p.resolve() for p in record_dir.glob("*.json") if p.is_file())
    indexed_record_paths: list[Path] = []
    seen_screen: set[str] = set(); seen_plan: set[str] = set()
    for entry in screens:
        require(isinstance(entry, dict) and set(entry) == {"screen_id","record_path","record_sha256"}, "screen plan index entry invalid")
        screen_id = str(entry["screen_id"]).strip(); require(screen_id and screen_id not in seen_screen, f"screen plan index duplicate screen_id: {screen_id}")
        seen_screen.add(screen_id)
        record_path = workspace_path(entry["record_path"], root, must_exist=True)
        require(record_path.parent.resolve() == record_dir.resolve(), f"screen plan record outside screen-plan directory: {screen_id}")
        require(entry["record_sha256"] == sha256_file(record_path), f"screen plan index record hash stale: {screen_id}")
        record = _validate_screen_record(load_json(record_path), work, root)
        require(record["screen_id"] == screen_id, f"screen plan index record screen mismatch: {screen_id}")
        require(record["ui_layer_plan_path"] not in seen_plan, f"screen plan index duplicate plan path: {record['ui_layer_plan_path']}")
        seen_plan.add(record["ui_layer_plan_path"]); indexed_record_paths.append(record_path.resolve())
    require(set(indexed_record_paths) == set(record_paths), "screen plan index must exactly cover request-level screen records")
    return value


def _register_screen_plan(plan_path: Path, plan: dict[str, Any], work: Path, root: Path) -> tuple[Path, Path]:
    record_dir = _screen_records_dir(work); record_dir.mkdir(parents=True, exist_ok=True)
    record = _screen_record(plan_path, plan, work, root)
    record_path = record_dir / f"{_safe_screen_id(str(plan['screen_id']))}.json"
    # screen_id is the stable request-level identity for one Screen Plan.
    if record_path.is_file():
        old = load_json(record_path)
        require(old.get("ui_layer_plan_path") == record["ui_layer_plan_path"],
                f"screen_id already registered to another plan: {plan['screen_id']}")
    record_path.write_text(stable_json(record), encoding="utf-8")
    entries=[]
    for rp in sorted(record_dir.glob("*.json")):
        rv=_validate_screen_record(load_json(rp), work, root)
        entries.append({"screen_id":rv["screen_id"],"record_path":workspace_relative(rp,root),"record_sha256":sha256_file(rp)})
    entries.sort(key=lambda x:x["screen_id"])
    index={"schema_version":SCREEN_INDEX_SCHEMA,"request_work":workspace_relative(work,root),"screens":entries}
    index_path=_screen_index_path(work); index_path.write_text(stable_json(index),encoding="utf-8")
    validate_screen_index(work,root)
    return index_path, final_dir_for_plan(plan_path,plan,work)

def _registry_path(work: Path) -> Path:
    return work / "common-asset-registry.json"


def _empty_registry(work: Path, root: Path) -> dict[str, Any]:
    return {
        "schema_version": COMMON_REGISTRY_SCHEMA,
        "request_work": workspace_relative(work, root),
        "assets": {},
    }


def _validate_registry_value(value: dict[str, Any], work: Path, root: Path) -> dict[str, Any]:
    require(set(value) == {"schema_version", "request_work", "assets"}, "common asset registry fields are invalid")
    require(value.get("schema_version") == COMMON_REGISTRY_SCHEMA, "common asset registry schema mismatch")
    require(value.get("request_work") == workspace_relative(work, root), "common asset registry belongs to another request work")
    require(isinstance(value.get("assets"), dict), "common asset registry assets must be an object")
    for key, entry in value["assets"].items():
        require(isinstance(key, str) and key.strip() and isinstance(entry, dict), "common asset registry entry is invalid")
        required = {"reuse_key", "variant_of", "status", "signature", "master_screen_id", "master_layer_id", "master_asset_path", "master_asset_sha256", "placements"}
        require(set(entry) == required, f"common asset registry entry fields are invalid: {key}")
        require(entry["reuse_key"] == key, f"common asset registry key mismatch: {key}")
        require(entry["variant_of"] is None or (isinstance(entry["variant_of"], str) and entry["variant_of"].strip()), f"common asset registry variant_of invalid: {key}")
        require(entry["status"] in {"PLANNED", "READY"}, f"common asset registry status invalid: {key}")
        require(isinstance(entry["placements"], list) and entry["placements"], f"common asset registry placements missing: {key}")
        if entry["status"] == "READY":
            require(isinstance(entry["master_asset_path"], str) and entry["master_asset_path"], f"READY common asset path missing: {key}")
            asset = workspace_path(entry["master_asset_path"], root, must_exist=True)
            require((work / "final").resolve() in asset.parents, f"READY common asset must live under work/final/: {key}")
            require(entry["master_asset_sha256"] == sha256_file(asset), f"READY common asset hash is stale: {key}")
        else:
            require(entry["master_asset_sha256"] is None, f"PLANNED common asset must not have a master hash: {key}")
    for key, entry in value["assets"].items():
        parent = entry["variant_of"]
        if parent is None:
            continue
        require(parent in value["assets"], f"common asset registry variant references missing parent: {key}->{parent}")
        require(value["assets"][parent]["variant_of"] is None, f"common asset registry variant parent must be a common master: {key}->{parent}")
        require(parent != key, f"common asset registry variant cannot reference itself: {key}")
    return value


def _load_registry(work: Path, root: Path) -> dict[str, Any]:
    path = _registry_path(work)
    if not path.is_file():
        return _empty_registry(work, root)
    return _validate_registry_value(load_json(path), work, root)


def _save_registry(work: Path, root: Path, value: dict[str, Any], *, force: bool) -> Path:
    # The common-asset registry is request-owned machine state and is expected to
    # evolve as additional screens are analyzed. Requiring --force for every new
    # placement would make the normal cross-screen workflow unusable. Validate the
    # complete state, then replace it atomically. `force` remains in the function
    # signature for CLI/backward compatibility; it does not weaken validation.
    _validate_registry_value(value, work, root)
    path = _registry_path(work)
    content = stable_json(value)
    if path.is_file() and path.read_text(encoding="utf-8") == content:
        return path
    atomic_write_text(path, content)
    return path


def _resolve_common_assets(plan: dict[str, Any], work: Path, root: Path, compiled: list[dict[str, Any]], *, force: bool) -> tuple[list[dict[str, Any]], list[dict[str, Any]], Path]:
    registry = _load_registry(work, root)
    screen_id = str(plan["screen_id"])
    reused_layers: set[str] = set()
    bindings: list[dict[str, Any]] = []
    reusable_layers = [layer for layer in plan["layers"] if layer.get("reuse_scope") in {"common", "variant"}]
    reusable_layers.sort(key=lambda layer: 0 if layer.get("reuse_scope") == "common" else 1)
    for layer in reusable_layers:
        layer_id = str(layer["layer_id"])
        key = str(layer["reuse_key"])
        scope = str(layer["reuse_scope"])
        variant_of = str(layer["variant_of"]).strip() if scope == "variant" else None
        if scope == "variant":
            require(variant_of in registry["assets"],
                    f"variant reuse_key={key} references unknown master reuse_key={variant_of}")
            require(registry["assets"][variant_of]["variant_of"] is None,
                    f"variant_of must reference a common master, not another variant: {key}->{variant_of}")
            require(key != variant_of, f"variant reuse_key must differ from variant_of: {key}")
        signature = _common_signature(layer)
        placement = {
            "screen_id": screen_id,
            "layer_id": layer_id,
            "bbox_hint": layer["bbox_hint"],
            "anchor_hint": layer["anchor_hint"],
            "observed_state": layer["observed_state"],
        }
        entry = registry["assets"].get(key)
        if entry is None:
            entry = {
                "reuse_key": key,
                "variant_of": variant_of,
                "status": "PLANNED",
                "signature": signature,
                "master_screen_id": screen_id,
                "master_layer_id": layer_id,
                "master_asset_path": f"{workspace_relative(work, root)}/final/common/{_safe_reuse_key(key)}.png",
                "master_asset_sha256": None,
                "placements": [placement],
            }
            registry["assets"][key] = entry
            role = "master" if scope == "common" else "variant-master"
        else:
            require(entry["variant_of"] == variant_of,
                    f"reuse_key={key} lineage changed; expected variant_of={entry['variant_of']!r}, got {variant_of!r}")
            require(entry["signature"] == signature,
                    f"reuse_key={key} visual signature changed; declare a variant instead of silently reusing the master")
            if not any(p.get("screen_id") == screen_id and p.get("layer_id") == layer_id for p in entry["placements"]):
                entry["placements"].append(placement)
            is_master = entry["master_screen_id"] == screen_id and entry["master_layer_id"] == layer_id
            role = ("master" if scope == "common" else "variant-master") if is_master else "reuse"
            if not is_master:
                reused_layers.add(layer_id)
        bindings.append({
            "reuse_key": key,
            "variant_of": variant_of,
            "layer_id": layer_id,
            "role": role,
            "status": entry["status"],
            "master_screen_id": entry["master_screen_id"],
            "master_layer_id": entry["master_layer_id"],
            "master_asset_path": entry["master_asset_path"],
            "master_asset_sha256": entry["master_asset_sha256"],
            "placement": placement,
        })
    screen_prefix = _safe_screen_id(screen_id)
    kept = [item for item in compiled if not any(item["id"].startswith(f"{screen_prefix}__{layer_id}__") for layer_id in reused_layers)]
    registry_path = _save_registry(work, root, registry, force=force)
    return kept, bindings, registry_path

def register_common(plan_path: Path, root: Path, reuse_key: str, asset_path: Path, *, force: bool = False) -> dict[str, Any]:
    plan, work, _ = validate_plan(plan_path, root)
    registry = _load_registry(work, root)
    key = reuse_key.strip()
    require(key in registry["assets"], f"reuse_key is not planned in common asset registry: {key}")
    entry = registry["assets"][key]
    master_layer = next((layer for layer in plan["layers"] if layer.get("layer_id") == entry["master_layer_id"] and plan["screen_id"] == entry["master_screen_id"]), None)
    require(master_layer is not None, "register-common must be executed with the master screen plan")
    asset = workspace_path(asset_path, root, must_exist=True)
    require((work / "final").resolve() in asset.parents, "common master asset must live under work/final/")
    require(asset.suffix.lower() == ".png", "common master asset must be a PNG")
    try:
        from PIL import Image
        with Image.open(asset) as opened:
            opened.load()
            require(opened.format == "PNG", "common master asset bytes must decode as PNG")
            has_alpha = opened.mode in {"RGBA", "LA"} or "transparency" in opened.info
            require(has_alpha, "common master UI asset must contain an alpha channel")
    except ImportError as exc:
        raise BatchError("Pillow is required to validate common master UI assets") from exc
    except OSError as exc:
        raise BatchError(f"common master asset is not a valid PNG: {asset}") from exc
    expected = workspace_path(entry["master_asset_path"], root)
    if asset != expected:
        expected.parent.mkdir(parents=True, exist_ok=True)
        if expected.exists():
            require(force, f"common master destination already exists: {entry['master_asset_path']}")
            expected.unlink()
        expected.write_bytes(asset.read_bytes())
        asset = expected
    entry["status"] = "READY"
    entry["master_asset_path"] = workspace_relative(asset, root)
    entry["master_asset_sha256"] = sha256_file(asset)
    registry_path = _save_registry(work, root, registry, force=True)
    return {
        "status": "success",
        "operation": "register-common",
        "reuse_key": key,
        "master_asset_path": entry["master_asset_path"],
        "master_asset_sha256": entry["master_asset_sha256"],
        "registry": workspace_relative(registry_path, root),
        "registry_sha256": sha256_file(registry_path),
        "network_called": False,
    }


def validate_plan(plan_path: Path, root: Path) -> tuple[dict[str, Any], Path, list[dict[str, Any]]]:
    plan = load_json(plan_path)
    require(plan.get("schema_version") == SCHEMA, f"UI layer plan schema must be {SCHEMA}")
    require(plan.get("status") == "READY", "UI layer plan must be READY")
    work = find_work_root(plan_path, root)
    require(plan_path.parent.resolve() == work, "ui-layer-plan.json must live directly in current work/")

    state = load_json(work.parent / "state.json")
    require(state.get("primary_skill") == PRIMARY_SKILL,
            f"request primary_skill must be {PRIMARY_SKILL}")

    source = workspace_path(str(plan.get("source_image", "")), root, must_exist=True)
    require(str(plan.get("source_sha256", "")) == sha256_file(source), "UI layer plan source_sha256 is stale")
    try:
        from PIL import Image
        with Image.open(source) as opened:
            opened.load(); decoded_source_size = list(opened.size)
    except ImportError as exc:
        raise BatchError("Pillow is required to validate UI decomposition sizes") from exc
    require(plan.get("source_canvas_size") == decoded_source_size, "source_canvas_size must exactly match decoded source")
    size_contract = plan.get("size_contract")
    require(isinstance(size_contract, dict), "size_contract is required")
    try:
        validate_size_contract(size_contract, source_size=tuple(decoded_source_size))
    except ValueError as exc:
        raise BatchError(str(exc)) from exc
    require(size_contract.get("skill") == SKILL_UI, "size_contract skill mismatch")
    delivery = size_contract["delivery_canvas"]
    delivery_canvas = [int(delivery["width"]), int(delivery["height"])]
    require(plan.get("delivery_canvas_size") == delivery_canvas, "delivery_canvas_size does not match size_contract")
    surface = size_contract["work_surfaces"][0]
    canvas = [int(surface["width"]), int(surface["height"])]
    require(plan.get("work_canvas_size") == canvas, "work_canvas_size does not match size_contract")
    expected_size = f"{canvas[0]}x{canvas[1]}"
    work_image = workspace_path(str(plan.get("work_source", "")), root, must_exist=True)
    require(find_work_root(work_image, root) == work, "work_source must be inside current request work/")
    work_sha = str(plan.get("work_sha256", ""))
    require(work_sha == sha256_file(work_image), "UI layer plan work_sha256 is stale")
    with Image.open(work_image) as opened:
        opened.load()
        require(opened.size == tuple(canvas), f"work_source size {opened.width}x{opened.height} does not match plan {expected_size}")

    screen_map_path = workspace_path(str(plan.get("screen_structure_map", "")), root, must_exist=True)
    require(find_work_root(screen_map_path, root) == work, "screen_structure_map must be inside current request work/")
    screen_map = _validate_screen_map(screen_map_path, str(plan.get("screen_structure_map_sha256", "")),
                                      str(plan.get("source_sha256", "")), work_sha, delivery_canvas)
    screen_id = str(plan.get("screen_id", "")).strip()
    require(screen_id and screen_id == screen_map["screen_id"], "UI layer plan screen_id must match screen structure map")
    require(plan.get("scene_present") == screen_map["scene_present"], "UI layer plan scene_present must match screen structure map")
    occlusion_path = workspace_path(str(plan.get("ui_occlusion_graph", "")), root, must_exist=True)
    require(find_work_root(occlusion_path, root) == work, "ui_occlusion_graph must be inside current request work/")
    occlusion_graph = _validate_occlusion_graph(occlusion_path, str(plan.get("ui_occlusion_graph_sha256", "")), screen_id)

    granularity = str(plan.get("granularity_mode", ""))
    require(granularity in ALLOWED_GRANULARITY, f"invalid granularity_mode={granularity}")
    default_text = str(plan.get("default_text_policy", ""))
    require(default_text in ALLOWED_TEXT_POLICIES, f"invalid default_text_policy={default_text}")
    default_model = str(plan.get("default_model") or "gpt-image-2.5-sunburst")
    require(default_model in ALLOWED_MODELS, f"unsupported default_model={default_model}")
    require(str(plan.get("screen_type", "")).strip(), "screen_type is required")

    layers = plan.get("layers")
    require(isinstance(layers, list) and layers, "UI layer plan requires non-empty layers")
    layer_ids: set[str] = set()
    z_orders: set[int] = set()
    call_ids: set[str] = set()
    outputs: set[str] = set()
    compiled: list[dict[str, Any]] = []
    scene_count = 0
    required_fields = {
        "layer_id", "name", "layer_type", "space", "group", "z_order", "strategy", "transparent",
        "source_node_ids", "contains_text", "text_regions", "text_policy", "observed_state", "observed_in_screens", "other_states",
        "bbox_hint", "anchor_hint", "occluded_by", "occludes", "occludes_scene", "independent_control",
        "reuse_scope", "reuse_key", "variant_of", "includes", "excludes", "completion_scope", "api_calls",
    }
    common_master_by_key: dict[str, str] = {}
    pending_occlusion: dict[str, list[str]] = {}
    pending_occludes: dict[str, list[str]] = {}
    screen_node_ids = {str(node["node_id"]) for node in screen_map["nodes"]}
    screen_nodes = {str(node["node_id"]): node for node in screen_map["nodes"]}
    claimed_source_nodes: dict[str, str] = {}
    selected_source_nodes: set[str] = set()

    for index, layer in enumerate(layers):
        require(isinstance(layer, dict), f"layers[{index}] must be object")
        missing = required_fields - set(layer)
        require(not missing, f"UI layer missing fields {sorted(missing)} at index={index}")
        layer_id = str(layer["layer_id"]).strip()
        require(layer_id and layer_id not in layer_ids, f"layer_id missing or duplicate: {layer_id!r}")
        layer_ids.add(layer_id)
        require(str(layer["name"]).strip(), f"name missing: {layer_id}")
        require(layer["layer_type"] in ALLOWED_LAYER_TYPES, f"invalid layer_type: {layer_id}")
        require(layer["space"] in ALLOWED_SPACES, f"invalid space: {layer_id}")
        z = layer["z_order"]
        require(isinstance(z, int) and not isinstance(z, bool) and z not in z_orders,
                f"z_order must be unique integer: {layer_id}")
        z_orders.add(z)
        require(layer["strategy"] in ALLOWED_STRATEGIES, f"invalid strategy: {layer_id}")
        require(isinstance(layer["transparent"], bool), f"transparent must be boolean: {layer_id}")
        source_nodes = layer["source_node_ids"]
        require(isinstance(source_nodes, list) and source_nodes and all(isinstance(x, str) and x.strip() for x in source_nodes),
                f"source_node_ids must be a non-empty string array: {layer_id}")
        unknown_nodes = sorted(set(source_nodes) - screen_node_ids)
        require(not unknown_nodes, f"source_node_ids reference unknown screen-map nodes {unknown_nodes}: {layer_id}")
        require(isinstance(layer["contains_text"], bool), f"contains_text must be boolean: {layer_id}")
        require(layer["text_policy"] in ALLOWED_TEXT_POLICIES, f"invalid text_policy: {layer_id}")
        _validate_bbox(layer["bbox_hint"], layer_id, delivery_canvas)
        source_node_objs = [screen_nodes[node_id] for node_id in source_nodes]
        source_spaces = {node["space"] for node in source_node_objs}
        require(source_spaces == {layer["space"]},
                f"layer space must match all source screen-map nodes: {layer_id} nodes={sorted(source_spaces)} plan={layer['space']}")
        expected_bbox = _bbox_union([node["bbox"] for node in source_node_objs])
        require(layer["bbox_hint"] == expected_bbox,
                f"bbox_hint must equal the union of source screen-map node bboxes: {layer_id} expected={expected_bbox}")
        expected_contains_text = any(bool(node["contains_text"]) for node in source_node_objs)
        require(layer["contains_text"] == expected_contains_text,
                f"contains_text must match source screen-map evidence: {layer_id}")
        expected_occludes_scene = any(bool(node["occludes_scene"]) for node in source_node_objs)
        require(layer["occludes_scene"] == expected_occludes_scene,
                f"occludes_scene must match source screen-map evidence: {layer_id}")
        for node_id in source_nodes:
            require(node_id not in claimed_source_nodes,
                    f"screen-map node claimed by multiple layers: {node_id} -> {claimed_source_nodes.get(node_id)} / {layer_id}")
            for previous in selected_source_nodes:
                require(not _is_ancestor(previous, node_id, screen_nodes) and not _is_ancestor(node_id, previous, screen_nodes),
                        f"cannot decompose both a screen-map parent and its descendant: {previous} / {node_id}")
            claimed_source_nodes[node_id] = layer_id
            selected_source_nodes.add(node_id)
        _validate_text_regions(layer["text_regions"], layer_id, delivery_canvas, layer["bbox_hint"])
        if layer["contains_text"]:
            require(bool(layer["text_regions"]), f"contains_text=true requires text_regions: {layer_id}")
        else:
            require(not layer["text_regions"], f"contains_text=false requires empty text_regions: {layer_id}")
        require(str(layer["observed_state"]).strip(), f"observed_state required: {layer_id}")
        observed_in = layer["observed_in_screens"]
        require(isinstance(observed_in, list) and observed_in and all(isinstance(x, str) and x.strip() for x in observed_in),
                f"observed_in_screens must be a non-empty string array: {layer_id}")
        require(screen_id in observed_in, f"current screen_id must appear in observed_in_screens: {layer_id}")
        require(layer["other_states"] == "not_observed", f"unobserved states must remain not_observed; create explicit variants only from real screenshots: {layer_id}")
        anchor = layer["anchor_hint"]
        require(isinstance(anchor, list) and len(anchor) == 2 and all(isinstance(x, int) and not isinstance(x, bool) for x in anchor),
                f"anchor_hint must be integer [x,y]: {layer_id}")
        require(anchor == layer["bbox_hint"][:2], f"anchor_hint must equal bbox_hint top-left: {layer_id}")
        for field in ("occluded_by", "occludes", "includes", "excludes"):
            value = layer[field]
            require(isinstance(value, list) and all(isinstance(x, str) and x.strip() for x in value),
                    f"{field} must be array of non-empty strings: {layer_id}")
        require(layer["includes"], f"includes must identify owned content: {layer_id}")
        require(isinstance(layer["occludes_scene"], bool) and isinstance(layer["independent_control"], bool),
                f"occludes_scene/independent_control must be boolean: {layer_id}")
        reuse_scope = layer["reuse_scope"]
        require(reuse_scope in ALLOWED_REUSE_SCOPES, f"invalid reuse_scope: {layer_id}")
        reuse_key = layer["reuse_key"]
        require(reuse_key is None or (isinstance(reuse_key, str) and reuse_key.strip()), f"invalid reuse_key: {layer_id}")
        if reuse_scope == "common":
            require(isinstance(reuse_key, str) and reuse_key.strip(), f"common asset requires reuse_key: {layer_id}")
            require(layer["variant_of"] is None, f"common master must not set variant_of: {layer_id}")
            require(reuse_key not in common_master_by_key,
                    f"duplicate common master reuse_key={reuse_key}: {layer_id} vs {common_master_by_key.get(reuse_key)}")
            common_master_by_key[reuse_key] = layer_id
        elif reuse_scope == "variant":
            require(isinstance(reuse_key, str) and reuse_key.strip(), f"variant requires reuse_key: {layer_id}")
            require(isinstance(layer["variant_of"], str) and layer["variant_of"].strip(), f"variant requires variant_of: {layer_id}")
        else:
            require(layer["variant_of"] is None, f"screen-local layer must not set variant_of: {layer_id}")
        require(str(layer["completion_scope"]).strip(), f"completion_scope required: {layer_id}")
        pending_occlusion[layer_id] = list(layer["occluded_by"])
        pending_occludes[layer_id] = list(layer["occludes"])

        if layer["layer_type"] == "scene-clean":
            scene_count += 1
            require(layer["space"] == "scene", f"scene-clean must use space=scene: {layer_id}")
            require(layer["strategy"] == "scene_clean_patch", f"scene-clean must use scene_clean_patch: {layer_id}")
            require(layer["transparent"] is False, f"scene-clean must be opaque: {layer_id}")
        elif layer["space"] in {"screen-ui", "world-ui"}:
            require(layer["transparent"] is True, f"UI/world-ui formal layer must be transparent: {layer_id}")

        if granularity == "balanced":
            atom_words = {"icon-only", "badge-only", "label-only", "text-only", "border-only"}
            labels = {str(x).strip().lower() for x in layer["includes"]}
            require(not (labels & atom_words), f"balanced plan contains atomic fragment {labels & atom_words}: {layer_id}")

        if layer["contains_text"] and layer["text_policy"] == "strip-and-fill":
            require(layer["strategy"] == "text_strip_reconstruct",
                    f"contains_text + strip-and-fill requires text_strip_reconstruct: {layer_id}")
        calls = layer["api_calls"]
        require(isinstance(calls, list), f"api_calls must be array: {layer_id}")
        call_names = {str(call.get("id", "")).strip() for call in calls if isinstance(call, dict)}
        strategy = layer["strategy"]
        if strategy == "scene_clean_patch":
            require("clean" in call_names, f"scene_clean_patch requires clean pass: {layer_id}")
        elif strategy == "control_extract":
            require("visible" in call_names, f"control_extract requires visible pass: {layer_id}")
        elif strategy == "control_reconstruct":
            require({"visible", "reconstruct"}.issubset(call_names), f"control_reconstruct requires visible + reconstruct passes: {layer_id}")
        elif strategy == "text_strip_reconstruct":
            require("reconstruct" in call_names, f"text_strip_reconstruct requires reconstruct pass: {layer_id}")
        elif strategy == "model_native_alpha":
            require(bool(calls), f"model_native_alpha requires at least one model pass: {layer_id}")
        elif strategy in {"source_asset", "unrecoverable"}:
            require(not calls, f"strategy={strategy} must not define API calls: {layer_id}")
        for call in calls:
            require(isinstance(call, dict), f"api call must be object: {layer_id}")
            call_name = str(call.get("id", "")).strip()
            require(call_name, f"api call id missing: {layer_id}")
            global_id = f"{_safe_screen_id(str(plan['screen_id']))}__{layer_id}__{call_name}"
            require(global_id not in call_ids, f"duplicate API call id: {global_id}")
            call_ids.add(global_id)
            mode = str(call.get("mode", ""))
            require(mode in ALLOWED_MODES, f"invalid mode={mode}: {global_id}")
            model = str(call.get("model") or default_model).strip()
            require(model in ALLOWED_MODELS, f"unsupported model={model}: {global_id}")
            prompt_path = workspace_path(str(call.get("prompt_path", "")), root, must_exist=True)
            require(find_work_root(prompt_path, root) == work, f"Prompt outside current request: {global_id}")
            output_path = workspace_path(str(call.get("output_path", "")), root)
            originals = (work / "final" / "originals").resolve()
            require(originals in output_path.parents, f"API output must be inside work/final/originals/: {global_id}")
            output_rel = workspace_relative(output_path, root)
            require(output_rel not in outputs, f"duplicate API output: {output_rel}")
            outputs.add(output_rel)
            params = call.get("parameters")
            require(isinstance(params, dict), f"parameters must be object: {global_id}")
            require(str(params.get("size", "")) == expected_size,
                    f"all model passes must use work surface {expected_size}: {global_id}")
            require(str(params.get("output_format", "")).lower() == "png", f"UI layer passes must output PNG: {global_id}")
            expected_background = "opaque" if layer["layer_type"] == "scene-clean" else "transparent"
            require(str(params.get("background", "")).lower() == expected_background,
                    f"background must be {expected_background}: {global_id}")
            require(str(params.get("quality", "")).lower() in {"auto", "low", "medium", "high", "xhigh", "max"},
                    f"invalid quality: {global_id}")

            request: dict[str, Any] = {
                "api_profile": "gpt", "mode": mode, "model": model,
                "prompt_path": workspace_relative(prompt_path, root), "output_path": output_rel,
                "parameters": params,
            }
            for optional in ("reference_images", "base_image", "mask_image"):
                if call.get(optional) not in (None, "", []):
                    request[optional] = call[optional]
            _validate_bound_media(request.get("reference_images"), work, root, label=f"reference_images for {global_id}")
            _validate_bound_media(request.get("mask_image"), work, root, label=f"mask_image for {global_id}")
            if mode == "image_to_image_edit":
                base = str(request.get("base_image", "")).strip()
                require(base, f"image_to_image_edit requires base_image: {global_id}")
                base_path = workspace_path(base, root, must_exist=True)
                require(base_path == work_image, f"image_to_image_edit must bind work_source as base_image: {global_id}")
            if mode == "reference_to_image":
                require(bool(request.get("reference_images")), f"reference_to_image requires reference_images: {global_id}")

            compiled.append({
                "id": global_id, "status": "READY", "api_profile": "gpt", "mode": mode, "model": model,
                "prompt_path": request["prompt_path"], "prompt_sha256": sha256_file(prompt_path),
                "output_path": output_rel, "parameters": params,
                **({"reference_images": request["reference_images"]} if "reference_images" in request else {}),
                **({"base_image": request["base_image"]} if "base_image" in request else {}),
                **({"mask_image": request["mask_image"]} if "mask_image" in request else {}),
                "_request": request,
            })

    if plan.get("scene_present"):
        require(scene_count == 1, "scene_present=true requires exactly one scene-clean master")
    else:
        require(scene_count == 0, "scene_present=false must not declare scene-clean")
    for layer_id, occluders in pending_occlusion.items():
        require(layer_id not in occluders, f"layer cannot occlude itself: {layer_id}")
        unknown = sorted(set(occluders) - layer_ids)
        require(not unknown, f"occluded_by references unknown layer(s) {unknown}: {layer_id}")
    for layer_id, targets in pending_occludes.items():
        require(layer_id not in targets, f"layer cannot occlude itself: {layer_id}")
        unknown = sorted(set(targets) - layer_ids)
        require(not unknown, f"occludes references unknown layer(s) {unknown}: {layer_id}")
        for target in targets:
            require(layer_id in pending_occlusion.get(target, []),
                    f"UI occlusion relation not reciprocal: {layer_id} occludes {target} but target.occluded_by omits it")
    for layer_id, sources in pending_occlusion.items():
        for source in sources:
            require(layer_id in pending_occludes.get(source, []),
                    f"UI occlusion relation not reciprocal: {layer_id}.occluded_by={source} but source.occludes omits it")
    graph_edges = {(edge["from"], edge["to"]) for edge in occlusion_graph["edges"]}
    for source, targets in pending_occludes.items():
        for target in targets:
            require((source, target) in graph_edges, f"UI occlusion graph missing edge {source}->{target}")
    for layer in layers:
        if layer["occludes_scene"]:
            require((layer["layer_id"], "SCENE") in graph_edges, f"UI occlusion graph missing scene edge {layer['layer_id']}->SCENE")
    valid_graph_endpoints = set(layer_ids) | ({"SCENE"} if plan.get("scene_present") else set())
    for source, target in graph_edges:
        require(source in valid_graph_endpoints and target in valid_graph_endpoints,
                f"UI occlusion graph references unknown endpoint: {source}->{target}")
    require(compiled, "UI layer plan contains no API calls")
    return plan, work, compiled


def build(plan_path: Path, root: Path, *, force: bool = False) -> dict[str, Any]:
    plan, work, compiled = validate_plan(plan_path, root)
    compiled, reuse_bindings, registry_path = _resolve_common_assets(plan, work, root, compiled, force=force)
    screen_index_path, final_dir = _register_screen_plan(plan_path, plan, work, root)
    public_items: list[dict[str, Any]] = []
    request_files: list[str] = []
    for item in compiled:
        request = item.pop("_request")
        request_path = work / "api-requests" / f"{item['id']}.json"
        write_idempotent(request_path, stable_json(request), force=force)
        request_files.append(workspace_relative(request_path, root))
        public_items.append(item)
    generation_plan = {
        "schema_version": GENERATION_SCHEMA,
        "primary_skill": PRIMARY_SKILL,
        "status": "READY",
        "source_contract": source_contract(plan_path, plan, root),
        "items": public_items,
    }
    generation_path = work / "generation-plan.json"
    write_idempotent(generation_path, stable_json(generation_plan), force=force)
    return {
        "status": "success", "operation": "build", "ui_layer_plan": workspace_relative(plan_path, root),
        "generation_plan": workspace_relative(generation_path, root),
        "generation_plan_sha256": sha256_file(generation_path), "item_count": len(public_items),
        "request_files": request_files, "common_asset_registry": workspace_relative(registry_path, root),
        "common_asset_registry_sha256": sha256_file(registry_path), "reuse_bindings": reuse_bindings,
        "screen_plan_index": workspace_relative(screen_index_path, root),
        "screen_plan_index_sha256": sha256_file(screen_index_path),
        "final_dir": workspace_relative(final_dir, root),
        "network_called": False,
    }

def _successful_existing(output: Path) -> bool:
    receipt = output.with_name(output.name + ".call.json")
    if not output.is_file() or not receipt.is_file():
        return False
    try:
        value = load_json(receipt)
    except BatchError:
        return False
    return value.get("status") == "success" and value.get("output_sha256") == sha256_file(output)


def run(plan_path: Path, root: Path, mode: str, *, force_build: bool = False) -> dict[str, Any]:
    build_result = build(plan_path, root, force=force_build)
    if mode == "invoke":
        blocked_reuse = [item for item in build_result.get("reuse_bindings", []) if item.get("role") == "reuse" and item.get("status") != "READY"]
        require(not blocked_reuse,
                "invoke requires every reused common asset master to be READY; pending=" + ", ".join(item["reuse_key"] for item in blocked_reuse))
    generation_plan = load_json(workspace_path(build_result["generation_plan"], root, must_exist=True))
    api_script = root / ".agents" / "skills" / "image-generation-api" / "scripts" / "generation_api.py"
    require(api_script.is_file(), "image-generation-api executor is missing")
    results: list[dict[str, Any]] = []
    blocked = False
    api_module = load_local_module(api_script, "wxian_generation_api_ui_batch", "image-generation-api") if mode == "dry-run" else None
    for item in generation_plan["items"]:
        request_path = find_work_root(plan_path, root) / "api-requests" / f"{item['id']}.json"
        output = workspace_path(item["output_path"], root)
        if _successful_existing(output):
            results.append({"id": item["id"], "status": "skipped_existing_verified", "output": item["output_path"]})
            continue
        require(not output.exists(), f"output exists without a matching success receipt: {item['output_path']}")
        if mode == "dry-run":
            try:
                payload = api_module.dry_run_request_file(request_path, root)
                returncode = 0
            except (api_module.ApiError, OSError) as exc:
                payload = {"status": "blocked", "reason": str(exc), "network_called": False}
                returncode = 1
            entry: dict[str, Any] = {"id": item["id"], "returncode": returncode, "result": payload}
        else:
            command = [sys.executable, str(api_script), mode, "--request", str(request_path), "--workspace-root", str(root)]
            completed = subprocess.run(command, text=True, capture_output=True)
            try:
                payload = json.loads(completed.stdout) if completed.stdout.strip() else {}
            except json.JSONDecodeError:
                payload = {"status": "blocked", "reason": "generation_api returned non-JSON output", "stdout": completed.stdout[-2000:]}
            entry = {"id": item["id"], "returncode": completed.returncode, "result": payload}
            if completed.stderr.strip():
                entry["stderr"] = completed.stderr[-2000:]
            returncode = completed.returncode
        results.append(entry)
        if returncode != 0:
            blocked = True
            break
    return {
        "status": "blocked" if blocked else "success", "operation": f"run:{mode}",
        "item_count": len(generation_plan["items"]), "results": results,
        "reuse_bindings": build_result.get("reuse_bindings", []),
        "network_called": mode == "invoke" and any(
            isinstance(entry.get("result"), dict) and entry["result"].get("network_called") for entry in results
        ),
    }

def doctor() -> dict[str, Any]:
    require(PRIMARY_SKILL == "wxian-game-ui-layer-decomposition", "primary skill constant changed")
    require(SCHEMA == "wxian.game-ui-layer-plan.v4", "UI plan schema changed")
    require("balanced" in ALLOWED_GRANULARITY and "atomic" in ALLOWED_GRANULARITY, "granularity contract missing")
    require("strip-and-fill" in ALLOWED_TEXT_POLICIES and "preserve-visual" in ALLOWED_TEXT_POLICIES, "text policy contract missing")
    require("scene_clean_patch" in ALLOWED_STRATEGIES and "control_reconstruct" in ALLOWED_STRATEGIES, "UI reconstruction strategy missing")
    return {
        "status": "ready", "tool": "ui_layer_batch",
        "capabilities": ["screen-map-binding", "screen-node-layer-consistency", "hierarchy-granularity-guard", "occlusion-graph-binding",
                         "bounded-bbox-anchor", "balanced-granularity-gate", "text-strategy-contract", "observed-state-evidence",
                         "reuse-contract", "cross-screen-common-registry", "request-screen-plan-index", "per-screen-final-pack", "common-master-hash-binding", "source-contract-binding", "reconstruction-visual-contract-binding", "finite-plan-compile", "generation-plan-binding", "resume-verified-output"],
        "network_called": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("doctor")
    p_prepare = sub.add_parser("prepare-contract")
    p_prepare.add_argument("--plan", type=Path, required=True)
    p_prepare.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])
    p_prepare.add_argument("--force", action="store_true")
    p_register = sub.add_parser("register-common")
    p_register.add_argument("--plan", type=Path, required=True)
    p_register.add_argument("--reuse-key", required=True)
    p_register.add_argument("--asset", type=Path, required=True)
    p_register.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])
    p_register.add_argument("--force", action="store_true")
    p_build = sub.add_parser("build")
    p_build.add_argument("--plan", type=Path, required=True)
    p_build.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])
    p_build.add_argument("--force", action="store_true")
    p_run = sub.add_parser("run")
    p_run.add_argument("--plan", type=Path, required=True)
    p_run.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])
    p_run.add_argument("--mode", choices=("dry-run", "invoke"), required=True)
    p_run.add_argument("--force-build", action="store_true")
    args = parser.parse_args()
    try:
        if args.command == "doctor":
            result = doctor()
        else:
            root = args.workspace_root.resolve()
            plan = workspace_path(args.plan, root, must_exist=True)
            if args.command == "prepare-contract":
                result = prepare_contract(plan, root, force=args.force)
            elif args.command == "register-common":
                result = register_common(plan, root, args.reuse_key, args.asset, force=args.force)
            elif args.command == "build":
                result = build(plan, root, force=args.force)
            else:
                result = run(plan, root, args.mode, force_build=args.force_build)
    except (BatchError, OSError, subprocess.SubprocessError) as exc:
        print(json.dumps({"status": "blocked", "reason": str(exc)}, ensure_ascii=False))
        return 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result.get("status") != "blocked" else 1


if __name__ == "__main__":
    raise SystemExit(main())
