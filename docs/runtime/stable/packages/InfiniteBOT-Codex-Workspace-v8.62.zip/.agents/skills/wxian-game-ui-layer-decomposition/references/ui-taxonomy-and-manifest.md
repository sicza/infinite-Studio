# Game UI Taxonomy & Manifest

## 1. Spaces

```text
scene
screen-ui
world-ui
```

## 2. Layer Types

```text
scene-clean
hud-group
ui-module
ui-control
ui-base
navigation
modal-panel
detail-panel
quest-bar
chat-bar
world-indicator
world-bubble
decoration
```

## 3. Strategies

```text
scene_clean_patch
control_extract
control_reconstruct
text_strip_reconstruct
source_asset
model_native_alpha
unrecoverable
```

## 4. UI Layer Plan v3

```json
{
  "schema_version": "wxian.game-ui-layer-plan.v4",
  "status": "READY",
  "source_image": "requests/.../input/screen.png",
  "source_sha256": "...",
  "work_source": "requests/.../work/source-work.png",
  "work_sha256": "...",
  "work_canvas_size": [2160, 3840],
  "screen_id": "city_01",
  "scene_present": true,
  "screen_structure_map": "requests/.../work/screen-structure-map.json",
  "screen_structure_map_sha256": "...",
  "ui_occlusion_graph": "requests/.../work/ui-occlusion-graph.json",
  "ui_occlusion_graph_sha256": "...",
  "screen_type": "city_scene_with_hud",
  "granularity_mode": "balanced",
  "default_text_policy": "strip-and-fill",
  "default_model": "gpt-image-2.5-sunburst",
  "layers": []
}
```

## 5. Layer Item

```json
{
  "layer_id": "UI_RIGHT_ACTIVITY_CENTER",
  "name": "Activity center control",
  "layer_type": "ui-control",
  "space": "screen-ui",
  "group": "right-events",
  "z_order": 420,
  "strategy": "text_strip_reconstruct",
  "transparent": true,
  "source_node_ids": ["right_activity_center"],
  "contains_text": true,
  "text_regions": [[1900, 650, 160, 40]],
  "text_policy": "strip-and-fill",
  "observed_state": "notification",
  "observed_in_screens": ["city_01"],
  "other_states": "not_observed",
  "bbox_hint": [1870, 420, 230, 300],
  "anchor_hint": [1870, 420],
  "occluded_by": [],
  "occludes": [],
  "occludes_scene": true,
  "independent_control": true,
  "reuse_scope": "screen-local",
  "reuse_key": null,
  "variant_of": null,
  "includes": ["complete activity-center control", "icon", "notification badge"],
  "excludes": ["scene", "neighbor controls", "ordinary label text"],
  "completion_scope": "complete own control silhouette and hidden base only",
  "api_calls": []
}
```

### Screen-map binding

`ui-layer-plan.json` is invalid unless it is hash-bound to a `screen-structure-map.json` and `ui-occlusion-graph.json`. Each layer must map to one or more real `source_node_ids`. Bbox and anchor are delivery-canvas coordinates; anchor equals bbox top-left for deterministic crop placement.

### Text evidence

`contains_text` and `text_regions` make the low-priority text policy explicit. If `contains_text=true` and `text_policy=strip-and-fill`, the layer must use `text_strip_reconstruct`; ordinary text is not silently baked into the asset.

### Observed-state evidence

`observed_in_screens` records where the state was actually seen. `other_states` remains `not_observed`; another state only exists after a real screenshot provides evidence and is represented as a separate variant.

## 6. Text Policies

```text
strip-and-fill
retain-source
preserve-visual
ignore
```

## 7. Reuse

```text
reuse_scope = common | screen-local | variant
reuse_key   = stable semantic key or null
```

同 reuse_key 只应有一个正式 master；其他截图只记录 placement，不重复 generation。不同视觉状态/尺寸/结构必须使用新的 variant reuse_key，并用 `variant_of` 指向 common master。

### Request-level Common Asset Registry

多 Screen Plan 共享：

```text
work/common-asset-registry.json
schema = wxian.game-ui-common-asset-registry.v1
```

每个 registry entry 记录：

```text
reuse_key / variant_of
status = PLANNED | READY
signature
master_screen_id / master_layer_id
master_asset_path / master_asset_sha256
placements[]
```

规则：

- `common` 第一次出现建立 common master；
- `variant` 直接引用已存在的 common master；
- 同 reuse_key 的视觉 signature 变化必须拒绝，要求新 variant key；
- 后续 Screen 复用同 key 时，不再生成该层；
- `invoke` 前复用的 master 必须 READY；
- READY master 必须位于当前 request `work/final/`，是有效带 Alpha 的 PNG，并由 SHA256 锁定。

## 8. Final Manifest

Final output layout、request-level Screen completion scope 与 `wxian.game-ui-final-layer-manifest.v2` 的**唯一规范定义**位于 [execution-and-qa.md](execution-and-qa.md) 的 `Output contract` / `Final completion contract`。

本文件只维护 UI taxonomy、Screen Structure / reuse / state 语义，不维护第二份 Final Manifest 字段表。Final Manifest 必须由 `delivery_gate.py` 按当前 canonical `file / sha256 / crop_file / crop_sha256 / source_node_ids / reuse_*` 合同验证；历史 `full_canvas_file` 等字段不得作为替代。

## Screen-map Node Ownership

正式 UI 层必须以 `source_node_ids` 声明来自哪些 Screen Structure Map 节点。机器 Gate 强制 node 唯一 claim、parent/descendant 不重复交付、bbox union 一致、space/text/scene-occlusion evidence 一致。这样可以同时阻止“一个大组 + 组内按钮都生成”造成的重复资产，以及 layer bbox 脱离真实截图结构。
