# Occlusion & Clean Plate

## 1. 核心原则

拆掉上层后，下层必须完整。

## 2. Scene Clean Plate

要移除：

```text
Top/Left/Right/Bottom screen UI
modal/panel
quest/chat overlays
world-space bubbles/markers/arrows
screen text/icons/badges
```

要保留：

```text
真实游戏世界
建筑/地形/道路/水体
游戏角色/NPC/怪物
场景内真正的载具/道具
场景光影
```

World-space UI 不是场景实体，要移除。

## 3. 补全范围

必须补：

```text
原 UI bbox
阴影/外发光占用范围
因 UI 与 scene 接触产生的被挡边缘
```

正式 `scene_clean` 使用 source-preserving patch：保留可见 scene 原像素，模型只补原 UI 覆盖且缺失的区域。

## 4. UI Base Completion

若一个 base layer 被上层控件遮挡而要独立存在：

```text
resource bar behind avatar
nav background behind buttons
panel background behind cards/tabs
```

必须补完整 base，不能交付一个被挖掉的残件。

## 5. World UI Removal

移除箭头/气泡/marker 后：

- Scene 下方内容必须恢复；
- World UI 自己以透明 PNG 独立；
- 不把 World UI 的 glow 烘焙在 scene 上。
## 6. Provider mask is guidance, not geometry authority

GPT Image 2.5 的 edit mask 可用来限制编辑区域和降低误改概率，但模型可能不会逐像素严格服从 mask 轮廓。因此：

```text
provider mask = generation guidance
visible source pixels = Source Authority
final reveal boundary = deterministic occupancy/reveal mask
formal merge = source-lock / patch-clean-plate
```

Provider mask 只提供编辑 guidance；正式几何与结果仍由确定性合成和回拼 QA 确认。

