#!/usr/bin/env python3
"""Resident request-level finalization test for UI 2x editable masters + 1x PSD delivery."""
from __future__ import annotations
import os as _os,sys as _sys
_sys.dont_write_bytecode=True; _os.environ['PYTHONDONTWRITEBYTECODE']='1'
import argparse,hashlib,importlib.util,json,shutil,uuid
from pathlib import Path
from PIL import Image
HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[3]
def mod(p,n):
 s=importlib.util.spec_from_file_location(n,p); assert s and s.loader; m=importlib.util.module_from_spec(s); s.loader.exec_module(m); return m
batch=mod(HERE/'ui_layer_batch.py','ui_batch_finalization_v2'); gate=mod(HERE/'delivery_gate.py','ui_delivery_finalization_v2'); size=mod(ROOT/'.agents/lib/decomposition_size.py','ui_size_v2'); psd=mod(ROOT/'.agents/skills/wxian-layered-psd-export/scripts/psd_export.py','ui_psd_v2')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def wj(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def rel(p):return p.resolve().relative_to(ROOT.resolve()).as_posix()
def expect_block(fn,label):
 try:fn()
 except Exception as exc:return str(exc)
 raise AssertionError(f'negative fixture unexpectedly passed: {label}')
def make_plan(req,suffix='',screen='s1'):
 work=req/'work'; inp=req/'input'; prompts=work/'ui-prompts'; prompts.mkdir(parents=True,exist_ok=True); inp.mkdir(parents=True,exist_ok=True)
 source=inp/f'screen{suffix}.png'; delivery=Image.new('RGBA',(1024,1024),(50,70,90,255)); hud=Image.new('RGBA',(1024,1024),(0,0,0,0)); hud.paste((100,120,140,255),(0,0,1024,160)); source_im=Image.alpha_composite(delivery,hud); source_im.save(source)
 contract=size.plan_size_contract((1024,1024),skill=size.SKILL_UI,model='gpt-image-2.5-sunburst'); surface=contract['work_surfaces'][0]; assert [surface['width'],surface['height']]==[2048,2048]
 work_source=work/f'source-work{suffix}.png'; source_im.resize((2048,2048),Image.Resampling.LANCZOS).save(work_source)
 sm={'schema_version':'wxian.game-ui-screen-map.v1','screen_id':screen,'scene_present':True,'source_sha256':sha(source),'work_sha256':sha(work_source),'delivery_canvas_size':[1024,1024],'nodes':[{'node_id':'scene','role':'game-world','space':'scene','bbox':[0,0,1024,1024],'parent':None,'children':[],'interactive':False,'independent_visibility':False,'independent_motion':False,'reusable':False,'occludes_scene':False,'observed_state':'visible','contains_text':False},{'node_id':'hud','role':'hud','space':'screen-ui','bbox':[0,0,1024,160],'parent':None,'children':[],'interactive':False,'independent_visibility':True,'independent_motion':False,'reusable':False,'occludes_scene':True,'observed_state':'visible','contains_text':False}]}
 smp=work/f'screen-structure-map{suffix}.json'; wj(smp,sm); op=work/f'ui-occlusion-graph{suffix}.json'; wj(op,{'schema_version':'wxian.game-ui-occlusion-graph.v1','screen_id':screen,'edges':[{'from':'HUD','to':'SCENE'}]})
 (prompts/f'scene{suffix}.txt').write_text('clean scene',encoding='utf-8'); (prompts/f'hud{suffix}.txt').write_text('hud',encoding='utf-8'); params={'size':'2048x2048','quality':'max','background':'opaque','moderation':'auto','output_format':'png'}
 layers=[{'layer_id':'SCENE','name':'scene','layer_type':'scene-clean','space':'scene','group':'scene','z_order':0,'strategy':'scene_clean_patch','transparent':False,'source_node_ids':['scene'],'contains_text':False,'text_regions':[],'text_policy':'ignore','observed_state':'visible','observed_in_screens':[screen],'other_states':'not_observed','bbox_hint':[0,0,1024,1024],'anchor_hint':[0,0],'occluded_by':['HUD'],'occludes':[],'occludes_scene':False,'independent_control':True,'reuse_scope':'screen-local','reuse_key':None,'variant_of':None,'includes':['scene'],'excludes':['ui'],'completion_scope':'hidden scene','api_calls':[{'id':'clean','mode':'image_to_image_edit','prompt_path':rel(prompts/f'scene{suffix}.txt'),'output_path':rel(work/'final'/'originals'/f'SCENE{suffix}.png'),'base_image':rel(work_source),'parameters':params}]},{'layer_id':'HUD','name':'hud','layer_type':'hud-group','space':'screen-ui','group':'hud','z_order':10,'strategy':'control_extract','transparent':True,'source_node_ids':['hud'],'contains_text':False,'text_regions':[],'text_policy':'ignore','observed_state':'visible','observed_in_screens':[screen],'other_states':'not_observed','bbox_hint':[0,0,1024,160],'anchor_hint':[0,0],'occluded_by':[],'occludes':['SCENE'],'occludes_scene':True,'independent_control':True,'reuse_scope':'screen-local','reuse_key':None,'variant_of':None,'includes':['hud'],'excludes':['scene'],'completion_scope':'visible ui','api_calls':[{'id':'visible','mode':'image_to_image_edit','prompt_path':rel(prompts/f'hud{suffix}.txt'),'output_path':rel(work/'final'/'originals'/f'HUD{suffix}.png'),'base_image':rel(work_source),'parameters':{**params,'background':'transparent'}}]}]
 plan={'schema_version':'wxian.game-ui-layer-plan.v4','status':'READY','screen_id':screen,'screen_type':'gameplay','source_image':rel(source),'source_sha256':sha(source),'source_canvas_size':[1024,1024],'delivery_canvas_size':[1024,1024],'work_source':rel(work_source),'work_sha256':sha(work_source),'work_canvas_size':[2048,2048],'size_contract':contract,'screen_structure_map':rel(smp),'screen_structure_map_sha256':sha(smp),'scene_present':True,'ui_occlusion_graph':rel(op),'ui_occlusion_graph_sha256':sha(op),'granularity_mode':'balanced','default_text_policy':'strip-and-fill','default_model':'gpt-image-2.5-sunburst','layers':layers}
 pp=work/('ui-layer-plan.json' if not suffix else f'ui-layer-plan{suffix}.json'); wj(pp,plan); return pp,delivery,hud,source_im
def finalize(pp,scene,hud,source_im):
 plan=json.loads(pp.read_text(encoding='utf-8')); work=pp.parent; fd=batch.final_dir_for_plan(pp,plan,work); (fd/'scene').mkdir(parents=True,exist_ok=True); (fd/'layers').mkdir(parents=True,exist_ok=True); (fd/'crops').mkdir(parents=True,exist_ok=True); (fd/'masters').mkdir(parents=True,exist_ok=True)
 scene_p=fd/'scene/scene-clean.png'; hud_p=fd/'layers/HUD.png'; crop=fd/'crops/HUD.png'; scene_master=fd/'masters/SCENE@2x.png'; hud_master=fd/'masters/HUD@2x.png'; rec=fd/'recomposition.png'; sf=fd/'screen-structure-map.json'; delivery_ref=fd/'delivery-reference.png'
 scene.save(scene_p); hud.save(hud_p); hud.crop((0,0,1024,160)).save(crop); scene.resize((2048,2048),Image.Resampling.LANCZOS).save(scene_master); hud.crop((0,0,1024,160)).resize((2048,320),Image.Resampling.LANCZOS).save(hud_master); Image.alpha_composite(scene,hud).save(rec); source_im.save(delivery_ref); shutil.copy2(ROOT/plan['screen_structure_map'],sf)
 layers=[]
 for pl,f,c,m in [(plan['layers'][0],scene_p,None,scene_master),(plan['layers'][1],hud_p,crop,hud_master)]:
  bbox=pl['bbox_hint']; layers.append({'layer_id':pl['layer_id'],'name':pl['name'],'status':'passed','layer_type':pl['layer_type'],'space':pl['space'],'z_order':pl['z_order'],'file':rel(f),'sha256':sha(f),'bbox':bbox,'anchor':pl['anchor_hint'],'source_node_ids':pl['source_node_ids'],'reuse_scope':pl['reuse_scope'],'reuse_key':pl['reuse_key'],'variant_of':pl['variant_of'],'contains_text':pl['contains_text'],'text_policy':pl['text_policy'],'observed_state':pl['observed_state'],'qa_status':'PASS','crop_file':rel(c) if c else None,'crop_sha256':sha(c) if c else None,'editable_master':{'file':rel(m),'sha256':sha(m),'size':[bbox[2]*2,bbox[3]*2],'scale_vs_delivery':2.0,'provenance':'deterministic_resample'}})
 mf={'schema_version':'wxian.game-ui-final-layer-manifest.v2','status':'READY','decomposition_skill':'wxian-game-ui-layer-decomposition','ui_layer_plan_path':rel(pp),'ui_layer_plan_sha256':sha(pp),'source_image':plan['source_image'],'source_sha256':plan['source_sha256'],'source_canvas_size':[1024,1024],'delivery_canvas_size':[1024,1024],'delivery_reference_image':rel(delivery_ref),'delivery_reference_sha256':sha(delivery_ref),'screen_structure_map_path':rel(sf),'screen_structure_map_sha256':sha(sf),'common_asset_registry_path':None,'common_asset_registry_sha256':None,'layers':layers}; mfp=fd/'ui-layer-manifest.json'; wj(mfp,mf)
 qa={'schema_version':'wxian.game-ui-qa.v1','status':'PASS','ui_layer_manifest_path':rel(mfp),'ui_layer_manifest_sha256':sha(mfp),'recomposition_path':rel(rec),'recomposition_sha256':sha(rec),'reviewed_layer_ids':['SCENE','HUD']}
 for k in ('scene_complete_review','alpha_boundary_review','geometry_review','granularity_review','text_policy_review','observed_state_review','no_duplicate_ui_review','structure_binding_review'):qa[k]='PASS'
 wj(fd/'ui-qa.json',qa)
 psd.build(ROOT,mfp,fd/'layered.psd',fd/'layered-psd.json'); return fd
def main():
 argparse.ArgumentParser().parse_args(); st=psd.backend_status(ROOT)
 if st.get('status')!='ready': print(json.dumps({'status':'blocked','tool':'ui-finalization-selftest','reason':st.get('reason')},ensure_ascii=False)); return 2
 parent=ROOT/'requests/game-ui-layer-decomposition'; parent.mkdir(parents=True,exist_ok=True); req=parent/f'【20260921】99-UITEST-v858-{uuid.uuid4().hex}'; req.mkdir(); (req/'output').mkdir(); results={}
 try:
  wj(req/'state.json',{'primary_skill':'wxian-game-ui-layer-decomposition','status':'active','revision':1}); (req/'request.md').write_text('resident UI v2 finalization selftest\n',encoding='utf-8')
  p1,s1,h1,src1=make_plan(req); batch.build(p1,ROOT,force=True); f1=finalize(p1,s1,h1,src1); assert gate.validate(ROOT,req)['screen_count']==1; results['single_screen_positive']='PASS'
  mf_path=f1/'ui-layer-manifest.json'; saved=mf_path.read_bytes(); mf=json.loads(saved); mf['layers'][1]['editable_master']['scale_vs_delivery']=1.0; wj(mf_path,mf); q=json.loads((f1/'ui-qa.json').read_text(encoding='utf-8')); q['ui_layer_manifest_sha256']=sha(mf_path); wj(f1/'ui-qa.json',q); expect_block(lambda:gate.validate(ROOT,req),'UI master not 2x'); results['wrong_master_scale']='BLOCK'; mf_path.write_bytes(saved); q=json.loads((f1/'ui-qa.json').read_text(encoding='utf-8')); q['ui_layer_manifest_sha256']=sha(mf_path); wj(f1/'ui-qa.json',q)
  p2,s2,h2,src2=make_plan(req,'-2','s2'); batch.build(p2,ROOT,force=True); expect_block(lambda:gate.validate(ROOT,req),'missing second screen final'); results['missing_second_screen']='BLOCK'; f2=finalize(p2,s2,h2,src2); assert gate.validate(ROOT,req)['screen_count']==2; results['two_screen_positive']='PASS'
  receipt=f2/'layered-psd.json'; saved_receipt=receipt.read_bytes(); receipt.unlink(); expect_block(lambda:gate.validate(ROOT,req),'second screen missing PSD receipt'); results['missing_second_psd_receipt']='BLOCK'; receipt.write_bytes(saved_receipt)
  print(json.dumps({'status':'ready','tool':'ui-finalization-selftest','results':results,'network_called':False},ensure_ascii=False)); return 0
 finally:
  shutil.rmtree(req,ignore_errors=True)
  for p in (parent,parent.parent):
   try:p.rmdir()
   except OSError:pass
if __name__=='__main__':raise SystemExit(main())
