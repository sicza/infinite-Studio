# UI Prompt & Text Policy

## 1. Scene Clean Prompt

```text
Reconstruct the complete game scene from the reference screenshot with all screen-space and world-space UI removed.
Preserve the existing camera, projection, scene layout, visible buildings, terrain, characters, roads, water, vegetation, materials, lighting and all already-visible scene pixels as closely as possible.
Fill only the scene areas that were hidden by the removed UI/overlays, continuing nearby geometry, texture, lighting and perspective naturally.
Do not redesign, recompose, move existing scene objects, add new focal content, or convert UI into scene decoration.
```

正式结果必须再 source-preserving patch。

## 2. Complete UI Control

```text
Reconstruct only [CONTROL] from the reference screenshot as one complete standalone UI control on transparent background.
Preserve its original on-screen position, scale, silhouette, iconography, material, bevel, shadow/glow and visual hierarchy.
Include [CONTROL-INTERNAL ELEMENTS THAT BELONG TO THIS CONTROL].
Exclude the game scene, neighboring controls, unrelated overlays and modules.
Do not recenter, redesign, modernize, simplify, add extra controls or invent unseen states.
```

## 3. Text Strip-and-fill

```text
Text is not the fidelity target in this asset.
Remove ordinary label/counter/message text from the control and naturally reconstruct the underlying UI material/plate where the text was.
Preserve icons, borders, badges, panel materials, lighting and spacing structure.
Do not replace the removed text with invented or garbled text.
```

## 4. Preserve Visual Text

用于 LOGO、品牌字、KVK 等图形式文字：

```text
Preserve the existing visual mark exactly as seen. Do not rewrite, translate or substitute the glyph/logo form.
```

最终如能 Source Lock，优先回填源像素。

## 5. World UI

```text
Isolate only [WORLD-SPACE INDICATOR/BUBBLE] as a standalone transparent asset.
Preserve original shape, icon, glow, perspective, scale and relative visual construction.
Exclude the scene object underneath and every other UI module.
```

## 6. UI Base Reconstruction

```text
Reconstruct only the complete base panel/background for [MODULE].
Remove child controls/text/icons that sit on top of it and fill the hidden base material continuously so this base can exist independently.
Preserve original dimensions, corners, material, border, shadow and perspective.
Transparent outside the base silhouette.
```
