#!/usr/bin/env python3
"""Minimal request state, revision, and delivery promotion for a Codex project Workspace."""

from __future__ import annotations
import os as _bytecode_guard_os, sys as _bytecode_guard_sys
_bytecode_guard_sys.dont_write_bytecode = True
_bytecode_guard_os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unicodedata
from datetime import datetime
from pathlib import Path
from typing import Any

AGENTS_ROOT = Path(__file__).resolve().parents[3]
if str(AGENTS_ROOT / "lib") not in sys.path:
    sys.path.insert(0, str(AGENTS_ROOT / "lib"))
from text_integrity import TextIntegrityError, read_utf8, validate_tree
from atomic_io import atomic_write_text
from request_routing import PRIMARY_SKILLS, REQUEST_ROUTES, RoutingError, validate_primary
from production_contract import production_branch, request_input_files, workspace_relative
from visual_contracts import (
    VisualContractError, load_json as load_visual_json, validate_baseline_consumption,
    validate_prompt_binding, validate_visual_gate_result, validate_visual_spec,
)

HTML_DELIVERY_SKILLS = {
    "sicza-game-concept-lab",
    "wxian-visual-packaging",
    "wxian-visual-competitive-analysis",
    "wxian-conducting-internet-research",
}
PROMPT_ONLY_AUTH_SCHEMA = "sicza.prompt-only-authorization.v1"
VALID_STATUS = {"active", "blocked", "completed"}
MUTABLE_STATUS = {"active", "blocked"}
INTERNAL_COMPLETION_SKILLS = {"wxian-visual-baselines"}
VISUAL_SPEC_IMAGE_BRANCHES = {"new-generation", "image-edit", "video", "visual-brief-only", "prompt-only", "prompt-review-only"}
PROMPT_BINDING_IMAGE_BRANCHES = {"new-generation", "image-edit", "video", "prompt-only", "prompt-review-only"}
VISUAL_GATE_IMAGE_BRANCHES = {"new-generation", "image-edit", "video"}
STATE_FIELDS = {"primary_skill", "status", "revision"}
LEGACY_STATE_FIELDS = STATE_FIELDS | {"next_action"}
REQUEST_SEGMENT_RE = re.compile(r"^[a-z0-9]+(?:-[a-z0-9]+)*$")


def python_subprocess_env() -> dict[str, str]:
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return env
USER_REQUEST_NAME_RE = re.compile(r"^【(?P<date>[0-9]{8})】(?P<sequence>[0-9]{2,})-(?P<label>[^-]+)-(?P<title>.+)$")
USER_REQUEST_PREFIX_RE = re.compile(r"^【(?P<date>[0-9]{8})】(?P<sequence>[0-9]{2,})-")
DEFAULT_DEMAND_LABELS = {
    "visual-packaging": "视觉包装",
    "visual-competitive-analysis": "视觉竞品分析",
    "game-concept-lab": "玩法画风测试",
    "image-generation": "生图",
    "image-edit": "改图",
    "video-production": "视频",
    "resize": "尺寸适配",
    "localization": "本地化",
    "composite": "合成",
    "postprocess": "后处理",
    "visual-brief": "视觉需求文档",
    "prompt-writing": "提示词",
    "prompt-review": "提示词审核",
    "image-layer-decomposition": "KV拆层",
    "game-ui-layer-decomposition": "UI拆层",
    "visual-reverse-analysis": "视觉反推",
    "video-source-analysis": "视频分析",
    "visual-scorecard": "视觉评分",
    "kv-micro-animation": "KV微动画",
    "internet-research": "互联网调研",
}
DELIVERY_ROLE_RE = re.compile(r"^[a-z][a-z0-9]*(?:_[a-z0-9]+)*$")
DELIVERY_LOCALE_RE = re.compile(r"^(?:und|[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*)$")
DELIVERY_SIZE_RE = re.compile(r"^[1-9][0-9]{0,4}x[1-9][0-9]{0,4}$")
WINDOWS_RESERVED_STEMS = {"con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)), *(f"lpt{i}" for i in range(1, 10))}


class GateError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise GateError(message)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def bounded_path(root: Path, value: str | Path, *, must_exist: bool = False) -> Path:
    candidate = Path(value)
    if not candidate.is_absolute():
        candidate = root / candidate
    resolved = candidate.resolve()
    require(resolved == root or root in resolved.parents, f"path escapes Workspace: {value}")
    if must_exist:
        require(resolved.exists(), f"path does not exist: {value}")
    return resolved


def relative(root: Path, path: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def portable_machine_segment(value: str, pattern: re.Pattern[str], *, label: str) -> str:
    require(1 <= len(value) <= 64, f"{label} must be 1-64 characters")
    require(pattern.fullmatch(value) is not None, f"invalid {label} naming")
    require(value.casefold() not in WINDOWS_RESERVED_STEMS, f"{label} is not portable across supported filesystems")
    return value


def normalize_demand_label(value: str) -> str:
    text = unicodedata.normalize("NFKC", value or "").strip()
    text = re.sub(r"[\s\-/:\\|?*<>\"]+", "_", text)
    text = re.sub(r"_+", "_", text).strip("._")
    require(bool(text), "demand label must not be empty")
    require(len(text) <= 24, "demand label must be <= 24 characters")
    return text.upper()


def normalize_demand_title(value: str) -> str:
    text = unicodedata.normalize("NFKC", value or "").strip()
    text = re.sub(r"[<>:\"/\\|?*\x00-\x1f]+", "-", text)
    text = re.sub(r"\s+", "-", text)
    text = re.sub(r"-+", "-", text).strip(" .-_")
    require(bool(text), "demand title must not be empty")
    if len(text) > 48:
        text = text[:48].rstrip(" .-_")
    require(bool(text), "demand title became empty after portable filename normalization")
    return text


def parse_user_request_name(name: str) -> dict[str, Any] | None:
    match = USER_REQUEST_NAME_RE.fullmatch(name)
    if not match:
        return None
    date_value = match.group("date")
    try:
        datetime.strptime(date_value, "%Y%m%d")
    except ValueError as exc:
        raise GateError("request folder date must be valid YYYYMMDD") from exc
    sequence = int(match.group("sequence"))
    require(sequence >= 1, "request sequence must be >= 01")
    label = match.group("label")
    title = match.group("title")
    require(label == normalize_demand_label(label), "request demand label is not normalized")
    require(title == normalize_demand_title(title), "request demand title is not normalized")
    return {"date": date_value, "sequence": sequence, "label": label, "title": title}


def request_path(root: Path, value: str | Path, *, must_exist: bool = True) -> Path:
    request = bounded_path(root, value, must_exist=must_exist)
    parts = request.relative_to(root).parts
    require(len(parts) == 3 and parts[0] == "requests", "request must be requests/<type>/<name>")
    request_type, request_name = parts[1], parts[2]
    portable_machine_segment(request_type, REQUEST_SEGMENT_RE, label="request type (lowercase kebab-case)")
    canonical_internal = (request_type, request_name) == ("baseline", "project-visual-baseline")
    modern_user_name = parse_user_request_name(request_name)
    legacy_user_name = REQUEST_SEGMENT_RE.fullmatch(request_name) is not None
    if not canonical_internal and modern_user_name is None:
        require(must_exist and legacy_user_name,
                "new user request folder must use 【YYYYMMDD】NN-需求类型-需求标题; legacy kebab-case names are read-only compatibility")
    if must_exist:
        require(request.is_dir(), f"request is not a directory: {value}")
    return request


def request_local_date(request: Path) -> str | None:
    try:
        stat = request.stat()
        timestamp = getattr(stat, "st_birthtime", None)
        if timestamp is None:
            timestamp = stat.st_ctime if sys.platform.startswith("win") else stat.st_mtime
        return datetime.fromtimestamp(timestamp).astimezone().strftime("%Y%m%d")
    except OSError:
        return None


def next_daily_sequence(root: Path, date_value: str) -> int:
    highest = 0
    same_day_count = 0
    requests_root = root / "requests"
    if requests_root.is_dir():
        for request in requests_root.glob("*/*"):
            if not request.is_dir() or request.relative_to(root).parts[1:] == ("baseline", "project-visual-baseline"):
                continue
            match = USER_REQUEST_PREFIX_RE.match(request.name)
            if match and match.group("date") == date_value:
                highest = max(highest, int(match.group("sequence")))
                same_day_count += 1
            elif request_local_date(request) == date_value:
                # Legacy folders have no date/sequence in the name. Count same-day legacy
                # requests so the first modern request after an upgrade does not restart at 01.
                same_day_count += 1
    return max(highest, same_day_count) + 1


def allocate_user_request(root: Path, request_type: str, demand_label: str | None, demand_title: str) -> Path:
    portable_machine_segment(request_type, REQUEST_SEGMENT_RE, label="request type (lowercase kebab-case)")
    require(request_type in REQUEST_ROUTES and request_type != "baseline", "user request_type is unsupported or internal-only")
    label = normalize_demand_label(demand_label or DEFAULT_DEMAND_LABELS.get(request_type, request_type))
    title = normalize_demand_title(demand_title)
    date_value = datetime.now().astimezone().strftime("%Y%m%d")
    parent = root / "requests" / request_type
    parent.mkdir(parents=True, exist_ok=True)
    sequence = next_daily_sequence(root, date_value)
    for _ in range(1000):
        name = f"【{date_value}】{sequence:02d}-{label}-{title}"
        request = parent / name
        try:
            request.mkdir()
            return request
        except FileExistsError:
            sequence += 1
    raise GateError("unable to allocate a unique daily request sequence")


def load_json(path: Path) -> dict[str, Any]:
    require(path.is_file(), f"JSON file not found: {path}")
    try:
        value = json.loads(read_utf8(path))
    except (json.JSONDecodeError, TextIntegrityError) as exc:
        raise GateError(f"invalid or corrupted JSON: {path}: {exc}") from exc
    require(isinstance(value, dict), f"JSON root must be an object: {path}")
    return value

def validate_request_text_integrity(request: Path) -> dict[str, int]:
    checked=0
    for path in (request/"request.md", request/"state.json"):
        if path.is_file():
            read_utf8(path); checked+=1
    for folder in (request/"work", request/"output"):
        if folder.is_dir():
            result=validate_tree(folder, suffixes={".md", ".json", ".txt", ".yaml", ".yml", ".csv"})
            checked+=result["checked_text_files"]
    return {"checked_text_files":checked}


def write_json(path: Path, value: dict[str, Any]) -> None:
    atomic_write_text(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def state_path(request: Path) -> Path:
    return request / "state.json"


def current_path(root: Path) -> Path:
    return root / "requests" / ".current.json"


def last_delivered_path(root: Path) -> Path:
    return root / "requests" / ".last-delivered.json"


def validate_promoted_completion(root: Path, request: Path, state: dict[str, Any]) -> None:
    manifest_path = request / "output" / "manifest.json"
    manifest = load_json(manifest_path)
    require(set(manifest) == {"active_revision", "final_review_sha256", "files"},
            "completed user request has invalid output/manifest.json")
    require(manifest["active_revision"] == state["revision"],
            "completed user request revision does not match promoted output")
    review = request / "work" / "final-review.md"
    require(review.is_file() and sha256_file(review) == manifest["final_review_sha256"],
            "completed user request final review is missing or stale")
    files = manifest["files"]
    require(isinstance(files, list) and files, "completed user request has no promoted files")
    revision_dir = (request / "output" / "revisions" / f"r{state['revision']:03d}").resolve()
    for index, item in enumerate(files):
        require(isinstance(item, dict) and {"path", "sha256", "role", "locale", "size"} <= set(item),
                f"completed output files[{index}] is invalid")
        path = bounded_path(root, str(item["path"]), must_exist=True)
        require(path.is_file() and path.stat().st_size > 0, f"completed output is missing: {item['path']}")
        require(revision_dir in path.parents, f"completed output is outside active revision: {item['path']}")
        require(sha256_file(path) == str(item["sha256"]), f"completed output hash mismatch: {item['path']}")


def validate_state(request: Path) -> dict[str, Any]:
    root = request.resolve().parents[2]
    state = load_json(state_path(request))
    fields = set(state)
    require(frozenset(fields) in {frozenset(STATE_FIELDS), frozenset(LEGACY_STATE_FIELDS)},
            "state.json contains missing or unnecessary fields")
    require(state["primary_skill"] in PRIMARY_SKILLS, "invalid primary_skill")
    request_type = request.relative_to(root).parts[1]
    try:
        validate_primary(request_type, state["primary_skill"])
    except RoutingError as exc:
        raise GateError(str(exc)) from exc
    require(state["status"] in VALID_STATUS, "invalid request status")
    require(isinstance(state["revision"], int) and state["revision"] >= 1, "revision must be >= 1")
    require((request / "request.md").is_file(), "request.md is missing")
    for name in ("input", "work", "output"):
        require((request / name).is_dir(), f"request {name}/ is missing")
    if state["status"] == "completed":
        if state["primary_skill"] in INTERNAL_COMPLETION_SKILLS:
            parts = request.relative_to(root).parts
            require(parts[1:] == ("baseline", "project-visual-baseline"),
                    "internal completed request must be the canonical project Baseline request")
        else:
            validate_promoted_completion(root, request, state)
    return {key: state[key] for key in ("primary_skill", "status", "revision")}


def set_current(root: Path, request: Path) -> None:
    write_json(current_path(root), {"request": relative(root, request)})


def set_last_delivered(root: Path, request: Path) -> None:
    write_json(last_delivered_path(root), {"request": relative(root, request)})


def personal_layer_enabled(root: Path) -> tuple[bool, str | None]:
    """Read the explicit opt-in without making Personal Layer a public-chain dependency."""
    manifest = root / "user" / "manifest.json"
    if not manifest.is_file():
        return False, None
    try:
        value = json.loads(manifest.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return False, f"user manifest could not be read: {exc}"
    if not isinstance(value, dict):
        return False, "user manifest must be an object"
    enabled = value.get("enabled", False)
    if not isinstance(enabled, bool):
        return False, "user manifest enabled must be a boolean"
    return enabled, None


def clear_personal_layer_artifacts(request: Path) -> None:
    for name in ("personal-context.json", "personal-execution.json", "personal-layer-error.json"):
        path = request / "work" / name
        if path.exists():
            path.unlink()


def record_personal_layer_error(request: Path, reason: str) -> dict[str, Any]:
    context = request / "work" / "personal-context.json"
    if context.exists():
        context.unlink()
    execution = request / "work" / "personal-execution.json"
    if execution.exists():
        execution.unlink()
    result = {
        "status": "degraded",
        "fallback": "default-environment",
        "reason": reason,
    }
    write_json(request / "work" / "personal-layer-error.json", result)
    return result


def resolve_personal_context_sources(root: Path, request: Path) -> dict[str, Any]:
    """Resolve the current authoritative preferences and Personal Skill bindings."""
    request_type = request.relative_to(root).parts[1]
    state = load_json(state_path(request))
    primary_skill = str(state.get("primary_skill") or "")

    skill_script = root / ".agents" / "skills" / "workspace-personal-skill" / "scripts" / "personal_skill.py"
    require(skill_script.is_file(), "workspace-personal-skill resolver is missing")
    skill_cp = subprocess.run(
        [sys.executable, str(skill_script), "resolve", "--request-type", request_type,
         "--workspace-root", str(root)],
        check=False, capture_output=True, text=True, encoding="utf-8", timeout=90,
        env=python_subprocess_env(),
    )
    try:
        skill_result = json.loads(skill_cp.stdout)
    except json.JSONDecodeError as exc:
        raise GateError("personal-skill resolver returned invalid output") from exc
    require(skill_cp.returncode == 0 and isinstance(skill_result, dict) and skill_result.get("status") == "ready",
            f"personal-skill resolver failed: {skill_result.get('reason', skill_cp.stderr.strip() or 'unknown error') if isinstance(skill_result, dict) else 'unknown error'}")
    preference_scope = {
        "wxian-image-production": "image-production",
        "wxian-visual-packaging": "visual-packaging",
        "wxian-visual-reverse-analysis": "reverse-analysis",
        "wxian-visual-scorecard": "scorecard",
    }.get(primary_skill, "global")
    feedback_script = root / ".agents" / "skills" / "workspace-user-feedback" / "scripts" / "user_feedback.py"
    require(feedback_script.is_file(), "workspace-user-feedback preference resolver is missing")
    pref_cp = subprocess.run(
        [sys.executable, str(feedback_script), "get-preferences", "--scope", preference_scope,
         "--workspace-root", str(root)],
        check=False, capture_output=True, text=True, encoding="utf-8", timeout=90,
        env=python_subprocess_env(),
    )
    try:
        pref_result = json.loads(pref_cp.stdout)
    except json.JSONDecodeError as exc:
        raise GateError("preference resolver returned invalid output") from exc
    require(pref_cp.returncode == 0 and isinstance(pref_result, dict) and pref_result.get("status") == "ready",
            f"preference resolver failed: {pref_result.get('reason', pref_cp.stderr.strip() or 'unknown error') if isinstance(pref_result, dict) else 'unknown error'}")

    result = {
        "status": "ready",
        "execution_status": "resolved",
        "execution_binding": None,
        "request_type": request_type,
        "preference_scope": preference_scope,
        "preferences": pref_result.get("preferences", []),
        "preferences_sha256": sha256_file(root / "user" / "preferences.md"),
        "manifest": skill_result.get("manifest"),
        "manifest_sha256": skill_result.get("manifest_sha256"),
        "personal_skills": skill_result.get("personal_skills", []),
        "load_paths": skill_result.get("load_paths", []),
    }
    return result


def refresh_personal_context(root: Path, request: Path, resolved: dict[str, Any] | None = None) -> dict[str, Any]:
    """Write the current portable preferences + Personal Skill bindings for the request."""
    result = resolved if resolved is not None else resolve_personal_context_sources(root, request)
    context_path = request / "work" / "personal-context.json"
    write_json(context_path, result)
    error_path = request / "work" / "personal-layer-error.json"
    if error_path.exists():
        error_path.unlink()
    return result


PERSONAL_CONTEXT_SOURCE_FIELDS = (
    "status", "request_type", "preference_scope", "preferences", "preferences_sha256",
    "manifest", "manifest_sha256", "personal_skills", "load_paths",
)


def personal_context_matches_sources(context: dict[str, Any], expected: dict[str, Any], primary_skill: str) -> bool:
    if context.get("execution_status") not in {"resolved", "loaded"}:
        return False
    if context.get("execution_status") == "loaded" and context.get("execution_binding") != primary_skill:
        return False
    if context.get("execution_status") == "resolved" and context.get("execution_binding") is not None:
        return False
    return all(context.get(field) == expected.get(field) for field in PERSONAL_CONTEXT_SOURCE_FIELDS)


def consume_personal_context(root: Path, request_value: str, consumer: str) -> dict[str, Any]:
    request = request_path(root, request_value)
    state = validate_state(request)
    require(consumer == state["primary_skill"],
            f"Personal Context consumer must be current primary_skill={state['primary_skill']}")
    enabled, reason = personal_layer_enabled(root)
    require(reason is None, reason or "Personal Layer manifest is invalid")
    if not enabled:
        return {"status": "skipped", "reason": "personal-layer-disabled", "request": relative(root, request)}
    context_path = request / "work" / "personal-context.json"
    require(context_path.is_file(), "enabled Personal Layer requires resolved personal-context.json")
    context = load_json(context_path)
    expected_context = resolve_personal_context_sources(root, request)
    require(personal_context_matches_sources(context, expected_context, state["primary_skill"]),
            "Personal Context does not match current preferences and matched Personal Skills")
    manifest = root / "user" / "manifest.json"
    require(manifest.is_file() and context.get("manifest_sha256") == sha256_file(manifest),
            "Personal Context manifest hash is stale")
    preferences_path = root / "user" / "preferences.md"
    require(preferences_path.is_file() and context.get("preferences_sha256") == sha256_file(preferences_path),
            "Personal Context preferences hash is stale")
    for item in context.get("personal_skills", []):
        require(isinstance(item, dict) and item.get("path") and item.get("sha256"),
                "Personal Skill execution evidence is incomplete")
        skill_path = bounded_path(root, str(item["path"]), must_exist=True)
        require(sha256_file(skill_path) == item["sha256"], f"Personal Skill changed after resolution: {item['path']}")
    context["execution_status"] = "loaded"
    context["execution_binding"] = state["primary_skill"]
    write_json(context_path, context)
    receipt = {
        "status": "consumed",
        "request": relative(root, request),
        "revision": state["revision"],
        "consumer": state["primary_skill"],
        "consumer_source": "explicit-command-argument",
        "context_sha256": sha256_file(context_path),
        "manifest_sha256": context["manifest_sha256"],
        "preference_count": len(context.get("preferences", [])),
        "skill_sha256": [item["sha256"] for item in context.get("personal_skills", [])],
    }
    receipt_path = request / "work" / "personal-execution.json"
    write_json(receipt_path, receipt)
    return {"status": "loaded", "request": relative(root, request), "consumer": state["primary_skill"],
            "preferences": context.get("preferences", []), "load_paths": context.get("load_paths", []),
            "execution_receipt": relative(root, receipt_path)}


def validate_personal_execution(root: Path, request: Path, primary_skill: str) -> dict[str, Any] | None:
    enabled, reason = personal_layer_enabled(root)
    require(reason is None, reason or "Personal Layer manifest is invalid")
    if not enabled:
        return None
    context_path = request / "work" / "personal-context.json"
    receipt_path = request / "work" / "personal-execution.json"
    require(context_path.is_file(), "enabled Personal Layer requires work/personal-context.json")
    require(receipt_path.is_file(), "enabled Personal Layer requires work/personal-execution.json")
    context = load_json(context_path)
    receipt = load_json(receipt_path)
    require(context.get("status") == "ready" and context.get("execution_status") == "loaded",
            "Personal Context is not loaded")
    state = validate_state(request)
    require(receipt.get("status") == "consumed" and receipt.get("consumer") == primary_skill,
            "Personal execution receipt is not bound to current primary_skill")
    require(receipt.get("consumer_source") == "explicit-command-argument",
            "Personal execution receipt was not issued by an explicit Primary Skill consumer call")
    require(context.get("execution_binding") == primary_skill,
            "Personal Context execution binding does not match current primary_skill")
    manifest = root / "user" / "manifest.json"
    require(manifest.is_file() and receipt.get("manifest_sha256") == sha256_file(manifest),
            "Personal execution receipt does not match current user manifest")
    expected_context = resolve_personal_context_sources(root, request)
    require(personal_context_matches_sources(context, expected_context, primary_skill),
            "Personal Context does not match current preferences and matched Personal Skills")
    require(receipt.get("request") == relative(root, request) and receipt.get("revision") == state["revision"],
            "Personal execution receipt is not bound to current request revision")
    require(receipt.get("context_sha256") == sha256_file(context_path),
            "Personal execution receipt context hash is stale")
    require(receipt.get("manifest_sha256") == context.get("manifest_sha256"),
            "Personal execution receipt manifest hash is stale")
    preferences_path = root / "user" / "preferences.md"
    require(preferences_path.is_file() and context.get("preferences_sha256") == sha256_file(preferences_path),
            "Personal Context preferences hash is stale")
    for item in context.get("personal_skills", []):
        require(isinstance(item, dict) and item.get("path") and item.get("sha256"),
                "Personal Skill execution evidence is incomplete")
        skill_path = bounded_path(root, str(item["path"]), must_exist=True)
        require(sha256_file(skill_path) == item["sha256"], f"Personal Skill changed after consumption: {item['path']}")
    return receipt


def reusable_personal_context(root: Path, request: Path, expected: dict[str, Any]) -> dict[str, Any] | None:
    path = request / "work" / "personal-context.json"
    manifest = root / "user" / "manifest.json"
    preferences = root / "user" / "preferences.md"
    if not (path.is_file() and manifest.is_file() and preferences.is_file()):
        return None
    try:
        context = load_json(path)
        state = validate_state(request)
        if not personal_context_matches_sources(context, expected, state["primary_skill"]):
            return None
        return context
    except (GateError, OSError, json.JSONDecodeError, ValueError):
        return None


def maybe_refresh_personal_context(root: Path, request: Path) -> dict[str, Any] | None:
    enabled, reason = personal_layer_enabled(root)
    if not enabled:
        clear_personal_layer_artifacts(request)
        if reason:
            record_personal_layer_error(request, reason)
        return None
    try:
        expected = resolve_personal_context_sources(root, request)
        cached = reusable_personal_context(root, request, expected)
        if cached is not None:
            return cached
        return refresh_personal_context(root, request, expected)
    except (GateError, OSError, subprocess.SubprocessError, json.JSONDecodeError, ValueError) as exc:
        record_personal_layer_error(request, str(exc))
        raise GateError(f"Personal Layer is enabled but could not be loaded: {exc}") from exc


def attach_personal_context(result: dict[str, Any], personal_context: dict[str, Any] | None) -> dict[str, Any]:
    if personal_context is not None:
        result["personal_context"] = personal_context
    return result


def enforce_visual_preflight(root: Path, primary_skill: str, *, request: Path | None = None,
                             request_type: str | None = None) -> dict[str, Any] | None:
    """Hard-stop Baseline-consuming visual work when same-session project/reference changes made the Baseline stale."""
    route_type = request_type or (request.relative_to(root).parts[1] if request is not None else None)
    registry_path = root / ".agents" / "skills" / "workspace-governance" / "config" / "visual-contracts" / "visual-enforcement-profiles.json"
    registry = load_visual_json(registry_path)
    entry = registry.get("profiles", {}).get(primary_skill)
    if entry is None:
        return None
    require(isinstance(entry, dict), f"visual enforcement profile missing for {primary_skill}")
    if "branches" in entry:
        route = REQUEST_ROUTES.get(str(route_type), {})
        branch = route.get("production_branch")
        profile = entry.get("branches", {}).get(branch)
        require(isinstance(profile, dict), f"visual enforcement profile missing for {primary_skill}:{branch}")
    else:
        profile = entry.get("default")
        require(isinstance(profile, dict), f"visual enforcement default profile missing for {primary_skill}")
    baseline_policy = str(profile.get("baseline", "none"))
    if baseline_policy in {"none", "diagnostic-advisory", "authority-owner"}:
        return None
    if baseline_policy == "optional":
        receipt = request / "work" / "baseline-consumption.json" if request is not None else None
        if receipt is None or not receipt.is_file():
            return None
    if baseline_policy == "if_reconstructed" and (request is None or not request_has_reconstructed_layers(request)):
        return None
    script = root / ".agents" / "scripts" / "workspace_init.py"
    require(script.is_file(), "workspace visual preflight script is missing")
    cp = subprocess.run(
        [sys.executable, str(script), "visual-check", "--workspace-root", str(root)],
        check=False, capture_output=True, text=True, encoding="utf-8", timeout=90,
        env=python_subprocess_env(),
    )
    try:
        result = json.loads(cp.stdout)
    except json.JSONDecodeError as exc:
        raise GateError("workspace visual preflight returned invalid output") from exc
    require(isinstance(result, dict), "workspace visual preflight returned invalid payload")
    if result.get("status") != "ready":
        status = str(result.get("status", "blocked"))
        reason = str(result.get("reason", "visual Baseline is not current"))
        baseline_request = result.get("baseline_request")
        suffix = f"; baseline_request={baseline_request}" if baseline_request else ""
        raise GateError(f"visual preflight blocked request: {status}: {reason}{suffix}")
    return result


def init_request(root: Path, request_value: str | None, request_type_value: str | None, primary_skill: str,
                 request_text: str, demand_label: str | None = None, demand_title: str | None = None) -> dict[str, Any]:
    require(primary_skill in PRIMARY_SKILLS, f"unsupported primary_skill: {primary_skill}")
    require(request_text.strip(), "request_text must not be empty")

    if request_value is not None:
        request = bounded_path(root, request_value, must_exist=False)
        parts = request.relative_to(root).parts
        require(parts == ("requests", "baseline", "project-visual-baseline"),
                "explicit --request is reserved for the canonical internal Baseline; user requests must use automatic naming")
        request_type = "baseline"
        request = request_path(root, request_value, must_exist=False)
        require(not request.exists(), f"request already exists: {relative(root, request)}")
    else:
        require(bool(request_type_value), "user request requires --request-type")
        request_type = str(request_type_value)
        require(bool(demand_title and demand_title.strip()), "user request requires --demand-title")

    try:
        validate_primary(request_type, primary_skill)
    except RoutingError as exc:
        raise GateError(str(exc)) from exc
    enforce_visual_preflight(root, primary_skill, request_type=request_type)

    auto_allocated = request_value is None
    if auto_allocated:
        request = allocate_user_request(root, request_type, demand_label, str(demand_title))
    else:
        request.mkdir(parents=True)

    try:
        (request / "input").mkdir()
        (request / "work").mkdir()
        (request / "output").mkdir()
        (request / "request.md").write_text(request_text.strip() + "\n", encoding="utf-8")
        state = {
            "primary_skill": primary_skill,
            "status": "active",
            "revision": 1,
        }
        write_json(state_path(request), state)
        set_current(root, request)
        personal_context = maybe_refresh_personal_context(root, request)
        result = attach_personal_context(
            {"status": "ready", "request": relative(root, request), "state": state},
            personal_context,
        )
        if auto_allocated:
            parsed = parse_user_request_name(request.name) or {}
            result["folder_name"] = request.name
            result["daily_sequence"] = parsed.get("sequence")
        return result
    except Exception:
        if auto_allocated and request.exists():
            shutil.rmtree(request, ignore_errors=True)
        raise


def set_state(root: Path, request_value: str, status: str | None) -> dict[str, Any]:
    request = request_path(root, request_value)
    state = validate_state(request)
    if status is not None:
        require(status in MUTABLE_STATUS,
                "set-state only allows active|blocked; use promote for user deliverables or complete-internal for Baseline")
        require(state["status"] != "completed",
                "completed request can only reopen through revise-request or register-supplement")
        state["status"] = status
    write_json(state_path(request), state)
    set_current(root, request)
    return {"status": "ready", "request": relative(root, request), "state": state}


def complete_internal(root: Path, request_value: str) -> dict[str, Any]:
    request = request_path(root, request_value)
    state = validate_state(request)
    require(state["status"] == "active", "only active internal request can be completed")
    require(state["primary_skill"] in INTERNAL_COMPLETION_SKILLS,
            "complete-internal is only valid for registered internal primary skills")
    parts = request.relative_to(root).parts
    require(parts[1:] == ("baseline", "project-visual-baseline"),
            "complete-internal is only valid for requests/baseline/project-visual-baseline")
    validate_personal_execution(root, request, state["primary_skill"])
    gate = root / ".agents" / "skills" / "wxian-visual-baselines" / "scripts" / "baseline_gate.py"
    require(gate.is_file(), "Baseline validation gate is missing")
    cp = subprocess.run(
        [sys.executable, str(gate), "validate-published", "--request", relative(root, request),
         "--workspace-root", str(root)],
        check=False, capture_output=True, text=True, encoding="utf-8", timeout=120,
        env=python_subprocess_env(),
    )
    try:
        validation = json.loads(cp.stdout)
    except json.JSONDecodeError as exc:
        raise GateError("Baseline validation gate returned invalid output") from exc
    require(cp.returncode == 0 and isinstance(validation, dict) and validation.get("status") == "passed",
            f"internal completion blocked: {validation.get('reason', cp.stderr.strip() or 'published Baseline is invalid') if isinstance(validation, dict) else 'published Baseline is invalid'}")
    validate_request_text_integrity(request)
    state["status"] = "completed"
    write_json(state_path(request), state)
    set_current(root, request)
    return {"status": "completed", "request": relative(root, request), "revision": state["revision"],
            "internal": True, "validation": validation}


def revise_request(root: Path, request_value: str) -> dict[str, Any]:
    request = request_path(root, request_value)
    state = validate_state(request)
    enforce_visual_preflight(root, state["primary_skill"], request=request)
    require(state["status"] in {"completed", "blocked", "active"}, "request cannot be revised")
    state["revision"] += 1
    state["status"] = "active"
    work = request / "work"
    for name in ("delivery-manifest.json", "final-review.md"):
        path = work / name
        if path.exists():
            path.unlink()
    write_json(state_path(request), state)
    set_current(root, request)
    personal_context = maybe_refresh_personal_context(root, request)
    return attach_personal_context(
        {"status": "ready", "request": relative(root, request), "revision": state["revision"]},
        personal_context,
    )



def sync_image_source_lock(root: Path, request: Path, primary_skill: str) -> None:
    if primary_skill != "wxian-image-production":
        return
    sources = [workspace_relative(root, path) for path in request_input_files(request)]
    lock = request / "work" / "source-lock.json"
    if not sources:
        if lock.exists():
            lock.unlink()
        return
    write_json(lock, {"required_sources": sources})


def register_supplement(root: Path, request_value: str, input_value: str, note: str | None) -> dict[str, Any]:
    request = request_path(root, request_value)
    state = validate_state(request)
    source = bounded_path(root, input_value, must_exist=True)
    require(source.is_file() and request / "input" in source.parents,
            "supplemental input must already exist inside this request input/")
    if state["status"] == "completed":
        state["revision"] += 1
        for name in ("delivery-manifest.json", "final-review.md"):
            path = request / "work" / name
            if path.exists(): path.unlink()
    state["status"] = "active"
    sync_image_source_lock(root, request, state["primary_skill"])
    if note and note.strip():
        request_md = request / "request.md"
        with request_md.open("a", encoding="utf-8") as handle:
            handle.write("\n补充：" + note.strip() + "\n")
    write_json(state_path(request), state)
    set_current(root, request)
    personal_context = maybe_refresh_personal_context(root, request)
    return attach_personal_context(
        {"status":"ready","request":relative(root,request),"input":relative(root,source),
         "revision":state["revision"]},
        personal_context,
    )

def list_active(root: Path) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    requests_root = root / "requests"
    if not requests_root.is_dir():
        return result
    for state_file in sorted(requests_root.glob("*/*/state.json")):
        request = state_file.parent
        try:
            state = validate_state(request)
        except (GateError, OSError, json.JSONDecodeError):
            continue
        if state["status"] == "completed":
            continue
        request_text = (request / "request.md").read_text(encoding="utf-8").strip()
        result.append({
            "request": relative(root, request),
            "name": request.name,
            "primary_skill": state["primary_skill"],
            "status": state["status"],
            "revision": state["revision"],
            "summary": request_text.splitlines()[0][:120],
        })
    return result


def resolve_request(root: Path) -> dict[str, Any]:
    current = current_path(root)
    if current.is_file():
        request = None
        try:
            value = load_json(current)
            request = request_path(root, str(value.get("request", "")))
        except (GateError, OSError, json.JSONDecodeError):
            request = None
        if request is not None:
            state = validate_state(request)
            if state["status"] != "completed":
                # Preflight failures are real business blocks; do not swallow them as stale .current metadata.
                enforce_visual_preflight(root, state["primary_skill"], request=request)
                personal_context = maybe_refresh_personal_context(root, request)
                return attach_personal_context(
                    {"status": "resolved", "request": relative(root, request), "state": state},
                    personal_context,
                )
    active = list_active(root)
    if len(active) == 1:
        request = request_path(root, active[0]["request"])
        enforce_visual_preflight(root, active[0]["primary_skill"], request=request)
        set_current(root, request)
        personal_context = maybe_refresh_personal_context(root, request)
        return attach_personal_context({"status": "resolved", **active[0]}, personal_context)
    if not active:
        return {"status": "none", "message": "no unfinished request"}
    # Names/summaries are intentionally returned so the agent can ask in business language.
    return {"status": "ambiguous", "choices": [
        {k: item[k] for k in ("name", "summary", "primary_skill", "status", "revision")}
        for item in active
    ]}


def resolve_latest(root: Path) -> dict[str, Any]:
    # "latest" means the most recently promoted user deliverable, not merely
    # whichever request was opened last. This keeps "上一张/刚交付那张" stable
    # even after a new request has already been created. Legacy fallback to
    # .current is allowed only when that request has a real promoted output
    # manifest; internal Baseline/setup requests are never user deliverables.
    pointer = last_delivered_path(root)
    fallback_current = False
    if not pointer.is_file():
        pointer = current_path(root)
        fallback_current = True
    if not pointer.is_file():
        return {"status": "none", "message": "no recent delivered request"}
    try:
        value = load_json(pointer)
        request = request_path(root, str(value.get("request", "")))
    except (GateError, OSError, json.JSONDecodeError):
        return {"status": "none", "message": "no valid recent delivered request"}
    try:
        state = validate_state(request)
    except (GateError, OSError, json.JSONDecodeError) as exc:
        return {"status": "blocked", "reason": f"recent delivered request is invalid: {exc}"}
    if fallback_current and not (request / "output" / "manifest.json").is_file():
        return {"status": "none", "message": "no recent delivered request"}
    text = (request / "request.md").read_text(encoding="utf-8").strip()
    return {"status": "resolved", "request": relative(root, request), "name": request.name,
            "summary": text.splitlines()[0][:120], "state": state,
            "revision_required": state["status"] == "completed"}


def validate_delivery_manifest(root: Path, request: Path, manifest_path: Path) -> list[dict[str, Any]]:
    manifest = load_json(manifest_path)
    require(set(manifest) == {"files"}, "delivery manifest must contain only files")
    raw_files = manifest["files"]
    require(isinstance(raw_files, list) and raw_files, "delivery manifest files must be a non-empty array")
    files: list[dict[str, Any]] = []
    active_keys: set[tuple[str, str, str] | tuple[str, str, str, str]] = set()
    allowed = {"role", "source", "sha256", "active", "locale", "size"}
    for index, item in enumerate(raw_files):
        require(isinstance(item, dict) and set(item) <= allowed and {"role", "source", "sha256", "active"} <= set(item),
                f"files[{index}] must contain role/source/sha256/active with optional locale/size")
        role = str(item["role"]).strip()
        locale = str(item.get("locale", "")).strip()
        size = str(item.get("size", "")).strip()
        portable_machine_segment(role, DELIVERY_ROLE_RE, label=f"files[{index}].role (lowercase snake_case)")
        require(not locale or DELIVERY_LOCALE_RE.fullmatch(locale) is not None,
                f"files[{index}].locale must be BCP47-like or und")
        require(not size or DELIVERY_SIZE_RE.fullmatch(size) is not None,
                f"files[{index}].size must be WIDTHxHEIGHT pixels")
        require(isinstance(item["active"], bool), f"files[{index}].active must be boolean")
        source = bounded_path(root, str(item["source"]), must_exist=True)
        require(source.is_file() and source.stat().st_size > 0, f"delivery source is invalid: {item['source']}")
        require(request / "work" == source or request / "work" in source.parents,
                f"delivery source must be inside current request work/: {item['source']}")
        actual_hash = sha256_file(source)
        require(str(item["sha256"]) == actual_hash, f"delivery source sha256 mismatch: {item['source']}")
        key = ((role, locale, size, source.name.casefold()) if role == "generated_original"
               else (role, locale, size))
        if item["active"]:
            require(key not in active_keys, f"duplicate active delivery target: {key}")
            active_keys.add(key)
        files.append({"role": role, "locale": locale, "size": size, "source": relative(root, source),
                      "sha256": actual_hash, "active": item["active"]})
    require(any(item["active"] for item in files), "delivery manifest requires at least one active file")
    return files


def validate_prompt_only_authorization(root: Path, request: Path) -> dict[str, Any]:
    auth_path = request / "work" / "concept-lab" / "prompt-only-authorization.json"
    auth = load_json(auth_path)
    require(set(auth) == {"schema_version", "mode", "request_path", "request_sha256", "user_instruction_excerpt"},
            "prompt-only authorization fields are invalid")
    require(auth.get("schema_version") == PROMPT_ONLY_AUTH_SCHEMA, "prompt-only authorization schema mismatch")
    require(auth.get("mode") == "PROMPT_ONLY", "prompt-only authorization mode mismatch")
    request_source = request / "request.md"
    require(auth.get("request_path") == relative(root, request_source), "prompt-only authorization request_path mismatch")
    require(auth.get("request_sha256") == sha256_file(request_source), "prompt-only authorization request hash mismatch")
    excerpt = auth.get("user_instruction_excerpt")
    require(isinstance(excerpt, str) and excerpt.strip(), "prompt-only authorization excerpt is required")
    request_text = read_utf8(request_source)
    require(excerpt in request_text, "prompt-only authorization excerpt is not verbatim request text")
    normalized = re.sub(r"\s+", "", unicodedata.normalize("NFKC", excerpt).casefold())
    normalized_request = re.sub(r"\s+", "", unicodedata.normalize("NFKC", request_text).casefold())
    explicit_markers = (
        "只要prompt", "仅要prompt", "只需要prompt", "只输出prompt", "仅输出prompt",
        "只要提示词", "仅要提示词", "只需要提示词", "只输出提示词", "仅输出提示词",
        "prompt-only", "promptonly", "promptsonly", "onlyprovideprompts", "onlyoutputprompts",
        "donotgenerateimages", "donotcreateimages", "noimagegeneration",
        "不需要生图", "无需生图", "不要生图", "不生成图片",
    )
    generation_surface = normalized_request
    for skip_marker in ("不需要生图", "无需生图", "不要生图", "不生成图片",
                        "donotgenerateimages", "donotcreateimages", "noimagegeneration"):
        generation_surface = generation_surface.replace(skip_marker, "")
    generation_required_markers = (
        "不要只输出prompt", "不要只输出提示词", "不是只需要prompt", "不是只需要提示词",
        "不只是prompt", "不只是提示词", "必须生图", "需要生图", "要生图", "自动生图",
        "直接生图", "生成图片", "完成全部图片生成", "完成图片生成", "产出图片", "出图",
    )
    generation_required_patterns = (
        r"绘制(?:三|3|\d+)?张?概念图",
        r"(?:create|generate|draw|render|make)(?:three|3|\d+)?conceptimages",
    )
    require(not any(marker in generation_surface for marker in generation_required_markers)
            and not any(re.search(pattern, generation_surface) for pattern in generation_required_patterns),
            "prompt-only authorization conflicts with an explicit image-generation instruction")
    require(any(marker in normalized for marker in explicit_markers),
            "prompt-only authorization excerpt lacks an explicit user request to skip image generation")
    return auth


def enforce_primary_delivery_gate(root: Path, request: Path, state: dict[str, Any], files: list[dict[str, Any]]) -> None:
    gates = {
        "wxian-image-production": ("wxian-image-production/scripts/delivery_gate.py", "image-production"),
        "wxian-video-source-analysis": ("wxian-video-source-analysis/scripts/delivery_gate.py", "video-source-analysis"),
        "sicza-game-concept-lab": ("sicza-game-concept-lab/scripts/portfolio_gate.py", "game-concept-lab"),
        "wxian-image-layer-decomposition": ("wxian-image-layer-decomposition/scripts/delivery_gate.py", "kv-layer-decomposition"),
        "wxian-game-ui-layer-decomposition": ("wxian-game-ui-layer-decomposition/scripts/delivery_gate.py", "game-ui-layer-decomposition"),
    }
    primary = state["primary_skill"]
    if primary in HTML_DELIVERY_SKILLS:
        prompt_only = False
        if primary == "sicza-game-concept-lab":
            blueprint_path = request / "work" / "concept-lab" / "product-blueprint.json"
            if blueprint_path.is_file():
                blueprint = load_json(blueprint_path)
                if blueprint.get("portfolio_output") == "PROMPT_MARKDOWN":
                    validate_prompt_only_authorization(root, request)
                    prompt_only = True
        if not prompt_only:
            html_items = [item for item in files if item.get("active") and item.get("role") == "interactive_html"]
            require(len(html_items) == 1, f"{primary} delivery requires exactly one active interactive_html")
            html_path = bounded_path(root, html_items[0]["source"], must_exist=True)
            report_path = request / "work" / "html-delivery" / "report.json"
            require(report_path.is_file(), f"{primary} delivery requires work/html-delivery/report.json")
            html_gate = root / ".agents" / "skills" / "wxian-html-delivery" / "scripts" / "html_delivery.py"
            require(html_gate.is_file(), "HTML delivery validator is missing")
            cp = subprocess.run(
                [sys.executable, str(html_gate), "validate", "--manifest", relative(root, report_path),
                 "--html", relative(root, html_path), "--workspace-root", str(root)],
                text=True, capture_output=True, encoding="utf-8", errors="replace", timeout=90,
                env=python_subprocess_env(),
            )
            if cp.returncode != 0:
                reason = cp.stdout.strip() or cp.stderr.strip() or "unknown HTML delivery validation failure"
                try:
                    payload = json.loads(cp.stdout)
                    reason = str(payload.get("reason", reason))
                except (json.JSONDecodeError, TypeError):
                    pass
                raise GateError(f"HTML delivery gate blocked promote: {reason}")
            originals = request / "work" / "final" / "originals"
            expected_originals = {
                relative(root, path) for path in originals.rglob("*")
                if path.is_file() and not path.name.endswith(".call.json")
            } if originals.is_dir() else set()
            active_originals = {
                item["source"] for item in files
                if item.get("active") and item.get("role") == "generated_original"
            }
            require(active_originals == expected_originals,
                    f"active generated_original files differ from work/final/originals: missing={sorted(expected_originals-active_originals)}, extra={sorted(active_originals-expected_originals)}")
            if primary == "sicza-game-concept-lab":
                require(bool(active_originals), "game-concept-lab image delivery requires at least one generated original")
            allowed_external = {"interactive_html", "generated_original"}
            unexpected = sorted({item["role"] for item in files if item.get("active") and item["role"] not in allowed_external})
            require(not unexpected, f"HTML delivery exposes non-standard active roles: {unexpected}")

    spec = gates.get(primary)
    if spec is None:
        return
    gate_rel, label = spec
    gate=Path(__file__).resolve().parents[2] / gate_rel
    require(gate.is_file(), f"{label} delivery gate is missing")
    gate_args=[sys.executable,str(gate),"--request",relative(root,request),"--workspace-root",str(root)]
    if primary in {"wxian-image-layer-decomposition", "wxian-game-ui-layer-decomposition"}:
        gate_args.extend(["--delivery-manifest", relative(root, request / "work" / "delivery-manifest.json")])
    cp=subprocess.run(gate_args,
                      text=True,capture_output=True,encoding="utf-8",errors="replace",timeout=90,
                      env=python_subprocess_env())
    if cp.returncode != 0:
        reason=cp.stdout.strip() or cp.stderr.strip() or "unknown delivery gate failure"
        try:
            payload=json.loads(cp.stdout); reason=str(payload.get("reason",reason))
        except (json.JSONDecodeError,TypeError):
            pass
        raise GateError(f"{label} delivery gate blocked promote: {reason}")



def load_visual_enforcement_profile(root: Path, request: Path, state: dict[str, Any]) -> tuple[dict[str, Any] | None, str | None]:
    registry_path = root / ".agents" / "skills" / "workspace-governance" / "config" / "visual-contracts" / "visual-enforcement-profiles.json"
    try:
        registry = load_visual_json(registry_path)
    except VisualContractError as exc:
        raise GateError(f"visual enforcement registry invalid: {exc}") from exc
    require(registry.get("schema_version") == "sicza.visual-enforcement-profiles.v1", "visual enforcement registry schema mismatch")
    profiles = registry.get("profiles")
    require(isinstance(profiles, dict), "visual enforcement registry profiles must be object")
    primary = state["primary_skill"]
    entry = profiles.get(primary)
    if entry is None:
        return None, None
    require(isinstance(entry, dict), f"visual enforcement profile invalid for {primary}")
    branch: str | None = None
    if "branches" in entry:
        require(primary == "wxian-image-production", "branch visual enforcement is only valid for image production")
        branch = production_branch(request)
        profile = entry.get("branches", {}).get(branch)
        require(isinstance(profile, dict), f"no visual enforcement profile for {primary}:{branch}")
        return profile, branch
    profile = entry.get("default")
    require(isinstance(profile, dict), f"visual enforcement default profile missing for {primary}")
    return profile, branch


def request_has_reconstructed_layers(request: Path) -> bool:
    """Resolve reconstruction semantics across image and game-UI layer plans."""
    legacy = request / "work" / "layer-manifest.json"
    if legacy.is_file():
        try:
            obj = json.loads(legacy.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise GateError(f"invalid layer-manifest.json while resolving visual enforcement: {exc}") from exc
        layers = obj.get("layers", []) if isinstance(obj, dict) else []
        require(isinstance(layers, list), "layer-manifest layers must be an array")
        if any(isinstance(item, dict) and item.get("output_mode") == "reconstructed" for item in layers):
            return True

    work = request / "work"
    candidates = [(work / "layer-plan.json", "wxian.kv-layer-plan.v6",
                   {"source_locked_reconstruct", "clean_plate_patch", "model_native_alpha"})]
    candidates.extend((path, "wxian.game-ui-layer-plan.v4",
                       {"scene_clean_patch", "control_reconstruct", "text_strip_reconstruct", "model_native_alpha"})
                      for path in sorted(work.glob("ui-layer-plan*.json")))
    for current, expected_schema, reconstructing in candidates:
        if not current.is_file():
            continue
        try:
            plan = json.loads(current.read_text(encoding="utf-8"))
        except json.JSONDecodeError as exc:
            raise GateError(f"invalid {current.name} while resolving visual enforcement: {exc}") from exc
        require(isinstance(plan, dict), f"{current.name} root must be an object")
        if plan.get("schema_version") != expected_schema:
            continue
        layers = plan.get("layers", [])
        require(isinstance(layers, list), f"{current.name} layers must be an array")
        if any(isinstance(item, dict) and item.get("strategy") in reconstructing for item in layers):
            return True
    return False

def visual_policy_active(policy: str, request: Path) -> bool:
    if policy == "required":
        return True
    if policy in {"none", "optional", "diagnostic-advisory", "authority-owner"}:
        return False
    if policy == "if_reconstructed":
        return request_has_reconstructed_layers(request)
    if policy.startswith("if_exists:"):
        rel = policy.split(":", 1)[1]
        candidate = (request / rel).resolve()
        require(request.resolve() in candidate.parents, "conditional visual policy path escapes request")
        return candidate.is_file()
    raise GateError(f"unknown visual enforcement policy: {policy}")


def enforce_visual_contract_chain(root: Path, request: Path, state: dict[str, Any], files: list[dict[str, Any]]) -> dict[str, Any] | None:
    """Enforce the registered request-local visual profile before formal promotion; never calls providers."""
    profile, branch = load_visual_enforcement_profile(root, request, state)
    if profile is None:
        return None
    primary = state["primary_skill"]
    baseline_policy = str(profile.get("baseline", "none"))
    spec_policy = str(profile.get("visual_spec", "none"))
    binding_policy = str(profile.get("prompt_binding", "none"))
    gate_policy = str(profile.get("visual_gate", "none"))
    try:
        receipt = None
        receipt_path = request / "work" / "baseline-consumption.json"
        if baseline_policy == "required":
            receipt = validate_baseline_consumption(root, receipt_path)
            require(receipt.get("consumer") == profile.get("baseline_consumer"), "Baseline receipt consumer does not match active enforcement profile")
        elif baseline_policy == "optional":
            if receipt_path.is_file():
                receipt = validate_baseline_consumption(root, receipt_path)
                expected_consumer = profile.get("baseline_consumer")
                if expected_consumer is not None:
                    require(receipt.get("consumer") == expected_consumer, "Baseline receipt consumer does not match active enforcement profile")
        elif baseline_policy not in {"none", "authority-owner"}:
            raise GateError(f"unknown baseline enforcement policy: {baseline_policy}")

        if spec_policy == "authority-owner":
            return {"status": "authority-owner", "profile": primary, "production_branch": branch}
        if spec_policy == "diagnostic-advisory":
            # Explicitly registered advisory integration: if a canonical spec is present it must be valid,
            # but this analytical Skill does not fabricate a production Visual Spec solely to satisfy Governance.
            spec_path = request / "work" / "visual-spec.json"
            spec = validate_visual_spec(root, spec_path) if spec_path.is_file() else None
            return {"status": "diagnostic-advisory", "profile": primary, "production_branch": branch,
                    "baseline_receipt": relative(root, receipt_path) if receipt else None,
                    "visual_spec": relative(root, spec_path) if spec else None}

        spec_required = visual_policy_active(spec_policy, request)
        binding_required = visual_policy_active(binding_policy, request)
        gate_required = visual_policy_active(gate_policy, request)
        spec = None; binding = None; gate = None
        spec_path = request / "work" / "visual-spec.json"
        binding_path = request / "work" / "prompt-binding.json"
        gate_path = request / "work" / "visual-gate-result.json"
        if spec_required:
            spec = validate_visual_spec(root, spec_path)
            allowed_visual_profiles = set(profile.get("visual_profiles", []))
            require(spec.get("profile_id") in allowed_visual_profiles, f"Visual Spec profile is not allowed for {primary}:{branch or 'default'}")
        elif spec_path.is_file():
            # A present canonical contract may not be stale/invalid even when this branch does not require one.
            spec = validate_visual_spec(root, spec_path)

        if binding_required:
            require(spec is not None, "Prompt Binding requires active Visual Spec")
            binding = validate_prompt_binding(root, binding_path)
            allowed_compilers = set(profile.get("compiler_profiles", []))
            require(binding.get("compiler_profile") in allowed_compilers, f"Prompt compiler profile is not allowed for {primary}:{branch or 'default'}")
        elif binding_path.is_file():
            binding = validate_prompt_binding(root, binding_path)
            allowed_compilers = set(profile.get("compiler_profiles", []))
            if allowed_compilers:
                require(binding.get("compiler_profile") in allowed_compilers, f"Prompt compiler profile is not allowed for {primary}:{branch or 'default'}")

        if gate_required:
            require(spec is not None, "Visual Gate requires active Visual Spec")
            gate = validate_visual_gate_result(root, gate_path)
            require(gate.get("result") == "VISUAL_PASS", "visual-gate-result must be VISUAL_PASS before promote")
            require(gate.get("gate_profile") in set(profile.get("gate_profiles", [])), f"Visual Gate profile is not allowed for {primary}:{branch or 'default'}")
            if binding is not None:
                require(gate.get("prompt_binding_path") == relative(root, binding_path), "Visual Gate must link active Prompt Binding")
                require(gate.get("prompt_binding_sha256") == sha256_file(binding_path), "Visual Gate Prompt Binding hash is stale")
            target_policy = str(profile.get("gate_target", "delivery_source"))
            if target_policy == "delivery_source":
                active = {(item["source"], item["sha256"]) for item in files if item.get("active")}
                require((str(gate["target_path"]), str(gate["target_sha256"])) in active,
                        "visual-gate-result target must be an active delivery source/hash")
            elif target_policy == "request_scope":
                pass  # low-level validator already binds target to this request input/ or work/
            elif target_policy != "none":
                raise GateError(f"unknown visual gate target policy: {target_policy}")
        elif gate_path.is_file():
            gate = validate_visual_gate_result(root, gate_path)

        return {
            "status": "passed", "enforcement_profile": primary, "production_branch": branch,
            "baseline_receipt": relative(root, receipt_path) if receipt else None,
            "visual_spec": relative(root, spec_path) if spec else None,
            "prompt_binding": relative(root, binding_path) if binding else None,
            "visual_gate": relative(root, gate_path) if gate else None,
        }
    except VisualContractError as exc:
        raise GateError(f"visual contract chain blocked promote: {exc}") from exc

def register_delivery_feedback(root: Path, request: Path) -> dict[str, Any]:
    script = root / ".agents" / "skills" / "workspace-user-feedback" / "scripts" / "user_feedback.py"
    if not script.is_file():
        return {"status": "warning", "reason": "workspace-user-feedback script is missing", "ask_rating": False}
    try:
        cp = subprocess.run(
            [sys.executable, str(script), "register-delivery", "--request", relative(root, request),
             "--workspace-root", str(root)],
            check=False, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30,
            env=python_subprocess_env(),
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"status": "warning", "reason": f"feedback registration failed: {exc}", "ask_rating": False}
    try:
        payload = json.loads(cp.stdout or "")
    except (json.JSONDecodeError, TypeError):
        return {"status": "warning", "reason": "feedback registration returned invalid output", "ask_rating": False}
    if cp.returncode != 0 or not isinstance(payload, dict) or payload.get("status") != "ready":
        reason = payload.get("reason", cp.stderr.strip() or "feedback registration failed") if isinstance(payload, dict) else "feedback registration failed"
        return {"status": "warning", "reason": str(reason), "ask_rating": False}
    return {"status": "ready", "registered": bool(payload.get("registered")),
            "revision": payload.get("revision"), "rating": payload.get("rating", "unrated"),
            "ask_rating": True}


def promote(root: Path, request_value: str, manifest_value: str) -> dict[str, Any]:
    request = request_path(root, request_value)
    state = validate_state(request)
    validate_personal_execution(root, request, state["primary_skill"])
    enforce_visual_preflight(root, state["primary_skill"], request=request)
    require(state["status"] == "active", "only active request can be promoted")
    review = request / "work" / "final-review.md"
    require(review.is_file() and read_utf8(review).strip(), "work/final-review.md is required")
    validate_request_text_integrity(request)
    manifest_path = bounded_path(root, manifest_value, must_exist=True)
    require(manifest_path == (request / "work" / "delivery-manifest.json").resolve(),
            "manifest must be the request work/delivery-manifest.json")
    files = validate_delivery_manifest(root, request, manifest_path)
    visual_contracts = enforce_visual_contract_chain(root, request, state, files)
    enforce_primary_delivery_gate(root, request, state, files)
    revision_dir = request / "output" / "revisions" / f"r{state['revision']:03d}"
    require(not revision_dir.exists(), f"output revision already exists: {relative(root, revision_dir)}")
    revision_dir.mkdir(parents=True)
    output_files: list[dict[str, Any]] = []
    for item in files:
        if not item["active"]:
            continue
        source = bounded_path(root, item["source"], must_exist=True)
        parts = [item["role"]]
        if item["locale"]:
            parts.append(item["locale"])
        if item["size"]:
            parts.append(item["size"])
        target_dir = revision_dir.joinpath(*parts)
        target_dir.mkdir(parents=True, exist_ok=True)
        target = target_dir / source.name
        require(target.resolve().parent == target_dir.resolve() and revision_dir.resolve() in target.resolve().parents,
                "promoted target escaped its revision directory")
        require(not target.exists(), f"duplicate promoted target: {relative(root, target)}")
        shutil.copy2(source, target)
        require(sha256_file(target) == item["sha256"], f"copied delivery hash mismatch: {target.name}")
        output_files.append({"path": relative(root, target), "sha256": item["sha256"], "role": item["role"],
                             "locale": item["locale"], "size": item["size"]})
    output_manifest = {
        "active_revision": state["revision"],
        "final_review_sha256": sha256_file(review),
        "files": output_files,
    }
    write_json(request / "output" / "manifest.json", output_manifest)
    state["status"] = "completed"
    write_json(state_path(request), state)
    set_current(root, request)
    set_last_delivered(root, request)
    feedback = register_delivery_feedback(root, request)
    return {"status": "completed", "request": relative(root, request), "revision": state["revision"],
            "manifest": relative(root, request / "output" / "manifest.json"), "files": output_files,
            "visual_contracts": visual_contracts, "post_delivery_feedback": feedback}


def governance_visual_selftest(root: Path) -> dict[str, str]:
    results: dict[str, str] = {}
    registry_source = root / ".agents" / "skills" / "workspace-governance" / "config" / "visual-contracts" / "visual-enforcement-profiles.json"
    require(registry_source.is_file(), "visual enforcement registry is missing")
    with tempfile.TemporaryDirectory(prefix="governance-visual-selftest-") as td:
        test_root = Path(td)
        contract_dir = test_root / ".agents" / "skills" / "workspace-governance" / "config" / "visual-contracts"; contract_dir.mkdir(parents=True)
        shutil.copy2(registry_source, contract_dir / registry_source.name)

        def fixture(req_type: str, name: str, primary: str) -> Path:
            request=test_root/"requests"/req_type/name
            for folder in ("input","work","output"): (request/folder).mkdir(parents=True,exist_ok=True)
            (request/"request.md").write_text("selftest\n",encoding="utf-8")
            write_json(request/"state.json",{"primary_skill":primary,"status":"active","revision":1})
            return request
        def must_block(name: str, fn) -> None:
            try: fn()
            except (GateError, VisualContractError, OSError, ValueError): results[name]="BLOCK"
            else: raise GateError(f"governance self-test unexpectedly passed: {name}")

        packaging=fixture("visual-packaging","a","wxian-visual-packaging")
        must_block("missing_baseline_receipt",lambda:enforce_visual_contract_chain(test_root,packaging,load_json(packaging/"state.json"),[]))

        score=fixture("visual-scorecard","b","wxian-visual-scorecard")
        must_block("scorecard_missing_visual_spec",lambda:enforce_visual_contract_chain(test_root,score,load_json(score/"state.json"),[]))

        reverse=fixture("visual-reverse-analysis","c","wxian-visual-reverse-analysis")
        advisory=enforce_visual_contract_chain(test_root,reverse,load_json(reverse/"state.json"),[])
        require(isinstance(advisory,dict) and advisory.get("status")=="diagnostic-advisory","diagnostic advisory policy did not resolve explicitly")
        results["diagnostic_advisory"]="PASS"

        layer=fixture("image-layer-decomposition","d","wxian-image-layer-decomposition")
        require(not visual_policy_active("if_reconstructed",layer),"non-reconstructed layer request incorrectly activates visual production chain")
        write_json(layer/"work"/"layer-manifest.json",{"layers":[{"output_mode":"reconstructed"}]})
        require(visual_policy_active("if_reconstructed",layer),"reconstructed layer request did not activate visual production chain")
        results["layer_conditional_policy"]="PASS"
    return results


def governance_delivery_selftest() -> dict[str, str]:
    results: dict[str, str] = {}

    def must_block(name: str, fn) -> None:
        try:
            fn()
        except (GateError, OSError, ValueError):
            results[name] = "BLOCK"
        else:
            raise GateError(f"delivery self-test unexpectedly passed: {name}")

    with tempfile.TemporaryDirectory(prefix="governance-delivery-") as td:
        test_root = Path(td) / "中文项目"
        request = test_root / "requests" / "internet-research" / "case"
        work = request / "work"
        work.mkdir(parents=True)
        (request / "request.md").write_text("研究当前视觉趋势并生成展示页。\n", encoding="utf-8")
        state = {"primary_skill": "wxian-conducting-internet-research", "status": "active", "revision": 1}
        write_json(request / "state.json", state)
        first = work / "one.txt"; first.write_text("one\n", encoding="utf-8")
        second = work / "two.txt"; second.write_text("two\n", encoding="utf-8")
        manifest = work / "delivery-manifest.json"
        write_json(manifest, {"files": [
            {"role": "research", "source": relative(test_root, first), "sha256": sha256_file(first), "active": True},
            {"role": "research", "source": relative(test_root, second), "sha256": sha256_file(second), "active": True},
        ]})
        must_block("duplicate_non_generated_role", lambda: validate_delivery_manifest(test_root, request, manifest))
        write_json(manifest, {"files": [
            {"role": "generated_original", "source": relative(test_root, first), "sha256": sha256_file(first), "active": True},
            {"role": "generated_original", "source": relative(test_root, second), "sha256": sha256_file(second), "active": True},
        ]})
        require(len(validate_delivery_manifest(test_root, request, manifest)) == 2,
                "multiple generated originals should remain legal")
        results["multiple_generated_originals"] = "PASS"
        must_block("missing_interactive_html", lambda: enforce_primary_delivery_gate(test_root, request, state, []))

        concept = test_root / "requests" / "game-concept-lab" / "case"
        (concept / "work" / "concept-lab").mkdir(parents=True)
        (concept / "request.md").write_text("请输出完整 Prompt，然后自动生图。\n", encoding="utf-8")
        concept_state = {"primary_skill": "sicza-game-concept-lab", "status": "active", "revision": 1}
        write_json(concept / "state.json", concept_state)
        write_json(concept / "work" / "concept-lab" / "product-blueprint.json", {"portfolio_output": "PROMPT_MARKDOWN"})
        must_block("prompt_only_without_user_authorization",
                   lambda: enforce_primary_delivery_gate(test_root, concept, concept_state, []))
        auth_path = concept / "work" / "concept-lab" / "prompt-only-authorization.json"
        write_json(auth_path, {
            "schema_version": PROMPT_ONLY_AUTH_SCHEMA, "mode": "PROMPT_ONLY",
            "request_path": relative(test_root, concept / "request.md"),
            "request_sha256": sha256_file(concept / "request.md"),
            "user_instruction_excerpt": "请输出完整 Prompt，然后自动生图。",
        })
        must_block("prompt_only_forged_semantics", lambda: validate_prompt_only_authorization(test_root, concept))
        for index, conflict in enumerate((
            "不要只输出提示词，请自动生图。",
            "请不要遵循‘只要 Prompt’的旧说明；本次必须生图。",
            "不是只需要提示词，而是要完成全部图片生成。",
            "只输出提示词，并绘制三张概念图。",
            "Prompt only, then create three concept images.",
        )):
            (concept / "request.md").write_text(conflict + "\n", encoding="utf-8")
            write_json(auth_path, {
                "schema_version": PROMPT_ONLY_AUTH_SCHEMA, "mode": "PROMPT_ONLY",
                "request_path": relative(test_root, concept / "request.md"),
                "request_sha256": sha256_file(concept / "request.md"),
                "user_instruction_excerpt": conflict,
            })
            must_block(f"prompt_only_conflicting_generation_intent_{index + 1}",
                       lambda: validate_prompt_only_authorization(test_root, concept))
        (concept / "request.md").write_text("只需要提示词，不需要生图。\n", encoding="utf-8")
        write_json(auth_path, {
            "schema_version": PROMPT_ONLY_AUTH_SCHEMA, "mode": "PROMPT_ONLY",
            "request_path": relative(test_root, concept / "request.md"),
            "request_sha256": sha256_file(concept / "request.md"),
            "user_instruction_excerpt": "只需要提示词，不需要生图。",
        })
        validate_prompt_only_authorization(test_root, concept)
        results["request_bound_prompt_only_authorization"] = "PASS"

        # Layer decomposition skills must not inherit the generic completion seam.
        for request_type, primary, label in (
            ("image-layer-decomposition", "wxian-image-layer-decomposition", "kv_layer_delivery_gate_registered"),
            ("game-ui-layer-decomposition", "wxian-game-ui-layer-decomposition", "ui_layer_delivery_gate_registered"),
        ):
            layer_req = test_root / "requests" / request_type / "case"
            (layer_req / "work").mkdir(parents=True, exist_ok=True)
            (layer_req / "input").mkdir(parents=True, exist_ok=True)
            (layer_req / "output").mkdir(parents=True, exist_ok=True)
            (layer_req / "request.md").write_text("layer delivery selftest\n", encoding="utf-8")
            layer_state = {"primary_skill": primary, "status": "active", "revision": 1}
            write_json(layer_req / "state.json", layer_state)
            dummy = layer_req / "work" / "dummy.txt"
            dummy.write_text("not a layer pack\n", encoding="utf-8")
            write_json(layer_req / "work" / "delivery-manifest.json", {"files": [{
                "role": "artifact", "source": relative(test_root, dummy),
                "sha256": sha256_file(dummy), "active": True,
            }]})
            parsed = validate_delivery_manifest(test_root, layer_req, layer_req / "work" / "delivery-manifest.json")
            must_block(label, lambda tr=test_root, lr=layer_req, st=layer_state, pf=parsed: enforce_primary_delivery_gate(tr, lr, st, pf))
        (concept / "request.md").write_text("Only provide prompts; do not generate images.\n", encoding="utf-8")
        write_json(auth_path, {
            "schema_version": PROMPT_ONLY_AUTH_SCHEMA, "mode": "PROMPT_ONLY",
            "request_path": relative(test_root, concept / "request.md"),
            "request_sha256": sha256_file(concept / "request.md"),
            "user_instruction_excerpt": "Only provide prompts; do not generate images.",
        })
        validate_prompt_only_authorization(test_root, concept)
        results["english_request_bound_prompt_only_authorization"] = "PASS"

        feedback_script = test_root / ".agents" / "skills" / "workspace-user-feedback" / "scripts" / "user_feedback.py"
        feedback_script.parent.mkdir(parents=True)
        feedback_script.write_bytes(b"import sys\nsys.stdout.buffer.write(b'\\xff')\n")
        feedback = register_delivery_feedback(test_root, concept)
        require(feedback.get("status") == "warning", "invalid feedback subprocess output must degrade to warning")
        results["windows_unicode_feedback_failure"] = "PASS"
    return results


def visual_preflight_policy_selftest(root: Path) -> dict[str, str]:
    results: dict[str, str] = {}
    original_run = subprocess.run
    calls: list[list[str]] = []

    def ready_visual_check(command: list[str], **_kwargs: Any) -> subprocess.CompletedProcess[str]:
        calls.append([str(item) for item in command])
        return subprocess.CompletedProcess(command, 0, stdout='{"status":"ready"}', stderr="")

    try:
        subprocess.run = ready_visual_check
        with tempfile.TemporaryDirectory(prefix="visual-preflight-policy-") as temp_dir:
            request = Path(temp_dir) / "request"
            (request / "work").mkdir(parents=True)
            receipt = request / "work/baseline-consumption.json"
            receipt.write_text("{}\n", encoding="utf-8")
            optional_skills = (
                "sicza-game-concept-lab",
                "wxian-visual-scorecard",
                "wxian-game-ui-layer-decomposition",
            )
            for skill in optional_skills:
                before = len(calls)
                result = enforce_visual_preflight(root, skill, request=request, request_type="game-concept-lab")
                require(result is not None and len(calls) == before + 1,
                        f"optional Baseline consumer skipped freshness check: {skill}")
                results[f"optional_receipt_{skill}"] = "PASS"
            receipt.unlink()
            before = len(calls)
            require(enforce_visual_preflight(root, "sicza-game-concept-lab", request=request,
                                             request_type="game-concept-lab") is None
                    and len(calls) == before,
                    "optional Baseline consumer without a receipt ran visual preflight")
            results["optional_without_receipt"] = "PASS"
            require(enforce_visual_preflight(root, "wxian-conducting-internet-research", request=request,
                                             request_type="internet-research") is None
                    and len(calls) == before,
                    "non-visual Skill ran visual preflight")
            results["non_visual_profile_absent"] = "PASS"
    finally:
        subprocess.run = original_run
    return results


def doctor(root: Path) -> dict[str, Any]:
    require(root.is_dir(), f"Workspace root does not exist: {root}")
    registry_path=root/".agents"/"skills"/"workspace-governance"/"config"/"visual-contracts"/"visual-enforcement-profiles.json"
    registry_obj=load_visual_json(registry_path)
    require(registry_obj.get("schema_version")=="sicza.visual-enforcement-profiles.v1","visual enforcement registry schema mismatch")
    profiles=registry_obj.get("profiles"); require(isinstance(profiles,dict),"visual enforcement profiles invalid")
    expected_visual={"wxian-visual-packaging","wxian-visual-competitive-analysis","sicza-game-concept-lab","wxian-image-production","wxian-image-layer-decomposition","wxian-game-ui-layer-decomposition","wxian-visual-reverse-analysis","wxian-visual-scorecard","wxian-kv-micro-animation","wxian-visual-baselines"}
    require(expected_visual <= set(profiles), f"visual enforcement registry missing skills: {sorted(expected_visual-set(profiles))}")
    valid_policy={"required","none","optional","diagnostic-advisory","authority-owner","if_reconstructed"}
    for skill,entry in profiles.items():
        variants=entry.get("branches",{}).values() if isinstance(entry,dict) and "branches" in entry else [entry.get("default") if isinstance(entry,dict) else None]
        for profile in variants:
            require(isinstance(profile,dict),f"visual enforcement profile malformed: {skill}")
            for key in ("baseline","visual_spec","prompt_binding","visual_gate"):
                value=str(profile.get(key,"none"))
                require(value in valid_policy or value.startswith("if_exists:"),f"unsupported {key} policy for {skill}: {value}")
    selftests=governance_visual_selftest(root)
    portfolio_gate = root / ".agents" / "skills" / "sicza-game-concept-lab" / "scripts" / "portfolio_gate.py"
    require(portfolio_gate.is_file(), "game-concept-lab portfolio gate is missing")
    cp = subprocess.run(
        [sys.executable, str(portfolio_gate), "--doctor", "--workspace-root", str(root)],
        check=False, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30,
        env=python_subprocess_env(),
    )
    try:
        portfolio_selftest = json.loads(cp.stdout)
    except json.JSONDecodeError as exc:
        raise GateError("game-concept-lab portfolio gate doctor returned invalid JSON") from exc
    require(cp.returncode == 0 and portfolio_selftest.get("status") == "ready",
            f"game-concept-lab portfolio gate doctor failed: {portfolio_selftest.get('reason', cp.stderr.strip())}")
    html_gate = root / ".agents" / "skills" / "wxian-html-delivery" / "scripts" / "html_delivery.py"
    require(html_gate.is_file(), "HTML delivery gate is missing")
    html_cp = subprocess.run(
        [sys.executable, str(html_gate), "doctor"], check=False,
        capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=30,
        env=python_subprocess_env(),
    )
    try:
        html_selftest = json.loads(html_cp.stdout)
    except json.JSONDecodeError as exc:
        raise GateError("HTML delivery gate doctor returned invalid JSON") from exc
    require(html_cp.returncode == 0 and html_selftest.get("status") == "passed",
            f"HTML delivery gate doctor failed: {html_selftest.get('reason', html_cp.stderr.strip())}")
    delivery_selftests = governance_delivery_selftest()
    preflight_selftests = visual_preflight_policy_selftest(root)
    baseline_preflight_skills = sorted(
        skill for skill, entry in profiles.items()
        if isinstance(entry, dict) and any(
            isinstance(profile, dict) and profile.get("baseline") in {"required", "optional", "if_reconstructed"}
            for profile in (entry.get("branches", {}).values() if "branches" in entry else [entry.get("default")])
        )
    )
    return {"status": "ready", "tool": "workspace_gate", "state_fields": sorted(STATE_FIELDS),
            "mutable_status": sorted(MUTABLE_STATUS), "internal_completion_skills": sorted(INTERNAL_COMPLETION_SKILLS),
            "primary_skills": sorted(PRIMARY_SKILLS), "request_types": sorted(REQUEST_ROUTES),
            "request_folder_format": "【YYYYMMDD】NN-需求类型-需求标题",
            "sequence_scope": "all user requests created on the same local calendar date",
            "legacy_request_names": "read-only compatibility; new creation is blocked",
            "baseline_required_skills": baseline_preflight_skills,
            "visual_enforcement_profiles": sorted(profiles), "visual_enforcement_selftests": selftests,
            "visual_preflight_policy_selftests": preflight_selftests,
            "game_concept_portfolio_selftests": portfolio_selftest.get("selftests", {}),
            "html_delivery_selftest": html_selftest, "delivery_selftests": delivery_selftests}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    init = sub.add_parser("init-request")
    init_source = init.add_mutually_exclusive_group(required=True)
    init_source.add_argument("--request", help="canonical internal request path; reserved for Baseline")
    init_source.add_argument("--request-type", help="machine request_type for a new user demand")
    init.add_argument("--demand-label", help="human demand type shown in the folder name, e.g. BANNER/KV/商店图")
    init.add_argument("--demand-title", help="short human-readable title derived from the demand theme/copy")
    init.add_argument("--primary-skill", required=True)
    init.add_argument("--request-text", required=True)
    init.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])

    resolve = sub.add_parser("resolve-request")
    resolve.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])

    consume = sub.add_parser("consume-personal-context")
    consume.add_argument("--request", required=True)
    consume.add_argument("--consumer", required=True)
    consume.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])

    latest = sub.add_parser("resolve-latest")
    latest.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])

    revise = sub.add_parser("revise-request")
    revise.add_argument("--request", required=True)
    revise.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])

    supplement = sub.add_parser("register-supplement")
    supplement.add_argument("--request", required=True)
    supplement.add_argument("--input", required=True)
    supplement.add_argument("--note")
    supplement.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])

    state = sub.add_parser("set-state")
    state.add_argument("--request", required=True)
    state.add_argument("--status")
    state.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])

    internal = sub.add_parser("complete-internal")
    internal.add_argument("--request", required=True)
    internal.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])

    promote_parser = sub.add_parser("promote")
    promote_parser.add_argument("--request", required=True)
    promote_parser.add_argument("--manifest", required=True)
    promote_parser.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])

    health = sub.add_parser("doctor")
    health.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])

    args = parser.parse_args()
    try:
        root = args.workspace_root.resolve()
        require(root.is_dir(), f"Workspace root does not exist: {root}")
        if args.command == "init-request":
            result = init_request(root, args.request, args.request_type, args.primary_skill, args.request_text,
                                  args.demand_label, args.demand_title)
        elif args.command == "resolve-request":
            result = resolve_request(root)
        elif args.command == "consume-personal-context":
            result = consume_personal_context(root, args.request, args.consumer)
        elif args.command == "resolve-latest":
            result = resolve_latest(root)
        elif args.command == "revise-request":
            result = revise_request(root, args.request)
        elif args.command == "register-supplement":
            result = register_supplement(root, args.request, args.input, args.note)
        elif args.command == "set-state":
            result = set_state(root, args.request, args.status)
        elif args.command == "complete-internal":
            result = complete_internal(root, args.request)
        elif args.command == "promote":
            result = promote(root, args.request, args.manifest)
        else:
            result = doctor(root)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (GateError, TextIntegrityError, OSError, json.JSONDecodeError) as exc:
        print(json.dumps({"status": "blocked", "reason": str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    sys.exit(main())
