---
name: workspace-governance
description: 管理 request 的创建、续接、返修、生命周期状态与最终 promote，并约束 request 的内部存放和交付命名。
---

# Request 管理

脚本：`scripts/workspace_gate.py`。

## Request 契约

每个用户 request 固定为：

```text
requests/<type>/【YYYYMMDD】NN-需求类型-需求标题/
├── request.md
├── state.json
├── input/
├── work/
└── output/
```

其中 `<type>` 仍为 lowercase kebab-case 机器路由键；第二层用户可见需求目录必须由 `init-request` 自动生成：

- `YYYYMMDD` = 创建时本机当日日期；
- `NN` = 当天**全 request type 共用**的需求序号，按现有最大序号 + 1 分配，最少两位（`01...10...99...100`）；删除旧需求也不回收序号；
- `需求类型` = 业务短标签，例如 `BANNER / KV / LOGO / ICON / 商店图`；
- `需求标题` = 用户需求名称，或 Intake 根据主题/文案/活动/核心对象自动生成的短标题；
- Windows 禁用字符由脚本清洗，Agent 不得自行填写日期、序号或自由 slug。

Canonical Baseline 是内部系统 request，唯一例外仍为 `requests/baseline/project-visual-baseline/`。历史 lowercase-kebab 用户目录只提供续接兼容，**禁止新建**，避免升级后切断既有 request；所有新需求必须进入新格式。用户原始素材文件名不因进入 `input/` 或项目素材区而强制改名。

`<type>` 不是自由标签：必须存在于 `.agents/lib/request_routing.py`，并与 `state.json.primary_skill` 的唯一映射一致。`init-request` 与后续 state 校验都会硬检查；图片生产类 `<type>` 还会在读取 `requirement-lock.md` 时硬检查对应唯一 `production_branch`。

职责固定：

- `request.md`：当前需求与用户追加原话；
- `input/`：当前 request 的真实输入证据；
- `work/`：可重建的中间事实、分析、候选、门禁与待发布文件；
- `output/`：只由 `promote` 写入的正式 revision，不手工写入；
- `state.json`：只记录粗粒度 request 生命周期，不记录可从真实产物推导的阶段或下一动作。

`state.json` 只保留：

```json
{"primary_skill":"...","status":"active|blocked|completed","revision":1}
```

实际下一步由当前 primary Skill 根据其 canonical artifacts 与 gates 判定；不得维护第二份 `next_action` / `next_step` 进度事实源。

## 操作

- 新目标：`init-request --request-type <type> --demand-label <业务类型> --demand-title <需求标题>`；路径由脚本自动生成
- 更新未完成生命周期：`set-state`（只允许 `active | blocked`）
- 补素材：`register-supplement`；图片生产 request 同步刷新机器生成的 `source-lock.json`
- 继续当前未完成需求：`resolve-request`
- 定位刚交付需求：`resolve-latest`
- 同一成品返修：`revise-request`
- 用户交付：`promote`
- Baseline 内部完成：`complete-internal`

`user/manifest.json` 仅在 `enabled=true` 时由 `$workspace-personal-skill` 解析当前 `personal-context.json`；完整 resolve/load/consumer-provenance 与完成门禁见 [Personal Context Lifecycle](references/personal-context-lifecycle.md)。

`completed` 不是可手工设置的普通状态。用户交付只能由 `promote` 写入；Canonical Baseline 只能在 `validate-published` 通过后由 `complete-internal` 写入。`resolve-latest` 只认真实 promoted 用户交付；Baseline/初始化等内部 request 即使 `completed` 也不属于“刚交付需求”，不得触发成品返修。

会消费项目视觉事实的 Primary Skill 在 `init-request / resolve-request / revise-request / promote` 前按当前 `request_type → production_branch → visual enforcement profile` 决定是否执行 `workspace_init.py visual-check`。`baseline=required` 始终执行；`optional` 只有当前 request 已存在 `baseline-consumption.json` 时执行；`none / diagnostic-advisory / authority-owner` 跳过。该检查只验证 Project Visual Baseline freshness，不改变 receipt 的 `consumer` machine key，也不依赖 Agent 自觉调用。

用户不需要知道 request 路径。

## Promote

`work/final-review.md` 与 `work/delivery-manifest.json` 必须对应真实文件与 Hash。图片生产从 `work/requirement-lock.md` 的唯一 `production_branch` 执行 delivery gate。Gate 不通过不得 completed。


涉及共享视觉链时，Promote 额外按 [Visual Contract Enforcement](references/visual-contract-enforcement.md) 与 `config/visual-contracts/visual-enforcement-profiles.json` 执行机器门禁；Skill 文档不能自行放宽。

Delivery manifest 的 `role` 使用 1–64 字符 lowercase snake_case 且避开跨平台保留设备名；`locale` 使用 `und` 或 BCP47-like 标识；`size` 使用 `WIDTHxHEIGHT` 像素。Promote 固定写入：

```text
output/revisions/rNNN/<role>[/<locale>][/<size>]/<source-filename>
output/manifest.json
```

`role / locale / size` 只能作为单个目录段，不得形成额外路径层级或逃出当前 revision；`<source-filename>` 保留已验证交付源的真实 basename，不为统一外观擅自改写用户/业务文件名。

Promote 成功后自动按 `request + revision` 登记本次真实交付为 `unrated`。实际把成品交给用户后询问一次 1–5 分；未评分保持 `unrated`，不阻塞下一需求，也不改变已完成状态。
