# Visual Contract Enforcement

本文件定义 Governance 对共享视觉链的机器执行边界；Provider/API Runtime 不在此处修改。

机器事实唯一来自 `config/visual-contracts/visual-enforcement-profiles.json`。注册表按 Primary Skill 与 production branch/condition 声明 Baseline receipt、Visual Spec、Prompt Binding、Visual Gate 的 `required / optional / conditional / diagnostic-advisory / none`，并限制合法 spec/compiler/gate profile 与 target policy。

生产型合同必须绑定当前 `request_id + request_revision + request_fingerprint`。`request.md`、input、requirement-lock、source-lock 或 revision 变化后旧链失效；request-local authority 只能指向当前 request canonical path。需要 Baseline 消费证明的 profile 验证 `work/baseline-consumption.json`。需要 Prompt/Gate 的 profile 只能使用注册 profile。

Visual Gate 的 PASS 必须满足注册 profile 的全部 mandatory gates；每个 gate 至少提供一条绑定当前 gated target path/hash 的具体可观察 evidence。空 evidence、弱占位结论、未知 gate、`UNVERIFIED`、跨 request target 均 fail-closed。

`diagnostic-advisory` 必须返回显式状态；不得以缺少 enforcement 结果或 `None` 冒充已接入。
