# Personal Context Lifecycle

仅当 `user/manifest.json` 明确 `enabled=true` 时才解析 Personal Context。每次复用前都从当前 manifest、preferences、request type 与已命中 Skill 文件重算权威投影；仅当投影逐项一致时复用 `work/personal-context.json` 且不重写文件。未开启时完全跳过；启用但无匹配 Skill 时允许空 Context；命中 Skill 必须绑定 registry 中的路径与文件 Hash，失败写 `work/personal-layer-error.json` 并阻断。

进入 Primary Skill 前，由该 Primary Skill 显式执行：

```text
$workspace-governance consume-personal-context --request <request> --consumer <primary_skill>
```

consumer 必须与 `state.json.primary_skill` 一致。成功后 Context 进入 `loaded` 并生成 `work/personal-execution.json`，绑定 request、revision、consumer、manifest/context/Skill 文件 Hash 与显式调用来源。正文不进入 Context 或命令输出，由 consumer 按 `load_paths` 读取。缺失、错误 consumer、旧 revision、Hash 漂移或 state-derived 旧式来源时，实际执行器与所有完成入口均阻断。
