#!/usr/bin/env python3
"""CLI wrapper for the canonical current-request source-lock validator."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path

LIB=Path(__file__).resolve().parents[3]/'lib'
if str(LIB) not in sys.path: sys.path.insert(0,str(LIB))
from production_contract import ProductionContractError, request_input_files, validate_source_lock, workspace_relative

class SourceLockError(ValueError): pass

def require(c,m):
    if not c: raise SourceLockError(m)

def bounded(root:Path,value:str|Path,exist=False)->Path:
    p=Path(value); p=(root/p if not p.is_absolute() else p).resolve()
    require(p==root or root in p.parents,f"path escapes Workspace: {value}")
    if exist: require(p.exists(),f"path does not exist: {value}")
    return p

def request_path(root:Path,value:str)->Path:
    p=bounded(root,value,True); parts=p.relative_to(root).parts
    require(len(parts)==3 and parts[0].lower()=='requests' and p.is_dir(),'request must be requests/<type>/<name>')
    return p

def validate(root:Path,request:Path)->dict:
    return validate_source_lock(root,request)

def sync(root:Path,request:Path)->dict:
    lock=request/'work/source-lock.json'
    sources=[workspace_relative(root,p) for p in request_input_files(request)]
    if not sources:
        if lock.exists(): lock.unlink()
        return {'status':'not_required','source_count':0}
    lock.parent.mkdir(parents=True,exist_ok=True)
    lock.write_text(json.dumps({'required_sources':sources},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return validate_source_lock(root,request)

def main()->int:
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--request',required=True); ap.add_argument('--sync',action='store_true'); ap.add_argument('--workspace-root',type=Path,default=Path(__file__).resolve().parents[4]); a=ap.parse_args()
    try:
        root=a.workspace_root.resolve(); req=request_path(root,a.request); result=sync(root,req) if a.sync else validate(root,req); print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
    except (SourceLockError,ProductionContractError,OSError) as e:
        print(json.dumps({'status':'blocked','reason':str(e)},ensure_ascii=False,indent=2)); return 1
if __name__=='__main__': sys.exit(main())
