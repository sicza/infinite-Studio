#!/usr/bin/env python3
"""Portable personal-skill registry and exact request-type resolver."""
from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path

AGENTS_ROOT = Path(__file__).resolve().parents[3]
if str(AGENTS_ROOT / "lib") not in sys.path:
    sys.path.insert(0, str(AGENTS_ROOT / "lib"))
from request_routing import REQUEST_ROUTES
from atomic_io import atomic_write_text

DEFAULT_MANIFEST = {
    "version": 1,
    "enabled": False,
    "skills": [],
}

REQUEST_LABELS = {
    "baseline": "项目 Visual Baseline",
    "visual-packaging": "视觉包装方案",
    "visual-competitive-analysis": "视觉竞品分析",
    "game-concept-lab": "游戏概念 / 画风玩法实验",
    "image-generation": "生图 / KV / 海报 / Banner / 角色图等成图",
    "image-edit": "改图 / 重绘 / 精修",
    "video-production": "真实视频生成",
    "resize": "尺寸适配",
    "localization": "多语言 / 换文案",
    "composite": "真实 LOGO / ICON / UI / 道具合成",
    "postprocess": "后处理链",
    "visual-brief": "视觉需求文档",
    "prompt-writing": "提示词编写",
    "prompt-review": "提示词审核",
    "image-layer-decomposition": "图像拆层",
    "game-ui-layer-decomposition": "游戏 UI 拆层",
    "visual-reverse-analysis": "视觉反推",
    "video-source-analysis": "视频输入分析",
    "visual-scorecard": "视觉评分 / 候选比较",
    "kv-micro-animation": "KV 5 秒微动画 Prompt",
    "internet-research": "互联网调研",
}


class PersonalSkillError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise PersonalSkillError(message)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def bounded(root: Path, value: str | Path, *, exist: bool = False) -> Path:
    path = Path(value)
    path = (root / path if not path.is_absolute() else path).resolve()
    require(path == root or root in path.parents, f"path escapes Workspace: {value}")
    if exist:
        require(path.exists(), f"path does not exist: {value}")
    return path


def user_root(root: Path) -> Path:
    return root / "user"


def manifest_path(root: Path) -> Path:
    return user_root(root) / "manifest.json"


def atomic_json(path: Path, payload: dict) -> None:
    atomic_write_text(path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")


def init_store(root: Path) -> dict:
    user = user_root(root)
    legacy = root / "USER"
    if legacy.exists() and not user.exists():
        legacy.rename(user)
    user.mkdir(parents=True, exist_ok=True)
    path = manifest_path(root)
    if not path.exists():
        atomic_json(path, DEFAULT_MANIFEST)
    manifest = load_manifest(root)
    return {
        "status": "ready",
        "user_root": "user",
        "manifest": "user/manifest.json",
        "skill_count": len(manifest["skills"]),
    }


def load_manifest(root: Path) -> dict:
    path = manifest_path(root)
    require(path.is_file(), "user/manifest.json is missing")
    value = json.loads(path.read_text(encoding="utf-8"))
    require(isinstance(value, dict), "user/manifest.json must be an object")
    require(value.get("version") == 1, "unsupported user manifest version")
    require(isinstance(value.get("enabled", False), bool), "user manifest enabled must be a boolean")
    skills = value.get("skills")
    require(isinstance(skills, list), "user manifest skills must be a list")
    return value


def validate_request_types(values: list[str]) -> list[str]:
    result: list[str] = []
    for value in values:
        key = value.strip()
        require(key in REQUEST_ROUTES, f"unsupported request_type: {key}")
        if key not in result:
            result.append(key)
    return result


def list_request_types() -> dict:
    items = []
    for request_type, route in REQUEST_ROUTES.items():
        if request_type == "baseline":
            continue
        items.append({
            "request_type": request_type,
            "label": REQUEST_LABELS.get(request_type, request_type),
            "primary_skill": route["primary_skill"],
            "production_branch": route.get("production_branch", ""),
        })
    return {"status": "ready", "request_types": items}


def skill_name_from_file(path: Path) -> str:
    text = path.read_text(encoding="utf-8")
    if text.startswith("---"):
        end = text.find("\n---", 3)
        if end != -1:
            for line in text[3:end].splitlines():
                if line.strip().startswith("name:"):
                    value = line.split(":", 1)[1].strip()
                    if value:
                        return value
    return path.parent.name or path.stem


def skill_description_from_file(path: Path) -> str:
    text = path.read_text(encoding="utf-8")
    if text.startswith("---"):
        end = text.find("\n---", 3)
        if end != -1:
            for line in text[3:end].splitlines():
                if line.strip().startswith("description:"):
                    return line.split(":", 1)[1].strip()
    return ""


def normalize_skill_path(root: Path, value: str) -> Path:
    path = bounded(root, value, exist=True)
    require(path.is_file(), "personal skill path must be a SKILL.md file")
    require(path.name.casefold() == "skill.md", "personal skill entry file must be named SKILL.md")
    require((user_root(root) / "skills").resolve() in path.parents,
            "registered personal skill must live under user/skills/")
    return path


def register_skill(root: Path, path_value: str, load_mode: str, request_types: list[str]) -> dict:
    init_store(root)
    path = normalize_skill_path(root, path_value)
    require(load_mode in {"global", "request_types"}, "load_mode must be global or request_types")
    selected = validate_request_types(request_types)
    if load_mode == "global":
        require(not selected, "global personal skill must not also declare request_types")
    else:
        require(bool(selected), "request_types mode requires at least one request_type")
    entry = {
        "name": skill_name_from_file(path),
        "description": skill_description_from_file(path),
        "path": path.relative_to(root).as_posix(),
        "sha256": sha256_file(path),
        "load_mode": load_mode,
        "request_types": selected,
    }
    manifest = load_manifest(root)
    manifest["enabled"] = True
    skills = manifest["skills"]
    replaced = False
    for index, current in enumerate(skills):
        if current.get("path") == entry["path"] or current.get("name") == entry["name"]:
            skills[index] = entry
            replaced = True
            break
    if not replaced:
        skills.append(entry)
    atomic_json(manifest_path(root), manifest)
    return {"status": "ready", "registered": True, "skill": entry}


def promote_candidate(root: Path, candidate_value: str, load_mode: str, request_types: list[str]) -> dict:
    init_store(root)
    candidate = bounded(root, candidate_value, exist=True)
    require(candidate.is_file() and candidate.name.casefold() == "skill.md",
            "candidate must point to user/candidates/<name>/SKILL.md")
    require((user_root(root) / "candidates").resolve() in candidate.parents,
            "candidate must live under user/candidates/")
    folder = candidate.parent.name
    target_dir = user_root(root) / "skills" / folder
    target_dir.mkdir(parents=True, exist_ok=True)
    target = target_dir / "SKILL.md"
    target.write_text(candidate.read_text(encoding="utf-8"), encoding="utf-8")
    result = register_skill(root, target.relative_to(root).as_posix(), load_mode, request_types)
    result["promoted_from"] = candidate.relative_to(root).as_posix()
    result["promoted_to"] = target.relative_to(root).as_posix()
    candidate_dir = candidate.parent
    if candidate_dir != (user_root(root) / "candidates"):
        shutil.rmtree(candidate_dir, ignore_errors=True)
    return result


def validate_entry(root: Path, entry: dict) -> dict:
    require(isinstance(entry, dict), "personal skill entry must be an object")
    path_value = str(entry.get("path") or "")
    path = normalize_skill_path(root, path_value)
    require(entry.get("sha256") == sha256_file(path),
            f"personal skill changed after registration: {path_value}; re-register it")
    load_mode = entry.get("load_mode")
    require(load_mode in {"global", "request_types"}, f"invalid load_mode for {path_value}")
    request_types = entry.get("request_types")
    require(isinstance(request_types, list), f"request_types must be a list for {path_value}")
    selected = validate_request_types([str(item) for item in request_types])
    if load_mode == "global":
        require(not selected, f"global skill must not declare request_types: {path_value}")
    else:
        require(bool(selected), f"request_types skill has no targets: {path_value}")
    return {
        "name": str(entry.get("name") or skill_name_from_file(path)),
        "description": str(entry.get("description") or ""),
        "path": path.relative_to(root).as_posix(),
        "sha256": sha256_file(path),
        "load_mode": load_mode,
        "request_types": selected,
    }


def entry_matches_request_type(entry: object, request_type: str) -> bool:
    require(isinstance(entry, dict), "personal skill entry must be an object")
    load_mode = entry.get("load_mode")
    require(load_mode in {"global", "request_types"}, "invalid personal skill load_mode")
    request_types = entry.get("request_types")
    require(isinstance(request_types, list), "personal skill request_types must be a list")
    selected = validate_request_types([str(item) for item in request_types])
    if load_mode == "global":
        require(not selected, "global personal skill must not declare request_types")
        return True
    require(bool(selected), "request_types personal skill has no targets")
    return request_type in selected


def resolve(root: Path, request_type: str) -> dict:
    init_store(root)
    request_type = request_type.strip()
    require(request_type in REQUEST_ROUTES, f"unsupported request_type: {request_type}")
    manifest = load_manifest(root)
    if not manifest.get("enabled", False):
        return {
            "status": "ready",
            "enabled": False,
            "request_type": request_type,
            "manifest": "user/manifest.json",
            "manifest_sha256": sha256_file(manifest_path(root)),
            "personal_skills": [],
            "load_paths": [],
        }
    if request_type == "baseline":
        return {
            "status": "ready",
            "request_type": request_type,
            "manifest": "user/manifest.json",
            "manifest_sha256": sha256_file(manifest_path(root)),
            "personal_skills": [],
            "load_paths": [],
        }
    matched = []
    for raw in manifest["skills"]:
        if entry_matches_request_type(raw, request_type):
            entry = validate_entry(root, raw)
            path = bounded(root, entry["path"], exist=True)
            body = path.read_text(encoding="utf-8").strip()
            require(body, f"personal skill is empty: {entry['path']}")
            matched.append(entry)
    return {
        "status": "ready",
        "enabled": True,
        "request_type": request_type,
        "manifest": "user/manifest.json",
        "manifest_sha256": sha256_file(manifest_path(root)),
        "personal_skills": matched,
        "load_paths": [entry["path"] for entry in matched],
    }


def doctor(root: Path) -> dict:
    init_store(root)
    manifest = load_manifest(root)
    validated = [validate_entry(root, entry) for entry in manifest["skills"]]
    return {
        "status": "ready",
        "enabled": bool(manifest.get("enabled", False)),
        "skill_count": len(validated),
        "user_request_type_count": len([key for key in REQUEST_ROUTES if key != "baseline"]),
        "user_root": "user",
        "manifest": "user/manifest.json",
    }


def main() -> int:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)

    for name in ("init-store", "list-request-types", "register-skill", "promote-candidate", "resolve", "doctor"):
        command = sub.add_parser(name)
        command.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])
        if name in {"register-skill", "promote-candidate"}:
            command.add_argument("--load-mode", choices=("global", "request_types"), required=True)
            command.add_argument("--request-type", action="append", default=[])
        if name == "register-skill":
            command.add_argument("--path", required=True)
        if name == "promote-candidate":
            command.add_argument("--candidate", required=True)
        if name == "resolve":
            command.add_argument("--request-type", required=True)

    args = parser.parse_args()
    root = args.workspace_root.resolve()
    try:
        if args.command == "init-store":
            result = init_store(root)
        elif args.command == "list-request-types":
            result = list_request_types()
        elif args.command == "register-skill":
            result = register_skill(root, args.path, args.load_mode, args.request_type)
        elif args.command == "promote-candidate":
            result = promote_candidate(root, args.candidate, args.load_mode, args.request_type)
        elif args.command == "resolve":
            result = resolve(root, args.request_type)
        else:
            result = doctor(root)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (PersonalSkillError, OSError, json.JSONDecodeError, ValueError) as exc:
        print(json.dumps({"status": "blocked", "reason": str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    sys.exit(main())
