---
name: workspace-personal-skill
description: 管理可迁移的可选 user/ 个人 Skill 层：候选沉淀、用户选择加载范围、注册，并在用户明确开启后按 request_type 精确解析和加载。
---

# Personal Skill

`user/` 是当前用户的长期可迁移个人层。公共专业 Skill 留在 `.agents/skills/`，项目事实留在 `project/`，个人审美与个人工作方法留在 `user/`。

```text
user/
├─ manifest.json
├─ preferences.md
├─ demand-history.md
├─ high-score-demands.md
├─ ratings.md
├─ candidates/
└─ skills/
   └─ <personal-skill>/SKILL.md
```

新 Workspace 默认只创建：

```json
{
  "version": 1,
  "enabled": false,
  "skills": []
}
```

`preferences.md`、反馈文件、`candidates/` 与 `skills/` 都在用户真正使用对应能力时惰性创建。复制整个 `user/` 到另一 Project Workspace 后，可以继续使用同一份个人层；只有 manifest 明确 `enabled=true` 时，个人层才参与需求执行。

## 沉淀

跨项目仍成立的个人方法才进入 Personal Skill。项目角色、项目 LOGO、具体项目禁用元素、单次需求修改留在 `project/` 或当前 request。

新的个人方法先写入：

```text
user/candidates/<skill-name>/SKILL.md
```

Skill 内容完成后，先读取 Workspace 当前机器路由表，再使用 Codex 原生 `request-user-input` 问卷只确认一次自动加载范围。问卷分两步：

```text
Q1｜希望这个 Personal Skill 在什么时候自动加载？
- 全局：所有用户业务需求
- 指定需求类型

Q2｜仅当 Q1=指定需求类型时出现
- 从当前 Workspace 真实 request_type 列表中多选一个或多个需求类型
```

Q2 的选项直接来自下面命令，不手写一份可能过时的需求类型表；展示时同时给出中文业务标签。`baseline` 是内部项目 Baseline request，不作为用户问卷选项。用户完成问卷后立即 Promote，不再用聊天重复确认。当前 host 若没有原生问卷能力，才用同样两步的精简聊天选择。

读取当前可选需求类型：

```bash
python .agents/skills/workspace-personal-skill/scripts/personal_skill.py list-request-types --workspace-root .
```

用户选择后 Promote；这次自动加载范围确认同时把 manifest 的 `enabled` 设为 `true`：

```bash
# 全局
python .agents/skills/workspace-personal-skill/scripts/personal_skill.py promote-candidate \
  --candidate user/candidates/<name>/SKILL.md --load-mode global --workspace-root .

# 指定一个或多个需求类型
python .agents/skills/workspace-personal-skill/scripts/personal_skill.py promote-candidate \
  --candidate user/candidates/<name>/SKILL.md --load-mode request_types \
  --request-type image-generation --request-type visual-packaging --workspace-root .
```

已有 Personal Skill 也可以直接 `register-skill`，规则相同。

## 可选精确加载

Personal Layer 默认关闭。只有 `user/manifest.json` 明确 `enabled=true` 时，Governance 才在业务 request 中执行 Resolver：

```bash
python .agents/skills/workspace-personal-skill/scripts/personal_skill.py resolve \
  --request-type <current_request_type> --workspace-root .
```

机器匹配规则：

```text
load_mode = global
→ 命中所有 request_type

load_mode = request_types
→ 当前 request_type 必须存在于该 Skill 的 request_types
```

Resolver 先读取 registry，只验证命中 Skill 的路径与单一文件 Hash，并返回 `load_paths`；正文由真实 consumer 按路径读取，不写入 `personal-context.json` 或 resolver 输出。未命中项不读取。若同一需求类型注册了多个 Personal Skill，则这些 Skill 都属于用户明确授权的当前需求能力，按 manifest 顺序一并加载。

Personal Layer 不存在或未开启时使用默认环境；启用但无匹配 Skill 时写入空个人上下文。命中的 Personal Skill / Preference 加载失败时由 Governance 记录异常并阻断当前 request，禁止静默回退。公共 Skill 与 Workflow 不得跳过已加载的个人上下文。

当前用户明确要求 > 当前项目事实 / Baseline > Personal Skill / Preference > 公共 Skill 默认方法。

## 更新

编辑已经注册的 `user/skills/**/SKILL.md` 后重新执行 `register-skill`，更新 Hash 与加载范围。Resolver 遇到文件 Hash 与 registry 不一致时阻塞该个人层加载，先重新注册，避免静默使用未登记版本。
