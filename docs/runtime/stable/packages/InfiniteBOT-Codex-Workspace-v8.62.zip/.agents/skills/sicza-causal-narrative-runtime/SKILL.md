---
name: sicza-causal-narrative-runtime
description: 在当前 Codex request 内解析会影响画面的因果、角色知识、关系、动作/物体状态、空间连续、叙事时刻与观众信息，并输出派生 Narrative–Visual Contract。它不建立独立正典、持久 Runtime 或项目事实 Authority。
---

# SICZA Causal Narrative Solver — Codex Integration

## 角色

这是 **当前 request 内的派生求解器**。它读取 Codex 已有 Authority，闭合会改变视觉结果的叙事语义，并把最小充分语义交给 Visual Director。

它不是第二 Runtime，不拥有 Project Fact、Request State、Baseline、Delivery、Release 或 Promote 权限。

## Authority 边界

唯一事实来源仍由 Codex Workspace 管理：

`当前用户要求 / request.md / request input / requirement-lock / source-lock / Project Brief / material-index / 用户已锁定叙事事实`

Narrative Solver：

- 只读取与当前问题有关的事实和锁定项；
- 不读取 `project/baselines/**` 作为叙事事实；Project Visual Baseline 必须等 Narrative Contract 完成后才进入 Visual Director；
- 可以生成、比较和验证当前 request 的候选叙事解释；
- 不把候选写成独立项目正典；
- 不维护 `ACTIVE / RESOLVED / HISTORICAL` 等第二套持久状态；
- 不原子提交项目事实；
- 需要改变上游事实时返回 `NEED_UPSTREAM`；
- 需要其他专业 Authority 时返回 `NEED_DOMAIN`。

参考文件中若出现“正典 / canon / owner / commit”等 standalone 术语，在本 Workspace 中只解释为“当前 Codex Authority 中已锁定、不可由本 Solver 擅改的事实”，**不得据此获得写权限**。

## 路由

Visual 任务先判断是否需要 Narrative：

| route | 使用条件 | 行为 |
|---|---|---|
| `NONE` | 纯构图、光材质、排版、成像、视觉层级等，不存在会改变画面的叙事歧义 | 不调用本 Skill |
| `HANDOFF_ONLY` | 事件、角色状态、起终点、剧情已经锁定，只需要 R09 编译视觉证明义务 | 不重写故事；只输出合同 |
| `SOLVE` | 因果、角色知识、动作/物体/空间状态、叙事时刻尚未闭合 | 最小模块求解后输出合同 |
| `REPAIR` | 现有叙事输入存在矛盾、跳变、知识泄漏或不可视觉化 | R10 定位第一断点，再回对应领域修复 |

`HANDOFF_ONLY / SOLVE / REPAIR` 都只服务当前 request。

## 专业定义权

| 问题 | 模块 |
|---|---|
| 状态为什么从 A 变成 B | R01 Story State & Causality |
| 角色为什么会这样做 / 知道什么 | R02 Character & Knowledge |
| 多人如何互相影响 | R03 Relationships & Interaction |
| 身体、接触、受力、阻挡是否成立 | R04 Physical Action & Blocking |
| 物体、路径、可达性、环境连续 | R05 Objects, Environment & Space |
| 制度、社会、历史系统约束 | R06 World Systems |
| 哪个合法方案更有体验价值 | R07 Experience Design |
| 场景/节拍/时间/终局结构 | R08 Narrative Architecture |
| 决定性时刻、观众信息、视觉证明义务 | R09 Camera & Readability |
| 诊断第一断点与最小修复 | R10 Diagnostic & Repair |

默认只加载 `1 个主模块 + 0–2 个依赖模块`。不得为了“完整”全库加载。

## 运行模式

按 [`runtime-mode-manifest.md`](references/runtime/runtime-mode-manifest.md) 读取参考文件。按行读取前必须校验 [`runtime-mode-integrity.json`](config/runtime-mode-integrity.json)；Hash 不一致或运行时不支持按行读取时整份读取。

常用最小组合：

- 已锁故事视觉化：`R09.VISUAL_CONTRACT`；
- 单一状态变化：`R01.CAUSAL_TRANSITION + R09`；
- 角色选择：追加 `R02.GOAL_POLICY / KNOWLEDGE_BELIEF`；
- 多人关系：追加 R03；
- 高风险身体/车辆/绳索动作：追加 R04；
- 物体/路线/环境连续：追加 R05；
- 故事结构问题：R08；
- 已存在矛盾：先 R10，再回第一断点模块。

## 当前 request 的临时投影

需要结构化中间状态时，只允许保存 **可丢弃的工作投影**，例如：

```yaml
narrative_projection:
  request_ref:
  route: HANDOFF_ONLY | SOLVE | REPAIR
  locked_inputs:
  observed_state:
  candidate_delta:
  unresolved:
  first_breakpoint:
```

它不是 Authority：

- 不进入 `project/`；
- 不替代 `request.md / requirement-lock / Project Brief`；
- 与上游 Authority 冲突时直接废弃并重建；
- Promote 后不作为新的项目事实源。

## 候选与选择

候选只允许当前 request 生命周期：

`PROPOSED → SELECTED → VALIDATED`

失败候选直接丢弃。没有 `ACTIVE` 或第二套历史状态。

验证至少覆盖当前启用模块的：

- 前置条件；
- 状态传播；
- 角色知识；
- 物体/路径/空间连续；
- 事件结果；
- 观众信息；
- 与当前 Authority 的不变量一致性。

## Return 语义

本 Skill 只返回以下结构化结果给当前 Primary Skill：

| result | 含义 | Codex 动作 |
|---|---|---|
| `READY` | Narrative Contract 可供 Visual Director 消费 | 写 `work/narrative-visual-contract.json`，继续 Visual Spec |
| `NEED_UPSTREAM` | 上游需求/事实/锁定项缺失或矛盾 | 当前 request 保持 active/blocked，由 Primary Skill 回需求层处理 |
| `NEED_DOMAIN` | 需要视觉/叙事之外的专业事实 | 当前 request 内调用对应专家/可靠事实源 |
| `PRESENTATION_UNSATISFIABLE` | 当前已锁事实无法同时满足视觉证明义务 | 不改故事；返回上游决策 |

不得创建第二个辅助 request 来表达这些状态。`NEED_UPSTREAM / NEED_DOMAIN / PRESENTATION_UNSATISFIABLE` 必须由当前 Primary Skill 写成 `work/visual-return.json`（Schema `.agents/skills/workspace-governance/config/visual-contracts/visual-return-schema.json`）并保持当前 request active/blocked。

## Narrative–Visual Contract

唯一机器合同：

- Schema：`.agents/skills/workspace-governance/config/visual-contracts/narrative-visual-contract-schema.json`
- 固定路径：`<request>/work/narrative-visual-contract.json`
- 说明：[`runtime-narrative-visual-contract.md`](references/runtime/runtime-narrative-visual-contract.md)

核心字段：

```json
{
  "schema_version": "sicza.narrative-visual-contract.v2",
  "request_ref": "requests/...",
  "request_id": "<64hex>",
  "request_revision": 1,
  "request_fingerprint": "<64hex>",
  "contract_id": "...",
  "contract_revision": 1,
  "route": "HANDOFF_ONLY",
  "result": "READY",
  "authority_trace": [],
  "selected_moment_or_windows": [],
  "protected_narrative_truth": [],
  "must_show": [],
  "may_show": [],
  "must_not_imply": [],
  "audience_information": [],
  "causal_evidence": [],
  "continuity_obligations": [],
  "open_issues": [],
  "semantic_checksum": "<sha256>"
}
```

`authority_trace` 必须绑定真实 Workspace 文件及 SHA-256。`semantic_checksum` 由：

```text
python .agents/scripts/visual_contract_gate.py stamp-narrative --file <request>/work/narrative-visual-contract.json
python .agents/scripts/visual_contract_gate.py validate-narrative --file <request>/work/narrative-visual-contract.json --workspace-root .
```

生成/验证，不允许凭手写自证。

## R09 交接边界

R09 只定义：

- 决定性时刻/窗口；
- 哪些叙事事实必须保护；
- 必须显示、允许显示、不得暗示；
- 观众当前应该知道什么；
- 哪些可见证据证明因果；
- 连续性义务。

R09 不拥有最终 Blocking、镜头设计、构图、光材质、成像、Graphic Communication 或品牌视觉身份；这些归 `$sicza-visual-director`。

## Visual 交接

合法链路：

```text
Codex Authority
→ [NONE | HANDOFF_ONLY | SOLVE | REPAIR]
→ Narrative–Visual Contract（需要时）
→ Canonical work/visual-spec.json
→ Prompt Binding
→ 当前 Primary Skill 的执行与 Gate
```

Narrative Contract 的 `semantic_checksum` 必须进入 Visual Spec 的 `narrative_trace`；Visual Director 不得静默改变它。

## 诊断原则

修复遵循：

`症状 → 可见/可验证证据 → 第一断点 → 最小必要模块 → 修复候选 → 重模拟 → 回归`

禁止：

- 为了视觉更强而改已锁定人物、事件或世界事实；
- 角色使用不可能知道的信息；
- 用“后来发生了什么”解释状态跳变；
- 为局部问题无理由重写整段故事；
- 把视觉风格 Baseline 当成叙事事实；
- 把 Prompt 阶段新增内容反向合理化成故事事实；
- 在本 Skill 内发布、Promote 或写项目 Baseline。

## 输出纪律

用户可见输出服从用户要求。内部合同和投影只用于当前 request 运行与证据链；除非用户要求审计，不输出内部路由、自证过程或全量状态表。
