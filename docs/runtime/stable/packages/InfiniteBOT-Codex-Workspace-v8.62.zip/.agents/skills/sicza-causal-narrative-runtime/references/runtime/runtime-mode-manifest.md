# 运行模式清单

`当前问题 → 通用段 → 当前模式 → 必要 request-local 投影`

## r01-story-state-and-causality.md
- **COMMON** → 行 1-142，348-423
- **CAUSAL_TRANSITION** → 行 145-205，268-308
- **CHOICE_CONFLICT_PRESSURE** → 行 206-267
- **EVENT_VALUE** → 行 309-347

## r02-character-and-knowledge.md
- **COMMON** → 行 1-142，430-540
- **GOAL_POLICY** → 行 143-181，217-292，336-390
- **KNOWLEDGE_BELIEF** → 行 182-216
- **COMMITMENT_CAPABILITY** → 行 293-335
- **LEARNING_ARC** → 行 391-429

## r03-relationships-and-interaction.md
- **COMMON** → 行 1-123，504-604
- **RELATIONSHIP** → 行 124-186，237-250，451-467
- **COORDINATION_ATTENTION** → 行 187-236，251-317
- **COMMUNICATION** → 行 318-425
- **BLOCKING_INTERACTION** → 行 426-450，468-503

## r04-physical-action-and-blocking.md
- **CORE_MECHANICS** → 行 3-385，475-573
- **FIREARM** → 行 386-409
- **ROPE_CABLE** → 行 410-425
- **VEHICLE** → 行 426-443
- **CLIMB_HANG** → 行 444-458
- **MELEE** → 行 459-474

## r05-objects-environment-and-space.md
- **COMMON** → 行 1-163，533-629
- **OBJECT** → 行 164-250
- **TOPOLOGY_ROUTE** → 行 251-305，432-450，488-532
- **VISIBILITY_REACHABILITY** → 行 306-359
- **SUPPORT_HAZARD_RESIDUE** → 行 360-431
- **ENVIRONMENT_FUNCTION** → 行 451-487

## r06-world-systems.md
- **COMMON** → 行 3-57，762-959
- **INSTITUTIONAL** → 行 58-269
- **SOCIOCULTURAL** → 行 270-506
- **HISTORICAL** → 行 507-761

## r07-experience-design.md
- **COMMON** → 行 3-60，662-868
- **VALUE_GATE** → 行 621-661
- **EMOTION** → 行 61-205
- **THEME** → 行 206-313
- **GENRE_TONE** → 行 314-435
- **CREATIVE_DIVERGENCE** → 行 436-620

## r08-narrative-architecture.md
- **COMMON** → 行 3-46，883-1067
- **HIERARCHY** → 行 47-315
- **TEMPORAL** → 行 316-469
- **DEPENDENCY** → 行 470-655
- **TERMINAL** → 行 656-882

## r09-camera-and-readability.md
- **COMMON** → 行 3-119，行 557-664
- **MOMENT** → 行 120-204
- **AUDIENCE_INFO** → 行 205-310
- **CAMERA_READABILITY** → 行 311-509
- **VISUAL_CONTRACT** → 行 510-556

## r10-diagnostic-and-repair.md
- **COMMON** → 行 3-84，563-708
- **DIAGNOSE** → 行 85-331
- **REPAIR** → 行 332-454
- **VERIFY** → 行 455-562

## 读取规则

- 存在 `COMMON` 时必须读取 `COMMON + 当前模式`。
- R04 的 `CORE_MECHANICS` 是公共物理底座；启用 `FIREARM / ROPE_CABLE / VEHICLE / CLIMB_HANG / MELEE` 时必须同时读取 `CORE_MECHANICS`。
- 所有模式行范围互不重叠。
- 按行读取前必须校验 `../../config/runtime-mode-integrity.json`。
- Hash 一致且运行时支持按行读取时，才能使用行范围。
- Hash 不一致、无法校验 Hash、或运行时不支持按行读取时，必须整份读取；必要时重建清单与完整性表。
