# Request-local Narrative Projection Contract

本文件定义的只是当前 Codex request 的 **临时叙事投影**，不是项目正典、数据库或第二 Runtime。

## 1. Authority

所有不可擅改事实来自现有 Codex Authority：当前用户要求、`request.md`、request input、`requirement-lock`、`source-lock`、Project Brief、material index 或其他已明确授权的事实源。

Narrative Solver 不拥有上述文件的写权限。需要改变上游事实时返回 `NEED_UPSTREAM`。

## 2. 临时投影

```yaml
narrative_projection:
  request_ref:
  route: HANDOFF_ONLY | SOLVE | REPAIR
  locked_inputs:
  observed_state:
  candidate_delta:
  unresolved:
  first_breakpoint:
```

规则：

- 只允许放在当前 request 的 `work/` 中；
- 可随时删除并由 Authority 重建；
- 不使用 `ACTIVE / RESOLVED / HISTORICAL` 等持久状态；
- 不执行项目事实 commit；
- 不进入 `project/`；
- 与上游 Authority 冲突时投影作废。

## 3. 候选状态

当前 request 内候选只使用：

`PROPOSED → SELECTED → VALIDATED`

失败候选删除，不形成历史事实层。

## 4. 视觉交接

只有 `READY` 时才能写 `work/narrative-visual-contract.json`。合同的 Authority path/hash 和 `semantic_checksum` 必须通过 `.agents/scripts/visual_contract_gate.py` 验证。

## 5. Return

- `READY`：继续 Visual Spec。
- `NEED_UPSTREAM`：回当前 request 的需求/事实层。
- `NEED_DOMAIN`：调用对应专业 Authority。
- `PRESENTATION_UNSATISFIABLE`：已锁事实与呈现义务不可同时满足；不得由 Narrative/Visual 层擅改上游事实。
