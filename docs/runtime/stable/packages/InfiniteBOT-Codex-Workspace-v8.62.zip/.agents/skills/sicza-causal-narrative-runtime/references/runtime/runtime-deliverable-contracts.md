# Request-local Narrative Deliverables

本 Skill 不发布用户交付物，只向当前 Primary Skill 返回派生语义。

| 当前问题 | 最低派生结果 | 假完成 |
|---|---|---|
| 状态变化 | 起始状态 + trigger + change + result + persistent consequence | 只说“发生变化” |
| 角色选择 | 目标/知识/约束 + 可执行选择 + 结果 | 角色知道不可能知道的信息 |
| 多人关系 | action → condition → reaction | 并列动作没有互相影响 |
| 物体/空间 | 物体状态 + 路径/接触/可达性 + 变化 | 瞬移、无因重置 |
| 桥接 | 起点 + 终点 + 必要前置 + 中间铰链 + 持久变化 | “一番过程后”跳过桥接 |
| 修复 | 缺陷 + 第一断点 + 不变量 + 最小修复 + 重模拟结果 | 只改表述不修逻辑 |
| 视觉化 | `sicza.narrative-visual-contract.v2` + semantic checksum | 为构图改故事 |

视觉化只使用 `.agents/skills/workspace-governance/config/visual-contracts/narrative-visual-contract-schema.json`；不得在本文件维护第二套字段。
