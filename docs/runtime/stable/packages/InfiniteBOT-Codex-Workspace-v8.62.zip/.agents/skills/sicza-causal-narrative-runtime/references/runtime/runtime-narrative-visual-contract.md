# Narrative–Visual Derived Contract

## Authority

这是当前 Codex request 的派生合同，不是第二事实源。唯一机器 Schema：

`.agents/skills/workspace-governance/config/visual-contracts/narrative-visual-contract-schema.json`

固定文件：

`<request>/work/narrative-visual-contract.json`

## 路由

- `HANDOFF_ONLY`：故事已锁定，只由 R09 编译呈现义务；禁止重新编故事。
- `SOLVE`：先闭合会改变画面的叙事语义，再编译合同。
- `REPAIR`：先定位第一断点并修复当前 request 的候选语义，再编译合同。

纯视觉问题使用 `NONE`，不生成合同。

## Canonical Machine Shape

```json
{
  "schema_version": "sicza.narrative-visual-contract.v2",
  "request_ref": "requests/<type>/<request>",
  "request_id": "<64hex>",
  "request_revision": 1,
  "request_fingerprint": "<64hex>",
  "contract_id": "request-local-stable-id",
  "contract_revision": 1,
  "route": "HANDOFF_ONLY",
  "result": "READY",
  "authority_trace": [
    {"role": "current_request", "path": "requests/.../request.md", "sha256": "<64hex>"}
  ],
  "selected_moment_or_windows": [],
  "protected_narrative_truth": [],
  "must_show": [],
  "may_show": [],
  "must_not_imply": [],
  "audience_information": [],
  "causal_evidence": [],
  "continuity_obligations": [],
  "open_issues": [],
  "semantic_checksum": "<64hex>"
}
```

## Authority Trace

每条记录必须指向真实 Workspace 文件并绑定 SHA-256。允许角色以 Schema 为准。Visual 层不得把自己的推断写回 `authority_trace`。

## semantic_checksum

只覆盖会影响视觉语义的合同字段，不覆盖路径、request identity / revision 等元数据。由机器脚本生成并验证：

```text
python .agents/scripts/visual_contract_gate.py stamp-narrative --file <request>/work/narrative-visual-contract.json
python .agents/scripts/visual_contract_gate.py validate-narrative --file <request>/work/narrative-visual-contract.json --workspace-root .
```

合同语义变化时 checksum 必须变化；仅元数据变化不应伪造语义变化。

## Result

Narrative–Visual Contract 只承载 `READY` handoff，且 `open_issues` 必须为空。

失败不写成第二种合同：`NEED_UPSTREAM / NEED_DOMAIN / PRESENTATION_UNSATISFIABLE` 统一由当前 Primary Skill 写 `work/visual-return.json`，Schema 为 `.agents/skills/workspace-governance/config/visual-contracts/visual-return-schema.json`。因此 `visual-spec.json` 永远不会消费失败合同。

## Visual 边界

合同只定义叙事证明义务，不定义最终：Blocking、镜头、构图、光、材质、色彩、成像、图形传播、品牌识别。Visual Director 只能在不改变本合同语义的前提下完成视觉构建。
