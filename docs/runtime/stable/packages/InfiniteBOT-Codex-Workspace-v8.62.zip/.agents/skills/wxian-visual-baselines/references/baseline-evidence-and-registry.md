# Baseline Consumption

Baseline 是项目视觉先验与最低合格线，不是每次请求的报账清单，也不是已有 Family 白名单。

## Evidence role registry

存储路径只提供默认分类，不能决定证据权威。若 `project/references/**` 中包含历史正式产出，必须新增 `project/evidence-registry.json` 明确声明：

```json
{
  "schema_version": 1,
  "sources": [
    {
      "source_path": "project/references/kv/1.png",
      "evidence_role": "historical-project-output",
      "provenance": "PNS historical KV output",
      "authority_scope": "historical visual production evidence only"
    }
  ]
}
```

`historical-project-output` 可以证明项目过去实际采用过的视觉语言，但不能证明永久玩法、剧情、版权或角色身份；`external-reference` 只证明可借鉴的视觉方法。Source Manifest 与单图分析会绑定这三个字段，注册内容变化会使旧分析失效。

只有 Baseline **实际改变当前判断**时才写 `work/baseline-consumption.json`。记录当前是沿用已有先验、建立新方向，还是只消费身份资产；再记录真正相关的 Family / Floor / Character / Reference。不要为无关内容写 N/A。

`consumer` 是 Baseline 契约的 machine key，不是 Skill 名。唯一映射：

| Primary Skill | `consumer` / `--consumer-name` |
|---|---|
| `wxian-visual-packaging` | `visual-packaging` |
| `wxian-image-production` | `image-production` |
| `wxian-image-layer-decomposition` | `layer-decomposition` |
| `sicza-game-concept-lab` | `game-concept-lab` |
| `wxian-kv-micro-animation` | `kv-micro-animation` |
| `wxian-visual-competitive-analysis` | `visual-competitive-analysis` |
| `wxian-visual-scorecard`（仅实际消费 Baseline 时） | `visual-scorecard` |

Canonical receipt 固定为当前 request 的 `work/baseline-consumption.json`，Schema 为 `.agents/skills/workspace-governance/config/visual-contracts/baseline-consumption-schema.json`。它不仅记录 Family/Floor/Character/Reference，还必须绑定当前 `request_id / request_revision / request_fingerprint`、正式 Baseline path/hash 与 Baseline index path/hash。不要手写简化版 JSON；先读取 Schema，并用：

```text
python .agents/scripts/visual_contract_gate.py identity --request <request> --workspace-root .
python .agents/skills/wxian-visual-baselines/scripts/baseline_consumption.py \
  --baseline project/baselines/project-visual-standard.md \
  --consumer <request>/work/baseline-consumption.json \
  --consumer-name <registered-consumer> \
  --workspace-root .
```

验证。旧版只有 `baseline_sha256 / consumer / mode` 的简化记录不再是合法机器合同。
验证器只确认引用是否真实、Floor 覆盖是否有明确理由、Reference 是否属于正式 Baseline。`novel-direction` 明确允许不选择任何已有 Family；这不是绕过 Baseline，而是用 Baseline Floor 保证“像项目”的底线，同时保留创意上限。
