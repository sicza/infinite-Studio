#!/usr/bin/env python3
"""Validate a canonical request-bound Project Visual Baseline consumption receipt."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path

AGENTS_ROOT=Path(__file__).resolve().parents[3]
if str(AGENTS_ROOT/'lib') not in sys.path: sys.path.insert(0,str(AGENTS_ROOT/'lib'))
from visual_contracts import VisualContractError, validate_baseline_consumption, workspace_relative

CONSUMERS={'visual-packaging','image-production','layer-decomposition','game-concept-lab','kv-micro-animation','visual-competitive-analysis','visual-scorecard'}


def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--baseline',required=True)
    ap.add_argument('--consumer',required=True,help='canonical request work/baseline-consumption.json')
    ap.add_argument('--consumer-name',choices=tuple(sorted(CONSUMERS)),required=True)
    ap.add_argument('--stage',choices=('initial','final'),default='initial',help='compatibility only; validation is identical')
    ap.add_argument('--workspace-root',type=Path,default=Path(__file__).resolve().parents[4])
    a=ap.parse_args(); root=a.workspace_root.resolve()
    try:
        obj=validate_baseline_consumption(root,(root/a.consumer).resolve() if not Path(a.consumer).is_absolute() else Path(a.consumer).resolve())
        baseline=(root/a.baseline).resolve() if not Path(a.baseline).is_absolute() else Path(a.baseline).resolve()
        if obj['baseline_path'] != workspace_relative(root,baseline):
            raise VisualContractError('CLI baseline does not match canonical Baseline receipt')
        if obj['consumer'] != a.consumer_name:
            raise VisualContractError('CLI consumer-name does not match Baseline receipt consumer')
        print(json.dumps({'status':'passed','stage':a.stage,'schema_version':obj['schema_version'],'request_ref':obj['request_ref'],'request_revision':obj['request_revision'],'consumer':obj['consumer'],'mode':obj['mode'],'baseline_sha256':obj['baseline_sha256']},ensure_ascii=False,indent=2)); return 0
    except (VisualContractError,OSError,json.JSONDecodeError,ValueError) as e:
        print(json.dumps({'status':'blocked','reason':str(e)},ensure_ascii=False,indent=2)); return 1

if __name__=='__main__': raise SystemExit(main())
