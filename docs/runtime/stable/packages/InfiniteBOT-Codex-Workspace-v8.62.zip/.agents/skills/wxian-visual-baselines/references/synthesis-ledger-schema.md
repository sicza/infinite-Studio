# Synthesis Ledger Schema 1

```json
{
  "schema_version": 1,
  "project_context_sha256": "...",
  "source_set_sha256": "...",
  "claims": [
    {
      "claim_id": "visual-hierarchy-01",
      "claim_type": "project-identity|output-landscape|visual-dna|historical-prior|floor-candidate|boundary|innovation-opportunity|identity-system",
      "statement": "具体的项目级判断",
      "scope": "在哪些任务/产出中成立",
      "baseline_role": "prior|floor-candidate|identity|boundary|opportunity",
      "confidence": "high|medium|low",
      "evidence_paths": ["project/baselines/analyses/..."],
      "counterevidence_paths": [],
      "differentiation_test": "为什么这不是换个同类项目也成立的通用废话",
      "one_shot_effect": "它会改变下一稿的哪个具体设计决策"
    }
  ],
  "analysis_participation": {
    "project/baselines/analyses/...": ["visual-hierarchy-01"]
  }
}
```

Ledger 是证据层，不是下游日常消费正文。所有正式深度分析都必须参与至少一条 claim，但最终 Baseline 不要求逐图复述。
