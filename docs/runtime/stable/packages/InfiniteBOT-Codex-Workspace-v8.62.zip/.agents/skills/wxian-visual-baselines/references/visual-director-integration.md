# Visual Director Integration for Project Visual Baseline

`wxian-visual-baselines` 是唯一 Baseline Authority；本文件只提供分析维度与可生成语法的专业词汇。

## 使用方式

在 Whole-set Gestalt、Evidence Matrix、Visual DNA 与 Family 综合时，按证据需要调用 `$sicza-visual-director BASELINE_DELTA` 的以下模块：

- `D-GRAMMAR`：哪些视觉关系是稳定语法；
- `D-STYLE`：风格化发生在哪些可控维度，而不是“某某风”；
- `D-SIGN`：项目识别特征如何在不同资产保持；
- `D-MEM`：哪些结构真正形成记忆；
- `D-SERIES`：多资产共享语法与允许变化；
- `H-MULTISCALE`：缩略图/正常观看/放大时各读什么；
- `G-VERIFY`：图形传播与多语言是否在真实载体成立。

## 不能复制的东西

- 不把 Visual Director 的 `visual_projection` 当第二份项目 Baseline；
- 不建立第二份 Family registry；
- 不把历史高频风格自动升级成 Floor；
- 不把通用视觉规律写成项目 DNA；
- 不因“可生成”抹掉真实历史反例。

## Baseline 应新增的质量判断

项目级结论除区分度/反例/因果测试外，还应能回答：

1. 关系与空间：哪些对象关系最能让画面像这个项目；
2. 表演：角色如何行动而不是如何站立；
3. 投影：什么镜头/深度组织是真正高频有效，什么只是一次性；
4. 外观：光材质如何区分身份、空间和状态；
5. 图像结构：明暗、色彩、细节频率与静默区如何分配；
6. 成像：哪些镜头/焦点/颗粒/动态采样属于稳定成像语法；
7. 感知：第一读、第二读与缩略图读形；
8. 身份：识别特征、记忆锚点、允许变化与漂移；
9. 图形：标题、Logo、UI、多语言如何与图像形成系统。

没有足够证据的维度标 `unknown / insufficient-evidence`，不补全。


## Authority Lock

Visual Director 只能返回 `baseline_delta`；正式 Schema 8、revision、publication receipt、路径与 complete gate 仍只由 `wxian-visual-baselines` 写入和验证。
