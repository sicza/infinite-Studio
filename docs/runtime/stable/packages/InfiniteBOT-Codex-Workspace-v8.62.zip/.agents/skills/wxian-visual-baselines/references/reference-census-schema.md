# Reference Visual Census

仅在 unique `project/references/**` >100 时使用。<=100 张全部做深度反推；更大集合才先让**每张 Reference 至少被视觉判断一次**，再决定哪些图值得做昂贵的逐图深度反推。

输出：`work/project-visual-standard/reference-census.json`

```json
{
  "schema_version": 1,
  "project_context_sha256": "<sha256>",
  "sources": [
    {
      "source_path": "project/references/kv/17.png",
      "source_sha256": "<sha256>",
      "hook_type": "ui-choice",
      "narrative_mode": "gameplay-choice",
      "composition_mode": "split-choice",
      "tone": "high-contrast-action",
      "text_ui_load": "heavy",
      "cluster_id": "gameplay-choice-kv",
      "outlier": false,
      "distinguishing_cue": "左右两条高对比选择路径夹住中央角色，用大数字和按钮把玩法决策置于第一视觉层级"
    }
  ],
  "clusters": [
    {
      "cluster_id": "gameplay-choice-kv",
      "cluster_name": "玩法选择型 KV",
      "definition": "以选择、数值、路径或 UI 决策作为首要点击钩子，角色和环境为玩法信息服务",
      "production_use": "适合需要一眼读懂操作选择、收益差异或路线决策的效果广告与玩法 KV"
    }
  ]
}
```

要求：

- 每个 unique Reference 恰好出现一次；
- `cluster_id` 描述视觉机制，不能直接写 `kv`、`banner` 或目录名；
- `distinguishing_cue` 必须来自当前图片，不得三张以上机械复制同一句；
- Cluster ≥4 张时应存在清晰的叙事+构图主模式；若成员差异太大，应继续拆 Cluster；
- 单张 Cluster 只能作为明确 outlier；
- Census 只负责分类和覆盖，不替代逐张深度反推。
