# Project Visual Baseline Schema 8

## 1. 基准定位
```text
schema_version: 8
baseline_status: usable
character_identity_status: established|partial|none
brand_identity_status: established|partial|none
reference_playbook_status: established|partial|none
project_context_sha256:
source_set_sha256:
source_count:
baseline_scope:
project_visual_summary:
authority_boundary:
baseline_role: floor-not-ceiling
```

## 2. 项目视觉认知
```text
project_identity:
production_context:
visual_job:
current_output_landscape:
signature_impression:
recognition_system:
default_visual_hierarchy:
recurring_tensions:
quality_bar_character:
not_the_project:
```

## 3. 当前产出结构
每个历史产出 Family：
```text
family_id:
family_name:
family_authority: project-evidence|reference-playbook
cluster_ids:
presence: dominant|common|secondary|rare|outlier
observed_source_count:
deep_analysis_count:
business_job:
dominant_visual_question:
what_it_looks_like:
visual_hierarchy:
composition_camera:
color_light_material:
character_environment_relation:
text_logo_ui:
typical_variants:
failure_modes:
start_when:
do_not_use_when:
evidence:
```

## 4. 跨产出视觉 DNA
```text
dna_id:
presence: core|frequent|situational
statement:
project_specificity:
one_shot_effect:
scope:
counterexamples:
evidence:
```

## 5. 产出差异决策
两个以上主要 Family 时至少写一组：
```text
comparison_id:
between: family-a|family-b
shared_core:
decisive_difference:
choose_first_when:
choose_second_when:
do_not_merge:
evidence:
```

## 6. 角色与品牌身份
沿用经过二次验证的角色 Production Card / Brand Card 引用与简要摘要。

## 7. Baseline Floor｜最低合格线
```text
floor_id:
floor_type: project-likeness|identity|brand|quality|readability|asset-boundary
requirement:
scope:
why_floor:
evidence:
```

## 8. 创新空间｜Baseline 不是上限
```text
baseline_role: floor-not-ceiling
existing_families_are: priors-not-whitelist
mature_spaces:
underexplored_spaces:
new_direction_rule:
do_not_freeze:
variation_axes:
failure_mode:
```

## 9. 一稿校准
```text
route_id:
when:
start_family_ids:
required_floor_ids:
first_three_decisions:
preserve:
can_break:
failure_check:
success_check:
```
必须存在 `start_family_ids: none` 的新方向路径。

## 10. 证据边界与刷新
```text
deep_analysis_coverage: 100%
reference_census_coverage: 100%|not-required
synthesis_ledger: project/baselines/synthesis-ledger.json
known:
unknown:
never_infer:
refresh_when:
```
