#!/usr/bin/env python3
"""Validate complete per-image reverse analysis and publish one project Baseline."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import re
import shutil
import sys
import tempfile
from collections import Counter
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any

AGENTS_ROOT = Path(__file__).resolve().parents[3]
if str(AGENTS_ROOT / "lib") not in sys.path:
    sys.path.insert(0, str(AGENTS_ROOT / "lib"))
from asset_taxonomy import (
    props_location_report,
    canonical_kind as canonical_asset_kind,
    is_legacy_prop,
    evidence_defaults as asset_evidence_defaults,
    identity_authority_for as asset_identity_authority,
    is_prop_parts as is_prop_asset,
    REQUIRED_SELECTION_KINDS,
    STORAGE_OWNED_KINDS,
)
from text_integrity import TextIntegrityError, read_utf8, validate_tree
from atomic_io import atomic_write_text
from baseline_contract import (
    BASELINE_SCHEMA,
    BASELINE_INDEX_SCHEMA,
    project_context_sha256 as shared_project_context_sha256,
)

try:
    from PIL import Image
except ImportError:
    Image = None


IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif", ".tif", ".tiff"}
REQUIRED_ANALYSIS_SECTIONS = (
    "## 1. 源绑定",
    "## 2. 故事性画面描述",
    "## 3. 核心主题、构图与镜头",
    "## 4. 视觉风格与质感",
    "## 5. 角色动作与神态",
    "## 6. 角色身份反推",
    "## 7. 远景、中景与近景",
    "## 8. 可复用中文正向 Phrase",
    "## 9. 完整中文正向反推提示词",
    "## 10. 单图可复用价值",
    "## 11. 事实、判断与不确定项",
    "## 12. 上层 Skill 可用摘要",
)
REVERSE_ANALYSIS_SKILL_VERSION = "reverse-analysis-v2"
REVERSE_ANALYSIS_CONTRACT_VERSION = 2
VISUAL_GROUNDING_GATE_VERSION = 2
CONTRACT_FIELD_PAYLOAD = "reference-analysis-v2|" + "|".join((
        "source_path", "source_sha256", "source_kind", "source_label", "character_id",
        "identity_authority", "evidence_role", "provenance", "authority_scope", "dimensions",
        "analysis_contract_version", "analysis_contract_sha256", "reverse_analysis_skill_version",
        "visual_grounding_gate_version", "story", "blind_reconstruction", "subject_map",
        "focal_hierarchy", "visual_route", "composition_coordinates", "camera", "text_ui",
        "rendering", "material_fx", "color_light", "light_causality", "actions",
        "environment_role", "positive_prompt", "transferable_mechanisms", "production_use",
    ))
PROFESSIONAL_OUTPUT_MARKERS = (
    "visual-synthesis.md", "synthesis-ledger.json", "project-visual-standard.md", "character-profiles",
    "visual_mother:", "signature_terms:", "family_id:", "prompt_module_id:",
)


class BaselineGateError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise BaselineGateError(message)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def bounded_path(root: Path, value: str, *, must_exist: bool = False) -> Path:
    path = Path(value)
    if not path.is_absolute():
        path = root / path
    resolved = path.resolve()
    require(resolved == root or root in resolved.parents, f"path escapes Workspace: {value}")
    if must_exist:
        require(resolved.exists(), f"path does not exist: {value}")
    return resolved


def relative(root: Path, path: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def request_path(root: Path, value: str) -> Path:
    request = bounded_path(root, value, must_exist=True)
    parts = request.relative_to(root).parts
    require(len(parts) == 3 and parts[0].lower() == "requests" and request.is_dir(),
            "request must be requests/<type>/<request>")
    return request


def work_root(request: Path) -> Path:
    return request / "work" / "project-visual-standard"


def load_json(path: Path) -> dict[str, Any]:
    require(path.is_file(), f"JSON file not found: {path}")
    try:
        value = json.loads(read_utf8(path))
    except (json.JSONDecodeError, TextIntegrityError) as exc:
        raise BaselineGateError(f"invalid or corrupted JSON: {path}: {exc}") from exc
    require(isinstance(value, dict), f"JSON root must be an object: {path}")
    return value


def write_json(path: Path, value: dict[str, Any]) -> None:
    atomic_write_text(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def reverse_analysis_contract_sha256(root: Path) -> str:
    files = [
        root / ".agents/skills/wxian-visual-reverse-analysis/SKILL.md",
        root / ".agents/skills/wxian-visual-reverse-analysis/references/reference-analysis-template.md",
        root / ".agents/skills/wxian-visual-reverse-analysis/references/reverse-analysis-prompt.md",
        root / ".agents/skills/wxian-visual-reverse-analysis/references/visual-fact-vs-judgement.md",
    ]
    digest = hashlib.sha256(CONTRACT_FIELD_PAYLOAD.encode("utf-8"))
    for path in files:
        require(path.is_file(), f"reverse-analysis contract file is missing: {path}")
        digest.update(path.relative_to(root).as_posix().encode("utf-8")); digest.update(b"\0"); digest.update(path.read_bytes()); digest.update(b"\0")
    return digest.hexdigest()


def validate_generated_text_tree(root: Path, label: str) -> dict[str, int]:
    try:
        return validate_tree(root, suffixes={".md", ".json", ".txt", ".yaml", ".yml", ".csv"})
    except TextIntegrityError as exc:
        raise BaselineGateError(f"{label} text integrity failed: {exc}") from exc


CHARACTER_MARKERS=("character","characters","角色","人物","立绘","portrait","avatar","hero")
GAMEPLAY_MARKERS=("gameplay","game-screenshot","screenshots","screenshot","玩法","截图")
REFERENCE_MARKERS=("reference","references","参考")
ENTITY_STOPWORDS={"核心角色","角色","主角","人物","英雄","形态","角色设定","立绘","项目","游戏","当前","以及","and","with",
                  "png","jpg","jpeg","webp","gif","bmp","tif","tiff","image","images","file","asset","assets","visual"}

def verified_entity_facts(root: Path) -> list[tuple[str, str]]:
    brief=root/"project"/"project-brief.md"
    if not brief.is_file(): return []
    text=brief.read_text(encoding="utf-8")
    return [(claim.strip(), evidence.split("#",1)[0].strip()) for claim, evidence in re.findall(
        r"(?im)^\s*-\s*entity:\s*(.+?)\s*\|\s*evidence:\s*`([^`]+)`\s*$", text)]

def verified_entity_terms(root: Path) -> set[str]:
    terms=set()
    for claim, _ in verified_entity_facts(root):
        # English/alphanumeric names are stable tokens.
        for token in re.findall(r"[A-Za-z][A-Za-z0-9_-]{2,}", claim):
            value=token.casefold().strip("_- ")
            if value and value not in ENTITY_STOPWORDS: terms.add(value)
        # Chinese entity facts are usually short names embedded in phrases such as “核心角色为斯嘉丽与露娜”.
        cleaned=claim
        for phrase in ("是当前项目核心角色","是当前核心角色","是核心角色","核心角色包括","核心角色为","主角包括","主角为","角色包括","角色为","当前项目核心角色","当前核心角色"):
            cleaned=cleaned.replace(phrase,"|")
        for part in re.split(r"[|、，,；;：:/\s]+|和|与|及",cleaned):
            value=part.strip("：:。 ._- ").casefold()
            value=re.sub(r"^(?:核心角色|主角|角色)","",value)
            value=re.sub(r"(?:核心角色|主角|角色)$","",value)
            if 2<=len(value)<=12 and re.fullmatch(r"[\u4e00-\u9fff]+",value) and value not in ENTITY_STOPWORDS:
                terms.add(value)
    return terms

def entity_evidence_keys(path: Path, root: Path) -> list[str]:
    rel=path.relative_to(root).as_posix()
    keys=[]
    for claim, evidence in verified_entity_facts(root):
        if evidence == rel and path.suffix.lower() in IMAGE_EXTENSIONS:
            digest=hashlib.sha256((claim+"\n"+evidence).encode("utf-8")).hexdigest()[:12]
            keys.append(f"__entity_evidence__:{digest}")
    return sorted(set(keys))

def identity_keys(path: Path, root: Path) -> list[str]:
    parts=tuple(part.casefold() for part in path.relative_to(root).parts)
    # project/references is an explicit ownership boundary: reference media must
    # never become project identity evidence because of filename/extension terms.
    if parts[:2] == ("project", "references"):
        return []
    # A canonical prop is object identity evidence. It must never be promoted to
    # a character because its filename contains a character name.
    if is_prop_asset(parts):
        return []
    evidence_keys=entity_evidence_keys(path,root)
    if evidence_keys: return evidence_keys
    rel=path.relative_to(root).as_posix().casefold()
    hits=sorted(term for term in verified_entity_terms(root) if term in rel)
    if hits: return hits
    if any(marker in rel for marker in CHARACTER_MARKERS): return ["__character_asset__"]
    return []

WINDOWS_RESERVED_STEMS = {"con", "prn", "aux", "nul", *(f"com{i}" for i in range(1, 10)), *(f"lpt{i}" for i in range(1, 10))}

def valid_character_id(value: str) -> bool:
    return (1 <= len(value) <= 64 and value == value.casefold()
            and value.casefold() not in WINDOWS_RESERVED_STEMS
            and value[0].isalnum() and value[-1].isalnum()
            and all(ch.isalnum() or ch in "-_" for ch in value))


def source_kind(path: Path, root: Path) -> str:
    rel=path.relative_to(root).as_posix().casefold()
    parts = tuple(part.casefold() for part in path.relative_to(root).parts)
    # Explicit storage ownership outranks heuristic identity hints. The single
    # shared taxonomy owns this decision for characters, props, logos, gameplay
    # captures and other assets alike.
    if parts[:2] == ("project", "references"):
        return "reference"
    stored = canonical_asset_kind(parts)
    if stored and stored in STORAGE_OWNED_KINDS:
        return stored
    if is_legacy_prop(parts):
        return "prop"
    if identity_keys(path,root):
        return "character"
    if any(marker in rel for marker in GAMEPLAY_MARKERS):
        return "game-screenshot"
    if any(marker in rel for marker in REFERENCE_MARKERS):
        return "reference"
    return "unclassified"


def evidence_registry(root: Path) -> dict[str, dict[str, str]]:
    """Load explicit evidence roles; storage paths are only a default, never authority."""
    registry_path = root / "project" / "evidence-registry.json"
    if not registry_path.is_file():
        return {}
    value = load_json(registry_path)
    require(value.get("schema_version") == 1 and isinstance(value.get("sources"), list),
            "project/evidence-registry.json must use schema_version 1 and a sources array")
    out: dict[str, dict[str, str]] = {}
    for item in value["sources"]:
        require(isinstance(item, dict), "evidence registry entries must be objects")
        path = str(item.get("source_path", "")).strip()
        role = str(item.get("evidence_role", "")).strip()
        provenance = str(item.get("provenance", "")).strip()
        authority_scope = str(item.get("authority_scope", "")).strip()
        require(path and role in {"canonical-identity", "historical-project-output", "external-reference", "gameplay-evidence", "unknown"},
                f"invalid evidence registry entry: {item}")
        require(provenance and authority_scope, f"evidence registry requires provenance and authority_scope: {path}")
        require(path not in out, f"duplicate evidence registry source_path: {path}")
        out[path] = {"evidence_role": role, "provenance": provenance, "authority_scope": authority_scope}
    return out


def evidence_metadata(root: Path, path: Path, kind: str) -> dict[str, str]:
    rel = relative(root, path)
    configured = evidence_registry(root).get(rel, {})
    role, provenance, scope = asset_evidence_defaults(kind)
    return {"evidence_role": configured.get("evidence_role", role),
            "provenance": configured.get("provenance", provenance),
            "authority_scope": configured.get("authority_scope", scope)}


def analysis_paths(root: Path, request: Path, source: Path) -> tuple[Path, Path]:
    try:
        source_relative = source.relative_to(root / "project")
    except ValueError:
        source_relative = Path("external") / source.relative_to(root)
    parent = source_relative.parent
    name = f"{source.stem}.md"
    work = work_root(request) / "single-analysis" / parent / name
    formal = root / "project" / "baselines" / "analyses" / parent / name
    return work, formal


def inspect_image(path: Path) -> tuple[int, int]:
    require(Image is not None, "Pillow is required to validate Baseline image sources")
    try:
        with Image.open(path) as image:
            image.load(); return image.width, image.height
    except Exception as exc:
        raise BaselineGateError(f"image source is not decodable: {path}: {exc}") from exc


def scan_logo_assets(root: Path) -> list[dict[str, Any]]:
    logo_root = root / "project" / "assets" / "logos"
    if not logo_root.is_dir():
        return []
    out=[]; seen_hashes=set()
    for path in sorted(logo_root.rglob("*"), key=lambda p: p.as_posix().casefold()):
        if not path.is_file() or path.suffix.lower() not in IMAGE_EXTENSIONS:
            continue
        digest=sha256_file(path)
        if digest in seen_hashes:
            continue
        seen_hashes.add(digest)
        width,height=inspect_image(path)
        out.append({"logo_path":relative(root,path),"logo_sha256":digest,"dimensions":f"{width}x{height}","source_label":path.stem})
    return out


def unique_reference_inventory(inventory: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [item for item in inventory if item.get("detected_kind")=="reference" and not item.get("duplicate_of")]


def reference_census_input_path(request: Path) -> Path:
    return work_root(request) / "reference-census-input.json"


def reference_census_path(request: Path) -> Path:
    return work_root(request) / "reference-census.json"


def write_reference_census_input(root: Path, request: Path, inventory: list[dict[str, Any]]) -> Path:
    refs=unique_reference_inventory(inventory)
    path=reference_census_input_path(request)
    write_json(path,{"schema_version":1,"project_context_sha256":project_context_sha256(root),
                     "references":[{"source_path":i["source_path"],"source_sha256":i["source_sha256"],"dimensions":i["dimensions"]} for i in refs]})
    return path


def valid_taxonomy_value(value: str) -> bool:
    value=value.strip().casefold()
    return bool(value) and value not in {"none","unknown","generic","default","reference","references","image","images","kv","banner"} and len(value)<=64


def census_signature(row: dict[str, Any]) -> tuple[str,str,str]:
    return (str(row["hook_type"]).casefold(),str(row["narrative_mode"]).casefold(),str(row["composition_mode"]).casefold())


def validate_reference_census(root: Path, request: Path, inventory: list[dict[str, Any]]) -> dict[str, Any]:
    refs=unique_reference_inventory(inventory)
    require(len(refs)>100,"reference census is only required for curated pools larger than 100 unique images")
    census_path=reference_census_path(request)
    value=load_json(census_path)
    require(value.get("schema_version")==1,"reference-census.json schema_version must be 1")
    require(value.get("project_context_sha256")==project_context_sha256(root),"reference census is stale")
    rows=value.get("sources"); clusters=value.get("clusters")
    require(isinstance(rows,list) and isinstance(clusters,list),"reference census must contain sources and clusters arrays")
    by_path={i["source_path"]:i for i in refs}; seen=set(); cues=[]; cluster_rows:dict[str,list[dict[str,Any]]]={}
    exact_keys={"source_path","source_sha256","hook_type","narrative_mode","composition_mode","tone","text_ui_load","cluster_id","outlier","distinguishing_cue"}
    for idx,row in enumerate(rows):
        require(isinstance(row,dict) and set(row)==exact_keys,f"reference census source[{idx}] fields are invalid")
        path=str(row["source_path"]); require(path in by_path and path not in seen,f"reference census source path invalid/duplicate: {path}")
        seen.add(path); require(str(row["source_sha256"])==by_path[path]["source_sha256"],f"reference census hash mismatch: {path}")
        for key in ("hook_type","narrative_mode","composition_mode","tone","text_ui_load"):
            require(valid_taxonomy_value(str(row[key])),f"reference census {path} {key} is generic/invalid")
        cid=str(row["cluster_id"]).strip(); require(valid_character_id(cid),f"reference census invalid cluster_id: {cid}")
        folder=Path(path).relative_to("project/references").parts[0].casefold()
        require(cid.casefold()!=folder and cid.casefold() not in {"kv","banner","reference","references"},
                f"reference cluster_id must describe a visual mechanism, not a storage folder: {cid}")
        require(isinstance(row["outlier"],bool),f"reference census outlier must be boolean: {path}")
        cue=normalized_text(str(row["distinguishing_cue"])); concrete_text(cue,f"reference census {path} distinguishing_cue",minimum=10); cues.append(cue.casefold())
        cluster_rows.setdefault(cid,[]).append(row)
    require(seen==set(by_path),"reference census must classify every unique project/references image exactly once")
    cue_counts=Counter(cues); copied=[cue for cue,count in cue_counts.items() if count>=3]
    require(not copied,"reference census mechanically copies distinguishing_cue across >=3 images")
    cluster_meta={};
    for idx,item in enumerate(clusters):
        require(isinstance(item,dict) and set(item)=={"cluster_id","cluster_name","definition","production_use"},f"reference census cluster[{idx}] fields invalid")
        cid=str(item["cluster_id"]).strip(); require(cid in cluster_rows and cid not in cluster_meta,f"reference census unknown/duplicate cluster: {cid}")
        for key in ("cluster_name","definition","production_use"): concrete_text(str(item[key]),f"reference cluster {cid} {key}",minimum=6)
        cluster_meta[cid]=item
    require(set(cluster_meta)==set(cluster_rows),"reference census clusters must exactly match source cluster_ids")
    # A cluster must be semantically coherent. For clusters >=4, at least 40% of sources must share one narrative+composition pair.
    # Singleton clusters are allowed only when explicitly marked as outliers.
    for cid,members in cluster_rows.items():
        if len(members)==1:
            require(bool(members[0]["outlier"]),f"singleton reference cluster {cid} must be marked outlier")
        if len(members)>=4:
            narratives=Counter(str(r["narrative_mode"]).casefold() for r in members)
            compositions=Counter(str(r["composition_mode"]).casefold() for r in members)
            require(max(max(narratives.values()),max(compositions.values()))/len(members)>=0.40,
                    f"reference cluster {cid} is too heterogeneous; split it before representative selection")
    return {"status":"passed","reference_count":len(refs),"cluster_count":len(cluster_rows),"sources":rows,"clusters":clusters,
            "census":relative(root,census_path),"census_sha256":sha256_file(census_path)}


def cluster_rep_requirement(size: int) -> int:
    if size<=2: return size
    if size<=5: return 3
    if size<=12: return 4
    if size<=24: return 5
    return min(8,max(6,math.ceil(math.sqrt(size))))


def visual_input_fingerprint(root: Path) -> str:
    index = root / "project" / "material-index.json"
    value = load_json(index)
    require(value.get("schema_version") == 2, "project material index must use schema_version 2")
    digest = str(value.get("visual_input_fingerprint", "")).strip().lower()
    require(re.fullmatch(r"[0-9a-f]{64}", digest) is not None, "project material index lacks visual_input_fingerprint")
    return digest


def project_context_sha256(root: Path) -> str:
    brief = root / "project" / "project-brief.md"
    require(brief.is_file(), "project/project-brief.md is required before Baseline")
    return shared_project_context_sha256(root, visual_input_fingerprint(root), brief)


def scan_all_visual_sources(root: Path, request: Path) -> list[dict[str, Any]]:
    excluded_top = {".agents", ".git", "requests", "user", "USER", "tmp", "__pycache__"}
    candidates=[]
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in IMAGE_EXTENSIONS:
            continue
        rel=path.relative_to(root); parts=rel.parts
        if not parts or parts[0] in excluded_top or parts[:2] == ("project","baselines"):
            continue
        if tuple(p.lower() for p in parts[:3]) == ("project","assets","logos"):
            continue
        candidates.append(path.resolve())
    candidates=sorted(set(candidates), key=lambda x: relative(root,x).casefold())
    require(candidates, "no eligible project image sources exist")
    entries=[]; seen_targets={}; seen_hashes={}
    for source in candidates:
        width,height=inspect_image(source); work_analysis,formal_analysis=analysis_paths(root,request,source)
        key=relative(root,work_analysis).casefold()
        require(key not in seen_targets, f"two sources map to one analysis path: {seen_targets.get(key)} and {relative(root,source)}")
        seen_targets[key]=relative(root,source)
        digest=sha256_file(source)
        kind = source_kind(source, root)
        entries.append({"source_path":relative(root,source),"source_sha256":digest,"detected_kind":kind,
                        "identity_keys":identity_keys(source,root),"dimensions":f"{width}x{height}",
                        **evidence_metadata(root, source, kind), "duplicate_of":seen_hashes.get(digest)})
        seen_hashes.setdefault(digest, relative(root,source))
    return entries


def write_source_inventory(root: Path, request: Path, entries: list[dict[str, Any]]) -> Path:
    out=work_root(request)/"source-inventory.json"
    write_json(out,{"schema_version":2,"project_context_sha256":project_context_sha256(root),"sources":entries})
    return out


def selected_sources(root: Path, request: Path, inventory: list[dict[str, Any]]) -> list[dict[str, Any]]:
    selection_path=work_root(request)/"source-selection.json"
    require(selection_path.is_file(), "source-selection.json is missing; select representative sources from source-inventory.json")
    selection=load_json(selection_path)
    require(set(selection)=={"sources"} and isinstance(selection["sources"],list) and selection["sources"],
            "source-selection.json must contain only a non-empty sources array")
    by_path={item["source_path"]:item for item in inventory}; selected=[]; paths=set(); hashes=set()
    for raw in selection["sources"]:
        require(isinstance(raw,dict),"source selection entry must be an object")
        require(set(raw) <= {"source_path","source_kind","character_id","evidence_role"},"source selection contains unnecessary fields")
        path=str(raw.get("source_path","")).strip(); kind=str(raw.get("source_kind","")).strip()
        require(path in by_path, f"selected source is not in current inventory: {path}")
        require(path not in paths, f"duplicate selected source: {path}")
        require(kind in {"character","prop","game-screenshot","reference","other-asset"}, f"invalid selected source_kind: {kind}")
        base=by_path[path]; digest=base["source_sha256"]
        detected=str(base.get("detected_kind") or "unclassified")
        legacy_prop = detected=="prop" and is_legacy_prop(path.replace(chr(92),"/").split("/"))
        if detected in {"character","prop","reference","game-screenshot"}:
            # A legacy project/props/** source was legally recorded as other-asset while the
            # taxonomy had no prop category, so that recorded kind stays acceptable. The
            # canonical folders keep the strict ownership rule, and legacy props are not a
            # mandatory category, so this tolerance removes no requirement.
            require(kind==detected or (legacy_prop and kind=="other-asset"),
                    f"selected source_kind must respect storage/detected ownership for {path}: expected {detected}"
                    + (" (or other-asset for a legacy project/props source)" if legacy_prop else ""))
        require(digest not in hashes, f"duplicate image bytes must not be reverse-analyzed twice: {path}")
        paths.add(path); hashes.add(digest)
        source=bounded_path(root,path,must_exist=True); work_analysis,formal_analysis=analysis_paths(root,request,source)
        char_id=str(raw.get("character_id") or "").strip() if kind=="character" else ""
        if kind=="character":
            require(valid_character_id(char_id), f"character source requires a stable lowercase path-safe character_id: {path}")
        metadata = evidence_metadata(root, source, kind)
        selected_role = str(raw.get("evidence_role") or metadata["evidence_role"])
        require(selected_role == metadata["evidence_role"], f"selected evidence_role must match evidence registry for {path}")
        selected.append({"source_path":path,"source_sha256":digest,"source_kind":kind,"dimensions":base["dimensions"],
                         "evidence_role":selected_role,"provenance":metadata["provenance"],"authority_scope":metadata["authority_scope"],
                         "analysis_path":relative(root,work_analysis),"formal_analysis_path":relative(root,formal_analysis),
                         "character_id":char_id or None,"source_label":source.stem})
    # Only the canonical folders are mandatory. A legacy project/props/** image is
    # classified as a prop but must not become a new blocking requirement.
    canonical_core={i["source_path"] for i in inventory
                    if i["detected_kind"] in REQUIRED_SELECTION_KINDS
                    and i["source_path"].casefold().startswith(("project/assets/characters/", "project/assets/props/"))
                    and not i.get("duplicate_of")}
    require(canonical_core <= paths,
            "all canonical project/assets/characters and project/assets/props sources must be selected (project/props/** is recognised as props but not mandatory)")

    unique_refs=unique_reference_inventory(inventory); ref_paths={i["source_path"] for i in unique_refs}
    if len(unique_refs)<=100:
        require(ref_paths<=paths,"all unique project/references sources must be selected for a full deep-analysis pool (<=100 images)")
    else:
        census=validate_reference_census(root,request,inventory)
        rows=census["sources"]; by_cluster:dict[str,list[dict[str,Any]]]={}
        for row in rows: by_cluster.setdefault(str(row["cluster_id"]),[]).append(row)
        selected_refs={item["source_path"] for item in selected if item["source_kind"]=="reference"}
        for cid,members in by_cluster.items():
            member_paths={str(r["source_path"]) for r in members}; chosen=selected_refs & member_paths
            need=cluster_rep_requirement(len(members))
            require(len(chosen)>=need,f"reference visual cluster {cid} requires at least {need} deep-analysis representatives, got {len(chosen)}")
            outliers={str(r["source_path"]) for r in members if bool(r["outlier"])}
            require(outliers<=chosen,f"reference visual cluster {cid} must deep-analyze every marked outlier")
            # Every major census signature (>=20% of the cluster, minimum 2 images) needs a representative.
            sig_sources:dict[tuple[str,str,str],set[str]]={}
            for r in members: sig_sources.setdefault(census_signature(r),set()).add(str(r["source_path"]))
            threshold=max(2,math.ceil(len(members)*0.20))
            for sig,sources in sig_sources.items():
                if len(sources)>=threshold:
                    require(bool(chosen & sources),f"reference visual cluster {cid} misses a major census signature: {sig}")

    required_identity_keys={key for i in inventory if not i.get("duplicate_of") for key in i.get("identity_keys",[]) }
    for key in required_identity_keys:
        matching={i["source_path"] for i in inventory if key in i.get("identity_keys",[]) and not i.get("duplicate_of")}
        require(any(item["source_path"] in matching and item["source_kind"]=="character" for item in selected),
                f"character identity representative is missing for {key}")
    return selected

def build_source_manifest(root: Path, request: Path) -> dict[str, Any]:
    inventory=scan_all_visual_sources(root,request); inv_path=write_source_inventory(root,request,inventory)
    refs=unique_reference_inventory(inventory)
    census_input=None
    if len(refs)>100:
        census_input=write_reference_census_input(root,request,inventory)
        census_path=reference_census_path(request)
        if not census_path.is_file():
            return {"status":"needs_reference_census","inventory":relative(root,inv_path),"candidate_count":len(inventory),
                    "unique_reference_count":len(refs),"census_input":relative(root,census_input),
                    "census":relative(root,census_path)}
        try:
            validate_reference_census(root,request,inventory)
        except BaselineGateError as exc:
            return {"status":"needs_reference_census","inventory":relative(root,inv_path),"candidate_count":len(inventory),
                    "unique_reference_count":len(refs),"census_input":relative(root,census_input),
                    "census":relative(root,census_path),"reason":str(exc)}
    selection_path=work_root(request)/"source-selection.json"
    if not selection_path.is_file():
        result={"status":"needs_selection","inventory":relative(root,inv_path),"candidate_count":len(inventory),
            "props_location":props_location_report([str(i["source_path"]) for i in inventory]),
                "unique_count":sum(not bool(i.get("duplicate_of")) for i in inventory),"selection":relative(root,selection_path)}
        if census_input: result["reference_census"]=relative(root,reference_census_path(request))
        return result
    try:
        entries=selected_sources(root,request,inventory)
    except BaselineGateError as exc:
        result={"status":"needs_selection","inventory":relative(root,inv_path),"candidate_count":len(inventory),
            "props_location":props_location_report([str(i["source_path"]) for i in inventory]),
                "unique_count":sum(not bool(i.get("duplicate_of")) for i in inventory),"selection":relative(root,selection_path),"reason":str(exc)}
        if census_input: result["reference_census"]=relative(root,reference_census_path(request))
        return result
    census_sha=sha256_file(reference_census_path(request)) if len(refs)>100 else None
    manifest={"schema_version":5,"request_path":relative(root,request),"project_context_sha256":project_context_sha256(root),
              "analysis_contract_version":REVERSE_ANALYSIS_CONTRACT_VERSION,
              "analysis_contract_sha256":reverse_analysis_contract_sha256(root),
              "reverse_analysis_skill_version":REVERSE_ANALYSIS_SKILL_VERSION,
              "visual_grounding_gate_version":VISUAL_GROUNDING_GATE_VERSION,
              "reference_census_sha256":census_sha,
              "coverage":f"{len(entries)} deep reverse-analysis sources selected from {len(inventory)} inventoried images; {len(refs)} unique References census-covered",
              "sources":entries}
    output=work_root(request)/"source-manifest.json"; write_json(output,manifest)
    return {"status":"built","manifest":relative(root,output),"source_count":len(entries),"inventory_count":len(inventory),
            "props_location":props_location_report([str(i["source_path"]) for i in inventory]),
            "character_count":sum(i["source_kind"]=="character" for i in entries),
            "prop_count":sum(i["source_kind"]=="prop" for i in entries),
            "reference_count":sum(i["source_kind"]=="reference" for i in entries),"unique_reference_count":len(refs),
            "reference_census":relative(root,reference_census_path(request)) if len(refs)>100 else None}

def current_manifest(root: Path, request: Path) -> dict[str, Any]:
    path=work_root(request)/"source-manifest.json"; value=load_json(path)
    require(value.get("schema_version")==5 and value.get("request_path")==relative(root,request),
            "source manifest schema or request binding is invalid")
    require(value.get("analysis_contract_version")==REVERSE_ANALYSIS_CONTRACT_VERSION and
            value.get("analysis_contract_sha256")==reverse_analysis_contract_sha256(root) and
            value.get("reverse_analysis_skill_version")==REVERSE_ANALYSIS_SKILL_VERSION and
            value.get("visual_grounding_gate_version")==VISUAL_GROUNDING_GATE_VERSION,
            "source manifest is bound to an outdated reverse-analysis contract")
    inventory=scan_all_visual_sources(root,request); refs=unique_reference_inventory(inventory)
    expected=selected_sources(root,request,inventory)
    require(value.get("project_context_sha256")==project_context_sha256(root),
            "visual inputs or verified project brief changed after Source Manifest; refresh only affected Baseline stages")
    expected_census=sha256_file(reference_census_path(request)) if len(refs)>100 else None
    require(value.get("reference_census_sha256")==expected_census,"reference census changed after Source Manifest; rebuild affected stages")
    require(value.get("sources")==expected,"selected visual sources changed after Source Manifest; rebuild affected stages")
    return value

def prepare_cached_analyses(root: Path, request: Path) -> dict[str, Any]:
    """Reuse only published analyses that still pass the current reverse-analysis gate."""
    manifest = current_manifest(root, request)
    reused, needs = [], []
    for entry in manifest["sources"]:
        formal = bounded_path(root, entry["formal_analysis_path"])
        work = bounded_path(root, entry["analysis_path"])
        if not formal.is_file():
            needs.append(entry["source_path"]); continue
        work.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(formal, work)
        try:
            validate_analysis(root, entry)
        except (BaselineGateError, OSError):
            if work.exists(): work.unlink()
            needs.append(entry["source_path"]); continue
        reused.append(entry["source_path"])
    return {"status": "ready", "reused": reused, "needs_analysis": needs,
            "reused_count": len(reused), "needs_analysis_count": len(needs)}


def source_set_sha256(entries: list[dict[str, Any]]) -> str:
    payload = "\n".join(f"{entry['source_path']}\t{entry['source_sha256']}\t{entry.get('evidence_role','')}\t{entry.get('provenance','')}\t{entry.get('authority_scope','')}" for entry in entries)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def require_text_file(path: Path, label: str) -> str:
    require(path.is_file(), f"{label} is missing: {path}")
    text = path.read_text(encoding="utf-8")
    require(text.strip(), f"{label} is empty: {path}")
    return text


def validate_inventory_for_request(root: Path, request: Path) -> dict[str, Any]:
    manifest=current_manifest(root,request)
    inventory_path=work_root(request)/"source-inventory.json"; inventory=load_json(inventory_path)
    require(inventory.get("schema_version")==2 and inventory.get("project_context_sha256")==project_context_sha256(root),
            "source inventory is stale")
    all_paths={item["source_path"] for item in inventory.get("sources",[]) if isinstance(item,dict)}
    selected={entry["source_path"] for entry in manifest["sources"]}
    require(selected <= all_paths,"selected source is missing from inventory")
    return {"status":"passed","inventory_count":len(all_paths),"selected_count":len(selected),
            "inventory":relative(root,inventory_path)}

def section(text: str, heading: str) -> str:
    start = text.find(heading)
    require(start >= 0, f"reverse analysis is missing section: {heading}")
    body_start = start + len(heading)
    match = re.search(r"^##\s+", text[body_start:], flags=re.MULTILINE)
    end = body_start + match.start() if match else len(text)
    return text[body_start:end].strip()


def subsection(text: str, heading: str) -> str:
    start = text.find(heading)
    require(start >= 0, f"reverse analysis is missing subsection: {heading}")
    body_start = start + len(heading)
    match = re.search(r"^###\s+", text[body_start:], flags=re.MULTILINE)
    end = body_start + match.start() if match else len(text)
    return text[body_start:end].strip()



def normalized_text(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip()


def field_value(text: str, name: str) -> str:
    match = re.search(rf"(?m)^{re.escape(name)}:\s*(.+?)\s*$", text)
    return match.group(1).strip() if match else ""


def named_blocks(text: str, field: str) -> list[tuple[str, str]]:
    matches = list(re.finditer(rf"(?m)^{re.escape(field)}:\s*([^\s]+)\s*$", text))
    blocks = []
    for index, match in enumerate(matches):
        end = matches[index + 1].start() if index + 1 < len(matches) else len(text)
        blocks.append((match.group(1).strip(), text[match.start():end].strip()))
    return blocks


def analysis_phrases(text: str) -> list[str]:
    body = section(text, "## 8. 可复用中文正向 Phrase")
    return [line.strip()[2:].strip() for line in body.splitlines() if line.strip().startswith("- ")]




def validate_no_professional_generators(root: Path, request: Path) -> None:
    candidates: set[Path] = set()
    for scan_root in (request / "work", root / "tmp"):
        if scan_root.is_dir():
            candidates.update(path for path in scan_root.rglob("*") if path.is_file())
    for path in sorted(candidates):
        lower = path.name.casefold()
        if path.suffix.casefold() not in {".py", ".ps1", ".js", ".ts"} and not lower.endswith(".template.md"):
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        hits = {marker for marker in PROFESSIONAL_OUTPUT_MARKERS if marker in text}
        require(len(hits) < 2,
                f"professional Baseline conclusions must not be generated by script/template: {relative(root, path)}")


def validate_project_brief_ownership(root: Path) -> None:
    brief = root / "project" / "project-brief.md"
    if not brief.is_file():
        return
    text = brief.read_text(encoding="utf-8")
    require(re.search(r"(?im)^##\s+Evidence-backed project inferences\s*$", text) is None,
            "project/project-brief.md must keep facts and unknowns only; move visual conclusions into the Baseline")
    for field in ("visual_mother", "signature_terms", "family_id", "rendering_mode", "prompt_module_id"):
        require(re.search(rf"(?m)^{field}:\s*", text) is None,
                f"project/project-brief.md duplicates formal Baseline field: {field}")



# Baseline schema 8: project-level visual synthesis, not per-image compliance compilation.
AGGREGATION_SCHEMA = 6
CHARACTER_ANALYSIS_SECTIONS = REQUIRED_ANALYSIS_SECTIONS
REFERENCE_ANALYSIS_SECTIONS = (
    "## 1. 源绑定", "## 2. 故事性画面描述", "## 3. 核心主题、构图与镜头",
    "## 4. 视觉风格与质感", "## 5. 角色动作与场景关系", "## 6. 远景、中景与近景",
    "## 7. 可复用中文正向 Phrase", "## 8. 完整中文正向反推提示词", "## 9. 单图可复用价值",
    "## 10. 不可继承与边界", "## 11. 事实、判断与不确定项", "## 12. 上层 Skill 可用摘要",
)
SYNTHESIS_REQUIRED_SECTIONS = (
    "## 1. Whole-set Gestalt",
    "## 2. Evidence Matrix 与反例",
    "## 3. 当前产出结构推导",
    "## 4. 跨产出 Visual DNA",
    "## 5. Prior / Floor / Innovation",
    "## 6. One-shot Calibration",
)
STANDARD_REQUIRED_SECTIONS_V8 = (
    "## 1. 基准定位",
    "## 2. 项目视觉认知",
    "## 3. 当前产出结构",
    "## 4. 跨产出视觉 DNA",
    "## 5. 产出差异决策",
    "## 6. 角色与品牌身份",
    "## 7. Baseline Floor｜最低合格线",
    "## 8. 创新空间｜Baseline 不是上限",
    "## 9. 一稿校准",
    "## 10. 证据边界与刷新",
)
CONSUMERS = {"visual-packaging", "image-production", "layer-decomposition", "game-concept-lab", "kv-micro-animation", "visual-competitive-analysis", "visual-scorecard"}


def split_ids(value: str) -> set[str]:
    if not value or value.casefold() == "none":
        return set()
    return {item for item in re.split(r"[|,，、\s]+", value) if item and item.casefold() != "none"}


def text_field(text: str, name: str) -> str:
    match = re.search(rf"(?m)^\s*(?:[-*]\s*)?{re.escape(name)}:\s*`?(.+?)`?\s*$", text)
    return match.group(1).strip().strip("`") if match else ""


def concrete_text(value: str, label: str, *, minimum: int = 4) -> None:
    require(value and value.casefold() not in {"todo", "tbd", "placeholder", "none"}, f"{label} is missing")
    require(chinese_count(value) >= minimum or len(value) >= max(8, minimum * 2), f"{label} is too generic")


def chinese_count(value: str) -> int:
    return len(re.findall(r"[\u4e00-\u9fff]", value))


def bullet_items(body: str) -> list[str]:
    return [line.strip()[2:].strip() for line in body.splitlines() if line.strip().startswith("- ")]


def validate_positive_phrase(phrase: str, label: str) -> None:
    value = normalized_text(phrase)
    require(chinese_count(value) >= 8, f"{label} is too short")
    generic_openers = ("整体构图", "整体画面", "画面通过", "主体通过", "角色互动", "背景通过")
    require(not value.startswith(generic_openers), f"{label} starts from a generic placeholder subject")
    require(not any(token in value.casefold() for token in ("masterpiece", "best quality", "--ar")),
            f"{label} contains model syntax instead of visual language")


def validate_reference_visual_coverage(text: str, entry: dict[str, Any]) -> None:
    """Reject schema-filled captions that omit the visual coordinates needed for reconstruction."""
    body = section(text, "## 2. 故事性画面描述") + "\n" + section(text, "## 3. 核心主题、构图与镜头") + "\n" + \
           section(text, "## 4. 视觉风格与质感") + "\n" + section(text, "## 5. 角色动作与场景关系") + "\n" + \
           section(text, "## 6. 远景、中景与近景")
    groups = {
        "objects": r"人物|角色|主体|怪物|生物|车辆|建筑|武器|道具|物体",
        "spatial": r"左|右|中央|中心|前景|中景|后景|背景|上方|下方|远处|近处|边缘|象限",
        "relations": r"朝|指向|奔跑|持|抱|遮挡|面对|追|攻击|沿|连接|背对|视线",
        "camera": r"镜头|机位|透视|消失点|裁切|焦平面|景别|广角|俯拍|仰拍",
        "light_color": r"主光|光源|轮廓光|逆光|阴影|冷|暖|明度|色彩|高光|雾",
        "information": r"文字|Logo|LOGO|UI|数字|门|标志|标题|文案|界面|按钮",
    }
    hits = sum(bool(re.search(pattern, body, flags=re.IGNORECASE)) for pattern in groups.values())
    require(hits >= 5, f"reference lacks reconstructive visual coverage ({hits}/6 cue groups): {entry['analysis_path']}")
    require(len(body) >= 900, f"reference visual fact body is too thin for blind reconstruction: {entry['analysis_path']}")


def analysis_mechanisms(text: str, entry: dict[str, Any]) -> list[str]:
    if entry["source_kind"] == "character":
        return analysis_phrases(text)
    return bullet_items(section(text, "## 7. 可复用中文正向 Phrase"))


def validate_analysis(root: Path, entry: dict[str, Any]) -> None:
    path = bounded_path(root, entry["analysis_path"], must_exist=True)
    text = require_text_file(path, "single-image reverse analysis")
    required = CHARACTER_ANALYSIS_SECTIONS if entry["source_kind"] == "character" else REFERENCE_ANALYSIS_SECTIONS
    for heading in required:
        require(text.count(heading) == 1, f"{entry['analysis_path']} must contain section exactly once: {heading}")
    bind = section(text, "## 1. 源绑定")
    for name, expected in (("source_path", entry["source_path"]), ("source_sha256", entry["source_sha256"]),
                           ("source_kind", entry["source_kind"]), ("source_label", entry["source_label"]),
                           ("evidence_role", entry.get("evidence_role", "unknown")),
                           ("provenance", entry.get("provenance", "")),
                           ("authority_scope", entry.get("authority_scope", "")),
                           ("analysis_contract_version", REVERSE_ANALYSIS_CONTRACT_VERSION),
                           ("analysis_contract_sha256", reverse_analysis_contract_sha256(root)),
                           ("reverse_analysis_skill_version", REVERSE_ANALYSIS_SKILL_VERSION),
                           ("dimensions", entry["dimensions"]),
                           ("visual_grounding_gate_version", VISUAL_GROUNDING_GATE_VERSION)):
        require(text_field(bind, name) == str(expected), f"reverse analysis {name} mismatch: {entry['analysis_path']}")
    expected_authority = asset_identity_authority(entry["source_kind"])
    require(text_field(bind, "identity_authority") == expected_authority,
            f"reverse analysis identity_authority mismatch: {entry['analysis_path']}")
    expected_character = entry.get("character_id") or "none"
    require(text_field(bind, "character_id") == expected_character,
            f"reverse analysis character_id mismatch: {entry['analysis_path']}")

    mechanisms = analysis_mechanisms(text, entry)
    lo, hi = ((6, 12) if entry["source_kind"] == "character" else (8, 16))
    require(lo <= len(mechanisms) <= hi,
            f"reverse analysis requires {lo}-{hi} evidence-dense mechanisms: {entry['analysis_path']} has {len(mechanisms)}")
    norm = [normalized_text(item) for item in mechanisms]
    require(len(norm) == len(set(norm)), f"reverse analysis contains duplicate mechanisms: {entry['analysis_path']}")
    for idx, phrase in enumerate(norm, 1):
        validate_positive_phrase(phrase, f"{entry['analysis_path']} mechanism {idx}")

    if entry["source_kind"] == "character":
        story = section(text, "## 2. 故事性画面描述")
        require(chinese_count(story) >= 35, f"story description is not substantive: {entry['analysis_path']}")
        prompt = section(text, "## 9. 完整中文正向反推提示词")
        require(chinese_count(prompt) >= 45, f"complete reverse prompt is not substantive: {entry['analysis_path']}")
        identity = section(text, "## 6. 角色身份反推")
        require(text_field(identity, "identity_label") == entry["source_label"],
                f"character identity_label must equal source label: {entry['analysis_path']}")
        require(text_field(identity, "character_id") == entry["character_id"],
                f"character identity section must bind character_id: {entry['analysis_path']}")
        for field in ("face_shape_skin","eyes_brows","hair_structure_color","outfit_silhouette","equipment_signature"):
            concrete_text(text_field(identity,field),f"{entry['analysis_path']} {field}",minimum=6)
        anchors = bullet_items(subsection(identity, "### 6.4 最高价值垫图锚点"))
        require(3 <= len(anchors) <= 6, f"character analysis requires 3-6 identity anchors: {entry['analysis_path']}")
    else:
        story = section(text, "## 2. 故事性画面描述")
        comp = section(text, "## 3. 核心主题、构图与镜头")
        style = section(text, "## 4. 视觉风格与质感")
        relation = section(text, "## 5. 角色动作与场景关系")
        depth = section(text, "## 6. 远景、中景与近景")
        prompt = section(text, "## 8. 完整中文正向反推提示词")
        value = section(text, "## 9. 单图可复用价值")
        boundary = section(text, "## 10. 不可继承与边界")
        facts = section(text, "## 11. 事实、判断与不确定项")
        summary = section(text, "## 12. 上层 Skill 可用摘要")
        for field, body, minimum in (
            ("story", story, 70), ("blind_reconstruction", story, 45), ("subject_map", comp, 30),
            ("focal_hierarchy", comp, 20), ("visual_route", comp, 20), ("composition_coordinates", comp, 25),
            ("camera", comp, 20), ("text_ui", comp, 12), ("rendering", style, 12),
            ("material_fx", style, 12), ("color_light", style, 18), ("light_causality", style, 18),
            ("actions", relation, 30), ("environment_role", relation, 18),
            ("positive_prompt", prompt, 80), ("transferable_mechanisms", value, 25),
            ("best_for", value, 12), ("avoid_when", value, 12), ("identity_boundary", boundary, 12),
            ("do_not_inherit", boundary, 12), ("production_use", summary, 12)):
            concrete_text(text_field(body, field), f"{entry['analysis_path']} {field}", minimum=minimum)
        require(chinese_count(facts) >= 100, f"reference facts/judgement boundary is not substantive: {entry['analysis_path']}")
        require(all(chinese_count(subsection(depth, heading)) >= 18 for heading in ("### 6.1 远景", "### 6.2 中景", "### 6.3 近景")),
                f"reference must describe substantive far/mid/near planes: {entry['analysis_path']}")
        require(not any(token in text_field(prompt, "positive_prompt") for token in ("不要", "避免", "不得", "禁止")),
                f"reference positive_prompt contains negative instructions: {entry['analysis_path']}")
        validate_reference_visual_coverage(text, entry)


def source_neutral_text(value: str, entry: dict[str, Any]) -> str:
    result = value.casefold()
    source_path = str(entry.get("source_path", ""))
    tokens = {str(entry.get("source_label", "")), str(entry.get("character_id", "")), source_path,
              Path(source_path).name if source_path else "", Path(source_path).stem if source_path else "",
              str(entry.get("source_sha256", "")), str(entry.get("dimensions", ""))}
    for token in sorted((item.casefold() for item in tokens if item and item != "none"), key=len, reverse=True):
        result = result.replace(token, "<source>")
    result = re.sub(r"(?m)^\s*#{1,6}[^\n]*$", "", result)
    result = re.sub(r"[`*_>#|—–\-]+", "", result)
    result = re.sub(r"\s+", "", result)
    return result


def analysis_comparison_sections(text: str, entry: dict[str, Any]) -> tuple[str, ...]:
    if entry["source_kind"] == "character":
        return ("## 3. 核心主题、构图与镜头", "## 4. 视觉风格与质感", "## 10. 单图可复用价值")
    return ("## 2. 故事性画面描述", "## 3. 核心主题、构图与镜头", "## 4. 视觉风格与质感", "## 5. 角色动作与场景关系")


SEMANTIC_STOPWORDS = {"画面", "主体", "当前", "形成", "使得", "通过", "整体", "构图", "视觉", "清晰", "增强", "突出", "承担", "建立", "保留", "强化", "以及", "一种", "一种"}


def semantic_tokens(value: str) -> set[str]:
    value = re.sub(r"[\s\W_]+", "", value.casefold())
    tokens = {token for token in re.findall(r"[a-z0-9]{2,}", value) if token not in SEMANTIC_STOPWORDS}
    han = "".join(re.findall(r"[\u4e00-\u9fff]", value))
    tokens.update(han[index:index + 2] for index in range(len(han) - 1))
    tokens.update(han[index:index + 3] for index in range(len(han) - 2))
    return {token for token in tokens if token not in SEMANTIC_STOPWORDS and len(token) >= 2}


def jaccard(left: set[str], right: set[str]) -> float:
    union = left | right
    return len(left & right) / len(union) if union else 0.0


def validate_cross_source_independence(root: Path, manifest: dict[str, Any]) -> dict[str, Any]:
    phrase_sources: dict[str, set[str]] = {}
    per_analysis: dict[str, list[str]] = {}
    section_digests: dict[tuple[str, str], set[str]] = {}
    near_copy_pairs=[]
    texts={}
    for entry in manifest["sources"]:
        text=bounded_path(root, entry["analysis_path"], must_exist=True).read_text(encoding="utf-8")
        texts[entry["analysis_path"]]=(entry,text)
        items=[source_neutral_text(item,entry) for item in analysis_mechanisms(text,entry)]
        per_analysis[entry["analysis_path"]]=items
        for item in set(items):
            if len(item)>=20: phrase_sources.setdefault(item,set()).add(entry["source_sha256"])
        for heading in analysis_comparison_sections(text,entry):
            body=source_neutral_text(section(text,heading),entry)
            if len(body)>=80:
                section_digests.setdefault((heading,hashlib.sha256(body.encode("utf-8")).hexdigest()),set()).add(entry["source_sha256"])
    offenders=[]
    for path,items in per_analysis.items():
        repeated=sum(1 for item in items if len(phrase_sources.get(item,set()))>=3)
        if len(items)>=6 and repeated/len(items)>=0.50:
            offenders.append({"analysis_path":path,"repeated_mechanisms":repeated,"count":len(items)})
    require(not offenders,"single-image analyses mechanically reuse mechanisms across sources: "+json.dumps(offenders[:5],ensure_ascii=False))
    copied=sum(1 for hashes in section_digests.values() if len(hashes)>=3)
    require(copied<2,"multiple substantive analysis sections are copied across >=3 independent sources")
    paths=list(texts)
    for i,left in enumerate(paths):
        le,lt=texts[left]
        for right in paths[i+1:]:
            re_,rt=texts[right]
            if le["source_kind"]!=re_["source_kind"]: continue
            lh=analysis_comparison_sections(lt,le)[:2]; rh=analysis_comparison_sections(rt,re_)[:2]
            if lh!=rh: continue
            ratios=[]
            for heading in lh:
                a=source_neutral_text(section(lt,heading),le); b=source_neutral_text(section(rt,heading),re_)
                if min(len(a),len(b))>=120: ratios.append(SequenceMatcher(None,a,b,autojunk=False).ratio())
            if len(ratios)>=2 and all(r>=0.94 for r in ratios[:2]): near_copy_pairs.append((left,right))
    require(not near_copy_pairs,"source-neutral near-copy analyses indicate template laundering: "+json.dumps(near_copy_pairs[:5],ensure_ascii=False))
    semantic_pairs=[]
    semantic_mechanisms={path:[semantic_tokens(item) for item in items if len(semantic_tokens(item)) >= 4]
                         for path,items in per_analysis.items()}
    for i,left in enumerate(paths):
        le = semantic_mechanisms[left]
        for right in paths[i + 1:]:
            re_ = semantic_mechanisms[right]
            if not le or not re_: continue
            matches=sum(1 for tokens in le if max((jaccard(tokens, other) for other in re_), default=0.0) >= 0.72)
            reverse=sum(1 for tokens in re_ if max((jaccard(tokens, other) for other in le), default=0.0) >= 0.72)
            if min(matches / len(le), reverse / len(re_)) >= 0.50:
                semantic_pairs.append((left, right))
    require(not semantic_pairs,
            "semantic template laundering detected across analyses: " + json.dumps(semantic_pairs[:5], ensure_ascii=False))
    return {"cross_source_mechanism_reuse":"passed","copied_section_groups":copied,
            "near_copy_pairs":len(near_copy_pairs),"semantic_template_pairs":len(semantic_pairs)}


def validate_single_analysis_for_request(root: Path, request: Path) -> dict[str, Any]:
    validate_inventory_for_request(root, request)
    manifest=current_manifest(root,request); expected=set()
    for entry in manifest["sources"]:
        validate_analysis(root,entry); expected.add(bounded_path(root,entry["analysis_path"],must_exist=True).resolve())
    analysis_root=work_root(request)/"single-analysis"
    actual={p.resolve() for p in analysis_root.rglob("*.md")} if analysis_root.is_dir() else set()
    require(actual==expected,"single-analysis set must exactly match Source Manifest")
    quality=validate_cross_source_independence(root,manifest)
    index=work_root(request)/"single-analysis-index.md"
    lines=["# Single Analysis Index","",f"project_context_sha256: {project_context_sha256(root)}",f"source_set_sha256: {source_set_sha256(manifest['sources'])}",""]
    for entry in manifest["sources"]:
        analysis=bounded_path(root,entry["analysis_path"],must_exist=True)
        lines.append(f"- source: `{entry['source_path']}` | source_sha256: `{entry['source_sha256']}` | analysis: `{entry['analysis_path']}` | analysis_sha256: `{sha256_file(analysis)}` | formal: `{entry['formal_analysis_path']}`")
    expected_index="\n".join(lines)+"\n"
    if index.is_file(): require(index.read_text(encoding="utf-8")==expected_index,"single-analysis-index.md is stale; rerun prepare-aggregation")
    return {"status":"passed","analysis_count":len(expected),"index":relative(root,index) if index.is_file() else None,**quality}


def expected_aggregation_evidence(root: Path, request: Path) -> dict[str, Any]:
    manifest=current_manifest(root,request); inventory=scan_all_visual_sources(root,request); refs=unique_reference_inventory(inventory)
    return {"schema_version":AGGREGATION_SCHEMA,"project_context_sha256":project_context_sha256(root),
            "source_set_sha256":source_set_sha256(manifest["sources"]),
            "reference_census_sha256":sha256_file(reference_census_path(request)) if len(refs)>100 else None,
            "grounding_review_sha256":sha256_file(work_root(request)/"grounding-review.json") if (work_root(request)/"grounding-review.json").is_file() else None,
            "logo_assets":[{"logo_path":i["logo_path"],"logo_sha256":i["logo_sha256"]} for i in scan_logo_assets(root)],
            "sources":[{"source_path":e["source_path"],"source_sha256":e["source_sha256"],"source_kind":e["source_kind"],
                        "evidence_role":e.get("evidence_role"),"provenance":e.get("provenance"),"authority_scope":e.get("authority_scope"),
                        "character_id":e.get("character_id"),"analysis_path":e["analysis_path"],
                        "analysis_sha256":sha256_file(bounded_path(root,e["analysis_path"],must_exist=True)),
                        "formal_analysis_path":e["formal_analysis_path"]} for e in manifest["sources"]]}

def prepare_aggregation_for_request(root: Path, request: Path) -> dict[str, Any]:
    # Validate the actual analyses first, then deterministically rebuild the index.
    # A stale index is an output of this step, never a prerequisite that can deadlock the workflow.
    validate_inventory_for_request(root,request)
    manifest=current_manifest(root,request)
    for entry in manifest["sources"]:
        validate_analysis(root,entry)
    quality=validate_cross_source_independence(root,manifest)
    index=work_root(request)/"single-analysis-index.md"
    lines=["# Single Analysis Index","",f"project_context_sha256: {project_context_sha256(root)}",
           f"source_set_sha256: {source_set_sha256(manifest['sources'])}",""]
    for entry in manifest["sources"]:
        analysis=bounded_path(root,entry["analysis_path"],must_exist=True)
        lines.append(f"- source: `{entry['source_path']}` | source_sha256: `{entry['source_sha256']}` | analysis: `{entry['analysis_path']}` | analysis_sha256: `{sha256_file(analysis)}` | formal: `{entry['formal_analysis_path']}`")
    index.parent.mkdir(parents=True,exist_ok=True)
    index.write_text("\n".join(lines)+"\n",encoding="utf-8")
    evidence=expected_aggregation_evidence(root,request)
    path=work_root(request)/"aggregation-evidence.json"
    write_json(path,evidence)
    single=validate_single_analysis_for_request(root,request)
    return {"status":"ready_for_aggregation","analysis_count":single["analysis_count"],"evidence":relative(root,path),
            "source_set_sha256":evidence["source_set_sha256"],**quality}


def analysis_hash_map(root: Path, request: Path, *, formal: bool=False) -> dict[str,str]:
    manifest=current_manifest(root,request); out={}
    for e in manifest["sources"]:
        key=e["formal_analysis_path"] if formal else e["analysis_path"]
        path=bounded_path(root,key,must_exist=formal)
        out[key]=e["source_sha256"]
    return out


def expected_identity_statuses(root: Path, request: Path) -> dict[str,str]:
    manifest=current_manifest(root,request)
    char_count=sum(e["source_kind"]=="character" for e in manifest["sources"])
    logos=scan_logo_assets(root)
    inventory=scan_all_visual_sources(root,request); refs=unique_reference_inventory(inventory)
    return {
        "character_identity_status":"established" if char_count else "none",
        "brand_identity_status":"established" if logos else "none",
        "reference_playbook_status":"none" if not refs else ("established" if len(refs)<=100 else "partial"),
    }

def validate_synthesis_ledger(root: Path, request: Path) -> dict[str, Any]:
    path=work_root(request)/"synthesis-ledger.json"
    value=load_json(path)
    require(value.get("schema_version")==1,"synthesis-ledger.json schema_version must be 1")
    manifest=current_manifest(root,request)
    require(value.get("project_context_sha256")==project_context_sha256(root),"synthesis ledger project context mismatch")
    require(value.get("source_set_sha256")==source_set_sha256(manifest["sources"]),"synthesis ledger source set mismatch")
    claims=value.get("claims"); require(isinstance(claims,list) and claims,"synthesis ledger needs claims")
    allowed_types={"project-identity","output-landscape","visual-dna","historical-prior","floor-candidate","boundary","innovation-opportunity","identity-system","asset-identity"}
    allowed_roles={"prior","floor-candidate","identity","boundary","opportunity"}
    allowed_conf={"high","medium","low"}
    all_formal={e["formal_analysis_path"] for e in manifest["sources"]}
    claim_ids=set(); claim_evidence:dict[str,set[str]]={}; normalized=[]
    for idx,claim in enumerate(claims):
        require(isinstance(claim,dict),f"synthesis claim {idx} must be object")
        cid=str(claim.get("claim_id","")).strip(); require(valid_character_id(cid) and cid not in claim_ids,f"invalid/duplicate synthesis claim_id: {cid}")
        claim_ids.add(cid)
        require(claim.get("claim_type") in allowed_types,f"synthesis claim {cid} claim_type invalid")
        require(claim.get("baseline_role") in allowed_roles,f"synthesis claim {cid} baseline_role invalid")
        require(claim.get("confidence") in allowed_conf,f"synthesis claim {cid} confidence invalid")
        statement=str(claim.get("statement","")).strip(); scope=str(claim.get("scope","")).strip()
        diff=str(claim.get("differentiation_test","")).strip(); effect=str(claim.get("one_shot_effect","")).strip()
        for text_value,label,minimum in ((statement,"statement",12),(scope,"scope",6),(diff,"differentiation_test",10),(effect,"one_shot_effect",10)):
            concrete_text(text_value,f"synthesis claim {cid} {label}",minimum=minimum)
        generic=("高品质","电影感","冲击力强","构图有层次","角色清晰","色彩统一")
        require(not any(statement.strip()==g for g in generic),f"synthesis claim {cid} is generic, not project-specific")
        ev=claim.get("evidence_paths"); counter=claim.get("counterevidence_paths",[])
        require(isinstance(ev,list) and ev and all(isinstance(x,str) for x in ev),f"synthesis claim {cid} evidence_paths invalid")
        require(isinstance(counter,list) and all(isinstance(x,str) for x in counter),f"synthesis claim {cid} counterevidence_paths invalid")
        evset=set(ev); cset=set(counter)
        require(evset<=all_formal,f"synthesis claim {cid} uses unknown evidence")
        require(cset<=all_formal,f"synthesis claim {cid} uses unknown counterevidence")
        require(not(evset & cset),f"synthesis claim {cid} evidence/counterevidence overlap")
        claim_evidence[cid]=evset
        norm=re.sub(r"[^\w\u4e00-\u9fff]+","",statement.casefold())
        normalized.append((cid,norm))
    for i,(a_id,a) in enumerate(normalized):
        for b_id,b in normalized[i+1:]:
            if min(len(a),len(b))>=24:
                require(SequenceMatcher(None,a,b,autojunk=False).ratio()<0.90,f"synthesis claims are near-copies: {a_id}, {b_id}")
    participation=value.get("analysis_participation")
    require(isinstance(participation,dict),"synthesis ledger analysis_participation must be object")
    require(set(participation)==all_formal,"synthesis ledger must account for every formal deep analysis exactly once as a key")
    for analysis_path,ids in participation.items():
        require(isinstance(ids,list) and ids and all(isinstance(i,str) and i in claim_ids for i in ids),f"analysis participation invalid: {analysis_path}")
        require(any(analysis_path in claim_evidence[i] for i in ids),f"analysis participation must point to a claim that actually cites it: {analysis_path}")
    return {"claim_count":len(claims),"analysis_participation_count":len(participation),"ledger":relative(root,path)}


def validate_grounding_review(root: Path, request: Path) -> dict[str, Any]:
    """Validate an independent image-to-analysis grounding receipt before synthesis can publish."""
    path = work_root(request) / "grounding-review.json"
    value = load_json(path)
    require(value.get("schema_version") == 1 and value.get("reviewer_type") == "independent-visual-model" and
            str(value.get("reviewer_id", "")).strip() and str(value.get("method", "")).strip(),
            "grounding-review.json must identify an independent visual model and review method")
    require(value.get("visual_grounding_gate_version") == VISUAL_GROUNDING_GATE_VERSION,
            "grounding review uses an outdated gate version")
    manifest = current_manifest(root, request)
    expected = {entry["source_path"]: entry for entry in manifest["sources"]}
    rows = value.get("sources")
    require(isinstance(rows, list) and {str(row.get("source_path")) for row in rows if isinstance(row, dict)} == set(expected),
            "grounding review must cover every selected source exactly once")
    seen = set()
    for row in rows:
        require(isinstance(row, dict), "grounding review rows must be objects")
        source = str(row.get("source_path", "")); require(source in expected and source not in seen, f"invalid/duplicate grounding source: {source}")
        seen.add(source); entry = expected[source]
        require(str(row.get("source_sha256", "")) == entry["source_sha256"], f"grounding source hash mismatch: {source}")
        require(row.get("decision") == "pass", f"grounding review failed for {source}")
        score = row.get("reconstruction_score"); require(isinstance(score, (int, float)) and 0 <= score <= 5 and score >= 4,
                                                            f"grounding reconstruction score must be >=4/5: {source}")
        for field in ("omitted_objects", "wrong_objects", "spatial_errors", "action_errors", "ui_errors", "light_errors"):
            require(isinstance(row.get(field), list) and not row[field], f"grounding review has {field}: {source}")
    return {"status": "passed", "review": relative(root, path), "source_count": len(rows), "review_sha256": sha256_file(path)}


def self_test(root: Path) -> dict[str, Any]:
    """Fast contract regression that does not require a project or model credentials."""
    # This test imports another Runtime script; avoid creating pycache artifacts
    # inside the candidate tree, which is a release input and must stay clean.
    previous_dont_write_bytecode = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        return _self_test(root)
    finally:
        sys.dont_write_bytecode = previous_dont_write_bytecode


def _self_test(root: Path) -> dict[str, Any]:
    """Implementation kept separate so the bytecode guard covers all imports."""
    require(REVERSE_ANALYSIS_CONTRACT_VERSION == 2 and VISUAL_GROUNDING_GATE_VERSION == 2,
            "reverse-analysis contract constants drifted")
    require(REVERSE_ANALYSIS_SKILL_VERSION == "reverse-analysis-v2", "reverse-analysis skill version is not stable")
    # The bootstrap and gate must agree for both registry states; otherwise a valid
    # publication can be reported stale before the user request reaches Baseline.
    init_path = AGENTS_ROOT / "scripts" / "workspace_init.py"
    init_spec = importlib.util.spec_from_file_location("baseline_init_contract_test", init_path)
    require(init_spec is not None and init_spec.loader is not None, "workspace initialization script cannot be loaded")
    init_module = importlib.util.module_from_spec(init_spec)
    init_spec.loader.exec_module(init_module)
    with tempfile.TemporaryDirectory(prefix="baseline-context-contract-") as temp:
        fixture = Path(temp)
        project = fixture / "project"
        project.mkdir()
        brief = project / "project-brief.md"
        brief.write_text("# Contract fixture\n", encoding="utf-8")
        (project / "material-index.json").write_text(json.dumps({
            "schema_version": 2,
            "visual_input_fingerprint": "a" * 64,
        }), encoding="utf-8")
        for registry in (None, {"schema_version": 1, "sources": []}):
            registry_path = project / "evidence-registry.json"
            if registry is None:
                if registry_path.exists():
                    registry_path.unlink()
            else:
                registry_path.write_text(json.dumps(registry), encoding="utf-8")
            gate_context = project_context_sha256(fixture)
            init_context = init_module.project_context_sha256("a" * 64, brief)
            require(gate_context == init_context, "workspace initialization and Baseline gate context hashes diverged")
    require(jaccard(semantic_tokens("前景蓝色数字门沿道路消失线缩小形成路径选择"),
                    semantic_tokens("前景蓝色数字门沿道路消失线缩小形成路径选择")) == 1.0,
            "semantic tokenization is not deterministic")
    headings = "\n".join(("## 2. 故事性画面描述", "## 3. 核心主题、构图与镜头", "## 4. 视觉风格与质感",
                           "## 5. 角色动作与场景关系", "## 6. 远景、中景与近景"))
    thin = headings + "\nstory: 一个主体。\n" + "\n".join(["subject_map: 主体", "focal_hierarchy: 主体", "visual_route: 主体", "composition_coordinates: 中心", "camera: 镜头", "text_ui: 无", "rendering: 写实", "material_fx: 材质", "color_light: 蓝色", "light_causality: 光", "actions: 站立", "environment_role: 背景", "### 6.1 远景\n背景", "### 6.2 中景\n主体", "### 6.3 近景\n地面"])
    try:
        validate_reference_visual_coverage(thin, {"analysis_path": "self-test"})
    except BaselineGateError:
        rejected = True
    else:
        rejected = False
    require(rejected, "thin reference analysis bypassed blind-reconstruction coverage")
    return {"status": "passed", "checks": ["stable-contract-version", "context-hash-parity", "deterministic-semantic-tokens", "thin-analysis-rejected"]}

def validate_aggregation_for_request(root: Path, request: Path) -> dict[str, Any]:
    single=validate_single_analysis_for_request(root,request); grounding=validate_grounding_review(root,request); validate_no_professional_generators(root,request)
    validate_generated_text_tree(work_root(request),"Baseline work")
    evidence_path=work_root(request)/"aggregation-evidence.json"
    require(evidence_path.is_file(),"aggregation-evidence.json is missing; run prepare-aggregation")
    require(load_json(evidence_path)==expected_aggregation_evidence(root,request),"aggregation-evidence.json is stale; rerun prepare-aggregation")
    synthesis=work_root(request)/"visual-synthesis.md"; text=require_text_file(synthesis,"visual synthesis")
    for heading in SYNTHESIS_REQUIRED_SECTIONS:
        require(text.count(heading)==1,f"visual-synthesis.md must contain section exactly once: {heading}")
        concrete_text(section(text,heading),f"visual synthesis {heading}",minimum=24)
    ledger=validate_synthesis_ledger(root,request)
    expected=expected_identity_statuses(root,request)
    return {"status":"passed","analysis_count":single["analysis_count"],"synthesis":relative(root,synthesis),**grounding,**ledger,**expected}

def validate_character_profiles(root: Path, request: Path, standard_text: str) -> dict[str,Path]:
    manifest=current_manifest(root,request); chars=[e for e in manifest["sources"] if e["source_kind"]=="character"]
    profile_root=work_root(request)/"character-profiles"; verify_root=work_root(request)/"character-verifications"
    expected={e["character_id"]:profile_root/f"{e['character_id']}.md" for e in chars}
    actual={p.stem:p for p in profile_root.glob("*.md")} if profile_root.is_dir() else {}
    require(set(actual)==set(expected),"character profile set must exactly match selected character assets")
    actual_verify={p.stem:p for p in verify_root.glob("*.md")} if verify_root.is_dir() else {}
    require(set(actual_verify)==set(expected),"character verification set must exactly match selected character assets")
    blocks=dict(named_blocks(section(standard_text,"## 6. 角色与品牌身份"),"character_id"))
    require(set(blocks)==set(expected),"formal character registry must exactly match character profiles")
    by_id={e["character_id"]:e for e in chars}
    for cid,path in expected.items():
        text=require_text_file(path,"character production card"); entry=by_id[cid]
        require(text_field(text,"character_profile_schema")=="3",f"character profile schema mismatch: {cid}")
        for name,expected_value in (("character_id",cid),("identity_label",entry["source_label"]),("source_asset_path",entry["source_path"]),("source_sha256",entry["source_sha256"]),
                                    ("formal_analysis_path",entry["formal_analysis_path"]),("analysis_sha256",sha256_file(bounded_path(root,entry["analysis_path"],must_exist=True)))):
            require(text_field(text,name)==expected_value,f"character profile {cid} {name} mismatch")
        for heading in ("## 1. Identity Lock","## 2. Must Preserve","## 3. Flexible","## 4. Never Mix","## 5. Generation Anchor"):
            require(text.count(heading)==1,f"character profile {cid} missing {heading}")
        lock=section(text,"## 1. Identity Lock")
        for field in ("face_shape_skin","eyes_brows","hair_structure_color","body_silhouette","outfit_silhouette","palette","equipment","signature_details"):
            concrete_text(text_field(lock,field),f"character {cid} {field}",minimum=6)
        require(len(bullet_items(section(text,"## 2. Must Preserve")))>=5,f"character {cid} needs >=5 must-preserve items")
        require(len(bullet_items(section(text,"## 3. Flexible")))>=2,f"character {cid} needs >=2 flexible items")
        require(len(bullet_items(section(text,"## 4. Never Mix")))>=3,f"character {cid} needs >=3 never-mix items")
        gen=section(text,"## 5. Generation Anchor")
        concrete_text(text_field(gen,"positive_identity_prompt"),f"character {cid} positive_identity_prompt",minimum=35)
        concrete_text(text_field(gen,"reference_instruction"),f"character {cid} reference_instruction",minimum=12)

        vpath=actual_verify[cid]; vtext=require_text_file(vpath,"character production verification")
        require(text_field(vtext,"verification_schema")=="1",f"character verification schema mismatch: {cid}")
        for name,expected_value in (("character_id",cid),("source_asset_path",entry["source_path"]),("source_sha256",entry["source_sha256"]),
                                    ("analysis_path",entry["analysis_path"]),("analysis_sha256",sha256_file(bounded_path(root,entry["analysis_path"],must_exist=True))),
                                    ("profile_path",relative(root,path)),("profile_sha256",sha256_file(path)),("verification_result","passed")):
            require(text_field(vtext,name)==expected_value,f"character verification {cid} {name} mismatch")
        check=section(vtext,"## 1. Re-checked Visual Identity")
        for field in ("face_hair_check","outfit_silhouette_check","palette_check","equipment_check","signature_detail_check"):
            concrete_text(text_field(check,field),f"character verification {cid} {field}",minimum=8)
        mismatch=section(vtext,"## 2. Mismatch Resolution")
        require(text_field(mismatch,"mismatches").casefold()=="none",f"character verification {cid} still has unresolved mismatches")
        require(text_field(mismatch,"resolution").casefold()=="none",f"character verification {cid} requires card correction before publish")

        block=blocks[cid]
        require(text_field(block,"identity_label")==entry["source_label"],f"standard character {cid} label mismatch")
        require(text_field(block,"profile_path")==f"project/baselines/character-profiles/{cid}.md",f"standard character {cid} profile path mismatch")
        require(text_field(block,"verification_path")==f"project/baselines/character-verifications/{cid}.md",f"standard character {cid} verification path mismatch")
        require(text_field(block,"analysis_path")==entry["formal_analysis_path"],f"standard character {cid} analysis path mismatch")
        require(text_field(block,"source_asset_path")==entry["source_path"],f"standard character {cid} source path mismatch")
        for field in ("identity_summary","must_keep","flexible","never_mix"):
            concrete_text(text_field(block,field),f"standard character {cid} {field}",minimum=8)
    return expected

def validate_brand_profile(root: Path, request: Path, standard_text: str) -> dict[str,str]:
    logos=scan_logo_assets(root); body=section(standard_text,"## 6. 角色与品牌身份"); mode=text_field(body,"brand_mode")
    require(mode in {"established","none"},"brand_mode invalid")
    if not logos:
        require(mode=="none","brand_mode must be none when no canonical logo assets exist")
        concrete_text(text_field(body,"brand_fallback"),"brand_fallback",minimum=8)
        require(not (work_root(request)/"brand-profile.md").exists(),"brand-profile.md must not exist without canonical logo assets")
        return {}
    require(mode=="established","canonical logo assets require established brand_mode")
    profile=work_root(request)/"brand-profile.md"; text=require_text_file(profile,"brand production card")
    require(text_field(text,"brand_profile_schema")=="1","brand profile schema mismatch")
    brand_name=text_field(text,"brand_name"); concrete_text(brand_name,"brand_name",minimum=2)
    require(brand_name.casefold() not in {"unknown","项目多语种正式 logo","项目正式 logo","多语种正式 logo","正式 logo","品牌 logo","logo"},"brand_name must identify the visible canonical brand, not describe the file set")
    visible=text_field(text,"brand_name_visible_text"); concrete_text(visible,"brand_name_visible_text",minimum=2)
    brand_ascii=re.sub(r"[^a-z0-9]+","",brand_name.casefold()); visible_ascii=re.sub(r"[^a-z0-9]+","",visible.casefold())
    if len(brand_ascii)>=4:
        require(brand_ascii in visible_ascii or visible_ascii in brand_ascii,"brand_name must be grounded in visible logo text")
    for heading in ("## 1. Visual Identity","## 2. Usage Lock","## 3. Canonical Logo Assets"):
        require(text.count(heading)==1,f"brand profile missing {heading}")
    identity=section(text,"## 1. Visual Identity")
    for field in ("wordmark_structure","typography_shape","color_material","symbol_motifs","silhouette","protected_details"):
        concrete_text(text_field(identity,field),f"brand {field}",minimum=8)
    require(len(bullet_items(section(text,"## 2. Usage Lock")))>=4,"brand profile needs >=4 usage locks")
    expected={i["logo_path"]:i for i in logos}; seen={}
    for locale,block in named_blocks(section(text,"## 3. Canonical Logo Assets"),"logo_locale"):
        path=text_field(block,"logo_path"); digest=text_field(block,"logo_sha256")
        require(path in expected and path not in seen,f"brand profile logo path invalid/duplicate: {path}")
        require(digest==expected[path]["logo_sha256"],f"brand profile logo hash mismatch: {path}")
        seen[path]=locale
    require(set(seen)==set(expected),"brand profile must register every unique canonical logo asset")
    require(text_field(body,"brand_name")==brand_name,"formal Baseline brand_name must match Brand Production Card")
    require(text_field(body,"brand_profile_path")=="project/baselines/brand-profile.md","formal Baseline brand_profile_path mismatch")
    concrete_text(text_field(body,"brand_summary"),"brand_summary",minimum=8)
    concrete_text(text_field(body,"brand_presence"),"brand_presence",minimum=6)
    concrete_text(text_field(body,"logo_usage_rule"),"logo_usage_rule",minimum=8)
    return seen

def expected_presence(count: int, total: int, *, explicit_outlier: bool = False) -> str:
    require(count >= 1 and total >= count, "invalid family presence counts")
    if explicit_outlier and count == 1:
        return "outlier"
    ratio = count / total if total else 0.0
    if ratio >= 0.35:
        return "dominant"
    if ratio >= 0.15:
        return "common"
    if ratio >= 0.05:
        return "secondary"
    return "rare"


def parse_family_blocks(root: Path, request: Path, text: str, formal_refs:set[str], all_formal:set[str], census:dict[str,Any]|None=None) -> dict[str,dict[str,Any]]:
    body=section(text,"## 3. 当前产出结构"); families={}; covered_clusters=set()
    census_clusters={str(i["cluster_id"]) for i in census.get("clusters",[])} if census else set()
    census_rows=census.get("sources",[]) if census else []
    cluster_rows:dict[str,list[dict[str,Any]]]={}
    for row in census_rows: cluster_rows.setdefault(str(row["cluster_id"]),[]).append(row)
    manifest=current_manifest(root,request); by_formal={e["formal_analysis_path"]:e for e in manifest["sources"]}
    project_evidence={e["formal_analysis_path"] for e in manifest["sources"]
                      if e.get("evidence_role") in {"canonical-identity", "historical-project-output", "gameplay-evidence"}}
    total_refs=len(unique_reference_inventory(scan_all_visual_sources(root,request)))
    family_fields={
        "family_name":4,"business_job":10,"dominant_visual_question":10,"what_it_looks_like":20,
        "visual_hierarchy":14,"composition_camera":14,"color_light_material":14,
        "character_environment_relation":12,"text_logo_ui":10,"typical_variants":12,
        "failure_modes":10,"start_when":10,"do_not_use_when":10,
    }
    signatures=[]
    for fid,block in named_blocks(body,"family_id"):
        require(fid not in families and valid_character_id(fid),f"invalid or duplicate family_id: {fid}")
        authority=text_field(block,"family_authority"); require(authority in {"reference-playbook","project-evidence"},f"family {fid} authority invalid")
        for field,minimum in family_fields.items(): concrete_text(text_field(block,field),f"family {fid} {field}",minimum=minimum)
        evidence=split_ids(text_field(block,"evidence")); require(evidence and evidence<=all_formal,f"family {fid} evidence invalid")
        clusters=split_ids(text_field(block,"cluster_ids"))
        if authority=="reference-playbook":
            require(evidence<=formal_refs,f"family {fid} reference-playbook must use reference analyses only")
            if census_clusters:
                require(clusters and clusters<=census_clusters,f"family {fid} must bind valid census cluster_ids")
                require(not (covered_clusters & clusters),f"reference census cluster claimed by multiple families: {sorted(covered_clusters & clusters)}")
                covered_clusters|=clusters; observed=sum(len(cluster_rows[cid]) for cid in clusters)
                expected_clusters={str(row["cluster_id"]) for row in census_rows if any(by_formal.get(path,{}).get("source_path")==str(row["source_path"]) for path in evidence)}
                require(expected_clusters<=clusters,f"family {fid} deep analyses must come from its bound census clusters")
                explicit_outlier=all(bool(row.get("outlier")) for cid in clusters for row in cluster_rows[cid])
            else:
                require(not clusters,f"family {fid} cluster_ids must be none when no census exists")
                observed=len(evidence); explicit_outlier=False
            require(text_field(block,"observed_source_count")==str(observed),f"family {fid} observed_source_count mismatch")
            require(text_field(block,"deep_analysis_count")==str(len(evidence)),f"family {fid} deep_analysis_count mismatch")
            require(text_field(block,"presence")==expected_presence(observed,max(total_refs,observed),explicit_outlier=explicit_outlier),f"family {fid} presence mismatch")
        else:
            require(not clusters,f"project-evidence family {fid} must not claim reference census clusters")
            require(bool(evidence & project_evidence),f"project-evidence family {fid} requires canonical, historical-output, or gameplay evidence")
            require(text_field(block,"observed_source_count")==str(len(evidence)),f"family {fid} observed_source_count mismatch")
            require(text_field(block,"deep_analysis_count")==str(len(evidence)),f"family {fid} deep_analysis_count mismatch")
            require(text_field(block,"presence") in {"dominant","common","secondary","rare","outlier"},f"family {fid} presence invalid")
        sig=" ".join(text_field(block,f) for f in ("business_job","dominant_visual_question","visual_hierarchy","composition_camera","color_light_material","character_environment_relation","text_logo_ui"))
        sig=re.sub(r"[^\w\u4e00-\u9fff]+","",sig.casefold()); signatures.append((fid,sig))
        families[fid]={"authority":authority,"evidence":evidence,"clusters":clusters}
    non_character={e["formal_analysis_path"] for e in manifest["sources"] if e["source_kind"]!="character"}
    if non_character: require(families,"projects with non-character visual evidence must contain output families")
    else: concrete_text(body,"current output structure",minimum=12)
    if census_clusters: require(covered_clusters==census_clusters,"formal output families must cover every census visual cluster exactly once")
    for i,(left,a) in enumerate(signatures):
        for right,b in signatures[i+1:]:
            if min(len(a),len(b))>=80:
                require(SequenceMatcher(None,a,b,autojunk=False).ratio()<0.88,f"families are semantically near-duplicates and need merge/repartition: {left}, {right}")
    return families

def validate_visual_dna_blocks(text:str, all_formal:set[str], non_character_count:int) -> dict[str,dict[str,Any]]:
    body=section(text,"## 4. 跨产出视觉 DNA"); dna={}; generic_exact={"角色清晰","构图有层次","色彩统一","画面有冲击力","电影感强","高品质"}
    for did,block in named_blocks(body,"dna_id"):
        require(did not in dna and valid_character_id(did),f"invalid or duplicate dna_id: {did}")
        presence=text_field(block,"presence"); require(presence in {"core","frequent","situational"},f"dna {did} presence invalid")
        for field,minimum in (("statement",12),("project_specificity",12),("one_shot_effect",10),("scope",8),("counterexamples",6)):
            concrete_text(text_field(block,field),f"dna {did} {field}",minimum=minimum)
        require(text_field(block,"statement").strip() not in generic_exact,f"dna {did} is generic design advice, not project-specific")
        evidence=split_ids(text_field(block,"evidence")); require(evidence and evidence<=all_formal,f"dna {did} evidence invalid")
        if presence in {"core","frequent"} and non_character_count>=2: require(len(evidence)>=2,f"dna {did} marked {presence} needs multiple evidence sources")
        dna[did]={"presence":presence,"evidence":evidence}
    if non_character_count>=2: require(len(dna)>=2,"projects with multiple outputs need at least two synthesized Visual DNA claims")
    else: concrete_text(body,"visual DNA section",minimum=12)
    return dna

def validate_comparison_blocks(text:str, families:set[str], all_formal:set[str])->dict[str,dict[str,Any]]:
    body=section(text,"## 5. 产出差异决策"); comparisons={}
    for cid,block in named_blocks(body,"comparison_id"):
        require(cid not in comparisons and valid_character_id(cid),f"invalid or duplicate comparison_id: {cid}")
        pair=list(split_ids(text_field(block,"between"))); require(len(pair)==2 and set(pair)<=families,f"comparison {cid} must compare exactly two known families")
        for field,minimum in (("shared_core",10),("decisive_difference",14),("choose_first_when",10),("choose_second_when",10),("do_not_merge",10)):
            concrete_text(text_field(block,field),f"comparison {cid} {field}",minimum=minimum)
        evidence=split_ids(text_field(block,"evidence")); require(evidence and evidence<=all_formal,f"comparison {cid} evidence invalid")
        comparisons[cid]={"between":set(pair),"evidence":evidence}
    if len(families)>=2: require(comparisons,"two or more output families require explicit cross-family differentiation")
    else: concrete_text(body,"output difference decision section",minimum=10)
    return comparisons

def validate_floor_blocks(root:Path, text:str, all_formal:set[str], profiles:set[str], brand_exists:bool) -> dict[str,dict[str,Any]]:
    body=section(text,"## 7. Baseline Floor｜最低合格线"); floors={}
    allowed_types={"project-likeness","identity","brand","quality","readability","asset-boundary"}
    allowed_project_paths={f"project/baselines/character-profiles/{cid}.md" for cid in profiles}
    if brand_exists: allowed_project_paths.add("project/baselines/brand-profile.md")
    for fid,block in named_blocks(body,"floor_id"):
        require(fid not in floors and valid_character_id(fid),f"invalid or duplicate floor_id: {fid}")
        ftype=text_field(block,"floor_type"); require(ftype in allowed_types,f"floor {fid} floor_type invalid")
        for field in ("requirement","scope","why_floor"):
            concrete_text(text_field(block,field),f"floor {fid} {field}",minimum=7)
        evidence=split_ids(text_field(block,"evidence")); require(evidence,f"floor {fid} requires evidence")
        for path in evidence:
            if path in all_formal or path in allowed_project_paths: continue
            require(path.startswith("project/"),f"floor {fid} evidence path invalid: {path}")
            bounded_path(root,path,must_exist=True)
        floors[fid]={"type":ftype,"evidence":evidence}
    require(floors,"formal Baseline must define at least one minimum floor")
    return floors


def validate_innovation_section(text:str) -> None:
    body=section(text,"## 8. 创新空间｜Baseline 不是上限")
    require(text_field(body,"baseline_role")=="floor-not-ceiling","innovation section must declare baseline_role: floor-not-ceiling")
    require(text_field(body,"existing_families_are")=="priors-not-whitelist","innovation section must declare existing_families_are: priors-not-whitelist")
    for field in ("mature_spaces","underexplored_spaces","new_direction_rule","do_not_freeze","variation_axes","failure_mode"):
        concrete_text(text_field(body,field),field,minimum=8)


def validate_routes_v8(text:str, families:set[str], floors:set[str])->dict[str,dict[str,set[str]]]:
    routes={}; has_novel=False
    for rid,block in named_blocks(section(text,"## 9. 一稿校准"),"route_id"):
        require(rid not in routes and valid_character_id(rid),f"invalid or duplicate route_id: {rid}")
        concrete_text(text_field(block,"when"),f"route {rid} when",minimum=6)
        fam=split_ids(text_field(block,"start_family_ids")); floor_ids=split_ids(text_field(block,"required_floor_ids"))
        require(fam<=families,f"route {rid} unknown family"); require(floor_ids<=floors,f"route {rid} unknown floor")
        if not fam: has_novel=True
        for field,minimum in (("first_three_decisions",14),("preserve",8),("can_break",8),("failure_check",8),("success_check",8)):
            concrete_text(text_field(block,field),f"route {rid} {field}",minimum=minimum)
        routes[rid]={"families":fam,"floors":floor_ids}
    require(routes,"formal Baseline needs at least one one-shot calibration route")
    require(has_novel,"formal Baseline must include at least one route with start_family_ids: none")
    return routes

def validate_project_standard_for_request(root: Path, request: Path) -> dict[str, Any]:
    validate_project_brief_ownership(root); synthesis=validate_aggregation_for_request(root,request); manifest=current_manifest(root,request)
    validate_generated_text_tree(work_root(request),"Baseline work")
    standard=work_root(request)/"project-visual-standard.md"; text=require_text_file(standard,"project visual standard"); normalized=text.replace("\\","/").casefold()
    require("requests/" not in normalized and "/work/" not in normalized and not re.search(r"(?m)^work/",normalized),"formal Baseline must not depend on request/work paths")
    for heading in STANDARD_REQUIRED_SECTIONS_V8: require(text.count(heading)==1,f"project visual standard must contain section exactly once: {heading}")
    s1=section(text,"## 1. 基准定位")
    require(text_field(s1,"schema_version")==BASELINE_SCHEMA,"project visual standard schema_version must be 8")
    require(text_field(s1,"baseline_status")=="usable","baseline_status must be usable")
    expected_status=expected_identity_statuses(root,request)
    for name,value in expected_status.items(): require(text_field(s1,name)==value,f"{name} must match current evidence coverage: {value}")
    require(text_field(s1,"project_context_sha256")==project_context_sha256(root),"project_context_sha256 mismatch")
    require(text_field(s1,"source_set_sha256")==source_set_sha256(manifest["sources"]),"source_set_sha256 mismatch")
    require(text_field(s1,"source_count")==str(len(manifest["sources"])),"source_count mismatch")
    for field in ("baseline_scope","project_visual_summary","authority_boundary"): concrete_text(text_field(s1,field),field,minimum=8)
    require(text_field(s1,"baseline_role")=="floor-not-ceiling","baseline_role must be floor-not-ceiling")

    s2=section(text,"## 2. 项目视觉认知")
    profile_fields=("project_identity","production_context","visual_job","current_output_landscape","signature_impression","recognition_system","default_visual_hierarchy","recurring_tensions","quality_bar_character","not_the_project")
    for field in profile_fields: concrete_text(text_field(s2,field),field,minimum=12)
    generic_tokens=("高品质","电影感","高级感","冲击力强","精致","好看","构图有层次")
    combined=" ".join(text_field(s2,f) for f in profile_fields)
    require(sum(token in combined for token in generic_tokens)<4,"project visual cognition is dominated by generic design language")

    all_formal={e["formal_analysis_path"] for e in manifest["sources"]}; formal_refs={e["formal_analysis_path"] for e in manifest["sources"] if e["source_kind"]=="reference"}
    inventory=scan_all_visual_sources(root,request); refs=unique_reference_inventory(inventory); census=None
    if len(refs)>100: census=validate_reference_census(root,request,inventory)
    families=parse_family_blocks(root,request,text,formal_refs,all_formal,census)
    non_character_count=sum(e["source_kind"]!="character" for e in manifest["sources"])
    dna=validate_visual_dna_blocks(text,all_formal,non_character_count)
    comparisons=validate_comparison_blocks(text,set(families),all_formal)
    profiles=validate_character_profiles(root,request,text)
    brand=validate_brand_profile(root,request,text)
    floors=validate_floor_blocks(root,text,all_formal,set(profiles),bool(brand))
    validate_innovation_section(text)
    routes=validate_routes_v8(text,set(families),set(floors))

    boundary=section(text,"## 10. 证据边界与刷新")
    require(text_field(boundary,"deep_analysis_coverage")=="100%","deep_analysis_coverage must be 100%")
    expected_census="100%" if len(refs)>100 else "not-required"
    require(text_field(boundary,"reference_census_coverage")==expected_census,f"reference_census_coverage must be {expected_census}")
    require(text_field(boundary,"synthesis_ledger")=="project/baselines/synthesis-ledger.json","formal Baseline must point to published synthesis ledger")
    for field in ("known","unknown","never_infer","refresh_when"): concrete_text(text_field(boundary,field),field,minimum=8)

    char_covered={text_field(block,"analysis_path") for _,block in named_blocks(section(text,"## 6. 角色与品牌身份"),"character_id")}
    expected_char={e["formal_analysis_path"] for e in manifest["sources"] if e["source_kind"]=="character"}
    require(char_covered==expected_char,"every character deep analysis must be integrated into the identity section")
    return {"status":"passed","character_profiles":len(profiles),"family_count":len(families),"dna_count":len(dna),"comparison_count":len(comparisons),"floor_count":len(floors),
            "brand_assets":len(brand),"route_count":len(routes),"synthesis_claim_count":synthesis["claim_count"],"standard":relative(root,standard),**expected_status}

def build_baseline_index(root: Path) -> Path:
    baseline=root/"project/baselines/project-visual-standard.md"; text=require_text_file(baseline,"formal project visual standard")
    def ids(field_name:str)->list[str]: return sorted(set(re.findall(rf"(?m)^{re.escape(field_name)}:\s*([^\s]+)\s*$",text)))
    meta=section(text,"## 1. 基准定位")
    reference_map=root/"project/baselines/reference-map.json"; brand_profile=root/"project/baselines/brand-profile.md"
    family_refs={}
    for fid,block in named_blocks(section(text,"## 3. 当前产出结构"),"family_id"):
        family_refs[fid]=sorted(split_ids(text_field(block,"evidence")))
    payload={"schema_version":BASELINE_INDEX_SCHEMA,"baseline_schema_version":BASELINE_SCHEMA,"baseline_sha256":sha256_file(baseline),
             "project_context_sha256":text_field(meta,"project_context_sha256"),"source_set_sha256":text_field(meta,"source_set_sha256"),
             "character_identity_status":text_field(meta,"character_identity_status"),"brand_identity_status":text_field(meta,"brand_identity_status"),
             "reference_playbook_status":text_field(meta,"reference_playbook_status"),"source_count":int(text_field(meta,"source_count")),
             "family_ids":ids("family_id"),"character_ids":ids("character_id"),"dna_ids":ids("dna_id"),"comparison_ids":ids("comparison_id"),"floor_ids":ids("floor_id"),"route_ids":ids("route_id"),
             "family_analysis_paths":family_refs,"consumers":sorted(CONSUMERS),
             "reference_map_sha256":sha256_file(reference_map) if reference_map.is_file() else None,
             "brand_profile_sha256":sha256_file(brand_profile) if brand_profile.is_file() else None,
             "synthesis_ledger_sha256":sha256_file(root/"project/baselines/synthesis-ledger.json") if (root/"project/baselines/synthesis-ledger.json").is_file() else None}
    path=root/"project/baselines/index.json"; write_json(path,payload); return path

def expected_published_files(root:Path,request:Path)->set[Path]:
    manifest=current_manifest(root,request); base=(root/"project/baselines").resolve(); out=set()
    for entry in manifest["sources"]: out.add(bounded_path(root,entry["formal_analysis_path"]).resolve())
    for entry in manifest["sources"]:
        if entry["source_kind"]=="character":
            out.add((base/"character-profiles"/f"{entry['character_id']}.md").resolve())
            out.add((base/"character-verifications"/f"{entry['character_id']}.md").resolve())
    if scan_logo_assets(root): out.add((base/"brand-profile.md").resolve())
    inventory=scan_all_visual_sources(root,request)
    if len(unique_reference_inventory(inventory))>100: out.add((base/"reference-map.json").resolve())
    out.add((base/"synthesis-ledger.json").resolve())
    out|={(base/"project-visual-standard.md").resolve(),(base/"index.json").resolve(),(base/"publication.json").resolve()}; return out

def validate_published_for_request(root: Path, request: Path) -> dict[str, Any]:
    manifest=current_manifest(root,request); base=root/"project/baselines"
    for entry in manifest["sources"]:
        work=bounded_path(root,entry["analysis_path"],must_exist=True); formal=bounded_path(root,entry["formal_analysis_path"],must_exist=True)
        require(sha256_file(work)==sha256_file(formal),f"published analysis differs: {entry['formal_analysis_path']}")
    profiles=work_root(request)/"character-profiles"; verifications=work_root(request)/"character-verifications"
    for entry in manifest["sources"]:
        if entry["source_kind"]!="character": continue
        for work,formal in ((profiles/f"{entry['character_id']}.md",base/"character-profiles"/f"{entry['character_id']}.md"),
                            (verifications/f"{entry['character_id']}.md",base/"character-verifications"/f"{entry['character_id']}.md")):
            require(formal.is_file() and sha256_file(work)==sha256_file(formal),f"published character artifact differs: {entry['character_id']}")
    if scan_logo_assets(root):
        require((base/"brand-profile.md").is_file() and sha256_file(work_root(request)/"brand-profile.md")==sha256_file(base/"brand-profile.md"),"published brand profile differs")
    inventory=scan_all_visual_sources(root,request)
    if len(unique_reference_inventory(inventory))>100:
        require((base/"reference-map.json").is_file() and sha256_file(reference_census_path(request))==sha256_file(base/"reference-map.json"),"published reference map differs")
    work_ledger=work_root(request)/"synthesis-ledger.json"; formal_ledger=base/"synthesis-ledger.json"
    require(formal_ledger.is_file() and sha256_file(work_ledger)==sha256_file(formal_ledger),"published synthesis ledger differs")
    work_standard=work_root(request)/"project-visual-standard.md"; formal_standard=base/"project-visual-standard.md"
    require(formal_standard.is_file() and sha256_file(work_standard)==sha256_file(formal_standard),"published standard differs from validated work standard")
    validate_generated_text_tree(base,"published Baseline")
    index=base/"index.json"; receipt=base/"publication.json"; require(index.is_file() and receipt.is_file(),"published Baseline lacks index/publication receipt")
    idx=load_json(index);pub=load_json(receipt)
    require(idx.get("schema_version")==BASELINE_INDEX_SCHEMA and idx.get("baseline_schema_version")==BASELINE_SCHEMA and idx.get("baseline_sha256")==sha256_file(formal_standard),"Baseline index is stale")
    require(pub.get("schema_version")==BASELINE_INDEX_SCHEMA and pub.get("baseline_sha256")==sha256_file(formal_standard) and pub.get("index_sha256")==sha256_file(index)
            and pub.get("project_context_sha256")==project_context_sha256(root) and pub.get("source_set_sha256")==source_set_sha256(manifest["sources"]),"publication receipt is stale")
    snapshot={relative(root,p):sha256_file(p) for p in sorted(base.rglob("*")) if p.is_file() and p.name!="publication.json"}
    require(pub.get("files")==snapshot,"publication receipt file snapshot is stale")
    actual={p.resolve() for p in base.rglob("*") if p.is_file()}; require(actual==expected_published_files(root,request),"project/baselines contains unsupported/stale files")
    return {"status":"passed","analysis_count":len(manifest["sources"]),
            "character_profiles":sum(entry["source_kind"] == "character" for entry in manifest["sources"]),
            "baseline":relative(root,formal_standard),"baseline_sha256":sha256_file(formal_standard),
            "reference_map":relative(root,base/"reference-map.json") if (base/"reference-map.json").is_file() else None}

def publish_for_request(root: Path, request: Path) -> dict[str, Any]:
    validation=validate_project_standard_for_request(root,request); manifest=current_manifest(root,request); baselines=root/"project/baselines"; (root/"tmp").mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="baseline-publish-",dir=root/"tmp") as temp_value:
        temp=Path(temp_value);stage=temp/"stage";backup=temp/"backup"
        if baselines.exists(): shutil.copytree(baselines,backup)
        for entry in manifest["sources"]:
            src=bounded_path(root,entry["analysis_path"],must_exist=True);dst=stage/Path(entry["formal_analysis_path"]).relative_to("project/baselines");dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
        for entry in manifest["sources"]:
            if entry["source_kind"]!="character": continue
            for folder in ("character-profiles","character-verifications"):
                src=work_root(request)/folder/f"{entry['character_id']}.md";dst=stage/folder/src.name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
        if scan_logo_assets(root): shutil.copy2(work_root(request)/"brand-profile.md",stage/"brand-profile.md")
        inventory=scan_all_visual_sources(root,request)
        if len(unique_reference_inventory(inventory))>100: shutil.copy2(reference_census_path(request),stage/"reference-map.json")
        shutil.copy2(work_root(request)/"synthesis-ledger.json",stage/"synthesis-ledger.json")
        src=work_root(request)/"project-visual-standard.md";stage.mkdir(parents=True,exist_ok=True);shutil.copy2(src,stage/"project-visual-standard.md")
        validate_generated_text_tree(stage,"Baseline publication stage")
        try:
            if baselines.exists(): shutil.rmtree(baselines)
            shutil.copytree(stage,baselines);index=build_baseline_index(root);standard=baselines/"project-visual-standard.md"
            snapshot={relative(root,p):sha256_file(p) for p in sorted(baselines.rglob("*")) if p.is_file() and p.name!="publication.json"}
            write_json(baselines/"publication.json",{"schema_version":BASELINE_INDEX_SCHEMA,"baseline_schema_version":BASELINE_SCHEMA,"baseline_sha256":sha256_file(standard),"index_sha256":sha256_file(index),
                       "project_context_sha256":project_context_sha256(root),"source_set_sha256":source_set_sha256(manifest["sources"]),"analysis_count":len(manifest["sources"]),"files":snapshot})
            published=validate_published_for_request(root,request)
        except Exception:
            if baselines.exists(): shutil.rmtree(baselines)
            if backup.exists(): shutil.copytree(backup,baselines)
            raise
    return {"status":"published","source_count":len(manifest["sources"]),"character_profiles":validation["character_profiles"],"family_count":validation["family_count"],
            "character_identity_status":validation["character_identity_status"],"brand_identity_status":validation["brand_identity_status"],
            "reference_playbook_status":validation["reference_playbook_status"],"validation":published,"index":"project/baselines/index.json","publication":"project/baselines/publication.json"}

def doctor(args: argparse.Namespace) -> dict[str, Any]:
    require(Image is not None,"Pillow is required")
    return {"status":"ready","tool":"baseline_gate","baseline_schema":BASELINE_SCHEMA,
            "capabilities":["complete-source-inventory","full-reference-census","full-deep-analysis-up-to-100-references",
                            "semantic-reference-clustering","cluster-covered-representative-selection","one-source-one-analysis",
                            "analysis-contract-cache-invalidation","blind-reconstruction-coverage","swap-test-and-semantic-template-rejection",
                            "independent-grounding-review","baseline-contract-self-test","cross-source-template-rejection","verified-character-production-card",
                            "brand-production-card","project-level-visual-synthesis","synthesis-ledger","one-shot-calibration",
                            "utf8-text-integrity","exact-snapshot-publication","baseline-index"]}


def main() -> int:
    parser=argparse.ArgumentParser(description=__doc__); subs=parser.add_subparsers(dest="command",required=True)
    for name in ("build-source-manifest","prepare-analyses","validate-inventory","validate-single-analysis","validate-grounding-review","prepare-aggregation",
                 "validate-aggregation","validate-project-standard","publish","validate-published"):
        cmd=subs.add_parser(name); cmd.add_argument("--request",required=True); cmd.add_argument("--workspace-root",type=Path,default=Path(__file__).resolve().parents[4])
    self_test_cmd=subs.add_parser("self-test"); self_test_cmd.add_argument("--workspace-root",type=Path,default=Path(__file__).resolve().parents[4])
    health=subs.add_parser("doctor"); health.add_argument("--workspace-root",type=Path,default=Path(__file__).resolve().parents[4])
    args=parser.parse_args()
    try:
        root=args.workspace_root.resolve(); require(root.is_dir(),f"Workspace root does not exist: {root}")
        if args.command=="doctor": result=doctor(args)
        elif args.command=="self-test": result=self_test(root)
        else:
            request=request_path(root,args.request)
            funcs={"build-source-manifest":build_source_manifest,"prepare-analyses":prepare_cached_analyses,
                   "validate-inventory":validate_inventory_for_request,"validate-single-analysis":validate_single_analysis_for_request,
                   "validate-grounding-review":validate_grounding_review,
                   "prepare-aggregation":prepare_aggregation_for_request,"validate-aggregation":validate_aggregation_for_request,
                   "validate-project-standard":validate_project_standard_for_request,"publish":publish_for_request,
                   "validate-published":validate_published_for_request}
            result=funcs[args.command](root,request)
        print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
    except (BaselineGateError,TextIntegrityError,OSError,json.JSONDecodeError) as exc:
        print(json.dumps({"status":"blocked","reason":str(exc)},ensure_ascii=False,indent=2)); return 1

if __name__=="__main__": sys.exit(main())
