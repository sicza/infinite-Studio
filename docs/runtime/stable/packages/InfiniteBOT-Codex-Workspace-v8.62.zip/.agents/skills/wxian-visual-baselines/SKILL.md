---
name: wxian-visual-baselines
description: 从项目真实资产、历史项目产出与 curated Reference 建立/刷新唯一正式 Project Visual Baseline。核心职责不是把单图分析填进 Schema，而是像资深视觉负责人一样完成项目级视觉综合判断：理解项目是什么、当前产出为何像这个项目、哪些视觉结构高频有效、哪些只是局部模式、最低什么程度才合格、哪些方向可继续突破。所有证据必须参与内部综合，但最终 Baseline 只保留高价值结论，不搬运单图分析。
---

# Project Visual Baseline｜项目视觉综合基准

进入前执行 `$workspace-governance consume-personal-context --request <request> --consumer wxian-visual-baselines`；阻断则停止。

## 0. 你在做什么

这个 Skill 的交付不是“分析汇总表”，而是**项目视觉认知模型**。

本 Skill 仍是唯一 Project Visual Baseline Authority。需要把历史证据抽象成可生成视觉语法时，读取 `references/visual-director-integration.md`，使用 `$sicza-visual-director` 的 `BASELINE_DELTA`、`D-GRAMMAR / D-STYLE / D-SIGN / D-MEM / H-MULTISCALE / G-VERIFY` 作为专业分析方法；不得发布第二份 Visual Baseline、第二份 Family registry 或另一套项目事实。

最终 `project/baselines/project-visual-standard.md` 必须让一个第一次进入项目的 Codex 在**不重新翻全量素材、不读全量单图分析**的情况下，先建立正确的项目脑内图像，并在真实需求里提高一稿命中概率。

Baseline 的正确作用：

- 告诉 Codex：这个项目是什么、现在已经做成什么样；
- 告诉 Codex：什么视觉信号最容易让结果“像这个项目”；
- 告诉 Codex：历史上哪些结构最常成功、各自解决什么业务问题；
- 告诉 Codex：不同历史方向之间真正的差异是什么，什么时候选 A、什么时候不该选 A；
- 告诉 Codex：角色、品牌、资产边界和最低质量线不能错在哪里；
- 告诉 Codex：已有产出是**高概率先验**，不是白名单；当前需求有更优解时可以建立新方向。

Baseline **不是**：

- 单图 Reverse Analysis 的拼接；
- 每张图一条 `source_note` 的审计报账；
- Family 字段填满后的数据库 dump；
- “高品质 / 电影感 / 冲击力 / 层次清楚”这类任何项目都成立的通用原则合集；
- 固定 Prompt、固定构图、固定色调或创意宪章。

正式发布目录：

```text
project/baselines/analyses/**
project/baselines/character-profiles/**
project/baselines/character-verifications/**
project/baselines/brand-profile.md              # 有 canonical Logo 时
project/baselines/reference-map.json             # Reference >100 时
project/baselines/synthesis-ledger.json          # 内部综合证据账本，下游默认不读
project/baselines/project-visual-standard.md     # 唯一主认知基准
project/baselines/index.json
project/baselines/publication.json
```

---

## 1. 先分清“项目产出”与“参考方法”

在开始综合前，先判断每类证据能证明什么。

### Canonical / Project Evidence

可以证明项目自身事实：

- `project/assets/characters/**`：角色身份；
- `project/assets/props/**`：道具/物件身份（含被角色使用的工具、装置、载具部件等）。道具图只证明该物件的结构、配色与使用方向，不证明稀有度、性能或获取规则；文件名里出现角色名不改变它的分类，道具不会被当作角色资产。**规范位置唯一 = `project/assets/props/`**：新素材一律放这里。`project/props/**` 是先于规范目录存在的**历史位置**——为不让项目已记录的素材被误判，Runtime 仍把它**按 props 分类**（不会变成角色），但会**明确报出迁移要求**（`props_location_report` 出 `migration_required` 与逐文件目标路径），不再静默容忍；发现非规范位置的道具时，应把文件移到规范目录并重建该 request 的选择与 Baseline。
- `project/assets/logos/**`：品牌身份；
- `project/assets/game-screenshots/**`、`project/assets/other/**`：游戏内画面与其他正式项目资产。
- 项目真实截图、历史正式 KV/Banner、游戏内画面、官方美术资产：如果它们被明确标记为项目正式产出，可以证明“项目过去真正长什么样”。

Canonical 目录由 `.agents/lib/asset_taxonomy.py` 唯一定义；`characters` 与 `props` 的正式资产必须全部进入深度分析与合成账本。道具身份在合成账本中使用合法的 `claim_type: asset-identity`。

### Reference

`project/references/**` 默认只能证明：

- 构图方法；
- 镜头与空间机制；
- 视觉钩子；
- 色光/材质手法；
- 信息层级；
- 广告叙事机制。

Reference **不能自动证明**：项目角色、品牌、玩法、世界观、官方剧情、历史正式风格。

`project/references/**` 只是默认存储位置，不等于 Evidence Authority。历史项目 KV/Banner 若要参与“项目过去实际采用过什么视觉语言”的综合，必须在 `project/evidence-registry.json` 声明 `evidence_role=historical-project-output`、`provenance` 与 `authority_scope`；未声明的 Reference 仍只能作为外部方法参考。

### 关键失败视角

如果项目历史真实 KV 被错误地只当 Reference 保存，那么 Baseline 只能把它理解成“可借鉴方法”，不能把它当“历史项目产出”。遇到这种证据角色不清时，Baseline 必须显式写明 `authority_boundary`，不得偷偷补全。

---

## 2. Inventory → 全量视觉 Census → 深度分析

```bash
python .agents/skills/wxian-visual-baselines/scripts/baseline_gate.py build-source-manifest --request <request> --workspace-root .
```

### Reference ≤100

全部 unique Reference 深度分析。

### Reference >100

必须先对 **100% Reference** 做轻量视觉 Census：

```text
work/project-visual-standard/reference-census.json
```

Census 的职责不是生成最终结论，而是确保没有任何视觉方向在“完全没被看过”的情况下被忽略。

Cluster 必须来自真实视觉差异：视觉钩子、叙事机制、构图/镜头、色光、角色作用、信息负载；`kv/`、`banner/` 只是存储目录，不能直接成为视觉 Cluster。

然后再按 Cluster 选代表图做深度 Reverse Analysis。所有 outlier 必须深挖。

逐图分析仍由 `$wxian-visual-reverse-analysis` 完成。它只负责**观察事实**，不负责最终项目级结论。

---

## 3. 角色与品牌身份单独建立，不混入项目级综合

### 角色

每个 canonical 角色建立：

```text
character-profiles/<id>.md
character-verifications/<id>.md
```

Production Card 必须至少锁定：

- 脸型 / 肤色；
- 眼睛 / 眉形；
- 发型结构 / 发色分区；
- 体型轮廓；
- 服装大形；
- 主辅色块；
- 关键装备；
- 高辨识细节。

卡片完成后必须重新打开 canonical 原图二次核验。发现错项先改卡，再验证。

### Brand

有 canonical Logo 时生成 `brand-profile.md`。必须看懂 Logo 本身：品牌名、字标结构、字体造型、色彩/材质、符号、轮廓、保护项和多语言资产关系。

`$wxian-project-style-index` 只可辅助生成/校验角色卡和 Brand Card；**不得再负责最终 Project Visual Baseline 综合。**

---

# 4. 核心专业步骤：Project Visual Synthesis

这是本 Skill 的主能力。**先综合，再写 Baseline；不要边看分析边填最终字段。**

生成内部工作文件：

```text
work/project-visual-standard/visual-synthesis.md
work/project-visual-standard/synthesis-ledger.json
```

`visual-synthesis.md` 是视觉负责人自己的综合判断草稿；`synthesis-ledger.json` 只负责证据追溯。最终 Baseline 不搬运 ledger。

## 4.1 第一遍：建立 Whole-set Gestalt｜整体视觉印象

先看完整证据集合，不分 Family，回答：

1. 如果只给我 10 秒，这个项目当前视觉上最像什么？
2. 它的画面通常在解决什么传播问题：角色展示、危机、玩法目标、活动氛围、情绪叙事、品牌包装，还是其他？
3. 第一视觉通常是什么？第二视觉通常是什么？
4. 人物、环境、威胁、道具、UI、标题、Logo 的优先级通常怎么排？
5. 哪些视觉信号一出现就明显提高“像这个项目”的概率？
6. 哪些东西虽然常见于同类游戏，但在这个项目证据里并不稳定？
7. 当前项目的质量特征到底体现在哪：人物完成度、材质、空间、打光、信息控制、情绪、特效、品牌包装中的哪些组合？

这一阶段**禁止先创建 Family**。否则模型会先分类，再强迫所有证据适应分类。

## 4.2 第二遍：建立 Evidence Matrix｜跨图比较矩阵

对完整证据按同一组视觉维度横向比较，而不是逐张复述：

- 业务目的 / 商业命题；
- 第一视觉钩子；
- 主体类型与主体占比；
- 人物在叙事中的角色；
- 环境承担的作用；
- 镜头距离 / 高低机位 / 透视强度；
- 前中后景组织；
- 明暗结构 / 冷暖关系；
- 材质与细节密度；
- 特效、烟尘、粒子使用量；
- 标题、Logo、UI、安全区与留白；
- 情绪强度；
- 缩略图第一读点；
- 可复用机制与不可继承内容。

目标是找出**跨图关系**：哪些东西经常一起出现，哪些互相排斥，哪些只在特定业务场景成立。

## 4.3 第三遍：提出 Candidate Claims｜候选项目结论

每条项目级结论必须先进入 `synthesis-ledger.json`，并通过三个测试：

### A. 区分度测试｜Differentiation Test

问：

> 把项目名换成另一个同类游戏，这句话是否仍几乎原样成立？

如果答案是“是”，它不是合格的项目 Visual DNA。

例如以下通常应被拒绝：

- “画面要有冲击力”；
- “角色要清晰”；
- “构图要有层次”；
- “色彩要统一”；
- “电影感强”；
- “第一视觉明确”。

必须继续追问：**这个项目具体通过什么方式做到？组合关系是什么？在什么任务里成立？**

### B. 反例测试｜Counterexample Test

主动找不符合该结论的历史证据。

如果大量反例存在：

- 缩小 scope；
- 从 `stable-prior` 降为 `situational`；
- 或删除该结论。

禁止为了形成“统一风格”而抹平真实差异。

### C. 因果测试｜One-shot Causal Test

问：

> 这条结论具体会改变下一次第一稿的哪个设计决策？

如果它不能改变：主体选择、镜头、构图、色光、信息层级、人物角色、品牌位置、细节预算或质量判断中的任何一项，它对 Baseline 没有实际价值。

每条 ledger claim 必须说明 `one_shot_effect`。

## 4.4 第四遍：先形成项目 Visual DNA，再拆当前产出 Family

顺序必须是：

```text
整体视觉认知
→ 跨图稳定关系
→ 项目 Visual DNA
→ 再判断历史产出中有哪些真正不同的 Family
```

不是：

```text
先 Cluster
→ 每个 Cluster 填一套相同字段
→ 把它们叫 Family
```

Family 只有在**业务目的或视觉机制存在决定性差异**时才成立。

每两个主要 Family 都要做横向比较：

- shared_core：它们共享什么项目 DNA；
- decisive_difference：真正决定它们不是同一个方向的差异；
- choose_first_when / choose_second_when：什么 Brief 下优先选哪一个；
- do_not_merge：什么东西不能平均化，否则两边都失去价值。

如果两个 Family 的构图、镜头、色光、人物作用、信息层级描述几乎一样，只是名字不同，**合并或重新划分**。

## 4.5 第五遍：把“常用”与“底线”彻底分开

### Historical Prior

代表：

> 历史证据中高频成立，默认从这里起稿更容易命中。

可以包括：某类主体、构图、镜头、色光、信息密度、人物/环境关系。

### Baseline Floor

只有“低于它就明显不像项目、身份错误、品牌错误或不可交付”的要求才能进入 Floor。

高频不等于 Floor。某个构图出现 70% 也不意味着新需求必须这样构图。

## 4.6 第六遍：明确 Strategic Whitespace｜创新空间

综合历史覆盖后，明确：

- 哪些视觉方向已经成熟；
- 哪些只是证据不足，不应误判成禁区；
- 哪些新镜头 / 色光 / 叙事 / 材质 / 空间机制值得探索；
- 当前 Brief 如果与历史 Family 不匹配，可以 `start_family_ids: none`。

创新不是“随便做”。新方向仍然必须保持项目身份、角色/品牌事实和 Baseline Floor。

---

## 5. Synthesis Ledger｜所有证据参与推理，但不污染正文

`synthesis-ledger.json` 使用 Schema 1。每条 claim 至少包含：

```text
claim_id
claim_type
statement
scope
baseline_role: prior|floor-candidate|identity|boundary|opportunity
confidence: high|medium|low
evidence_paths[]
counterevidence_paths[]
differentiation_test
one_shot_effect
```

并建立：

```text
analysis_participation:
  <formal analysis path>: [claim_id, ...]
```

硬要求：

- 所有正式深度 analysis 都必须参与至少一条内部 claim；
- 这只证明“证据参与了综合”，**不要求最终 Baseline 每张图留一句话**；
- claim 不能机械近似复制；
- Evidence 与 counterevidence 必须来自真实已分析素材；
- 不确定结论保留不确定，不为了形成漂亮统一口径而强行确认。

---

## 6. 最终 Baseline Schema 8｜写给未来 Codex 看的项目认知

最终正文只保留已经完成综合后的知识，结构固定为：

1. `基准定位`
2. `项目视觉认知`
3. `当前产出结构`
4. `跨产出视觉 DNA`
5. `产出差异决策`
6. `角色与品牌身份`
7. `Baseline Floor｜最低合格线`
8. `创新空间｜Baseline 不是上限`
9. `一稿校准`
10. `证据边界与刷新`

具体 Schema 见 `references/project-visual-baseline-schema-v8.md`。

### 最终正文写作标准

- 读正文就应形成项目的脑内图像；
- 先写项目综合结论，再写历史 Family；
- Family 是“历史产出原型”，不是 Reference 清单；
- 不复制逐图分析正文；
- 不写审计过程、Gate 过程、`none / fallback / insufficient` 堆叠；
- 不把证据路径数量当专业程度；
- 不把通用设计原则冒充项目 DNA；
- 不把现有 Family 当未来白名单。

---

## 7. One-shot Calibration Test｜最终专业准出

在聚合前必须存在 `work/project-visual-standard/grounding-review.json`。它必须记录 `reviewer_type=independent-visual-model`、非空 `reviewer_id` 与 `method`，并逐源绑定 `source_sha256`、重建评分和遗漏/错认/空间/动作/UI/光色错误列表；任一核心错误或评分低于 4/5 都不能发布。这个 Receipt 证明 grounding 检查已执行，但不把文本自报的 reviewer 身份当作密码学签名。

复核口径、复核模型稳定性要求、分歧的处理顺序与留痕要求读取 `references/grounding-review-protocol.md`；
需要重新看原图（观察或交叉核对）时使用 `scripts/vision_observe.py`（原图像素坐标裁切、可指定模型、
输入可复现，且从不打印密钥），观察侧的提示词分工、裁切规范与失败处理读取
`references/vision-observation-protocol.md`。

本环节的机器判据不变：`grounding-review.json` 的六个错误列表必须为空、重建评分不得低于 4/5。
上述 Reference 只规定在执行这些判据之前必须完成的核对与留痕，不放宽任何判据。

正式发布前，主 Agent 必须只读最终 Baseline，暂时不翻单图分析，回答以下问题：

1. **30 秒项目复述**：这个项目当前视觉上是什么？
2. **第一稿起点**：如果现在做一个典型 KV/Banner，我会优先做哪三个设计决策？为什么？
3. **项目相似度**：什么东西缺失后，结果即使“很好看”也不像这个项目？
4. **Family 差异**：两个主要历史方向到底为何不同，什么 Brief 下不能互换？
5. **突破路径**：如果当前需求与所有历史方向都不匹配，哪些 DNA/Floor 仍需保留，哪些可以完全重做？

如果不能仅凭 Baseline 清楚回答，说明综合失败，**不能靠增加字段或 source_note 过门禁**。只允许携带明确缺口清单回到第 4 节重新综合 1 次；第二次必须绑定新增或修正的 source evidence，否则停止并返回 blocked reason，不继续循环改写。

---

## 8. 编码完整性｜UTF-8 是发布契约

所有 Workspace 自有文本必须是严格 UTF-8。不要依赖 Windows 当前代码页。

### 写文件

优先：

- Python `Path.write_text(..., encoding="utf-8")`；
- JSON 使用 `ensure_ascii=False`；
- 原子写入后替换目标。

在 PowerShell 中禁止使用未声明编码的 `>` / `>>` / `Out-File` / `Set-Content` 生成正式 Markdown/JSON。若必须通过 PowerShell 写文本，必须显式使用无 BOM UTF-8；无法保证时改用 Python。

### 发布前

`baseline_gate` 会对 Baseline work tree 与 published tree 做严格检查：

- 非 UTF-8 → BLOCK；
- UTF-8 BOM → BLOCK；
- U+FFFD replacement character → BLOCK；
- 私有区异常字符 → BLOCK；
- `???` 等丢失替换 → BLOCK；
- `瑙掕 / 鍙 / 鐨勫 / 闇€ / 锟斤拷` 等典型 UTF-8↔GBK mojibake → BLOCK。

**禁止自动“猜着修乱码”后继续发布。** 乱码说明上游语义已经不可证明，必须从原始内容重新写入 UTF-8。

---

## 9. 执行与发布

```bash
python .agents/skills/wxian-visual-baselines/scripts/baseline_gate.py prepare-aggregation --request <request> --workspace-root .
# 完成 visual-synthesis.md + synthesis-ledger.json + 角色/品牌卡 + project-visual-standard.md
python .agents/skills/wxian-visual-baselines/scripts/baseline_gate.py publish --request <request> --workspace-root .
python .agents/skills/workspace-governance/scripts/workspace_gate.py complete-internal --request <request> --workspace-root .
```

`publish` 在正常路径中只执行一次完整 work-tree 专业验证；`validate-aggregation`、`validate-project-standard`、`validate-published` 只保留为显式诊断，不在发布序列中重复执行。`complete-internal` 是 non-Promote completion 的唯一 Authority，只 fresh 校验已发布文件与 publication receipt 的绑定。

发布是整快照替换。Reference/Census、角色/品牌、Source Set、Synthesis Ledger、最终 Baseline 或文本编码任一失效，正式 Baseline 都必须 stale。

---

## 10. 下游怎么读

下游先读 `project/baselines/index.json`，再读最终 Baseline：

- 项目视觉认知；
- 当前任务相关历史 Family；
- 跨产出 Visual DNA；
- Baseline Floor；
- 创新空间；
- 目标角色/Brand Card。

默认**不读** `synthesis-ledger.json`、Census 和全量单图分析；它们属于证据层，只在核验或细节不足时定向打开。

Baseline 的目标是让下游“不从零开始”，不是让下游“只能重复历史”。
