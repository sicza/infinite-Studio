# score-target-type-rules

## 作用

固定 `score_target_type` 与评分卡之间的对应关系。

评分卡只能由 `score_target_type` 决定，不得由调用来源或任务路由名称决定。

## 支持类型

```text
direction_draft
visual_asset
key_visual
conversion_asset
store_set
competitor_reference
packaging_plan
packaging_postmortem
```

## 类型规则

| score_target_type | 适用对象 | 默认 score_mode | 必读评分卡 | 是否给等级 |
|---|---|---|---|---|
| direction_draft | 方向 brief、候选方案、未成图草案 | potential_ranking | score-dimensions.md | 不给正式等级 |
| visual_asset | LOGO、ICON、品牌资产、单张通用视觉资产 | asset_review | asset-type-scorecards.md | 可给等级 |
| key_visual | KV、Feature Graphic、主视觉、活动主图 | asset_review | asset-type-scorecards.md | 可给等级 |
| conversion_asset | 商店单图、广告图、买量图、转化素材 | asset_review | asset-type-scorecards.md | 可给等级 |
| store_set | 商店套图、截图组、转化图组 | store_set_review | store-set-scorecard.md | 可给等级 |
| competitor_reference | 竞品素材、外部参考、案例图组 | reference_extract | 对应对象评分卡 + 可转译价值 | 可给参考等级 |
| packaging_plan | 视觉包装方案、套图规划、主轴方案 | detailed_review | score-dimensions.md + store-set-scorecard.md | 可给方案等级 |
| packaging_postmortem | 包装复盘对象、上线后表现回看 | postmortem | 对应对象评分卡 + 预期对比 | 可给复盘等级 |

## direction_draft

用于未成图方向。统一使用 S1-S7 潜力评分。

要求：

```text
不评价图片质量
不授予正式 S/A/B/C/D 等级
可以输出潜力分、排名、红线和改进建议
证据等级通常不高于 supported，除非有真实测试或验证结果
```

## visual_asset

先判断资产更接近：

```text
品牌资产：LOGO / ICON / 符号 / 头像 / 徽章
通用视觉资产：用 S1-S7 + 对应目标补充说明
```

LOGO / ICON 默认使用品牌资产评分卡。

## key_visual

默认使用主视觉评分卡。重点看定帧、焦点、主体主次、故事情绪、构图冲击、场景参与和商业包装可用性。

## conversion_asset

默认使用转化素材评分卡。重点看 3 秒钩子、玩法理解、卖点清晰、信息层级、缩略图可读、转化风险、地区适配。

## store_set

必须两层评分：

```text
逐张：按 conversion_asset 评分
整套：按 P1-P8 评分
```

不得只给整套总分。

## competitor_reference

必须额外输出：

```text
可学习方法
不可照搬风险
是否依赖竞品专属资产
可转译证据
```

不得把竞品资产直接当成可用方案。

## packaging_plan

评分对象是方案，不是最终图片。必须判断：

```text
包装主轴是否明确
图序策略是否成立
卖点覆盖是否完整
项目视觉标准是否被继承
可执行性是否足够
```

## packaging_postmortem

必须对比：

```text
原始目标
实际输出
测试 / 反馈 / 上线结果
偏差原因
可复用经验
下次优先改进项
```

不得把复盘评分写成任务完成或关闭结论。
