---
name: wxian-visual-scorecard
description: 对方向草案、成图、KV、转化素材、商店套图、竞品参考、包装方案和包装复盘做证据化评分、红线、封顶与排序。只在需要正式比较或诊断时调用，不是每张图的固定流程，也不替代最终视觉检查。
---

# 视觉评分卡

进入前执行 `$workspace-governance consume-personal-context --request <request> --consumer wxian-visual-scorecard`；阻断则停止。


新建用户需求先由 `$workspace-demand-intake` 按本类型最小 Contract 收集并锁定输入；本 Skill 不重复追问 Intake 已知字段，也不把自身专业判断转嫁给用户。
只依据真实可观察证据评分，用于比较、排序和定位问题。

对成图、KV、包装方案和候选选择，先按 `references/visual-director-gates.md` 调用 `$sicza-visual-director` 的完整性/交付门禁做 Hard Fail 筛查；再进入本 Skill 的分数体系。分数只能比较通过同一硬约束口径的对象，不能用高总分抵消空间、身份、机械、投影、图形传播或 Protect 破坏。

## 支持对象

`score_target_type`：

```text
direction_draft
visual_asset
key_visual
conversion_asset
store_set
competitor_reference
packaging_plan
packaging_postmortem
```

选择评分卡只看对象类型，不看调用它的 Skill 或路由来源。

## 最小输入

只需要：评分对象、`score_target_type`、评分目标、可直接检查的证据，以及项目目标/规格/Baseline 中真正相关的部分。不要为评分通读完整历史。

只有 Baseline 实际参与评分维度时才写 canonical `work/baseline-consumption.json`，machine key=`visual-scorecard`；未消费 Baseline 时不创建空 receipt。独立正式评分必须生成符合 `visual.analysis.scorecard.v1` 的 `work/visual-spec.json`，并用 `gate.visual.analysis.v1` 记录 Hard Gate evidence 后再进入数值评分。

成图类对象必须实际查看图片；Store 套图需要看到整套及单张。项目标准只有在评分维度依赖项目身份/商业目标时才定向读取。

## 执行

1. 读取 [score-target-type-rules.md](references/score-target-type-rules.md) 选择对象口径。
2. 读取 [score-dimensions.md](references/score-dimensions.md) 的通用维度和分制。
3. 成图/KV/转化素材读取 [asset-type-scorecards.md](references/asset-type-scorecards.md)；Store 套图读取 [store-set-scorecard.md](references/store-set-scorecard.md)。
4. 读取 [evidence-and-redline-rules.md](references/evidence-and-redline-rules.md) 判断证据等级和红线。
5. 只有命中红线、证据不足或目标地区/规格缺失时才读取 [score-cap-rules.md](references/score-cap-rules.md) 应用封顶。

只读取当前评分对象对应的 Reference。

## 输出

默认输出简洁 Markdown；只有调用方确实需要机器消费时再同时输出 JSON。

必须包含：

- 评分对象与类型；
- 各实际适用维度的分数 + 可观察依据；
- 总分/等级；`direction_draft` 只给 `potential_score`，不得伪装成正式成品总分；
- 红线与封顶；
- 同组排序（有多个对象时）；
- 最强项、最高风险、最值得修改的 1–3 项；
- 证据不足处明确标注未知。

分数不能抵消：品牌错误、角色身份错误、虚构玩法、核心主体不可读、竞品直接挪用、无法制作等红线。

评分结果**不自动等于通过/返工/交付结论**；调用方仍根据任务目标和真实最终检查决定下一步。

## 反馈价值

改进建议必须指向根因和可执行改变，不写“增强质感、提升高级感、优化构图”这类无作用意见。多个候选分数接近时优先解释差异来自哪里，而不是用小数制造虚假精度。


## 作为独立用户任务

用户直接要求“评分/比较/挑选最好的一版”时，本 Skill 可以作为 primary request。完成评分后把最终结果写入 `work/final/scorecard.md`；确认评分对象、证据和总分/红线一致后写最小 `work/final-review.md` 与 delivery manifest，再由 governance promote。不生成第二套评分摘要。
