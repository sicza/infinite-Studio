# Visual Director Hard Gates before Scoring

本文件不增加第二套分数。只在正式评分前执行可否决检查。

## 成图 / KV / Store / 包装方案

按对象实际风险，从 `$sicza-visual-director` 读取 `gates/integrity-gates.md` 与 `gates/delivery-gates.md` 的必要章节。

至少检查：

- `IG-TRUTH`：项目/叙事事实是否被改写；
- `IG-REFERENCE`：Reference 职责是否串线；
- `IG-IDENTITY`：角色/品牌/资产身份是否漂移；
- `IG-SPATIAL`：空间、尺度、支撑、路径是否成立；
- `IG-MECHANICAL`：身体、接触、道具、构造物是否成立；
- `IG-PROJECTION`：相机投影、遮挡、透视是否让关系仍可读；
- `IG-LIGHT / IG-MATERIAL / IG-IMAGE-FORMATION`：外观是否由合理视觉机制形成；
- `IG-GRAPHIC`：标题/Logo/UI/多语言是否属于画面结构而非后贴；
- `IG-STYLE`：风格变化是否破坏项目语法；
- `IG-PROTECT`：非目标高价值状态是否被误改；
- `IG-OUTPUT`：真实尺寸/裁切/交付形式是否成立。

命中阻塞条件时：输出符合 `.agents/skills/workspace-governance/config/visual-contracts/visual-gate-result-schema.json` 的结构化 gate evidence，先记录 Hard Fail 与责任层，不进入“高分但有致命错”的数值比较。

## Prompt Review

如果评分对象是 Prompt，不评分“文采”。检查：

`canonical work/visual-spec.json → Prompt Binding → Prompt 是否无损编码 → 模型方言是否只是压缩/重排 → Protect 是否完整`

结构语义丢失属于 Prompt 编译失败；上游 Visual Spec 本身错误则返回上游，不在 Prompt 层补造。
