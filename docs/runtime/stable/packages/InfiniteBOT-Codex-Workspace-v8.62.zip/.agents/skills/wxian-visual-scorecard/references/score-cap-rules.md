# score-cap-rules

## 作用

规定证据不足、红线命中和对象类型不完整时的评分封顶。

正式评分对象的封顶影响 `total_score` 和 `grade`。

`direction_draft` 不使用正式 S/A/B/C/D 等级封顶，只影响 `potential_score`；`grade` 必须保持 `potential_only`。

封顶不输出调用方结论。

## 证据封顶

| 情况 | 封顶 |
|---|---|
| 全部证据等级最高为 unknown | D |
| 关键维度证据为 unknown | C |
| 关键维度只有 unverified | B |
| 关键优势仅来自 inferred | A |
| 成图类对象无图片但有识图摘要 | B |
| 方向草案只有一句话概念 | `potential_score` 不得高于 69；`grade` 保持 `potential_only` |

## 红线封顶

| 红线 | 封顶 |
|---|---|
| 玩法表达明显错误或误导 | C |
| 主体不可读 | C |
| LOGO 字形不可读 | C |
| ICON 主体不可辨认 | C |
| 缩略图完全失效 | C |
| 文案 / LOGO 无安全区且无法修正 | C |
| 明显品牌混淆或抄袭风险 | D 或 C，按严重度 |
| 依赖竞品专属资产作为核心记忆 | C |
| 强烈地区 / 宗教 / 政治 / 历史风险 | D 或 C，按严重度 |
| 无证据却给 4-5 分 | 必须重算；无法重算则 C |

## 类型封顶

| score_target_type | 情况 | 封顶 |
|---|---|---|
| direction_draft | 缺主体、场景、事件、信息层级任意两项 | `potential_score` 不得高于 69；`grade` 保持 `potential_only` |
| direction_draft | 无法转成可执行画面 | `potential_score` 不得高于 59；`grade` 保持 `potential_only` |
| visual_asset | 小尺寸识别失败 | C |
| key_visual | 无定帧事件，只是摆拍 | B |
| key_visual | 主角不清 | C |
| conversion_asset | 玩法无法理解 | C |
| conversion_asset | 无目标地区但 C7 给高分 | 必须重算 C7 |
| store_set | 只评分整套，未逐张评分 | BLOCKED |
| store_set | 首图不承担吸引 | B |
| competitor_reference | 亮点无法安全转译 | B |
| packaging_plan | 无图序策略 | C |
| packaging_postmortem | 无实际结果证据 | B |

## 多红线处理

多条红线同时命中时，取最严格封顶。

正式评分对象示例：

```text
原始分 86
命中“缩略图完全失效” → total_score 封顶 C
封顶后 total_score 不得高于 69
score_caps_applied 记录 score_cap_type、score_cap_value、原始分、封顶后分、原因
```

`direction_draft` 示例：

```text
原始潜力分 78
命中“方向草案只有一句话概念” → potential_score 封顶
封顶后 potential_score 不得高于 69
grade 保持 potential_only
total_score 写 null 或 not_applicable
```

## 封顶记录格式

正式评分对象：

```json
{
  "object_id": "",
  "score_cap_type": "total_score",
  "score_cap_value": 69,
  "raw_score": 0,
  "capped_score": 0,
  "cap_grade": "C",
  "cap_reason": "",
  "source_rule": "score-cap-rules.md"
}
```

`direction_draft`：

```json
{
  "object_id": "",
  "score_cap_type": "potential_score",
  "score_cap_value": 69,
  "raw_score": 0,
  "capped_score": 0,
  "grade": "potential_only",
  "cap_reason": "",
  "source_rule": "score-cap-rules.md"
}
```

## 不允许

```text
不得为了让排名好看而跳过封顶。
不得把封顶写成任务放行或交付判断。
不得把未命中红线写成“无风险”。只能写“未发现明确红线”。
```
