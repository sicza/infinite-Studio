#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { createRequire } from 'node:module';

function fail(message) {
  process.stdout.write(JSON.stringify({status:'blocked', reason:String(message)}) + '\n');
  process.exit(2);
}
function sha256(data) { return crypto.createHash('sha256').update(data).digest('hex'); }
function uuidFrom(value) {
  const h = crypto.createHash('sha256').update(value).digest('hex');
  return `${h.slice(0,8)}-${h.slice(8,12)}-4${h.slice(13,16)}-a${h.slice(17,20)}-${h.slice(20,32)}`;
}
function rawImage(file, width, height) {
  const data = fs.readFileSync(file);
  if (data.length !== width * height * 4) throw new Error(`RGBA byte count mismatch for ${file}`);
  return {width, height, data: new Uint8ClampedArray(data)};
}
function args() {
  const out = {};
  for (let i=2;i<process.argv.length;i+=2) out[process.argv[i]] = process.argv[i+1];
  return out;
}
try {
  const a=args();
  if (!a['--spec'] || !a['--module-root'] || !a['--mode'] || !a['--package']) throw new Error('requires --mode build|verify --spec PATH --module-root PATH --package NAME');
  const spec=JSON.parse(fs.readFileSync(a['--spec'],'utf8'));
  const moduleRoot=path.resolve(a['--module-root']);
  const req=createRequire(path.join(moduleRoot,'package.json'));
  const {writePsdBuffer, readPsd}=req(a['--package']);

  if (a['--mode']==='build') {
    const linkedFiles=[];
    const children=[];
    const ordered=[...spec.layers].sort((x,y)=>y.z_order-x.z_order); // PSD children: top -> bottom
    for (const layer of ordered) {
      const master=fs.readFileSync(layer.master_file);
      if (sha256(master)!==layer.master_sha256) throw new Error(`master hash mismatch: ${layer.layer_id}`);
      const linkedId=uuidFrom(`linked:${layer.layer_id}:${layer.master_sha256}`);
      const placedId=uuidFrom(`placed:${layer.layer_id}:${layer.master_sha256}`);
      linkedFiles.push({id:linkedId,name:path.basename(layer.master_file),data:new Uint8Array(master)});
      const x=layer.bounds[0], y=layer.bounds[1], w=layer.bounds[2], h=layer.bounds[3];
      children.push({
        name: layer.name,
        top:y,
        left:x,
        imageData:rawImage(layer.preview_rgba,w,h),
        opacity: layer.opacity ?? 1,
        blendMode: layer.blend_mode ?? 'normal',
        placedLayer:{
          id:linkedId,
          placed:placedId,
          type:'raster',
          transform:[x,y,x+w,y,x+w,y+h,x,y+h],
          width:layer.master_size[0],
          height:layer.master_size[1],
          resolution:{value:72,units:'Density'}
        }
      });
    }
    const psd={
      width:spec.canvas[0], height:spec.canvas[1],
      imageData:rawImage(spec.composite_rgba,spec.canvas[0],spec.canvas[1]),
      children, linkedFiles
    };
    const buffer=writePsdBuffer(psd,{generateThumbnail:false,trimImageData:false,logMissingFeatures:true});
    fs.mkdirSync(path.dirname(spec.output_psd),{recursive:true});
    fs.writeFileSync(spec.output_psd,buffer);
  } else if (a['--mode']!=='verify') {
    throw new Error(`unsupported mode ${a['--mode']}`);
  }

  const bytes=fs.readFileSync(spec.output_psd);
  const parsed=readPsd(bytes,{skipLayerImageData:true,skipCompositeImageData:true,skipThumbnail:true,skipLinkedFilesData:false});
  if (parsed.width!==spec.canvas[0] || parsed.height!==spec.canvas[1]) throw new Error('PSD document canvas mismatch');
  const expected=[...spec.layers].sort((x,y)=>y.z_order-x.z_order);
  if (!Array.isArray(parsed.children) || parsed.children.length!==expected.length) throw new Error('PSD layer count mismatch');
  const linked=new Map((parsed.linkedFiles||[]).map(x=>[x.id,x]));
  const result=[];
  for (let i=0;i<expected.length;i++) {
    const want=expected[i], got=parsed.children[i];
    if (got.name!==want.name) throw new Error(`PSD layer order/name mismatch at ${i}`);
    if (!got.placedLayer) throw new Error(`PSD layer is not Smart Object: ${want.layer_id}`);
    const lf=linked.get(got.placedLayer.id);
    if (!lf || !lf.data) throw new Error(`embedded Smart Object payload missing: ${want.layer_id}`);
    const embedded=Buffer.from(lf.data);
    if (sha256(embedded)!==want.master_sha256) throw new Error(`embedded master hash mismatch: ${want.layer_id}`);
    const x=want.bounds[0], y=want.bounds[1], w=want.bounds[2], h=want.bounds[3];
    const expectedTransform=[x,y,x+w,y,x+w,y+h,x,y+h];
    if (JSON.stringify(got.placedLayer.transform)!==JSON.stringify(expectedTransform)) throw new Error(`Smart Object transform mismatch: ${want.layer_id}`);
    if (got.placedLayer.width!==want.master_size[0] || got.placedLayer.height!==want.master_size[1]) throw new Error(`Smart Object intrinsic size mismatch: ${want.layer_id}`);
    result.push({layer_id:want.layer_id,name:want.name,embedded_sha256:sha256(embedded),transform:got.placedLayer.transform,master_size:[got.placedLayer.width,got.placedLayer.height]});
  }
  process.stdout.write(JSON.stringify({status:'ready',psd_sha256:sha256(bytes),canvas:spec.canvas,layer_count:result.length,layers:result})+'\n');
} catch (e) { fail(e?.stack || e); }
