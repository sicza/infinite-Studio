#!/usr/bin/env python3
"""Build and verify code-generated Embedded Smart Object PSD deliveries."""
from __future__ import annotations
import os as _bytecode_guard_os, sys as _bytecode_guard_sys
_bytecode_guard_sys.dont_write_bytecode = True
_bytecode_guard_os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import argparse, hashlib, json, math, os, shutil, subprocess, sys, tempfile
from pathlib import Path
from typing import Any

from PIL import Image

PRIMARY_GENERAL="wxian-image-layer-decomposition"
PRIMARY_UI="wxian-game-ui-layer-decomposition"
MANIFESTS={"wxian.kv-final-layer-manifest.v2":PRIMARY_GENERAL,"wxian.game-ui-final-layer-manifest.v2":PRIMARY_UI}
RECEIPT_SCHEMA="wxian.smart-object-psd.v1"

class PsdExportError(ValueError): pass
def require(c:bool,m:str)->None:
    if not c: raise PsdExportError(m)
def sha(p:Path)->str:
    h=hashlib.sha256();
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def load(p:Path)->dict[str,Any]:
    v=json.loads(p.read_text(encoding='utf-8')); require(isinstance(v,dict),f'JSON root must be object: {p}'); return v
def bounded(root:Path,value:str,exists:bool=False)->Path:
    p=(Path(value) if Path(value).is_absolute() else root/value).resolve(); require(p==root or root in p.parents,f'path escapes Workspace: {value}')
    if exists: require(p.is_file(),f'file missing: {value}')
    return p
def rel(root:Path,p:Path)->str:return p.resolve().relative_to(root.resolve()).as_posix()
def runtime_contract(root:Path)->dict[str,str]:
    p=root/'.agents/skills/wxian-layered-psd-export/config/node-runtime.json'; v=load(p)
    require(v.get('schema_version')=='wxian.psd-node-runtime.v1','PSD Node Runtime contract schema mismatch')
    package=str(v.get('node_package','')).strip(); version=str(v.get('version','')).strip(); install=str(v.get('install_root','')).strip()
    require(package and version and install,'PSD Node Runtime contract incomplete')
    return {'package':package,'version':version,'install_root':install}
def module_root(root:Path)->Path:
    c=runtime_contract(root); p=(root/c['install_root']).resolve(); require(p==root.resolve() or root.resolve() in p.parents,'PSD Node Runtime install_root escapes Workspace'); return p
def writer(root:Path)->Path:return root/'.agents/skills/wxian-layered-psd-export/scripts/smart_object_writer.mjs'

def backend_status(root:Path)->dict[str,Any]:
    node=shutil.which('node'); c=runtime_contract(root); mr=module_root(root); pkg=mr/'node_modules'/c['package']/'package.json'
    if not node:return {'status':'blocked','reason':'Node.js is required for Smart Object PSD export'}
    if not pkg.is_file():return {'status':'blocked','reason':f'pinned ag-psd runtime is missing at {rel(root,mr)}; run Workspace runtime-repair'}
    try:v=load(pkg).get('version')
    except Exception as e:return {'status':'blocked','reason':f'ag-psd package metadata unreadable: {e}'}
    if v!=c['version']:return {'status':'blocked','reason':f"{c['package']} version must be {c['version']}, got {v}"}
    return {'status':'ready','node':node,'package':c['package'],'version':v,'module_root':rel(root,mr)}

def _master(entry:dict[str,Any], root:Path, profile:str)->tuple[Path,list[int],float,str]:
    m=entry.get('editable_master'); require(isinstance(m,dict),'layer editable_master is required')
    required={'file','sha256','size','scale_vs_delivery','provenance'}; require(required<=set(m),f'editable_master missing {sorted(required-set(m))}')
    p=bounded(root,str(m['file']),True); require(sha(p)==str(m['sha256']),'editable_master sha256 is stale')
    if profile==PRIMARY_GENERAL:
        require(p.parent.name=='originals' and p.parent.parent.name=='final' and p.parent.parent.parent.name=='work',
                'normal decomposition editable_master must be the approved file directly inside work/final/originals/')
    size=m['size']; require(isinstance(size,list) and len(size)==2 and all(isinstance(x,int) and x>0 for x in size),'editable_master size invalid')
    with Image.open(p) as im: im.load(); require(list(im.size)==size,'editable_master decoded size mismatch')
    scale=float(m['scale_vs_delivery']); expected=2.0 if profile==PRIMARY_UI else 1.0
    require(abs(scale-expected)<1e-6,f'{profile} requires editable_master scale {expected}x, got {scale}x')
    prov=str(m['provenance']).strip(); require(prov in {'source_preserved','ai_reconstructed','ai_upscaled','deterministic_resample','mixed'},'editable_master provenance invalid')
    return p,size,scale,prov

def _validate_general_master(entry:dict[str,Any], root:Path, master:Path, master_size:list[int], lid:str, bbox:list[int], canvas:list[int])->None:
    """Make direct PSD compilation enforce the same finalization proof as delivery."""
    require(master.name==f'{lid}.png',f'normal decomposition editable_master must be named {lid}.png')
    required={'file','sha256','minimum_visible_coverage_ratio','editable_master'}
    require(required<=set(entry),f'KV PSD layer fields missing: {lid}')
    layer=bounded(root,str(entry['file']),True); require(sha(layer)==str(entry['sha256']),f'final full-canvas layer sha256 is stale: {lid}')
    with Image.open(layer) as opened:
        opened.load(); full=opened.convert('RGBA')
    require(list(full.size)==canvas,f'final full-canvas layer size mismatch: {lid}')
    master_meta=entry['editable_master']; require(isinstance(master_meta,dict),f'editable_master invalid: {lid}')
    derivation=master_meta.get('derivation'); require(isinstance(derivation,dict),f'editable_master derivation is required: {lid}')
    required_derivation={'operation','source_canvas_file','source_canvas_sha256','crop_bbox'}
    require(required_derivation<=set(derivation),f'editable_master derivation fields missing: {lid}')
    require(derivation['operation']=='delivery_bbox_crop_v1',f'editable_master derivation operation invalid: {lid}')
    require(derivation['source_canvas_file']==entry['file'] and derivation['source_canvas_sha256']==entry['sha256'],f'editable_master derivation must bind final full-canvas layer: {lid}')
    require(derivation['crop_bbox']==bbox,f'editable_master derivation crop_bbox must equal bbox: {lid}')
    x,y,w,h=bbox; expected=full.crop((x,y,x+w,y+h))
    with Image.open(master) as opened:
        opened.load(); actual=opened.convert('RGBA')
    require(list(actual.size)==master_size and list(expected.getdata())==list(actual.getdata()),f'editable_master pixels are not final-layer bbox crop: {lid}')
    ratio=entry['minimum_visible_coverage_ratio']; require(isinstance(ratio,(int,float)) and 0.0<float(ratio)<=1.0,f'minimum_visible_coverage_ratio invalid: {lid}')
    alpha=full.getchannel('A').point(lambda value:255 if value>=16 else 0); alpha_bbox=alpha.getbbox()
    require(alpha_bbox is not None and alpha_bbox[0]>=x and alpha_bbox[1]>=y and alpha_bbox[2]<=x+w and alpha_bbox[3]<=y+h,f'final layer alpha escapes declared bbox: {lid}')
    visible=sum(value>=16 for value in actual.getchannel('A').getdata())
    require(visible>=math.ceil(w*h*float(ratio)),f'editable_master visible coverage below analyzed minimum: {lid}')
    sources=master_meta.get('provider_originals'); require(isinstance(sources,list) and sources,f'editable_master provider_originals are required: {lid}')
    provider=(master.parent/'provider').resolve()
    for source in sources:
        require(isinstance(source,dict) and {'file','sha256','size'}<=set(source),f'editable_master provider original fields missing: {lid}')
        raw=bounded(root,str(source['file']),True); require(provider in raw.parents,f'provider original must stay inside work/final/originals/provider/: {lid}')
        require(sha(raw)==str(source['sha256']),f'provider original sha256 is stale: {lid}')
        with Image.open(raw) as opened:
            opened.load(); raw_size=list(opened.size)
        require(raw_size==source['size']==canvas,f'provider original size must equal delivery canvas: {lid}')

def compile_spec(root:Path,manifest_path:Path,tmp:Path,output:Path)->tuple[dict[str,Any],dict[str,Any]]:
    mf=load(manifest_path); schema=str(mf.get('schema_version','')); require(schema in MANIFESTS,f'unsupported decomposition delivery manifest: {schema}')
    profile=MANIFESTS[schema]; require(mf.get('decomposition_skill')==profile,'manifest decomposition_skill mismatch')
    canvas=mf.get('delivery_canvas_size'); require(isinstance(canvas,list) and len(canvas)==2 and all(isinstance(x,int) and x>0 for x in canvas),'delivery_canvas_size invalid')
    layers=mf.get('layers'); require(isinstance(layers,list) and layers,'manifest layers missing')
    spec_layers=[]; composites=[]
    for i,e in enumerate(layers):
        require(isinstance(e,dict),'layer entry must be object'); lid=str(e.get('layer_id','')).strip(); require(lid,f'layer_id missing at {i}')
        bbox=e.get('bbox'); require(isinstance(bbox,list) and len(bbox)==4 and all(isinstance(x,int) for x in bbox),f'bbox invalid: {lid}')
        x,y,w,h=bbox; require(x>=0 and y>=0 and w>0 and h>0 and x+w<=canvas[0] and y+h<=canvas[1],f'bbox outside delivery canvas: {lid}')
        master,msize,scale,prov=_master(e,root,profile)
        require(msize==[round(w*scale),round(h*scale)],f'editable_master intrinsic size does not match bbox×scale: {lid}')
        if profile==PRIMARY_GENERAL:
            _validate_general_master(e,root,master,msize,lid,bbox,canvas)
        with Image.open(master) as im:
            im.load(); preview=im.convert('RGBA').resize((w,h),Image.Resampling.LANCZOS) if im.size!=(w,h) else im.convert('RGBA')
        raw=tmp/f'{i:04d}-{lid}.rgba'; raw.write_bytes(preview.tobytes())
        z=int(e.get('z_order')); composites.append((z,(x,y),preview))
        spec_layers.append({'layer_id':lid,'name':str(e.get('name') or lid),'z_order':z,'bounds':bbox,'preview_rgba':str(raw),'master_file':str(master),'master_sha256':sha(master),'master_size':msize,'master_scale':scale,'provenance':prov,'opacity':1,'blend_mode':'normal'})
    composite=Image.new('RGBA',tuple(canvas),(0,0,0,0))
    for _,(x,y),preview in sorted(composites,key=lambda z:z[0]): composite.alpha_composite(preview,(x,y))
    comp_raw=tmp/'document.rgba'; comp_raw.write_bytes(composite.tobytes())
    preview_path=output.with_suffix('.preview.png'); composite.save(preview_path,format='PNG',optimize=True)
    spec={'schema_version':'wxian.smart-object-psd-spec.v1','canvas':canvas,'composite_rgba':str(comp_raw),'output_psd':str(output),'layers':spec_layers}
    return spec,{'manifest':mf,'profile':profile,'preview':preview_path}

def node_call(root:Path,spec_path:Path,mode:str)->dict[str,Any]:
    st=backend_status(root); require(st['status']=='ready',str(st.get('reason')))
    c=runtime_contract(root)
    cp=subprocess.run([str(st['node']),str(writer(root)),'--mode',mode,'--spec',str(spec_path),'--module-root',str(module_root(root)),'--package',c['package']],capture_output=True,text=True,encoding='utf-8',timeout=180)
    try:v=json.loads(cp.stdout)
    except Exception as e:raise PsdExportError(f'PSD Node backend returned invalid JSON: {cp.stdout[-1000:]} {cp.stderr[-1000:]}') from e
    require(cp.returncode==0 and v.get('status')=='ready',f"PSD Node backend failed: {v.get('reason',cp.stderr[-1000:])}")
    return v

def build(root:Path,manifest_path:Path,output:Path,receipt:Path)->dict[str,Any]:
    require(not output.exists(),'PSD output already exists'); require(not receipt.exists(),'PSD receipt already exists')
    output.parent.mkdir(parents=True,exist_ok=True); receipt.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='wxian-psd-',dir=str(root/'tmp') if (root/'tmp').is_dir() else None) as td:
        tmp=Path(td); spec,meta=compile_spec(root,manifest_path,tmp,output); sp=tmp/'spec.json'; sp.write_text(json.dumps(spec,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        readback=node_call(root,sp,'build')
    require(output.is_file() and readback['psd_sha256']==sha(output),'PSD readback hash mismatch')
    value={'schema_version':RECEIPT_SCHEMA,'status':'PASS','source_manifest':rel(root,manifest_path),'source_manifest_sha256':sha(manifest_path),'decomposition_skill':meta['profile'],'psd':rel(root,output),'psd_sha256':sha(output),'preview':rel(root,meta['preview']),'preview_sha256':sha(meta['preview']),'canvas':readback['canvas'],'layer_count':readback['layer_count'],'layer_mode':'embedded_smart_object','readback':readback}
    receipt.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); return value

def verify(root:Path,receipt_path:Path)->dict[str,Any]:
    r=load(receipt_path); require(r.get('schema_version')==RECEIPT_SCHEMA and r.get('status')=='PASS','PSD receipt schema/status invalid')
    manifest=bounded(root,str(r.get('source_manifest','')),True); require(sha(manifest)==r.get('source_manifest_sha256'),'PSD receipt source manifest stale')
    psd=bounded(root,str(r.get('psd','')),True); require(sha(psd)==r.get('psd_sha256'),'PSD receipt file hash stale')
    preview=bounded(root,str(r.get('preview','')),True); require(sha(preview)==r.get('preview_sha256'),'PSD preview hash stale')
    with tempfile.TemporaryDirectory(prefix='wxian-psd-verify-',dir=str(root/'tmp') if (root/'tmp').is_dir() else None) as td:
        tmp=Path(td); spec,_=compile_spec(root,manifest,tmp,psd); sp=tmp/'spec.json'; sp.write_text(json.dumps(spec,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); readback=node_call(root,sp,'verify')
    require(readback['psd_sha256']==r['psd_sha256'],'PSD readback changed since receipt'); require(readback['layer_count']==r['layer_count'],'PSD readback layer count mismatch')
    return {'status':'ready','psd':r['psd'],'psd_sha256':r['psd_sha256'],'layer_count':r['layer_count'],'layer_mode':'embedded_smart_object'}

def doctor(root:Path)->dict[str,Any]:
    st=backend_status(root); return {'status':st['status'],'tool':'wxian-layered-psd-export','backend':st,'contract':'1x delivery PSD + embedded editable masters; UI requires 2x masters; no raster fallback'}

def main()->int:
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    b=sub.add_parser('build'); b.add_argument('--manifest',required=True); b.add_argument('--output',required=True); b.add_argument('--receipt',required=True)
    v=sub.add_parser('verify'); v.add_argument('--receipt',required=True)
    d=sub.add_parser('doctor')
    default_root=Path(__file__).resolve().parents[4]
    ap.add_argument('--workspace-root',type=Path,default=default_root)
    for command in (b,v,d): command.add_argument('--workspace-root',type=Path,dest='workspace_root_after')
    a=ap.parse_args(); root=getattr(a,'workspace_root_after',None) or a.workspace_root; root=root.resolve()
    try:
        result=doctor(root) if a.cmd=='doctor' else (build(root,bounded(root,a.manifest,True),bounded(root,a.output),bounded(root,a.receipt)) if a.cmd=='build' else verify(root,bounded(root,a.receipt,True)))
        print(json.dumps(result,ensure_ascii=False,indent=2)); return 0 if result.get('status') in {'ready','PASS'} or a.cmd=='build' else 2
    except (PsdExportError,OSError,json.JSONDecodeError,subprocess.SubprocessError,ValueError) as e:
        print(json.dumps({'status':'blocked','reason':str(e)},ensure_ascii=False)); return 2
if __name__=='__main__': raise SystemExit(main())
