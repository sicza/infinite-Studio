#!/usr/bin/env python3
"""No-network contract test for Smart Object PSD exporter orchestration."""
from __future__ import annotations
import importlib.util, json, tempfile
from pathlib import Path
from PIL import Image
HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[4]
spec=importlib.util.spec_from_file_location('psd_export_contract',HERE/'psd_export.py'); assert spec and spec.loader
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
def sha(p):return m.sha(p)
def main():
  with tempfile.TemporaryDirectory(prefix='psd-contract-') as td:
    root=Path(td); (root/'tmp').mkdir(); req=root/'requests/image-layer-decomposition/test/work/final'; req.mkdir(parents=True)
    source=root/'requests/image-layer-decomposition/test/input/source.png'; source.parent.mkdir(parents=True); Image.new('RGBA',(100,80),(0,0,0,255)).save(source)
    master=req/'originals'/'L1.png'; master.parent.mkdir(); Image.new('RGBA',(20,10),(255,0,0,255)).save(master)
    full=req/'layer.png'; im=Image.new('RGBA',(100,80),(0,0,0,0)); im.paste(Image.new('RGBA',(20,10),(255,0,0,255)),(5,6)); im.save(full)
    provider=req/'originals'/'provider'/'L1-provider.png'; provider.parent.mkdir(); Image.new('RGBA',(100,80),(0,0,0,0)).save(provider)
    mf={'schema_version':'wxian.kv-final-layer-manifest.v2','status':'READY','decomposition_skill':m.PRIMARY_GENERAL,'source_image':source.relative_to(root).as_posix(),'source_sha256':sha(source),'delivery_canvas_size':[100,80],'layers':[{'layer_id':'L1','name':'layer','z_order':1,'bbox':[5,6,20,10],'file':full.relative_to(root).as_posix(),'sha256':sha(full),'minimum_visible_coverage_ratio':0.5,'editable_master':{'file':master.relative_to(root).as_posix(),'sha256':sha(master),'size':[20,10],'scale_vs_delivery':1.0,'provenance':'source_preserved','provider_originals':[{'file':provider.relative_to(root).as_posix(),'sha256':sha(provider),'size':[100,80]}],'derivation':{'operation':'delivery_bbox_crop_v1','source_canvas_file':full.relative_to(root).as_posix(),'source_canvas_sha256':sha(full),'crop_bbox':[5,6,20,10]}}}]}
    mp=req/'layer-manifest.json'; mp.write_text(json.dumps(mf),encoding='utf-8')
    tmp=root/'tmp/spec'; tmp.mkdir(); sp,meta=m.compile_spec(root,mp,tmp,req/'layered.psd')
    assert sp['canvas']==[100,80] and sp['layers'][0]['master_size']==[20,10] and meta['profile']==m.PRIMARY_GENERAL
    bad=dict(mf); bad['decomposition_skill']=m.PRIMARY_UI; bad['schema_version']='wxian.game-ui-final-layer-manifest.v2'; bp=req/'bad.json'; bp.write_text(json.dumps(bad),encoding='utf-8')
    try:m.compile_spec(root,bp,tmp,req/'bad.psd'); raise AssertionError('UI 1x master was accepted')
    except m.PsdExportError as e: assert 'requires editable_master scale 2.0x' in str(e)
    missing=json.loads(json.dumps(mf)); del missing['layers'][0]['editable_master']['derivation']; mp.write_text(json.dumps(missing),encoding='utf-8')
    try:m.compile_spec(root,mp,tmp,req/'bad-derivation.psd'); raise AssertionError('unapproved KV master was accepted')
    except m.PsdExportError as e: assert 'derivation is required' in str(e)
  print(json.dumps({'status':'ready','tool':'psd-export-contract-selftest','backend_called':False}))
  return 0
if __name__=='__main__':raise SystemExit(main())
