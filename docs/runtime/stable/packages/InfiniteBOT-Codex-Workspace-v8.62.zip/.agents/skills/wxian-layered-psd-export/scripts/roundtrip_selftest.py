#!/usr/bin/env python3
"""Real Smart Object PSD round-trip; requires pinned local ag-psd runtime."""
from __future__ import annotations
import importlib.util,json,tempfile
from pathlib import Path
from PIL import Image
HERE=Path(__file__).resolve().parent; ROOT=HERE.parents[3]
spec=importlib.util.spec_from_file_location('psd_export_roundtrip',HERE/'psd_export.py'); assert spec and spec.loader
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
def main():
 st=m.backend_status(ROOT)
 if st.get('status')!='ready':
  print(json.dumps({'status':'blocked','reason':st.get('reason'),'tool':'psd-smart-object-roundtrip-selftest'})); return 2
 base=ROOT/'tmp/psd-smart-object-roundtrip'
 import shutil; shutil.rmtree(base,ignore_errors=True)
 try:
  final=base/'requests/game-ui-layer-decomposition/test/work/final/screen'; final.mkdir(parents=True)
  source=base/'requests/game-ui-layer-decomposition/test/input/source.png'; source.parent.mkdir(parents=True); Image.new('RGBA',(100,80),(15,20,25,255)).save(source)
  master=final/'button@2x.png'; Image.new('RGBA',(40,20),(220,40,30,255)).save(master)
  full=final/'button.png'; layer=Image.new('RGBA',(100,80),(0,0,0,0)); layer.paste(Image.new('RGBA',(20,10),(220,40,30,255)),(5,6)); layer.save(full)
  mf={'schema_version':'wxian.game-ui-final-layer-manifest.v2','status':'READY','decomposition_skill':m.PRIMARY_UI,'source_image':source.relative_to(base).as_posix(),'source_sha256':m.sha(source),'delivery_canvas_size':[100,80],'layers':[{'layer_id':'button','name':'button','z_order':1,'bbox':[5,6,20,10],'file':full.relative_to(base).as_posix(),'sha256':m.sha(full),'editable_master':{'file':master.relative_to(base).as_posix(),'sha256':m.sha(master),'size':[40,20],'scale_vs_delivery':2.0,'provenance':'ai_reconstructed'}}]}
  mp=final/'ui-layer-manifest.json'; mp.write_text(json.dumps(mf),encoding='utf-8'); output=final/'layered.psd'; receipt=final/'layered-psd.json'
  # compile against actual Workspace root paths, so copy fixture below ROOT/tmp and use ROOT as root
  def rewrite(obj):
   for k in ('source_image',): obj[k]=(base/obj[k]).relative_to(ROOT).as_posix()
   obj['source_sha256']=m.sha(source)
   for e in obj['layers']:
    e['file']=(base/e['file']).relative_to(ROOT).as_posix(); e['editable_master']['file']=(base/e['editable_master']['file']).relative_to(ROOT).as_posix()
  rewrite(mf); mp.write_text(json.dumps(mf),encoding='utf-8')
  built=m.build(ROOT,mp,output,receipt); verified=m.verify(ROOT,receipt)
  assert built['layer_mode']=='embedded_smart_object' and verified['layer_count']==1
  rb=built['readback']['layers'][0]; assert rb['master_size']==[40,20] and rb['transform']==[5,6,25,6,25,16,5,16]
  print(json.dumps({'status':'ready','tool':'psd-smart-object-roundtrip-selftest','psd_sha256':built['psd_sha256'],'layer_count':1})); return 0
 finally: shutil.rmtree(base,ignore_errors=True)
if __name__=='__main__':raise SystemExit(main())
