# Generation Review

## 目标

第一轮失败后先找“最早错误层”，不要默认再写一个更长 Prompt。

顺序：`Creative → Design → Identity → Gameplay → Environment → Composition → Style → Reference Control → Prompt → Model Execution`。

发现上游错误后停止在下游找借口。

## 1. Creative Error

图漂亮但方向普通、像常见同类、没有记忆点 → 回 01 Creative Levers / Operator Chain。不是 Prompt 问题。

## 2. Design Error

角色普通、服装与职业无关、怪物只会吓人、场景没有功能 → 回 05/06/07。即使模型 100% 执行仍不好。

## 3. Identity Drift

脸、头发、年龄、体型、Costume、Primary Prop 漂移 → 查 `Character Identity Anchor / Variant Grammar / Mother Reference Authority / Reference Binding`。不要先用更长的 `same character` 文案掩盖绑定错误。

按 Identity Delta 顺序：`Face Geometry → Hair Silhouette → Body Mass Distribution → Proportion → Costume Architecture → Signature Color Placement → Primary Prop → Minor Surface`。定位最早漂移层后只修该层及必要 Derived Change。


## 3.5 Character / IP Consistency Tests

长期角色按任务需要执行：

- `Silhouette Test`：黑剪影仍能识别；
- `Thumbnail Test`：目标 UI 尺度仍可读；
- `Grayscale Test`：去颜色后核心 Identity 不消失；
- `Lineup Test`：3+ 核心角色不模板化，同时仍属于同一 IP；
- `Variant Stress Test`：明显换装/环境 Variant 后仍是同一角色。

这些 Test 是 Production Evidence，不是美术偏好投票。失败必须映射到 `IP DNA / Cast Architecture / Character Identity / Variant Grammar / Reference Binding / Image Contract` 中最早的错误层。

## 4. Gameplay Error vs Gameplay Read Error

Gameplay Error：玩法逻辑本身不好 → 回 03/04。

Gameplay Read Error：机制没问题但图看不懂 → 查 Primary Read / Player Position / Target / Visible State Delta / Reward / UI。

## 5. Environment Drift

Macro Layout、Zone、Landmark、层级漂移 → 回 Environment Anchor，不让 Previous Image 替代 Mother Anchor。

## 6. Composition Error

主体太小、目标被挡、亮点顺序错误 → 回 Image Contract 的 Position/Scale/Fore-Mid-Back/Reading Axis。Primary Read 不是最抢眼对象说明优先级错。

## 7. Style Error

太写实/太Q/塑料/细节碎/颜色艳 → 查 Style Anchor 的 Material/Detail Density/Color/Camera。Gameplay Readability 优先于“更高级”。

## 8. Reference Control Error

动作图污染身份、Style 图改 Costume → 回 09 Role/Ignore/Authority，不只加“keep same”。

## 9. Prompt Error

只有上游都正确时才查 Prompt：关键要求位置太后、冲突、重复、遗漏 Must Show/Not Add。

## 10. Model Execution Error

Design/Anchors/Contract/Prompt 都正确，模型仍出现手、文字、多人身份、复杂装备形变等，才进入 Adapter/Profile/Reference Strategy/Generate-vs-Edit/Composite 层。

## 11. 返修 Scope

任何返修先写 `LOCKED / EDITABLE / DERIVED / FORBIDDEN`。长期角色还应显式继承 Variant Grammar：STABLE 默认进入 LOCKED；只有用户明确改设计时才重开。正确部分不重新开放。方向/身份/场景都正确、只有局部问题时优先 Edit；Composition/Camera/Macro Layout 根本错误时可 Regenerate，但仍复用 Anchors。

## 12. Review Output

`Failure Layer / What Is Wrong / What Is Already Correct / Root Cause / Change Scope / Correction / Updated Image Contract / Updated Prompt`

不需要重新输出全部设计文档。

## 13. Portfolio Batch Review

`PORTFOLIO / VERTICAL_SLICE` 每 10–20 项复核一次：ID、真实路径、字节、尺寸、SHA-256、解码与预览；事实／判断／建议／未知；至少 8 条图像特异机制；Graph/Coverage/Parent/Variant/Semantic Delta/Counting Class；批次内精确重复、近重复、同形异名、同名异形和拓扑漂移。

批次通过不能替代全局审计。收口时重新解析全部 Evidence Inventory，重算文件数与内容 Hash 唯一数，检查缺失、额外、孤儿证据、跨批次重复、身份／名称／拓扑／变体冲突和 blocking unknown。任何正式证据未被 Coverage 引用，或 Audit 自身为 `BLOCK`，都不得写 `PORTFOLIO_VERIFIED`。

没有生成 API 结果时可以审查计划、图谱、证据绑定和去重，但必须把图像质量、规则可玩性和玩家验证标记为未知，不能用静态文档代证。
