# ComfyUI Qwen Image Current Profile

Family: Qwen-Image
Verified At: 2026-08-14
Freshness Class: VOLATILE
Reverify After: 30 days
Official Sources:
- https://docs.comfy.org/tutorials/image/qwen/qwen-image-2512
- https://docs.comfy.org/tutorials/image/qwen/qwen-image-edit-2511

## Current Baselines

From-zero generation：Qwen-Image-2512 系列工作流。
Existing image edit：Qwen-Image-Edit-2511 系列工作流。

## Best Fit

Character/Environment T2I、中文/英文文字导向视觉、Material Replacement、Reference-based Edit、Product/Prop、几何感较强的编辑。

## Rule

Generation 与 Edit 使用各自原生 Workflow，不把它们当同一 Checkpoint。重复角色优先 Approved Character + Edit Workflow + Change Scope，而不是重建身份。

Exact UI/Logo/Text 仍需最终 QA。
