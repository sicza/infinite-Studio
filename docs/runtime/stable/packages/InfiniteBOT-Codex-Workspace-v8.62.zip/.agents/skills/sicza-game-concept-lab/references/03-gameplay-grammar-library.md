# Gameplay Grammar Extraction

## 目标

把“某某游戏/某某品类”拆成玩家每 5–30 秒真实做什么，从而得到可迁移、可变异的行为语法。

统一结构：`Player Input → Immediate Action → Target → Decision → Constraint → System Response → Feedback → Reward → Next Decision → Meta Progression`。

## 1. 不从 Genre 名开始

“经营/策略/三消/跑酷”不是动作。先问：手指/鼠标实际做什么？角色做什么？系统何时反馈？为什么再做一次？

## 2. Grammar 字段

对任何 Gameplay Reference 写：

`Primary Verb / Secondary Verb / Target / Movement / Decision / Constraint / System Response / Immediate Feedback / Reward / Failure / Rhythm / Camera / Meta Progression / Player Fantasy`

当目标是 `VERTICAL_SLICE`、跨系统 Portfolio，或声称玩法规则闭合时，补齐最小可推演合同：

`State Before / Player Input / Known Information / Hidden Information / Legal Actions / Transition Rule / Time or Turn / State After / End Condition / Failure or Exit / Recovery / Next-run Difference`

至少给出一个合法输入、一个边界输入和一个失败输入，并逐步推演状态。静态概念图只能证明界面或状态被设计，不能证明规则可玩、数值平衡或玩家行为成立。

### 反证

- 所有状态是否都被同一最优动作解决？若是，Decision 可能是假选择。
- 失败是否只是不再获得奖励，而没有可观察退出／恢复？若是，失败规则未闭合。
- 下一轮与第一轮是否只换数值或皮肤？若是，Meta Progression 没有改变决策空间。
- 移除 World Rule 后循环是否完全不变？若是，世界观只是 Skin。

### Feedback 与 Reward 分开

Feedback 证明“这一步做成功了”；Reward 回答“为什么还想继续”。

### Must-preserve Fun 与 Skin 分开

例如现场经营：

- Grammar：`Move → Reach Need → Resolve → Immediate Feedback → Invest → Expand`
- Must-preserve Fun：Avatar 现场参与、短循环、高频反馈、空间可见成长。
- Skin：Hotel / Guest / Room / Money。

Mutation 只以 Grammar 和 Must-preserve Fun 为底盘，不以 Skin 为底盘。

## 3. 常见 Grammar

### On-site Management / Idle Arcade

`Move → Discover Need → Reach → Perform Task → Immediate Value → Invest → Unlock → More Needs`

强项：角色 Agency、短循环、可见 Before/After、空间成长。

### Match-3

`Observe → Swap → Match → Resolve → Chain/Special → Goal/Blocker Progress`

Decision：哪两个交换、先解决哪个 Blocker、什么时候用 Special。

### Runner

`Continuous Movement → Read Ahead → Route Choice → Avoid/Jump/Slide → Collect/Trigger → Escalating Pressure`

核心：连续节奏、预判、路线选择。

### Tower Defense

`Read Route → Place → Spend → Enemy Moves → Defense Responds → Leak/Stop → Upgrade/Reconfigure`

“Defense”不一定是武器，也可以是泵、隔离门、屏蔽器等。

### Merge

`Acquire → Combine Equivalent Units → Higher-tier Unit → Use/Deliver → New Need`

强项：压缩、转化、发现、有限棋盘空间。

### Base Builder

`Acquire Resource → Build → Unlock Function → Increase Capacity → Generate/Protect → Expand Territory`

Building 可以是车厢、漂浮模块、移动设施，不默认固定房间。

### Network / Logistics

`Demand → Assign Route → Allocate Vehicle/Capacity → Transport → Resolve → New Bottleneck`

核心变量：Node / Edge / Capacity / Priority / Time / Risk。

### Survival Management

`Need → Allocate Scarce Resource → Stabilize → New Trade-off → Accumulated Consequence`

避免只做下降数值条，让资源改变空间/人口/行为。

### Extraction / Expedition

`Prepare → Enter Risk Zone → Explore → Acquire → Continue/Return Decision → Escape → Persistent Progress`

核心张力：More Reward vs More Risk。

### Roguelite

`Enter Run → Encounter → Choose Reward → Build Changes → Difficulty Escalates → Run Ends → Meta Progress`

可把 Meta 变成地图知识、人口、路线、科技等。

### Puzzle / Repair

`Inspect Broken State → Understand Rule → Manipulate Components → System Changes → Restore Function`

强 Reward 是机器启动、灯亮、水流、门开、列车移动。

### Management + Crisis

`Plan Stable System → Incident → Prioritize → Reallocate → Prevent Escalation → Recover`

稳定只是暂时的。

### Trading / Merchant

`Discover Demand → Acquire Supply → Travel/Access → Exchange → Profit/Relationship → Better Opportunity`

Reward 可以是路线权限、情报、人口、技术，不只钱。

### Crowd / Colony Simulation

`Create Conditions → Agents Act → Observe Bottleneck → Modify Environment/Policy → Agents Reorganize`

适合 Diorama / 大量 NPC。

### Craft / Assembly

`Acquire Components → Choose Combination → Assemble → Test → Deploy → New Components`

成品必须改变 Gameplay。

### Action Exploration

`Enter Space → Read Threat → Traverse → Interact/Fight/Avoid → Objective → Environment Changes → Continue`

Primary Verb 可是 Repair/Scan/Light/Carry/Stealth，不默认 Shooter。

## 4. Hybrid 判断

Hybrid 不是 A + B 两个小游戏并排。必须形成双向状态：`A → B → A` 或 `A → B → C → A`。例如 Runner 勘探产生路线数据→Network 选择维修路线→维修结果解锁新 Runner 区域。

## 5. 截图反推

只有 Gameplay 截图时，先从 Player / Interactable / UI / State / Camera / Possible Action / Visible Feedback 提取可见事实，并标记推测；有条件继续查 Gameplay 视频或可靠资料。

## 6. 完成标准

能在完全不提游戏名字的情况下回答“玩家每5秒做什么、要判断什么、受什么限制、看到什么结果、为什么再做一次”，Grammar 才完成。
