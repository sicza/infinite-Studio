# Image Contracts

## 目标

Image Contract 是 Design → Prompt 的视觉生产规格，冻结“这张图为什么存在、画什么、哪里画、多大、第一眼看什么、必须出现什么、不能加什么”。模型不负责自己设计核心构图。

## 1. 一图一主任务

先写 Purpose：验证角色身份、头身比、场景 Gameplay Geometry、Core Reward、Creature Silhouette 等。不要让一张图同时承担脸、全身、大场景、玩法、UI 五个同等目标。

## 2. 基本字段

`Asset Type / Purpose / Aspect Ratio / Primary Read / Subject Count / Primary Subject Position & Scale / Secondary Subject / Interaction Point / Gameplay Change Area / Foreground / Midground / Background / Reading Direction / Camera / Perspective / Framing / Pose/Action / Must Show / Must Preserve / Must Not Add`

`PORTFOLIO / VERTICAL_SLICE` 的每张正式证据再写：

`Content Graph Refs / Coverage Refs / Parent Asset or Screen ID / Variant Axes / Semantic Delta / Counting Class / Batch ID`

这些字段必须引用当前 Product Blueprint、Content Graph 与 Coverage Plan。`NEW_ASSET / NEW_STATE / NEW_EVENT / NEW_SCREEN / NEW_USE / PRESENTATION_ONLY` 由语义差决定，不由文件名、排版、镜头、UI 显隐或模型随机差异决定。没有 Coverage 的探索图不得提高正式分子。

## 3. Asset Contracts

### Character Full Body

Single Character；完整头顶到鞋底；Entire Footwear Visible；Camera/3⁄4 或正面按目的；背景简单；Must Show 5–8 个身份/功能关键；Must Not Add 不相关武器、额外人物、复杂背景、Crop Feet。

### Portrait

Head/Shoulders；Face Dominant；重点 Face Geometry/Hair/Age/Expression/Upper Costume Identity。不要用鞋/背包等低相关信息稀释脸。

### Turnaround

Same Character / Outfit / Body / Proportion；Front/Side/Back；Neutral Pose；Clean Background。禁止三个视图变三个人。

### Character Identity Sheet

Purpose 不是“画得丰富”，而是证明 Frozen Identity。建议按当前需求组合：`Neutral Full Body / 3⁄4 / Face Close-up / Silhouette / Key Icon Detail`。所有视图绑定同一 Character Identity Anchor 与 Mother References；禁止为了丰富性给不同视图偷偷换脸、体型、服装架构。

### Cast Lineup

统一 Ground Plane / Camera Family / Neutral Pose / Scale Rule；Purpose = 比较 `Height Rhythm / Width Rhythm / Body Mass / Silhouette / Face-Hair / Prop / Color Ownership`。不得用夸张透视让角色差异看起来比真实设定更大。

### Variant Stress Test

Same Character Identity，改变 2–4 个 Context Variant；锁 `Face Geometry / Core Hair Silhouette / Body Proportion Family / Primary Icon / Core Color Placement`，只开放 Variant Grammar 允许字段。Purpose = 验证换装不换人。

### Creature

先证明 Silhouette/Scale/Locomotion/Threat Structure，再加 Surface Detail；需要 Human/Environment Scale Reference。

### Environment Hero

Environment Identity、Camera、Scale Reference、Landmark、Fore/Mid/Background、Human Activity、Lighting。角色存在也不能抢环境主任务。

### Gameplay Environment

额外必须 Player Position / Route / Interaction / State-change Area / Future Area。

### Gameplay Hero Screen

`Gameplay Event / Primary Read / Player / Target / State Change / Reward / UI`，位置与尺度明确。

### Style Test

锁 Same Core World / Same Test Goal，但允许 Body Ratio/Camera/Prop Scale/Environment Scale/NPC Density/Detail Density 按产品表达变化，避免 Shader-only 比较。

## 4. Must Show / Preserve / Not Add

Must Show 只列真正决定身份、功能、玩法和世界 Hook 的 5–8 个高权重事实。

Must Preserve 只锁当前任务真正不能动的上游事实。长期角色优先从 `Character Identity Anchor + Variant Grammar + Mother Reference Manifest` 自动继承，不在每轮 Prompt 重新发明。

Must Not Add 用于阻止模型习惯性补 gun/helmet/extra NPC/text/logo/vehicle/monster/fog 等高风险内容，不写无限 Negative 清单。

## 5. Edit Contract

编辑额外加入：`CHANGE / LOCKED / DERIVED CHANGE / FORBIDDEN`。

例如只改腿：CHANGE=leg stance；LOCKED=face/hair/costume/weapon/camera/background；DERIVED=膝部衣褶/披风张力；FORBIDDEN=new armor/prop/identity change。

## 6. Contract → Prompt

Prompt 中高权重要求应来自 Contract。出现新武器/新 Landmark/新怪物等 Contract 没有的设计，说明 Prompt 越权。

Prompt Portfolio 中每个 Coverage 槽都拥有独立 Contract。批量生产不得共享一个含变量占位符的通用 Contract；可以继承 Frozen Anchor，但当前主体、事件、状态、构图、交互点和禁止项必须在本条 Contract 中闭合。每条正式 Prompt 使用稳定 `PROMPT_ID` 并绑定 `Direction / Material Domains / Graph Refs / Coverage Refs / Semantic Delta`。

## 7. 常见返修

- 半身 Crop → 修 Framing，不重写角色。
- 主角太小 → 修 Scale in Frame。
- 背景抢戏 → 修 Background Type / Primary Read。
- Gameplay 看不懂 → 修 Interaction / State-change / Reward Area。
