# ComfyUI FLUX Current Profile

Family: FLUX
Verified At: 2026-08-14
Freshness Class: VOLATILE
Reverify After: 30 days
Official Source: https://docs.comfy.org/tutorials/flux/flux-2-dev

## Current Relevant Family

ComfyUI 当前正式工作流已包含 FLUX.2 Dev、FLUX.2 Klein 4B/9B 及 FLUX.1 系列。新项目优先从对应官方模板验证，不继承旧架构默认参数。

## Routing

- Quality-first T2I / complex reference / semi-realistic：优先评估 FLUX.2 Dev。
- Fast local iteration / constrained VRAM：评估 Klein 系列。
- Image Editing：优先模型原生 Edit Workflow。

## Prompt

现代 FLUX 家族优先结构化自然语言；强 Pose/Depth/Edge/Identity 交给对应 Conditioning/Reference/Control，不靠 tag soup。

## Project Baseline

项目真正上线前保存 Model Variant / Workflow JSON / Resolution / Seed / Prompt / Guidance / Sampler/Scheduler if exposed / Reference Config / VRAM / Runtime / Known Failures。项目 Baseline 优先于本通用 Profile。
