# Creative Discovery & Operators

## 目标

把一句普通 Premise 转成真正具有产品差异的 Direction，而不是立即套“生存/经营/跑酷/塔防”等品类标签。

工作链：`Premise → Premise Map → Creative Levers → Questions → Operator Chains → Direction Seeds → Material Fertility → Direction Material DNA → Direction Prototypes`。

## 1. Premise Map

创意前先拆 7 类事实：

- **Theme**：题材、情绪、时代。
- **Structure**：节点、线路、层级、模块、边界、连接。
- **Function**：灾前/现实系统真正怎么工作。
- **Flow**：人、货、电、空气、水、信息、车辆、风险如何流动。
- **Constraint**：容量、时间、资源、安全、空间、天气等限制。
- **Human Role**：真正让系统运转的职业与责任。
- **Contradiction**：两种彼此拉扯的世界逻辑。

优先找“关系”和“限制”，不要只记漂亮名词。

## 2. Creative Lever

从 Premise Map 中挑 3–5 个能同时改变多个下游的高杠杆因素。优先：

- 会改变玩家行为；
- 能被画出来；
- 会影响 Character + Environment + Gameplay 中至少两个；
- 换成普通世界后不再成立。

例如“核战”通常只是 Theme；“地铁网络”“换乘容量”“通风系统”更容易成为 Lever。

## 3. 从 Lever 先造问题，不急着造答案

对每个 Lever 连问：

- 如果它断了会怎样？
- 如果它成为稀缺资源会怎样？
- 谁真正控制它？
- 谁依赖它？
- 它成功/失败怎样改变空间？
- 把它放大到整个产品会怎样？

## 4. Operators

### SYSTEMIZE

适合只有“地点/题材名词”的输入。强制回答：

1. 什么进入？
2. 什么离开？
3. 什么负责移动？
4. 什么负责转换？
5. 什么限制容量？
6. 什么会堵？
7. 什么最容易坏？
8. 谁负责继续运行？

产出必须包含关系，不是设施清单。

### NETWORKIZE

把世界改写成 `Node + Edge + Flow`。继续回答：节点为什么不同、连接为什么断、谁能重连、连接后谁获益/受损。

### ENVIRONMENT → RULE

把环境事实写成 `IF → THEN`：例如“如果一个区域断电超过一定时间，黑暗生物重新占据”。规则必须改变玩家决策，否则仍只是氛围。

### RESOURCE → WORLD

把 HUD 数值变成可见世界变化：电力恢复→灯亮/门开/居民回归；空气下降→可居住边界缩小。

### FAILURE → GAMEPLAY

从“什么最容易坏”开始，沿 `Failure → Visible Symptom → Escalation → Player Intervention → Recovery` 设计 Core Loop。

### ROLE FLIP

不要默认战士/英雄/基地长。尝试真实系统中的工程师、调度员、检疫员、站长、吊机操作员、巡检员、维修员、医生、商人等。每个角色回答：他控制什么、看到什么别人看不到、每天反复做什么、最大的失败是什么、成功怎样改变世界。

### RESPONSIBILITY FLIP

改变玩家负责尺度：`Self → Squad → Facility → Population → Route → Network → Civilization`，或反向收小。责任尺度应同步改变 Camera、信息层与情绪压力。

### FUNCTION INVERSION

写出 `Object / Original Function / Current Need`，让旧设施承担反向或新功能。继续追问这个功能怎样变成玩法与视觉证据。

### MOBILITY FLIP

让通常固定的东西移动，或让通常必须移动的东西失去移动能力。例如“基地是一列永不停驶的列车”。

### SCALE MUTATION

同一 Lever 分别尝试 `Individual / Facility / Network / Civilization`，每个尺度必须重新定义 Player Role、Core Verb、Camera、Reward；不是单纯缩放镜头。

### TIME SHIFT

比较 Crisis / Recovery / Established New Society。每个时间点重新回答资源、权力、技术、空间和 Player Verb；只改衣服旧一点不算成功。

### CIVILIZATION FORK

同一环境里构造不同的生存答案，让节点发展出不同资源、制度与依赖，产生贸易、冲突、外交与视觉身份。

### CONSTRAINT AMPLIFICATION

找到最有价值的限制并主动减少选择：12 个站只有 3 列车、6 个入口只有 1 个净化闸等。限制必须产生真实取舍。

### VERB / REWARD / PROGRESSION MUTATION

不要只换资源名。分别改：玩家真正做什么、最爽的可见结果是什么、长期世界怎样成长。

### CAMERA / PROPORTION MUTATION

Camera 和头身比变化必须重新检查信息层、角色屏占比、NPC 密度、Prop 尺度、Gameplay 可读性。禁止“同一游戏换 Renderer”。

### CONTRADICTION AMPLIFICATION

选两个最有张力的世界事实，让矛盾同时进入 Character、Environment、Gameplay，而不是做背景故事。

## 5. Operator Chains

Operator 要顺着后果串起来。例如：

`NETWORKIZE → TIME SHIFT → CIVILIZATION FORK → ROLE FLIP → CONSTRAINT AMPLIFICATION`

可能得到“断联 30 年后不同地铁站形成不同社会，玩家作为边境站主管，在有限通行容量下做检疫、接纳和贸易判断”。

## 6. Direction Seed

内部每个 Seed 用一句写清：

`PLAYER + CORE VERB + WORLD RULE + VISIBLE REWARD`

至少内部扩 6–12 个，再选 3–5 个给用户。

案例级任务不能只按标题和一句核心循环筛选。每个 Seed 还要列出它能因果派生的角色生态、地点／建筑生态、事件族、状态链、系统画面和交付用途，再按 `16-direction-material-divergence.md` 执行 Material Fertility。素材只来自换名、换装、换色或镜头变化的 Seed 直接淘汰。

## 7. 多方向差异检查

两个 Direction 如果只在人物或画风不同，而 `Core Verb / Reward / World Rule / Camera` 基本一样，不算不同方向。即使产品描述不同，若角色、空间、事件和系统画面仍可互换，也不得同时进入正式 Portfolio。

可用组合 `Grounded / Evolved / Bold / Wildcard` 作为内部覆盖提示，但不要为了标签硬凑。

## 8. 弱方向深化

如果“合理但没记忆点”：加强 Contradiction / Constraint / Function Inversion。

如果“很新但不像游戏”：补 Player Verb / Failure / Reward。

如果“好玩但世界只是皮肤”：补 Environment→Rule / Resource→World / World-binding Test。

如果“系统很强但没有角色感”：补 Role Flip / Human Scale。

## 9. 停止条件

方向已经有：明确玩家身份、Core Verb、World Rule、可见 Reward、世界专属关系、可落地场景、角色职能，并与其他候选显著不同，即进入 Prototype Realization。仍只能用“废土生存/经营/策略”描述时继续找。
