# Prompt Portfolio Composition

用于把已经通过素材肥力和方向差异审查的创意组合，编译为用户可直接使用的 Markdown Prompt Portfolio。Prompt 是最终载体；创意、素材关系与视觉权威仍来自既有 Lab、Visual Director 和 Prompt Compiler。

## 1. 不重建 Prompt 能力

每个正式 Prompt 继续走现有链：

`Direction Material DNA → Content Graph → Coverage → Image Contract → Visual Spec → Canonical Prompt → Optional Provider Adapter`

本能力只负责批量编排、依赖保持、Markdown 交付和 Prompt-level 验证，不复制 Visual Director、模型方言或图片生产职责。

## 2. Prompt Portfolio 不是变量模板

每条 Prompt 必须是完整、独立、可复制执行的正文。不得输出：

- `TBD`、占位符、待填写字段；
- “沿用上文”“与上一张相同”但没有重述必要锁定事实；
- 只有关键词、形容词或参数的骨架；
- 用角色名、建筑名或颜色替换制造的批量伪差异；
- 没有具体主体、动作、环境、构图或视觉因果的内容摘要。

合法复用通过 `must_preserve` 重述关键身份、拓扑和风格事实；合法变化通过 Semantic Delta 说明本 Prompt 新增的资产、状态、事件、屏幕或用途。

## 3. 用户可见 Markdown

推荐结构：

```text
work/final/prompt-portfolio-index.md
work/final/prompts/<direction-id>/01-character-and-cast.md
work/final/prompts/<direction-id>/02-creature-unit-npc.md
work/final/prompts/<direction-id>/03-environment-building-prop.md
work/final/prompts/<direction-id>/04-event-and-state.md
work/final/prompts/<direction-id>/05-gameplay-and-ui.md
work/final/prompts/<direction-id>/06-narrative-kv-packaging.md
```

每条使用稳定标记：

```markdown
<!-- PROMPT_ID: PROMPT-D01-001 -->
## PROMPT-D01-001 — 标题

```text
完整 Canonical Prompt 正文
```
```

索引只负责导航、方向差异和数量回执，不能代替 Prompt 正文。JSON Manifest 是内部机器绑定，不是主要用户交付。

## 4. Prompt 内容要求

每条正式 Prompt 至少明确：

- Purpose 与第一视觉读点；
- 主体身份、数量、相互关系和动作；
- 地点、空间层次、功能区域和世界专属物；
- Camera、Perspective、Framing 与阅读方向；
- 影响画面结果的 Gameplay、事件或状态变化；
- Must Preserve 与 Must Not Add；
- 至少八项针对当前画面的可见机制；
- Content Graph、Coverage、Direction 与素材域归属；
- `NEW_ASSET / NEW_STATE / NEW_EVENT / NEW_SCREEN / NEW_USE / PRESENTATION_ONLY` 中的真实增量。

机器 Manifest 还必须声明 `content_anchors`：主体身份、原子主体实体、地点身份、动作、可见后果和至少两个世界专属物。每个主体实体都是 `entity_id / entity_type / identity / visible_count=1` 的独立可见对象，identity 是最多四个词的名词性身份且不得包含另一个已登记主体身份；不得把“记者保护／靠近孩子”整句折叠成一个实体，`subject_identity` 必须按顺序精确连接实体 identity，`subject_count` 必须等于原子实体数。

每个 Direction 还必须声明独占的 `anchor_lexicon`：`subject_entities / locations / actions / consequences / world_objects`，并通过 `origin_evidence` 绑定 FROZEN Direction Origin JSON 与文件 SHA。Prompt 的全部内容锚必须属于本方向；多方向组合中同类锚不得交叉占有。Validator 会检查字段、Hash、词项所有权和明显串料，但这些结构事实不能证明语义归属真实成立：producer 可以同步重写 Origin、词库、DNA 和 Prompt。Direction 的因果与素材 DNA 是否真的被重新设计，必须由下述独立语义审查阅读真实 Prompt 后判断。

Canonical Prompt 使用 21 个顺序固定、各自独占一行且只出现一次的权威标签：Purpose、Subject identity、Subject entities、Location identity、Required action、Visible consequence、Direction、Direction causality、Material DNA、Primary read、Pose or action、World-specific objects、Must show、Visual mechanisms、Must preserve、Must not add、Semantic delta、Aspect ratio、Subject count、Camera、Framing。Validator 从这些行解析真实值，再与 Manifest 精确比较；对标签名执行 Unicode 规范化和大小写无关检测，把 `Camera:`、`camera:` 或全角变体藏进 `Must not add`、重复同名标签或仅让值在全文其他位置出现都不能通过。

`visual_mechanisms` 不是字符串列表，而是至少八个 `operation / target / visible_result` 三元组。机器检查 operation 是否来自允许集合、target 是否属于当前 Prompt、结果是否具备基本可观察结构，并检查目标和结果组合没有明显机械复用。它只能阻断低成本伪造，不能判断一句话是否真的形成有效画面机制；通用结果句、改写复述和语义空转由逐 Prompt 独立审查判定。

Prompt 正文必须自足。必要的角色和地点锁应直接进入正文，不能依赖模型读取内部 JSON。

## 5. 规模与形态

- `PROTOTYPE` 保留原轻量路径，不强制 Prompt Portfolio；
- `PORTFOLIO + MULTI_DIRECTION_DIVERGENCE`：至少 3 个方向，每个方向至少覆盖 4 个素材域和 8 条正式 Prompt；案例级目标通常为 48 条以上；
- `PORTFOLIO + SINGLE_DIRECTION_DEPTH`：至少覆盖 6 个素材域和 20 条正式 Prompt；案例级目标通常为 80 条以上；
- `HYBRID_PORTFOLIO`：至少 3 个方向，其中一个深度方向达到 20 条，其余方向各至少 8 条。

数量只是下限。语义重复、表现层变体和无因果素材不增加有效覆盖。

## 6. Prompt-only Evidence

当交付目标是 Prompt Portfolio 时，Coverage 使用 `CANONICAL_PROMPT` 证据。每条 Prompt 保存：

`prompt_id / evidence_id / direction_id / markdown_path / title / canonical_prompt / prompt_sha256 / graph_refs / coverage_refs / material_domains / counting_class / semantic_axes / presentation_only_axes / semantic_delta / content_anchors / image_contract / visual_mechanisms / must_preserve / must_not_add`

Evidence 的内容 Hash 使用 Prompt 正文 Hash，而不是整个 Markdown 文件 Hash；同一个 Markdown 文件中的不同 Prompt 不会被误判为相同证据。Markdown 文件本身仍通过路径、字节和 SHA 绑定。

## 7. 机器 Gate 与专业判断边界

Prompt-only 机器 Gate 可以证明：

- Prompt 实际存在、完整、自足、可追溯；
- 素材域、方向差异和语义增量的声明已完整登记并与当前文件绑定；
- Prompt 没有占位、精确重复和明显表现层伪增量；
- 角色、地点、状态与系统关系在文本权威上保持一致；
- 21 个权威标签唯一、顺序固定、解析值与 Manifest 精确相等，不能靠全文子串命中；
- 主体按原子可见实体计数，方向锚由 Direction 独占，视觉机制以 operation/target/visible_result 三元组落地；
- Prompt 不是仅替换编号、颜色或方向标签的模板克隆，正文与声明的内容锚、合同和方向 DNA 一致；
- Relationship / System 案例回归使用彼此隔离的素材词汇；同一关系组合中的不同方向也分别约束角色、地点、动作、后果和物件来源，跨案例或跨方向串料直接阻断；
- reviewer 回执覆盖全部 Prompt 和全部方向对，且绑定当前 Portfolio Manifest、每条 Prompt Hash 与审查报告。

机器 Gate 不能证明：某个主体短语是否偷偷折叠了多人、Direction DNA 是否只是 producer 自签改写、视觉机制结果是否真正有效、方向是否真的不可换皮、Prompt 是否达到案例级创意质量。字段存在、关键词命中、正则、相似度、数量和自签 Hash 都不能替代这些判断。

因此 `PROMPT_MARKDOWN | BOTH` 必须增加新的独立语义审查者。审查者不得与 Portfolio producer 相同；二者 actor ID 必须是规范化小写标识，大小写、首尾空格、兼容字符或零宽字符变化不构成不同身份。reviewer 必须完整阅读最终 Markdown，而不是抽样或只读 Manifest，并产出：

```text
work/concept-lab/prompt-semantic-review.json
work/final/prompt-semantic-review.md
```

每条 Prompt 都要分别审查主体基数与角色、因果和素材具体度、视觉机制有效性、完整可执行性、伪丰富度与重复风险；每个已批准方向对至少做两组真实 Swap Test，同时替换主体、地点、动作、后果、世界物件和因果链，说明为什么交换后会破坏该方向，而不只是风格不搭。审查报告严格区分事实、判断、建议和未知。任何 Prompt、任何方向对或任何 blocking unknown 为 `BLOCK`，整个 Portfolio 不得完成。

机器只验证规范化 reviewer 与 producer 标识分离、全量 ID 覆盖、Prompt/Manifest/报告 Hash 一致、Swap Test 结构齐全和最终结论为 PASS；`report_binding` 必须精确指向交付的 canonical `work/final/prompt-semantic-review.md`，不能内部审一个文件、对外提交另一个。专业语义结论由独立 reviewer 负责。它仍不能证明模型最终成图质量、参考图遵循程度或真实玩法体验；没有图片时不得产生这些声明。

审查义务由真实交付面决定，不允许靠模式字段或 role 改名逃逸。Active delivery role 使用 scope/output 精确白名单；`portfolio_output=EVIDENCE` 时不得出现 `prompt_portfolio_manifest / prompt_markdown / prototype_prompts / prompt_semantic_review / prompt_semantic_review_report`，未知 active role 也直接阻断。一旦正式交付任何 Prompt，就必须将输出模式声明为 `PROMPT_MARKDOWN | BOTH` 并完成全量独立审查。
