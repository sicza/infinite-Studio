# IP Character System

## 目标

为长期角色/IP建立可复用的身份系统，使角色在多姿态、多服装、多场景、多模型与编辑迭代中保持稳定身份。

核心链：

`IP DNA → Cast Architecture → Character Identity → Variant Grammar → Mother References → Binding → Image Contract → Provider Handoff → Consistency Review`

## 1. 适用条件

以下任一成立时建立完整系统：

- 同一角色预计跨多张图、姿态、场景或皮肤复用；
- 3 个以上核心角色需要形成统一家族语言与阵容差异；
- 用户要求角色 IP、品牌角色、Mascot、商业角色或长期角色资产；
- 已有正式设定图，需要继续扩展并保持身份；
- 后续需要跨模型或跨 Renderer 保持角色识别。

一次性 NPC 或只用于 Gameplay 验证的临时角色使用轻量 Character Anchor。

## 2. Authority

人物/IP长期事实按以下层级组织：

1. `IP DNA Anchor`
2. `Cast Architecture`
3. `Character Identity Anchor`
4. `Variant Grammar`
5. `Mother Reference Manifest`
6. `Image Contract`
7. `Generated Image (OBSERVED)`

默认 Authority：

`User Explicit Lock > Frozen IP/Character Anchor > Mother Reference Role Authority > Current Variant Contract > Pose/Composition/Style Reference > Previous Generated Image > Model Default`

Previous Generated Image 的职责是 edit target 或 continuity reference；Mother Reference Manifest 负责长期视觉 Authority。

## 3. IP DNA Anchor

### Shape Grammar

`Head-to-body Family / Head Scale / Shoulder-to-head Family / Torso Mass Logic / Waist-Pelvis Logic / Limb Taper / Hand Scale / Foot Scale / Center of Visual Mass / Primary Shape Rhythm / Silhouette Philosophy`

比例优先使用 family/range，只有真实设计事实要求时才使用固定单值。

### Facial Grammar

`Face Bounding Family / Eye Language / Brow Language / Nose Language / Mouth Language / Ear Exposure / Hairline Logic / Feature Exaggeration Range`

共享几何语言，不共享同一张脸。

### Surface / Rendering Grammar

`Realism / Material Strategy / Edge Language / Texture Density / Detail Density / Color Philosophy / Lighting Logic / Rendering Family`

Rendering Grammar 与 Shape Grammar 独立，Renderer 变化不自动改变身体或面部几何。

### Identity Grammar

`Recognition Distance / Iconic Feature Strategy / Stable Color Strategy / Signature Prop Strategy / Asymmetry Strategy / World Wear Logic`

分别定义 Portrait、Full-body、Thumbnail、Silhouette 尺度下的识别来源。

## 4. Character Identity Anchor

正式角色冻结：

`Character ID / Role / Exact Age / Face Geometry / Hair Silhouette / Body Mass Distribution / Proportion / Posture Baseline / Costume Architecture / Signature Color Placement / Primary Prop Relationship / World-specific Hook / Iconic Features`

其中：

- `Face Geometry` 使用结构描述；
- `Body Mass Distribution` 描述视觉重量分配；
- `Costume Architecture` 锁层级与大结构；
- `Iconic Features` 来自 Function、Identity、World、Gameplay、Camera 或 Recognition 需求。

## 5. Design Drivers

高权重设计特征至少归因到以下一类：

- `Functional`：Gameplay / Job / Environment / Risk；
- `Identity`：Personality / Narrative / Social Role / Emotional Read；
- `Iconic`：Recognition / IP传播 / UI缩略图 / 周边延展。

## 6. Variant Grammar

### STABLE

`Face Geometry / Core Hair Silhouette / Body Proportion Family / Primary Icon / Core Color Placement / Identity-defining Asymmetry`

### SEMI_VARIABLE

`Hair Styling / Makeup / Minor Accessories / Secondary Colors / Footwear Family / Minor Wear`

### CONTEXT_DRIVEN

`Armor / Profession Gear / Weather Clothing / Festival Skin / Damage State / Environment Protection`

### FREE

`Pose / Expression / Camera / Scene / FX / Temporary Interaction Props`

Variant 只在对应变化层内工作。用户明确改变身份设计时，更新相应 FROZEN 字段并提升 system version。

## 7. Mother Reference System

正式角色建立按职责拆分的 Mother Reference Pack。常见 Role：

- `identity-front`
- `identity-34`
- `face-master`
- `body-proportion`
- `costume-master`
- `material-master`
- `prop-master`

只要求实际身份维度都有明确 Authority，不要求固定数量。

Manifest 每项记录：

`REFERENCE_ID / LOCATOR{TYPE,VALUE} / ROLE / AUTHORITY / CHARACTER_ID / VERSION / STATUS / SOURCE / HASH_IF_AVAILABLE / NOTES`

`STATUS = FROZEN / ACTIVE / EXPERIMENTAL / DEPRECATED`

Locator 类型与 Provider 能力以 `config/provider-reference-binding-registry.json` 为机器 Authority。正式本地 Mother asset 由 runtime preflight 验证存在性、hash 与可解码图片格式。

## 8. Frozen System 与 Binding

长期 IP / 多图复用角色写：

```text
work/ip-character-system.json
```

只保存：

`IP DNA / Character Identity / Variant Grammar / Mother Reference Manifest / Cast Architecture(if any)`

Schema：`config/schemas/ip-character-system-schema.json`。

每次正式生成/编辑写：

```text
work/ip-character-binding.json
```

保存：

`CHARACTER_ID / SYSTEM_VERSION / VARIANT_OVERRIDES / MOTHER_REFERENCE_BINDING / REFERENCE_CONTRACT_REF / IMAGE_CONTRACT_REF`

Binding 中每个 Mother Reference 至少包含：

`REFERENCE_ID / USE_ROLES / PRESERVE / PROVIDER_SLOT_OR_ORDER(if applicable)`

Schema：`config/schemas/ip-character-binding-schema.json`。

Binding 是 Frozen Manifest 的当前使用视图；Provider slot/order 只承担执行映射，不改变 Reference Authority。

## 9. Production Runtime

先执行：

```text
python scripts/validate_ip_character_runtime.py \
  --system <request>/work/ip-character-system.json \
  --binding <request>/work/ip-character-binding.json \
  --asset-root <project-root> \
  --production \
  --report <request>/work/ip-character-preflight.json
```

Preflight 负责 System/Binding schema、版本、Variant、Authority、Reference 状态/角色/绑定、本地 Mother asset 与 Provider Registry 一致性。

实际生图/编辑再执行：

```text
python scripts/compile_ip_character_handoff.py \
  --system <request>/work/ip-character-system.json \
  --binding <request>/work/ip-character-binding.json \
  --workspace-root <workspace-root> \
  --provider <provider> \
  --mode <reference_to_image|image_to_image_edit> \
  [--base-image <workspace-relative-edit-target>] \
  --out <request>/work/ip-character-handoff.json
```

`READY` 是当前 `provider × mode × runtime × binding` 的事实。编辑模式的 `base_image` 保持 `edit_target` 身份；Mother References 继续拥有 Identity Authority。

Provider、locator、输入上限、slot/order、runtime hash 与当前支持模式由 `config/provider-reference-binding-registry.json` 和 Runtime 实现共同执行。`image_conditioning_inputs` 是独立图像输入通道，Prompt 只表达 Reference 的 Role/Preserve 语义。

`READY` 表示当前 Workspace Runtime 已验证本轮 Reference transport 并形成可消费 handoff；外部 Provider 实际生成结果属于 image-production execution，角色视觉一致性属于生成后的 Consistency Review。

## 10. Style / Proportion Mutation

- `Surface Style Translation`：保持 Shape / Face / Identity，只改变 Rendering / Material / Edge / Color / Light；
- `Product-level Proportion Mutation`：比例或脸部几何发生产品级变化时，建立新的 IP DNA / Style Prototype。

Q 版、写实化等转换根据是否改变身份几何判断属于哪一类。

## 11. 完成条件

正式 IP Character System 成立时：

- IP 家族语言与单角色身份已分离；
- Hard Identity 与可变层已分离；
- Mother References 的 Role/Authority 明确；
- 当前 Binding 能从 Frozen Truth 重新组装角色；
- Pose / Expression / Scene / Variant 变化保持身份；
- Style/Renderer 变化的可变边界明确；
- 实际生产任务通过适用的 preflight 与 Provider Handoff Gate。

## 12. Portfolio 集合视图

多角色内容包在 Content Graph 中为每个稳定 `character_id` 维护显示名、别名、职能、Anchor 引用、合法形态、允许 Variant Axis、禁止 Identity Delta 与 Screen Appearance。集合视图只治理跨角色关系，不替代本文件的单角色 Mother Reference、Binding、preflight 与 Provider Handoff。

同一真实视觉资产绑定多个 `character_id` 或多个显示名时记录 Identity／Name Conflict；同一显示名绑定多个视觉身份时同样阻断。冲突必须 `RESOLVED` 或带理由 `ACCEPTED`，不得通过删掉证据获得 PASS。
