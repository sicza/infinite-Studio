# Creature / Enemy Design

## 目标

Creature 先是 Gameplay Actor，再是怪物造型。核心链：`Gameplay Function → Habitat → Behavior → Detection → Locomotion → Attack/Interference → Anatomy → Silhouette → Surface`。

## 1. 先判断是否需要 Creature

如果主要压力已经来自缺氧、资源、调度、社会、天气，不为了题材强塞怪物。Creature 必须带来新的 Player Decision。

## 2. Gameplay Function

先选它逼玩家改变什么：`CHASE / AREA DENIAL / AMBUSH / RESOURCE THIEF / SYSTEM DISRUPTOR / HIVE EXPANSION / SLOW PRESSURE / HIGH-VALUE TARGET / ENVIRONMENTAL HAZARD`。

例：“只生活在完全黑暗区域并破坏新恢复的供电节点，迫使玩家维持照明网络”比“地下怪物很凶”有用得多。

## 3. Habitat & Behavior

明确 Temperature/Humidity/Light/Surface/Space/Verticality/Food/Infrastructure。先写它平时怎么移动、等待、寻找、逃离、攻击，再画身体。

## 4. Detection

从 Vision/Sound/Heat/Smell/Vibration/Electricity/Light Contrast/Chemical Signal 中确定感知机制。感知方式必须反向改变 Gameplay；例如感知电气振动意味着开机器本身就是风险。

## 5. Locomotion

身体结构必须支撑移动方式。狭窄隧道→低重心、柔韧脊柱；垂直井→抓附/爪/黏附；大厅冲锋→长步幅/质量分配。

## 6. Attack / Interference

Creature 可以攻击 Player、NPC、Power、Light、Resource、Building、Route、Visibility、Communication。强敌人不一定靠更高伤害，而是破坏系统。

## 7. Anatomy Derivation

按 `Mass Distribution / Skeleton / Spine / Limbs / Grip / Head / Mouth / Sensory Organ / Protection` 推导。每个大结构必须回答“为什么”。没眼睛就需要替代感官，不能行为上仍像正常视觉。

## 8. Silhouette

远距离至少能看出 Locomotion Type、Threat Level、Body Orientation。长前肢+拱背+低头比几十个小尖刺更有价值。

## 9. Surface Comes Last

最后才加 Skin/Fur/Fungus/Armor/Scar/Mucus/Radiation Effect，并服从 Habitat、Movement、Biology、Art Direction。

## 10. Counterplay

定义玩家怎样识别、规避、驱赶或利用它；Creature 不能只有攻击方式，没有可学习的 Counterplay。

## 11. Creature Anchor

`Gameplay Function / Habitat / Behavior Loop / Detection / Locomotion / Attack or Interference / Weakness / Mass Distribution / Anatomy / Silhouette / Surface / Color / Environment Relationship`

## 12. 完成标准

能回答玩家为什么怕它、它为什么长成这样、为什么生活在这里、身体是否真的能完成动作、剪影是否独特、是否真正改变 Gameplay。
