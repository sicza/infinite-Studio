# Reference Decomposition

## 目标

多参考图进入设计/Prompt 前必须先拆职责，防止“动作图顺便换脸、风格图顺便换服装、环境图污染构图”。

## 1. Role

每张图分配一个或多个窄职责：`IDENTITY / FACE / BODY / COSTUME / PROP / POSE / ACTION / CAMERA / COMPOSITION / STYLE / MATERIAL / LIGHTING / ENVIRONMENT / GAMEPLAY / UI / FX`。

“REFERENCE”或“综合参考”不是有效 Role。

## 2. 每种 Reference 怎么拆

### Identity

拆 `Face / Hair / Body / Proportion / Costume / Prop / Color Placement / Distinctive Features`。区分 Hard Identity（改了就不是同一角色）与 Soft Identity（Expression/Pose/Minor Wear 可变化）。

### Face

至少观察 Face Length/Width/Jaw/Chin/Cheekbone/Eye Spacing/Eye Shape/Brow/Nose/Mouth/Hairline，禁止只写“精致五官”。

### Costume

拆 Silhouette/Layering/Torso/Shoulder/Arm/Waist/Hip/Leg/Footwear/Material/Color Blocks/Functional Props。结构与表面纹理分开。

### Pose

拆 Torso/Pelvis/Head/Shoulder/Arms/Hands/Legs/Weight/Center of Gravity/Motion Direction，不借人物外观。

### Camera

拆 Height/Yaw/Pitch/Distance/Lens Feel/Perspective Strength/Framing/Horizon。

### Composition

拆 Primary Subject Position/Scale、Secondary Subject、Event Point、Fore/Mid/Background、Negative Space、Reading Axis、Motion Direction。

### Style

拆 Realism/Line/Shape/Rendering/Material/Edge/Color/Light/Contrast/Texture Density/FX，不自动改变 Identity/Proportion/Composition。

### Environment

拆 Architecture/Macro Layout/Scale/Landmark/Material Family/Lighting Logic/Density/Atmosphere/Camera Relation。

### Gameplay

拆 Camera/Player Position/Interaction Target/UI/State/Feedback/Flow/Object Scale，并判断这张图实际证明了什么 Gameplay。

## 3. Mother Reference vs Bound Reference

长期角色/IP先区分：

- `Mother Reference`：FROZEN/ACTIVE 的长期 Identity Authority，来自正式批准资产；
- `Bound Reference`：只服务当前请求的 Pose/Camera/Composition/Style/Environment 等临时参考；
- `Previous Generated Image`：默认仅是 OBSERVED 或 edit target，不自动成为 Mother Truth。

Mother Reference Manifest 必须记录 `REFERENCE_ID / LOCATOR{TYPE,VALUE} / ROLE / AUTHORITY / CHARACTER_ID / VERSION / STATUS / SOURCE`；若 runtime 可访问 bytes，推荐记录 SHA-256。Production `LOCAL_PATH` 还必须实际解码为支持的 `PNG/JPEG/WEBP` 图片；文件存在或 hash 正确不能替代图片可用性。正式生成只能绑定 `ACTIVE/FROZEN`，且 `USE_ROLES` 不得超出该 Mother Reference 的 ROLE。具体 Provider production handoff 至少绑定 1 个 Mother Reference；正式生成优先重新绑定 Mother References，避免误差沿着 v1→v2→v3 连续累积。

## 4. Reference Contract

每张最终写：

`REFERENCE ID / ROLE / PRESERVE / BORROW / REPLACE / IGNORE / AUTHORITY`

默认 Authority：`User Explicit Lock > Frozen IP/Character Anchor > Mother Reference Role Authority > Role-specific Reference > Gameplay/Environment Truth > Style Reference > Pose/Composition Reference > Previous Generated Image > Model Default`。

## 5. 常见失败

- Reference Bleeding：Pose 图污染服装/脸 → 收窄 Role 与 IGNORE。
- Identity Dilution：多图都影响脸 → `FACE AUTHORITY = one source`。
- Generational Drift：连续把上一张生成图当新母图 → 回到 Frozen Anchor + Mother References；上一张只保留当前 edit target 职责。
- Version Pollution：旧设定图与新设定图混用 → 检查 Mother Reference `VERSION / STATUS`，DEPRECATED 不得进入正式 binding。
- Style Changes Proportion：Q版 Style 图偷偷缩短角色 → 区分 Surface Style 与 Product-level Proportion Mutation。

## 6. 完成标准

每张图负责什么、不负责什么、冲突时谁优先都明确；Identity 不被动作图污染；Style 不自动改 Gameplay 结构；Prompt 能准确表达职责。
