# Gameplay Mutation

## 目标

把成熟 Gameplay 从“参考玩法”变成真正属于当前世界的 Gameplay。

输入：`Extracted Grammar + Must-preserve Fun + Creative Levers`。

## 1. Mutation Pass

依次检查：

1. **Target**：原行为作用对象是否应换成世界里的真实系统？
2. **Constraint**：当前世界的氧气、天气、容量、污染、路线等是否产生新决策？
3. **System Response**：动作是否改变真实世界，而不是只 +10 数字？
4. **Reward**：最爽结果能否直接成为 Hero Screen？
5. **Progression**：长期成长是否符合世界幻想？
6. **Failure**：失败是否改变区域、人口、路线、关系，而不只是 Game Over？
7. **Player Role**：原角色身份是否还合理？
8. **Space**：地图几何是否仍像原玩法换贴图？
9. **Camera**：信息尺度改变后原 Camera 是否仍合适？
10. **Character Consequence**：新玩法是否反推装备/职业？
11. **Environment Consequence**：新玩法系统是否真的出现在空间里？

## 2. Mutation Depth

- **L0 Baseline**：机制完全不变，只做对照。
- **L1 Reskin**：只换名字、资源、人物、环境。
- **L2 Integrated**：世界改变 Target / Reward / Progression，Core Verb 仍熟悉。
- **L3 Mutated**：世界规则改变 Decision / Constraint / Failure / Space。
- **L4 Hybrid**：两个 Grammar 互相产生状态闭环。

正式创新方向至少应达到 L2；宣称“新玩法”通常应达到 L3 或真正的 L4。

## 3. World-binding Test

残酷地问：把当前世界换成普通酒店/城市/城堡，这套玩法能否几乎原样继续？如果 YES，通常仍是 L0–L1。

真正绑定的 Mutation 会同时影响 `Decision / Constraint / Reward / Progression / Character / Environment` 中多个层。

## 4. Visual Proof Test

机制必须能被画出来。例如 `Power = Territory` 应该一眼看到 Lit Safe Zone vs Dark Unsafe Zone；Network Reconnection 应出现新路线、列车/人口流、区域重新激活。

如果玩法变化只能靠长文字解释，还没有完成视觉原型化。

## 5. Commercial Read

找“新玩法最爽的瞬间”。不是“维修成功 +100”，而是“整条地下线路逐段亮起，第一列列车重新驶入”。这通常就是首轮 Gameplay Hero Screen。

## 6. 示例：现场经营 → 地下生命维持

原：`Move → Need → Serve → Reward → Invest → Expand`

L1：Guest→Survivor，Room→Bunk，Money→Scrap，只是换皮。

L2：Need→Facility Failure；Serve→Repair；Reward→System Capacity；Expand→Unlock Station Sector。

L3：Power Failure 让区域变黑、NPC 撤离，玩家必须决定哪个系统先修；角色变成 Maintenance Chief，地图出现 Power/Water/Resident/Locked Zones。

## 7. 示例：Runner → Tunnel Survey

`Run → Avoid → Collect` 变成 `Run → Scan → Mark Hazard → Place Beacon → Reach Node`；结果是该隧道成为 Network Map 中真实可用路线。Score 变成 World Access。

## 8. 示例：Match-3 → Power Routing

Board→Local Circuit；Match→Route Energy；Blocker→Broken Node；Special→Emergency Bypass。胜利必须让真实 Station 亮起、NPC 回归、新 Sector 开启，否则仍只是视觉映射。

## 9. 输出

`Reference Grammar / Must-preserve Fun / World Levers / Preserve / Remove / Mutate / Add / New Core Loop / New Decision / New Constraint / New Feedback / New Reward / New Progression / New Failure / Player Role Consequence / Environment Consequence / Camera Consequence / Mutation Depth / Gameplay Hero Screen`
