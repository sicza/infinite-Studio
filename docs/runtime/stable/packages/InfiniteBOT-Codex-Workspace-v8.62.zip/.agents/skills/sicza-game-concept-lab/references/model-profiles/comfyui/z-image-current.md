# ComfyUI Z-Image Current Profile

Family: Z-Image
Verified At: 2026-08-14
Freshness Class: VOLATILE
Reverify After: 30 days
Official Source: https://docs.comfy.org/tutorials/image/z-image/z-image-turbo

## Current Family

Z-Image-Turbo / Z-Image-Base / Z-Image-Edit。

## Routing

- Turbo：快速 T2I、高迭代探索、消费级 GPU 测试。
- Edit：已有图的受控修改。
- Base：只有明确需要 Fine-tuning/Customization 时使用，不因为“Base”字样默认质量更高。

## Strengths

高效生成、写实方向、中文/英文文字能力与 Instruction-driven Edit。实际 VRAM/速度受分辨率、精度、Offload、Workflow 影响，项目上线前以真实环境 Baseline 为准。
