# Gameplay Screen & UI

## 目标

Gameplay Screen 必须让人第一眼知道“我是谁、我在做什么、操作什么、发生什么变化、为什么爽、下一步是什么”。

核心链：`Gameplay Truth → Before/After → Visual Proof → Primary Read → Composition → UI → Commercial Read`。

## 1. Gameplay Truth

先写真实链：`Player Verb → Target → System Response → Visible State Delta → Reward → Persistent Result → Next Decision`。不先设计 UI。

## 2. Before / After

必须定义可见差异。例如 Before：泵停、红灯、NPC 队列停滞、右区 Locked；After：水流、机器转、绿灯、NPC 恢复、右区开启。几乎看不出变化就不够强。

## 3. Read Hierarchy

每张图定义：

- **Primary Read**：第一眼最重要的产品价值。
- **Secondary Read**：玩家具体动作。
- **Tertiary Read**：NPC/未来区/次级结果。
- **Commercial Read**：如果是商店截图，用户为什么会想玩。

例如 Gameplay Truth 是“修发电机”，Commercial Read 应是“我让整个地下城市重新亮起来”，所以不能只拍角色拧螺丝。

## 4. Camera

Third Person→现场动作；Isometric→设施/NPC/多任务；Diorama/Cutaway→多层/资源流/大人口；Top-down/Network→路线/调度。

## 5. Layout

至少明确 Player / Interaction Target / Reward Area / Threat or Pressure / Future Area / UI Safe Area，并安排 Reading Axis。

## 6. UI Contract

UI 先回答“玩家现在必须知道什么”，再做视觉。分：

- Persistent：Health/Power/Currency/Population 等真正长期信息。
- Contextual：Repair/Open/Collect/Assign/Upgrade，只在交互附近出现。
- Progress：Repair % / Pressure / Decontamination 等。
- Objective：Current Goal / Sub-goal / Optional。
- Warning / Reward Feedback。

优先级：`Gameplay Critical > Current Objective > Current Interaction > Resource > Meta`。

Exact Chinese Text/Numbers/Logo 不要假设一次生图绝对可靠；Prototype 可生成结构，正式文字需 QA/Composite。

## 7. Hero Screen

第一轮优先选能同时证明 Core Loop + Core Reward 的瞬间，而不是 Menu/Tutorial/Idle。多图 Sequence 每张必须增加 New State 或 New Product Value；删除后无损的重复图不保留。

## 7.5 Screen Template 与 Experience Map

Screen Template 由 `Player Input / State Transition / Visible Feedback / Consequence / Persistent Information / Interaction Layout` 定义。同一底图的 UI 显隐、按钮文案、语言、裁切、镜头或排版变化属于 Presentation／Use；只有输入、状态变化、反馈或结果实质改变才建立新 Screen。

跨系统内容为每个 System 写：

`System ID / Input / Player Action / State Before / Transition / Visible Feedback / Output / Downstream System / Failure or Exit`

边必须写传递的真实 payload，例如资源、角色状态、地图解锁、叙事条件或商业化资格。两个页面相邻不构成系统因果。静态 Screen 的证据状态最多是 `OBSERVED_SCREEN`；没有交互原型或真实测试不得写 `PLAYABLE_VERIFIED`。

## 8. UI Anchor

`UI Family / Persistent Information / Contextual Information / Objective / Progress / Feedback / Hierarchy / Safe Areas / Density / Primary Action / Secondary Action`
