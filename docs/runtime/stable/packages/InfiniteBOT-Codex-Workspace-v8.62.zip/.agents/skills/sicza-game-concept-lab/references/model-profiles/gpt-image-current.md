# GPT Image Current Profile

Model Family: GPT Image
Default Production Model: gpt-image-2.5-flare
Supported Models: gpt-image-2.5-sunburst / gpt-image-2.5-flare / gpt-image-2
Provider: OpenAI
Verified At: 2026-09-14
Freshness Class: VOLATILE
Reverify After: 30 days
Official Source: https://developers.openai.com/api/docs/guides/image-generation

## Current Position

当前 OpenAI GPT Image 生成/编辑模型族。Flare 是普通 GPT 生图默认；Sunburst 承接 Image 2.5、高精度、4K、PNG 与透明输出；显式 Image 2 继续使用旧模型。

## Production Modes

`GENERATE / EDIT / MULTI-REFERENCE COMPOSE / ITERATIVE EDIT / TEXT-HEAVY IMAGE`

## Reference / Editing

当前高保真图像输入为该模型默认重要能力。多参考技术上可支持较多输入，但生产默认仍优先 1–4 张职责清楚的 Reference，而不是无控制堆图。

## Quality / Resolution

Quality/Resolution 属于调用参数，不写进 Canonical Prompt。高分辨率不等于自动补出缺失设计细节；大尺寸需要按当前 endpoint 规则验证。

## Recommended Routing

- Approved Character + new pose/camera → Reference + Anchor + Edit/Compose。
- Approved Environment + material/light/local change → Edit。
- New Gameplay Hero → Gameplay Truth + Image Contract → Generate。
- Exact final UI text/logo → 生成结构后仍做 QA/Composite。

## Refresh Trigger

新默认模型发布、分辨率/参考图/编辑行为变化、Profile 超过 30 天、用户问 current/latest、真实执行与 Profile 冲突时重新核对官方资料。
