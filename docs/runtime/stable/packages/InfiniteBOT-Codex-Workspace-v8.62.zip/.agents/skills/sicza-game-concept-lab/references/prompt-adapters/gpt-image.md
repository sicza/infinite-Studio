# GPT Image — Game Concept Domain Delta

共享 Provider 方言：`../../../wxian-image-production/references/prompt-packs/gpt-image-2.md`。  
共享不变量：`.agents/skills/sicza-visual-director/references/prompt-adapter-invariants.md`。

## Domain Delta

- Gameplay 图优先编码 `Player Action → Interaction Target → Visible Consequence`；
- Product Read / Interaction Point / Must Show 先于装饰风格；
- Character、Creature、Prop、Environment、UI 来自 Prototype/Frozen Anchor/Image Contract/Visual Spec；
- Edit 保持 Gameplay Read、Identity 与已批准 Camera/Composition，再表达当前 Change Scope；
- 多 Reference 的职责由 Reference Contract 与 Mother Binding 决定。

## IP Character Input

长期 IP / 正式角色使用 `05a-ip-character-system.md` 生成的 `ip-character-handoff.json`。`image_conditioning_inputs` 作为真实 GPT Image reference inputs；Prompt 只表达 `use_roles / preserve`。

Provider/Mode、locator、输入上限、顺序与 Runtime Gate 以 `config/provider-reference-binding-registry.json` 和当前 `wxian-image-production` 为 Authority。

## Failure Return

- Gameplay/产品事实 → Game Concept Authority；
- Camera/空间/光材质/层级 → Visual Spec；
- Prompt projection → 本 Adapter；
- Identity input binding → IP Character Handoff / image-production；
- Runtime/model capability → 执行层。
