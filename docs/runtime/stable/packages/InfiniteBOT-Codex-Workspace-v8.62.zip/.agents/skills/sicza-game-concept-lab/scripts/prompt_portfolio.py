#!/usr/bin/env python3
"""Compile and validate case-scale Markdown prompt portfolios."""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import re
import sys
import tempfile
import unicodedata
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


SCHEMA_VERSION = "sicza.game-concept.prompt-portfolio.v4"
PORTFOLIO_SHAPES = {"MULTI_DIRECTION_DIVERGENCE", "SINGLE_DIRECTION_DEPTH", "HYBRID_PORTFOLIO"}
SCALE_TIERS = {"STANDARD", "CASE_SCALE"}
EXPANSION_DRIVERS = {"RELATIONSHIP_DRIVEN", "SYSTEM_DRIVEN", "HYBRID"}
MATERIAL_DOMAINS = (
    "character_ecology",
    "space_ecology",
    "threat_ecology",
    "resource_prop_ecology",
    "event_families",
    "state_chains",
    "system_screen_families",
    "delivery_uses",
)
PRIMARY_MATERIAL_DOMAINS = {
    "character_ecology", "space_ecology", "event_families", "system_screen_families"
}
CAUSAL_AXES = ("player_agent", "relationship_engine", "world_rule", "core_loop")
COUNTING_SEMANTIC_AXES = {
    "NEW_ASSET": {"identity", "core_topology", "functional_role"},
    "NEW_STATE": {"entry_trigger", "visible_delta", "gameplay_meaning", "exit_or_recovery"},
    "NEW_EVENT": {"cause", "action", "consequence"},
    "NEW_SCREEN": {"input", "state_change", "feedback", "result"},
    "NEW_USE": {"delivery_purpose"},
    "PRESENTATION_ONLY": set(),
}
PRESENTATION_ONLY_AXES = {
    "camera", "layout", "ui_visibility", "language", "crop", "color", "lighting", "effect",
    "expression", "costume", "face", "duplicate",
}
PLACEHOLDER_RE = re.compile(
    r"(?:\bTBD\b|\bTODO\b|\bPLACEHOLDER\b|\[\s*(?:fill|insert|placeholder)[^\]]*\]|"
    r"\{[^{}\r\n]{1,100}\}|<\s*(?:fill|insert|placeholder|your[_ -]?|[A-Z][A-Z0-9_ -]{2,})[^>]*>|"
    r"待填写|待补充|根据需要(?:填写|补充))",
    re.IGNORECASE,
)
TOKEN_RE = re.compile(r"[a-z][a-z0-9'-]{2,}|[\u3400-\u9fff]{2,}", re.IGNORECASE)
CLONE_NOISE_RE = re.compile(
    r"\b(?:direction[-_ ]?[a-z0-9_-]*|prompt[-_ ]?[a-z0-9_-]*|study|variant|version|"
    r"red|orange|yellow|green|blue|purple|violet|pink|black|white|gray|grey|brown|gold|silver)\b|"
    r"#[0-9a-f]{3,8}|\b\d+(?:\.\d+)?\b",
    re.IGNORECASE,
)
LOW_INFORMATION_WORDS = {
    "asset", "concept", "direction", "frame", "image", "material", "prompt", "scene", "study",
    "variant", "version", "visual", "角色", "场景", "方向", "画面", "素材", "版本", "方案",
}
CANONICAL_SECTION_LABELS = (
    "Purpose", "Subject identity", "Subject entities", "Location identity", "Required action",
    "Visible consequence", "Direction", "Direction causality", "Material DNA", "Primary read",
    "Pose or action", "World-specific objects", "Must show", "Visual mechanisms", "Must preserve",
    "Must not add", "Semantic delta", "Aspect ratio", "Subject count", "Camera", "Framing",
)
ANCHOR_LEXICON_FIELDS = ("subject_entities", "locations", "actions", "consequences", "world_objects")
ATOMIC_ENTITY_TYPES = {"PERSON", "ANIMAL", "CREATURE", "VEHICLE", "STRUCTURE"}
ATOMIC_ENTITY_CLAUSE_RE = re.compile(
    r"(?:\b(?:and|with|while|who|that|beside|alongside|behind|before|after|around|against|between|among|"
    r"near|inside|outside|toward|towards|pair|duo|team|group|crowd|swarm|family|couple|"
    r"guarding|calming|shielding|treating|tracking|resisting|fortifying|carrying|escort(?:ing)?|"
    r"protecting|guiding|locating|directing|holding|managing|defending|triaging|stabilizing|"
    r"sheltering|restoring|training|rationing|exposing|assigning|organizing|counting|decoding)\b|"
    r"[+&/]|(?:和|与|及|以及|保护|护送|引导|追踪|治疗|防守))",
    re.IGNORECASE,
)
VISUAL_MECHANISM_OPERATIONS = {
    "asymmetric silhouette contrast", "foreground route obstruction", "midground cause-and-action coupling",
    "background consequence landmark", "functional prop scale cue", "material wear hierarchy",
    "directional crisis lighting", "controlled crowd density", "relationship distance staging",
    "state change before-and-after cue", "topology-preserving landmark placement", "single interaction focal point",
    "threat vector eye-line", "resource scarcity grouping", "readable traversal negative space",
    "system feedback color boundary", "identity-lock costume accent", "cause-to-consequence depth order",
    "world-specific tool affordance", "primary-versus-secondary value separation", "safe-zone boundary rhythm",
    "event timer pressure cue", "unit-role scale ladder", "screen-to-world continuity anchor",
    "occlusion-guided depth continuity",
}
VISUAL_RESULT_TERMS = {
    "affordance", "boundary", "contrast", "continuity", "depth", "distinct", "eye-line", "focal", "functional",
    "foreground", "hierarchy", "landmark", "material", "negative", "readable", "scale", "separation",
    "silhouette", "spatial", "thumbnail", "value", "visible", "层次", "轮廓", "可读", "视觉",
}
VISUAL_TARGET_REGIONS = {
    "foreground route", "midground action zone", "background consequence zone", "frame edge",
    "primary focal area", "secondary information layer",
}
OPERATION_RESULT_REQUIREMENTS = {
    "asymmetric silhouette contrast": {"thumbnail", "distinct"},
    "foreground route obstruction": {"blocked", "depth"},
    "midground cause-and-action coupling": {"sequence", "legible"},
    "background consequence landmark": {"aftermath", "readable"},
    "functional prop scale cue": {"affordance", "legible"},
    "material wear hierarchy": {"age", "hierarchy"},
    "directional crisis lighting": {"focal", "hazard"},
    "controlled crowd density": {"individual", "separation"},
    "relationship distance staging": {"emotional", "readable"},
    "state change before-and-after cue": {"transition", "comparison"},
    "topology-preserving landmark placement": {"navigation", "continuity"},
    "single interaction focal point": {"first", "readable"},
    "threat vector eye-line": {"incoming", "trajectory"},
    "resource scarcity grouping": {"priority", "depletion"},
    "readable traversal negative space": {"route", "passable"},
    "system feedback color boundary": {"changed", "state"},
    "identity-lock costume accent": {"recognizable", "distinct"},
    "cause-to-consequence depth order": {"sequence", "depth"},
    "world-specific tool affordance": {"function", "readable"},
    "primary-versus-secondary value separation": {"priority", "separation"},
    "safe-zone boundary rhythm": {"perimeter", "navigation"},
    "event timer pressure cue": {"urgency", "focal"},
    "unit-role scale ladder": {"hierarchy", "readable"},
    "screen-to-world continuity anchor": {"correspondence", "continuity"},
    "occlusion-guided depth continuity": {"overlap", "depth"},
}
VISUAL_RESULT_TERMS |= set().union(*OPERATION_RESULT_REQUIREMENTS.values())
PROMPT_MARKER = "<!-- PROMPT_ID: {prompt_id} -->"
AUTHORITY_CONFUSABLES = str.maketrans({
    "а": "a", "е": "e", "о": "o", "р": "p", "с": "c", "х": "x", "у": "y",
    "і": "i", "ј": "j", "ѕ": "s", "ӏ": "l",
})


class PromptPortfolioError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise PromptPortfolioError(message)


def sha_text(value: str) -> str:
    normalized = value.replace("\r\n", "\n").strip()
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def sha_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def bounded(root: Path, value: str | Path, *, exist: bool = False) -> Path:
    path = Path(value)
    path = (root / path if not path.is_absolute() else path).resolve()
    root = root.resolve()
    require(path == root or root in path.parents, f"path escapes Workspace: {value}")
    if exist:
        require(path.exists(), f"path does not exist: {value}")
    return path


def load_json(path: Path) -> dict[str, Any]:
    require(path.is_file(), f"prompt portfolio manifest missing: {path}")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise PromptPortfolioError(f"invalid prompt portfolio manifest: {exc}") from exc
    require(isinstance(value, dict), "prompt portfolio manifest root must be an object")
    return value


def string_list(value: Any, label: str, *, minimum: int = 0) -> list[str]:
    require(isinstance(value, list), f"{label} must be an array")
    require(len(value) >= minimum, f"{label} requires at least {minimum} items")
    require(all(isinstance(item, str) and item.strip() for item in value), f"{label} contains an empty item")
    require(len(value) == len(set(value)), f"{label} contains duplicates")
    return value


def normalized_phrase(value: str) -> str:
    return re.sub(r"[^a-z0-9\u3400-\u9fff]+", "", value.casefold())


def phrase_is_present(phrase: str, text: str) -> bool:
    needle = normalized_phrase(phrase)
    return len(needle) >= 4 and needle in normalized_phrase(text)


def _safe_section_atom(value: str, label: str) -> str:
    require(isinstance(value, str) and value.strip(), f"{label} contains an empty value")
    stripped = value.strip()
    require("\n" not in stripped and "\r" not in stripped, f"{label} contains a newline")
    require(";" not in stripped and " || " not in stripped, f"{label} contains a reserved list separator")
    return stripped


def serialize_list(values: list[str], label: str) -> str:
    return "; ".join(_safe_section_atom(value, label) for value in values)


def serialize_subject_entities(entities: list[dict[str, Any]]) -> str:
    return " || ".join(
        f"{entity['entity_id']} [{entity['entity_type']} x{entity['visible_count']}] {entity['identity']}"
        for entity in entities
    )


def serialize_mechanism(mechanism: dict[str, str]) -> str:
    return " -> ".join(
        _safe_section_atom(str(mechanism[key]), f"visual_mechanism.{key}")
        for key in ("operation", "target", "visible_result")
    )


def serialize_mechanisms(mechanisms: list[dict[str, str]]) -> str:
    return " || ".join(serialize_mechanism(mechanism) for mechanism in mechanisms)


def authority_skeleton(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value).casefold().translate(AUTHORITY_CONFUSABLES)
    return "".join(
        character for character in normalized
        if unicodedata.category(character) not in {"Cf", "Mn", "Me"}
    )


def parse_canonical_sections(text: str, prompt_id: str) -> dict[str, str]:
    lines = [line.strip() for line in text.replace("\r\n", "\n").split("\n") if line.strip()]
    require(len(lines) == len(CANONICAL_SECTION_LABELS),
            f"canonical prompt must contain exactly {len(CANONICAL_SECTION_LABELS)} authority lines: {prompt_id}")
    sections: dict[str, str] = {}
    seen: list[str] = []
    label_pattern = "|".join(re.escape(label) for label in CANONICAL_SECTION_LABELS)
    for line in lines:
        match = re.fullmatch(rf"({label_pattern}):[ \t]+(.+)", line)
        require(match is not None, f"canonical prompt contains an unrecognized or malformed authority line: {prompt_id}")
        label, value = match.group(1), match.group(2).strip()
        require(label not in sections, f"canonical prompt duplicates authority label {label}: {prompt_id}")
        require(value, f"canonical prompt authority label is empty: {prompt_id} -> {label}")
        normalized_value = authority_skeleton(value)
        hidden = [
            candidate for candidate in CANONICAL_SECTION_LABELS
            if f"{authority_skeleton(candidate)}:" in normalized_value
        ]
        hidden_label = hidden[0] if hidden else ""
        require(not hidden, f"canonical prompt hides authority label inside {label}: {prompt_id} -> {hidden_label}")
        sections[label] = value
        seen.append(label)
    require(tuple(seen) == CANONICAL_SECTION_LABELS,
            f"canonical prompt authority lines are missing, duplicated, or out of order: {prompt_id}")
    return sections


def require_section(sections: dict[str, str], label: str, expected: Any, prompt_id: str) -> None:
    require(sections[label] == str(expected),
            f"canonical authority section differs from manifest: {prompt_id} -> {label}")


def replace_canonical_section(text: str, label: str, value: str) -> str:
    lines = text.splitlines()
    prefix = f"{label}: "
    matches = [index for index, line in enumerate(lines) if line.startswith(prefix)]
    require(len(matches) == 1, f"cannot replace non-unique canonical section: {label}")
    lines[matches[0]] = f"{prefix}{value}"
    return "\n".join(lines)


def require_atomic_entity_identity(identity: str, label: str) -> None:
    value = _safe_section_atom(identity, label)
    require(len(value) <= 64, f"{label} is too long to be an atomic visible entity")
    latin_words = re.findall(r"[A-Za-z][A-Za-z'-]*", value)
    require(not latin_words or len(latin_words) <= 4,
            f"{label} is sentence-like rather than one atomic visible entity")
    require(ATOMIC_ENTITY_CLAUSE_RE.search(value) is None,
            f"{label} collapses a relation, action, or group into one visible entity")
    require_meaningful_phrase(value, label)


def subject_entity_list(value: Any, label: str) -> list[dict[str, Any]]:
    require(isinstance(value, list) and value, f"{label} must be a non-empty array")
    entities: list[dict[str, Any]] = []
    identities: list[str] = []
    ids: list[str] = []
    for entity in value:
        require(isinstance(entity, dict), f"{label} must contain typed entity objects")
        require(set(entity) == {"entity_id", "entity_type", "identity", "visible_count"},
                f"{label} entity fields are invalid")
        entity_id = str(entity["entity_id"])
        entity_type = str(entity["entity_type"])
        identity = str(entity["identity"])
        require(re.fullmatch(r"SUBJECT-[0-9]{2}", entity_id) is not None,
                f"{label} entity_id is invalid: {entity_id}")
        require(entity_type in ATOMIC_ENTITY_TYPES, f"{label} entity_type is invalid: {entity_type}")
        require(entity.get("visible_count") == 1,
                f"{label} requires one manifest item per visible entity")
        require_atomic_entity_identity(identity, f"{label}.{entity_id}.identity")
        entities.append(entity)
        identities.append(identity)
        ids.append(entity_id)
    require(len(ids) == len(set(ids)), f"{label} contains duplicate entity ids")
    require(len(identities) == len(set(identities)), f"{label} contains duplicate entity identities")
    return entities


def visual_mechanism_list(value: Any, label: str, *, minimum: int = 8) -> list[dict[str, str]]:
    require(isinstance(value, list) and len(value) >= minimum, f"{label} requires at least {minimum} items")
    mechanisms: list[dict[str, str]] = []
    signatures: list[str] = []
    residual_signatures: list[str] = []
    for item in value:
        require(isinstance(item, dict), f"{label} must contain operation/target/visible_result objects")
        require(set(item) == {"operation", "target", "visible_result"}, f"{label} mechanism fields are invalid")
        mechanism = {key: _safe_section_atom(str(item[key]), f"{label}.{key}")
                     for key in ("operation", "target", "visible_result")}
        require(mechanism["operation"] in VISUAL_MECHANISM_OPERATIONS,
                f"{label} contains a non-visual or unsupported operation: {mechanism['operation']}")
        require_meaningful_phrase(mechanism["visible_result"], f"{label}.visible_result")
        result_units = meaningful_units(mechanism["visible_result"])
        operation_units = meaningful_units(mechanism["operation"])
        require(len(result_units & VISUAL_RESULT_TERMS) >= 2,
                f"{label} visible_result lacks a concrete visual outcome")
        require(len(result_units & operation_units) >= min(2, len(operation_units)),
                f"{label} visible_result does not explain the selected operation")
        require(OPERATION_RESULT_REQUIREMENTS[mechanism["operation"]] <= result_units,
                f"{label} visible_result lacks the operation-specific observable outcome")
        require(phrase_is_present(mechanism["target"], mechanism["visible_result"]),
                f"{label} visible_result does not bind its target: {mechanism['target']}")
        mechanisms.append(mechanism)
        signatures.append(serialize_mechanism(mechanism))
        residual = normalized_phrase(mechanism["visible_result"])
        for removable in (mechanism["operation"], mechanism["target"]):
            residual = residual.replace(normalized_phrase(removable), "")
        residual_signatures.append(residual)
    require(len(signatures) == len(set(signatures)), f"{label} contains duplicates")
    require(len({item["target"] for item in mechanisms}) >= min(4, len(mechanisms)),
            f"{label} does not vary targets across the frame")
    require(len({normalized_phrase(item["visible_result"]) for item in mechanisms}) >= min(4, len(mechanisms)),
            f"{label} repeats a generic visible result")
    require(len(set(residual_signatures)) >= min(4, len(mechanisms)),
            f"{label} repeats one boilerplate result after removing operation and target")
    return mechanisms


def meaningful_units(value: str) -> set[str]:
    units: set[str] = set()
    for match in TOKEN_RE.finditer(value.casefold()):
        token = match.group(0)
        if token in LOW_INFORMATION_WORDS or re.fullmatch(r"(?:direction|prompt|asset)[-_]?\d+", token):
            continue
        if re.fullmatch(r"[\u3400-\u9fff]{2,}", token):
            units.update(token[index:index + 3] for index in range(max(1, len(token) - 2)))
        else:
            units.add(token)
    return units


def require_meaningful_phrase(value: str, label: str) -> None:
    stripped = CLONE_NOISE_RE.sub(" ", value)
    units = meaningful_units(stripped)
    has_long_word = any(re.fullmatch(r"[a-z][a-z'-]{5,}", unit) for unit in units)
    has_cjk_word = len(re.sub(r"[^\u3400-\u9fff]", "", stripped)) >= 2
    require(len(units) >= 2 or has_long_word or has_cjk_word,
            f"{label} is only an id, number, color, or generic label")


def clone_signature(value: str) -> str:
    normalized = CLONE_NOISE_RE.sub(" <noise> ", value.casefold())
    normalized = re.sub(r"\b(?:[a-z]+-){1,}[a-z0-9_-]+\b", " <id> ", normalized)
    return re.sub(r"\s+", " ", normalized).strip()


def unique(items: list[dict[str, Any]], key: str, label: str) -> dict[str, dict[str, Any]]:
    values = [str(item.get(key, "")) for item in items]
    require(all(values), f"{label} contains an empty {key}")
    repeated = [value for value, count in Counter(values).items() if count > 1]
    require(not repeated, f"duplicate {label}: {sorted(repeated)}")
    return {str(item[key]): item for item in items}


def validate_direction(direction: dict[str, Any], root: Path) -> None:
    required = {
        "direction_id", "title", "status", "expansion_driver", "causal_signature",
        "material_dna", "material_fertility", "anchor_lexicon", "origin_evidence",
    }
    require(required <= set(direction), f"direction missing fields: {sorted(required - set(direction))}")
    require(re.fullmatch(r"DIRECTION-[A-Z0-9_-]+", str(direction["direction_id"])) is not None,
            f"invalid direction_id: {direction['direction_id']}")
    require(direction["status"] in {"APPROVED", "REJECTED"}, "direction status must be APPROVED or REJECTED")
    require(direction["expansion_driver"] in EXPANSION_DRIVERS,
            f"invalid expansion driver: {direction['direction_id']}")
    causal = direction["causal_signature"]
    require(isinstance(causal, dict) and set(causal) == set(CAUSAL_AXES),
            f"causal signature fields invalid: {direction['direction_id']}")
    require(all(isinstance(causal[key], str) and causal[key].strip() for key in CAUSAL_AXES),
            f"causal signature contains an empty value: {direction['direction_id']}")
    for key in CAUSAL_AXES:
        require_meaningful_phrase(causal[key], f"{direction['direction_id']}.causal_signature.{key}")
    dna = direction["material_dna"]
    require(isinstance(dna, dict) and set(dna) == set(MATERIAL_DOMAINS),
            f"material DNA fields invalid: {direction['direction_id']}")
    supported = 0
    for domain in MATERIAL_DOMAINS:
        values = string_list(dna[domain], f"{direction['direction_id']}.{domain}")
        for index, value in enumerate(values):
            require_meaningful_phrase(value, f"{direction['direction_id']}.{domain}[{index}]")
        supported += bool(values)
    fertility = direction["material_fertility"]
    require(isinstance(fertility, dict), f"material fertility missing: {direction['direction_id']}")
    require(fertility.get("status") in {"PASS", "FAIL"}, f"material fertility status invalid: {direction['direction_id']}")
    require(fertility.get("supported_domains") == supported,
            f"material fertility supported_domains mismatch: {direction['direction_id']}")
    require(isinstance(fertility.get("prompt_capacity"), int) and fertility["prompt_capacity"] >= 0,
            f"material fertility prompt_capacity invalid: {direction['direction_id']}")
    if direction["status"] == "APPROVED":
        require(fertility["status"] == "PASS", f"approved direction failed material fertility: {direction['direction_id']}")
        require(supported >= 6, f"approved direction covers fewer than six material domains: {direction['direction_id']}")
    lexicon = direction["anchor_lexicon"]
    require(isinstance(lexicon, dict) and set(lexicon) == set(ANCHOR_LEXICON_FIELDS),
            f"direction anchor lexicon fields invalid: {direction['direction_id']}")
    for field in ANCHOR_LEXICON_FIELDS:
        values = string_list(lexicon[field], f"{direction['direction_id']}.anchor_lexicon.{field}", minimum=1)
        for value in values:
            if field == "subject_entities":
                require_atomic_entity_identity(value, f"{direction['direction_id']}.anchor_lexicon.{field}")
            else:
                require_meaningful_phrase(value, f"{direction['direction_id']}.anchor_lexicon.{field}")
    subject_catalog = lexicon["subject_entities"]
    for identity in subject_catalog:
        embedded = [
            other for other in subject_catalog
            if other != identity and phrase_is_present(other, identity)
        ]
        require(not embedded,
                f"direction subject catalog contains a composite identity: {direction['direction_id']} -> {identity}")
    origin = direction["origin_evidence"]
    require(isinstance(origin, dict) and set(origin) == {"source_id", "path", "sha256"},
            f"direction origin evidence fields invalid: {direction['direction_id']}")
    require(re.fullmatch(r"DIRECTION-ORIGIN-[A-Z0-9_-]+", str(origin["source_id"])) is not None,
            f"direction origin source_id invalid: {direction['direction_id']}")
    origin_path = bounded(root, str(origin["path"]), exist=True)
    require(origin_path.is_file() and origin_path.suffix.lower() == ".json",
            f"direction origin evidence must be JSON: {direction['direction_id']}")
    require(re.fullmatch(r"[0-9a-f]{64}", str(origin["sha256"])) is not None,
            f"direction origin evidence hash invalid: {direction['direction_id']}")
    require(sha_file(origin_path) == origin["sha256"],
            f"direction origin evidence hash mismatch: {direction['direction_id']}")
    origin_payload = load_json(origin_path)
    expected_origin = {
        "schema_version": "sicza.game-concept.direction-origin.v1",
        "source_id": origin["source_id"],
        "authority": "FROZEN",
        "direction_id": direction["direction_id"],
        "title": direction["title"],
        "causal_signature": direction["causal_signature"],
        "material_dna": direction["material_dna"],
        "anchor_lexicon": direction["anchor_lexicon"],
    }
    require(origin_payload == expected_origin,
            f"direction fields drift from frozen origin evidence: {direction['direction_id']}")


def computed_pair_difference(first: dict[str, Any], second: dict[str, Any]) -> tuple[set[str], set[str]]:
    causal = {
        key for key in CAUSAL_AXES
        if first["causal_signature"][key].casefold() != second["causal_signature"][key].casefold()
    }
    material = {
        key for key in MATERIAL_DOMAINS
        if {item.casefold() for item in first["material_dna"][key]}
        != {item.casefold() for item in second["material_dna"][key]}
    }
    return causal, material


def direction_semantic_units(direction: dict[str, Any]) -> set[str]:
    values = [direction["title"], *direction["causal_signature"].values()]
    values.extend(item for domain in MATERIAL_DOMAINS for item in direction["material_dna"][domain])
    return meaningful_units(" ".join(values))


def validate_prompt(prompt: dict[str, Any], directions: dict[str, dict[str, Any]], root: Path,
                    markdown_paths: set[str], graph_ids: set[str] | dict[str, dict[str, Any]] | None,
                    coverage_slots: dict[str, dict[str, Any]] | None) -> dict[str, Any]:
    required = {
        "prompt_id", "evidence_id", "direction_id", "markdown_path", "title", "canonical_prompt",
        "prompt_sha256", "graph_refs", "coverage_refs", "material_domains", "counting_class",
        "semantic_axes", "presentation_only_axes", "semantic_delta", "image_contract",
        "content_anchors", "visual_mechanisms", "must_preserve", "must_not_add",
    }
    require(required <= set(prompt), f"prompt missing fields: {sorted(required - set(prompt))}")
    prompt_id = str(prompt["prompt_id"])
    require(re.fullmatch(r"PROMPT-[A-Z0-9_-]+", prompt_id) is not None, f"invalid prompt_id: {prompt_id}")
    require(re.fullmatch(r"EVID-[A-Z0-9_-]+", str(prompt["evidence_id"])) is not None,
            f"invalid evidence_id for prompt: {prompt_id}")
    direction_id = str(prompt["direction_id"])
    require(direction_id in directions and directions[direction_id]["status"] == "APPROVED",
            f"prompt references non-approved direction: {prompt_id} -> {direction_id}")
    markdown_path = str(prompt["markdown_path"])
    require(markdown_path in markdown_paths, f"prompt markdown_path is not declared: {prompt_id}")
    require(markdown_path.endswith(".md"), f"prompt output must be Markdown: {prompt_id}")
    canonical = str(prompt["canonical_prompt"]).strip()
    require(len(canonical) >= 180, f"canonical prompt is too short to be independently executable: {prompt_id}")
    require(PLACEHOLDER_RE.search(canonical) is None, f"canonical prompt contains a placeholder: {prompt_id}")
    require(prompt["prompt_sha256"] == sha_text(canonical), f"prompt hash mismatch: {prompt_id}")
    sections = parse_canonical_sections(canonical, prompt_id)
    graph_refs = string_list(prompt["graph_refs"], f"{prompt_id}.graph_refs", minimum=1)
    coverage_refs = string_list(prompt["coverage_refs"], f"{prompt_id}.coverage_refs", minimum=1)
    if graph_ids is not None:
        known_graph_ids = set(graph_ids)
        require(set(graph_refs) <= known_graph_ids, f"prompt references unknown graph nodes: {prompt_id}")
        if isinstance(graph_ids, dict):
            require(any(direction_id in graph_ids[node_id].get("direction_refs", []) for node_id in graph_refs),
                    f"prompt graph refs do not bind its direction: {prompt_id} -> {direction_id}")
    if coverage_slots is not None:
        for coverage_id in coverage_refs:
            require(coverage_id in coverage_slots, f"prompt references unknown coverage slot: {prompt_id} -> {coverage_id}")
            slot = coverage_slots[coverage_id]
            require(slot["evidence_kind"] == "CANONICAL_PROMPT",
                    f"prompt coverage is not CANONICAL_PROMPT: {prompt_id} -> {coverage_id}")
            require(prompt["evidence_id"] in slot["evidence_refs"],
                    f"prompt evidence is not reciprocal with coverage: {prompt_id} -> {coverage_id}")
            require(slot["counting_class"] == prompt["counting_class"],
                    f"prompt counting class differs from coverage: {prompt_id} -> {coverage_id}")
    domains = set(string_list(prompt["material_domains"], f"{prompt_id}.material_domains", minimum=1))
    require(domains <= set(MATERIAL_DOMAINS), f"prompt contains invalid material domain: {prompt_id}")
    anchors = prompt["content_anchors"]
    anchor_fields = {
        "subject_identity", "subject_entities", "location_identity", "action", "visible_consequence",
        "world_specific_objects",
    }
    require(isinstance(anchors, dict) and set(anchors) == anchor_fields,
            f"prompt content anchors are incomplete: {prompt_id}")
    anchor_phrases = [
        str(anchors["subject_identity"]), str(anchors["location_identity"]),
        str(anchors["action"]), str(anchors["visible_consequence"]),
    ]
    subject_entities = subject_entity_list(
        anchors["subject_entities"], f"{prompt_id}.content_anchors.subject_entities"
    )
    subject_identities = [entity["identity"] for entity in subject_entities]
    anchor_phrases.extend(string_list(
        anchors["world_specific_objects"], f"{prompt_id}.content_anchors.world_specific_objects", minimum=2
    ))
    for index, phrase in enumerate(anchor_phrases):
        require(isinstance(phrase, str) and phrase.strip(), f"prompt content anchor is empty: {prompt_id}")
        require(PLACEHOLDER_RE.search(phrase) is None, f"prompt content anchor contains a placeholder: {prompt_id}")
        require_meaningful_phrase(phrase, f"{prompt_id}.content_anchors[{index}]")
    require(anchors["subject_identity"] == " + ".join(subject_identities),
            f"subject_identity must be the exact ordered identity of atomic visible entities: {prompt_id}")
    require_section(sections, "Subject entities", serialize_subject_entities(subject_entities), prompt_id)
    require_section(sections, "Subject identity", anchors["subject_identity"], prompt_id)
    require_section(sections, "Location identity", anchors["location_identity"], prompt_id)
    require_section(sections, "Required action", anchors["action"], prompt_id)
    require_section(sections, "Visible consequence", anchors["visible_consequence"], prompt_id)
    require_section(
        sections, "World-specific objects",
        serialize_list(anchors["world_specific_objects"], f"{prompt_id}.world_specific_objects"), prompt_id,
    )
    direction = directions[direction_id]
    require_section(sections, "Direction", direction["title"], prompt_id)
    lexicon = direction["anchor_lexicon"]
    require(set(subject_identities) <= set(lexicon["subject_entities"]),
            f"prompt subject entities are not owned by their direction: {prompt_id}")
    require(anchors["location_identity"] in lexicon["locations"],
            f"prompt location is not owned by its direction: {prompt_id}")
    require(anchors["action"] in lexicon["actions"],
            f"prompt action is not owned by its direction: {prompt_id}")
    require(anchors["visible_consequence"] in lexicon["consequences"],
            f"prompt consequence is not owned by its direction: {prompt_id}")
    require(set(anchors["world_specific_objects"]) <= set(lexicon["world_objects"]),
            f"prompt world objects are not owned by their direction: {prompt_id}")
    dna_section_values = [value.strip() for value in sections["Material DNA"].split("; ") if value.strip()]
    require(len(dna_section_values) == len(set(dna_section_values)) and dna_section_values,
            f"prompt Material DNA section is empty or duplicated: {prompt_id}")
    grounded_dna: dict[str, set[str]] = {}
    for domain in domains:
        matches = {
            item for item in direction["material_dna"][domain]
            if item in dna_section_values
        }
        require(matches, f"prompt does not ground its direction material DNA: {prompt_id} -> {domain}")
        grounded_dna[domain] = matches
    allowed_dna_values = {item for domain in domains for item in direction["material_dna"][domain]}
    require(set(dna_section_values) <= allowed_dna_values,
            f"prompt Material DNA section contains an unowned value: {prompt_id}")
    counting_class = prompt["counting_class"]
    require(counting_class in COUNTING_SEMANTIC_AXES, f"invalid prompt counting class: {prompt_id}")
    semantic_axes = set(string_list(prompt["semantic_axes"], f"{prompt_id}.semantic_axes"))
    presentation_axes = set(string_list(prompt["presentation_only_axes"], f"{prompt_id}.presentation_only_axes"))
    require(semantic_axes <= COUNTING_SEMANTIC_AXES[counting_class],
            f"prompt semantic axes mismatch counting class: {prompt_id}")
    require(presentation_axes <= PRESENTATION_ONLY_AXES, f"prompt presentation axes invalid: {prompt_id}")
    if counting_class == "PRESENTATION_ONLY":
        require(not semantic_axes, f"presentation-only prompt claims semantic change: {prompt_id}")
    else:
        require(bool(semantic_axes), f"semantic prompt lacks semantic axes: {prompt_id}")
    require(isinstance(prompt["semantic_delta"], str) and prompt["semantic_delta"].strip(),
            f"prompt semantic_delta missing: {prompt_id}")
    require_meaningful_phrase(prompt["semantic_delta"], f"{prompt_id}.semantic_delta")
    require_section(sections, "Semantic delta", prompt["semantic_delta"], prompt_id)
    contract = prompt["image_contract"]
    contract_fields = {
        "purpose", "aspect_ratio", "primary_read", "subject_count", "camera", "framing",
        "pose_or_action", "must_show", "must_preserve", "must_not_add",
    }
    require(isinstance(contract, dict) and contract_fields <= set(contract),
            f"prompt image contract incomplete: {prompt_id}")
    require(all(contract[key] not in (None, "") for key in contract_fields - {"must_show", "must_preserve", "must_not_add"}),
            f"prompt image contract contains empty scalar: {prompt_id}")
    require(isinstance(contract["subject_count"], int) and contract["subject_count"] > 0,
            f"prompt image contract subject_count invalid: {prompt_id}")
    require(contract["subject_count"] == sum(entity["visible_count"] for entity in subject_entities),
            f"prompt image contract subject_count differs from subject_entities: {prompt_id}")
    for field, label in (
        ("purpose", "Purpose"), ("aspect_ratio", "Aspect ratio"), ("primary_read", "Primary read"),
        ("subject_count", "Subject count"), ("camera", "Camera"), ("framing", "Framing"),
        ("pose_or_action", "Pose or action"),
    ):
        require_section(sections, label, contract[field], prompt_id)
    contract_phrases: list[str] = []
    contract_phrases.extend(string_list(contract["must_show"], f"{prompt_id}.image_contract.must_show", minimum=3))
    contract_phrases.extend(string_list(contract["must_preserve"], f"{prompt_id}.image_contract.must_preserve", minimum=1))
    contract_phrases.extend(string_list(contract["must_not_add"], f"{prompt_id}.image_contract.must_not_add", minimum=1))
    preserve = string_list(prompt["must_preserve"], f"{prompt_id}.must_preserve", minimum=1)
    exclusions = string_list(prompt["must_not_add"], f"{prompt_id}.must_not_add", minimum=1)
    mechanisms = visual_mechanism_list(prompt["visual_mechanisms"], f"{prompt_id}.visual_mechanisms", minimum=8)
    require(contract["must_preserve"] == preserve,
            f"prompt must_preserve differs from image contract: {prompt_id}")
    require(contract["must_not_add"] == exclusions,
            f"prompt must_not_add differs from image contract: {prompt_id}")
    must_show = contract["must_show"]
    require({anchors["subject_identity"], anchors["action"], anchors["visible_consequence"]} <= set(must_show),
            f"prompt must_show does not contain subject/action/consequence anchors: {prompt_id}")
    require_section(sections, "Must show", serialize_list(must_show, f"{prompt_id}.must_show"), prompt_id)
    require_section(sections, "Must preserve", serialize_list(preserve, f"{prompt_id}.must_preserve"), prompt_id)
    require_section(sections, "Must not add", serialize_list(exclusions, f"{prompt_id}.must_not_add"), prompt_id)
    require_section(sections, "Visual mechanisms", serialize_mechanisms(mechanisms), prompt_id)
    for label, phrase in [("image_contract", value) for value in contract_phrases] + [
        ("must_preserve", value) for value in preserve
    ] + [("must_not_add", value) for value in exclusions]:
        require_meaningful_phrase(phrase, f"{prompt_id}.{label}")
    allowed_mechanism_targets = set(subject_identities) | {
        anchors["subject_identity"], anchors["location_identity"], *anchors["world_specific_objects"],
    } | VISUAL_TARGET_REGIONS
    for mechanism in mechanisms:
        require(mechanism["target"] in allowed_mechanism_targets,
                f"prompt visual mechanism target is not owned by the prompt: {prompt_id} -> {mechanism['target']}")
    path = bounded(root, markdown_path, exist=True)
    require(path.is_file() and path.suffix.lower() == ".md", f"prompt Markdown missing: {prompt_id}")
    text = path.read_text(encoding="utf-8")
    marker = PROMPT_MARKER.format(prompt_id=prompt_id)
    require(text.count(marker) == 1, f"prompt marker missing or duplicated in Markdown: {prompt_id}")
    require(text.count(canonical) == 1, f"canonical prompt missing or duplicated in Markdown: {prompt_id}")
    causal_section_values = [value.strip() for value in sections["Direction causality"].split("; ") if value.strip()]
    require(len(causal_section_values) == len(set(causal_section_values)) and causal_section_values,
            f"prompt Direction causality section is empty or duplicated: {prompt_id}")
    grounded_causal = {
        key for key, value in direction["causal_signature"].items() if value in causal_section_values
    }
    require(set(causal_section_values) <= set(direction["causal_signature"].values()),
            f"prompt Direction causality contains an unowned value: {prompt_id}")
    require(grounded_causal, f"prompt does not ground any direction causal axis: {prompt_id}")
    return {
        "canonical": canonical,
        "lexical_units": meaningful_units(canonical),
        "clone_signature": clone_signature(canonical),
        "anchor_signature": tuple(sorted(normalized_phrase(value) for value in anchor_phrases)),
        "mechanism_signature": tuple(sorted(normalized_phrase(serialize_mechanism(value)) for value in mechanisms)),
        "grounded_dna": grounded_dna,
        "grounded_causal": grounded_causal,
    }


def validate_portfolio(data: dict[str, Any], root: Path, *, product_id: str | None = None,
                       graph_ids: set[str] | dict[str, dict[str, Any]] | None = None,
                       coverage_slots: dict[str, dict[str, Any]] | None = None) -> dict[str, Any]:
    required = {
        "schema_version", "product_id", "producer_id", "portfolio_shape", "scale_tier", "markdown_files",
        "directions", "direction_comparisons", "prompts",
    }
    require(required <= set(data), f"prompt portfolio missing fields: {sorted(required - set(data))}")
    require(data["schema_version"] == SCHEMA_VERSION, "prompt portfolio schema_version mismatch")
    require(isinstance(data["producer_id"], str)
            and re.fullmatch(r"[a-z0-9][a-z0-9._-]{2,127}", data["producer_id"]) is not None,
            "prompt portfolio producer_id must be a canonical lowercase actor id")
    if product_id is not None:
        require(data["product_id"] == product_id, "prompt portfolio product_id mismatch")
    shape = data["portfolio_shape"]
    tier = data["scale_tier"]
    require(shape in PORTFOLIO_SHAPES, f"invalid portfolio_shape: {shape}")
    require(tier in SCALE_TIERS, f"invalid scale_tier: {tier}")
    markdown_paths = set(string_list(data["markdown_files"], "markdown_files", minimum=1))
    require(all(path.endswith(".md") for path in markdown_paths), "prompt portfolio outputs must be Markdown")
    directions_list = data["directions"]
    prompts = data["prompts"]
    comparisons = data["direction_comparisons"]
    require(isinstance(directions_list, list) and directions_list, "prompt portfolio directions missing")
    require(isinstance(prompts, list) and prompts, "prompt portfolio prompts missing")
    require(isinstance(comparisons, list), "direction_comparisons must be an array")
    directions = unique(directions_list, "direction_id", "prompt portfolio directions")
    for direction in directions_list:
        validate_direction(direction, root)
    approved = {key: value for key, value in directions.items() if value["status"] == "APPROVED"}
    if shape == "SINGLE_DIRECTION_DEPTH":
        require(len(approved) == 1, "SINGLE_DIRECTION_DEPTH requires exactly one approved direction")
    else:
        require(3 <= len(approved) <= 5, f"{shape} requires 3-5 approved directions")
        origin_units = {direction_id: direction_semantic_units(direction) for direction_id, direction in approved.items()}
        for direction_id, direction in approved.items():
            other_units = set().union(*(
                units for other_id, units in origin_units.items() if other_id != direction_id
            ))
            exclusive_units = origin_units[direction_id] - other_units
            require(exclusive_units, f"direction has no discriminative causal/material vocabulary: {direction_id}")
            for field in ANCHOR_LEXICON_FIELDS:
                for value in direction["anchor_lexicon"][field]:
                    value_units = meaningful_units(value)
                    own_score = len(value_units & origin_units[direction_id])
                    foreign_score = max(
                        len(value_units & units) for other_id, units in origin_units.items()
                        if other_id != direction_id
                    )
                    require(bool(value_units & exclusive_units),
                            f"direction anchor lacks causal/material ownership evidence: {direction_id} -> {field} -> {value}")
                    require(own_score > foreign_score,
                            f"direction anchor semantically belongs to another direction: {direction_id} -> {field} -> {value}")
        for first_id, second_id in itertools.combinations(sorted(approved), 2):
            for field in ANCHOR_LEXICON_FIELDS:
                first_values = {normalized_phrase(value) for value in approved[first_id]["anchor_lexicon"][field]}
                second_values = {normalized_phrase(value) for value in approved[second_id]["anchor_lexicon"][field]}
                overlap = first_values & second_values
                require(not overlap,
                        f"approved directions share {field} anchor ownership: {first_id}, {second_id}")
    prompt_by_id = unique(prompts, "prompt_id", "prompt ids")
    prompt_by_evidence = unique(prompts, "evidence_id", "prompt evidence ids")
    prompt_facts: dict[str, dict[str, Any]] = {}
    for prompt in prompts:
        prompt_facts[prompt["prompt_id"]] = validate_prompt(
            prompt, directions, root, markdown_paths, graph_ids, coverage_slots
        )
    require(len({item["prompt_sha256"] for item in prompts}) == len(prompts),
            "prompt portfolio contains exact duplicate canonical prompts")
    clone_groups: dict[str, list[str]] = defaultdict(list)
    anchor_groups: dict[tuple[str, ...], list[str]] = defaultdict(list)
    for prompt_id, facts in prompt_facts.items():
        clone_groups[facts["clone_signature"]].append(prompt_id)
        anchor_groups[facts["anchor_signature"]].append(prompt_id)
    cloned = [ids for ids in clone_groups.values() if len(ids) > 1]
    require(not cloned, f"prompt portfolio contains number/color/direction-label template clones: {cloned[0][:4] if cloned else []}")
    repeated_anchors = [ids for ids in anchor_groups.values() if len(ids) > 1]
    require(not repeated_anchors,
            f"prompt portfolio repeats the same content-anchor bundle: {repeated_anchors[0][:4] if repeated_anchors else []}")
    prompt_items = list(prompt_facts.items())
    for index, (first_id, first_facts) in enumerate(prompt_items):
        for second_id, second_facts in prompt_items[index + 1:]:
            left, right = first_facts["lexical_units"], second_facts["lexical_units"]
            similarity = len(left & right) / len(left | right) if left and right else 1.0
            require(similarity < 0.92,
                    f"prompt portfolio contains near-template canonical prompts: {first_id}, {second_id}, similarity={similarity:.3f}")
    prompts_by_direction: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for prompt in prompts:
        prompts_by_direction[prompt["direction_id"]].append(prompt)
    for direction_id, direction in approved.items():
        owned = prompts_by_direction[direction_id]
        require(owned, f"approved direction has no prompts: {direction_id}")
        covered_domains = {domain for prompt in owned for domain in prompt["material_domains"]}
        require(len(covered_domains) >= 4, f"direction prompts cover fewer than four material domains: {direction_id}")
        require(direction["material_fertility"]["prompt_capacity"] >= len(owned),
                f"direction prompt count exceeds declared material fertility: {direction_id}")
        minimum = 20 if shape == "SINGLE_DIRECTION_DEPTH" else 8
        if shape == "HYBRID_PORTFOLIO" and direction.get("depth_anchor") is True:
            minimum = 20
        require(len(owned) >= minimum, f"direction has fewer than {minimum} prompts: {direction_id}")
        mechanism_groups = Counter(prompt_facts[item["prompt_id"]]["mechanism_signature"] for item in owned)
        max_reuse = max(2, len(owned) // 12)
        require(max(mechanism_groups.values(), default=0) <= max_reuse,
                f"direction repeats one generic eight-mechanism bundle too often: {direction_id}")
        grounded_causal = {
            axis for item in owned for axis in prompt_facts[item["prompt_id"]]["grounded_causal"]
        }
        require(grounded_causal == set(CAUSAL_AXES),
                f"direction prompts do not ground all causal axes: {direction_id}")
    if shape == "HYBRID_PORTFOLIO":
        require(sum(direction.get("depth_anchor") is True for direction in approved.values()) == 1,
                "HYBRID_PORTFOLIO requires exactly one depth_anchor direction")
    if tier == "CASE_SCALE":
        minimum_total = 80 if shape == "SINGLE_DIRECTION_DEPTH" else 48
        require(len(prompts) >= minimum_total,
                f"CASE_SCALE {shape} requires at least {minimum_total} prompts")
    expected_pairs = {frozenset(pair) for pair in itertools.combinations(sorted(approved), 2)}
    actual_pairs: set[frozenset[str]] = set()
    for comparison in comparisons:
        required_comparison = {
            "direction_a", "direction_b", "changed_causal_axes", "changed_material_domains",
            "skin_swap_interchangeable", "status",
        }
        require(required_comparison <= set(comparison), "direction comparison missing fields")
        first_id, second_id = comparison["direction_a"], comparison["direction_b"]
        pair = frozenset((first_id, second_id))
        require(len(pair) == 2 and first_id in approved and second_id in approved,
                f"direction comparison pair invalid: {first_id}, {second_id}")
        require(pair not in actual_pairs, f"duplicate direction comparison: {first_id}, {second_id}")
        actual_pairs.add(pair)
        causal, material = computed_pair_difference(approved[first_id], approved[second_id])
        declared_causal = set(string_list(comparison["changed_causal_axes"], "changed_causal_axes", minimum=1))
        declared_material = set(string_list(comparison["changed_material_domains"], "changed_material_domains", minimum=3))
        require(declared_causal == causal, f"direction causal difference is not computed truth: {first_id}, {second_id}")
        require(declared_material == material, f"direction material difference is not computed truth: {first_id}, {second_id}")
        require(len(material & PRIMARY_MATERIAL_DOMAINS) >= 2,
                f"direction pair lacks two primary material differences: {first_id}, {second_id}")
        grounded_material: set[str] = set()
        for domain in material:
            first_values = {
                value for item in prompts_by_direction[first_id]
                for value in prompt_facts[item["prompt_id"]]["grounded_dna"].get(domain, set())
            }
            second_values = {
                value for item in prompts_by_direction[second_id]
                for value in prompt_facts[item["prompt_id"]]["grounded_dna"].get(domain, set())
            }
            if first_values and second_values and {
                normalized_phrase(value) for value in first_values
            } != {normalized_phrase(value) for value in second_values}:
                grounded_material.add(domain)
        grounded_causal = {
            axis for axis in causal
            if axis in {
                value for item in prompts_by_direction[first_id]
                for value in prompt_facts[item["prompt_id"]]["grounded_causal"]
            } and axis in {
                value for item in prompts_by_direction[second_id]
                for value in prompt_facts[item["prompt_id"]]["grounded_causal"]
            }
        }
        computed_skin_swap_interchangeable = not (
            grounded_causal and len(grounded_material & PRIMARY_MATERIAL_DOMAINS) >= 2
        )
        require(comparison["skin_swap_interchangeable"] is computed_skin_swap_interchangeable,
                f"direction skin-swap result disagrees with grounded prompt evidence: {first_id}, {second_id}")
        require(computed_skin_swap_interchangeable is False,
                f"skin-swappable directions cannot both be approved: {first_id}, {second_id}")
        require(comparison["status"] == "PASS", f"direction comparison did not pass: {first_id}, {second_id}")
    require(actual_pairs == expected_pairs,
            f"direction pair coverage mismatch: missing={len(expected_pairs - actual_pairs)}, extra={len(actual_pairs - expected_pairs)}")
    for path_text in markdown_paths:
        path = bounded(root, path_text, exist=True)
        require(path.is_file(), f"prompt Markdown path is not a file: {path_text}")
        require(any(item["markdown_path"] == path_text for item in prompts),
                f"prompt Markdown has no bound prompts: {path_text}")
    return {
        "status": "PASS",
        "product_id": data["product_id"],
        "portfolio_shape": shape,
        "scale_tier": tier,
        "approved_directions": len(approved),
        "prompt_count": len(prompts),
        "markdown_file_count": len(markdown_paths),
        "markdown_paths": sorted(markdown_paths),
        "prompt_by_evidence": prompt_by_evidence,
        "prompt_by_id": prompt_by_id,
    }


def render_markdown(data: dict[str, Any], root: Path, *, origin_source_root: Path | None = None) -> list[Path]:
    if origin_source_root is not None:
        copy_direction_origins(data, origin_source_root, root)
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    direction_titles = {item["direction_id"]: item["title"] for item in data["directions"]}
    for prompt in data["prompts"]:
        grouped[prompt["markdown_path"]].append(prompt)
    outputs: list[Path] = []
    for path_text in data["markdown_files"]:
        path = bounded(root, path_text)
        prompts = grouped.get(path_text, [])
        require(prompts, f"cannot render empty prompt Markdown: {path_text}")
        path.parent.mkdir(parents=True, exist_ok=True)
        lines = [f"# {data['product_id']} Prompt Portfolio", ""]
        current_direction = None
        for prompt in prompts:
            if prompt["direction_id"] != current_direction:
                current_direction = prompt["direction_id"]
                lines.extend([f"## {direction_titles[current_direction]}", ""])
            lines.extend([
                PROMPT_MARKER.format(prompt_id=prompt["prompt_id"]),
                f"### {prompt['prompt_id']} — {prompt['title']}",
                "",
                "```text",
                prompt["canonical_prompt"].strip(),
                "```",
                "",
            ])
        path.write_text("\n".join(lines), encoding="utf-8")
        outputs.append(path)
    return outputs


RELATIONSHIP_SUBJECT_GROUPS = (
    ("guardian reporter", "immune child"), ("immune child", "refuge survivor"),
    ("roadside mechanic", "guardian evacuee", "evacuation child"), ("refuge medic", "injured guardian"),
    ("armed bride", "infected spouse"), ("infected groom", "wedding guest"),
    ("former partner",), ("flower girl",),
    ("prison officer", "scientist inmate"), ("scientist inmate", "officer child"),
    ("purple-haired child", "search hound"), ("search hound", "missing convoy guard"),
)
RELATIONSHIP_LOCATIONS = (
    "abandoned desert fuel station", "damaged convenience-store shelter", "blocked highway service lane",
    "sandstorm evacuation camp", "ruined wedding chapel", "forest manor entrance",
    "broken greenhouse living wing", "wedding chapel cemetery route", "flooded prison transfer yard",
    "collapsed cell-block corridor", "woodland survivor lodge", "mountain convoy ambush road",
)
RELATIONSHIP_ACTIONS = (
    "redirects infected pursuers away from the child", "repairs the refuge barricade before the shelter door fails",
    "shares the final medicine dose with a wounded guardian", "guides the evacuation group through a blocked service lane",
    "restrains the infected groom during a recognition pause", "seals the manor windows before the night siege",
    "recovers the torn wedding portrait from the chapel aisle", "moves the flower girl behind a defensible stone bench",
    "unlocks the inmate's restraints during the convoy breach", "uses mutation research to identify a safe escape interval",
    "tracks the officer child through the smoke", "converts the abandoned lodge into a field laboratory",
)
RELATIONSHIP_CONSEQUENCES = (
    "the child reaches cover while the infected pack changes route", "the refuge advances from exposed shell to defended safehouse",
    "the guardian survives but the medicine reserve becomes empty", "the convoy reaches the next shelter with one route permanently lost",
    "the groom recognizes the bride and stops the attack for one moment", "the manor becomes defensible while the outside swarm gathers",
    "the wedding relationship clue opens a rescue decision instead of a kill objective", "the bride's wedding escape closes as the groom's recognition ends",
    "custody changes into mutual rescue as the prison yard collapses", "the research warning reveals a larger mutation approaching",
    "the missing child is found and the officer must trust the inmate", "the lodge unlocks research work while attracting armed hunters",
)
RELATIONSHIP_OBJECTS = (
    "hand-painted evacuation arrow", "child-sized evacuation backpack", "improvised fuel siphon",
    "blood-marked medical pouch", "desert refuge route marker", "torn wedding veil",
    "cracked wedding portrait", "manor barricade timber", "greenhouse water barrel",
    "wedding ring token", "rusted prison restraint", "research sample satchel",
    "research toy badge", "search hound scent cloth", "convoy radio handset", "lodge family photograph",
)

SYSTEM_SUBJECT_GROUPS = (
    ("Roman surveyor", "displaced worker"), ("shield captain",),
    ("bathhouse steward",), ("vineyard keeper",),
    ("caravan medic", "wounded scout"), ("young courier",),
    ("stone mason",), ("tavern keeper", "first rival informant", "second rival informant"),
    ("workshop engineer",), ("veteran spearman", "frightened resident"),
    ("merchant widow",), ("senator's clerk",),
    ("villa steward",), ("arena marshal", "reserve infantryman"),
    ("harbor quartermaster",), ("temple archivist",),
)
SYSTEM_LOCATIONS = (
    "terraced Roman forum", "breached legion gate", "steam-filled public bathhouse",
    "hillside vineyard press", "storm-damaged caravan camp", "collapsed aqueduct junction",
    "half-restored governor villa", "crowded riverside tavern", "ash-covered merge workshop",
    "mountain watchtower road", "granary counting hall", "subterranean cistern chamber",
    "coastal victory market", "arena formation yard", "marble hero archive", "walled expedition harbor",
)
SYSTEM_ACTIONS = (
    "assigns builders to restore the forum's blocked production lane", "deploys shield units to cover an exposed healer",
    "reroutes clean water away from a contaminated bath", "harvests medicine while protecting the only seed stock",
    "triages scouts before the expedition timer expires", "marks a safe path across a collapsing district map",
    "rebuilds the missing aqueduct segment under labor pressure", "separates two informants before either signals the raiders",
    "combines damaged tools into a working construction crane", "forms a defensive line around fleeing residents",
    "opens emergency grain stores against a corrupt decree", "connects the forged order to the commander who benefits",
    "fulfills a furniture order to unlock the villa's next room", "moves reserve infantry into a counterattack formation",
    "converts battle loot into equipment for the selected hero", "trades faction favor for access to the sealed harbor route",
)
SYSTEM_CONSEQUENCES = (
    "the forum resumes production and feeds the next city upgrade", "the battle line stabilizes and a counterattack lane opens",
    "the contamination meter falls as citizens return to service", "the settlement gains medicine but exposes its food reserve",
    "the expedition continues while the infirmary queue becomes active", "the map reveals a district and removes a false destination",
    "the aqueduct feeds the villa and enables its next upgrade state", "one testimony becomes trustworthy and the other triggers an ambush",
    "the workshop completes its order and transfers progress to the city", "the civilians escape and the veteran becomes recruitable",
    "public approval rises while the treasury loses emergency stock", "the command chain fractures and a political event begins",
    "the restored room starts earning resources for later construction", "the enemy flank breaks and a victory reward becomes available",
    "the hero power rises and the next battle node unlocks", "the harbor opens and launches a new regional expedition",
)
SYSTEM_OBJECTS = (
    "Roman survey tripod", "bronze legion signal horn", "marble bath temperature gauge",
    "grape press counterweight", "caravan medicine ledger", "wax-sealed district map",
    "aqueduct sluice wheel", "villa furniture order board", "tavern witness token",
    "merge workshop tool tray", "shield formation ground marker", "granary ration abacus",
    "cistern contamination float", "victory market offer chest", "hero equipment socket board",
    "harbor expedition seal", "faction favor tablet", "arena reserve banner",
    "construction labor token", "restoration progress plaque",
)
MECHANISM_POOL = (
    "asymmetric silhouette contrast", "foreground route obstruction", "midground cause-and-action coupling",
    "background consequence landmark", "functional prop scale cue", "material wear hierarchy",
    "directional crisis lighting", "controlled crowd density", "relationship distance staging",
    "state change before-and-after cue", "topology-preserving landmark placement", "single interaction focal point",
    "threat vector eye-line", "resource scarcity grouping", "readable traversal negative space",
    "system feedback color boundary", "identity-lock costume accent", "cause-to-consequence depth order",
    "world-specific tool affordance", "primary-versus-secondary value separation", "safe-zone boundary rhythm",
    "event timer pressure cue", "unit-role scale ladder", "screen-to-world continuity anchor",
)
CASE_DIRECTION_PROFILES = (
    {
        "title": "Protected Child Exodus", "driver": "RELATIONSHIP_DRIVEN",
        "causal": {
            "player_agent": "guardian reporter choosing routes for a vulnerable child",
            "relationship_engine": "protection bond that redirects every threat and resource choice",
            "world_rule": "infected creatures avoid the child but pursue everyone protecting her",
            "core_loop": "scavenge shelter escort and repair around a moving dependent",
        },
        "dna": {
            "character_ecology": ["guardian reporter and immune child pair", "mechanic medic and survivor support circle"],
            "space_ecology": ["fuel station refuge and desert migration corridor", "damaged convenience shelter with locked service lanes"],
            "threat_ecology": ["child-avoiding infected pursuit pack", "oversized roadside mutation breaking the safe perimeter"],
            "resource_prop_ecology": ["evacuation backpack and improvised fuel tools", "medical cache and repair-material bundle"],
            "event_families": ["protection choice under converging pursuit", "shelter repair interrupted by redirected infection"],
            "state_chains": ["exposed refuge to barricaded safehouse chain", "separated guardian to reunited escort chain"],
            "system_screen_families": ["escort route decision screen", "shelter merge and repair screen"],
            "delivery_uses": ["relationship premise storyboard", "guardian-and-child campaign key visual"],
        },
    },
    {
        "title": "Infected Wedding Bond", "driver": "RELATIONSHIP_DRIVEN",
        "causal": {
            "player_agent": "bride balancing rescue loyalty against settlement survival",
            "relationship_engine": "marriage bond that turns the primary monster into a recoverable loved one",
            "world_rule": "emotional recognition interrupts infection aggression for brief windows",
            "core_loop": "investigate restrain restore and defend a manor around an infected spouse",
        },
        "dna": {
            "character_ecology": ["armed bride former partner and infected groom triangle", "flower child survivor and manor support group"],
            "space_ecology": ["ruined chapel combat aisle", "forest manor restoration rooms and grounds"],
            "threat_ecology": ["ceremonial infected groom with recognition pauses", "wedding guest swarm crossing chapel benches"],
            "resource_prop_ecology": ["torn portrait wedding ring and barricade timber", "garden seed water barrel and manor repair kit"],
            "event_families": ["wedding transformation and emergency extraction", "night siege triggered by remembered identity"],
            "state_chains": ["ceremony to infection to recognition chain", "broken manor to defended household chain"],
            "system_screen_families": ["relationship choice dialogue screen", "manor restoration order screen"],
            "delivery_uses": ["romantic horror storyboard", "bride-versus-groom loading key visual"],
        },
    },
    {
        "title": "Escort Duty Reversal", "driver": "RELATIONSHIP_DRIVEN",
        "causal": {
            "player_agent": "prison officer depending on the inmate he was ordered to contain",
            "relationship_engine": "custody reversal that converts suspicion into mutual rescue",
            "world_rule": "the inmate's research can predict mutations but revealing it attracts hunters",
            "core_loop": "escort investigate build trust and fortify a survivor lodge",
        },
        "dna": {
            "character_ecology": ["officer scientist inmate purple-haired child and search hound team", "prison bruiser and feral inmate threat ladder"],
            "space_ecology": ["collapsed transfer prison yard", "woodland survivor lodge with research room"],
            "threat_ecology": ["orange-uniform prison mutation", "cell-block infected pack following alarm noise"],
            "resource_prop_ecology": ["restraint key research satchel and scent cloth", "lodge food barrel field lab and radio parts"],
            "event_families": ["convoy breach and custody reversal", "research reveal during lodge defense"],
            "state_chains": ["restrained suspect to trusted scientist chain", "abandoned lodge to defended field laboratory chain"],
            "system_screen_families": ["escort trust decision screen", "lodge operations and research screen"],
            "delivery_uses": ["custody reversal storyboard", "three-person prison escape key visual"],
        },
    },
)

SYSTEM_DIRECTION_PROFILE = {
    "title": "Roman Restoration Network", "driver": "SYSTEM_DRIVEN",
    "causal": {
        "player_agent": "settlement governor coordinating workers heroes and military squads",
        "relationship_engine": "citizen trust and faction obligations redistribute labor and rewards",
        "world_rule": "every restored facility unlocks resources for a different downstream system",
        "core_loop": "merge build assign explore battle collect and reinvest across the city",
    },
    "dna": {
        "character_ecology": ["governor worker resident hero and legion unit hierarchy", "merchant steward scout and political rival network"],
        "space_ecology": ["forum villa bathhouse tavern vineyard and granary topology", "adventure districts linked back to the evolving main city"],
        "threat_ecology": ["raider legion and arena opponent escalation", "fire collapse contamination and supply-crisis hazards"],
        "resource_prop_ecology": ["merge tools construction crates grain wine and marble economy", "hero equipment formation tokens and offer rewards"],
        "event_families": ["facility restoration feeding city progression", "expedition battle reward returning to hero growth"],
        "state_chains": ["ruin repair furnishing operation and upgrade chain", "locked route deployment combat victory and reward chain"],
        "system_screen_families": ["main city merge adventure formation hero and offer surfaces", "facility detail staffing order and completion surfaces"],
        "delivery_uses": ["cross-system product flow board", "Roman city progression campaign packaging"],
    },
}

DOMAIN_COUNTING = {
    "character_ecology": ("NEW_ASSET", ["identity"]),
    "space_ecology": ("NEW_ASSET", ["core_topology"]),
    "threat_ecology": ("NEW_EVENT", ["cause", "action", "consequence"]),
    "resource_prop_ecology": ("NEW_ASSET", ["functional_role"]),
    "event_families": ("NEW_EVENT", ["cause", "action", "consequence"]),
    "state_chains": ("NEW_STATE", ["entry_trigger", "visible_delta", "gameplay_meaning"]),
    "system_screen_families": ("NEW_SCREEN", ["input", "state_change", "feedback", "result"]),
    "delivery_uses": ("NEW_USE", ["delivery_purpose"]),
}


def _fixture_prompt(index: int, direction: dict[str, Any], markdown_path: str, domain: str,
                    *, rich_semantics: bool) -> dict[str, Any]:
    direction_id = direction["direction_id"]
    short_id = direction_id.removeprefix("DIRECTION-")
    prompt_id = f"PROMPT-{short_id}-{index:03d}"
    evidence_id = f"EVID-{short_id}-{index:03d}"
    graph_id = f"ASSET-{short_id}-{index:03d}"
    coverage_id = f"COV-{short_id}-{index:03d}"
    direction_number = int(short_id.removeprefix("D")) if short_id.removeprefix("D").isdigit() else 1
    zero = index - 1 + (direction_number - 1) * 64
    if direction["expansion_driver"] == "SYSTEM_DRIVEN":
        subject_groups, locations = SYSTEM_SUBJECT_GROUPS, SYSTEM_LOCATIONS
        actions, consequences, object_pool = SYSTEM_ACTIONS, SYSTEM_CONSEQUENCES, SYSTEM_OBJECTS
    else:
        segment = direction_number - 1
        subject_groups = RELATIONSHIP_SUBJECT_GROUPS[segment * 4:(segment + 1) * 4]
        locations = RELATIONSHIP_LOCATIONS[segment * 4:(segment + 1) * 4]
        actions = RELATIONSHIP_ACTIONS[segment * 4:(segment + 1) * 4]
        consequences = RELATIONSHIP_CONSEQUENCES[segment * 4:(segment + 1) * 4]
        object_ranges = ((0, 5), (5, 10), (10, 16))
        object_start, object_end = object_ranges[segment]
        object_pool = RELATIONSHIP_OBJECTS[object_start:object_end]
    identities = subject_groups[zero % len(subject_groups)]
    subject_entities = [
        {
            "entity_id": f"SUBJECT-{entity_index:02d}",
            "entity_type": "ANIMAL" if identity == "search hound" else "PERSON",
            "identity": identity,
            "visible_count": 1,
        }
        for entity_index, identity in enumerate(identities, start=1)
    ]
    subject = " + ".join(identities)
    location = locations[(zero // len(subject_groups)) % len(locations)]
    action = actions[(zero * 5 + zero // 7) % len(actions)]
    consequence = consequences[(zero * 7 + zero // 5) % len(consequences)]
    objects = [object_pool[(zero * 3) % len(object_pool)], object_pool[(zero * 3 + 7) % len(object_pool)]]
    mechanism_targets = [*identities, location, *objects, "foreground route", "midground action zone", "background consequence zone"]
    mechanisms = []
    for offset in range(8):
        operation = MECHANISM_POOL[(zero * 5 + offset) % len(MECHANISM_POOL)]
        target = mechanism_targets[(zero + offset) % len(mechanism_targets)]
        result_terms = sorted(OPERATION_RESULT_REQUIREMENTS[operation])
        mechanisms.append({
            "operation": operation,
            "target": target,
            "visible_result": (
                f"{operation} makes {target} produce a concrete {result_terms[0]} and {result_terms[1]} reading "
                f"at the intended viewing scale"
            ),
        })
    dna_anchor = direction["material_dna"][domain][zero % len(direction["material_dna"][domain])]
    causal_axis = CAUSAL_AXES[zero % len(CAUSAL_AXES)]
    causal_value = direction["causal_signature"][causal_axis]
    purpose = f"prove how {subject} changes the playable situation inside {location}"
    primary_read = f"{action} changing the play state"
    semantic_delta = f"Introduces {subject} at {location}, where {action} causes {consequence}."
    preserve = [direction["title"], dna_anchor]
    exclusions = ["unrelated secondary storyline", "generic fantasy decoration"]
    must_show = [subject, action, consequence]
    body = "\n".join((
        f"Purpose: {purpose}",
        f"Subject identity: {subject}",
        f"Subject entities: {serialize_subject_entities(subject_entities)}",
        f"Location identity: {location}",
        f"Required action: {action}",
        f"Visible consequence: {consequence}",
        f"Direction: {direction['title']}",
        f"Direction causality: {causal_value}",
        f"Material DNA: {dna_anchor}",
        f"Primary read: {primary_read}",
        f"Pose or action: {action}",
        f"World-specific objects: {serialize_list(objects, 'fixture.world_specific_objects')}",
        f"Must show: {serialize_list(must_show, 'fixture.must_show')}",
        f"Visual mechanisms: {serialize_mechanisms(mechanisms)}",
        f"Must preserve: {serialize_list(preserve, 'fixture.must_preserve')}",
        f"Must not add: {serialize_list(exclusions, 'fixture.must_not_add')}",
        f"Semantic delta: {semantic_delta}",
        "Aspect ratio: 16:9",
        f"Subject count: {len(subject_entities)}",
        "Camera: three-quarter gameplay camera",
        "Framing: full action-and-site framing",
    ))
    counting_class, semantic_axes = DOMAIN_COUNTING[domain] if rich_semantics else ("NEW_ASSET", ["functional_role"])
    return {
        "prompt_id": prompt_id, "evidence_id": evidence_id, "direction_id": direction_id,
        "markdown_path": markdown_path, "title": f"{subject.capitalize()} — {action} at {location}",
        "canonical_prompt": body, "prompt_sha256": sha_text(body), "graph_refs": [graph_id],
        "coverage_refs": [coverage_id], "material_domains": [domain], "counting_class": counting_class,
        "semantic_axes": semantic_axes, "presentation_only_axes": [], "semantic_delta": semantic_delta,
        "content_anchors": {
            "subject_identity": subject, "subject_entities": subject_entities, "location_identity": location, "action": action,
            "visible_consequence": consequence, "world_specific_objects": objects,
        },
        "image_contract": {
            "purpose": purpose, "aspect_ratio": "16:9", "primary_read": primary_read,
            "subject_count": len(subject_entities),
            "camera": "three-quarter gameplay camera", "framing": "full action-and-site framing",
            "pose_or_action": action, "must_show": must_show,
            "must_preserve": preserve, "must_not_add": exclusions,
        },
        "visual_mechanisms": mechanisms, "must_preserve": preserve, "must_not_add": exclusions,
    }


def _fixture_direction(index: int, *, driver: str, capacity: int, single_system: bool) -> dict[str, Any]:
    profile = SYSTEM_DIRECTION_PROFILE if single_system else CASE_DIRECTION_PROFILES[index - 1]
    direction_id = f"DIRECTION-D{index}"
    if single_system:
        subject_groups = SYSTEM_SUBJECT_GROUPS
        locations, actions = SYSTEM_LOCATIONS, SYSTEM_ACTIONS
        consequences, objects = SYSTEM_CONSEQUENCES, SYSTEM_OBJECTS
    else:
        segment = index - 1
        subject_groups = RELATIONSHIP_SUBJECT_GROUPS[segment * 4:(segment + 1) * 4]
        locations = RELATIONSHIP_LOCATIONS[segment * 4:(segment + 1) * 4]
        actions = RELATIONSHIP_ACTIONS[segment * 4:(segment + 1) * 4]
        consequences = RELATIONSHIP_CONSEQUENCES[segment * 4:(segment + 1) * 4]
        object_ranges = ((0, 5), (5, 10), (10, 16))
        object_start, object_end = object_ranges[segment]
        objects = RELATIONSHIP_OBJECTS[object_start:object_end]
    return {
        "direction_id": direction_id, "title": profile["title"], "status": "APPROVED",
        "expansion_driver": profile["driver"] if driver else profile["driver"],
        "causal_signature": json.loads(json.dumps(profile["causal"])),
        "material_dna": json.loads(json.dumps(profile["dna"])),
        "material_fertility": {"supported_domains": len(MATERIAL_DOMAINS), "prompt_capacity": capacity, "status": "PASS"},
        "anchor_lexicon": {
            "subject_entities": list(dict.fromkeys(identity for group in subject_groups for identity in group)),
            "locations": list(locations), "actions": list(actions), "consequences": list(consequences),
            "world_objects": list(objects),
        },
    }


def write_direction_origin(direction: dict[str, Any], root: Path) -> None:
    source_id = f"DIRECTION-ORIGIN-{direction['direction_id'].removeprefix('DIRECTION-')}"
    path_text = f"work/concept-lab/direction-origins/{direction['direction_id'].lower()}.json"
    payload = {
        "schema_version": "sicza.game-concept.direction-origin.v1",
        "source_id": source_id,
        "authority": "FROZEN",
        "direction_id": direction["direction_id"],
        "title": direction["title"],
        "causal_signature": direction["causal_signature"],
        "material_dna": direction["material_dna"],
        "anchor_lexicon": direction["anchor_lexicon"],
    }
    path = bounded(root, path_text)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    direction["origin_evidence"] = {"source_id": source_id, "path": path_text, "sha256": sha_file(path)}


def copy_direction_origins(data: dict[str, Any], source_root: Path, target_root: Path) -> None:
    for direction in data["directions"]:
        path_text = direction["origin_evidence"]["path"]
        source = bounded(source_root, path_text, exist=True)
        target = bounded(target_root, path_text)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(source.read_bytes())


def build_selftest_fixture(root: Path, *, count: int, direction_count: int, shape: str,
                           rich_semantics: bool = False) -> tuple[dict[str, Any], set[str], dict[str, dict[str, Any]]]:
    require(direction_count == 1 or 3 <= direction_count <= len(CASE_DIRECTION_PROFILES),
            "selftest fixture supports one system direction or three relationship directions")
    directions = [
        _fixture_direction(
            index + 1, driver="RELATIONSHIP_DRIVEN" if direction_count > 1 else "SYSTEM_DRIVEN",
            capacity=count, single_system=direction_count == 1,
        )
        for index in range(direction_count)
    ]
    for direction in directions:
        write_direction_origin(direction, root)
    markdown_files = [f"work/final/prompts/{item['direction_id'].lower()}.md" for item in directions]
    prompts: list[dict[str, Any]] = []
    graph_ids: set[str] = set()
    coverage: dict[str, dict[str, Any]] = {}
    base, remainder = divmod(count, direction_count)
    global_index = 0
    for direction_index, direction in enumerate(directions):
        owned = base + (1 if direction_index < remainder else 0)
        for local_index in range(1, owned + 1):
            global_index += 1
            domain = MATERIAL_DOMAINS[(local_index - 1) % len(MATERIAL_DOMAINS)]
            prompt = _fixture_prompt(
                local_index, direction, markdown_files[direction_index], domain, rich_semantics=rich_semantics
            )
            prompts.append(prompt)
            graph_ids.update(prompt["graph_refs"])
            coverage[prompt["coverage_refs"][0]] = {
                "evidence_kind": "CANONICAL_PROMPT", "evidence_refs": [prompt["evidence_id"]],
                "counting_class": prompt["counting_class"],
            }
    comparisons = []
    by_id = {item["direction_id"]: item for item in directions}
    for first, second in itertools.combinations(sorted(by_id), 2):
        causal, material = computed_pair_difference(by_id[first], by_id[second])
        comparisons.append({
            "direction_a": first, "direction_b": second,
            "changed_causal_axes": sorted(causal), "changed_material_domains": sorted(material),
            "skin_swap_interchangeable": False, "status": "PASS",
        })
    data = {
        "schema_version": SCHEMA_VERSION,
        "product_id": "prompt-portfolio-selftest",
        "producer_id": "prompt-portfolio-selftest-producer",
        "portfolio_shape": shape,
        "scale_tier": "CASE_SCALE",
        "markdown_files": markdown_files,
        "directions": directions,
        "direction_comparisons": comparisons,
        "prompts": prompts,
    }
    render_markdown(data, root)
    return data, graph_ids, coverage


def selftest() -> dict[str, str]:
    results: dict[str, str] = {}
    with tempfile.TemporaryDirectory(prefix="sicza-prompt-portfolio-") as directory:
        root = Path(directory)
        relationship_root = root / "relationship"
        system_root = root / "system"
        relationship, relationship_graph_ids, relationship_coverage = build_selftest_fixture(
            relationship_root, count=52, direction_count=3, shape="MULTI_DIRECTION_DIVERGENCE",
            rich_semantics=True,
        )
        result = validate_portfolio(
            relationship, relationship_root,
            graph_ids=relationship_graph_ids, coverage_slots=relationship_coverage,
        )
        require(result["prompt_count"] == 52, "relationship case did not validate 52 prompts")
        results["relationship_case_52_case_derived_markdown_prompts"] = "PASS"
        relationship_text = "\n".join(item["canonical_prompt"].casefold() for item in relationship["prompts"])
        require(not any(term in relationship_text for term in (
            "roman surveyor", "legion gate", "public bathhouse", "aqueduct", "granary", "arena formation", "expedition harbor",
        )), "relationship prompt fixture is contaminated by the Roman system case")
        object_ranges = ((0, 5), (5, 10), (10, 16))
        for direction_index, direction in enumerate(relationship["directions"]):
            allowed_subjects = {
                " + ".join(group)
                for group in RELATIONSHIP_SUBJECT_GROUPS[direction_index * 4:(direction_index + 1) * 4]
            }
            allowed_locations = set(RELATIONSHIP_LOCATIONS[direction_index * 4:(direction_index + 1) * 4])
            allowed_actions = set(RELATIONSHIP_ACTIONS[direction_index * 4:(direction_index + 1) * 4])
            allowed_consequences = set(RELATIONSHIP_CONSEQUENCES[direction_index * 4:(direction_index + 1) * 4])
            object_start, object_end = object_ranges[direction_index]
            allowed_objects = set(RELATIONSHIP_OBJECTS[object_start:object_end])
            owned = [item for item in relationship["prompts"] if item["direction_id"] == direction["direction_id"]]
            require(all(item["content_anchors"]["subject_identity"] in allowed_subjects for item in owned),
                    f"relationship direction subject vocabulary contamination: {direction['direction_id']}")
            require(all(item["content_anchors"]["location_identity"] in allowed_locations for item in owned),
                    f"relationship direction location vocabulary contamination: {direction['direction_id']}")
            require(all(item["content_anchors"]["action"] in allowed_actions for item in owned),
                    f"relationship direction action vocabulary contamination: {direction['direction_id']}")
            require(all(item["content_anchors"]["visible_consequence"] in allowed_consequences for item in owned),
                    f"relationship direction consequence vocabulary contamination: {direction['direction_id']}")
            require(all(set(item["content_anchors"]["world_specific_objects"]) <= allowed_objects for item in owned),
                    f"relationship direction object vocabulary contamination: {direction['direction_id']}")
        results["relationship_case_vocabulary_isolated"] = "PASS"
        system, system_graph_ids, system_coverage = build_selftest_fixture(
            system_root, count=146, direction_count=1, shape="SINGLE_DIRECTION_DEPTH",
            rich_semantics=True,
        )
        result = validate_portfolio(
            system, system_root, graph_ids=system_graph_ids, coverage_slots=system_coverage,
        )
        require(result["prompt_count"] == 146, "system case did not validate 146 prompts")
        results["system_case_146_case_derived_markdown_prompts"] = "PASS"
        system_text = "\n".join(item["canonical_prompt"].casefold() for item in system["prompts"])
        require(not any(term in system_text for term in (
            "immune child", "infected groom", "wedding chapel", "scientist inmate", "search hound", "fuel station",
        )), "system prompt fixture is contaminated by the relationship case")
        require(all(item["content_anchors"]["subject_identity"] in {
            " + ".join(group) for group in SYSTEM_SUBJECT_GROUPS
        } for item in system["prompts"]),
                "system prompt fixture uses a foreign subject vocabulary")
        require(all(item["content_anchors"]["location_identity"] in set(SYSTEM_LOCATIONS) for item in system["prompts"]),
                "system prompt fixture uses a foreign location vocabulary")
        require(all(item["content_anchors"]["action"] in set(SYSTEM_ACTIONS) for item in system["prompts"]),
                "system prompt fixture uses a foreign action vocabulary")
        require(all(item["content_anchors"]["visible_consequence"] in set(SYSTEM_CONSEQUENCES) for item in system["prompts"]),
                "system prompt fixture uses a foreign consequence vocabulary")
        require(all(set(item["content_anchors"]["world_specific_objects"]) <= set(SYSTEM_OBJECTS) for item in system["prompts"]),
                "system prompt fixture uses a foreign object vocabulary")
        results["system_case_vocabulary_isolated"] = "PASS"
        broken = json.loads(json.dumps(relationship))
        broken["prompts"][0]["canonical_prompt"] += " TBD"
        broken["prompts"][0]["prompt_sha256"] = sha_text(broken["prompts"][0]["canonical_prompt"])
        try:
            validate_portfolio(broken, relationship_root, graph_ids=relationship_graph_ids, coverage_slots=None)
        except PromptPortfolioError:
            results["placeholder_prompt"] = "BLOCK"
        else:
            raise PromptPortfolioError("placeholder prompt unexpectedly passed")
        named_placeholder = json.loads(json.dumps(relationship))
        first_prompt = named_placeholder["prompts"][0]
        original_subject = first_prompt["content_anchors"]["subject_identity"]
        first_prompt["canonical_prompt"] = first_prompt["canonical_prompt"].replace(original_subject, "{CHARACTER_NAME}")
        first_prompt["prompt_sha256"] = sha_text(first_prompt["canonical_prompt"])
        named_placeholder_root = root / "named-placeholder"
        render_markdown(named_placeholder, named_placeholder_root, origin_source_root=relationship_root)
        try:
            validate_portfolio(named_placeholder, named_placeholder_root, graph_ids=None, coverage_slots=None)
        except PromptPortfolioError:
            results["named_placeholder_prompt"] = "BLOCK"
        else:
            raise PromptPortfolioError("named placeholder prompt unexpectedly passed")
        duplicate = json.loads(json.dumps(relationship))
        duplicate["prompts"][1]["canonical_prompt"] = duplicate["prompts"][0]["canonical_prompt"]
        duplicate["prompts"][1]["prompt_sha256"] = duplicate["prompts"][0]["prompt_sha256"]
        duplicate_root = root / "duplicate"
        render_markdown(duplicate, duplicate_root, origin_source_root=relationship_root)
        try:
            validate_portfolio(duplicate, duplicate_root, graph_ids=None, coverage_slots=None)
        except PromptPortfolioError:
            results["duplicate_prompt"] = "BLOCK"
        else:
            raise PromptPortfolioError("duplicate prompt unexpectedly passed")
        skin = json.loads(json.dumps(relationship))
        skin["directions"][1]["causal_signature"] = json.loads(json.dumps(skin["directions"][0]["causal_signature"]))
        skin["directions"][1]["material_dna"] = json.loads(json.dumps(skin["directions"][0]["material_dna"]))
        try:
            validate_portfolio(skin, relationship_root, graph_ids=None, coverage_slots=None)
        except PromptPortfolioError:
            results["skin_swap_direction"] = "BLOCK"
        else:
            raise PromptPortfolioError("skin-swappable directions unexpectedly passed")
        template_clone = json.loads(json.dumps(relationship))
        for index, prompt in enumerate(template_clone["prompts"], start=1):
            prompt["canonical_prompt"] = (
                f"Create direction {prompt['direction_id']} color blue variant {index}. "
                "Show one generic character in one generic location performing one generic action with one generic consequence. "
                "Use silhouette separation, foreground route cue, midground interaction, background consequence, "
                "functional prop scale, material hierarchy, directional light, and controlled density. "
                "Preserve direction identity and do not add unrelated secondary events."
            )
            prompt["prompt_sha256"] = sha_text(prompt["canonical_prompt"])
        template_root = root / "template-clone"
        render_markdown(template_clone, template_root, origin_source_root=relationship_root)
        try:
            validate_portfolio(template_clone, template_root, graph_ids=None, coverage_slots=None)
        except PromptPortfolioError:
            results["number_color_template_clone"] = "BLOCK"
        else:
            raise PromptPortfolioError("number/color template clone unexpectedly passed")
        contract_drift = json.loads(json.dumps(relationship))
        drift_prompt = contract_drift["prompts"][0]
        drift_action = drift_prompt["content_anchors"]["action"]
        drift_prompt["canonical_prompt"] = drift_prompt["canonical_prompt"].replace(drift_action, "performs an unspecified task")
        drift_prompt["prompt_sha256"] = sha_text(drift_prompt["canonical_prompt"])
        drift_root = root / "contract-drift"
        render_markdown(contract_drift, drift_root, origin_source_root=relationship_root)
        try:
            validate_portfolio(contract_drift, drift_root, graph_ids=None, coverage_slots=None)
        except PromptPortfolioError:
            results["prompt_contract_semantic_drift"] = "BLOCK"
        else:
            raise PromptPortfolioError("prompt contract semantic drift unexpectedly passed")
        for field, changed in (
            ("camera", "extreme macro first-person camera"),
            ("framing", "isolated face crop"),
            ("aspect_ratio", "1:1"),
            ("subject_count", 99),
        ):
            scalar_drift = json.loads(json.dumps(relationship))
            scalar_drift["prompts"][0]["image_contract"][field] = changed
            try:
                validate_portfolio(scalar_drift, relationship_root, graph_ids=None, coverage_slots=None)
            except PromptPortfolioError:
                results[f"image_contract_{field}_drift"] = "BLOCK"
            else:
                raise PromptPortfolioError(f"image contract {field} drift unexpectedly passed")
        swapped_fields = json.loads(json.dumps(relationship))
        swapped_prompt = swapped_fields["prompts"][0]
        swapped_prompt["content_anchors"]["subject_identity"] = swapped_prompt["content_anchors"]["location_identity"]
        swapped_prompt["content_anchors"]["subject_entities"] = [{
            "entity_id": "SUBJECT-01", "entity_type": "STRUCTURE",
            "identity": swapped_prompt["content_anchors"]["location_identity"], "visible_count": 1,
        }]
        swapped_prompt["semantic_delta"] = swapped_prompt["content_anchors"]["visible_consequence"]
        swapped_prompt["image_contract"]["must_show"] = [
            swapped_prompt["must_not_add"][0], *swapped_prompt["content_anchors"]["world_specific_objects"],
        ]
        swapped_prompt["must_not_add"] = [swapped_prompt["content_anchors"]["subject_identity"]]
        swapped_prompt["image_contract"]["must_not_add"] = list(swapped_prompt["must_not_add"])
        try:
            validate_portfolio(swapped_fields, relationship_root, graph_ids=None, coverage_slots=None)
        except PromptPortfolioError:
            results["cross_field_semantic_swap"] = "BLOCK"
        else:
            raise PromptPortfolioError("cross-field semantic swap unexpectedly passed")
        fake_mechanisms = json.loads(json.dumps(relationship))
        mechanism_prompt = fake_mechanisms["prompts"][0]
        old_mechanisms = mechanism_prompt["visual_mechanisms"]
        anchor = mechanism_prompt["content_anchors"]
        statements = [
            anchor["subject_identity"], anchor["location_identity"], anchor["action"],
            anchor["visible_consequence"], *anchor["world_specific_objects"],
            mechanism_prompt["must_preserve"][0], mechanism_prompt["must_not_add"][0],
        ]
        new_mechanisms = [
            {"operation": statement, "target": anchor["location_identity"],
             "visible_result": f"{anchor['location_identity']} stays readable in the frame"}
            for statement in statements
        ]
        mechanism_prompt["visual_mechanisms"] = new_mechanisms
        mechanism_prompt["canonical_prompt"] = replace_canonical_section(
            mechanism_prompt["canonical_prompt"], "Visual mechanisms", serialize_mechanisms(new_mechanisms)
        )
        mechanism_prompt["prompt_sha256"] = sha_text(mechanism_prompt["canonical_prompt"])
        fake_mechanism_root = root / "fake-mechanisms"
        render_markdown(fake_mechanisms, fake_mechanism_root, origin_source_root=relationship_root)
        try:
            validate_portfolio(fake_mechanisms, fake_mechanism_root, graph_ids=None, coverage_slots=None)
        except PromptPortfolioError:
            results["non_visual_mechanism_substitution"] = "BLOCK"
        else:
            raise PromptPortfolioError("non-visual mechanism substitution unexpectedly passed")
        subject_count_mismatch = json.loads(json.dumps(relationship))
        count_prompt = subject_count_mismatch["prompts"][0]
        old_count = count_prompt["image_contract"]["subject_count"]
        require(old_count > 1, "subject-count selftest requires a multi-entity prompt")
        count_prompt["image_contract"]["subject_count"] = 1
        count_prompt["canonical_prompt"] = count_prompt["canonical_prompt"].replace(
            f"Subject count: {old_count}", "Subject count: 1"
        )
        count_prompt["prompt_sha256"] = sha_text(count_prompt["canonical_prompt"])
        subject_count_root = root / "subject-count-mismatch"
        render_markdown(subject_count_mismatch, subject_count_root, origin_source_root=relationship_root)
        try:
            validate_portfolio(subject_count_mismatch, subject_count_root, graph_ids=None, coverage_slots=None)
        except PromptPortfolioError:
            results["subject_count_entity_mismatch"] = "BLOCK"
        else:
            raise PromptPortfolioError("subject_count/entity mismatch unexpectedly passed")
        hidden_label = json.loads(json.dumps(relationship))
        hidden_prompt = hidden_label["prompts"][0]
        hidden_camera = "extreme macro first-person camera"
        hidden_prompt["image_contract"]["camera"] = hidden_camera
        hidden_prompt["must_not_add"][0] += f" Camera: {hidden_camera}"
        hidden_prompt["image_contract"]["must_not_add"] = list(hidden_prompt["must_not_add"])
        hidden_prompt["canonical_prompt"] = replace_canonical_section(
            hidden_prompt["canonical_prompt"], "Must not add",
            serialize_list(hidden_prompt["must_not_add"], "hidden_label.must_not_add"),
        )
        hidden_prompt["prompt_sha256"] = sha_text(hidden_prompt["canonical_prompt"])
        hidden_root = root / "hidden-label"
        render_markdown(hidden_label, hidden_root, origin_source_root=relationship_root)
        try:
            validate_portfolio(hidden_label, hidden_root, graph_ids=None, coverage_slots=None)
        except PromptPortfolioError:
            results["label_hidden_in_other_field"] = "BLOCK"
        else:
            raise PromptPortfolioError("authority label hidden in another field unexpectedly passed")
        lowercase_hidden = json.loads(json.dumps(relationship))
        lowercase_prompt = lowercase_hidden["prompts"][0]
        lowercase_prompt["must_not_add"][0] += " camera: extreme macro first-person camera"
        lowercase_prompt["image_contract"]["must_not_add"] = list(lowercase_prompt["must_not_add"])
        lowercase_prompt["canonical_prompt"] = replace_canonical_section(
            lowercase_prompt["canonical_prompt"], "Must not add",
            serialize_list(lowercase_prompt["must_not_add"], "lowercase_hidden.must_not_add"),
        )
        lowercase_prompt["prompt_sha256"] = sha_text(lowercase_prompt["canonical_prompt"])
        lowercase_root = root / "lowercase-hidden-label"
        render_markdown(lowercase_hidden, lowercase_root, origin_source_root=relationship_root)
        try:
            validate_portfolio(lowercase_hidden, lowercase_root, graph_ids=None, coverage_slots=None)
        except PromptPortfolioError:
            results["casefold_hidden_authority_label"] = "BLOCK"
        else:
            raise PromptPortfolioError("casefold authority label hidden in another field unexpectedly passed")
        for test_name, disguised_label in (
            ("default_ignorable_hidden_authority_label", "ca\u200bmera:"),
            ("confusable_hidden_authority_label", "\u0441amera:"),
        ):
            disguised = json.loads(json.dumps(relationship))
            disguised_prompt = disguised["prompts"][0]
            disguised_prompt["must_not_add"][0] += f" {disguised_label} extreme macro first-person camera"
            disguised_prompt["image_contract"]["must_not_add"] = list(disguised_prompt["must_not_add"])
            disguised_prompt["canonical_prompt"] = replace_canonical_section(
                disguised_prompt["canonical_prompt"], "Must not add",
                serialize_list(disguised_prompt["must_not_add"], f"{test_name}.must_not_add"),
            )
            disguised_prompt["prompt_sha256"] = sha_text(disguised_prompt["canonical_prompt"])
            disguised_root = root / test_name
            render_markdown(disguised, disguised_root, origin_source_root=relationship_root)
            try:
                validate_portfolio(disguised, disguised_root, graph_ids=None, coverage_slots=None)
            except PromptPortfolioError:
                results[test_name] = "BLOCK"
            else:
                raise PromptPortfolioError(f"{test_name} unexpectedly passed")
        duplicate_label = json.loads(json.dumps(relationship))
        duplicate_label_prompt = duplicate_label["prompts"][0]
        duplicate_label_prompt["canonical_prompt"] += "\nCamera: extreme macro first-person camera"
        duplicate_label_prompt["prompt_sha256"] = sha_text(duplicate_label_prompt["canonical_prompt"])
        duplicate_label_root = root / "duplicate-authority-label"
        render_markdown(duplicate_label, duplicate_label_root, origin_source_root=relationship_root)
        try:
            validate_portfolio(duplicate_label, duplicate_label_root, graph_ids=None, coverage_slots=None)
        except PromptPortfolioError:
            results["duplicate_authority_label"] = "BLOCK"
        else:
            raise PromptPortfolioError("duplicate authority label unexpectedly passed")
        collapsed = json.loads(json.dumps(relationship))
        collapsed_prompt = collapsed["prompts"][0]
        old_subject = collapsed_prompt["content_anchors"]["subject_identity"]
        collapsed_identity = "field journalist guarding an immune child"
        collapsed_entities = [{
            "entity_id": "SUBJECT-01", "entity_type": "PERSON",
            "identity": collapsed_identity, "visible_count": 1,
        }]
        collapsed_prompt["content_anchors"]["subject_identity"] = collapsed_identity
        collapsed_prompt["content_anchors"]["subject_entities"] = collapsed_entities
        collapsed_prompt["image_contract"]["subject_count"] = 1
        collapsed_prompt["image_contract"]["must_show"][0] = collapsed_identity
        collapsed_prompt["canonical_prompt"] = replace_canonical_section(
            collapsed_prompt["canonical_prompt"], "Subject identity", collapsed_identity,
        )
        collapsed_prompt["canonical_prompt"] = replace_canonical_section(
            collapsed_prompt["canonical_prompt"], "Subject entities", serialize_subject_entities(collapsed_entities),
        )
        collapsed_prompt["canonical_prompt"] = replace_canonical_section(
            collapsed_prompt["canonical_prompt"], "Must show",
            serialize_list(collapsed_prompt["image_contract"]["must_show"], "collapsed.must_show"),
        )
        collapsed_prompt["canonical_prompt"] = replace_canonical_section(
            collapsed_prompt["canonical_prompt"], "Subject count", "1",
        )
        collapsed_prompt["prompt_sha256"] = sha_text(collapsed_prompt["canonical_prompt"])
        collapsed_root = root / "collapsed-multi-subject"
        render_markdown(collapsed, collapsed_root, origin_source_root=relationship_root)
        try:
            validate_portfolio(collapsed, collapsed_root, graph_ids=None, coverage_slots=None)
        except PromptPortfolioError:
            results["collapsed_multi_subject_entity"] = "BLOCK"
        else:
            raise PromptPortfolioError(f"collapsed multi-subject entity unexpectedly passed: {old_subject}")
        cross_direction = json.loads(json.dumps(relationship))
        cross_prompt = cross_direction["prompts"][0]
        foreign_action = cross_direction["directions"][1]["anchor_lexicon"]["actions"][0]
        old_action = cross_prompt["content_anchors"]["action"]
        cross_prompt["content_anchors"]["action"] = foreign_action
        cross_prompt["image_contract"]["pose_or_action"] = foreign_action
        cross_prompt["image_contract"]["primary_read"] = f"{foreign_action} changing the play state"
        cross_prompt["image_contract"]["must_show"] = [
            foreign_action if value == old_action else value for value in cross_prompt["image_contract"]["must_show"]
        ]
        cross_prompt["semantic_delta"] = cross_prompt["semantic_delta"].replace(old_action, foreign_action)
        for label, value in (
            ("Required action", foreign_action), ("Pose or action", foreign_action),
            ("Primary read", cross_prompt["image_contract"]["primary_read"]),
            ("Must show", serialize_list(cross_prompt["image_contract"]["must_show"], "cross_direction.must_show")),
            ("Semantic delta", cross_prompt["semantic_delta"]),
        ):
            cross_prompt["canonical_prompt"] = replace_canonical_section(cross_prompt["canonical_prompt"], label, value)
        cross_prompt["prompt_sha256"] = sha_text(cross_prompt["canonical_prompt"])
        cross_root = root / "cross-direction-anchor"
        render_markdown(cross_direction, cross_root, origin_source_root=relationship_root)
        try:
            validate_portfolio(cross_direction, cross_root, graph_ids=None, coverage_slots=None)
        except PromptPortfolioError:
            results["cross_direction_anchor_ownership"] = "BLOCK"
        else:
            raise PromptPortfolioError("foreign direction action unexpectedly passed")
        non_visual_triple = json.loads(json.dumps(relationship))
        triple_prompt = non_visual_triple["prompts"][0]
        triple_target = triple_prompt["content_anchors"]["location_identity"]
        false_operations = (
            "camera follows the child", "lighting reveals the journalist", "composition centers the pouch",
            "framing tracks the pursuers", "contrast describes the crisis", "depth mentions the shelter",
            "silhouette names the guardian", "material states the setting",
        )
        triple_prompt["visual_mechanisms"] = [
            {"operation": operation, "target": triple_target,
             "visible_result": f"{triple_target} remains readable with visible contrast"}
            for operation in false_operations
        ]
        triple_prompt["canonical_prompt"] = replace_canonical_section(
            triple_prompt["canonical_prompt"], "Visual mechanisms",
            serialize_mechanisms(triple_prompt["visual_mechanisms"]),
        )
        triple_prompt["prompt_sha256"] = sha_text(triple_prompt["canonical_prompt"])
        triple_root = root / "non-visual-triple"
        render_markdown(non_visual_triple, triple_root, origin_source_root=relationship_root)
        try:
            validate_portfolio(non_visual_triple, triple_root, graph_ids=None, coverage_slots=None)
        except PromptPortfolioError:
            results["non_visual_mechanism_triple"] = "BLOCK"
        else:
            raise PromptPortfolioError("content statements disguised as mechanism triples unexpectedly passed")
        beside_collapse = json.loads(json.dumps(relationship))
        beside_prompt = beside_collapse["prompts"][0]
        beside_identity = "field journalist next to immune child"
        beside_collapse["directions"][0]["anchor_lexicon"]["subject_entities"].append(beside_identity)
        beside_entities = [{
            "entity_id": "SUBJECT-01", "entity_type": "PERSON",
            "identity": beside_identity, "visible_count": 1,
        }]
        beside_prompt["content_anchors"]["subject_identity"] = beside_identity
        beside_prompt["content_anchors"]["subject_entities"] = beside_entities
        beside_prompt["image_contract"]["subject_count"] = 1
        beside_prompt["image_contract"]["must_show"][0] = beside_identity
        beside_prompt["canonical_prompt"] = replace_canonical_section(
            beside_prompt["canonical_prompt"], "Subject identity", beside_identity,
        )
        beside_prompt["canonical_prompt"] = replace_canonical_section(
            beside_prompt["canonical_prompt"], "Subject entities", serialize_subject_entities(beside_entities),
        )
        beside_prompt["canonical_prompt"] = replace_canonical_section(
            beside_prompt["canonical_prompt"], "Must show",
            serialize_list(beside_prompt["image_contract"]["must_show"], "beside_collapse.must_show"),
        )
        beside_prompt["canonical_prompt"] = replace_canonical_section(
            beside_prompt["canonical_prompt"], "Subject count", "1",
        )
        beside_prompt["prompt_sha256"] = sha_text(beside_prompt["canonical_prompt"])
        beside_root = root / "beside-collapse"
        render_markdown(beside_collapse, beside_root, origin_source_root=relationship_root)
        for direction in beside_collapse["directions"]:
            write_direction_origin(direction, beside_root)
        try:
            validate_portfolio(beside_collapse, beside_root, graph_ids=None, coverage_slots=None)
        except PromptPortfolioError:
            results["atomic_subject_relation_paraphrase"] = "BLOCK"
        else:
            raise PromptPortfolioError("relation paraphrase collapsed into one subject unexpectedly passed")
        lexicon_reassignment = json.loads(json.dumps(relationship))
        first_direction = lexicon_reassignment["directions"][0]
        second_direction = lexicon_reassignment["directions"][1]
        moved_action = second_direction["anchor_lexicon"]["actions"][0]
        first_direction["anchor_lexicon"]["actions"].append(moved_action)
        second_direction["anchor_lexicon"]["actions"][0] = "holds the transformed spouse during a memory break"
        reassignment_root = root / "lexicon-reassignment"
        render_markdown(lexicon_reassignment, reassignment_root, origin_source_root=relationship_root)
        for direction in lexicon_reassignment["directions"]:
            write_direction_origin(direction, reassignment_root)
        try:
            validate_portfolio(lexicon_reassignment, reassignment_root, graph_ids=None, coverage_slots=None)
        except PromptPortfolioError:
            results["mutable_direction_lexicon_reassignment"] = "BLOCK"
        else:
            raise PromptPortfolioError("mutable direction anchor ownership unexpectedly passed")
        generic_results = json.loads(json.dumps(relationship))
        generic_prompt = generic_results["prompts"][0]
        for mechanism in generic_prompt["visual_mechanisms"]:
            mechanism["visible_result"] = (
                f"{mechanism['target']} remains visible and readable because "
                f"{mechanism['operation']} controls contrast and depth"
            )
        generic_prompt["canonical_prompt"] = replace_canonical_section(
            generic_prompt["canonical_prompt"], "Visual mechanisms",
            serialize_mechanisms(generic_prompt["visual_mechanisms"]),
        )
        generic_prompt["prompt_sha256"] = sha_text(generic_prompt["canonical_prompt"])
        generic_root = root / "generic-mechanism-results"
        render_markdown(generic_results, generic_root, origin_source_root=relationship_root)
        try:
            validate_portfolio(generic_results, generic_root, graph_ids=None, coverage_slots=None)
        except PromptPortfolioError:
            results["generic_visual_mechanism_results"] = "BLOCK"
        else:
            raise PromptPortfolioError("generic mechanism results unexpectedly passed")
        ninth = json.loads(json.dumps(system))
        ninth_prompt = ninth["prompts"][0]
        extra_target = ninth_prompt["content_anchors"]["location_identity"]
        extra_mechanism = {
            "operation": "occlusion-guided depth continuity", "target": extra_target,
            "visible_result": f"{extra_target} preserves readable depth continuity through controlled overlap",
        }
        old_mechanisms = list(ninth_prompt["visual_mechanisms"])
        ninth_prompt["visual_mechanisms"].append(extra_mechanism)
        ninth_prompt["canonical_prompt"] = replace_canonical_section(
            ninth_prompt["canonical_prompt"], "Visual mechanisms",
            serialize_mechanisms(ninth_prompt["visual_mechanisms"]),
        )
        ninth_prompt["prompt_sha256"] = sha_text(ninth_prompt["canonical_prompt"])
        ninth_root = root / "ninth-mechanism"
        render_markdown(ninth, ninth_root, origin_source_root=system_root)
        result = validate_portfolio(ninth, ninth_root, graph_ids=None, coverage_slots=None)
        require(result["prompt_count"] == 146, "ninth grounded mechanism changed prompt coverage")
        results["ninth_grounded_visual_mechanism"] = "PASS"
    return results


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["compile", "validate"], nargs="?")
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--workspace-root", type=Path, default=Path.cwd())
    parser.add_argument("--doctor", action="store_true")
    args = parser.parse_args()
    try:
        if args.doctor:
            print(json.dumps({"status": "ready", "tool": "prompt-portfolio", "selftests": selftest()}, indent=2))
            return 0
        require(args.command is not None and args.manifest is not None,
                "command and --manifest are required unless --doctor is used")
        root = args.workspace_root.resolve()
        manifest_path = bounded(root, args.manifest, exist=True)
        data = load_json(manifest_path)
        if args.command == "compile":
            outputs = render_markdown(data, root)
            print(json.dumps({"status": "compiled", "files": [str(path) for path in outputs]}, indent=2))
        else:
            result = validate_portfolio(data, root)
            result.pop("prompt_by_evidence", None)
            result.pop("prompt_by_id", None)
            print(json.dumps(result, indent=2))
        return 0
    except (PromptPortfolioError, OSError, json.JSONDecodeError, ValueError) as exc:
        print(json.dumps({"status": "blocked", "reason": str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    sys.exit(main())
