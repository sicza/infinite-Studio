# Product Content Architecture

用于 `scope_profile=PORTFOLIO | VERTICAL_SLICE`。目标是从已选方向建立可执行的内容结构，不是把一个 Prompt 扩写成图片清单。

Portfolio 可以是一个方向的深度展开，也可以是多个方向的差异发散。多方向时先按 `16-direction-material-divergence.md` 建立各自 Material DNA，再让每个 Graph 节点归属于明确 Direction；不能把同一内容树复制后改名。

## 1. 先锁产品因果

先写 `product-blueprint.json`，明确：

```text
谁在行动
→ 每轮输入与动作
→ 系统状态如何变化
→ 玩家如何看到结果
→ 结果进入哪个下一系统
→ 为什么值得重复
```

世界规则必须至少改变输入、动作、状态、反馈或结果之一。只改变名词和装饰时标记为 Skin，不宣称 World-bound。

用户只给世界观时，产品类型、玩家代理、核心体验、循环与内容规模都属于 `ASSUMED`。可以探索，但这些关键假设未确认前不得进入 Portfolio Verified。

`assumptions[]` 必须始终包含五个稳定 ID：`PLAYER_AGENT / PRODUCT_TYPE / TARGET_EXPERIENCE / CORE_LOOP / CONTENT_SCOPE`。即使当前已确认也保留记录并写 `status=CONFIRMED + evidence`；不得通过省略记录把推断伪装成事实。`PROTOTYPE` 允许这些记录保持 `ASSUMED`，`PORTFOLIO / VERTICAL_SLICE` 必须全部确认。

## 2. Experience Map

每个系统建立：

```text
SYSTEM_ID
Input
Player Action
State Before
Transition Rule
Visible Feedback
Output
Downstream System
Failure / Exit
```

`VERTICAL_SLICE` 还必须写 `experience_loop`：入口 State、出口 State、连续编号 Steps、每步 System/Input/Before/Transition/After/Visible Feedback/Output/Screen，以及 End Condition、Failure/Exit、Recovery、Next-run Difference。入口必须等于首步 Before，出口必须等于末步 After，相邻步骤必须满足前一步 After 等于后一步 Before。所有 System、State、Screen 与 `TRANSITIONS_TO` 边必须在 Content Graph 中存在并进入 Approved Coverage/Evidence；各段边分别合法但彼此断开的链不能通过。

系统边必须说明传递的真实对象，例如资源、角色状态、地图解锁、叙事条件或商业化资格。两个界面相邻不等于两个系统发生因果。

### 反证

- 移除一个系统后，核心体验是否更清楚？若是，该系统可能只是负担。
- 输出不进入任何下游时，这个系统是否只是孤立页面？
- 同一最优动作能否解决所有状态？若是，决策可能是假选择。
- 第三轮与第一轮是否有实质差异？若否，Meta Loop 可能只是重复等待。

## 3. Content Graph

用稳定 ID 建节点，显示名不得作为 ID。先建资产，再建状态、事件、屏幕和用途。

### Asset

- Character：有稳定个人身份、叙事／系统职能；
- Creature：以行为、栖息地、反制和身体结构区分；
- NPC Template：群体功能模板，不冒充核心角色；
- Unit Template：兵种模板，实例数量不增加单位类型数；
- Building：功能与核心拓扑稳定；等级是同族状态；
- Location：由空间拓扑、地标、功能区与世界关系定义；
- Prop：有独立功能或叙事权威。

### State

状态必须绑定基础 Asset/Location/Screen，并说明：

```text
Entry Trigger / Changed Layer / Visible Delta / Gameplay Meaning / Exit or Recovery
```

湿、污、破损、修复、升级、箭雨、火灾、UI展开等默认是状态，不是新资产。

### Event

事件最小结构：

```text
Cause / Participants / Location / Action / Consequence
```

若只改变镜头、色光、特效或表情，仍归原事件的表现变体。若原因、动作或后果改变，才考虑新事件。

### Screen / Use

Screen 表达交互模板；Use 表达交付目的，例如 Gameplay、Loading、KV、Character Sheet、UI Detail、Offer、Flow Diagram。去 UI、改排版、换语言或裁切通常是 Use/Presentation 变化。

## 4. 建筑和城市

建筑族先锁 `function / footprint / entrance / click zone / stable landmark`，再定义等级差：容量、设备、层数、人员、入口和输出如何增加。多条升级链在未选择前使用不同 candidate branch，不能累加为同一正式资产。

城市先锁地形骨架、道路、水系、桥港、功能区、可建设槽、地标层级、镜头预算与交互净空。只有核心拓扑改变才建立新地点；火灾、天气、繁荣度和损毁进入状态。

## 5. 角色集合

每个角色以 `character_id` 为 Authority，保存显示名、别名、职能、Anchor、合法形态与禁止变化。执行四类冲突检查：

- 同资产多名称；
- 同名称多资产；
- 同脸／同体换装冒充多人；
- 只有服装色或道具变化的低置信候选。

角色卡网格同时报告卡槽、唯一身份、皮肤／状态和重复实例，不按格数报告独立角色。

## 6. 范围设计

内容预算使用语义单位：方向、核心角色、NPC/兵种模板、建筑族、地点族、事件、状态、屏幕模板和正式证据项。预算不是质量目标；它的作用是防止内容域缺失和无限发散。

对每个预算项建立 Coverage 槽。无法解释“它支持哪个玩家体验、系统或叙事因果”的资产，不进入正式范围。

Prompt-only 交付时，范围分母仍来自语义槽位；每个槽位最终编译为一个完整 `CANONICAL_PROMPT` Evidence。多个Prompt可以写入同一Markdown文件，但每个Prompt拥有独立ID与正文Hash。

## 7. 与现有 Anchor 的关系

Product Blueprint/Content Graph 负责集合和关系；已有 Character/Creature/Environment/Gameplay/Style/UI Anchor 继续负责单对象冻结。Content Graph 节点引用 Anchor，不复制全部正文。Visual Spec 使用 `other_authority` 绑定当前 Product Blueprint；Portfolio 同时绑定 Content Graph 与 Coverage Plan 的路径和 Hash。
