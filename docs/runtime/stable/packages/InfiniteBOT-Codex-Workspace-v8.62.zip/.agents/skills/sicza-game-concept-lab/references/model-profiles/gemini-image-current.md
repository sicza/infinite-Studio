# Gemini Image Current Profile

Provider: Google
Verified At: 2026-08-17
Freshness Class: VOLATILE
Reverify After: 30 days
Official Source: https://ai.google.dev/gemini-api/docs/image-generation

## Current Family

当前原生图像家族包括 Gemini 3.1 Flash Image（Nano Banana 2）、Gemini 3.1 Flash Lite Image、Gemini 3 Pro Image（Nano Banana Pro）以及旧 Gemini 2.5 Flash Image。

## Routing

- 高频探索/普通生成编辑：当前 Flash Image 主力。
- 复杂专业视觉、多参考、Style Reference 或最终资产：优先评估 Pro Image。
- 极高量、低延迟简单操作：评估 Lite。

## Resolution

Gemini 3 Image 当前支持高分辨率输出，不同型号能力不同；“4K”是输出配置，不是 Prompt 画质咒语。

## Reference

Gemini 3 Image 官方支持文本+图片输入、图像编辑和多 Reference。当前官方表格对 Pro Image 给出的能力上限为：单次工作流最多 14 张参考图，其中最多 6 张高保真对象图、5 张角色一致性图、3 张 Style Reference。复杂多参考任务仍应按职责最小化选择，并在超过本 Profile 新鲜度时重新核对官方表格。

## Strengths

Conversational Iteration / Multiple References / Character Consistency / Natural-language Edit / Element Composition / Text-oriented Visual / Rapid Exploration。

## Production Rule

Approved Character 连续生产时复用已批准图像；Style Reference 只负责渲染层，除非上游已经批准 Product-level Style Mutation。

## Refresh Trigger

型号稳定状态、参考图容量、Style Reference、分辨率、编辑行为变化或超过 30 天时重新验证。
