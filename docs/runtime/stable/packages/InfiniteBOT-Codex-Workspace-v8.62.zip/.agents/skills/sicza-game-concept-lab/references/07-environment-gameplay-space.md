# Environment & Gameplay Space

## 目标

Environment 必须同时是 `World + Architecture + Gameplay Geometry + Visual Composition`。玩家位置、路线、目标、不可进入区、成功后的变化、下一步都必须明确。

## 1. 从 Player Action Sequence 开始

禁止先写“宏伟废土地铁大厅”。先写：`进入 → 发现问题 → 到达目标 → 交互 → 状态变化 → Reward → 下一步`，再反推空间。

## 2. 三种 Function

每个空间区分：`Original Function / Current World Function / Gameplay Function`。灾后场景尤其要说明 What Survived / What Was Added / What Was Repurposed。

## 3. Gameplay Geometry

先放逻辑，不想装饰：`Player Start / Main Route / Interaction Node / Resource Node / Blocked Area / Unlockable Area / Threat Entry / Safe Area / Vertical Connection / State-change Area / Scale Reference`。

### Management

额外：`NPC Flow / Resource Flow / Workstation / Service Point / Expansion Boundary`。

### Action / Runner / Exploration

额外：`Alternate Route / Obstacle / Traversal Point / Cover / Threat Entry / Payoff Point`。

### Puzzle / Board

明确 Board Location/World Mapping/Input/Output/World-state Connection，胜负必须改变真实空间状态。

## 4. Visual Path

确定阅读顺序，例如 `当前危险 → 目标设备 → 成功后的收益区 → 下一步`，形成 Reading Axis。不要平均铺信息。

## 5. Scale

至少有 Human/Train/Door/Vehicle/Column/Stair 等 Scale Reference。必要时写主设备和角色相对尺寸，避免“很大但不知道多大”。

## 6. Landmark

Landmark 至少承担 Navigation / Identity / World History / Gameplay Objective / Visual Memory 中一项，最好多项。不是随便放雕像。

## 7. State Change

必须明确操作成功后哪里变：灯光、机器、NPC 流、门、资源流、区域可达性。Before/After 几乎一样说明 Visual Proof 不够。

## 8. Lighting

先回答光从哪来、为什么在这里、Gameplay 会不会改变它。光可以表达 Safety/Danger/Availability/Progress/Power/Ownership，不只是“电影级”。

## 9. Materials

材质同时反映 Original Architecture、Current Function、Maintenance State，形成时间层。旧 Marble/Tile/Metal 与新 Cable/Temporary Steel/Fabric Shelter/Polymer Pipe 应有明确关系。

## 10. Fore/Mid/Background

每层承担功能：Foreground=Player/Immediate Interaction；Midground=Main Gameplay Device；Background=Reward/Future/Locked Space。不要每层都塞废墟。

## 11. Environment Anchor

`Environment Identity / Macro Layout / Function Zones / Landmark / Navigation / Vertical Structure / Material Family / Lighting Logic / Scale / Gameplay Change Areas`

### Building Family

同一建筑先冻结 `building_family_id / function / footprint / entrance_and_click_zone / stable_landmarks / interior_exterior_relation / staff_or_user_scale / production_inputs_outputs`。等级写入 `level_states[]`，每级明确容量、设备、层数、人员、入口或输出的可见增量。只换材质、颜色、天气、损坏或装饰仍是状态；功能身份或核心拓扑改变才建立新建筑族。

多条升级方案在选择前必须使用不同 `candidate_branch`；只允许一个 `selected_branch` 进入正式 Coverage，不能把互斥候选累加成同一等级链。

### City Topology

城市冻结 `terrain_skeleton / road_graph / water_and_bridge_graph / functional_zones / ports / buildable_slots / landmark_hierarchy / camera_budget / interaction_clearance`。天气、繁荣度、火灾、NPC 密度和表面损毁绑定为同一地点的 State。道路、地标或功能区发生互斥变化时保留候选或冲突，不得擅自拼成升级序列。

## 12. 完成标准

玩家位置明确；交互和路线明确；Before/After 可见；下一步明确；空间不能换成任意大厅仍成立；Landmark 属于世界；建筑等级保持家族身份且功能增量可见；城市实例与冻结拓扑一致；Prompt 可以准确描述主体位置和关系。
