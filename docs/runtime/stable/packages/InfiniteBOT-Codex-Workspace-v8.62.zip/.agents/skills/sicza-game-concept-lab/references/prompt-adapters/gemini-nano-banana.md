# Gemini / Nano Banana — Game Concept Domain Delta

共享 Provider 方言：`../../../wxian-image-production/references/prompt-packs/gemini-image.md`。  
共享不变量：`.agents/skills/sicza-visual-director/references/prompt-adapter-invariants.md`。

## Domain Delta

- 先表达可见 Gameplay Result，再写角色/怪物/场景细节；
- 多 Reference 保持 Identity / Pose-Camera / Environment / Rendering / Product Asset 的职责隔离；
- Gameplay Mutation 只改变 Frozen Anchor 开放的层；
- 高精度重绘保持产品结构与角色身份；
- Sequential consistency 复用已批准 Identity/Prototype Anchor。

## IP Character Input

长期 IP / 正式角色使用 `05a-ip-character-system.md` 生成的 `ip-character-handoff.json`。`image_conditioning_inputs` 作为真实 Gemini reference inputs；Prompt 只表达 `use_roles / preserve`。

Provider/Mode、locator、输入上限、顺序与 Runtime Gate 以 `config/provider-reference-binding-registry.json` 和当前 `wxian-image-production` 为 Authority。

## Failure Return

- Gameplay/产品事实 → Game Concept Authority；
- Camera/空间/光材质/层级 → Visual Spec；
- Reference Role → Reference Contract / Mother Binding；
- Prompt projection → 本 Adapter；
- Runtime/model capability → 执行层。
