#!/usr/bin/env python3
"""Validate an independent, full-coverage semantic review of a Prompt Portfolio."""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import re
import sys
import tempfile
import unicodedata
from pathlib import Path
from typing import Any


SCHEMA_VERSION = "sicza.game-concept.prompt-semantic-review.v1"
REVIEW_MODE = "FULL_INDEPENDENT_SEMANTIC_REVIEW"
PROMPT_CHECKS = {
    "subject_cardinality_and_roles",
    "causal_and_material_specificity",
    "visual_mechanism_effectiveness",
    "prompt_completeness_and_executability",
    "pseudo_variety_and_duplication",
}
SWAP_COMPONENTS = {
    "subject", "location", "action", "consequence", "world_objects", "causal_chain",
}
PROMPT_MARKER = "<!-- SEMANTIC_REVIEW_PROMPT: {prompt_id} {prompt_sha256} -->"
PAIR_MARKER = "<!-- SEMANTIC_SWAP_PAIR: {direction_a} {direction_b} -->"


class PromptSemanticReviewError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise PromptSemanticReviewError(message)


def sha_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def bounded(root: Path, value: str | Path, *, exist: bool = False) -> Path:
    path = Path(value)
    path = (root / path if not path.is_absolute() else path).resolve()
    root = root.resolve()
    require(path == root or root in path.parents, f"path escapes Workspace: {value}")
    if exist:
        require(path.exists(), f"path does not exist: {value}")
    return path


def relative(root: Path, path: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def canonical_actor_id(value: Any, label: str) -> str:
    require(isinstance(value, str), f"{label} missing")
    normalized = unicodedata.normalize("NFKC", value)
    normalized = "".join(
        character for character in normalized if unicodedata.category(character) != "Cf"
    ).strip().casefold()
    require(re.fullmatch(r"[a-z0-9][a-z0-9._-]{2,127}", value) is not None,
            f"{label} must be a canonical lowercase actor id")
    require(value == normalized, f"{label} contains non-canonical or ignorable characters")
    return normalized


def load_json(path: Path, label: str) -> dict[str, Any]:
    require(path.is_file(), f"{label} missing: {path}")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise PromptSemanticReviewError(f"invalid {label}: {exc}") from exc
    require(isinstance(value, dict), f"{label} root must be an object")
    return value


def nonempty_strings(value: Any, label: str, *, minimum: int = 1) -> list[str]:
    require(isinstance(value, list) and len(value) >= minimum, f"{label} requires at least {minimum} items")
    require(all(isinstance(item, str) and len(item.strip()) >= 20 for item in value),
            f"{label} items must contain concrete review evidence")
    return value


def _unique(items: list[dict[str, Any]], key: str, label: str) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for item in items:
        require(isinstance(item, dict) and key in item, f"{label} item lacks {key}")
        value = str(item[key])
        require(value not in result, f"duplicate {label} {key}: {value}")
        result[value] = item
    return result


def validate_review(review: dict[str, Any], root: Path, manifest: dict[str, Any],
                    manifest_path: Path) -> dict[str, Any]:
    required = {
        "schema_version", "product_id", "review_mode", "portfolio_binding", "producer_id",
        "reviewer_id", "prompt_reviews", "cross_direction_reviews", "portfolio_judgement",
        "summary", "report_binding", "status",
    }
    require(set(review) == required, f"prompt semantic review fields mismatch: {sorted(set(review) ^ required)}")
    require(review["schema_version"] == SCHEMA_VERSION, "prompt semantic review schema_version mismatch")
    require(review["product_id"] == manifest.get("product_id"), "semantic review product_id mismatch")
    require(review["review_mode"] == REVIEW_MODE, "semantic review must cover the full portfolio")
    producer_id = canonical_actor_id(review["producer_id"], "semantic review producer_id")
    manifest_producer_id = canonical_actor_id(manifest.get("producer_id"), "portfolio producer_id")
    reviewer_id = canonical_actor_id(review["reviewer_id"], "semantic review reviewer_id")
    require(producer_id == manifest_producer_id, "semantic review producer differs from portfolio producer")
    require(reviewer_id != producer_id, "semantic reviewer must be separate from portfolio producer")

    binding = review["portfolio_binding"]
    require(isinstance(binding, dict) and set(binding) == {"path", "sha256"},
            "portfolio_binding fields invalid")
    bound_manifest = bounded(root, str(binding["path"]), exist=True)
    require(bound_manifest == manifest_path.resolve(), "semantic review binds a different portfolio manifest")
    require(re.fullmatch(r"[0-9a-f]{64}", str(binding["sha256"])) is not None,
            "portfolio_binding sha256 invalid")
    require(binding["sha256"] == sha_file(manifest_path), "semantic review portfolio hash drift")

    prompts = manifest.get("prompts")
    require(isinstance(prompts, list) and prompts, "portfolio prompts missing")
    prompt_by_id = _unique(prompts, "prompt_id", "portfolio prompt")
    reviews = review["prompt_reviews"]
    require(isinstance(reviews, list), "prompt_reviews must be an array")
    review_by_id = _unique(reviews, "prompt_id", "prompt review")
    require(set(review_by_id) == set(prompt_by_id),
            "semantic review must cover every prompt exactly once")
    blocked_prompts = 0
    for prompt_id, item in review_by_id.items():
        require(set(item) == {"prompt_id", "prompt_sha256", "verdict", "checks"},
                f"prompt review fields invalid: {prompt_id}")
        require(item["prompt_sha256"] == prompt_by_id[prompt_id].get("prompt_sha256"),
                f"reviewed prompt hash drift: {prompt_id}")
        require(item["verdict"] in {"PASS", "BLOCK"}, f"invalid prompt review verdict: {prompt_id}")
        checks = item["checks"]
        require(isinstance(checks, dict) and set(checks) == PROMPT_CHECKS,
                f"prompt semantic checks incomplete: {prompt_id}")
        for check_name, check in checks.items():
            require(isinstance(check, dict) and set(check) == {"verdict", "evidence"},
                    f"prompt check fields invalid: {prompt_id} -> {check_name}")
            require(check["verdict"] in {"PASS", "BLOCK"},
                    f"invalid prompt check verdict: {prompt_id} -> {check_name}")
            nonempty_strings(check["evidence"], f"{prompt_id}.{check_name}.evidence")
        derived = "BLOCK" if any(value["verdict"] == "BLOCK" for value in checks.values()) else "PASS"
        require(item["verdict"] == derived, f"prompt verdict disagrees with checks: {prompt_id}")
        blocked_prompts += item["verdict"] == "BLOCK"

    approved_directions = sorted(
        str(item["direction_id"]) for item in manifest.get("directions", [])
        if item.get("status") == "APPROVED"
    )
    expected_pairs = {
        frozenset(pair) for pair in itertools.combinations(approved_directions, 2)
    }
    swaps = review["cross_direction_reviews"]
    require(isinstance(swaps, list), "cross_direction_reviews must be an array")
    actual_pairs: set[frozenset[str]] = set()
    prompts_by_direction: dict[str, set[str]] = {item: set() for item in approved_directions}
    for prompt in prompts:
        direction_id = str(prompt.get("direction_id"))
        if direction_id in prompts_by_direction:
            prompts_by_direction[direction_id].add(str(prompt.get("prompt_id")))
    blocked_pairs = 0
    for item in swaps:
        require(isinstance(item, dict) and set(item) == {
            "direction_a", "direction_b", "prompt_pairs", "verdict",
        }, "cross-direction review fields invalid")
        direction_a, direction_b = str(item["direction_a"]), str(item["direction_b"])
        pair = frozenset((direction_a, direction_b))
        require(len(pair) == 2 and pair in expected_pairs, "cross-direction review pair invalid")
        require(pair not in actual_pairs, "duplicate cross-direction review pair")
        actual_pairs.add(pair)
        prompt_pairs = item["prompt_pairs"]
        require(isinstance(prompt_pairs, list) and len(prompt_pairs) >= 2,
                f"direction swap review requires at least two prompt pairs: {direction_a}, {direction_b}")
        pair_blocked = False
        seen_prompt_pairs: set[tuple[str, str]] = set()
        for swap in prompt_pairs:
            require(isinstance(swap, dict) and set(swap) == {
                "prompt_a", "prompt_b", "components_tested", "swap_failure", "verdict",
            }, f"swap test fields invalid: {direction_a}, {direction_b}")
            prompt_a, prompt_b = str(swap["prompt_a"]), str(swap["prompt_b"])
            require(prompt_a in prompts_by_direction[direction_a],
                    f"swap prompt_a belongs to wrong direction: {prompt_a}")
            require(prompt_b in prompts_by_direction[direction_b],
                    f"swap prompt_b belongs to wrong direction: {prompt_b}")
            require((prompt_a, prompt_b) not in seen_prompt_pairs, "duplicate prompt swap test")
            seen_prompt_pairs.add((prompt_a, prompt_b))
            components = swap["components_tested"]
            require(isinstance(components, list) and set(components) == SWAP_COMPONENTS,
                    f"swap test must cover all material and causal components: {prompt_a}, {prompt_b}")
            require(isinstance(swap["swap_failure"], str) and len(swap["swap_failure"].strip()) >= 40,
                    f"swap test lacks concrete failure evidence: {prompt_a}, {prompt_b}")
            require(swap["verdict"] in {"PASS", "BLOCK"}, "invalid swap test verdict")
            pair_blocked = pair_blocked or swap["verdict"] == "BLOCK"
        expected_verdict = "BLOCK" if pair_blocked else "PASS"
        require(item["verdict"] == expected_verdict, "direction-pair verdict disagrees with swap tests")
        blocked_pairs += item["verdict"] == "BLOCK"
    require(actual_pairs == expected_pairs, "semantic swap review must cover every approved direction pair")

    judgement = review["portfolio_judgement"]
    require(isinstance(judgement, dict) and set(judgement) == {
        "facts", "judgements", "recommendations", "unknowns",
    }, "portfolio_judgement fields invalid")
    nonempty_strings(judgement["facts"], "portfolio_judgement.facts")
    nonempty_strings(judgement["judgements"], "portfolio_judgement.judgements")
    nonempty_strings(judgement["recommendations"], "portfolio_judgement.recommendations")
    require(isinstance(judgement["unknowns"], list), "portfolio_judgement.unknowns must be an array")
    require(all(isinstance(item, str) and item.strip() for item in judgement["unknowns"]),
            "portfolio_judgement.unknowns contains an empty item")

    report_binding = review["report_binding"]
    require(isinstance(report_binding, dict) and set(report_binding) == {"path", "sha256"},
            "report_binding fields invalid")
    report_path = bounded(root, str(report_binding["path"]), exist=True)
    require(report_path.is_file() and report_path.suffix.lower() == ".md",
            "semantic review report must be Markdown")
    require(report_binding["sha256"] == sha_file(report_path), "semantic review report hash drift")
    report_text = report_path.read_text(encoding="utf-8")
    require(len(report_text.strip()) >= 500, "semantic review report is too short")
    for prompt_id, prompt in prompt_by_id.items():
        marker = PROMPT_MARKER.format(prompt_id=prompt_id, prompt_sha256=prompt["prompt_sha256"])
        require(marker in report_text, f"semantic review report lacks prompt evidence marker: {prompt_id}")
    for pair in expected_pairs:
        direction_a, direction_b = sorted(pair)
        marker = PAIR_MARKER.format(direction_a=direction_a, direction_b=direction_b)
        require(marker in report_text, f"semantic review report lacks direction swap marker: {direction_a}, {direction_b}")

    summary = review["summary"]
    require(isinstance(summary, dict) and set(summary) == {
        "total_prompts", "reviewed_prompts", "blocked_prompts", "direction_pairs",
        "reviewed_direction_pairs", "blocked_direction_pairs",
    }, "semantic review summary fields invalid")
    expected_summary = {
        "total_prompts": len(prompts), "reviewed_prompts": len(reviews),
        "blocked_prompts": blocked_prompts, "direction_pairs": len(expected_pairs),
        "reviewed_direction_pairs": len(swaps), "blocked_direction_pairs": blocked_pairs,
    }
    require(summary == expected_summary, "semantic review summary is not computed truth")
    require(review["status"] in {"PASS", "BLOCK"}, "semantic review status invalid")
    derived_status = "PASS" if not blocked_prompts and not blocked_pairs and not judgement["unknowns"] else "BLOCK"
    require(review["status"] == derived_status, "semantic review status disagrees with review findings")
    require(review["status"] == "PASS", "prompt portfolio semantic review did not pass")
    return {
        "status": "PASS", "reviewer_id": reviewer_id, "prompt_count": len(prompts),
        "direction_pair_count": len(expected_pairs), "report_path": relative(root, report_path),
    }


def build_selftest_review(manifest: dict[str, Any], root: Path, manifest_path: Path,
                          review_path: Path, report_path: Path, *, reviewer_id: str) -> dict[str, Any]:
    report_lines = [
        f"# {manifest['product_id']} Prompt Semantic Review", "",
        "This independent report records full Prompt-by-Prompt semantic judgement. Machine validation binds coverage and hashes; the reviewer owns the professional conclusions.", "",
    ]
    prompt_reviews = []
    for prompt in manifest["prompts"]:
        checks = {
            check: {
                "verdict": "PASS",
                "evidence": [f"{prompt['prompt_id']} has concrete, prompt-local evidence for {check.replace('_', ' ')}."],
            }
            for check in sorted(PROMPT_CHECKS)
        }
        prompt_reviews.append({
            "prompt_id": prompt["prompt_id"], "prompt_sha256": prompt["prompt_sha256"],
            "verdict": "PASS", "checks": checks,
        })
        report_lines.extend([
            PROMPT_MARKER.format(prompt_id=prompt["prompt_id"], prompt_sha256=prompt["prompt_sha256"]),
            f"## {prompt['prompt_id']}",
            f"The reviewer checked subject count, causal specificity, material identity, eight visual mechanisms, completeness, and pseudo-variety risk for {prompt.get('title', prompt['prompt_id'])}; no blocking interchangeability was found.", "",
        ])
    approved = sorted(
        str(item["direction_id"]) for item in manifest["directions"] if item["status"] == "APPROVED"
    )
    cross_reviews = []
    by_direction = {
        direction: [item["prompt_id"] for item in manifest["prompts"] if item["direction_id"] == direction]
        for direction in approved
    }
    for direction_a, direction_b in itertools.combinations(approved, 2):
        prompt_pairs = []
        for index in range(2):
            prompt_a = by_direction[direction_a][index % len(by_direction[direction_a])]
            prompt_b = by_direction[direction_b][index % len(by_direction[direction_b])]
            prompt_pairs.append({
                "prompt_a": prompt_a, "prompt_b": prompt_b,
                "components_tested": sorted(SWAP_COMPONENTS),
                "swap_failure": (
                    f"Swapping {prompt_a} with {prompt_b} breaks the direction-specific actor, place, "
                    "action, consequence, prop ecology, and causal chain rather than merely changing styling."
                ),
                "verdict": "PASS",
            })
        cross_reviews.append({
            "direction_a": direction_a, "direction_b": direction_b,
            "prompt_pairs": prompt_pairs, "verdict": "PASS",
        })
        report_lines.extend([
            PAIR_MARKER.format(direction_a=direction_a, direction_b=direction_b),
            f"## Swap test: {direction_a} × {direction_b}",
            "Two prompt pairs were swapped across subject, location, action, consequence, world objects, and causal chain. Both swaps broke the world-specific logic, so the directions are not presentation-only skins.", "",
        ])
    report_lines.extend([
        "## Facts", "Every declared Prompt ID and hash was reviewed.", "",
        "## Judgements", "The portfolio is materially differentiated and executable as written.", "",
        "## Recommendations", "Retain the current causal and material boundaries during downstream adaptation.", "",
        "## Unknowns", "None blocking.", "",
    ])
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text("\n".join(report_lines), encoding="utf-8")
    review = {
        "schema_version": SCHEMA_VERSION,
        "product_id": manifest["product_id"],
        "review_mode": REVIEW_MODE,
        "portfolio_binding": {"path": relative(root, manifest_path), "sha256": sha_file(manifest_path)},
        "producer_id": manifest["producer_id"], "reviewer_id": reviewer_id,
        "prompt_reviews": prompt_reviews, "cross_direction_reviews": cross_reviews,
        "portfolio_judgement": {
            "facts": ["Every Prompt ID and Prompt SHA in the bound manifest was reviewed in full."],
            "judgements": ["The reviewed prompts contain materially specific subjects, places, actions, consequences, objects, and visual mechanisms."],
            "recommendations": ["Preserve the reviewed causal and material boundaries when adapting prompts for a downstream model."],
            "unknowns": [],
        },
        "summary": {
            "total_prompts": len(prompt_reviews), "reviewed_prompts": len(prompt_reviews),
            "blocked_prompts": 0, "direction_pairs": len(cross_reviews),
            "reviewed_direction_pairs": len(cross_reviews), "blocked_direction_pairs": 0,
        },
        "report_binding": {"path": relative(root, report_path), "sha256": sha_file(report_path)},
        "status": "PASS",
    }
    review_path.parent.mkdir(parents=True, exist_ok=True)
    review_path.write_text(json.dumps(review, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return review


def selftest() -> dict[str, str]:
    results: dict[str, str] = {}
    with tempfile.TemporaryDirectory(prefix="sicza-prompt-semantic-review-") as directory:
        root = Path(directory)
        manifest_path = root / "work" / "concept-lab" / "prompt-portfolio.json"
        report_path = root / "work" / "final" / "prompt-semantic-review.md"
        review_path = root / "work" / "concept-lab" / "prompt-semantic-review.json"
        prompts = [
            {"prompt_id": f"PROMPT-{index:03d}", "prompt_sha256": hashlib.sha256(str(index).encode()).hexdigest(),
             "direction_id": f"DIRECTION-D{1 if index < 2 else 2}"}
            for index in range(4)
        ]
        manifest = {
            "schema_version": "sicza.game-concept.prompt-portfolio.v4", "product_id": "semantic-selftest",
            "producer_id": "producer-selftest", "prompts": prompts,
            "directions": [
                {"direction_id": "DIRECTION-D1", "status": "APPROVED"},
                {"direction_id": "DIRECTION-D2", "status": "APPROVED"},
            ],
        }
        manifest_path.parent.mkdir(parents=True)
        manifest_path.write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
        review = build_selftest_review(
            manifest, root, manifest_path, review_path, report_path, reviewer_id="reviewer-selftest"
        )
        require(validate_review(review, root, manifest, manifest_path)["prompt_count"] == 4,
                "valid semantic review fixture failed")
        results["valid_full_independent_review"] = "PASS"

        mutations = {
            "reviewer_separation": lambda value: value.update({"reviewer_id": value["producer_id"]}),
            "reviewer_separation_trailing_space": lambda value: value.update({"reviewer_id": value["producer_id"] + " "}),
            "reviewer_separation_case_variant": lambda value: value.update({"reviewer_id": value["producer_id"].upper()}),
            "reviewer_separation_zero_width": lambda value: value.update({"reviewer_id": value["producer_id"] + "\u200b"}),
            "full_prompt_coverage": lambda value: value["prompt_reviews"].pop(),
            "prompt_hash_binding": lambda value: value["prompt_reviews"][0].update({"prompt_sha256": "0" * 64}),
            "full_swap_coverage": lambda value: value.update({"cross_direction_reviews": []}),
            "blocked_review_completion": lambda value: (
                value["prompt_reviews"][0]["checks"]["pseudo_variety_and_duplication"].update({"verdict": "BLOCK"}),
                value["prompt_reviews"][0].update({"verdict": "BLOCK"}),
                value["summary"].update({"blocked_prompts": 1}),
                value.update({"status": "BLOCK"}),
            ),
        }
        for name, mutate in mutations.items():
            candidate = json.loads(json.dumps(review))
            mutate(candidate)
            try:
                validate_review(candidate, root, manifest, manifest_path)
            except PromptSemanticReviewError:
                results[name] = "BLOCK"
            else:
                raise PromptSemanticReviewError(f"negative semantic review fixture unexpectedly passed: {name}")

        manifest_path.write_text(json.dumps({**manifest, "tampered": True}, indent=2) + "\n", encoding="utf-8")
        try:
            validate_review(review, root, manifest, manifest_path)
        except PromptSemanticReviewError:
            results["portfolio_manifest_hash_drift"] = "BLOCK"
        else:
            raise PromptSemanticReviewError("portfolio manifest hash drift unexpectedly passed")
    return results


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--review", type=Path)
    parser.add_argument("--workspace-root", type=Path, default=Path.cwd())
    parser.add_argument("--doctor", action="store_true")
    args = parser.parse_args()
    try:
        if args.doctor:
            print(json.dumps({"status": "ready", "tool": "prompt-semantic-review", "selftests": selftest()}, indent=2))
            return 0
        require(args.manifest is not None and args.review is not None,
                "--manifest and --review are required unless --doctor is used")
        root = args.workspace_root.resolve()
        manifest_path = bounded(root, args.manifest, exist=True)
        review_path = bounded(root, args.review, exist=True)
        result = validate_review(
            load_json(review_path, "prompt semantic review"), root,
            load_json(manifest_path, "prompt portfolio manifest"), manifest_path,
        )
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (PromptSemanticReviewError, OSError, json.JSONDecodeError, ValueError) as exc:
        print(json.dumps({"status": "blocked", "reason": str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    sys.exit(main())
