# Visual Director Bridge

## 职责

把已冻结的游戏产品事实与 Image Contract 编译为 canonical Visual Spec。Visual Director 拥有视觉结构编译职责；Game Concept Lab 保留 Gameplay、Prototype、Production Anchor 与 Image Contract Authority。

## 输入

- Prototype Spec / Frozen Anchors；
- 长期 IP / 正式角色：`ip-character-system.json` + 已通过 preflight 的 `ip-character-binding.json`；
- Reference Contract；
- Change Scope；
- Image Contract；
- 当前项目正式 Visual Baseline。

## 模式

- `CREATE`：新原型/新生产图；
- `TRANSFORM`：既有资产重组/改图；
- `ITERATE`：已批准方向的局部修复。

默认 1 个主模块 + 0–2 个依赖模块。

## Canonical Visual Spec

唯一输出：

```text
<request>/work/visual-spec.json
```

Schema：`.agents/skills/workspace-governance/config/visual-contracts/visual-spec-schema.json`。

产品事实进入 `authority_trace / truth_protection`；视觉机制进入 `world_space / performance / projection / appearance / image_structure / image_formation / graphic / identity / channel_roles / change_set`。

## Mother Reference Boundary

Mother Reference Binding 是独立的 Identity Conditioning Authority。Visual Director 读取：

`CHARACTER_ID / USE_ROLES / PRESERVE / VARIANT_OVERRIDES / Reference Authority`

用于约束身份、服装、比例、材质等视觉编译。真实 Reference locator 与 Provider input 继续由 `ip-character-handoff.json` 承载。

编辑任务中 Previous Generated Image/base image 的职责是 edit target；Mother Reference Authority 仍来自 Frozen System/Binding。

## Prompt Compilation

Prompt 编译消费已验证的 `visual-spec.json` 与 Mother Binding 的 Role/Preserve 语义，输出 `work/prompt-binding.json`。`compiler_profile` 来自 `.agents/skills/workspace-governance/config/visual-contracts/prompt-compiler-profiles.json`，并使用 Governance 注册给 `sicza-game-concept-lab` 的允许集合。

空间、姿态、投影、光材质、层级等新增视觉决定先回 Visual Spec，再进入 Prompt。
