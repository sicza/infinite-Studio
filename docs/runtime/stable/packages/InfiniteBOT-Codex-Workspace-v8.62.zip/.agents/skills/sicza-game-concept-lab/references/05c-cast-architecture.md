# Cast Architecture

## 目标

避免“每个角色单看都不错，放在一起却像同一个模板换衣服”。Cast Architecture 同时解决两件事：

1. 所有人属于同一个 IP；
2. 每个人又能在远景、剪影、头像和功能定位上快速区分。

## 1. 先定 Family，再定 Contrast

阵容不是追求最大差异。先锁 IP DNA 的共享范围，再分配角色之间的 Contrast。

共享：`Shape Grammar / Facial Grammar / Rendering Grammar / World Material Logic / Detail Density Family`

差异：`Height / Width / Body Mass / Head Shape / Silhouette / Age / Posture / Color Ownership / Prop Shape / Costume Architecture / Personality Read / Role Read`

## 2. Cast Matrix

3 个以上核心角色建议建立 Cast Matrix。每个角色至少填：

`Role / Height Band / Body Mass / Head Shape / Shoulder-Torso Shape / Limb Rhythm / Posture / Primary Silhouette Icon / Primary Color Ownership / Prop Family / Costume Architecture / Personality Read / Gameplay Read`

如果连续多个角色在 5 个以上高权重字段几乎相同，应主动检查是否模板化。

## 3. Silhouette Rhythm

推荐同时观察：

- Tall / Medium / Short；
- Narrow / Medium / Wide；
- Top-heavy / Balanced / Bottom-heavy；
- Angular / Blocky / Round / Mixed；
- Upright / Forward / Relaxed / Compressed posture；
- Compact / Extended carry shape。

不是每个维度都必须不同，但核心角色不能只靠头发颜色区分。

## 4. Color Ownership

共享 IP Palette，不等于所有角色平均分配同样颜色。

每个核心角色可以拥有：

`Primary Ownership Color / Secondary Family Color / Shared World Neutral / Hazard or Gameplay Color`

避免“角色 A 蓝、B 红、C 黄”这种脱离世界和 Costume Architecture 的机械配色；颜色差异应与 Role、Personality、Faction、Gameplay 或 Iconic Read 有关系。

## 5. Face Diversity Within Grammar

同一 IP 的脸部要共享几何语言，但不能变成同一张脸。

检查：

`Face Length-Width / Jaw / Cheekbone / Eye Spacing / Eye Tilt / Nose / Mouth / Hairline / Ear Exposure`

至少若干主维度形成真实差异，同时不越出 IP Facial Grammar。

## 6. Role & Prop Contrast

道具和服装应承担角色功能差异，不让所有人都获得相同的：

`tactical harness / backpack / shoulder armor / long coat / giant weapon / glowing device`

Primary Prop 的轮廓、使用方式、挂载位置和交互姿态都可成为 Cast Contrast。

## 7. Cast Tests

### Silhouette Test

角色统一转为黑剪影。核心角色应能主要依靠轮廓与体块区分。

### Thumbnail Test

缩到目标 UI/头像的真实使用尺度。检查 Icon、脸/发型、色块是否仍可读。

### Grayscale Test

去掉颜色后仍应保留主要角色区分，防止 Identity 全压在 hue。

### Lineup Test

统一镜头、统一地面、统一中性姿态排列。检查：

`Height Rhythm / Width Rhythm / Body Family / Silhouette Repetition / Prop Repetition / Costume Repetition / Face Repetition`

### Costume-off Test

在合理范围弱化外套/装备信息，检查角色 Body、Face、Hair 是否仍有 Identity。不是要求真的裸体生成。

### Variant Stress Test

给同一角色换 2–4 种明显不同的 Context Variant，例如 Formal / Winter / Space Suit / Festival。确认换装后仍是同一个人。

## 8. Pass / Fail

PASS 不是“每个人都不同”；正确状态是：

`Family Resemblance HIGH + Character Differentiation HIGH`

常见 Fail：

- `Family LOW / Difference HIGH`：像来自五个不同游戏；
- `Family HIGH / Difference LOW`：复制人换衣服；
- `Color Difference HIGH / Shape Difference LOW`：去色后全部失去区分；
- `Prop Difference HIGH / Body-Face Difference LOW`：拿掉武器就认不出角色。

## 9. 完成标准

- 阵容共享明确 IP DNA；
- 核心角色黑剪影不存在大面积模板化；
- 身体、脸、服装、道具至少有两层以上承担差异；
- 颜色不是唯一识别方式；
- 新增角色时可依据 Cast Matrix 判断“缺什么位置”，而不是继续随机加人。

## 10. 集合计数与冲突

角色卡网格分别报告 `card_slots / unique_character_ids / forms_or_states / duplicate_instances`。士兵、人群和卡槽实例不增加核心角色数；只满足群体功能的对象归入 NPC／Unit Template。

Cast Review 必须保留 `same asset multiple names / same name multiple assets / same face-body with costume swap / low-confidence identity` 四类候选。显示名不能覆盖 Identity Anchor，未裁决候选不能被强行合并或拆分来满足数量目标。
