# Character Identity Grammar

## 目标

把“same character”从模糊自然语言升级为可观察、可比较、可修复的身份结构。Identity 不是一个名字，而是一组跨图保持稳定的几何、比例、轮廓与高权重识别关系。

## 1. Hard Identity vs Soft Identity

### HARD IDENTITY

改动后高概率被认成另一个人的结构：

`Face Bounding Shape / Jaw Curve / Cheekbone Position / Eye Spacing / Eye Shape Family / Nose Structure / Mouth Width / Chin Length / Hairline / Core Hair Silhouette / Body Proportion Family / Signature Silhouette / Identity-defining Asymmetry`

### SOFT IDENTITY

可以变化但应维持同一人的范围：

`Expression / Minor Hair Strands / Makeup Intensity / Skin Microdetail / Minor Wear / Temporary Dirt / Small Accessories`

用户明确要求改 HARD 字段时，这是 Design Revision，不是普通 Image Edit。

## 2. Facial Geometry Anchor

至少用结构化语言冻结：

- Face Length : Width；
- Forehead Width / Height；
- Jaw Width / Curve；
- Chin Length / Width / Projection；
- Cheekbone Width / Height；
- Eye Size / Spacing / Tilt / Lid Shape；
- Brow Height / Angle / Thickness；
- Nose Bridge / Width / Tip；
- Philtrum Length；
- Mouth Width / Lip Shape；
- Hairline Shape；
- Ear Size / Exposure。

不要用“高级脸、御姐脸、可爱脸、欧美脸”替代几何事实。

## 3. Body Mass Distribution

除 Head-to-body Ratio 外，明确：

`Shoulder Width : Head Width / Ribcage Mass / Waist Width / Pelvis Width / Upper-vs-Lower Visual Mass / Arm Thickness / Leg Thickness / Limb Taper / Hand Scale / Foot Scale / Center of Visual Mass`

无需为了伪精确强行数字化；只有在参考资产支持时才给 ratio/range。没有证据时用相对关系：`shoulder clearly wider than pelvis / long narrow lower leg / compact torso`。

## 4. Silhouette Identity

缩成黑色剪影时检查：

`Head Shape / Hair Outer Contour / Shoulder Line / Torso Shape / Waist-Pelvis Transition / Arm-Leg Rhythm / Foot Shape / Carry Shape / Primary Prop`

至少 2 个高权重识别点应在中远景成立；只靠纹身、眼睛颜色、小首饰不算稳健 Identity。

## 5. Costume Identity

锁的是 Architecture：

`Layer Order / Collar-Neck Shape / Shoulder Structure / Torso Opening / Waist Logic / Hip Transition / Sleeve Shape / Leg Silhouette / Footwear Family / Carry System / Primary Color Blocks`

不要把纹理、所有缝线、每一个小挂件都升级为 Hard Identity。

## 6. Iconic Feature Budget

每个角色优先 1–3 个高权重 Icon，而不是堆十几个“记忆点”。Icon 应满足至少两个条件：

- Thumbnail 可读；
- Silhouette 或高对比色块可读；
- 与角色 Personality/Role/World 有关系；
- 可跨服装 Variant 保留或转换；
- 可在周边/头像/宣传图复用。

## 7. Recognition Distance

为角色定义至少三种尺度：

- `PORTRAIT`：脸部几何与头发身份；
- `FULL_BODY`：Body / Costume / Prop / Color Placement；
- `THUMBNAIL/SILHOUETTE`：大轮廓、颜色大块、Icon。

任何只在大特写有效的识别点都不能承担全局 Identity。

## 8. Identity Envelope

同一角色允许在一个范围内变化，而不是逐像素复制。建立 Envelope：

`Age Range if allowed / Weight Range if allowed / Hair Variation Range / Expression Range / Costume Variant Boundaries / Color Tolerance / Prop Presence Rules`

超出 Envelope 时必须进入 Design Revision，而不是用“same character”强压模型。

## 9. Identity Delta Review

比较新图与 Mother Truth 时，按以下顺序：

`Face Geometry → Hair Silhouette → Body Mass → Proportion → Costume Architecture → Color Placement → Primary Prop → Minor Surface`

最早出现明显偏移的层就是优先修复点。不要先修眼睫毛或布料纹理。

## 10. 完成标准

- 不依赖姓名仍能描述角色 Hard Identity；
- Portrait / Full-body / Thumbnail 分别有明确识别机制；
- Face、Body、Costume Architecture 可独立检查；
- Variant 不会因为换装把人换掉；
- 同一角色不需要依赖“上一张生成图”才能延续。

## 11. Alias 与跨图身份

身份 Authority 是稳定 `character_id`，不是显示名。`display_names[] / aliases[]` 只描述命名层；换名不能自动创建新角色，换脸、换体、换装或换色也不能在没有职能与身份锚时冒充新角色。低信息肖像缺少跨场景、跨用途或功能锚时标记 `LOW_IDENTITY_CONFIDENCE`，不得自行补全身份。

精确相同的图像 Hash 若绑定多个角色节点，必须登记 `SAME_ASSET_MULTIPLE_IDENTITIES`；同名异形登记 `SAME_NAME_MULTIPLE_ASSETS`。最终身份裁决结合 Face、Body、Silhouette、Costume Architecture、Prop、Function 与来源证据，不由文件名或单一相似度阈值决定。
