# ComfyUI / Diffusion — Game Concept Domain Delta

共享 Provider 方言：`../../../wxian-image-production/references/prompt-packs/comfyui-diffusion.md`。  
共享不变量：`.agents/skills/sicza-visual-director/references/prompt-adapter-invariants.md`。

## Domain Delta

- Gameplay 关系优先于风格 token；
- Character/Creature/Environment/Prop/UI 只投影已冻结事实；
- Control/Conditioning 的职责按 Reference Contract 分离；
- 原型 A/B 固定非目标变量，只比较目标 Gameplay/Visual delta。

## IP Character Input

长期 IP / 正式角色的真实 Reference 输入来自 `ip-character-handoff.json`。当前 Provider 是否具备可执行 Reference mapping 由 Registry 与 `wxian-image-production` Runtime 决定；本 Adapter 不拥有 Runtime capability Authority。

## Failure Return

- 设计事实 → Game Concept Authority；
- 视觉结构 → Visual Spec；
- Conditioning projection → 本 Adapter；
- Workflow capability → 执行层。
