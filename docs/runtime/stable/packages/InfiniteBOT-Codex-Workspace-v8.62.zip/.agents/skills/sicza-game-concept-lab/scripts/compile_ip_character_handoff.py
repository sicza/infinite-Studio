#!/usr/bin/env python3
"""Compile IP Character Binding into a mode-scoped live provider handoff.

Concrete-provider READY is emitted only after this compiler synchronously invokes
current Workspace wxian-image-production with the exact Mother References and the
actual execution mode. reference_to_image and image_to_image_edit are separate
contracts. Edit READY is additionally bound to the exact base image edit_target.
"""
from __future__ import annotations
import os as _bytecode_guard_os, sys as _bytecode_guard_sys
_bytecode_guard_sys.dont_write_bytecode = True
_bytecode_guard_os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import argparse
import hashlib
import json
import subprocess
import sys
import uuid
from pathlib import Path
from typing import Any

from validate_ip_character_runtime import (
    CONTRACT_VERSION,
    PRODUCTION_BINDABLE_STATUS,
    PROVIDERS,
    PROVIDER_CONTRACT_TEST_PRODUCER,
    PROVIDER_PRODUCER_RELATIVE_PATH,
    PINNED_RUNTIME_SHA256,
    TRUSTED_PROVIDER_BINDINGS,
    load_json,
    validate_runtime,
)

ALL_PROVIDERS = {"general"} | PROVIDERS
EXECUTION_MODES = {"reference_to_image", "image_to_image_edit"}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _not_ready(provider: str, status: str, risk: str, errors: list[str], code: int, mode: str | None = None) -> tuple[dict[str, Any], int]:
    result: dict[str, Any] = {
        "status": status,
        "contract_version": CONTRACT_VERSION,
        "provider": provider,
        "errors": errors,
        "identity_risk": risk,
        "image_conditioning_inputs": [],
    }
    if mode is not None:
        result["execution_mode"] = mode
    return result, code


def _request_context(system_path: Path, binding_path: Path, workspace_root: Path) -> tuple[Path, str]:
    system = system_path.resolve()
    binding = binding_path.resolve()
    root = workspace_root.resolve()
    if system.parent != binding.parent:
        raise ValueError("system and binding must be in the same contract directory")
    contract_dir = system.parent
    if contract_dir.name == "work":
        request = contract_dir.parent
    elif contract_dir.name == "concept-lab" and contract_dir.parent.name == "work":
        request = contract_dir.parent.parent
    else:
        raise ValueError("contracts must be in request work/ or work/concept-lab/")
    if root != request and root not in request.parents:
        raise ValueError("IP Character request is outside the selected Workspace")
    rel = request.relative_to(root)
    parts = rel.parts
    if len(parts) != 3 or parts[0].lower() != "requests":
        raise ValueError("IP Character production handoff requires requests/<type>/<name>/work contracts")
    return request, rel.as_posix()


def _workspace_reference_inputs(
    system: dict[str, Any],
    binding: dict[str, Any],
    workspace_root: Path,
) -> tuple[list[dict[str, Any]], list[str], list[str]]:
    refs = {r["reference_id"]: r for r in system.get("mother_references", []) if isinstance(r, dict) and "reference_id" in r}
    raw_bindings = binding.get("mother_reference_binding", [])
    if not raw_bindings:
        raise ValueError("Concrete-provider production handoff requires at least one Mother Reference Binding")

    ordered: list[tuple[int, dict[str, Any]]] = []
    for i, bound in enumerate(raw_bindings):
        slot = bound.get("provider_slot_or_order")
        rid = bound.get("reference_id")
        if not isinstance(slot, int) or isinstance(slot, bool) or slot < 1:
            raise ValueError(f"mother_reference_binding[{i}] {rid}: provider_slot_or_order must be a positive integer")
        ordered.append((slot, bound))
    ordered.sort(key=lambda x: x[0])
    slots = [x[0] for x in ordered]
    if slots != list(range(1, len(ordered) + 1)):
        raise ValueError(f"provider_slot_or_order must be contiguous 1..N; got {slots}")

    root = workspace_root.resolve()
    inputs: list[dict[str, Any]] = []
    workspace_paths: list[str] = []
    hashes: list[str] = []
    for slot, bound in ordered:
        rid = bound["reference_id"]
        ref = refs[rid]
        if ref["status"] not in PRODUCTION_BINDABLE_STATUS:
            raise ValueError(f"preflight invariant violated: unbindable status for {rid}")
        locator = ref["locator"]
        if locator.get("type") != "LOCAL_PATH":
            raise ValueError(
                f"Mother Reference {rid} uses {locator.get('type')!r}; current wxian-image-production provider bridge accepts LOCAL_PATH only"
            )
        raw = str(locator.get("value", ""))
        if not raw or Path(raw).is_absolute():
            raise ValueError(f"Mother Reference {rid} LOCAL_PATH must be a Workspace-relative path")
        path = (root / raw).resolve()
        if root != path and root not in path.parents:
            raise ValueError(f"Mother Reference {rid} path escapes Workspace")
        if not path.is_file():
            raise ValueError(f"Mother Reference {rid} is missing from Workspace: {raw}")
        rel = path.relative_to(root).as_posix()
        digest = sha256_file(path)
        expected = ref.get("sha256")
        if isinstance(expected, str) and expected.lower() != digest.lower():
            raise ValueError(f"Mother Reference hash mismatch: {rid}")
        inputs.append({
            "reference_id": rid,
            "locator": locator,
            "provider_workspace_path": rel,
            "resolved_local_path": str(path),
            "use_roles": bound["use_roles"],
            "preserve": bound.get("preserve", []),
            "authority": ref["authority"],
            "reference_version": ref["version"],
            "source": ref["source"],
            "provider_slot_or_order": slot,
            "sha256": digest,
        })
        workspace_paths.append(rel)
        hashes.append(digest)
    return inputs, workspace_paths, hashes


def _normalize_base_image(mode: str, base_image: str | None) -> str | None:
    if mode == "reference_to_image":
        if base_image:
            raise ValueError("reference_to_image handoff must not bind a base_image")
        return None
    if mode == "image_to_image_edit":
        if not isinstance(base_image, str) or not base_image or Path(base_image).is_absolute():
            raise ValueError("image_to_image_edit handoff requires a Workspace-relative --base-image")
        return base_image
    raise ValueError(f"unsupported execution mode: {mode}")


def _invoke_live_provider_contract_test(
    provider: str,
    workspace_root: Path,
    request_rel: str,
    workspace_paths: list[str],
    mode: str,
    base_image: str | None,
) -> tuple[dict[str, Any] | None, list[str], int]:
    root = workspace_root.resolve()
    producer = (root / PROVIDER_PRODUCER_RELATIVE_PATH).resolve()
    if not producer.is_file():
        return None, [f"wxian-image-production provider contract-test producer is unavailable: {producer}"], 4
    api = root / ".agents/skills/image-generation-api/scripts/generation_api.py"
    gate = root / ".agents/skills/wxian-image-production/scripts/request_reference_gate.py"
    missing = [str(p) for p in (api, gate) if not p.is_file()]
    if missing:
        return None, ["provider runtime dependency missing: " + ", ".join(missing)], 4
    direct_before = {
        "producer_sha256": sha256_file(producer),
        "generation_api_sha256": sha256_file(api),
        "request_reference_gate_sha256": sha256_file(gate),
    }
    drift = [f"{k}: got {direct_before[k]}, expected {v}" for k, v in PINNED_RUNTIME_SHA256.items() if direct_before.get(k) != v]
    if drift:
        return None, [f"provider runtime does not match the pinned v{CONTRACT_VERSION} integration contract: " + "; ".join(drift)], 4

    challenge = uuid.uuid4().hex
    cmd = [
        sys.executable, str(producer),
        "--provider", provider,
        "--workspace-root", str(root),
        "--request", request_rel,
        "--mode", mode,
        "--challenge", challenge,
    ]
    if base_image:
        cmd += ["--base-image", base_image]
    for path in workspace_paths:
        cmd += ["--reference", path]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=30, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return None, [f"provider contract-test invocation failed: {exc}"], 4
    try:
        result = json.loads(proc.stdout)
    except Exception:
        return None, [f"provider contract-test returned invalid JSON (exit={proc.returncode}): {proc.stderr.strip()}"], 4
    if not isinstance(result, dict):
        return None, ["provider contract-test JSON root must be an object"], 4
    if proc.returncode != 0 or result.get("status") != "PASS":
        reason = result.get("reason") or result.get("reason_code") or proc.stderr.strip() or "provider contract-test did not PASS"
        code = 4 if result.get("status") == "UNVERIFIED" or proc.returncode == 3 else 3
        return result, [str(reason)], code

    expected = TRUSTED_PROVIDER_BINDINGS.get(provider)
    errors: list[str] = []
    checks = {
        "contract_version": CONTRACT_VERSION,
        "producer": PROVIDER_CONTRACT_TEST_PRODUCER,
        "provider": provider,
        "mode": mode,
        "runtime_id": expected["runtime_id"] if expected else None,
        "adapter_id": expected["adapter_id"] if expected else None,
        "mapping_id": expected["mapping_id"] if expected else None,
        "challenge": challenge,
    }
    for field, wanted in checks.items():
        if result.get(field) != wanted:
            errors.append(f"provider contract-test {field} mismatch: got {result.get(field)!r}, expected {wanted!r}")
    ri = result.get("reference_input") if isinstance(result.get("reference_input"), dict) else {}
    if expected:
        if mode not in expected.get("supported_modes", []):
            errors.append("provider contract-test mode is not registered for this provider")
        if expected.get("max_inputs_semantics") != "TOTAL_IMAGES_INCLUDING_BASE_IMAGE":
            errors.append("provider registry max_inputs semantics mismatch")
        if ri.get("slot_mode") != expected["slot_mode"]:
            errors.append("provider contract-test slot_mode mismatch")
        if ri.get("accepted_locator_types") != expected["accepted_locator_types"]:
            errors.append("provider contract-test accepted_locator_types mismatch")
        if ri.get("max_inputs") != expected["max_inputs"]:
            errors.append("provider contract-test max_inputs mismatch")
        if ri.get("max_inputs_semantics") != "TOTAL_IMAGES_INCLUDING_BASE_IMAGE":
            errors.append("provider contract-test max_inputs semantics mismatch")
    run = result.get("test_run") if isinstance(result.get("test_run"), dict) else {}
    if run.get("mode") != mode:
        errors.append("provider contract-test test_run mode mismatch")
    if run.get("mother_reference_paths") != workspace_paths:
        errors.append("provider contract-test observed Mother Reference path/order mismatch")
    provider_paths = run.get("provider_workspace_paths")
    if not isinstance(provider_paths, list) or provider_paths[:len(workspace_paths)] != workspace_paths:
        errors.append("provider contract-test did not preserve Mother References as ordered reference prefix")
    if not isinstance(run.get("observed_reference_inputs"), int) or run.get("observed_reference_inputs") < len(workspace_paths):
        errors.append("provider contract-test observed fewer reference inputs than bound Mother References")
    if run.get("endpoint_path") != "/v1/images/edits":
        errors.append("provider contract-test did not resolve /v1/images/edits")
    if mode == "reference_to_image":
        if run.get("base_image_path") is not None or run.get("base_image_sha256") is not None:
            errors.append("reference_to_image evidence unexpectedly contains an edit_target")
    else:
        if run.get("base_image_path") != base_image:
            errors.append("image_to_image_edit evidence base_image path mismatch")
        if not isinstance(run.get("base_image_sha256"), str):
            errors.append("image_to_image_edit evidence base_image hash is missing")
        expected_input_paths = [base_image] + list(provider_paths or [])
        if run.get("provider_input_paths") != expected_input_paths:
            errors.append("image_to_image_edit provider input order is not base_image -> references")

    # Bind the producer report to the exact runtime bytes invoked in this call.
    runtime = result.get("runtime_binding") if isinstance(result.get("runtime_binding"), dict) else {}
    direct_hashes = {
        "producer_sha256": sha256_file(producer),
        "generation_api_sha256": sha256_file(api),
        "request_reference_gate_sha256": sha256_file(gate),
    }
    for field, digest in direct_hashes.items():
        if runtime.get(field) != digest:
            errors.append(f"provider contract-test runtime binding mismatch: {field}")
        if digest != PINNED_RUNTIME_SHA256.get(field):
            errors.append(f"provider runtime changed during contract-test: {field}")
    if errors:
        return result, errors, 4
    return result, [], 0


def compile_handoff(
    system_path: Path,
    binding_path: Path,
    provider: str,
    workspace_root: Path | None,
    asset_root: Path | None = None,
    mode: str = "reference_to_image",
    base_image: str | None = None,
) -> tuple[dict[str, Any], int]:
    if provider not in ALL_PROVIDERS:
        raise ValueError(f"unsupported provider {provider!r}; expected one of {sorted(ALL_PROVIDERS)}")
    if mode not in EXECUTION_MODES:
        raise ValueError(f"unsupported execution mode {mode!r}; expected one of {sorted(EXECUTION_MODES)}")
    try:
        normalized_base = _normalize_base_image(mode, base_image)
    except ValueError as exc:
        return _not_ready(provider, "FAIL", "INVALID_EXECUTION_MODE_BINDING", [str(exc)], 3, mode)

    effective_asset_root = workspace_root if workspace_root is not None else asset_root
    preflight = validate_runtime(system_path, binding_path, effective_asset_root, production=True)
    if preflight["status"] != "PASS":
        return _not_ready(provider, "FAIL", "INVALID_IP_CHARACTER_BINDING", ["IP Character Runtime preflight failed"] + preflight["errors"], 2, mode)

    if provider == "general":
        return _not_ready(
            provider, "REQUIRES_PROVIDER_ADAPTER", "PROVIDER_NOT_RESOLVED",
            ["A concrete provider plus live wxian-image-production contract-test is required before production."], 0, mode,
        )
    if provider not in TRUSTED_PROVIDER_BINDINGS:
        return _not_ready(
            provider, "UNVERIFIED", "PROVIDER_ADAPTER_UNAVAILABLE",
            [f"No live wxian-image-production reference adapter is registered for {provider!r}."], 4, mode,
        )
    if workspace_root is None:
        return _not_ready(
            provider, "UNVERIFIED", "PROVIDER_RUNTIME_UNRESOLVED",
            ["Concrete-provider READY requires --workspace-root so the real wxian-image-production producer can be invoked."], 4, mode,
        )

    try:
        _request_root, request_rel = _request_context(system_path, binding_path, workspace_root)
        system = load_json(system_path, "system")
        binding = load_json(binding_path, "binding")
        inputs, workspace_paths, hashes = _workspace_reference_inputs(system, binding, workspace_root)
    except ValueError as exc:
        return _not_ready(provider, "FAIL", "INVALID_PROVIDER_REFERENCE_INPUT", [str(exc)], 3, mode)

    capability = TRUSTED_PROVIDER_BINDINGS[provider]
    minimum_total_inputs = len(inputs) + (1 if mode == "image_to_image_edit" else 0)
    if minimum_total_inputs > capability["max_inputs"]:
        return _not_ready(
            provider, "FAIL", "PROVIDER_REFERENCE_LIMIT_EXCEEDED",
            [f"provider allows at most {capability['max_inputs']} total input images including base_image, got at least {minimum_total_inputs}"], 3, mode,
        )

    evidence, errors, evidence_code = _invoke_live_provider_contract_test(
        provider, workspace_root, request_rel, workspace_paths, mode, normalized_base
    )
    if errors:
        status = "UNVERIFIED" if evidence_code == 4 else "FAIL"
        risk = "PROVIDER_RUNTIME_UNVERIFIED" if evidence_code == 4 else "PROVIDER_REFERENCE_MAPPING_INVALID"
        return _not_ready(provider, status, risk, errors, evidence_code, mode)

    run = evidence.get("test_run", {}) if isinstance(evidence, dict) else {}
    observed_hashes = run.get("mother_reference_sha256")
    if observed_hashes != hashes:
        return _not_ready(
            provider, "UNVERIFIED", "PROVIDER_RUNTIME_UNVERIFIED",
            ["provider contract-test observed reference byte hashes do not match bound Mother References"], 4, mode,
        )

    edit_target = None
    if mode == "image_to_image_edit":
        edit_target = {
            "role": "edit_target",
            "provider_workspace_path": run.get("base_image_path"),
            "sha256": run.get("base_image_sha256"),
        }
        if edit_target["provider_workspace_path"] != normalized_base or not isinstance(edit_target["sha256"], str):
            return _not_ready(
                provider, "UNVERIFIED", "PROVIDER_RUNTIME_UNVERIFIED",
                ["provider contract-test did not bind the exact edit_target"], 4, mode,
            )

    order_rule = (
        "Mother Reference prefix first, then other must_upload entries in reference-plan order"
        if mode == "reference_to_image"
        else "base_image edit_target first, then Mother Reference prefix, then other must_upload entries in reference-plan order"
    )
    result = {
        "status": "READY",
        "contract_version": CONTRACT_VERSION,
        "provider": provider,
        "execution_mode": mode,
        "character_id": binding["character_id"],
        "system_version": binding["system_version"],
        "variant_overrides": binding.get("variant_overrides", {}),
        "reference_contract_ref": binding.get("reference_contract_ref"),
        "image_contract_ref": binding.get("image_contract_ref"),
        "identity_risk": None,
        "request": request_rel,
        "contract_binding": {
            "system_sha256": sha256_file(system_path.resolve()),
            "binding_sha256": sha256_file(binding_path.resolve()),
        },
        "execution_contract": {
            "mode": mode,
            "edit_target": edit_target,
            "provider_input_order": run.get("provider_input_paths"),
            "provider_input_sha256": run.get("provider_input_sha256"),
            "max_inputs_semantics": "TOTAL_IMAGES_INCLUDING_BASE_IMAGE",
        },
        "provider_runtime_evidence": evidence,
        "reference_plan_requirement": {
            "mother_reference_prefix": workspace_paths,
            "role": "character-identity",
            "analysis": "identity-lock",
            "use": "must_upload",
            "generation_api_order_rule": order_rule,
        },
        "image_conditioning_inputs": inputs,
        "binding_rule": "Mother References MUST reach the real provider as identity-conditioning inputs. In image_to_image_edit, base_image is edit_target only and MUST NOT become Mother Authority.",
    }
    return result, 0


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--system", required=True, type=Path)
    ap.add_argument("--binding", required=True, type=Path)
    ap.add_argument("--provider", required=True, choices=sorted(ALL_PROVIDERS))
    ap.add_argument("--mode", choices=sorted(EXECUTION_MODES), default="reference_to_image")
    ap.add_argument("--base-image", default=None, help="Workspace-relative edit target; required only for image_to_image_edit")
    ap.add_argument("--workspace-root", type=Path, default=None, help="Workspace containing wxian-image-production and image-generation-api")
    ap.add_argument("--asset-root", type=Path, default=None, help="Non-provider preflight asset root; concrete production normally uses --workspace-root")
    ap.add_argument("--out", required=True, type=Path)
    args = ap.parse_args()

    try:
        result, code = compile_handoff(
            args.system, args.binding, args.provider, args.workspace_root, args.asset_root,
            mode=args.mode, base_image=args.base_image,
        )
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
