---
name: sicza-game-concept-lab
description: 从极少量游戏设定、玩法参考、视觉参考或已有资产出发，完成高差异游戏方向发散、关系／系统驱动的素材生态展开、人物/IP/怪物/场景/玩法原型设计，并默认调用图片 API 验证各方向，交付原图、逐图完整 Prompt 与项目化互动 HTML。用于“从0做新游戏方向、画风玩法入口测试、人物×场景×玩法概念、角色／怪物／场景差异设计、把成熟玩法变异到新世界”等；用户明确只要 Prompt 时保留 Prompt-only，概念已定且只要单次成图/改图使用 wxian-image-production，发行 KV/Store 包装方向使用 wxian-visual-packaging。
---

# 游戏概念实验室

作为 Primary 时先执行 `$workspace-governance consume-personal-context --request <request> --consumer sicza-game-concept-lab`；阻断则停止。作为辅助能力时继承调用方已验证的 Primary Context，不重复消费。

## 目标

把极少量输入转化为：

**有创意、有产品差异、设计具体、可直接生图、可验证、可持续迭代的游戏视觉原型。**

当目标是案例级创意组合时，Lab 的核心产物是多个方向的创意发散、方向独有素材生态、逐图完整 Prompt、真实生成原图与项目化互动 HTML。除非用户明确要求 `Prompt-only`，图片生成与 HTML 验证都是完成前提。Prompt 是创意的执行合同，不是用文字长度替代创意。

优先级：

`Creative Quality > Product Difference > World × Gameplay > Design Causality > Concrete Design > Gameplay Readability > Prototype Testability > Prompt Execution`

“可生图”是设计终点，不是创意起点；方向选择以创意质量与产品差异为准。

## 1. 入口模式

先判断当前真正任务，不默认从零发散。

### DISCOVER

用户只有 Premise 或少量世界设定，需要从零寻找产品方向。

`Premise → Research Fuel → Creative Discovery → Direction Seeds → Direction Prototypes → Prototype Realization → Test Prompts`

### DEVELOP

用户已经选定一个方向，需要把它做成具体人物、怪物、场景、玩法或视觉原型。

`Selected Prototype → Freeze Production Anchors → Concrete Design → Image Contract → Prompt`

该模式只深化已选方向。

按交付规模选择 `scope_profile`：

- `PROTOTYPE`：验证单方向，通常只需1–3类测试资产；
- `PORTFOLIO`：多角色、多地点、多状态、多系统或完整概念包；
- `VERTICAL_SLICE`：证明一个最小可体验闭环及其关键状态序列。

`PORTFOLIO / VERTICAL_SLICE` 必须执行 Content Architecture Pass，不能把单图合同重复很多次当作内容架构。

`PORTFOLIO` 内部再选择形态：

- `MULTI_DIRECTION_DIVERGENCE`：3–5 个高差异方向分别形成素材与 Prompt 组合；
- `SINGLE_DIRECTION_DEPTH`：一个已选方向形成跨资产、状态、事件和系统的深度 Prompt 组合；
- `HYBRID_PORTFOLIO`：先完成多方向差异，再深化一个方向。

选择扩展发动机：`RELATIONSHIP_DRIVEN / SYSTEM_DRIVEN / HYBRID`。这是 Lab 的专业判断，不要求用户填写技术表格。用户明确授权自主创作或收敛时，记录为 Lab 决策及其授权来源后继续，不把 Lab 选择伪装成用户事实。

### TRANSFORM

用户提供成熟 Gameplay、游戏、真实行业系统或产品参考，希望迁移/变异到当前世界。

`Reference → Grammar / Relationship Extraction → Mutation → World-bound Prototype`

输出必须改变底层 Grammar/Relationship，并重新绑定当前世界。

### VISUALIZE / ITERATE

已有角色、场景、Gameplay、参考图或生成结果，只做继续生产、局部修改或失败修正。

`Existing Truth → Reference Contract → Change Scope → Image Contract → Generate/Edit Prompt`

长期 IP / 多图复用角色在 VISUALIZE / ITERATE 中先恢复 `ip-character-system.json + ip-character-binding.json`，执行 production preflight，再将 Mother Reference Binding 编译为真实 `image_conditioning_inputs`。

已锁设计保持 FROZEN，除非当前 Change Scope 明确重开。

## 2. Context & Research Gate

先收集可用事实：

`当前用户要求 + Hard Locks + Project Brief + Visual Baseline + 已有项目资产/决策 + 用户 Reference`

正式 Visual Baseline 存在且进入本次判断时，写 canonical `work/baseline-consumption.json`，machine key=`game-concept-lab`，并通过 `$wxian-visual-baselines` 的 request-bound validator。纯文字／零视觉资产的概念发现不伪造 Baseline，也不得因没有 Baseline 被阻断；实际图片生产仍由对应 Primary 的视觉门禁负责。

已有信息直接复用。

以下情况在创意前必须研究：

- Premise 依赖真实地点、行业、技术、职业、基础设施；
- 真实功能/约束能实质改善 Gameplay 或视觉设计；
- 用户给了具体 Gameplay / 产品参考，且需要理解其真实机制；
- 用户明确要求互联网研究；
- 当前模型能力影响执行且 Model Profile 缺失、过期或行为冲突。

事实来源优先官方/一手资料；生产实践同时吸收成熟社区经验。内部把研究结果区分为 `FACT / PRACTICE / INSPIRATION / UNVERIFIED`。

研究最终压缩成 `Research Fuel`：真实功能、关系、约束、失败方式、专业角色、空间结构、成熟实践及其创意含义，并直接进入设计。

需要系统互联网研究时调用 `$wxian-conducting-internet-research` 作为当前 request 的辅助能力，不创建第二 request。

## 3. Artifact Lifecycle

不同产物拥有不同生命周期与权威。

### EPHEMERAL

只用于推理，可在产生下一层后丢弃：

`Research Fuel / Premise Map / Creative Levers / Direction Seeds / Rejected Alternatives`

### PROVISIONAL

用于候选探索，必须具体到可生成，但在用户选择前允许变化：

`Direction Prototype / Prototype Spec / Test Image Contract / Test Prompt`

世界观-only 输入中的产品类型、玩家代理、体验目标、核心循环和内容规模先记为 `ASSUMED`，不能作为已确认产品事实。

这五类关键决定使用稳定假设 ID：`PLAYER_AGENT / PRODUCT_TYPE / TARGET_EXPERIENCE / CORE_LOOP / CONTENT_SCOPE`。不得通过省略记录绕过 Authority；`PORTFOLIO / VERTICAL_SLICE` 完成前全部必须有 `CONFIRMED` 状态和证据。

### FROZEN

用户选中方向后的长期设计事实：

`IP DNA Anchor / Cast Architecture / Character Identity Anchor / Variant Grammar / Mother Reference Manifest / Character Anchor / Creature Anchor / Environment Anchor / Gameplay Anchor / Style Anchor / UI Anchor`

`PORTFOLIO / VERTICAL_SLICE` 还冻结 `Product Blueprint / Content Graph / Coverage Plan`；其版本变化必须使下游 Visual Spec／Prompt Binding 失效。

FROZEN 只在用户明确改设计，或 Review 证明上游设计错误时更新。

### BOUND

只约束当前这一次生成/编辑：

`Mother Reference Binding / Reference Contract / Change Scope / Image Contract`

新图片可以建立新的 BOUND Contract，同时继续复用同一 FROZEN Anchor。

### COMPILED

从上游事实编译出的执行产物：

`Canonical Prompt / Target Model Prompt / ComfyUI Conditioning Instructions`

COMPILED 不拥有独立设计权威；上游变化后重新编译，不手工继承过时 Prompt。

### OBSERVED

真实生成/测试结果：

`Generated Image / Generation Review / Eval Result`

Observed 用于暴露问题；Production Truth 仍由上游 Authority 更新。

## 4. Reference Routing

只加载当前阶段需要的 Reference。

### DISCOVER — Creative Discovery

必读：`references/01-creative-operators.md`。需要案例级、多方向或素材丰富度时同时读取 `references/16-direction-material-divergence.md`，在 Direction Seed 阶段执行 Material Fertility 与成对素材差异检查。

按需：

- 真实行业/跨域系统：`02-cross-domain-creative-systems.md`
- Gameplay Reference：`03-gameplay-grammar-library.md` + `04-gameplay-mutation.md`

内部产生 6–12 个 Direction Seeds，用户默认只看到 3–5 个真正不同的 Direction Prototypes。

### DISCOVER — Prototype Realization

方向形成后进入 Prototype Realization，按需读取：

- 人物：`05-character-design.md`；如果方向将成为长期角色/IP、存在多角色阵容或后续多图复用，再读 `05a-ip-character-system.md` + `05b-character-identity-grammar.md`，3 个以上核心角色再读 `05c-cast-architecture.md`
- Creature：`06-creature-design.md`
- 场景/玩法空间：`07-environment-gameplay-space.md`
- 画风/比例/Camera：`08-visual-style-proportion-camera.md`
- Gameplay Screen/UI：`10-gameplay-screen-ui.md`

每个候选生成 `Prototype Spec (PROVISIONAL)`，而不是提前建立全部 Production Anchors。

### DEVELOP

- Character（单次/临时）：05 + 08 + 11
- Character（长期 IP / 多图复用 / 角色设定）：05 + 05a + 05b + 08 + 09 + 11
- Character Cast（3+ 核心角色）：在上条基础上加 05c
- Creature：06 + 08 + 11
- Environment：07 + 08 + 11
- Gameplay Screen：07 + 10 + 11
- 多图内容包／完整概念集：在对象 Reference 之外必读 `14-product-content-architecture.md` + `15-portfolio-coverage-and-dedup.md`
- 案例级 Prompt 组合：再读 `16-direction-material-divergence.md` + `17-prompt-portfolio-composition.md`

涉及参考图时加 09；目标模型确定后再加载对应 Adapter/Profile。

### TRANSFORM

默认 03 → 04；需要真实行业关系时加 02。产生新的 Direction Prototype 后进入 Prototype Realization。

### VISUALIZE / ITERATE

- 普通多参考生成：09 + 11 + Adapter
- 长期 IP / 正式角色继续生产：05a + 05b + 09 + 11 + Adapter；必须恢复 Frozen System/Binding，preflight PASS 后再编译 Provider Handoff
- 普通局部 Edit：09 + 11 + Adapter
- Pose/人体结构判断：再加 05 的 Pose & Anatomy 部分
- 场景结构判断：再加 07
- Gameplay/UI：再加 10
- Style/Camera：再加 08
- 用户返回失败生成结果并要求诊断：才加载 12

创意已冻结时默认不加载 01–04；Review 指向创意/玩法根因时再恢复。

## 5. Prototype Spec

每个第一轮方向建立轻量但可直接生成的：

`STATUS = PROVISIONAL`

至少包括：

### Direction

`Product Type / Player Fantasy / Core Verb / World Rule / Core Reward / World Dependency`

### Character Core

有角色时必须具体到：

`Exact Age / Body / Head-to-body Ratio / Face / Hair / Costume Architecture / Primary Functional Prop / World-specific Hook`

重要外观需要能追溯到世界、Gameplay、职业、Camera 或视觉需求；武器只在 Gameplay 需要时设计。

### Environment Core

`Environment Identity / Original Function / Current Function / Gameplay Geometry / Landmark / Lighting / Camera`

### Gameplay Core

`Player Action / Target / System Response / Visible State Delta / Reward / Progression`

进入 `VERTICAL_SLICE` 或声称规则已闭合时，还必须写：

`Input / Known Information / Hidden Information / Legal Action / State Transition / Time or Turn / End Condition / Failure or Exit / Recovery / Next-run Difference / Dangerous Assumption / Falsification Test`

### Visual Core

`Art Direction / Proportion / Camera / Environment Scale / Prop Scale / NPC Density / Material & Lighting Logic`

默认首轮测试：`Character Test / Hero Environment / Gameplay Hero Screen`。完整入口测试默认选择 3–5 个高差异方向，每方向各生成上述 3 张主证据图，共 9–15 张；某类图确实无意义时换成最能证明产品价值的资产并记录替代理由。角色、怪物、场景、道具、建筑或玩法界面等单对象差异设计，默认 3–5 个方向、每方向 1 张主图，共 3–5 张；设定集、结构拆解或状态变化只按需求增补，不用重复镜头凑数。

## 6. Selection → Production Anchors

用户选中 Prototype 后才进入 FROZEN。按当前对象建立：

- 长期角色/IP：`IP DNA Anchor / Character Identity Anchor / Variant Grammar / Mother Reference Manifest`；3+ 核心角色再建立 `Cast Architecture`。完整方法与机器产物见 `references/05a-ip-character-system.md`、`05b-character-identity-grammar.md`、`05c-cast-architecture.md`。
- 临时角色：`Character Anchor = Identity / Exact Age / Face / Hair / Body / Proportion / Costume Architecture / Primary Functional Prop / Signature Color Placement / World-specific Hook`。
- Creature：`Gameplay Function / Habitat / Behavior / Locomotion / Anatomy / Silhouette / Surface`。
- Environment：`Identity / Macro Layout / Function Zones / Landmark / Navigation / Vertical Structure / Material Family / Lighting Logic / Scale`。
- Gameplay：`Primary Verb / Target / Constraint / System Response / Visible State Delta / Reward / Progression / Core Loop`。
- Style：`Realism / Proportion / Shape Language / Camera Family / Material Strategy / Color Structure / Lighting Logic / Detail Density`。
- UI（仅需要时）：`UI Family / Persistent Information / Contextual Information / Hierarchy / Safe Areas / Interaction Feedback`。

长期角色/IP 的 canonical 文件固定为：

```text
work/ip-character-system.json
work/ip-character-binding.json
work/ip-character-preflight.json
work/ip-character-handoff.json   # 仅实际生图/编辑时
```

执行顺序与 Provider/Mode 边界由 `05a-ip-character-system.md` 和对应脚本定义。FROZEN 事实变化后重新绑定/编译；OBSERVED 图片不拥有上游 Authority。

## 6.5 Content Architecture Pass

所有 scope 先建立最小 `work/concept-lab/product-blueprint.json`，把产品因果、Authority 与关键假设结构化。`scope_profile=PORTFOLIO | VERTICAL_SLICE` 时再读取 `14-product-content-architecture.md` 与 `15-portfolio-coverage-and-dedup.md`，建立完整四件套：

```text
work/concept-lab/product-blueprint.json
work/concept-lab/content-graph.json
work/concept-lab/coverage-plan.json
work/concept-lab/content-audit.json
```

Product Blueprint 记录产品因果与范围；Vertical Slice 的 `experience_loop` 必须用 entry/exit State 绑定首尾并保持每个相邻 Step 状态连续；Content Graph 用稳定 ID 管理内容及关系；Coverage Plan 定义必须证明的槽位；Content Audit 重算证据、重复、冲突与完成状态。

案例级创意任务在四件套之外建立：

```text
work/concept-lab/prompt-portfolio.json
work/final/prompts/**/*.md
```

其中 Manifest 只承担机器绑定，Markdown Prompt 是用户可直接使用的正式成果。多方向先做 Material Fertility 和 Direction Material DNA，再建立方向各自的 Graph/Coverage；不能先复制一批 Prompt，再用不同方向名称包装。单方向深度与多方向发散分别使用 `SINGLE_DIRECTION_DEPTH` 和 `MULTI_DIRECTION_DIVERGENCE`，需要二者时使用 `HYBRID_PORTFOLIO`。

每张正式证据额外绑定：

`batch_id / evidence_kind / path / byte_size / width / height / preview_path / sha256 / graph_refs / coverage_refs / coverage_claims / parent_asset_or_screen_id / variant_axes / semantic_delta / counting_class / counting_delta / event_delta / facts / judgements / recommendations / unknowns / image_specific_mechanisms / regions`

所有 `NEW_*` 必须用结构化 `counting_delta` 绑定对应 Graph 节点并证明类别允许的语义轴；`NEW_EVENT` 还必须用 `event_delta` 证明 Cause、Action 或 Consequence至少一项真实改变。只换镜头、色光、特效、表情、裁切、排版、语言、脸或服装必须记为表现变化，不能依靠自由文本宣称语义新增。产品方向另由 `direction_inventory` 验证 Player Agent、Product Type、Core Loop 或 World Causality 的真实变化。

没有 Coverage 槽位的探索图可以保留，但不能提高正式覆盖率。显示名不是身份键；卡牌格数、士兵实例数和画面人头数不等于独立角色数。

## 7. Reference Contract

用户给 Gameplay 录屏、广告/PV 或其他视频 Reference 时，在当前 request 内调用 `$wxian-video-source-analysis`，自动拆时间线、关键事件和代表帧；成熟 Gameplay 的 Grammar / Must-preserve Fun 基于已验证 Observation 与受证据支持的 Inference。

用户给 Reference 时读取 `09-reference-decomposition.md`。长期 IP/正式角色优先绑定 Mother Reference Manifest；临时外部参考再进入当前 BOUND Reference Contract。每张图必须定义：

`ROLE / PRESERVE / BORROW / REPLACE / IGNORE / AUTHORITY`

默认权威：

`User Explicit Lock > Frozen IP/Character Anchor > Mother Reference Role Authority > Role-specific Reference > Gameplay/Environment Truth > Style Reference > Pose/Composition Reference > Previous Generated Image > Model Default`

“综合参考所有图片”不是可接受的 Reference Contract。

## 8. Change Scope

编辑已有资产前建立：

`LOCKED / EDITABLE / DERIVED CHANGE / FORBIDDEN`

修改范围严格跟随 Change Scope；正确层保持 LOCKED。

## 9. Image Contract

任何正式生成或编辑前读取 `11-image-contracts.md` 并冻结当前图片的 BOUND Contract：

`Asset Type / Purpose / Aspect Ratio / Primary Read / Subject Count / Position / Scale / Interaction Point / Gameplay Change Area / Foreground / Midground / Background / Reading Direction / Camera / Perspective / Framing / Pose/Action / Must Show / Must Preserve / Must Not Add`

多图范围再追加 `Content Graph Refs / Coverage Refs / Parent ID / Variant Axes / Semantic Delta / Counting Class`，并在 Visual Spec `authority_trace` 中绑定当前 Product Blueprint；Portfolio 还必须绑定 Content Graph 与 Coverage Plan。

模型不负责自己决定核心构图。

## 9.5 Visual Director Pass

Image Contract 冻结后、Prompt Compilation 之前读取 `references/13-visual-director-bridge.md`，调用 `$sicza-visual-director` 把产品/玩法事实编译为可见的 `Visual Spec`。

- 从零原型图：`CREATE`；
- 已有资产重组/改图：`TRANSFORM`；
- 已批准方向的局部修正：`ITERATE`。

Authority 保持分层：本 Skill 拥有游戏概念、Gameplay Grammar、Mutation、Prototype、Production Anchor 与 Image Contract；Visual Director 拥有其视觉编译职责。长期 IP / 正式角色的 Mother Reference Binding 保持为独立 Identity Conditioning Authority，并在 Visual Spec 之后继续进入 Provider Handoff。

## 10. Prompt Compilation

先读取 `.agents/skills/sicza-visual-director/references/prompt-adapter-invariants.md`，再生成 Prompt Compilation 结果。它只能表达：

`Prototype Spec or Frozen Anchors + Mother Reference Binding(if applicable) + Reference Contract + Change Scope + Image Contract + Visual Spec`

Prompt Compilation 只投影已存在的上游事实。Mother Reference Binding 的 Preserve/Role 可进入文本语义；真实图像输入继续通过 `ip-character-handoff.json.image_conditioning_inputs` 进入 Provider/Workflow。

案例级 Prompt Portfolio 按 `references/17-prompt-portfolio-composition.md` 批量编译。每个正式 Coverage 槽分别产生完整、自足、可复制执行的 Canonical Prompt；禁止输出关键词骨架、待填模板或依赖“沿用上一条”的残缺 Prompt。相同角色、地点和建筑的身份／拓扑锁必须重述到当前 Prompt，差异只开放当前 Semantic Delta。

如果用户没有指定目标模型，不为了模型选择打断创意流程：输出 `TARGET = GENERAL` 的自然语言 Canonical Prompt。用户之后指定模型时只重新编译 Adapter，不重做上游设计。

目标模型已解析时，下列文件只提供 Game Concept domain delta；通用 Provider 方言统一引用 `wxian-image-production/references/prompt-packs/`：

1. GPT Image → `references/prompt-adapters/gpt-image.md`
2. Gemini / Nano Banana → `references/prompt-adapters/gemini-nano-banana.md`
3. ComfyUI / Diffusion → `references/prompt-adapters/comfyui-diffusion.md`

当前易变模型能力从 `references/model-profiles/` 读取。Profile `Verified At` 超过 30 天，或用户询问当前/最新能力、模型标识变化、真实行为冲突时，重新核对官方资料。

## 11. Review

用户返回真实生成结果并要求判断/修正时读取 `12-generation-review.md`。`PORTFOLIO / VERTICAL_SLICE` 每10–20项及全局收口时也读取该文件执行内容审计；这类审计可以在没有生成 API 结果时验证计划、资产图谱、重复和一致性，但不能声称验证了图像质量或玩法体验。长期角色/IP必须额外检查 Identity Delta；3+ 核心角色的阵容图按 `05c-cast-architecture.md` 执行 Silhouette / Thumbnail / Grayscale / Lineup / Variant Stress Test。

当 `portfolio_output=PROMPT_MARKDOWN | BOTH` 时，producer 完成全部 Markdown 后必须开启新的独立语义 reviewer。reviewer 与 producer 分离，二者使用规范化小写 actor ID，不能靠大小写、尾空格或零宽字符伪造分离；reviewer 完整阅读每条 Prompt，不得抽样。逐条判断主体基数与角色、因果和素材具体度、视觉机制有效性、完整可执行性、伪丰富度／重复风险，并对全部已批准方向对执行真实 Swap Test。结果写入 `work/concept-lab/prompt-semantic-review.json` 与 canonical `work/final/prompt-semantic-review.md`，绑定当前 Portfolio Manifest SHA 和每条 Prompt SHA；交付的 review report 必须就是 JSON 绑定的同一文件。机器 Gate 只检查身份分离声明、全量覆盖、Hash、Swap Test 结构和 PASS 状态，不把字段、关键词、正则或 producer 自签 Hash 冒充创意质量证明。

按最早因果层定位：

`Creative → Gameplay Grammar/Mutation → IP DNA/Cast/Character Identity → Character/Pose → Creature → Environment → Image Contract → Visual Director/Visual Spec → Reference Control → Gameplay Screen/UI → Adapter/Model Execution`

修最早错误层，不通过加长 Prompt 掩盖上游问题。

每张 READY Prompt 均通过 `work/generation-plan.json` 调用 `$image-generation-api`，原图存入 `work/final/originals/`，回执绑定 Prompt、计划项与调用参数。只有 `request.md` 明确要求 Prompt-only 且 `prompt-only-authorization.json` 绑定其原文和 Hash 时可跳过；producer 自报无效。调用失败不得用占位图或纯 Prompt 冒充结果。

所有生成结果实际查看后，再调用 `$wxian-html-delivery`。HTML 中每张生成图必须以图片标题与自己的完整 Prompt 组成独立配对，并明确说明“该 Prompt 生成该图”，同时提供查看、筛选、对比、展开与复制；每张图使用唯一 Prompt 路径和唯一 Prompt 内容，不得截断 Prompt，不得用“同上”，不得复制 Prompt 文件或把一个通用 Prompt 绑定到多张图。

交付接入：必须调用 `$wxian-html-delivery`，并由 `$workspace-governance promote` 验证。

## 12. 与 Workspace 其他 Skill 的边界

- 从零游戏概念、画风玩法实验、人物×场景×玩法原型、成熟玩法变异：本 Skill。
- 概念已经确定，只要执行单次既定生图/图片编辑/成图交付：`$wxian-image-production`。需要先产生差异方向的角色、怪物、场景或玩法设计时仍由本 Skill 负责，并在同一 request 内直接调用 `$image-generation-api`。
- 用户要求“先做概念探索并最终直接交付图片文件”：`$wxian-image-production` 为 primary，本 Skill作为前置概念/原型能力，不创建第二 request。
- LOGO / ICON / KV / Store 等发行包装方案：`$wxian-visual-packaging`。
- 海外手游发行视觉竞品研究：`$wxian-visual-competitive-analysis`。
- 一般互联网事实/案例研究：`$wxian-conducting-internet-research`。

本 Skill 可以输出完整 Prototype Spec、Image Contract 和可直接生图 Prompt；不以“概念名称”作为完成标准。

## 13. 完成标准

### Prototype Complete

`Direction 有产品价值 + Prototype Spec 已具体 + Test Image Contracts 可执行 + Test Prompts 可直接生成`

仍为 PROVISIONAL。

必须存在并通过 Schema 的 `work/concept-lab/product-blueprint.json`；世界观-only 任务可以保留关键 `ASSUMED` 项，但完成声明只能是 `DIRECTION_PROPOSED` 或 `PROTOTYPE_SPECIFIED`。
`PROTOTYPE_SPECIFIED` 还要求通过 Schema 的 `work/concept-lab/prototype-spec.json`，其中至少一个 READY 测试资产含完整 Image Contract 与可执行 Canonical Prompt。

### Portfolio Complete

`Product Blueprint + Content Graph + Coverage Plan + Content Audit` 均通过机器验证；每个未豁免 Coverage 槽位为 APPROVED；精确重复不重复计数；近重复有 Parent/Changed Axes/Semantic Delta；身份、名称、拓扑与变体冲突均已解决或明确接受；不存在 blocking unknown；`final-review.md` 明确 `PORTFOLIO_VERIFIED`。

当 `portfolio_output=PROMPT_MARKDOWN | BOTH` 时还必须：

- `prompt-portfolio.json` 通过结构、路径、Hash、Coverage、明显重复和合同一致性验证；
- 每条 Prompt 的主体、原子可见实体、地点、动作、可见后果和至少两个世界专属物必须作为 `content_anchors` 进入各自唯一的权威标签行；主体实体采用 `entity_id / entity_type / identity / visible_count=1`，identity 是最多四词的名词性目录项且不得包含另一已登记主体身份，`subject_identity` 是实体 identity 的精确有序组合，`subject_count` 等于原子实体数，禁止把多人关系句折叠成一个主体；
- Canonical Prompt 的 21 个权威标签必须各自独占一行、顺序固定且只出现一次，Validator 解析后与 Manifest 精确相等；标签名按 Unicode 规范化和大小写无关方式排除藏匿，正文其他位置出现同名标签、跨字段藏值或重复权威行一律阻断；
- 每个 Direction 必须拥有独占的主体／地点／动作／后果／世界物件 `anchor_lexicon`，由 FROZEN Direction Origin JSON 与 SHA 绑定，并接受词项所有权和明显串料校验；这些机器事实不证明真实语义归属，重签来源、重分配词库、DNA 填词与跨方向搬运必须由独立 reviewer 识别；
- Semantic Delta、Image Contract 全部执行字段严格绑定；至少八项视觉机制必须是 `operation / target / visible_result` 三元组，机器 Gate 检查结构、目标归属和明显复用，独立 reviewer 判断结果是否真正形成当前画面的可见机制，通用“仍可见”、关键词回声和复述 operation 均判 BLOCK；
- 视觉机制必须描述真实可见的构图、空间、光色、材质、层级或可读性操作，不能拿主体、地点、动作或排除项充数；
- 关系驱动与系统驱动的案例回归必须使用各自独立的素材词汇和因果合同，关系驱动内部不同方向也要各自锁定词汇边界；跨案例或跨方向角色、地点、事件、物件和系统混入视为语义污染，不得用“数量已达标”掩盖；
- Gate 计算编号／颜色／方向标签归一化克隆、正文近重复、内容锚重复、八机制组合滥用和合同绑定；它不声称这些词法检查已证明 Direction DNA、真实因果差异或创意质量；
- 必须存在由不同 reviewer 产出的全量语义审查 JSON 与 Markdown 报告；每条 Prompt 五类检查全部 PASS，全部方向对至少两组 Swap Test PASS，不存在 blocking unknown；`skin_swap_interchangeable=false`、producer 自评或抽样审查不能替代该证据；
- Active delivery role 按当前 scope/output 使用精确白名单；`portfolio_output=EVIDENCE` 不得夹带 `prompt_portfolio_manifest / prompt_markdown / prototype_prompts / prompt_semantic_review / prompt_semantic_review_report` 或用未知 role 改名绕过；任何正式 Prompt 交付都必须显式选择 `PROMPT_MARKDOWN | BOTH` 并进入同一语义审查门禁；
- 每条正式 Prompt 是 `CANONICAL_PROMPT` Evidence，内容 Hash 绑定 Prompt 正文而非整个文件；
- 所有Prompt均真实存在于 `work/final/prompts/**/*.md`；
- `final-review.md` 明确 `PROMPT_PORTFOLIO_VERIFIED` 与 `PROMPT_SEMANTIC_REVIEW_PASS`；
- 不要求图片、尺寸或预览，也不得声称验证了成图质量。

正式 standalone 交付必经 `$workspace-governance promote`，由 Promote 唯一 blocking 调用 `portfolio_gate.py`。直接运行该 Gate 只用于显式诊断，不属于正常交付序列。

Prompt Portfolio 可先由内部 Manifest 确定性写出并单独检查：

```bash
python .agents/skills/sicza-game-concept-lab/scripts/prompt_portfolio.py compile \
  --manifest <request>/work/concept-lab/prompt-portfolio.json --workspace-root .
python .agents/skills/sicza-game-concept-lab/scripts/prompt_portfolio.py validate \
  --manifest <request>/work/concept-lab/prompt-portfolio.json --workspace-root .
python .agents/skills/sicza-game-concept-lab/scripts/prompt_semantic_review.py \
  --manifest <request>/work/concept-lab/prompt-portfolio.json \
  --review <request>/work/concept-lab/prompt-semantic-review.json \
  --workspace-root .
```

### Production Complete

`Selected Direction + Frozen Anchors + Production Image Contracts + Canonical/Target Prompts + Generated Originals + Interactive HTML + Applicable Runtime Gates PASS`。长期 IP / 正式角色包含 `ip-character-system/binding` preflight；目标含实际图片时还要求当前 Provider×Mode 的 `ip-character-handoff.status=READY`。READY 的机器语义由 `05a-ip-character-system.md`、Registry 与 Runtime 定义。

### Iteration Complete

`Failure Layer 明确 + 正确内容明确 + Change Scope 明确 + 下一轮能验证修复`

最终必须达到：

**有想法、想得通、设计具体、能直接画、能稳定继续做。**

## 14. Workspace 输出与交付

### 作为独立 `game-concept-lab` request

最终用户产物统一进入 `work/final/`：

```text
work/final/game-concept-lab.html      # 默认对外交付；内嵌全部展示图片和逐图完整 Prompt
work/final/originals/*                # 全部实际生成原图；Prompt-only 时不存在
work/final/game-concept-proposal.md   # 内部权威内容源
work/final/prototype-prompts.md       # 内部 Prompt 汇总；Prompt-only 时可作为外部交付
work/final/production-anchors.md      # 已进入 FROZEN Production Anchors 时
work/concept-lab/product-blueprint.json # 必须；scope_profile 与产品因果
work/concept-lab/prototype-spec.json     # PROTOTYPE 必须；结构化测试资产、合同与 Prompt
work/concept-lab/content-graph.json     # PORTFOLIO / VERTICAL_SLICE 必须
work/concept-lab/coverage-plan.json     # PORTFOLIO / VERTICAL_SLICE 必须
work/concept-lab/content-audit.json     # PORTFOLIO / VERTICAL_SLICE 必须
work/concept-lab/prompt-portfolio.json  # Prompt Portfolio 内部绑定
work/concept-lab/prompt-semantic-review.json # 独立全量语义审查绑定
work/final/prompts/**/*.md              # Prompt Portfolio 用户核心交付
work/final/prompt-semantic-review.md    # 逐 Prompt 与跨方向 Swap Test 审查证据
```

`game-concept-proposal.md` 保留足以直接执行的人物/场景/玩法/视觉具体设计和 Prototype 状态。完成后实际核对最终文件，写：

- `work/final-review.md`：只检查 Premise/Hard Lock、Direction 差异、World×Gameplay 因果、Prototype 具体度、Image Contract/Prompt 可执行性、Reference 边界；长期 IP/角色项目再检查 IP DNA、Character Identity、Variant Grammar、Mother Reference Binding 与适用的 Consistency Tests；
- `work/delivery-manifest.json`：默认把 HTML 记为 active `interactive_html`，每张真实生成原图记为 active `generated_original`；Markdown、JSON 与审查文件保留在 request 内作为内部权威和验证证据。只有用户明确要求 `Prompt-only` 时，Prompt 文件可作为 active 外部交付；
- `product_blueprint` 对所有 scope 保留；Prototype 另含 `prototype_spec`；Portfolio 另含 `content_graph / coverage_plan / content_audit`。这些内部机器合同不因对外交付收敛为 HTML 而删除；
- Prompt Portfolio 另含一个 `prompt_portfolio_manifest`、一个 `prompt_semantic_review`、一个 `prompt_semantic_review_report` 和全部 `prompt_markdown` 文件；它们作为 HTML 和审查的权威来源，必须与 Manifest 一一对应；
- `portfolio_gate.py` 验证 Product Blueprint、Vertical Slice 连续状态链、全部语义计数与方向增量、图谱交叉引用、Coverage、证据路径/Hash、精确重复、近重复登记、冲突状态、Visual Spec 上游绑定和完成声明；18 项案例回归必须绑定真实来源 ID/Hash 并执行行为断言，52+146 条案例规模 Prompt 回归还必须验证内容锚、合同正文绑定和反模板克隆，不能只登记名称或数量；
- `$workspace-governance promote`：唯一 standalone completion。

### 作为 `wxian-image-production` 的前置能力

当最终目标是实际图片文件时，本 Skill 不创建第二 request、不 Promote。产物写入调用方当前 request：

```text
work/concept-lab/direction-prototypes.md
work/concept-lab/selected-prototype.md
work/concept-lab/test-prompts.md
work/concept-lab/ip-character-system.json      # 长期 IP / 正式角色适用
work/concept-lab/ip-character-binding.json     # 长期 IP / 正式角色适用
work/concept-lab/ip-character-preflight.json   # production preflight 证据
work/concept-lab/ip-character-handoff.json     # provider-resolved image conditioning inputs
work/concept-lab/product-blueprint.json        # 作为任何 Concept 前置的最小产品因果合同
work/concept-lab/content-graph.json            # PORTFOLIO / VERTICAL_SLICE 适用
work/concept-lab/coverage-plan.json            # PORTFOLIO / VERTICAL_SLICE 适用
work/concept-lab/content-audit.json             # PORTFOLIO / VERTICAL_SLICE 适用
```

用户已选择或已授权收敛的结果交回 `wxian-image-production` 写入正式 `visual-requirement.md`。长期 IP / 正式角色同时交接 `ip-character-system/binding/preflight/handoff`；`image_conditioning_inputs` 保持为独立图像输入通道。
