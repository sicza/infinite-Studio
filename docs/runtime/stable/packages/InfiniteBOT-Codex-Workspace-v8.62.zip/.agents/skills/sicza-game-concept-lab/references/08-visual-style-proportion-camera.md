# Visual Style, Proportion & Camera

## 目标

Style 不是“写实/3D卡通/Q版”标签，而是 `Realism × Proportion × Shape × Camera × Scale × Detail × Material × Color × Lighting × UI`。视觉选择应真实改变 Product Expression 与 Gameplay Readability。

## 1. 先看信息，不先选风格

问：一屏要看到多少系统？角色还是空间更重要？NPC 多不多？交互目标多大？是否需要读脸？Gameplay Change 在哪里？

Character-dominant 产品适合更近 Camera、更高头身、更多面部信息；System-dominant 产品需要更大空间、更小角色、更清楚 Zone。

## 2. Proportion

- 7.5–8H：写实/半写实、第三人称、角色动作与身份。
- 6–7H：Stylized Realism、商业角色表现。
- 4.5–6H：Stylized 3D、45°、管理/Hybrid，头手工具更可读。
- 3–4H：Diorama、大量 NPC、系统模拟、UI 密度高。

比例变化同步 Head/Hands/Feet/Equipment/Prop Scale/Animation Exaggeration。

## 3. Shape Language

Angular/Triangular→危险、快速、技术；Square/Blocky→稳定、工业、可靠；Round→友好、安全。角色可以混合，例如身体块面稳、工具有长技术斜线、脸部稍软。


## 3.5 IP Shape Grammar vs Surface Style

长期人物/IP不得把 `Shape Grammar` 混进 Surface Style。

- `IP Shape Grammar`：Head/Body family、Shoulder/Torso、Limb taper、Hand/Foot scale、Face geometry family、Silhouette rhythm；
- `Surface Style`：Rendering、Material、Edge、Texture、Color、Lighting。

同一角色从 3D PBR 切到 2D illustration，如果只是 Surface Translation，应保留 Shape/Face/Body Identity；如果连头身比、手脚尺度和脸部几何一起改变，则属于 Product-level Proportion Mutation，需要新的 Prototype/Anchor，而不是普通“换风格”。

## 4. Prop Exaggeration

越 Stylized，功能道具越应强化大结构和状态可读性，而不是只是“更可爱”。小诊断仪可以变成更大的清晰屏幕/握柄，但功能与 World Anchor 不变。

## 5. Environment Scale

写实保真实 Architecture/Doors/Machines；Stylized 可简化次要结构、放大交互装置、加强 Zone Color；Diorama 可压缩距离、强化垂直层级和功能区。不能只换材质。

## 6. Camera Families

- First Person：手/工具/沉浸，弱角色身份。
- Third Person：角色身份+动作+环境。
- Isometric/45°：空间规划、多任务、管理。
- Top-down：路线/网络/策略。
- Side/Cutaway：垂直结构、房间关系、Before/After。
- Diorama：世界作为系统、NPC/资源流、多区管理。
- Network Map：Node/Route/Capacity，空间本身变 UI。

Camera 是 Gameplay 决策，不是 Presentation-only。

## 7. Lens / Perspective

Strong wide-angle 服务动态、巨大空间、前后景差异，但会带来脸/结构形变；Normal Perspective 适合角色表与清晰 Gameplay；Orthographic-like 适合 Diorama/Strategy/Layout Readability。

## 8. Detail Density

明确 Primary Detail Zone / Secondary Detail / Rest Area。交互点必须比装饰细节更抢眼。高细节不等于高可读性。

## 9. Material / Color / Lighting

写实强调物理可信与磨损；Stylized PBR 减少微噪声、强化 Material Group 和大 Value Shape；Diorama 仍需分清 Metal/Rubber/Cloth/Concrete，避免一切塑料化。

颜色可以编码 Residential/Power/Medical/Locked 等功能；光可编码 Safe/Unsafe/Active/Locked/Progress。

## 10. Visual → Gameplay Mutation

多画风测试每个方向都重做：`Body Ratio → Camera → Character Screen Size → NPC Density → Prop Scale → Environment Scale → Detail Density → Gameplay Readability → Product Expression`。

例如同一地下避难所：

- Semi-realistic 7.5H + Third Person → 亲自维修、沉浸生存维护。
- Stylized 5H + 45° → 多设施/中等 NPC 的现场管理。
- 3.2H Diorama + Cutaway → 多层站区、人口/资源流、系统调度。

这是三个产品表达，不是一个游戏三种 Renderer。

## 11. Style Anchor

`Realism / Head-to-body Ratio / Character Size in Frame / NPC Density / Shape Language / Prop Scale / Environment Scale / Camera / Perspective / Detail Density / Material Strategy / Color Structure / Lighting Logic / UI Relationship`。长期 IP 同时维护独立 `IP DNA Anchor`；Style Anchor 不得静默覆盖 Character Identity。
