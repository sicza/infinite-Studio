# Portfolio Coverage and Dedup

用于多图内容包的计划、批次审查和最终完成判断。

## 1. 七种计数面

任何规模报告同时区分：

```text
Raw Evidence Files
Content-hash Unique Files
Asset / Identity Families
States
Events
Screen Templates
Product Directions
```

不得用文件数替代角色、地点、玩法或方向数；不得用军团实例、卡牌格或画面人头数替代身份数。

Prompt-only Portfolio 额外报告 `Canonical Prompt Count / Canonical Prompt Unique Hash Count / Direction Material Domain Coverage`。同一个Markdown文件可以承载多条Prompt，因此Prompt正文Hash才是内容唯一性单位，文件Hash只负责交付完整性。

## 2. 新增判定

| 声称 | 最低语义差 |
|---|---|
| NEW_ASSET | 稳定身份／核心拓扑／功能角色产生新实体 |
| NEW_STATE | 同一父资产的进入条件、可见变化与玩法含义明确 |
| NEW_EVENT | Cause、Action 或 Consequence 至少一项实质改变 |
| NEW_SCREEN | 输入、状态变化、反馈或结果形成新交互模板 |
| NEW_USE | 同一内容承担新的交付目的，但不增加资产／事件数 |
| PRESENTATION_ONLY | 镜头、排版、UI显隐、语言、裁切、色光等表达变化 |

只换脸、换装、换色、换镜头、UI显隐和排版默认不能成为 NEW_ASSET、NEW_STATE、NEW_EVENT、NEW_SCREEN、NEW_USE 或新方向。每项证据必须填写结构化 `counting_delta`，把目标 Graph ID、语义变化轴和表现变化轴分开；对应类别没有合法语义轴时直接阻断。`NEW_EVENT` 还必须填写结构化 `event_delta` 并绑定一个 EVENT graph_ref；只有 Cause、Action 或 Consequence 至少一项为真实变化时才成立。Participants/Location 变化和 presentation-only axes 只能作为辅助事实，不能单独把原事件升级为新事件。

方向使用独立 `direction_inventory`：只允许一个无父级的根方向；其他 Approved 方向必须引用 Approved 父方向、父链无环且最终到达该唯一根，并在 Player Agent、Product Type、Core Loop 或 World Causality 至少一项发生变化。比例、镜头、色光、服装或排版变化只能记录为表现轴，不增加 Product Direction 数。

## 3. Coverage Slot

每个槽位回答：

```text
为什么需要
依赖哪些 Graph Nodes
要证明哪个 State/Event
用于哪个 Use
证据类型
最低语义增量
计数类别
状态
真实证据
豁免理由（如有）
```

`PASS` 只允许 APPROVED 或有理由的 WAIVED；PLANNED、BOUND、OBSERVED、FAILED 均不能进入 Portfolio Verified。

## 4. 批次审查

每10–20项检查：

1. ID唯一，路径、字节、尺寸、Hash和解码真实；
2. 每项有事实、判断、建议和未知；
3. 至少8条图像特异机制；
4. Graph/Coverage 引用存在；
5. Parent、Variant Axes、Semantic Delta、Counting Class一致；
6. 精确重复、近重复、同名异形、同形异名和拓扑漂移已记录。

Evidence Inventory 每项保存 `batch_id / evidence_kind / path / byte_size / width / height / preview_path / sha256 / graph_refs / coverage_refs / coverage_claims / parent_asset_or_screen_id / variant_axes / semantic_delta / counting_class / counting_delta / event_delta / facts / judgements / recommendations / unknowns / image_specific_mechanisms / regions`。`counting_delta` 对所有类别必填并按类别限制合法语义轴；`event_delta` 仅用于 `NEW_EVENT`，必须记录 event_id、Cause/Action/Consequence 是否改变、Participants/Location 是否改变及表现轴；其他计数类别必须为 `null`。图片／Screen 必须可解码、尺寸匹配、有真实预览且 `image_specific_mechanisms >= 8`；非图像证据的尺寸和预览可以为 `null`。

`evidence_kind=CANONICAL_PROMPT` 时，`path/byte_size/sha256` 绑定Markdown文件，`fragment_id/fragment_sha256` 绑定具体Prompt正文；`width/height/preview_path` 必须为空。Prompt仍需至少八条针对当前画面的视觉机制，但不要求图片预览或声称验证成图质量。

Prompt组合还必须检查占位符、正文精确重复、方向归属、素材域覆盖和成对Direction Material DNA差异。只改形容词顺序、角色名、颜色、服装、镜头或UI显隐的Prompt不得提高语义覆盖。

`coverage_claims[]` 把每个 `coverage_id` 的最低语义增量与真实观察增量绑定。Coverage 与 Evidence 必须双向引用；Approved 槽位的证据并集覆盖其 Graph Nodes、State/Event 与 Use，双方 `counting_class` 一致，且不得引用 REJECTED 节点。大边长（≥8192）或长宽比≥3的图片必须记录局部 `regions[]` 和归一化 bbox。

批次通过不等于全局通过。全局阶段重新解析全部批次并计算缺失、重复、额外、孤儿证据和跨批次冲突。

## 5. 精确重复

对真实文件重新计算 SHA-256。相同 Hash 的证据保留全部源路径，但只能有一个成员使用任何 `NEW_*` 计数；其他成员只能是 `PRESENTATION_ONLY`，且整个重复族最多贡献一个 Coverage 槽。同一槽位允许由一个与槽位类别一致的语义主证据和同族 `PRESENTATION_ONLY` 重复证据共同闭合，不因重复证据的计数类别不同而误阻断。未登记的重复组直接 BLOCK；不同 Parent 身份共用同一 Hash 时还必须登记 Identity/Name 或 Topology Conflict。

## 6. 近重复

近重复不由单一阈值自动裁决。先用相似性或人工观察发现候选，再记录：

```text
Parent
Members
Invariant
Changed Axes
Semantic Delta
Counting Rule
```

边界测试：

- 去掉颜色后仍相同 → 颜色变体；
- 去掉服装后脸、体型、姿态和职能仍相同 → 角色形态；
- 固定镜头后仅 UI／按钮变化 → 屏幕状态；
- 固定地标和道路后仅天气、NPC、损毁变化 → 地点状态；
- 固定参与者和地点后仅特效变化 → 事件层；
- 核心循环、玩家代理和世界因果均未变化 → 不是新方向。

## 7. 冲突处理

Identity、Name、Topology、Variant Axis 冲突必须为：

- `OPEN`：阻断 Portfolio Verified；
- `RESOLVED`：已选定 Authority 并写清被替代项；
- `ACCEPTED`：明确保留歧义或候选分支，写清为什么不影响当前完成范围。

不能通过删除冲突证据获得 PASS。

## 8. 完成审计

最终 `content-audit.json` 必须由真实 Evidence Inventory 重算：

- inventory 与 unique content hash 数；
- 精确重复族与近重复族；
- 图谱引用；
- 四类冲突；
- Coverage 汇总；
- blocking unknown；
- reviewer findings。

`status=PASS` 必须同时满足：Coverage PASS、无 OPEN 冲突、无 blocking unknown、所有文件 Hash 匹配。PASS 不证明可玩性；若声称玩法验证，还必须提供对应的交互原型或真实测试证据。

完成回执同时报告 `inventory_count / content_hash_unique_count / asset_families / states / events / screen_templates / product_directions`。所有正式 Evidence Inventory 条目必须被至少一个 Coverage 槽位双向引用；孤儿证据直接 BLOCK。`content-audit.status=BLOCK` 不能被 final-review 的文字覆盖。
