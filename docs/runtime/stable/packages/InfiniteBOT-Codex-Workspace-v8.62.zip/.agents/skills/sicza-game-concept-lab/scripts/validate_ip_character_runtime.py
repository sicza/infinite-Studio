#!/usr/bin/env python3
"""Production preflight for SICZA Game Concept Lab IP character contracts.

Provider/runtime facts are loaded from provider-reference-binding-registry.json.
JSON Schemas are derived from that current machine authority.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

VALID_STATUS = {"FROZEN", "ACTIVE", "EXPERIMENTAL", "DEPRECATED"}
PRODUCTION_BINDABLE_STATUS = {"FROZEN", "ACTIVE"}
VARIANT_CLASSES = ("stable", "semi_variable", "context_driven", "free")
LOCATOR_TYPES = {"LOCAL_PATH", "ASSET_ID", "URI"}
SLOT_MODES = {"INTEGER_ORDER"}
SUPPORTED_MOTHER_IMAGE_FORMATS = {"PNG", "JPEG", "WEBP"}
HEX64 = re.compile(r"^[a-fA-F0-9]{64}$")
URI_SCHEME = re.compile(r"^[A-Za-z][A-Za-z0-9+.-]*://")

SCRIPT_ROOT = Path(__file__).resolve().parent.parent
SYSTEM_SCHEMA_PATH = SCRIPT_ROOT / "config/schemas/ip-character-system-schema.json"
BINDING_SCHEMA_PATH = SCRIPT_ROOT / "config/schemas/ip-character-binding-schema.json"
PROVIDER_REGISTRY_PATH = SCRIPT_ROOT / "config/provider-reference-binding-registry.json"


def _load_registry_authority() -> dict[str, Any]:
    try:
        data = json.loads(PROVIDER_REGISTRY_PATH.read_text(encoding="utf-8"))
    except Exception as exc:
        raise RuntimeError(f"invalid provider registry: {exc}") from exc
    if not isinstance(data, dict):
        raise RuntimeError("provider registry root must be an object")
    required = ("contract_version", "producer", "runtime_binding", "providers", "unsupported_providers")
    missing = [key for key in required if key not in data]
    if missing:
        raise RuntimeError("provider registry missing: " + ", ".join(missing))
    return data


PROVIDER_REGISTRY = _load_registry_authority()
CONTRACT_VERSION = PROVIDER_REGISTRY["contract_version"]
PRODUCER = PROVIDER_REGISTRY["producer"]
PROVIDER_CONTRACT_TEST_PRODUCER = PRODUCER["id"]
PROVIDER_PRODUCER_RELATIVE_PATH = PRODUCER["workspace_relative_path"]
PINNED_RUNTIME_SHA256 = PROVIDER_REGISTRY["runtime_binding"]
TRUSTED_PROVIDER_BINDINGS: dict[str, dict[str, Any]] = PROVIDER_REGISTRY["providers"]
PROVIDERS = set(TRUSTED_PROVIDER_BINDINGS) | set(PROVIDER_REGISTRY["unsupported_providers"])
PRODUCTION_PROVIDERS = set(TRUSTED_PROVIDER_BINDINGS)


def _string_schema() -> dict[str, Any]:
    return {"type": "string", "minLength": 1}


def _slot_schema() -> dict[str, Any]:
    return {
        "anyOf": [
            {"type": "integer", "minimum": 1},
            {"type": "string", "minLength": 1},
        ]
    }


def expected_system_schema() -> dict[str, Any]:
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "sicza-game-concept-lab/ip-character-system.schema.json",
        "title": "SICZA Game Concept Lab Frozen IP Character System",
        "type": "object",
        "required": ["contract_version", "system_version", "ip_dna", "character_identity", "variant_grammar", "mother_references"],
        "properties": {
            "contract_version": {"const": CONTRACT_VERSION},
            "system_version": _string_schema(),
            "ip_id": _string_schema(),
            "ip_dna": {
                "type": "object",
                "required": ["shape_grammar", "facial_grammar", "surface_grammar", "identity_grammar"],
                "properties": {
                    "shape_grammar": {"type": "object", "minProperties": 1},
                    "facial_grammar": {"type": "object", "minProperties": 1},
                    "surface_grammar": {"type": "object", "minProperties": 1},
                    "identity_grammar": {"type": "object", "minProperties": 1},
                },
                "additionalProperties": True,
            },
            "character_identity": {
                "type": "object",
                "required": ["character_id", "hard_identity", "body_mass_distribution", "costume_architecture"],
                "properties": {
                    "character_id": _string_schema(),
                    "hard_identity": {"type": "object", "minProperties": 1},
                    "soft_identity": {"type": "object"},
                    "body_mass_distribution": {"type": "object", "minProperties": 1},
                    "costume_architecture": {"type": "object", "minProperties": 1},
                    "iconic_features": {"type": "array", "items": _string_schema(), "uniqueItems": True},
                },
                "additionalProperties": True,
            },
            "variant_grammar": {
                "type": "object",
                "required": list(VARIANT_CLASSES),
                "properties": {k: {"type": "array", "items": _string_schema(), "uniqueItems": True} for k in VARIANT_CLASSES},
                "additionalProperties": False,
            },
            "mother_references": {
                "type": "array",
                "items": {
                    "type": "object",
                    "required": ["reference_id", "locator", "role", "authority", "character_id", "version", "status", "source"],
                    "properties": {
                        "reference_id": _string_schema(),
                        "locator": {
                            "type": "object",
                            "required": ["type", "value"],
                            "properties": {
                                "type": {"enum": sorted(LOCATOR_TYPES)},
                                "value": _string_schema(),
                            },
                            "additionalProperties": False,
                        },
                        "role": {"type": "array", "items": _string_schema(), "minItems": 1, "uniqueItems": True},
                        "authority": {"type": "integer", "minimum": 0, "maximum": 100},
                        "character_id": _string_schema(),
                        "version": _string_schema(),
                        "status": {"enum": sorted(VALID_STATUS)},
                        "source": _string_schema(),
                        "sha256": {"type": "string", "pattern": "^[a-fA-F0-9]{64}$"},
                        "notes": {"type": "string"},
                    },
                    "additionalProperties": False,
                },
            },
            "cast_architecture": {"type": "object", "minProperties": 1},
        },
        "additionalProperties": False,
    }


def expected_binding_schema() -> dict[str, Any]:
    return {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$id": "sicza-game-concept-lab/ip-character-binding.schema.json",
        "title": "SICZA Game Concept Lab Bound Character Identity Binding",
        "type": "object",
        "required": ["contract_version", "character_id", "system_version", "variant_overrides", "mother_reference_binding"],
        "properties": {
            "contract_version": {"const": CONTRACT_VERSION},
            "character_id": _string_schema(),
            "system_version": _string_schema(),
            "variant_overrides": {"type": "object"},
            "mother_reference_binding": {
                "type": "array",
                "items": {
                    "type": "object",
                    "required": ["reference_id", "use_roles"],
                    "properties": {
                        "reference_id": _string_schema(),
                        "use_roles": {"type": "array", "items": _string_schema(), "minItems": 1, "uniqueItems": True},
                        "preserve": {"type": "array", "items": _string_schema(), "uniqueItems": True},
                        "provider_slot_or_order": _slot_schema(),
                    },
                    "additionalProperties": False,
                },
            },
            "reference_contract_ref": _string_schema(),
            "image_contract_ref": _string_schema(),
            "identity_risk": {"type": "string"},
        },
        "additionalProperties": False,
    }

def _json_type_ok(value: Any, expected: str) -> bool:
    if expected == "object":
        return isinstance(value, dict)
    if expected == "array":
        return isinstance(value, list)
    if expected == "string":
        return isinstance(value, str)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "null":
        return value is None
    return False


def validate_schema_instance(value: Any, schema: dict[str, Any], path: str = "$", errors: list[str] | None = None) -> list[str]:
    """Validate the JSON-Schema subset used by this skill against the live instance.

    This intentionally implements only the keywords emitted by the machine
    contract above, keeping validation dependency-free and deterministic.
    """
    if errors is None:
        errors = []

    if "anyOf" in schema:
        branches = schema["anyOf"]
        if not any(not validate_schema_instance(value, branch, path, []) for branch in branches):
            errors.append(f"{path}: does not match any allowed schema")
        return errors

    if "const" in schema and value != schema["const"]:
        errors.append(f"{path}: must equal {schema['const']!r}")
        return errors
    if "enum" in schema and value not in schema["enum"]:
        errors.append(f"{path}: must be one of {schema['enum']!r}")
        return errors

    expected_type = schema.get("type")
    if expected_type is not None:
        types = expected_type if isinstance(expected_type, list) else [expected_type]
        if not any(_json_type_ok(value, t) for t in types):
            errors.append(f"{path}: must be type {'/'.join(types)}")
            return errors

    if isinstance(value, str):
        min_length = schema.get("minLength")
        if isinstance(min_length, int) and len(value) < min_length:
            errors.append(f"{path}: string is shorter than minLength {min_length}")
        pattern = schema.get("pattern")
        if isinstance(pattern, str) and re.search(pattern, value) is None:
            errors.append(f"{path}: string does not match pattern {pattern!r}")

    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if "minimum" in schema and value < schema["minimum"]:
            errors.append(f"{path}: must be >= {schema['minimum']}")
        if "maximum" in schema and value > schema["maximum"]:
            errors.append(f"{path}: must be <= {schema['maximum']}")

    if isinstance(value, list):
        min_items = schema.get("minItems")
        if isinstance(min_items, int) and len(value) < min_items:
            errors.append(f"{path}: array must contain at least {min_items} item(s)")
        if schema.get("uniqueItems"):
            serialized = [json.dumps(x, ensure_ascii=False, sort_keys=True) for x in value]
            if len(serialized) != len(set(serialized)):
                errors.append(f"{path}: array items must be unique")
        item_schema = schema.get("items")
        if isinstance(item_schema, dict):
            for i, item in enumerate(value):
                validate_schema_instance(item, item_schema, f"{path}[{i}]", errors)

    if isinstance(value, dict):
        min_properties = schema.get("minProperties")
        if isinstance(min_properties, int) and len(value) < min_properties:
            errors.append(f"{path}: object must contain at least {min_properties} propert{'y' if min_properties == 1 else 'ies'}")
        required = schema.get("required", [])
        for key in required:
            if key not in value:
                errors.append(f"{path}.{key}: required property missing")
        properties = schema.get("properties", {})
        if isinstance(properties, dict):
            for key, child in properties.items():
                if key in value:
                    validate_schema_instance(value[key], child, f"{path}.{key}", errors)
        if schema.get("additionalProperties") is False and isinstance(properties, dict):
            extra = sorted(set(value) - set(properties))
            for key in extra:
                errors.append(f"{path}.{key}: additional property is not allowed")

    return errors


def load_json(path: Path, label: str) -> dict[str, Any]:
    if not path.is_file():
        raise ValueError(f"{label} not found: {path}")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise ValueError(f"invalid {label} JSON: {exc}") from exc
    if not isinstance(data, dict):
        raise ValueError(f"{label} root must be an object")
    return data


def check_schema_sync(errors: list[str]) -> None:
    expected = [
        (SYSTEM_SCHEMA_PATH, expected_system_schema()),
        (BINDING_SCHEMA_PATH, expected_binding_schema()),
    ]
    for path, contract in expected:
        if not path.is_file():
            errors.append(f"packaged schema missing: {path}")
            continue
        try:
            actual = json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            errors.append(f"packaged schema invalid JSON: {path}: {exc}")
            continue
        if actual != contract:
            errors.append(f"packaged machine contract drift: {path.name}; regenerate schemas")

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def resolve_asset(raw: str, system_path: Path, asset_root: Path | None) -> Path:
    p = Path(raw)
    if p.is_absolute():
        return p
    if asset_root is not None:
        return (asset_root / p).resolve()
    return (system_path.parent / p).resolve()


def validate_decodable_image(path: Path) -> tuple[dict[str, Any] | None, str | None]:
    try:
        from PIL import Image, UnidentifiedImageError
    except Exception as exc:
        return None, f"image decoder unavailable (Pillow required): {exc}"
    try:
        with Image.open(path) as im:
            fmt = (im.format or "").upper()
            if fmt not in SUPPORTED_MOTHER_IMAGE_FORMATS:
                return None, f"unsupported image format {fmt or 'UNKNOWN'}; supported={sorted(SUPPORTED_MOTHER_IMAGE_FORMATS)}"
            width, height = im.size
            if width < 1 or height < 1:
                return None, "image has invalid dimensions"
            im.verify()
        # verify() checks structure but does not decode pixels; reopen and load to prove decodability.
        with Image.open(path) as im:
            im.load()
            width, height = im.size
            mode = im.mode
            fmt = (im.format or "").upper()
        return {"format": fmt, "width": width, "height": height, "mode": mode}, None
    except (UnidentifiedImageError, Image.DecompressionBombError, OSError, ValueError) as exc:
        return None, f"image decode failed: {exc}"


def validate_system_cross_rules(
    data: dict[str, Any],
    system_path: Path,
    asset_root: Path | None,
    production: bool,
    errors: list[str],
    warnings: list[str],
) -> tuple[dict[str, dict[str, Any]], dict[str, set[str]], list[dict[str, Any]]]:
    identity = data.get("character_identity") if isinstance(data.get("character_identity"), dict) else {}
    system_character = identity.get("character_id") if isinstance(identity.get("character_id"), str) else ""

    vg = data.get("variant_grammar") if isinstance(data.get("variant_grammar"), dict) else {}
    variant_sets: dict[str, set[str]] = {}
    seen_variant_owner: dict[str, str] = {}
    for key in VARIANT_CLASSES:
        value = vg.get(key)
        normalized = [x.strip() for x in value if isinstance(x, str)] if isinstance(value, list) else []
        variant_sets[key] = set(normalized)
        for field in normalized:
            if field in seen_variant_owner:
                errors.append(f"variant field {field!r} appears in both {seen_variant_owner[field]} and {key}")
            else:
                seen_variant_owner[field] = key

    refs = data.get("mother_references") if isinstance(data.get("mother_references"), list) else []
    ref_index: dict[str, dict[str, Any]] = {}
    checked_assets: list[dict[str, Any]] = []
    role_authorities: dict[str, list[tuple[str, int, str]]] = {}

    for i, ref in enumerate(refs):
        if not isinstance(ref, dict):
            continue
        where = f"mother_references[{i}]"
        rid = ref.get("reference_id") if isinstance(ref.get("reference_id"), str) else ""
        if rid:
            if rid in ref_index:
                errors.append(f"duplicate reference_id: {rid}")
            else:
                ref_index[rid] = ref
        ref_character = ref.get("character_id")
        if system_character and isinstance(ref_character, str) and ref_character != system_character:
            errors.append(f"{where}.character_id {ref_character!r} does not match system character_id {system_character!r}")

        roles = ref.get("role") if isinstance(ref.get("role"), list) else []
        authority = ref.get("authority") if isinstance(ref.get("authority"), int) and not isinstance(ref.get("authority"), bool) else -1
        status = ref.get("status") if isinstance(ref.get("status"), str) else "INVALID"
        for role in roles:
            if isinstance(role, str):
                role_authorities.setdefault(role, []).append((rid or where, authority, status))

        locator = ref.get("locator") if isinstance(ref.get("locator"), dict) else {}
        locator_type = locator.get("type")
        locator_value = locator.get("value")
        expected_hash = ref.get("sha256")
        item: dict[str, Any] = {"reference_id": rid or where, "locator": locator}

        if locator_type == "LOCAL_PATH" and isinstance(locator_value, str) and locator_value.strip():
            path = resolve_asset(locator_value.strip(), system_path, asset_root)
            item.update({"resolved_path": str(path), "exists": path.is_file(), "kind": "local_path"})
            if path.is_file():
                actual = sha256(path)
                item["sha256"] = actual
                if isinstance(expected_hash, str) and HEX64.fullmatch(expected_hash) and actual.lower() != expected_hash.lower():
                    errors.append(f"hash mismatch for {rid or where}")
                elif production and status in PRODUCTION_BINDABLE_STATUS and not expected_hash:
                    warnings.append(f"production local Mother Reference has no sha256; content integrity is not version-locked: {rid or where}")
                if production and status in PRODUCTION_BINDABLE_STATUS:
                    image_info, image_error = validate_decodable_image(path)
                    if image_error:
                        errors.append(f"invalid production Mother Reference image {rid or where}: {image_error}")
                    else:
                        item["image"] = image_info
            elif production and status in PRODUCTION_BINDABLE_STATUS:
                errors.append(f"local production reference missing: {rid or where} -> {path}")
            else:
                warnings.append(f"local non-production reference not found: {rid or where} -> {path}")
        elif locator_type == "ASSET_ID" and isinstance(locator_value, str) and locator_value.strip():
            item.update({"kind": "asset_id", "exists": None})
        elif locator_type == "URI" and isinstance(locator_value, str) and locator_value.strip():
            if not URI_SCHEME.match(locator_value) or locator_value.lower().startswith("file://"):
                errors.append(f"{where}.locator.value must be a non-file absolute URI when locator.type=URI")
            item.update({"kind": "uri", "exists": None})
        checked_assets.append(item)

    for role, entries in role_authorities.items():
        active = [e for e in entries if e[2] in PRODUCTION_BINDABLE_STATUS and e[1] >= 0]
        if len(active) > 1:
            top = max(e[1] for e in active)
            winners = [e for e in active if e[1] == top]
            if len(winners) > 1:
                msg = f"role {role!r} has unresolved equal-top authority {top}: " + ", ".join(e[0] for e in winners)
                if production:
                    errors.append(msg)
                else:
                    warnings.append(msg)

    return ref_index, variant_sets, checked_assets


def validate_binding_cross_rules(
    data: dict[str, Any],
    system: dict[str, Any],
    ref_index: dict[str, dict[str, Any]],
    variant_sets: dict[str, set[str]],
    production: bool,
    errors: list[str],
) -> None:
    binding_contract = data.get("contract_version")
    system_contract = system.get("contract_version")
    if isinstance(binding_contract, str) and isinstance(system_contract, str) and binding_contract != system_contract:
        errors.append(f"binding contract_version {binding_contract!r} does not match system {system_contract!r}")

    binding_character = data.get("character_id") if isinstance(data.get("character_id"), str) else ""
    binding_version = data.get("system_version") if isinstance(data.get("system_version"), str) else ""
    identity = system.get("character_identity") if isinstance(system.get("character_identity"), dict) else {}
    system_character = identity.get("character_id") if isinstance(identity.get("character_id"), str) else ""
    system_version = system.get("system_version") if isinstance(system.get("system_version"), str) else ""
    if binding_character and system_character and binding_character != system_character:
        errors.append(f"binding character_id {binding_character!r} does not match system character_id {system_character!r}")
    if binding_version and system_version and binding_version != system_version:
        errors.append(f"binding system_version {binding_version!r} does not match system {system_version!r}")

    overrides = data.get("variant_overrides") if isinstance(data.get("variant_overrides"), dict) else {}
    stable = variant_sets.get("stable", set())
    allowed = set().union(*(variant_sets.get(k, set()) for k in ("semi_variable", "context_driven", "free")))
    stable_attempts = sorted(set(overrides) & stable)
    if stable_attempts:
        errors.append("variant_overrides attempts to modify STABLE fields: " + ", ".join(stable_attempts))
    unknown_overrides = sorted(set(overrides) - allowed - stable)
    if unknown_overrides:
        errors.append("variant_overrides contains fields not declared by Variant Grammar: " + ", ".join(unknown_overrides))

    bindings = data.get("mother_reference_binding") if isinstance(data.get("mother_reference_binding"), list) else []
    seen: set[str] = set()
    for i, item in enumerate(bindings):
        if not isinstance(item, dict):
            continue
        rid = item.get("reference_id") if isinstance(item.get("reference_id"), str) else ""
        roles = item.get("use_roles") if isinstance(item.get("use_roles"), list) else []
        if rid in seen:
            errors.append(f"duplicate bound reference_id: {rid}")
        if rid:
            seen.add(rid)
        ref = ref_index.get(rid)
        if ref is None:
            if rid:
                errors.append(f"binding references unknown Mother Reference: {rid}")
            continue
        status = ref.get("status")
        if production and status not in PRODUCTION_BINDABLE_STATUS:
            errors.append(f"production binding may only use ACTIVE/FROZEN Mother References: {rid} has {status}")
        elif not production and status == "DEPRECATED":
            errors.append(f"binding references DEPRECATED Mother Reference: {rid}")
        ref_character = ref.get("character_id")
        if binding_character and isinstance(ref_character, str) and ref_character != binding_character:
            errors.append(f"bound Mother Reference {rid} belongs to character {ref_character!r}, not {binding_character!r}")
        ref_roles = set(ref.get("role", [])) if isinstance(ref.get("role"), list) else set()
        illegal_roles = sorted(set(x for x in roles if isinstance(x, str)) - ref_roles)
        if illegal_roles:
            errors.append(f"mother_reference_binding[{i}].use_roles exceeds Mother Reference role for {rid}: " + ", ".join(illegal_roles))

    if production and ref_index and not bindings:
        errors.append("production binding is empty while Mother References exist in the Frozen system")


def validate_runtime(
    system_path: Path,
    binding_path: Path | None,
    asset_root: Path | None = None,
    production: bool = False,
) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    check_schema_sync(errors)
    system = load_json(system_path, "system")
    binding = load_json(binding_path, "binding") if binding_path else None

    errors.extend(validate_schema_instance(system, expected_system_schema(), "system"))
    if binding is not None:
        errors.extend(validate_schema_instance(binding, expected_binding_schema(), "binding"))

    ref_index, variant_sets, checked_assets = validate_system_cross_rules(system, system_path, asset_root, production, errors, warnings)
    if production and not ref_index:
        errors.append("production preflight requires at least one Mother Reference; concept/non-production mode may omit Mother References")
    if binding is not None:
        validate_binding_cross_rules(binding, system, ref_index, variant_sets, production, errors)
        if production and not binding.get("mother_reference_binding"):
            errors.append("production preflight requires at least one Mother Reference Binding")
    elif production:
        errors.append("production preflight requires --binding")

    return {
        "status": "PASS" if not errors else "FAIL",
        "contract_version": CONTRACT_VERSION,
        "system": str(system_path.resolve()),
        "binding": str(binding_path.resolve()) if binding_path else None,
        "production_mode": production,
        "errors": errors,
        "warnings": warnings,
        "checked_assets": checked_assets,
        "mother_reference_count": len(ref_index),
        "bound_reference_count": len(binding.get("mother_reference_binding", [])) if isinstance(binding, dict) and isinstance(binding.get("mother_reference_binding"), list) else 0,
    }


def write_expected_schemas() -> None:
    SYSTEM_SCHEMA_PATH.parent.mkdir(parents=True, exist_ok=True)
    SYSTEM_SCHEMA_PATH.write_text(json.dumps(expected_system_schema(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    BINDING_SCHEMA_PATH.write_text(json.dumps(expected_binding_schema(), ensure_ascii=False, indent=2) + "\n", encoding="utf-8")



def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--system", type=Path, help="Frozen ip-character-system.json")
    ap.add_argument("--binding", type=Path, default=None, help="Bound ip-character-binding.json")
    ap.add_argument("--asset-root", type=Path, default=None)
    ap.add_argument("--production", action="store_true")
    ap.add_argument("--report", type=Path, default=None)
    ap.add_argument("--write-schemas", action="store_true", help="Regenerate packaged schemas from this machine contract")
    args = ap.parse_args()

    if args.write_schemas:
        write_expected_schemas()
        print(json.dumps({"status": "PASS", "written": [str(SYSTEM_SCHEMA_PATH), str(BINDING_SCHEMA_PATH)]}, ensure_ascii=False, indent=2))
        return 0
    if args.system is None:
        ap.error("--system is required unless --write-schemas is used")

    try:
        result = validate_runtime(args.system, args.binding, args.asset_root, args.production)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        return 2

    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
