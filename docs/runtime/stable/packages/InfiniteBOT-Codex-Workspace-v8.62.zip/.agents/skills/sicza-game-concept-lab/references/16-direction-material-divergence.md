# Direction Material Divergence

用于 `DISCOVER` 的方向筛选，以及 `PORTFOLIO` 的多方向创意展开。目标不是增加方向名称，而是让每个方向拥有不同、可持续派生的素材生态。

## 1. 两种案例级丰富度发动机

### RELATIONSHIP_DRIVEN

`关系命题 → 功能角色生态 → 冲突事件 → 地点／道具需求 → 状态变化 → 产品用途`

适合人物关系、叙事反转、生存抉择、身份冲突等方向。关系必须改变参与者、场所、行动或后果，不能只写背景故事。

### SYSTEM_DRIVEN

`产品系统 → 输入输出 → 所需资产 → 等级／状态 → 跨系统页面 → 产品用途`

适合城建、经营、SLG、二合、修复、养成等方向。系统必须制造不同的建筑、单位、地点、状态或屏幕需求，不能只增加菜单名称。

### HYBRID

关系事件必须触发系统状态变化，系统结果又必须反向改变人物关系或世界状态。两套清单并列不构成 Hybrid。

## 2. Material Fertility Pass

内部先产生 8–12 个 Direction Seeds。每个 Seed 在进入用户可见候选前，回答：

- 能否产生不同职能、轮廓和关系的角色生态；
- 能否产生世界专属的地点、建筑、道具或资源；
- 是否有可重复制造新事件的关系或系统发动机；
- 是否存在可见的状态、等级、控制权或时间变化；
- 是否能覆盖 Character、Environment、Gameplay、Narrative、UI/Screen、Packaging 中多个用途；
- 去掉题材名后，这些素材是否仍然只属于当前世界与方向。

只能支撑一张漂亮 KV 的 Seed 可以进入轻量 `PROTOTYPE`，但不能进入案例级 Portfolio。素材潜力不能用“预计可画很多张”代替，必须列出实际可派生的素材族和因果来源。

## 3. Direction Material DNA

每个进入 Portfolio 的方向建立八个素材域：

1. `character_ecology`：核心角色、支撑角色、NPC、职业、兵种、敌人与生物；
2. `space_ecology`：地点、建筑、功能区、室内外关系、地图与路径；
3. `threat_ecology`：风险来源、敌对关系、环境失效和反制方式；
4. `resource_prop_ecology`：资源、生产物、身份道具、交互道具；
5. `event_families`：能持续派生的关系、危机、建设、战斗和转折事件；
6. `state_chains`：身份、破损、修复、升级、占领、繁荣、危机与恢复；
7. `system_screen_families`：主城、地图、建造、经营、战斗、阵容、成长、任务、奖励等产品面；
8. `delivery_uses`：设定、阵容、Gameplay、剧情、Loading、KV、UI Detail、Offer 等交付用途。

DNA 项必须是方向专属的具体素材族或机制，不接受“更多角色”“若干地点”“丰富事件”之类占位概括。

## 4. 多方向差异门禁

每对正式方向都做成对比较：

1. `player_agent / relationship_engine / world_rule / core_loop` 至少一项真实不同；
2. 八个素材域至少三个不同；
3. `character_ecology / space_ecology / event_families / system_screen_families` 中至少两个不同；
4. 去掉题材名、画风、色彩、服装和镜头后，两组 Prompt 仍不可互换；
5. 不能由另一方向的一次换皮、换名或表现层编辑得到。

失败时合并、淘汰或回到 Operators 重新发散。不得用评分平均值保留一个本质重复的方向。

## 5. 两种 Portfolio 形态

- `MULTI_DIRECTION_DIVERGENCE`：3–5 个方向分别形成中型素材包，重点证明方向间素材差异；
- `SINGLE_DIRECTION_DEPTH`：一个方向沿资产、事件、状态和系统形成大型素材组合；
- `HYBRID_PORTFOLIO`：先完成多方向差异，再选择一个方向做系统级深化。

这些是 Lab 内部生产策略，不要求用户填写。用户已明确授权自主收敛时，Lab 可以记录自己的选择来源并继续，不把选择伪装成用户事实，也不因缺少表格确认而停工。

## 6. 反证

- 删除世界名词后仍适用于任何题材：World Binding 失败；
- 交换两个方向标题后素材清单仍成立：Direction Difference 失败；
- 去掉颜色、服装、比例和镜头后差异消失：Presentation-only；
- 十个 Prompt 可压缩成一个变量模板且因果不变：伪丰富度；
- Content Graph 很大但没有具体 Prompt：治理空转；
- Prompt 很长但只描述一个角色或一个场景：素材生态不足。

