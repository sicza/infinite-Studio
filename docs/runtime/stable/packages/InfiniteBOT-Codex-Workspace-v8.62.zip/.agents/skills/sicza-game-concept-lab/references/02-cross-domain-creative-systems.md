# Cross-domain System Transfer

## 目标

从真实行业借 **关系**，而不是借主题皮肤。适合题材有趣但玩法普通、多个方向像同类游戏、真实设施复杂却没有系统感时。

## 1. 先写当前缺口

例如：“需要玩家亲自在避难所跑动处理高频现场需求，并看到空间恢复。”再寻找拥有相似关系的真实系统，而不是随机列行业。

## 2. 拆 Source System

任何行业至少回答：What enters / leaves / acts / is processed / scarce / delayed / fails / how success is measured。

压成：`INPUT → DECISION → PROCESS → OUTPUT → FEEDBACK`，并标记 `Capacity / Priority / Flow / Failure / Recovery`。

## 3. 常用系统语法

### Hotel / Service

`Demand → Travel → Service → Customer State → Value → Capacity → More Demand`

可迁移：现场任务节奏、短循环、空间扩张。不要搬酒店房间/前台皮肤。

### Airport / Transfer Hub

`Arrival → Gate Assignment → Screening → Transfer → Departure`

关键：容量、延误、优先级、连接时间、路线。适合人口流、检疫、节点调度。

### Hospital

`Arrival → Triage → Diagnosis → Priority → Treatment → Recovery/Isolation`

关键：有限资源下的优先级，而不是白墙/病床。

### Logistics Hub

`Input → Sort → Store → Route → Transport → Deliver`

关键：吞吐、瓶颈、距离、优先级、车辆、路径故障。

### Factory

`Raw Material → Process A → Intermediate → Process B → Product`

关键：依赖链、停机传播、维修、物流。

### Port / Container Terminal

`Ship Arrival → Unload → Stack → Sort → Crane Move → Rail/Truck/Ship Dispatch`

关键：模块化、重量、堆叠、吊机 Reach、到港窗口、拥堵。Container 可同时成为资源、建筑模块、货物或人口单元。

### Mining

`Survey → Dig → Support → Extract → Transport → Process`

关键：深度作为 Progression，以及坍塌、气体、积水、热、设备故障。

### Submarine / Space Station

封闭 Habitat + 有限 Air/Power/Heat/Pressure + 相互依赖系统。强项是 Failure Propagation。

### Restaurant / Kitchen

`Order → Prepare → Process → Assemble → Deliver`

真正可借的是多工位并行、时间压力、顺序依赖。

### Emergency Response

`Incident → Detect → Assess → Prioritize → Dispatch → Stabilize → Recover`

强项是不可预测事件与优先级重分配。

### Theme Park

`Attraction → Visitor Flow → Queue → Capacity → Satisfaction → Expansion`

强项是 Gameplay Reward 与 Visual Spectacle 天然绑定。

### Hive / Ant Colony

`Distributed Agents → Specialized Roles → Resource Trails → Expansion → Collective Response`

适合 NPC-heavy Diorama、群体流与角色分工。

### Ecosystem

不是线性生产，而是 `A affects B → B affects C → C feeds back to A`。适合 Benefit × Risk、非二元威胁。

### Market / Exchange

`Supply × Demand × Information × Access`。重点是谁缺什么、谁知道什么、谁能到哪里、什么时候能交易。

## 4. Mapping

写清：`SOURCE ELEMENT → CURRENT WORLD ELEMENT`，然后强制让当前世界反过来改变 Source System。

例如机场 Gate Assignment 进入灾后地铁后，叠加疾病、有限氧气、断线列车，就会变成“谁能进站、谁必须隔离、哪列车值得冒险发出”的生存决策。

## 5. 只迁移有价值的关系

如果只需要 Hotel 的“Avatar 现场处理需求→即时反馈→空间增长”，不要把前台、客房、房价也搬过去。

可以组合两个来源，但每个来源必须解决不同问题，例如 Hotel 提供现场任务 Rhythm，Hospital 提供有限资源下的优先级。

## 6. Visual / Character Consequence

好的跨域迁移必须改变画面和人物。引入 Triage 就应出现筛查通道、隔离区、检测设备与不同人口流；引入港口吊机系统则会自然产生吊机操作员、Rigging Specialist、Salvage Diver 等职业。

## 7. 输出

`Current Problem / Source System / Source Grammar / Borrowed Relationship / Current-world Mapping / World Mutation / Gameplay Consequence / Visual Consequence / Character Consequence / What Not To Copy`

删除源行业表面外观后，新玩法仍成立，才算 Transfer 完成。

## 8. 从系统关系派生素材

案例级任务不能停在 Source Grammar。每个有效关系继续编译为：

`Responsible Roles / Dependent Roles / Functional Spaces / Equipment & Resources / Failure Events / Recovery States / System Screens / Cross-system Uses`

例如引入 Triage 不只产生“分诊玩法”，还应产生筛查人员、等待者、隔离对象、检测设备、分流通道、风险状态、恢复结果与对应界面。若迁移没有改变素材生态，它仍只是概念说明。

关系驱动方向则反向检查：人物关系必须制造不同地点、道具、事件与状态需求。完整方法见 `16-direction-material-divergence.md`。
