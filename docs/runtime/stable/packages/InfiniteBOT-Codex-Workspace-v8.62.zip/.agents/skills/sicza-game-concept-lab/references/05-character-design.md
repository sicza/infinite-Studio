# Character Design & Pose/Anatomy

## 目标

把角色概念设计成具体、可信、有辨识度、能直接生图且能持续复用的角色。不是填 `Age / Face / Hair / Clothes / Weapon` 表格，而是建立 `World + Gameplay + Role + Personality + Body + Recognition → Visible Design` 的因果。职业/功能型角色先做 Job Model；强 IP、品牌角色、Mascot、二次元/商业角色还必须进入 `05a-ip-character-system.md` 与 `05b-character-identity-grammar.md`。

## 1. 先做 Job Model

禁止先画脸。先回答：

- 他真实负责什么，不只是职业名？
- 一天反复做哪些 5–8 个动作？
- 工作环境的温度、湿度、光线、空间、危险是什么？
- 什么最容易出错？
- 哪些装备/服装限制由这些动作和风险直接产生？

把事实压成 3–5 个 **Design Drivers**，每个 Driver 必须产生 Visible Decision。

例：双手维修→主工具可快速收纳；低照度→头灯/胸灯进入稳定轮廓；高压→绝缘手套/靴/握柄；狭窄攀爬→短外套而非长风衣。

角色设计不只有 Functional Driver。长期 IP 可同时使用：`Functional Driver / Identity Driver / Iconic Driver`。高权重特征必须能归因到 World、Gameplay、Role、Personality、Recognition 或 Camera，但不要求所有 Icon 都强行解释成现实功能。

## 2. 年龄

年龄来自 `Training Requirement / Experience / Physical Requirement / Leadership / Narrative Tone`，不是“29岁更帅”。

参考阶段：Junior 18–24；Early Professional 24–30；Experienced Field Professional 30–40；Senior Specialist 40–55；Veteran 55+。最终锁具体年龄，并能解释为何需要这个经验/体力组合。

## 3. Body & Proportion

体型从职业动作推导：耐力型→lean/compact；重搬运→厚肩背/前臂；长距离侦查→轻量耐力；管理角色可弱化体力特征。

头身比同时服务 Camera 与 Gameplay：

- 7.5–8H：写实/半写实、第三人称、角色驱动。
- 6–7H：Stylized Realism。
- 4.5–6H：Stylized 3D、45°/经营 Hybrid，手/工具更可读。
- 3–4H：Diorama、大量 NPC、系统管理。

比例变化必须同步 Hands/Feet/Equipment/Torso/Costume Shape，不是只缩腿。长期 IP 还应记录 `Body Mass Distribution`：Shoulder/Head、Ribcage、Waist、Pelvis、Upper-vs-Lower Mass、Arm/Leg Thickness、Limb Taper、Hand/Foot Scale、Center of Visual Mass。只有参考事实支持时才使用数字 ratio；否则使用明确相对关系，禁止伪精确。

## 4. Face

先定大几何：脸长宽、下颌、颧骨、额头、下巴，再定眉眼鼻口。正式角色进一步冻结 Face Bounding Shape、Jaw Curve、Cheekbone Position、Eye Spacing/Tilt、Brow、Nose Bridge/Tip、Mouth Width、Chin、Hairline、Ear Exposure。中远景识别优先发型轮廓、脸型、眉眼结构、头部装备、颜色分区；不要把身份全压在小疤痕/痣/异色瞳。

## 5. Hair

由 Job / Environment / Maintenance / Silhouette 决定。工业维修中的长发必须有合理固定方式，不能为了帅长期披散进机械区域。

## 6. Costume Architecture

按功能分层：Inner / Middle Uniform / Outer Protection / Bottom / Footwear / Hands。每层说明解决的环境与动作问题。

鞋和手套不是末尾装饰；湿金属地面→防滑，电气→绝缘，重工业→强化鞋头。

## 7. Functional Prop

默认先设计 `Primary Functional Prop / Secondary Functional Prop / Protection / Carry System / Utility Gear`。只有 Combat 真在 Gameplay 里才设计 Weapon。

所有道具必须说明持握/挂载/背负位置。角色需要两手工作时，主工具必须有合理收纳。

## 8. Material / Color / Silhouette

分清主织物、防护材料、硬质设备、软附件、磨损表面。颜色先从 World/Job/Recognition/Hazard 功能分配大色块，不平均撒装饰色。

缩成黑剪影后仍应通过 Body Proportion、Head Gear、Main Prop、Carry Shape、Costume Big Shapes 认出角色。

至少一个主要识别来自当前世界，例如“旧地铁检修电池箱改成背部电源模块”，而不是 generic tactical backpack。

## 9. Pose & Anatomy Correction

用于站姿、动作迁移、骑乘、驾驶、坐姿、头颈连接与局部人体纠错。Pose Reference 默认只提供 `Skeleton Relationship / Weight Distribution / Direction / Action`，不自动提供 Identity、Body、Costume。

### 分析顺序

`Support → Center of Gravity → Pelvis → Spine → Ribcage → Shoulders → Head/Neck → Arms → Legs → Feet`

不要先修手指/衣褶。

### Support / Center of Gravity

先明确身体由哪只脚、双脚、座椅、墙、手等支撑。重心必须落在有效支撑区。明确 Primary Support Leg 与 Secondary/Free Leg。

### Pelvis / Spine

骨盆 Tilt/Rotation/Height 必须与承重腿匹配；腿位变化往往需要骨盆和躯干平衡联动。脊柱从 Pelvis→Lumbar→Ribcage→Neck→Head 连续，不能腰部突然折断。

### Ribcage / Shoulders

动态姿势常通过 Pelvis 与 Ribcage 的相对旋转产生扭转；手臂前伸时肩带/肩胛也要联动，不能只旋转上臂。

### Head / Neck

区分 Eye Direction、Head Rotation、Neck Rotation、Torso Rotation。修正时对齐 Neck Axis 与 Upper Spine，并让 Neck 平滑连接 Trapezius/Shoulders，防止 Floating Head、Broken Neck、No Neck。

### Legs / Feet

检查 Hip→Femur→Knee→Shin→Ankle→Foot。Knee 与 Foot Direction 应形成合理运动链。双脚必须服从同一 Ground Plane Perspective，Heel/Toe/Sole 有真实接触。

### Prop Interaction

盾、重剑、方向盘、机器控制件都会改变肩臂受力与身体反平衡。道具不能只是粘在手上。

### Driving / Sitting

驾驶先确定 Seat / Foot Control / Hand Control 三组接触。人物必须在真实座椅高度、踏板、控制台 Reach 下成立；如果必须扭成不可能姿态才能够到方向盘，可能是 Cockpit Geometry Error，应回场景/载具结构，而不是继续扭人物。

坐姿检查 Seat Height/Depth、Hip、Knee Angle、Foot Contact、Back Support。

### Pose Transfer

从 Reference 提取 `Line of Action / Pelvis / Ribcage / Support Leg / Free Leg / Shoulder Relation / Arm Direction / Head Direction / Camera`，再映射到当前角色比例；不复制 Reference 的 Limb Length/Body Width。

### Local Edit

只修站姿时：Lock Identity → Identify Support → Fix Center of Gravity → Pelvis → Legs → Feet → Necessary Cloth Reaction。只有必要的 Fold/Stretch/Armor Angle/Cape Tension 属于 Derived Change。

## 10. Character Anchor

临时/一次性角色正式锁定：`Identity / Exact Age / Face Geometry / Hair / Body / Proportion / Costume Architecture / Primary Functional Prop / Carry System / Signature Color Placement / World-specific Hook`。

长期 IP / 多图复用角色不得停在这个轻量 Anchor；继续建立：

`IP DNA Anchor → Character Identity Anchor → Variant Grammar → Mother Reference Manifest`

详细规则见 `05a-ip-character-system.md` 与 `05b-character-identity-grammar.md`。3 个以上核心角色还必须建立 `05c-cast-architecture.md`。

## 11. 完成标准

不看名字也能读出角色 Role/Identity；不看世界观文字也能看到世界痕迹；功能型角色的主要道具与 Gameplay 直接相关；Iconic 特征不是随机装饰；服装和动作环境不冲突；比例适合 Camera；Full-body/Portrait/Action 可以复用同一 Anchor；Pose 修改不污染 Identity。长期 IP 还必须能回答：哪些 Identity 永远不动、哪些可变、Mother Reference 是什么、换装后如何证明仍是同一角色。
