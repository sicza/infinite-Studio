#!/usr/bin/env python3
"""Validate Game Concept Lab product, portfolio, evidence, and delivery contracts."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import tempfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

from prompt_portfolio import (
    PromptPortfolioError,
    build_selftest_fixture,
    load_json as load_prompt_portfolio_json,
    render_markdown as render_prompt_markdown,
    serialize_mechanism,
    selftest as prompt_portfolio_selftest,
    validate_portfolio as validate_prompt_portfolio,
)
from prompt_semantic_review import (
    PromptSemanticReviewError,
    build_selftest_review,
    load_json as load_prompt_semantic_review_json,
    selftest as prompt_semantic_review_selftest,
    validate_review as validate_prompt_semantic_review,
)


SKILL_ROOT = Path(__file__).resolve().parent.parent
SCHEMA_ROOT = SKILL_ROOT / "config" / "schemas"
SCHEMAS = {
    "product": "product-blueprint-schema.json",
    "prototype": "prototype-spec-schema.json",
    "graph": "content-graph-schema.json",
    "coverage": "coverage-plan-schema.json",
    "audit": "content-audit-schema.json",
}
PORTFOLIO_PROFILES = {"PORTFOLIO", "VERTICAL_SLICE"}
CRITICAL_ASSUMPTIONS = {"PLAYER_AGENT", "PRODUCT_TYPE", "TARGET_EXPERIENCE", "CORE_LOOP", "CONTENT_SCOPE"}
SEMANTIC_COUNTING_CLASSES = {"NEW_ASSET", "NEW_STATE", "NEW_EVENT", "NEW_SCREEN", "NEW_USE"}
IMAGE_EVIDENCE_KINDS = {"IMAGE", "SCREEN"}
PRESENTATION_ONLY_AXES = {
    "camera", "layout", "ui_visibility", "language", "crop", "color", "lighting", "effect", "expression",
    "costume", "face", "duplicate",
}
COUNTING_SEMANTIC_AXES = {
    "NEW_ASSET": {"identity", "core_topology", "functional_role"},
    "NEW_STATE": {"entry_trigger", "visible_delta", "gameplay_meaning", "exit_or_recovery"},
    "NEW_EVENT": {"cause", "action", "consequence"},
    "NEW_SCREEN": {"input", "state_change", "feedback", "result"},
    "NEW_USE": {"delivery_purpose"},
}
ASSET_TYPES = {
    "ASSET_CHARACTER", "ASSET_CREATURE", "ASSET_NPC_TEMPLATE", "ASSET_UNIT_TEMPLATE",
    "ASSET_BUILDING", "ASSET_LOCATION", "ASSET_PROP",
}
COUNTING_NODE_TYPES = {
    "NEW_ASSET": ASSET_TYPES,
    "NEW_STATE": {"STATE"},
    "NEW_EVENT": {"EVENT"},
    "NEW_SCREEN": {"SCREEN"},
    "NEW_USE": {"USE"},
}
CASE_EXPECTATIONS = {
    "CASE-01": "EXACT_DUPLICATE_ZERO_COVERAGE_DELTA",
    "CASE-02": "SAME_EVENT_STATE_VARIANTS",
    "CASE-03": "EVENT_LAYER_NOT_NEW_ASSET_OR_LOCATION",
    "CASE-04": "ONE_LOCATION_MULTIPLE_PRESENTATIONS_OR_STATES",
    "CASE-05": "FIVE_SCREEN_TEMPLATES_NOT_SEVENTEEN",
    "CASE-06": "SAME_ASSET_MULTIPLE_NAMES_AND_LABEL_DRIFT",
    "CASE-07": "SAME_ASSET_NAME_CONFLICT",
    "CASE-08": "SAME_ASSET_AND_SAME_NAME_DIFFERENT_ASSET_CONFLICT",
    "CASE-09": "CARD_SLOTS_NOT_UNIQUE_CHARACTERS",
    "CASE-10": "ROLE_FAMILIES_AND_CANDIDATE_BRANCHES",
    "CASE-11": "UNRESOLVED_NAME_CONFLICT_BLOCKS",
    "CASE-12": "PROPORTION_AND_COLOR_LIGHT_AXES_NOT_NEW_DIRECTIONS",
    "CASE-13": "REGION_EVIDENCE_AND_CROSS_SYSTEM_FLOW",
    "CASE-14": "PROVISIONAL_ALLOWED_PORTFOLIO_VERIFIED_BLOCKED",
    "CASE-15": "ORPHAN_EVIDENCE_BLOCKED",
    "CASE-16": "RELATIONSHIP_DRIVEN_THREE_MATERIAL_ECOSYSTEMS",
    "CASE-17": "SYSTEM_DRIVEN_CROSS_SURFACE_ECOSYSTEM",
    "CASE-18": "CASE_SCALE_MARKDOWN_PROMPT_PORTFOLIO",
}
CASE_SOURCE_IDS = {
    "CASE-01": ["B083", "B084", "B095", "B102"],
    "CASE-02": ["B085", "B086"],
    "CASE-03": ["B087", "B088"],
    "CASE-04": ["B090", "B091", "B092", "B093"],
    "CASE-05": [f"B{number:03d}" for number in range(36, 53)],
    "CASE-06": ["B119", "B120", "B121", "B142"],
    "CASE-07": ["B122", "B124", "B128"],
    "CASE-08": ["B123", "B135", "B121"],
    "CASE-09": ["B125", "B126"],
    "CASE-10": ["A015", "A024"],
    "CASE-11": ["A035", "A036", "A037", "A038"],
    "CASE-12": ["A047", "A048", "A049", "A050"],
    "CASE-13": ["B110"],
    "CASE-14": ["WORLD_ONLY"],
    "CASE-15": ["ORPHAN_EVIDENCE"],
    "CASE-16": ["A001", "A025", "A043"],
    "CASE-17": ["B006", "B019", "B028", "B036", "B095", "B103", "B110", "B111", "B119"],
    "CASE-18": ["A001", "A052", "B001", "B146"],
}
CASE_SOURCE_SNAPSHOT_SHA256 = "c0176e40cc150ace7036d063f7361d03947eebfcf44298c0e3851aaed0525989"
CASE_SOURCE_BINDING_DIGEST = "f11f08d5486be2ed4e2c269e1575819b921e8ebaefcf5895f5d6cda129884c60"


class PortfolioError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise PortfolioError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def stable_object_sha(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def bounded(root: Path, value: str | Path, *, exist: bool = False) -> Path:
    path = Path(value)
    path = (root / path if not path.is_absolute() else path).resolve()
    root = root.resolve()
    require(path == root or root in path.parents, f"path escapes Workspace: {value}")
    if exist:
        require(path.exists(), f"path does not exist: {value}")
    return path


def relative(root: Path, path: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def load_json(path: Path, label: str) -> dict[str, Any]:
    require(path.is_file(), f"{label} missing: {path}")
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise PortfolioError(f"invalid {label}: {exc}") from exc
    require(isinstance(data, dict), f"{label} root must be an object")
    return data


def _type_ok(value: Any, expected: str) -> bool:
    if expected == "object":
        return isinstance(value, dict)
    if expected == "array":
        return isinstance(value, list)
    if expected == "string":
        return isinstance(value, str)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    if expected == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool)
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "null":
        return value is None
    return False


def _resolve_ref(root_schema: dict[str, Any], value: str) -> dict[str, Any]:
    require(value.startswith("#/$defs/"), f"unsupported schema reference: {value}")
    key = value.split("/", 2)[-1]
    target = root_schema.get("$defs", {}).get(key)
    require(isinstance(target, dict), f"schema definition missing: {key}")
    return target


def validate_schema(value: Any, schema: dict[str, Any], *, root_schema: dict[str, Any] | None = None,
                    path: str = "$") -> list[str]:
    root_schema = schema if root_schema is None else root_schema
    errors: list[str] = []
    if "$ref" in schema:
        return validate_schema(value, _resolve_ref(root_schema, str(schema["$ref"])), root_schema=root_schema, path=path)
    if "anyOf" in schema:
        if not any(not validate_schema(value, branch, root_schema=root_schema, path=path) for branch in schema["anyOf"]):
            errors.append(f"{path}: does not match any allowed schema")
        return errors
    if "const" in schema and value != schema["const"]:
        errors.append(f"{path}: must equal {schema['const']!r}")
        return errors
    if "enum" in schema and value not in schema["enum"]:
        errors.append(f"{path}: must be one of {schema['enum']!r}")
        return errors
    expected = schema.get("type")
    if expected is not None:
        types = expected if isinstance(expected, list) else [expected]
        if not any(_type_ok(value, item) for item in types):
            errors.append(f"{path}: must be type {'/'.join(types)}")
            return errors
    if isinstance(value, str):
        if isinstance(schema.get("minLength"), int) and len(value) < schema["minLength"]:
            errors.append(f"{path}: string shorter than minLength")
        if isinstance(schema.get("pattern"), str) and re.search(schema["pattern"], value) is None:
            errors.append(f"{path}: string does not match pattern")
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if "minimum" in schema and value < schema["minimum"]:
            errors.append(f"{path}: below minimum {schema['minimum']}")
        if "maximum" in schema and value > schema["maximum"]:
            errors.append(f"{path}: above maximum {schema['maximum']}")
    if isinstance(value, list):
        if isinstance(schema.get("minItems"), int) and len(value) < schema["minItems"]:
            errors.append(f"{path}: fewer than {schema['minItems']} items")
        if schema.get("uniqueItems"):
            canonical = [json.dumps(item, ensure_ascii=False, sort_keys=True) for item in value]
            if len(canonical) != len(set(canonical)):
                errors.append(f"{path}: items must be unique")
        if isinstance(schema.get("items"), dict):
            for index, item in enumerate(value):
                errors.extend(validate_schema(item, schema["items"], root_schema=root_schema, path=f"{path}[{index}]"))
    if isinstance(value, dict):
        for key in schema.get("required", []):
            if key not in value:
                errors.append(f"{path}.{key}: required property missing")
        properties = schema.get("properties", {})
        if isinstance(properties, dict):
            for key, child in properties.items():
                if key in value:
                    errors.extend(validate_schema(value[key], child, root_schema=root_schema, path=f"{path}.{key}"))
        if schema.get("additionalProperties") is False and isinstance(properties, dict):
            for key in sorted(set(value) - set(properties)):
                errors.append(f"{path}.{key}: additional property is not allowed")
    return errors


def validate_with_schema(kind: str, data: dict[str, Any]) -> None:
    schema = load_json(SCHEMA_ROOT / SCHEMAS[kind], f"{kind} schema")
    errors = validate_schema(data, schema)
    require(not errors, f"{kind} schema failed: {'; '.join(errors[:12])}")


def evaluate_case_fixture(fixture: dict[str, Any], prompt_gate_results: dict[str, str] | None = None) -> str:
    operation = fixture.get("operation")
    if operation == "deduplicate_hashes":
        hashes = fixture["hashes"]
        return "EXACT_DUPLICATE_ZERO_COVERAGE_DELTA" if len(set(hashes)) < len(hashes) and fixture["duplicate_coverage_delta"] == 0 else "FAIL"
    if operation == "classify_event_variants":
        unchanged = not any(fixture[key] for key in ("cause_changed", "action_changed", "consequence_changed"))
        return "SAME_EVENT_STATE_VARIANTS" if fixture["same_event_id"] and unchanged and fixture["state_axes"] else "FAIL"
    if operation == "classify_event_layer":
        stable = fixture["asset_id_stable"] and fixture["location_id_stable"]
        return "EVENT_LAYER_NOT_NEW_ASSET_OR_LOCATION" if stable and fixture["event_layer"] else "FAIL"
    if operation == "normalize_location":
        signatures = fixture["topology_signatures"]
        return "ONE_LOCATION_MULTIPLE_PRESENTATIONS_OR_STATES" if len(set(signatures)) == 1 and fixture["changed_axes"] else "FAIL"
    if operation == "count_screen_templates":
        templates = fixture["template_ids"]
        return "FIVE_SCREEN_TEMPLATES_NOT_SEVENTEEN" if len(templates) == 17 and len(set(templates)) == 5 else "FAIL"
    if operation == "detect_label_drift":
        return "SAME_ASSET_MULTIPLE_NAMES_AND_LABEL_DRIFT" if len(set(fixture["identity_ids"])) == 1 and len(set(fixture["display_names"])) > 1 else "FAIL"
    if operation == "detect_same_asset_name_conflict":
        return "SAME_ASSET_NAME_CONFLICT" if len(set(fixture["identity_ids"])) == 1 and len(set(fixture["display_names"])) > 1 else "FAIL"
    if operation == "detect_bidirectional_identity_name_conflict":
        same_asset = len(set(fixture["same_asset_pair"])) == 1
        same_name_different_assets = len(set(fixture["same_name_identity_ids"])) > 1
        return "SAME_ASSET_AND_SAME_NAME_DIFFERENT_ASSET_CONFLICT" if same_asset and same_name_different_assets else "FAIL"
    if operation == "count_card_identities":
        return "CARD_SLOTS_NOT_UNIQUE_CHARACTERS" if fixture["slot_count"] > len(set(fixture["identity_ids"])) else "FAIL"
    if operation == "separate_role_families_and_branches":
        return "ROLE_FAMILIES_AND_CANDIDATE_BRANCHES" if fixture["candidate_count"] > fixture["approved_family_count"] and not fixture["identities_frozen"] else "FAIL"
    if operation == "block_open_name_conflict":
        return "UNRESOLVED_NAME_CONFLICT_BLOCKS" if fixture["conflict_status"] == "OPEN" else "FAIL"
    if operation == "reject_presentation_directions":
        axes = set(fixture["changed_axes"])
        semantic = any(fixture[key] for key in ("player_agent_changed", "product_type_changed", "core_loop_changed", "world_causality_changed"))
        return "PROPORTION_AND_COLOR_LIGHT_AXES_NOT_NEW_DIRECTIONS" if axes <= PRESENTATION_ONLY_AXES and not semantic else "FAIL"
    if operation == "require_long_image_regions_and_flow":
        long_image = max(fixture["width"], fixture["height"]) >= 8192 or max(fixture["width"], fixture["height"]) / min(fixture["width"], fixture["height"]) >= 3
        return "REGION_EVIDENCE_AND_CROSS_SYSTEM_FLOW" if long_image and fixture["region_count"] > 0 and fixture["cross_system_node_count"] >= 2 else "FAIL"
    if operation == "world_only_scope_gate":
        unresolved = any(status == "ASSUMED" for status in fixture["critical_assumption_statuses"])
        return "PROVISIONAL_ALLOWED_PORTFOLIO_VERIFIED_BLOCKED" if unresolved and fixture["prototype_allowed"] and not fixture["portfolio_verified_allowed"] else "FAIL"
    if operation == "portfolio_completion_blockers":
        blocked = fixture["missing_core_coverage"] or fixture["open_identity_conflict"] or fixture["orphan_evidence"]
        return "ORPHAN_EVIDENCE_BLOCKED" if blocked and not fixture["portfolio_verified_allowed"] else "FAIL"
    if operation == "relationship_material_ecosystems":
        directions = fixture["directions"]
        relationship_engines = {item["relationship_engine"] for item in directions}
        rich = all(
            item["character_families"] >= 4
            and item["location_families"] >= 2
            and item["event_families"] >= 2
            and item["delivery_uses"] >= 3
            for item in directions
        )
        return "RELATIONSHIP_DRIVEN_THREE_MATERIAL_ECOSYSTEMS" if len(directions) == 3 and len(relationship_engines) == 3 and rich else "FAIL"
    if operation == "system_material_ecosystem":
        required = {"main_city", "merge_build", "adventure", "restoration", "pve", "operations", "hero", "offer"}
        valid = (
            fixture["building_families"] >= 7
            and fixture["map_templates"] >= 5
            and required <= set(fixture["system_surfaces"])
            and fixture["cross_system_flow"]
        )
        return "SYSTEM_DRIVEN_CROSS_SURFACE_ECOSYSTEM" if valid else "FAIL"
    if operation == "prompt_portfolio_scale":
        if prompt_gate_results is None:
            prompt_gate_results = prompt_portfolio_selftest()
        required_results = fixture.get("required_prompt_gate_results", {})
        valid = (
            fixture["relationship_prompt_count"] == 52
            and fixture["system_prompt_count"] == 146
            and fixture["output_format"] == "MARKDOWN"
            and fixture["image_generation_required"] is False
            and isinstance(required_results, dict)
            and len(required_results) >= 10
            and all(prompt_gate_results.get(name) == expected for name, expected in required_results.items())
        )
        return "CASE_SCALE_MARKDOWN_PROMPT_PORTFOLIO" if valid else "FAIL"
    raise PortfolioError(f"unknown case semantic regression operation: {operation}")


def validate_case_semantic_fixture(fixture: dict[str, Any], prompt_gate_results: dict[str, str] | None = None) -> dict[str, str]:
    require(fixture.get("schema_version") == "sicza.game-concept.case-semantic-regression.v1",
            "case semantic regression schema mismatch")
    require(fixture.get("source_snapshot_sha256") == CASE_SOURCE_SNAPSHOT_SHA256,
            "case semantic regression source snapshot drift")
    cases = fixture.get("cases")
    require(isinstance(cases, list), "case semantic regression cases must be an array")
    ids = unique_ids(cases, "id", "case semantic regression ids")
    require(ids == set(CASE_EXPECTATIONS),
            f"case semantic regression coverage mismatch: missing={sorted(set(CASE_EXPECTATIONS) - ids)}, extra={sorted(ids - set(CASE_EXPECTATIONS))}")
    results: dict[str, str] = {}
    for item in cases:
        case_id = item["id"]
        require(item.get("expected_outcome") == CASE_EXPECTATIONS[case_id],
                f"case semantic regression outcome drift: {case_id}")
        source_ids = item.get("source_ids")
        require(source_ids == CASE_SOURCE_IDS[case_id],
                f"case semantic regression source_ids drift: {case_id}")
        source_hashes = item.get("source_sha256s")
        require(isinstance(source_hashes, dict) and set(source_hashes) == set(source_ids),
                f"case semantic regression source hashes incomplete: {case_id}")
        require(all(re.fullmatch(r"[a-f0-9]{64}", str(value)) for value in source_hashes.values()),
                f"case semantic regression source hash invalid: {case_id}")
        require(evaluate_case_fixture(item.get("fixture", {}), prompt_gate_results) == item["expected_outcome"],
                f"case semantic regression executable outcome failed: {case_id}")
        results[f"case_semantic_{case_id.lower().replace('-', '_')}"] = "PASS"
    bindings = [
        {"id": item["id"], "source_ids": item["source_ids"], "source_sha256s": item["source_sha256s"]}
        for item in cases
    ]
    require(stable_object_sha(bindings) == CASE_SOURCE_BINDING_DIGEST,
            "case semantic regression source binding digest mismatch")
    return results


def validate_case_semantic_regressions(prompt_gate_results: dict[str, str] | None = None) -> dict[str, str]:
    fixture = load_json(SKILL_ROOT / "config" / "case-semantic-regression.json", "case semantic regression fixture")
    return validate_case_semantic_fixture(fixture, prompt_gate_results)


def unique_ids(items: list[dict[str, Any]], field: str, label: str) -> set[str]:
    values = [str(item.get(field, "")) for item in items]
    duplicates = sorted(key for key, count in Counter(values).items() if count > 1)
    require(not duplicates, f"duplicate {label}: {duplicates}")
    return set(values)


def validate_counting_delta(item: dict[str, Any], nodes: dict[str, dict[str, Any]]) -> None:
    counting_class = item["counting_class"]
    delta = item["counting_delta"]
    semantic_axes = set(delta["semantic_axes"])
    presentation_axes = set(delta["presentation_only_axes"])
    require(presentation_axes <= PRESENTATION_ONLY_AXES,
            f"counting_delta contains invalid presentation axes: {item['evidence_id']}")
    require(presentation_axes <= set(item["variant_axes"]),
            f"counting_delta presentation axes are not bound to variant_axes: {item['evidence_id']}")
    if counting_class == "PRESENTATION_ONLY":
        require(not semantic_axes,
                f"PRESENTATION_ONLY evidence claims semantic axes: {item['evidence_id']}")
        require(delta["target_id"] is None or delta["target_id"] in item["graph_refs"],
                f"PRESENTATION_ONLY target is not bound to graph_refs: {item['evidence_id']}")
        return
    allowed_axes = COUNTING_SEMANTIC_AXES[counting_class]
    require(bool(semantic_axes) and semantic_axes <= allowed_axes,
            f"{counting_class} lacks a valid structured semantic delta: {item['evidence_id']}")
    target_id = delta["target_id"]
    require(target_id in item["graph_refs"] and target_id in nodes,
            f"counting_delta target is not bound to graph_refs: {item['evidence_id']} -> {target_id}")
    require(nodes[target_id]["type"] in COUNTING_NODE_TYPES[counting_class],
            f"counting_delta target type mismatches {counting_class}: {item['evidence_id']} -> {target_id}")


def validate_blueprint(data: dict[str, Any], root: Path) -> dict[str, Any]:
    validate_with_schema("product", data)
    for authority in data["input_authority"]:
        if authority["authority"] in {"PROJECT", "REFERENCE"}:
            require("sha256" in authority,
                    f"{authority['authority']} input authority lacks sha256: {authority['source']}")
            source = bounded(root, authority["source"], exist=True)
            require(source.is_file(), f"input authority source is not a file: {authority['source']}")
            require(authority["sha256"] == sha256(source),
                    f"input authority hash mismatch: {authority['source']}")
    system_ids = unique_ids(data["systems"], "id", "system ids")
    assumption_ids = unique_ids(data["assumptions"], "id", "assumption ids")
    test_ids = unique_ids(data["falsification_tests"], "id", "falsification test ids")
    missing_assumptions = sorted(CRITICAL_ASSUMPTIONS - assumption_ids)
    require(not missing_assumptions, f"blueprint omits critical assumption records: {missing_assumptions}")
    require(test_ids is not None, "blueprint identifiers invalid")
    for edge in data["system_edges"]:
        require(edge["from"] in system_ids and edge["to"] in system_ids,
                f"system edge references unknown system: {edge['from']} -> {edge['to']}")
    if data["scope_profile"] in PORTFOLIO_PROFILES:
        require(data.get("portfolio_output", "EVIDENCE") in {"EVIDENCE", "PROMPT_MARKDOWN", "BOTH"},
                "portfolio_output is invalid")
        unresolved = sorted(
            item["id"] for item in data["assumptions"]
            if item["status"] == "ASSUMED" and item["id"] in CRITICAL_ASSUMPTIONS
        )
        require(not unresolved, f"portfolio scope retains critical assumptions: {unresolved}")
        tests = data["falsification_tests"]
        require(any(item["status"] == "PASS" for item in tests), "portfolio scope requires at least one passed falsification test")
        require(not any(item["status"] == "FAIL" for item in tests), "portfolio scope contains failed falsification test")
    if data["scope_profile"] == "VERTICAL_SLICE":
        loop = data["experience_loop"]
        require(isinstance(loop, dict), "vertical slice requires experience_loop")
        sequences = [item["sequence"] for item in loop["steps"]]
        require(sequences == list(range(1, len(sequences) + 1)),
                "vertical slice experience_loop sequence must be contiguous from 1")
    return data


def validate_graph(data: dict[str, Any], product_id: str, blueprint: dict[str, Any]) -> tuple[dict[str, Any], dict[str, dict[str, Any]]]:
    validate_with_schema("graph", data)
    require(data["product_id"] == product_id, "content graph product_id mismatch")
    node_ids = unique_ids(data["nodes"], "id", "content node ids")
    unique_ids(data["edges"], "id", "content edge ids")
    nodes = {item["id"]: item for item in data["nodes"]}
    outgoing: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for edge in data["edges"]:
        require(edge["from"] in node_ids and edge["to"] in node_ids,
                f"content edge references unknown node: {edge['from']} -> {edge['to']}")
        require(edge["from"] != edge["to"], f"content edge cannot self-reference: {edge['id']}")
        outgoing[edge["from"]].append(edge)
    for node in data["nodes"]:
        if node["type"] == "VARIANT":
            require(any(edge["type"] == "VARIANT_OF" for edge in outgoing[node["id"]]),
                    f"variant node lacks VARIANT_OF edge: {node['id']}")
        if node["type"] == "STATE":
            require(any(edge["type"] == "STATE_OF" for edge in outgoing[node["id"]]),
                    f"state node lacks STATE_OF edge: {node['id']}")
        if node["type"] == "EVENT":
            kinds = {edge["type"] for edge in outgoing[node["id"]]}
            require("PARTICIPATES_IN" in kinds and "OCCURS_AT" in kinds,
                    f"event node must bind participant and location: {node['id']}")
        if node["type"] in {"ASSET_CHARACTER", "ASSET_CREATURE"} and node["status"] == "APPROVED":
            require(node["confidence"] >= 0.7, f"approved identity confidence below 0.7: {node['id']}")
            require(bool(node["facts"]), f"approved identity lacks facts: {node['id']}")
    active_nodes = [item for item in data["nodes"] if item["status"] != "REJECTED"]
    count_map = {
        "core_characters": sum(item["type"] == "ASSET_CHARACTER" for item in active_nodes),
        "npc_templates": sum(item["type"] == "ASSET_NPC_TEMPLATE" for item in active_nodes),
        "unit_templates": sum(item["type"] == "ASSET_UNIT_TEMPLATE" for item in active_nodes),
        "building_families": sum(item["type"] == "ASSET_BUILDING" for item in active_nodes),
        "location_families": sum(item["type"] == "ASSET_LOCATION" for item in active_nodes),
        "events": sum(item["type"] == "EVENT" for item in active_nodes),
        "states": sum(item["type"] == "STATE" for item in active_nodes),
        "screen_templates": sum(item["type"] == "SCREEN" for item in active_nodes),
    }
    for field, actual in count_map.items():
        require(blueprint["content_scope"][field] == actual,
                f"content_scope {field} mismatch: planned={blueprint['content_scope'][field]}, graph={actual}")
    blueprint_systems = {item["id"] for item in blueprint["systems"]}
    graph_systems = {item["id"] for item in active_nodes if item["type"] == "SYSTEM"}
    require(graph_systems <= blueprint_systems,
            f"content graph contains systems absent from blueprint: {sorted(graph_systems - blueprint_systems)}")
    if blueprint["scope_profile"] == "VERTICAL_SLICE":
        loop = blueprint["experience_loop"]
        steps = loop["steps"]
        require(loop["entry_state_id"] in nodes and nodes[loop["entry_state_id"]]["type"] == "STATE",
                "vertical slice entry_state_id must reference a STATE node")
        require(loop["exit_state_id"] in nodes and nodes[loop["exit_state_id"]]["type"] == "STATE",
                "vertical slice exit_state_id must reference a STATE node")
        require(loop["entry_state_id"] == steps[0]["state_before_id"],
                "vertical slice entry_state_id must equal the first step state_before_id")
        require(loop["exit_state_id"] == steps[-1]["state_after_id"],
                "vertical slice exit_state_id must equal the final step state_after_id")
        for current, following in zip(steps, steps[1:]):
            require(current["state_after_id"] == following["state_before_id"],
                    "vertical slice state sequence is disconnected: "
                    f"{current['state_after_id']} != {following['state_before_id']}")
        transitions = {(edge["from"], edge["to"]) for edge in data["edges"] if edge["type"] == "TRANSITIONS_TO"}
        for step in steps:
            require(step["system_id"] in blueprint_systems,
                    f"vertical slice step references unknown system: {step['system_id']}")
            before, after, screen = step["state_before_id"], step["state_after_id"], step["screen_id"]
            require(step["system_id"] in nodes and nodes[step["system_id"]]["type"] == "SYSTEM",
                    f"vertical slice system_id must reference a SYSTEM node: {step['system_id']}")
            require(before in nodes and nodes[before]["type"] == "STATE",
                    f"vertical slice state_before_id invalid: {before}")
            require(after in nodes and nodes[after]["type"] == "STATE",
                    f"vertical slice state_after_id invalid: {after}")
            require(screen in nodes and nodes[screen]["type"] == "SCREEN",
                    f"vertical slice screen_id invalid: {screen}")
            require((before, after) in transitions,
                    f"vertical slice lacks TRANSITIONS_TO edge: {before} -> {after}")
    return data, nodes


def validate_coverage(data: dict[str, Any], product_id: str, scope_profile: str,
                      nodes: dict[str, dict[str, Any]], blueprint: dict[str, Any]) -> tuple[dict[str, Any], set[str], dict[str, dict[str, Any]]]:
    validate_with_schema("coverage", data)
    require(data["product_id"] == product_id, "coverage product_id mismatch")
    require(data["scope_profile"] == scope_profile, "coverage scope_profile mismatch")
    unique_ids(data["slots"], "coverage_id", "coverage ids")
    slots = {item["coverage_id"]: item for item in data["slots"]}
    evidence_refs: set[str] = set()
    for slot in data["slots"]:
        for node_id in slot["required_graph_nodes"]:
            require(node_id in nodes, f"coverage references unknown graph node: {node_id}")
            require(nodes[node_id]["status"] != "REJECTED", f"coverage references rejected graph node: {node_id}")
        state_or_event = slot["required_state_or_event"]
        if state_or_event is not None:
            require(state_or_event in nodes and nodes[state_or_event]["type"] in {"STATE", "EVENT"},
                    f"coverage required_state_or_event invalid: {state_or_event}")
            require(nodes[state_or_event]["status"] != "REJECTED",
                    f"coverage references rejected state/event: {state_or_event}")
        use_id = slot["required_use"]
        require(use_id in nodes and nodes[use_id]["type"] == "USE", f"coverage required_use invalid: {use_id}")
        require(nodes[use_id]["status"] != "REJECTED", f"coverage references rejected use: {use_id}")
        if slot["status"] in {"OBSERVED", "APPROVED"}:
            require(bool(slot["evidence_refs"]), f"observed/approved coverage lacks evidence: {slot['coverage_id']}")
        if slot["status"] == "WAIVED":
            require(isinstance(slot["waiver"], str) and slot["waiver"].strip(),
                    f"waived coverage lacks reason: {slot['coverage_id']}")
        else:
            require(slot["waiver"] is None, f"non-waived coverage contains waiver: {slot['coverage_id']}")
        evidence_refs.update(slot["evidence_refs"])
    counts = Counter(slot["status"] for slot in data["slots"])
    summary = data["summary"]
    require(summary["planned"] == len(data["slots"]), "coverage summary planned count mismatch")
    require(summary["approved"] == counts["APPROVED"], "coverage summary approved count mismatch")
    require(summary["waived"] == counts["WAIVED"], "coverage summary waived count mismatch")
    require(summary["failed"] == counts["FAILED"], "coverage summary failed count mismatch")
    require(blueprint["content_scope"]["formal_evidence_items"] == len(data["slots"]),
            "content_scope formal_evidence_items does not match coverage slot count")
    if summary["coverage_status"] == "PASS":
        require(counts["APPROVED"] + counts["WAIVED"] == len(data["slots"]),
                "PASS coverage contains incomplete slots")
        require(counts["FAILED"] == 0, "PASS coverage contains failed slots")
    if scope_profile == "VERTICAL_SLICE":
        loop_nodes = {
            node_id
            for step in blueprint["experience_loop"]["steps"]
            for node_id in (step["system_id"], step["state_before_id"], step["state_after_id"], step["screen_id"])
        }
        covered_nodes = {
            node_id
            for slot in data["slots"] if slot["status"] == "APPROVED"
            for node_id in slot["required_graph_nodes"]
        }
        covered_nodes.update(
            slot["required_state_or_event"]
            for slot in data["slots"]
            if slot["status"] == "APPROVED" and slot["required_state_or_event"] is not None
        )
        require(loop_nodes <= covered_nodes,
                f"vertical slice loop nodes absent from approved Coverage: {sorted(loop_nodes - covered_nodes)}")
    return data, evidence_refs, slots


def _normalized_groups(groups: list[list[str]]) -> set[tuple[str, ...]]:
    return {tuple(sorted(group)) for group in groups}


def image_size(path: Path) -> tuple[int, int]:
    try:
        from PIL import Image, UnidentifiedImageError
    except ImportError as exc:
        raise PortfolioError("Pillow is required to validate image evidence") from exc
    try:
        with Image.open(path) as image:
            image.load()
            return int(image.width), int(image.height)
    except (OSError, UnidentifiedImageError) as exc:
        raise PortfolioError(f"image evidence cannot be decoded: {path}") from exc


def validate_audit(root: Path, data: dict[str, Any], product_id: str, graph: dict[str, Any],
                   nodes: dict[str, dict[str, Any]], coverage: dict[str, Any],
                   coverage_evidence: set[str], coverage_slots: dict[str, dict[str, Any]],
                   blueprint: dict[str, Any],
                   prompt_evidence: dict[str, dict[str, Any]] | None = None) -> dict[str, Any]:
    validate_with_schema("audit", data)
    require(data["product_id"] == product_id, "content audit product_id mismatch")
    inventory_ids = unique_ids(data["evidence_inventory"], "evidence_id", "evidence ids")
    actual_hashes: dict[str, list[str]] = defaultdict(list)
    evidence = {item["evidence_id"]: item for item in data["evidence_inventory"]}
    batch_counts = Counter(item["batch_id"] for item in data["evidence_inventory"])
    require(all(size <= 20 for size in batch_counts.values()),
            f"evidence batch exceeds 20 items: {dict(batch_counts)}")
    if len(evidence) > 20:
        require(sum(size < 10 for size in batch_counts.values()) <= 1,
                f"more than one evidence batch is below 10 items: {dict(batch_counts)}")
    for item in data["evidence_inventory"]:
        path = bounded(root, item["path"], exist=True)
        require(path.is_file(), f"evidence path is not a file: {item['path']}")
        require(path.stat().st_size == item["byte_size"], f"evidence byte_size mismatch: {item['evidence_id']}")
        actual = sha256(path)
        require(actual == item["sha256"], f"evidence hash mismatch: {item['evidence_id']}")
        content_hash = actual
        if item["evidence_kind"] == "CANONICAL_PROMPT":
            require(prompt_evidence is not None and item["evidence_id"] in prompt_evidence,
                    f"canonical prompt evidence is absent from prompt portfolio: {item['evidence_id']}")
            prompt = prompt_evidence[item["evidence_id"]]
            require(item.get("fragment_id") == prompt["prompt_id"],
                    f"canonical prompt fragment_id mismatch: {item['evidence_id']}")
            require(item.get("fragment_sha256") == prompt["prompt_sha256"],
                    f"canonical prompt fragment hash mismatch: {item['evidence_id']}")
            require(item["width"] is None and item["height"] is None and item["preview_path"] is None,
                    f"canonical prompt evidence must not claim image metadata: {item['evidence_id']}")
            require(len(item["image_specific_mechanisms"]) >= 8,
                    f"canonical prompt evidence has fewer than 8 visual mechanisms: {item['evidence_id']}")
            content_hash = prompt["prompt_sha256"]
        actual_hashes[content_hash].append(item["evidence_id"])
        for node_id in item["graph_refs"]:
            require(node_id in nodes, f"evidence references unknown graph node: {node_id}")
        for coverage_id in item["coverage_refs"]:
            require(coverage_id in coverage_slots,
                    f"evidence references unknown coverage slot: {coverage_id}")
            slot = coverage_slots[coverage_id]
            require(item["evidence_id"] in slot["evidence_refs"],
                    f"evidence/coverage binding is not reciprocal: {item['evidence_id']} -> {coverage_id}")
            require(item["evidence_kind"] == slot["evidence_kind"],
                    f"evidence kind differs from coverage slot: {item['evidence_id']} -> {coverage_id}")
        claims = {claim["coverage_id"]: claim for claim in item["coverage_claims"]}
        require(len(claims) == len(item["coverage_claims"]),
                f"duplicate evidence coverage claims: {item['evidence_id']}")
        require(set(claims) == set(item["coverage_refs"]),
                f"evidence coverage_claims do not match coverage_refs: {item['evidence_id']}")
        for coverage_id, claim in claims.items():
            require(claim["minimum_semantic_delta"] == coverage_slots[coverage_id]["minimum_semantic_delta"],
                    f"evidence minimum semantic delta is stale: {item['evidence_id']} -> {coverage_id}")
            require(claim["observed_semantic_delta"] == item["semantic_delta"],
                    f"evidence observed semantic delta mismatch: {item['evidence_id']} -> {coverage_id}")
        parent = item["parent_asset_or_screen_id"]
        if parent is not None:
            require(parent in nodes, f"evidence parent is unknown: {item['evidence_id']} -> {parent}")
            require(parent in item["graph_refs"], f"evidence parent must also appear in graph_refs: {item['evidence_id']}")
        validate_counting_delta(item, nodes)
        event_delta = item["event_delta"]
        if item["counting_class"] == "NEW_EVENT":
            require(isinstance(event_delta, dict),
                    f"NEW_EVENT requires structured event_delta: {item['evidence_id']}")
            event_id = event_delta["event_id"]
            require(event_id in item["graph_refs"] and event_id in nodes and nodes[event_id]["type"] == "EVENT",
                    f"event_delta is not bound to an EVENT graph_ref: {item['evidence_id']} -> {event_id}")
            require(any(event_delta[field] for field in ("cause_changed", "action_changed", "consequence_changed")),
                    f"NEW_EVENT lacks cause/action/consequence delta: {item['evidence_id']}")
            require(
                set(item["counting_delta"]["semantic_axes"])
                == {
                    axis for axis, field in (
                        ("cause", "cause_changed"), ("action", "action_changed"),
                        ("consequence", "consequence_changed")
                    ) if event_delta[field]
                },
                f"NEW_EVENT counting_delta disagrees with event_delta: {item['evidence_id']}"
            )
            axes = set(event_delta["presentation_only_axes"])
            require(axes <= PRESENTATION_ONLY_AXES,
                    f"event_delta contains non-presentation axes: {item['evidence_id']} -> {sorted(axes - PRESENTATION_ONLY_AXES)}")
            require(axes <= set(item["variant_axes"]),
                    f"event_delta presentation axes are not bound to variant_axes: {item['evidence_id']}")
        else:
            require(event_delta is None,
                    f"event_delta is only valid for NEW_EVENT evidence: {item['evidence_id']}")
        if item["evidence_kind"] in IMAGE_EVIDENCE_KINDS:
            require(bool(item["facts"]), f"image evidence lacks facts: {item['evidence_id']}")
            require(bool(item["judgements"]), f"image evidence lacks judgements: {item['evidence_id']}")
            require(bool(item["recommendations"]), f"image evidence lacks recommendations: {item['evidence_id']}")
            require(len(item["image_specific_mechanisms"]) >= 8,
                    f"image evidence has fewer than 8 specific mechanisms: {item['evidence_id']}")
            width, height = image_size(path)
            require((item["width"], item["height"]) == (width, height),
                    f"evidence dimensions mismatch: {item['evidence_id']}")
            require(isinstance(item["preview_path"], str) and item["preview_path"].strip(),
                    f"image evidence preview missing: {item['evidence_id']}")
            preview = bounded(root, item["preview_path"], exist=True)
            require(preview.is_file(), f"image evidence preview is not a file: {item['evidence_id']}")
            image_size(preview)
            for region in item["regions"]:
                box = region["bbox_normalized"]
                require(len(box) == 4 and box[0] < box[2] and box[1] < box[3],
                        f"invalid evidence region bounds: {item['evidence_id']} / {region['region_id']}")
            if max(width, height) >= 8192 or max(width, height) / min(width, height) >= 3:
                require(bool(item["regions"]), f"large/long image evidence requires region verification: {item['evidence_id']}")
    if prompt_evidence is not None:
        audit_prompt_ids = {
            item["evidence_id"] for item in data["evidence_inventory"]
            if item["evidence_kind"] == "CANONICAL_PROMPT"
        }
        require(audit_prompt_ids == set(prompt_evidence),
                "prompt portfolio and content audit evidence sets differ")
    require(data["inventory_count"] == len(evidence), "audit inventory_count mismatch")
    require(data["content_hash_unique_count"] == len(actual_hashes), "audit content_hash_unique_count mismatch")
    actual_duplicates = _normalized_groups([items for items in actual_hashes.values() if len(items) > 1])
    declared_duplicates = _normalized_groups(data["exact_duplicate_groups"])
    require(len(declared_duplicates) == len(data["exact_duplicate_groups"]),
            "exact duplicate groups contain repeated declarations")
    require(actual_duplicates == declared_duplicates,
            f"exact duplicate groups mismatch: actual={sorted(actual_duplicates)}, declared={sorted(declared_duplicates)}")
    for group in actual_duplicates:
        content_claims = sum(1 for evidence_id in group if evidence[evidence_id]["counting_class"] in SEMANTIC_COUNTING_CLASSES)
        require(content_claims <= 1, f"exact duplicate group counts as multiple semantic additions: {group}")
        covered_slots = {coverage_id for evidence_id in group for coverage_id in evidence[evidence_id]["coverage_refs"]}
        require(len(covered_slots) <= 1,
                f"exact duplicate group contributes to multiple coverage slots: {group} -> {sorted(covered_slots)}")
    near_members: set[str] = set()
    for group in data["near_duplicate_groups"]:
        require(all(item in inventory_ids for item in group["members"]),
                f"near duplicate group contains unknown evidence: {group['parent_id']}")
        require(group["parent_id"] in nodes or group["parent_id"] in inventory_ids,
                f"near duplicate parent is unknown: {group['parent_id']}")
        parent_node = group["parent_id"] if group["parent_id"] in nodes else evidence[group["parent_id"]]["parent_asset_or_screen_id"]
        if parent_node is not None:
            require(all(evidence[item]["parent_asset_or_screen_id"] == parent_node for item in group["members"]),
                    f"near duplicate members do not share declared parent: {group['parent_id']}")
        member_axes = {axis for member in group["members"] for axis in evidence[member]["variant_axes"]}
        require(set(group["changed_axes"]) <= member_axes,
                f"near duplicate changed_axes are not bound by member evidence: {group['parent_id']}")
        near_members.update(group["members"])
    require(coverage_evidence <= inventory_ids,
            f"coverage references evidence absent from audit inventory: {sorted(coverage_evidence - inventory_ids)}")
    require(inventory_ids <= coverage_evidence,
            f"audit inventory contains orphan evidence: {sorted(inventory_ids - coverage_evidence)}")
    require(data["coverage_result"] == coverage["summary"], "audit coverage_result does not match coverage plan summary")
    for coverage_id, slot in coverage_slots.items():
        if slot["status"] != "APPROVED":
            continue
        slot_evidence = [evidence[item] for item in slot["evidence_refs"]]
        require(slot_evidence, f"approved coverage has no evidence: {coverage_id}")
        if slot["counting_class"] == "PRESENTATION_ONLY":
            require(all(item["counting_class"] == "PRESENTATION_ONLY" for item in slot_evidence),
                    f"presentation-only coverage contains semantic evidence: {coverage_id}")
        else:
            semantic_items = [item for item in slot_evidence if item["counting_class"] != "PRESENTATION_ONLY"]
            require(len(semantic_items) == 1 and semantic_items[0]["counting_class"] == slot["counting_class"],
                    f"coverage must contain exactly one matching semantic claim: {coverage_id}")
            require(all(item["counting_class"] in {slot["counting_class"], "PRESENTATION_ONLY"}
                        for item in slot_evidence),
                    f"coverage/evidence counting_class mismatch: {coverage_id}")
        graph_union = {node for item in slot_evidence for node in item["graph_refs"]}
        required_nodes = set(slot["required_graph_nodes"]) | {slot["required_use"]}
        if slot["required_state_or_event"] is not None:
            required_nodes.add(slot["required_state_or_event"])
        require(required_nodes <= graph_union,
                f"coverage evidence does not prove required graph nodes: {coverage_id} missing {sorted(required_nodes - graph_union)}")
    all_conflicts = (
        data["identity_conflicts"] + data["topology_conflicts"] +
        data["name_conflicts"] + data["variant_axis_conflicts"]
    )
    for conflict in all_conflicts:
        require(all(node in nodes for node in conflict["nodes"]), f"conflict references unknown graph node: {conflict['id']}")
        if conflict["status"] in {"RESOLVED", "ACCEPTED"}:
            require(bool(conflict["resolution"].strip()), f"closed conflict lacks resolution: {conflict['id']}")
    duplicate_names: list[set[str]] = []
    by_name: dict[str, set[str]] = defaultdict(set)
    for node in nodes.values():
        if node["type"] in ASSET_TYPES:
            by_name[node["name"].casefold()].add(node["id"])
    duplicate_names = [value for value in by_name.values() if len(value) > 1]
    declared_name_sets = [set(item["nodes"]) for item in data["name_conflicts"]]
    for group in duplicate_names:
        require(any(group <= declared for declared in declared_name_sets),
                f"same-name assets lack name_conflict record: {sorted(group)}")
    identity_conflict_sets = [set(item["nodes"]) for item in data["identity_conflicts"] + data["name_conflicts"]]
    topology_conflict_sets = [set(item["nodes"]) for item in data["topology_conflicts"]]
    for group in actual_duplicates:
        parents = {evidence[item]["parent_asset_or_screen_id"] for item in group
                   if evidence[item]["parent_asset_or_screen_id"] is not None}
        if len(parents) <= 1:
            continue
        relevant = identity_conflict_sets if any(nodes[parent]["type"] == "ASSET_CHARACTER" for parent in parents) else topology_conflict_sets
        require(any(parents <= declared for declared in relevant),
                f"exact duplicate bound to different parent identities without conflict: {sorted(parents)}")
    contradiction_pairs = {
        frozenset((edge["from"], edge["to"]))
        for edge in graph.get("edges", []) if edge.get("type") == "CONTRADICTS"
    }
    if contradiction_pairs:
        conflict_pairs = {frozenset(item["nodes"]) for item in all_conflicts}
        require(all(any(pair <= declared for declared in conflict_pairs) for pair in contradiction_pairs),
                "CONTRADICTS edges lack conflict records")
    active_nodes = [item for item in graph["nodes"] if item["status"] != "REJECTED"]
    expected_semantic_counts = {
        "asset_families": sum(item["type"] in ASSET_TYPES for item in active_nodes),
        "states": sum(item["type"] == "STATE" for item in active_nodes),
        "events": sum(item["type"] == "EVENT" for item in active_nodes),
        "screen_templates": sum(item["type"] == "SCREEN" for item in active_nodes),
        "product_directions": blueprint["content_scope"]["directions"],
    }
    direction_ids = unique_ids(data["direction_inventory"], "direction_id", "direction ids")
    direction_by_id = {item["direction_id"]: item for item in data["direction_inventory"]}
    roots = [item for item in data["direction_inventory"] if item["parent_direction_id"] is None and item["status"] != "REJECTED"]
    require(len(roots) == 1, "direction inventory requires exactly one approved root direction")
    root_direction_id = roots[0]["direction_id"]
    for direction in data["direction_inventory"]:
        presentation_axes = set(direction["presentation_only_axes"])
        require(presentation_axes <= PRESENTATION_ONLY_AXES,
                f"direction contains invalid presentation axes: {direction['direction_id']}")
        parent_id = direction["parent_direction_id"]
        semantic_change = any(direction[field] for field in (
            "player_agent_changed", "product_type_changed", "core_loop_changed", "world_causality_changed"
        ))
        if parent_id is None:
            require(not semantic_change, f"root direction cannot claim parent-relative change: {direction['direction_id']}")
        else:
            require(parent_id in direction_ids and parent_id != direction["direction_id"],
                    f"direction parent invalid: {direction['direction_id']} -> {parent_id}")
            require(semantic_change,
                    f"presentation-only variant cannot count as a new direction: {direction['direction_id']}")
        if direction["status"] == "REJECTED":
            continue
        seen: set[str] = set()
        cursor = direction
        while cursor["parent_direction_id"] is not None:
            cursor_id = cursor["direction_id"]
            require(cursor_id not in seen,
                    f"direction parent cycle detected from: {direction['direction_id']}")
            seen.add(cursor_id)
            cursor = direction_by_id[cursor["parent_direction_id"]]
            require(cursor["status"] != "REJECTED",
                    f"approved direction descends from rejected parent: {direction['direction_id']}")
        require(cursor["direction_id"] == root_direction_id,
                f"approved direction does not reach the root: {direction['direction_id']}")
    expected_semantic_counts["product_directions"] = sum(
        item["status"] != "REJECTED" for item in direction_by_id.values()
    )
    require(blueprint["content_scope"]["directions"] == expected_semantic_counts["product_directions"],
            "content_scope directions does not match approved direction inventory")
    require(data["semantic_counts"] == expected_semantic_counts,
            f"audit semantic_counts mismatch: expected={expected_semantic_counts}")
    require(data["status"] == "PASS", "content audit status must be PASS before completion")
    require(data["coverage_result"]["coverage_status"] == "PASS", "PASS audit requires PASS coverage")
    require(not any(item["blocking"] for item in data["unresolved_unknowns"]),
            "PASS audit contains blocking unknowns")
    require(not any(item["status"] == "OPEN" for item in all_conflicts), "PASS audit contains open conflicts")
    return data


def validate_manifest(root: Path, request: Path, scope_profile: str, portfolio_output: str,
                      prompt_result: dict[str, Any] | None,
                      semantic_review_result: dict[str, Any] | None) -> list[dict[str, Any]]:
    manifest_path = request / "work" / "delivery-manifest.json"
    manifest = load_json(manifest_path, "delivery manifest")
    require(set(manifest) == {"files"} and isinstance(manifest["files"], list), "delivery manifest schema invalid")
    active: list[dict[str, Any]] = []
    for index, item in enumerate(manifest["files"]):
        require(isinstance(item, dict), f"delivery files[{index}] must be object")
        require({"role", "source", "sha256", "active"} <= set(item), f"delivery files[{index}] missing fields")
        path = bounded(root, item["source"], exist=True)
        require(path.is_file() and request / "work" in path.parents, "delivery source must be inside request work/")
        require(item["sha256"] == sha256(path), f"delivery hash mismatch: {item['source']}")
        if item["active"] is True:
            active.append(item)
    by_role = Counter(str(item["role"]) for item in active)
    if by_role["interactive_html"]:
        require(by_role["interactive_html"] == 1, "delivery requires one active role=interactive_html")
        unexpected_roles = sorted(role for role in by_role if role not in {"interactive_html", "generated_original"})
        require(not unexpected_roles,
                f"HTML delivery contains non-standard active roles: {unexpected_roles}")
        return active
    require(by_role["concept_proposal"] == 1, "delivery requires one active role=concept_proposal")
    require(by_role["product_blueprint"] == 1, "delivery requires one active role=product_blueprint")
    canonical = {
        "concept_proposal": request / "work" / "final" / "game-concept-proposal.md",
        "product_blueprint": request / "work" / "concept-lab" / "product-blueprint.json",
        "prototype_spec": request / "work" / "concept-lab" / "prototype-spec.json",
        "content_graph": request / "work" / "concept-lab" / "content-graph.json",
        "coverage_plan": request / "work" / "concept-lab" / "coverage-plan.json",
        "content_audit": request / "work" / "concept-lab" / "content-audit.json",
        "prompt_portfolio_manifest": request / "work" / "concept-lab" / "prompt-portfolio.json",
        "prompt_semantic_review": request / "work" / "concept-lab" / "prompt-semantic-review.json",
        "prompt_semantic_review_report": request / "work" / "final" / "prompt-semantic-review.md",
    }
    for item in active:
        role = str(item["role"])
        if role in canonical:
            require(bounded(root, item["source"]) == canonical[role].resolve(),
                    f"delivery role {role} must reference canonical path {relative(root, canonical[role])}")
    common_roles = {"concept_proposal", "product_blueprint", "production_anchors"}
    if scope_profile in PORTFOLIO_PROFILES:
        allowed_roles = common_roles | {"content_graph", "coverage_plan", "content_audit"}
        if portfolio_output in {"PROMPT_MARKDOWN", "BOTH"}:
            allowed_roles |= {
                "prompt_portfolio_manifest", "prompt_semantic_review",
                "prompt_semantic_review_report", "prompt_markdown",
            }
    else:
        allowed_roles = common_roles | {"prototype_spec", "prototype_prompts"}
    unexpected_roles = sorted(role for role in by_role if role not in allowed_roles)
    require(not unexpected_roles,
            f"active delivery roles are not allowed for this scope/output: {unexpected_roles}")
    if scope_profile in PORTFOLIO_PROFILES:
        for role in ("content_graph", "coverage_plan", "content_audit"):
            require(by_role[role] == 1, f"portfolio delivery requires one active role={role}")
        if portfolio_output in {"PROMPT_MARKDOWN", "BOTH"}:
            require(by_role["prompt_portfolio_manifest"] == 1,
                    "prompt portfolio delivery requires one active role=prompt_portfolio_manifest")
            require(prompt_result is not None, "prompt portfolio delivery lacks validated prompt result")
            require(by_role["prompt_semantic_review"] == 1,
                    "prompt portfolio delivery requires one active role=prompt_semantic_review")
            require(by_role["prompt_semantic_review_report"] == 1,
                    "prompt portfolio delivery requires one active role=prompt_semantic_review_report")
            require(semantic_review_result is not None,
                    "prompt portfolio delivery lacks independent semantic review")
            require(
                semantic_review_result["report_path"]
                == relative(root, canonical["prompt_semantic_review_report"]),
                "semantic review binding must reference the canonical delivered review report",
            )
            prompt_files = {
                str(item["source"]) for item in active if item["role"] == "prompt_markdown"
            }
            require(prompt_files == set(prompt_result["markdown_paths"]),
                    "delivery prompt_markdown files differ from prompt portfolio manifest")
    else:
        require(by_role["prototype_spec"] == 1, "prototype delivery requires one active role=prototype_spec")
    return active


def validate_prototype_spec(data: dict[str, Any], product_id: str) -> dict[str, Any]:
    validate_with_schema("prototype", data)
    require(data["product_id"] == product_id, "prototype spec product_id mismatch")
    unique_ids(data["test_assets"], "id", "prototype test asset ids")
    require(all(item["status"] == "READY" for item in data["test_assets"]),
            "prototype completion requires every test asset status=READY")
    return data


def validate_visual_trace(root: Path, request: Path, scope_profile: str, *, required: bool) -> None:
    visual_spec = request / "work" / "visual-spec.json"
    if not visual_spec.is_file():
        require(not required, "approved IMAGE/SCREEN coverage requires work/visual-spec.json")
        return
    data = load_json(visual_spec, "visual spec")
    trace = data.get("authority_trace")
    require(isinstance(trace, list), "visual spec authority_trace missing")
    traced = {str(item.get("path")): str(item.get("sha256")) for item in trace if isinstance(item, dict)}
    required = [request / "work" / "concept-lab" / "product-blueprint.json"]
    if scope_profile in PORTFOLIO_PROFILES:
        required.extend([
            request / "work" / "concept-lab" / "content-graph.json",
            request / "work" / "concept-lab" / "coverage-plan.json",
        ])
    for path in required:
        rel = relative(root, path)
        require(traced.get(rel) == sha256(path), f"visual spec does not bind current concept authority: {rel}")


def validate(root: Path, request: Path) -> dict[str, Any]:
    state = load_json(request / "state.json", "state")
    require(state.get("primary_skill") == "sicza-game-concept-lab",
            "portfolio gate only applies to sicza-game-concept-lab")
    base = request / "work" / "concept-lab"
    blueprint_path = base / "product-blueprint.json"
    blueprint = validate_blueprint(load_json(blueprint_path, "product blueprint"), root)
    scope_profile = blueprint["scope_profile"]
    product_id = blueprint["product_id"]
    portfolio_output = blueprint.get("portfolio_output", "EVIDENCE")
    graph_path = base / "content-graph.json"
    coverage_path = base / "coverage-plan.json"
    audit_path = base / "content-audit.json"
    prototype_path = base / "prototype-spec.json"
    portfolio_files = [graph_path, coverage_path, audit_path]
    if scope_profile in PORTFOLIO_PROFILES:
        require(all(path.is_file() for path in portfolio_files), "portfolio scope requires content graph, coverage plan, and content audit")
    else:
        require(prototype_path.is_file(), "prototype scope requires work/concept-lab/prototype-spec.json")
        validate_prototype_spec(load_json(prototype_path, "prototype spec"), product_id)
        if any(path.exists() for path in portfolio_files):
            require(all(path.is_file() for path in portfolio_files), "partial portfolio contract is forbidden")

    counts = {"graph_nodes": 0, "coverage_slots": 0, "evidence_items": 0, "prompt_count": 0}
    visual_spec_required = False
    prompt_result: dict[str, Any] | None = None
    semantic_review_result: dict[str, Any] | None = None
    if all(path.is_file() for path in portfolio_files):
        graph, nodes = validate_graph(load_json(graph_path, "content graph"), product_id, blueprint)
        coverage, coverage_evidence, coverage_slots = validate_coverage(
            load_json(coverage_path, "coverage plan"), product_id, scope_profile, nodes, blueprint
        )
        if portfolio_output in {"PROMPT_MARKDOWN", "BOTH"}:
            prompt_manifest_path = base / "prompt-portfolio.json"
            require(prompt_manifest_path.is_file(), "prompt portfolio output requires prompt-portfolio.json")
            try:
                prompt_result = validate_prompt_portfolio(
                    load_prompt_portfolio_json(prompt_manifest_path), root,
                    product_id=product_id, graph_ids=nodes, coverage_slots=coverage_slots,
                )
            except PromptPortfolioError as exc:
                raise PortfolioError(str(exc)) from exc
            semantic_review_path = base / "prompt-semantic-review.json"
            semantic_report_path = request / "work" / "final" / "prompt-semantic-review.md"
            require(semantic_review_path.is_file(),
                    "prompt portfolio output requires prompt-semantic-review.json")
            require(semantic_report_path.is_file(),
                    "prompt portfolio output requires final/prompt-semantic-review.md")
            try:
                semantic_review_result = validate_prompt_semantic_review(
                    load_prompt_semantic_review_json(semantic_review_path, "prompt semantic review"),
                    root, load_prompt_portfolio_json(prompt_manifest_path), prompt_manifest_path,
                )
            except PromptSemanticReviewError as exc:
                raise PortfolioError(str(exc)) from exc
        visual_spec_required = any(
            slot["status"] == "APPROVED" and slot["evidence_kind"] in IMAGE_EVIDENCE_KINDS
            for slot in coverage["slots"]
        )
        audit = load_json(audit_path, "content audit")
        validate_audit(root, audit, product_id, graph, nodes, coverage, coverage_evidence,
                       coverage_slots, blueprint,
                       prompt_result["prompt_by_evidence"] if prompt_result is not None else None)
        counts = {
            "graph_nodes": len(graph["nodes"]),
            "coverage_slots": len(coverage["slots"]),
            "evidence_items": len(audit["evidence_inventory"]),
            "prompt_count": prompt_result["prompt_count"] if prompt_result is not None else 0,
        }

    final = request / "work" / "final" / "game-concept-proposal.md"
    require(final.is_file() and len(final.read_text(encoding="utf-8").strip()) >= 200,
            "work/final/game-concept-proposal.md is required")
    proposal = final.read_text(encoding="utf-8")
    require(product_id in proposal, "concept proposal must name product_id")
    review = request / "work" / "final-review.md"
    require(review.is_file() and review.read_text(encoding="utf-8").strip(), "work/final-review.md is required")
    review_text = review.read_text(encoding="utf-8")
    require(scope_profile in review_text, "final review must state scope_profile")
    review_lines = {line.strip() for line in review_text.splitlines()}
    if scope_profile in PORTFOLIO_PROFILES:
        require("PORTFOLIO_VERIFIED" in review_lines, "portfolio final review must state PORTFOLIO_VERIFIED")
        if portfolio_output in {"PROMPT_MARKDOWN", "BOTH"}:
            require("PROMPT_PORTFOLIO_VERIFIED" in review_lines,
                    "prompt portfolio final review must state PROMPT_PORTFOLIO_VERIFIED")
            require("PROMPT_SEMANTIC_REVIEW_PASS" in review_lines,
                    "prompt portfolio final review must state PROMPT_SEMANTIC_REVIEW_PASS")
    else:
        require("DIRECTION_PROPOSED" in review_lines or "PROTOTYPE_SPECIFIED" in review_lines,
                "prototype final review must state DIRECTION_PROPOSED or PROTOTYPE_SPECIFIED")
    active = validate_manifest(
        root, request, scope_profile, portfolio_output, prompt_result, semantic_review_result
    )
    validate_visual_trace(root, request, scope_profile, required=visual_spec_required)
    return {
        "status": "passed",
        "scope_profile": scope_profile,
        "product_id": product_id,
        "active_delivery_count": len(active),
        **counts,
    }


def _write(path: Path, value: str | dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(value, str):
        path.write_text(value, encoding="utf-8")
    else:
        path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _minimal_blueprint(scope: str) -> dict[str, Any]:
    return {
        "schema_version": "sicza.game-concept.product-blueprint.v1",
        "product_id": "selftest-game",
        "scope_profile": scope,
        "input_authority": [{"source": "request.md", "authority": "USER"}],
        "explicit_user_locks": ["test"],
        "assumptions": [
            {"id": item, "statement": f"{item} confirmed by selftest fixture", "status": "CONFIRMED", "evidence": "selftest"}
            for item in sorted(CRITICAL_ASSUMPTIONS)
        ],
        "player_agent": "builder",
        "product_type": "strategy",
        "target_platform": ["desktop"],
        "target_experience": ["planning"],
        "core_loop": ["observe", "choose", "resolve"],
        "meta_loop": ["expand"],
        "world_rules": [{"id": "WORLD-001", "rule": "roads decay", "gameplay_effect": "routes change", "status": "CONFIRMED"}],
        "systems": [{"id": "SYS-CORE", "name": "core", "input": "plan", "action": "place", "state": "route", "feedback": "traffic", "output": "access"}],
        "system_edges": [],
        "experience_loop": None,
        "content_scope": {"directions": 1, "core_characters": 1, "npc_templates": 0, "unit_templates": 0, "building_families": 0, "location_families": 1, "events": 1, "states": 0, "screen_templates": 0, "formal_evidence_items": 1},
        "known_unknowns": [],
        "falsification_tests": [{"id": "TEST-CORE", "claim": "choice matters", "test": "compare two choices", "fail_condition": "same outcome", "status": "PASS"}],
    }


def _prompt_portfolio_integration_selftest(root: Path) -> dict[str, str]:
    results: dict[str, str] = {}
    request = root / "requests" / "game-concept-lab" / "prompt-portfolio-selftest"
    base = request / "work" / "concept-lab"
    final = request / "work" / "final"
    final.mkdir(parents=True)
    _write(request / "state.json", {"primary_skill": "sicza-game-concept-lab", "status": "active", "revision": 1})
    _write(request / "request.md", "Create an autonomous prompt portfolio for a route-repair world.\n")
    prompt_manifest, _, _ = build_selftest_fixture(
        request, count=20, direction_count=1, shape="SINGLE_DIRECTION_DEPTH"
    )
    prompt_manifest["product_id"] = "prompt-portfolio-selftest"
    prompt_manifest["scale_tier"] = "STANDARD"
    for index, path_text in enumerate(prompt_manifest["markdown_files"]):
        prompt_manifest["markdown_files"][index] = relative(root, request / path_text)
    for direction in prompt_manifest["directions"]:
        direction["origin_evidence"]["path"] = relative(root, request / direction["origin_evidence"]["path"])
    for prompt in prompt_manifest["prompts"]:
        prompt["markdown_path"] = relative(root, request / prompt["markdown_path"])
        prompt["graph_refs"].append("USE-PROMPT")
    render_prompt_markdown(prompt_manifest, root)
    prompt_manifest_path = base / "prompt-portfolio.json"
    _write(prompt_manifest_path, prompt_manifest)
    semantic_review_path = base / "prompt-semantic-review.json"
    semantic_report_path = final / "prompt-semantic-review.md"
    semantic_review = build_selftest_review(
        prompt_manifest, root, prompt_manifest_path, semantic_review_path, semantic_report_path,
        reviewer_id="independent-semantic-reviewer-selftest",
    )

    blueprint = _minimal_blueprint("PORTFOLIO")
    blueprint["product_id"] = "prompt-portfolio-selftest"
    blueprint["portfolio_output"] = "PROMPT_MARKDOWN"
    blueprint["content_scope"] = {
        "directions": 1, "core_characters": 0, "npc_templates": 0, "unit_templates": 0,
        "building_families": 0, "location_families": 0, "events": 0, "states": 0,
        "screen_templates": 0, "formal_evidence_items": 20,
    }
    blueprint_path = base / "product-blueprint.json"
    _write(blueprint_path, blueprint)

    nodes = []
    for prompt in prompt_manifest["prompts"]:
        asset_id = prompt["graph_refs"][0]
        nodes.append({
            "id": asset_id, "type": "ASSET_PROP", "name": prompt["title"], "authority": "FROZEN",
            "status": "APPROVED", "confidence": 1, "source_refs": [],
            "direction_refs": [prompt["direction_id"]], "facts": [prompt["semantic_delta"]],
            "judgements": [], "unknowns": [], "attributes": {},
        })
    nodes.append({
        "id": "USE-PROMPT", "type": "USE", "name": "canonical prompt", "authority": "FROZEN",
        "status": "APPROVED", "confidence": 1, "source_refs": [], "direction_refs": ["DIRECTION-D1"],
        "facts": ["user-visible Markdown prompt"], "judgements": [], "unknowns": [], "attributes": {},
    })
    graph = {
        "schema_version": "sicza.game-concept.content-graph.v1",
        "product_id": "prompt-portfolio-selftest", "nodes": nodes, "edges": [],
    }
    graph_path = base / "content-graph.json"
    _write(graph_path, graph)

    slots = []
    evidence_items = []
    for index, prompt in enumerate(prompt_manifest["prompts"]):
        coverage_id = prompt["coverage_refs"][0]
        asset_id = prompt["graph_refs"][0]
        slots.append({
            "coverage_id": coverage_id, "purpose": prompt["image_contract"]["purpose"],
            "required_graph_nodes": [asset_id], "required_state_or_event": None,
            "required_use": "USE-PROMPT", "evidence_kind": "CANONICAL_PROMPT",
            "minimum_semantic_delta": prompt["semantic_delta"], "counting_class": "NEW_ASSET",
            "status": "APPROVED", "evidence_refs": [prompt["evidence_id"]], "waiver": None,
        })
        markdown_path = bounded(root, prompt["markdown_path"], exist=True)
        evidence_items.append({
            "evidence_id": prompt["evidence_id"],
            "batch_id": f"BATCH-{index // 10 + 1:03d}", "evidence_kind": "CANONICAL_PROMPT",
            "path": prompt["markdown_path"], "byte_size": markdown_path.stat().st_size,
            "width": None, "height": None, "preview_path": None, "sha256": sha256(markdown_path),
            "fragment_id": prompt["prompt_id"], "fragment_sha256": prompt["prompt_sha256"],
            "graph_refs": prompt["graph_refs"], "coverage_refs": [coverage_id],
            "coverage_claims": [{
                "coverage_id": coverage_id, "minimum_semantic_delta": prompt["semantic_delta"],
                "observed_semantic_delta": prompt["semantic_delta"],
            }],
            "parent_asset_or_screen_id": asset_id, "variant_axes": [],
            "semantic_delta": prompt["semantic_delta"], "counting_class": "NEW_ASSET",
            "counting_delta": {
                "target_id": asset_id, "semantic_axes": ["functional_role"], "presentation_only_axes": [],
            },
            "event_delta": None, "facts": ["canonical prompt exists in Markdown"],
            "judgements": ["prompt adds a functional asset"], "recommendations": ["retain prompt"],
            "unknowns": [],
            "image_specific_mechanisms": [serialize_mechanism(item) for item in prompt["visual_mechanisms"]],
            "regions": [],
        })
    coverage = {
        "schema_version": "sicza.game-concept.coverage-plan.v1",
        "product_id": "prompt-portfolio-selftest", "scope_profile": "PORTFOLIO", "slots": slots,
        "summary": {"planned": 20, "approved": 20, "waived": 0, "failed": 0, "coverage_status": "PASS"},
    }
    coverage_path = base / "coverage-plan.json"
    _write(coverage_path, coverage)
    audit = {
        "schema_version": "sicza.game-concept.content-audit.v1", "product_id": "prompt-portfolio-selftest",
        "inventory_count": 20, "content_hash_unique_count": 20,
        "semantic_counts": {"asset_families": 20, "states": 0, "events": 0, "screen_templates": 0, "product_directions": 1},
        "direction_inventory": [{
            "direction_id": "DIRECTION-D1", "parent_direction_id": None,
            "player_agent_changed": False, "product_type_changed": False,
            "core_loop_changed": False, "world_causality_changed": False,
            "presentation_only_axes": [], "status": "APPROVED",
        }],
        "evidence_inventory": evidence_items, "exact_duplicate_groups": [], "near_duplicate_groups": [],
        "identity_conflicts": [], "topology_conflicts": [], "name_conflicts": [],
        "variant_axis_conflicts": [], "coverage_result": coverage["summary"],
        "unresolved_unknowns": [], "reviewer_findings": ["prompt-only integration selftest"], "status": "PASS",
    }
    audit_path = base / "content-audit.json"
    _write(audit_path, audit)
    proposal = final / "game-concept-proposal.md"
    _write(proposal, "# prompt-portfolio-selftest\n\nThis request proves that the existing Game Concept Lab can preserve its product blueprint, content graph, coverage, semantic counting, and delivery contracts while compiling a complete prompt-only portfolio. The user-visible evidence is a Markdown collection of independent canonical prompts; no generated image, preview, image dimensions, or image-quality claim is required.\n")
    review_path = request / "work" / "final-review.md"
    _write(
        review_path,
        "scope_profile: PORTFOLIO\nPORTFOLIO_VERIFIED\nPROMPT_PORTFOLIO_VERIFIED\n"
        "PROMPT_SEMANTIC_REVIEW_PASS\n",
    )
    role_paths = {
        "concept_proposal": [proposal], "product_blueprint": [blueprint_path],
        "content_graph": [graph_path], "coverage_plan": [coverage_path],
        "content_audit": [audit_path], "prompt_portfolio_manifest": [prompt_manifest_path],
        "prompt_semantic_review": [semantic_review_path],
        "prompt_semantic_review_report": [semantic_report_path],
        "prompt_markdown": [bounded(root, value, exist=True) for value in prompt_manifest["markdown_files"]],
    }
    delivery = {"files": [
        {"role": role, "source": relative(root, path), "sha256": sha256(path), "active": True}
        for role, paths in role_paths.items() for path in paths
    ]}
    _write(request / "work" / "delivery-manifest.json", delivery)
    result = validate(root, request)
    require(result["status"] == "passed" and result["prompt_count"] == 20,
            "prompt-only portfolio integration fixture failed")
    results["valid_prompt_only_portfolio_integration"] = "PASS"
    alternate_report_path = request / "work" / "private-semantic-review.md"
    _write(alternate_report_path, semantic_report_path.read_text(encoding="utf-8"))
    mismatched_report_review = json.loads(json.dumps(semantic_review))
    mismatched_report_review["report_binding"] = {
        "path": relative(root, alternate_report_path), "sha256": sha256(alternate_report_path),
    }
    _write(semantic_review_path, mismatched_report_review)
    mismatched_report_delivery = json.loads(json.dumps(delivery))
    for item in mismatched_report_delivery["files"]:
        if item["role"] == "prompt_semantic_review":
            item["sha256"] = sha256(semantic_review_path)
    _write(request / "work" / "delivery-manifest.json", mismatched_report_delivery)
    try:
        validate(root, request)
    except PortfolioError:
        results["semantic_review_report_delivery_binding"] = "BLOCK"
    else:
        raise PortfolioError("semantic review bound a different report than the delivered canonical report")
    _write(semantic_review_path, semantic_review)
    _write(request / "work" / "delivery-manifest.json", delivery)
    semantic_review_path.unlink()
    try:
        validate(root, request)
    except PortfolioError:
        results["missing_independent_semantic_review"] = "BLOCK"
    else:
        raise PortfolioError("missing independent semantic review unexpectedly passed")
    _write(semantic_review_path, semantic_review)
    tampered = json.loads(json.dumps(audit))
    tampered["evidence_inventory"][0]["fragment_sha256"] = "0" * 64
    _write(audit_path, tampered)
    try:
        validate(root, request)
    except PortfolioError:
        results["prompt_fragment_tamper"] = "BLOCK"
    else:
        raise PortfolioError("tampered prompt fragment unexpectedly passed")
    return results


def selftest() -> dict[str, str]:
    results: dict[str, str] = {}
    with tempfile.TemporaryDirectory(prefix="game-concept-portfolio-") as td:
        root = Path(td)
        request = root / "requests" / "game-concept-lab" / "selftest"
        base = request / "work" / "concept-lab"
        final = request / "work" / "final"
        final.mkdir(parents=True)
        _write(request / "state.json", {"primary_skill": "sicza-game-concept-lab", "status": "active", "revision": 1})
        _write(request / "request.md", "selftest-game\n")
        blueprint = _minimal_blueprint("PORTFOLIO")
        _write(base / "product-blueprint.json", blueprint)

        graph = {
            "schema_version": "sicza.game-concept.content-graph.v1", "product_id": "selftest-game",
            "nodes": [
                {"id": "ASSET-LOCATION", "type": "ASSET_LOCATION", "name": "road", "authority": "FROZEN", "status": "APPROVED", "confidence": 1, "source_refs": [], "facts": ["road"], "judgements": [], "unknowns": [], "attributes": {}},
                {"id": "EVENT-DECAY", "type": "EVENT", "name": "decay", "authority": "FROZEN", "status": "APPROVED", "confidence": 1, "source_refs": [], "facts": ["decay"], "judgements": [], "unknowns": [], "attributes": {}},
                {"id": "ASSET-PLAYER", "type": "ASSET_CHARACTER", "name": "builder", "authority": "FROZEN", "status": "APPROVED", "confidence": 1, "source_refs": [], "facts": ["player"], "judgements": [], "unknowns": [], "attributes": {}},
                {"id": "USE-GAMEPLAY", "type": "USE", "name": "gameplay", "authority": "FROZEN", "status": "APPROVED", "confidence": 1, "source_refs": [], "facts": ["screen"], "judgements": [], "unknowns": [], "attributes": {}}
            ],
            "edges": [
                {"id": "EDGE-PART", "type": "PARTICIPATES_IN", "from": "EVENT-DECAY", "to": "ASSET-PLAYER", "reason": "player responds"},
                {"id": "EDGE-PLACE", "type": "OCCURS_AT", "from": "EVENT-DECAY", "to": "ASSET-LOCATION", "reason": "road decays"}
            ]
        }
        _write(base / "content-graph.json", graph)
        evidence_path = request / "work" / "evidence.png"
        try:
            from PIL import Image
        except ImportError as exc:
            raise PortfolioError("Pillow is required for Portfolio Gate selftest") from exc
        evidence_path.parent.mkdir(parents=True, exist_ok=True)
        Image.new("RGB", (8, 6), (120, 80, 40)).save(evidence_path)
        evidence_hash = sha256(evidence_path)
        coverage = {
            "schema_version": "sicza.game-concept.coverage-plan.v1", "product_id": "selftest-game", "scope_profile": "PORTFOLIO",
            "slots": [{"coverage_id": "COV-CORE", "purpose": "prove loop", "required_graph_nodes": ["ASSET-LOCATION", "ASSET-PLAYER"], "required_state_or_event": "EVENT-DECAY", "required_use": "USE-GAMEPLAY", "evidence_kind": "IMAGE", "minimum_semantic_delta": "shows changed route", "counting_class": "NEW_EVENT", "status": "APPROVED", "evidence_refs": ["EVID-CORE"], "waiver": None}],
            "summary": {"planned": 1, "approved": 1, "waived": 0, "failed": 0, "coverage_status": "PASS"}
        }
        _write(base / "coverage-plan.json", coverage)
        audit = {
            "schema_version": "sicza.game-concept.content-audit.v1", "product_id": "selftest-game",
            "inventory_count": 1, "content_hash_unique_count": 1,
            "semantic_counts": {"asset_families": 2, "states": 0, "events": 1, "screen_templates": 0, "product_directions": 1},
            "direction_inventory": [{
                "direction_id": "DIRECTION-ROOT", "parent_direction_id": None,
                "player_agent_changed": False, "product_type_changed": False,
                "core_loop_changed": False, "world_causality_changed": False,
                "presentation_only_axes": [], "status": "APPROVED"
            }],
            "evidence_inventory": [{
                "evidence_id": "EVID-CORE", "batch_id": "BATCH-001", "evidence_kind": "IMAGE",
                "path": relative(root, evidence_path), "byte_size": evidence_path.stat().st_size,
                "width": 8, "height": 6, "preview_path": relative(root, evidence_path), "sha256": evidence_hash,
                "graph_refs": ["ASSET-LOCATION", "ASSET-PLAYER", "EVENT-DECAY", "USE-GAMEPLAY"],
                "coverage_refs": ["COV-CORE"],
                "coverage_claims": [{"coverage_id": "COV-CORE", "minimum_semantic_delta": "shows changed route", "observed_semantic_delta": "shows changed route"}],
                "parent_asset_or_screen_id": None, "variant_axes": [],
                "semantic_delta": "shows changed route", "counting_class": "NEW_EVENT",
                "counting_delta": {"target_id": "EVENT-DECAY", "semantic_axes": ["cause", "consequence"], "presentation_only_axes": []},
                "event_delta": {
                    "event_id": "EVENT-DECAY", "cause_changed": True, "action_changed": False,
                    "consequence_changed": True, "participants_changed": False,
                    "location_changed": False, "presentation_only_axes": []
                },
                "facts": ["fixture image exists"], "judgements": ["event is evidenced"],
                "recommendations": ["retain event"], "unknowns": [],
                "image_specific_mechanisms": ["route", "surface", "camera", "contrast", "state", "target", "feedback", "landmark"],
                "regions": []
            }],
            "exact_duplicate_groups": [], "near_duplicate_groups": [], "identity_conflicts": [], "topology_conflicts": [], "name_conflicts": [], "variant_axis_conflicts": [],
            "coverage_result": coverage["summary"], "unresolved_unknowns": [], "reviewer_findings": ["selftest"], "status": "PASS"
        }
        _write(base / "content-audit.json", audit)
        proposal = final / "game-concept-proposal.md"
        _write(proposal, "# selftest-game\n\nThis portfolio fixture documents the player, route-decay event, visible state change, coverage purpose, evidence binding, content graph authority, and completion boundary. It is intentionally substantive enough to prove the canonical proposal path while all semantic facts remain machine-bound in the four portfolio contracts.\n")
        _write(request / "work" / "final-review.md", "scope_profile: PORTFOLIO\nPORTFOLIO_VERIFIED\n")
        role_paths = {
            "concept_proposal": proposal,
            "product_blueprint": base / "product-blueprint.json",
            "content_graph": base / "content-graph.json",
            "coverage_plan": base / "coverage-plan.json",
            "content_audit": base / "content-audit.json",
        }
        def refresh_portfolio_fixture(current_blueprint: dict[str, Any], current_graph: dict[str, Any],
                                      current_coverage: dict[str, Any], current_audit: dict[str, Any]) -> dict[str, Any]:
            _write(base / "product-blueprint.json", current_blueprint)
            _write(base / "content-graph.json", current_graph)
            _write(base / "coverage-plan.json", current_coverage)
            _write(base / "content-audit.json", current_audit)
            _write(request / "work" / "final-review.md",
                   f"scope_profile: {current_blueprint['scope_profile']}\nPORTFOLIO_VERIFIED\n")
            current_manifest = {
                "files": [
                    {"role": role, "source": relative(root, path), "sha256": sha256(path), "active": True}
                    for role, path in role_paths.items()
                ]
            }
            _write(request / "work" / "delivery-manifest.json", current_manifest)
            _write(request / "work" / "visual-spec.json", {"authority_trace": [
                {"path": relative(root, base / "product-blueprint.json"), "sha256": sha256(base / "product-blueprint.json")},
                {"path": relative(root, base / "content-graph.json"), "sha256": sha256(base / "content-graph.json")},
                {"path": relative(root, base / "coverage-plan.json"), "sha256": sha256(base / "coverage-plan.json")},
            ]})
            return current_manifest

        manifest = refresh_portfolio_fixture(blueprint, graph, coverage, audit)
        require(validate(root, request)["status"] == "passed", "valid portfolio fixture failed")
        results["valid_portfolio"] = "PASS"
        unreviewed_prompt = final / "unreviewed-prompt.md"
        _write(
            unreviewed_prompt,
            "# Unreviewed Prompt\n\nA complete-looking prompt must not be delivered through EVIDENCE mode.\n",
        )
        for role, result_name in (
            ("prompt_markdown", "evidence_mode_unreviewed_prompt_delivery"),
            ("prototype_prompts", "evidence_mode_prototype_prompt_delivery"),
        ):
            evidence_mode_prompt_delivery = json.loads(json.dumps(manifest))
            evidence_mode_prompt_delivery["files"].append({
                "role": role, "source": relative(root, unreviewed_prompt),
                "sha256": sha256(unreviewed_prompt), "active": True,
            })
            _write(request / "work" / "delivery-manifest.json", evidence_mode_prompt_delivery)
            try:
                validate(root, request)
            except PortfolioError:
                results[result_name] = "BLOCK"
            else:
                raise PortfolioError(f"EVIDENCE mode delivered unreviewed active role={role}")
        _write(request / "work" / "delivery-manifest.json", manifest)
        results["valid_new_event_delta"] = "PASS"
        semantic_nodes = {
            **{item["id"]: item for item in graph["nodes"]},
            "STATE-DELTA": {"id": "STATE-DELTA", "type": "STATE"},
            "SCREEN-DELTA": {"id": "SCREEN-DELTA", "type": "SCREEN"},
        }
        for test_name, counting_class, target_id, semantic_axis in (
            ("valid_new_asset_delta", "NEW_ASSET", "ASSET-PLAYER", "identity"),
            ("valid_new_state_delta", "NEW_STATE", "STATE-DELTA", "gameplay_meaning"),
            ("valid_new_screen_delta", "NEW_SCREEN", "SCREEN-DELTA", "state_change"),
            ("valid_new_use_delta", "NEW_USE", "USE-GAMEPLAY", "delivery_purpose"),
        ):
            validate_counting_delta({
                "evidence_id": f"EVID-{test_name.upper()}", "counting_class": counting_class,
                "graph_refs": [target_id], "variant_axes": [],
                "counting_delta": {"target_id": target_id, "semantic_axes": [semantic_axis], "presentation_only_axes": []},
            }, semantic_nodes)
            results[test_name] = "PASS"
        for test_name, counting_class, target_id, presentation_axis in (
            ("color_only_new_state", "NEW_STATE", "STATE-DELTA", "color"),
            ("layout_only_new_screen", "NEW_SCREEN", "SCREEN-DELTA", "layout"),
            ("crop_only_new_use", "NEW_USE", "USE-GAMEPLAY", "crop"),
        ):
            try:
                validate_counting_delta({
                    "evidence_id": f"EVID-{test_name.upper()}", "counting_class": counting_class,
                    "graph_refs": [target_id], "variant_axes": [presentation_axis],
                    "counting_delta": {"target_id": target_id, "semantic_axes": [], "presentation_only_axes": [presentation_axis]},
                }, semantic_nodes)
            except PortfolioError:
                results[test_name] = "BLOCK"
            else:
                raise PortfolioError(f"presentation-only evidence unexpectedly counted as {counting_class}")

        alternate_proposal = request / "work" / "alternate-proposal.md"
        _write(alternate_proposal, proposal.read_text(encoding="utf-8"))
        noncanonical_manifest = json.loads(json.dumps(manifest))
        concept_entry = next(item for item in noncanonical_manifest["files"] if item["role"] == "concept_proposal")
        concept_entry["source"] = relative(root, alternate_proposal)
        concept_entry["sha256"] = sha256(alternate_proposal)
        _write(request / "work" / "delivery-manifest.json", noncanonical_manifest)
        try:
            validate(root, request)
        except PortfolioError:
            results["noncanonical_manifest_role"] = "BLOCK"
        else:
            raise PortfolioError("noncanonical manifest role selftest unexpectedly passed")
        _write(request / "work" / "delivery-manifest.json", manifest)

        vertical = json.loads(json.dumps(blueprint))
        vertical["scope_profile"] = "VERTICAL_SLICE"
        vertical["experience_loop"] = {
            "entry_state_id": "STATE-BEFORE", "exit_state_id": "STATE-AFTER",
            "steps": [{"sequence": 1, "system_id": "SYS-CORE", "input": "repair", "state_before_id": "STATE-BEFORE", "transition_rule": "repair completes", "state_after_id": "STATE-AFTER", "visible_feedback": "route lights", "output": "access", "screen_id": "SCREEN-CORE"}],
            "end_condition": "route open", "failure_or_exit": "resource depleted", "recovery": "collect repair parts", "next_run_difference": "new route available"
        }
        vertical_coverage = json.loads(json.dumps(coverage))
        vertical_coverage["scope_profile"] = "VERTICAL_SLICE"
        _write(base / "product-blueprint.json", vertical)
        _write(base / "coverage-plan.json", vertical_coverage)
        try:
            validate(root, request)
        except PortfolioError:
            results["vertical_slice_missing_state_sequence"] = "BLOCK"
        else:
            raise PortfolioError("vertical slice without graph state sequence unexpectedly passed")
        _write(base / "product-blueprint.json", blueprint)
        _write(base / "coverage-plan.json", coverage)

        vertical_valid = json.loads(json.dumps(blueprint))
        vertical_valid["scope_profile"] = "VERTICAL_SLICE"
        vertical_valid["experience_loop"] = {
            "entry_state_id": "STATE-A", "exit_state_id": "STATE-C",
            "steps": [
                {"sequence": 1, "system_id": "SYS-CORE", "input": "repair", "state_before_id": "STATE-A", "transition_rule": "repair starts", "state_after_id": "STATE-B", "visible_feedback": "repair begins", "output": "work", "screen_id": "SCREEN-1"},
                {"sequence": 2, "system_id": "SYS-CORE", "input": "confirm", "state_before_id": "STATE-B", "transition_rule": "repair completes", "state_after_id": "STATE-C", "visible_feedback": "route lights", "output": "access", "screen_id": "SCREEN-2"},
            ],
            "end_condition": "exit state STATE-C reached", "failure_or_exit": "resource depleted",
            "recovery": "collect repair parts", "next_run_difference": "new route available"
        }
        vertical_valid["content_scope"]["states"] = 3
        vertical_valid["content_scope"]["screen_templates"] = 2
        vertical_graph = json.loads(json.dumps(graph))
        vertical_graph["nodes"].extend([
            {"id": "SYS-CORE", "type": "SYSTEM", "name": "core", "authority": "FROZEN", "status": "APPROVED", "confidence": 1, "source_refs": [], "facts": ["loop system"], "judgements": [], "unknowns": [], "attributes": {}},
            {"id": "STATE-A", "type": "STATE", "name": "broken", "authority": "FROZEN", "status": "APPROVED", "confidence": 1, "source_refs": [], "facts": ["broken route"], "judgements": [], "unknowns": [], "attributes": {}},
            {"id": "STATE-B", "type": "STATE", "name": "repairing", "authority": "FROZEN", "status": "APPROVED", "confidence": 1, "source_refs": [], "facts": ["repair active"], "judgements": [], "unknowns": [], "attributes": {}},
            {"id": "STATE-C", "type": "STATE", "name": "open", "authority": "FROZEN", "status": "APPROVED", "confidence": 1, "source_refs": [], "facts": ["route open"], "judgements": [], "unknowns": [], "attributes": {}},
            {"id": "SCREEN-1", "type": "SCREEN", "name": "repair", "authority": "FROZEN", "status": "APPROVED", "confidence": 1, "source_refs": [], "facts": ["repair feedback"], "judgements": [], "unknowns": [], "attributes": {}},
            {"id": "SCREEN-2", "type": "SCREEN", "name": "route open", "authority": "FROZEN", "status": "APPROVED", "confidence": 1, "source_refs": [], "facts": ["completion feedback"], "judgements": [], "unknowns": [], "attributes": {}},
        ])
        vertical_graph["edges"].extend([
            {"id": "EDGE-STATE-A", "type": "STATE_OF", "from": "STATE-A", "to": "ASSET-LOCATION", "reason": "broken route state"},
            {"id": "EDGE-STATE-B", "type": "STATE_OF", "from": "STATE-B", "to": "ASSET-LOCATION", "reason": "repair route state"},
            {"id": "EDGE-STATE-C", "type": "STATE_OF", "from": "STATE-C", "to": "ASSET-LOCATION", "reason": "open route state"},
            {"id": "EDGE-TRANS-AB", "type": "TRANSITIONS_TO", "from": "STATE-A", "to": "STATE-B", "reason": "repair starts"},
            {"id": "EDGE-TRANS-BC", "type": "TRANSITIONS_TO", "from": "STATE-B", "to": "STATE-C", "reason": "repair completes"},
        ])
        vertical_valid_coverage = json.loads(json.dumps(coverage))
        vertical_valid_coverage["scope_profile"] = "VERTICAL_SLICE"
        vertical_valid_coverage["slots"][0]["required_graph_nodes"] = [
            "ASSET-LOCATION", "ASSET-PLAYER", "SYS-CORE", "STATE-A", "STATE-B", "STATE-C", "SCREEN-1", "SCREEN-2"
        ]
        vertical_valid_audit = json.loads(json.dumps(audit))
        vertical_valid_audit["semantic_counts"]["states"] = 3
        vertical_valid_audit["semantic_counts"]["screen_templates"] = 2
        vertical_valid_audit["evidence_inventory"][0]["graph_refs"] = [
            "ASSET-LOCATION", "ASSET-PLAYER", "EVENT-DECAY", "USE-GAMEPLAY", "SYS-CORE",
            "STATE-A", "STATE-B", "STATE-C", "SCREEN-1", "SCREEN-2"
        ]
        refresh_portfolio_fixture(vertical_valid, vertical_graph, vertical_valid_coverage, vertical_valid_audit)
        require(validate(root, request)["status"] == "passed", "valid vertical slice fixture failed")
        results["valid_vertical_slice"] = "PASS"

        disconnected_blueprint = json.loads(json.dumps(vertical_valid))
        disconnected_blueprint["experience_loop"]["steps"][1]["state_before_id"] = "STATE-D"
        disconnected_graph = json.loads(json.dumps(vertical_graph))
        disconnected_graph["nodes"].append(
            {"id": "STATE-D", "type": "STATE", "name": "unrelated", "authority": "FROZEN", "status": "APPROVED", "confidence": 1, "source_refs": [], "facts": ["unrelated state"], "judgements": [], "unknowns": [], "attributes": {}}
        )
        disconnected_graph["edges"].extend([
            {"id": "EDGE-STATE-D", "type": "STATE_OF", "from": "STATE-D", "to": "ASSET-LOCATION", "reason": "unrelated route state"},
            {"id": "EDGE-TRANS-DC", "type": "TRANSITIONS_TO", "from": "STATE-D", "to": "STATE-C", "reason": "unrelated completion"},
        ])
        disconnected_blueprint["content_scope"]["states"] = 4
        disconnected_coverage = json.loads(json.dumps(vertical_valid_coverage))
        disconnected_coverage["slots"][0]["required_graph_nodes"].append("STATE-D")
        disconnected_audit = json.loads(json.dumps(vertical_valid_audit))
        disconnected_audit["semantic_counts"]["states"] = 4
        disconnected_audit["evidence_inventory"][0]["graph_refs"].append("STATE-D")
        refresh_portfolio_fixture(disconnected_blueprint, disconnected_graph, disconnected_coverage, disconnected_audit)
        try:
            validate(root, request)
        except PortfolioError:
            results["vertical_slice_disconnected_state_chain"] = "BLOCK"
        else:
            raise PortfolioError("disconnected vertical slice state chain unexpectedly passed")

        manifest = refresh_portfolio_fixture(blueprint, graph, coverage, audit)

        camera_only_event = json.loads(json.dumps(audit))
        camera_item = camera_only_event["evidence_inventory"][0]
        camera_item["variant_axes"] = ["camera"]
        camera_item["semantic_delta"] = "camera angle changed only"
        camera_item["coverage_claims"][0]["observed_semantic_delta"] = "camera angle changed only"
        camera_item["counting_delta"] = {"target_id": "EVENT-DECAY", "semantic_axes": [], "presentation_only_axes": ["camera"]}
        camera_item["event_delta"] = {
            "event_id": "EVENT-DECAY", "cause_changed": False, "action_changed": False,
            "consequence_changed": False, "participants_changed": False,
            "location_changed": False, "presentation_only_axes": ["camera"]
        }
        _write(base / "content-audit.json", camera_only_event)
        try:
            validate(root, request)
        except PortfolioError:
            results["camera_only_new_event"] = "BLOCK"
        else:
            raise PortfolioError("camera-only presentation unexpectedly counted as NEW_EVENT")
        _write(base / "content-audit.json", audit)

        color_only_asset = json.loads(json.dumps(audit))
        color_item = color_only_asset["evidence_inventory"][0]
        color_item["counting_class"] = "NEW_ASSET"
        color_item["variant_axes"] = ["color"]
        color_item["semantic_delta"] = "color changed only"
        color_item["coverage_claims"][0]["observed_semantic_delta"] = "color changed only"
        color_item["counting_delta"] = {"target_id": "ASSET-PLAYER", "semantic_axes": [], "presentation_only_axes": ["color"]}
        color_item["event_delta"] = None
        color_coverage = json.loads(json.dumps(coverage))
        color_coverage["slots"][0]["counting_class"] = "NEW_ASSET"
        _write(base / "coverage-plan.json", color_coverage)
        _write(base / "content-audit.json", color_only_asset)
        try:
            validate(root, request)
        except PortfolioError:
            results["color_only_new_asset"] = "BLOCK"
        else:
            raise PortfolioError("color-only presentation unexpectedly counted as NEW_ASSET")
        _write(base / "coverage-plan.json", coverage)
        _write(base / "content-audit.json", audit)

        presentation_direction = json.loads(json.dumps(audit))
        presentation_direction["direction_inventory"].append({
            "direction_id": "DIRECTION-COLOR", "parent_direction_id": "DIRECTION-ROOT",
            "player_agent_changed": False, "product_type_changed": False,
            "core_loop_changed": False, "world_causality_changed": False,
            "presentation_only_axes": ["color", "lighting"], "status": "APPROVED"
        })
        presentation_direction["semantic_counts"]["product_directions"] = 2
        presentation_blueprint = json.loads(json.dumps(blueprint))
        presentation_blueprint["content_scope"]["directions"] = 2
        _write(base / "product-blueprint.json", presentation_blueprint)
        _write(base / "content-audit.json", presentation_direction)
        try:
            validate(root, request)
        except PortfolioError:
            results["presentation_only_new_direction"] = "BLOCK"
        else:
            raise PortfolioError("presentation-only variant unexpectedly counted as a new direction")

        valid_direction_audit = json.loads(json.dumps(audit))
        valid_direction_audit["direction_inventory"].append({
            "direction_id": "DIRECTION-TACTICAL", "parent_direction_id": "DIRECTION-ROOT",
            "player_agent_changed": False, "product_type_changed": False,
            "core_loop_changed": True, "world_causality_changed": False,
            "presentation_only_axes": ["camera"], "status": "APPROVED"
        })
        valid_direction_audit["semantic_counts"]["product_directions"] = 2
        valid_direction_blueprint = json.loads(json.dumps(blueprint))
        valid_direction_blueprint["content_scope"]["directions"] = 2
        refresh_portfolio_fixture(valid_direction_blueprint, graph, coverage, valid_direction_audit)
        require(validate(root, request)["status"] == "passed", "valid derived direction fixture failed")
        results["valid_derived_direction"] = "PASS"

        cyclic_direction_audit = json.loads(json.dumps(audit))
        cyclic_direction_audit["direction_inventory"].extend([
            {"direction_id": "DIRECTION-A", "parent_direction_id": "DIRECTION-B", "player_agent_changed": False,
             "product_type_changed": False, "core_loop_changed": True, "world_causality_changed": False,
             "presentation_only_axes": [], "status": "APPROVED"},
            {"direction_id": "DIRECTION-B", "parent_direction_id": "DIRECTION-A", "player_agent_changed": False,
             "product_type_changed": False, "core_loop_changed": False, "world_causality_changed": True,
             "presentation_only_axes": [], "status": "APPROVED"},
        ])
        cyclic_direction_audit["semantic_counts"]["product_directions"] = 3
        cyclic_direction_blueprint = json.loads(json.dumps(blueprint))
        cyclic_direction_blueprint["content_scope"]["directions"] = 3
        _write(base / "product-blueprint.json", cyclic_direction_blueprint)
        _write(base / "content-audit.json", cyclic_direction_audit)
        try:
            validate(root, request)
        except PortfolioError:
            results["cyclic_direction_parentage"] = "BLOCK"
        else:
            raise PortfolioError("cyclic direction parentage unexpectedly passed")
        manifest = refresh_portfolio_fixture(blueprint, graph, coverage, audit)

        unbound_evidence = json.loads(json.dumps(audit))
        unbound_evidence["evidence_inventory"][0]["graph_refs"] = ["EVENT-DECAY"]
        _write(base / "content-audit.json", unbound_evidence)
        try:
            validate(root, request)
        except PortfolioError:
            results["coverage_required_nodes_unproven"] = "BLOCK"
        else:
            raise PortfolioError("coverage with unproven required nodes unexpectedly passed")

        mismatched_counting = json.loads(json.dumps(audit))
        mismatched_counting["evidence_inventory"][0]["counting_class"] = "NEW_ASSET"
        mismatched_counting["evidence_inventory"][0]["counting_delta"] = {"target_id": "ASSET-PLAYER", "semantic_axes": ["identity"], "presentation_only_axes": []}
        mismatched_counting["evidence_inventory"][0]["event_delta"] = None
        _write(base / "content-audit.json", mismatched_counting)
        try:
            validate(root, request)
        except PortfolioError:
            results["coverage_counting_mismatch"] = "BLOCK"
        else:
            raise PortfolioError("coverage/evidence counting mismatch unexpectedly passed")

        stale_delta = json.loads(json.dumps(audit))
        stale_delta["evidence_inventory"][0]["coverage_claims"][0]["minimum_semantic_delta"] = "stale requirement"
        _write(base / "content-audit.json", stale_delta)
        try:
            validate(root, request)
        except PortfolioError:
            results["coverage_semantic_delta_stale"] = "BLOCK"
        else:
            raise PortfolioError("stale coverage semantic delta unexpectedly passed")
        _write(base / "content-audit.json", audit)

        assumed = json.loads(json.dumps(blueprint))
        next(item for item in assumed["assumptions"] if item["id"] == "PLAYER_AGENT")["status"] = "ASSUMED"
        _write(base / "product-blueprint.json", assumed)
        try:
            validate(root, request)
        except PortfolioError:
            results["critical_assumption"] = "BLOCK"
        else:
            raise PortfolioError("critical assumption selftest unexpectedly passed")
        _write(base / "product-blueprint.json", blueprint)

        broken = json.loads(json.dumps(coverage))
        broken["slots"][0]["required_graph_nodes"] = ["MISSING"]
        _write(base / "coverage-plan.json", broken)
        try:
            validate(root, request)
        except PortfolioError:
            results["missing_graph_node"] = "BLOCK"
        else:
            raise PortfolioError("missing graph node selftest unexpectedly passed")
        _write(base / "coverage-plan.json", coverage)

        rejected_graph = json.loads(json.dumps(graph))
        next(item for item in rejected_graph["nodes"] if item["id"] == "ASSET-LOCATION")["status"] = "REJECTED"
        rejected_blueprint = json.loads(json.dumps(blueprint))
        rejected_blueprint["content_scope"]["location_families"] = 0
        rejected_audit = json.loads(json.dumps(audit))
        rejected_audit["semantic_counts"]["asset_families"] = 1
        _write(base / "product-blueprint.json", rejected_blueprint)
        _write(base / "content-graph.json", rejected_graph)
        _write(base / "content-audit.json", rejected_audit)
        try:
            validate(root, request)
        except PortfolioError:
            results["coverage_rejected_node"] = "BLOCK"
        else:
            raise PortfolioError("coverage rejected node selftest unexpectedly passed")
        _write(base / "product-blueprint.json", blueprint)
        _write(base / "content-graph.json", graph)
        _write(base / "content-audit.json", audit)

        second = request / "work" / "evidence-copy.png"
        second.write_bytes(evidence_path.read_bytes())
        duplicate = json.loads(json.dumps(audit))
        duplicate["inventory_count"] = 2
        duplicate_item = json.loads(json.dumps(duplicate["evidence_inventory"][0]))
        duplicate_item.update({"evidence_id": "EVID-COPY", "path": relative(root, second), "byte_size": second.stat().st_size, "sha256": sha256(second)})
        duplicate["evidence_inventory"].append(duplicate_item)
        duplicate["exact_duplicate_groups"] = []
        duplicate_coverage = json.loads(json.dumps(coverage))
        duplicate_coverage["slots"][0]["evidence_refs"].append("EVID-COPY")
        _write(base / "coverage-plan.json", duplicate_coverage)
        _write(base / "content-audit.json", duplicate)
        try:
            validate(root, request)
        except PortfolioError:
            results["unreported_exact_duplicate"] = "BLOCK"
        else:
            raise PortfolioError("unreported exact duplicate selftest unexpectedly passed")

        duplicate_presentation = json.loads(json.dumps(duplicate))
        duplicate_presentation["exact_duplicate_groups"] = [["EVID-CORE", "EVID-COPY"]]
        duplicate_copy = duplicate_presentation["evidence_inventory"][1]
        duplicate_copy["counting_class"] = "PRESENTATION_ONLY"
        duplicate_copy["variant_axes"] = ["duplicate"]
        duplicate_copy["counting_delta"] = {
            "target_id": "EVENT-DECAY", "semantic_axes": [], "presentation_only_axes": ["duplicate"]
        }
        duplicate_copy["event_delta"] = None
        refresh_portfolio_fixture(blueprint, graph, duplicate_coverage, duplicate_presentation)
        require(validate(root, request)["status"] == "passed",
                "one semantic claim plus presentation-only exact duplicate should pass")
        results["valid_duplicate_zero_delta"] = "PASS"
        manifest = refresh_portfolio_fixture(blueprint, graph, coverage, audit)

        duplicate_new_use = json.loads(json.dumps(duplicate))
        duplicate_new_use["exact_duplicate_groups"] = [["EVID-CORE", "EVID-COPY"]]
        for item in duplicate_new_use["evidence_inventory"]:
            item["counting_class"] = "NEW_USE"
            item["counting_delta"] = {"target_id": "USE-GAMEPLAY", "semantic_axes": ["delivery_purpose"], "presentation_only_axes": []}
            item["event_delta"] = None
        duplicate_use_coverage = json.loads(json.dumps(duplicate_coverage))
        duplicate_use_coverage["slots"][0]["counting_class"] = "NEW_USE"
        _write(base / "coverage-plan.json", duplicate_use_coverage)
        _write(base / "content-audit.json", duplicate_new_use)
        try:
            validate(root, request)
        except PortfolioError:
            results["duplicate_double_count"] = "BLOCK"
        else:
            raise PortfolioError("registered duplicate double-count selftest unexpectedly passed")

        duplicate_parent = json.loads(json.dumps(duplicate))
        duplicate_parent["exact_duplicate_groups"] = [["EVID-CORE", "EVID-COPY"]]
        duplicate_parent["evidence_inventory"][0]["counting_class"] = "PRESENTATION_ONLY"
        duplicate_parent["evidence_inventory"][0]["variant_axes"] = ["duplicate"]
        duplicate_parent["evidence_inventory"][0]["counting_delta"] = {"target_id": "ASSET-PLAYER", "semantic_axes": [], "presentation_only_axes": ["duplicate"]}
        duplicate_parent["evidence_inventory"][0]["event_delta"] = None
        duplicate_parent["evidence_inventory"][0]["parent_asset_or_screen_id"] = "ASSET-PLAYER"
        duplicate_parent["evidence_inventory"][1]["counting_class"] = "PRESENTATION_ONLY"
        duplicate_parent["evidence_inventory"][1]["variant_axes"] = ["duplicate"]
        duplicate_parent["evidence_inventory"][1]["counting_delta"] = {"target_id": "ASSET-LOCATION", "semantic_axes": [], "presentation_only_axes": ["duplicate"]}
        duplicate_parent["evidence_inventory"][1]["event_delta"] = None
        duplicate_parent["evidence_inventory"][1]["parent_asset_or_screen_id"] = "ASSET-LOCATION"
        duplicate_parent_coverage = json.loads(json.dumps(duplicate_coverage))
        duplicate_parent_coverage["slots"][0]["counting_class"] = "PRESENTATION_ONLY"
        _write(base / "coverage-plan.json", duplicate_parent_coverage)
        _write(base / "content-audit.json", duplicate_parent)
        try:
            validate(root, request)
        except PortfolioError:
            results["duplicate_parent_identity_conflict"] = "BLOCK"
        else:
            raise PortfolioError("duplicate parent identity conflict selftest unexpectedly passed")
        _write(base / "coverage-plan.json", coverage)
        _write(base / "content-audit.json", audit)

        orphan_path = request / "work" / "orphan.png"
        Image.new("RGB", (8, 6), (20, 40, 60)).save(orphan_path)
        orphan_audit = json.loads(json.dumps(audit))
        orphan_item = json.loads(json.dumps(orphan_audit["evidence_inventory"][0]))
        orphan_item.update({
            "evidence_id": "EVID-ORPHAN", "path": relative(root, orphan_path),
            "preview_path": relative(root, orphan_path), "byte_size": orphan_path.stat().st_size,
            "sha256": sha256(orphan_path)
        })
        orphan_audit["evidence_inventory"].append(orphan_item)
        orphan_audit["inventory_count"] = 2
        orphan_audit["content_hash_unique_count"] = 2
        _write(base / "content-audit.json", orphan_audit)
        try:
            validate(root, request)
        except PortfolioError:
            results["orphan_evidence"] = "BLOCK"
        else:
            raise PortfolioError("orphan evidence selftest unexpectedly passed")

        near_audit = json.loads(json.dumps(orphan_audit))
        near_audit["evidence_inventory"][1]["coverage_refs"] = ["COV-CORE"]
        near_audit["evidence_inventory"][1]["coverage_claims"] = json.loads(json.dumps(audit["evidence_inventory"][0]["coverage_claims"]))
        for item in near_audit["evidence_inventory"]:
            item["parent_asset_or_screen_id"] = "ASSET-LOCATION"
        near_coverage = json.loads(json.dumps(coverage))
        near_coverage["slots"][0]["evidence_refs"].append("EVID-ORPHAN")
        near_audit["near_duplicate_groups"] = [{"parent_id": "ASSET-LOCATION", "members": ["EVID-CORE", "EVID-ORPHAN"], "invariant": "same route", "changed_axes": ["weather"], "semantic_delta": "weather only", "counting_rule": "one event"}]
        _write(base / "coverage-plan.json", near_coverage)
        _write(base / "content-audit.json", near_audit)
        try:
            validate(root, request)
        except PortfolioError:
            results["near_duplicate_unbound_axis"] = "BLOCK"
        else:
            raise PortfolioError("near duplicate unbound axis selftest unexpectedly passed")
        _write(base / "coverage-plan.json", coverage)
        _write(base / "content-audit.json", audit)

        graph_same_name = json.loads(json.dumps(graph))
        graph_same_name["nodes"].append({
            "id": "ASSET-LOCATION-2", "type": "ASSET_LOCATION", "name": "road", "authority": "FROZEN",
            "status": "APPROVED", "confidence": 1, "source_refs": [], "facts": ["second road"],
            "judgements": [], "unknowns": [], "attributes": {}
        })
        blueprint_two_locations = json.loads(json.dumps(blueprint))
        blueprint_two_locations["content_scope"]["location_families"] = 2
        audit_three_assets = json.loads(json.dumps(audit))
        audit_three_assets["semantic_counts"]["asset_families"] = 3
        _write(base / "product-blueprint.json", blueprint_two_locations)
        _write(base / "content-graph.json", graph_same_name)
        _write(base / "content-audit.json", audit_three_assets)
        try:
            validate(root, request)
        except PortfolioError:
            results["unreported_same_name_assets"] = "BLOCK"
        else:
            raise PortfolioError("unreported same-name asset selftest unexpectedly passed")
        _write(base / "product-blueprint.json", blueprint)
        _write(base / "content-graph.json", graph)
        _write(base / "content-audit.json", audit)

        open_conflict = json.loads(json.dumps(audit))
        open_conflict["identity_conflicts"] = [{
            "id": "CONFLICT-OPEN", "nodes": ["ASSET-LOCATION", "ASSET-PLAYER"],
            "reason": "fixture conflict", "resolution": "", "status": "OPEN"
        }]
        _write(base / "content-audit.json", open_conflict)
        try:
            validate(root, request)
        except PortfolioError:
            results["open_conflict"] = "BLOCK"
        else:
            raise PortfolioError("open conflict selftest unexpectedly passed")

        blocking_unknown = json.loads(json.dumps(audit))
        blocking_unknown["unresolved_unknowns"] = [{"id": "UNKNOWN-1", "statement": "scope uncertain", "blocking": True}]
        _write(base / "content-audit.json", blocking_unknown)
        try:
            validate(root, request)
        except PortfolioError:
            results["blocking_unknown"] = "BLOCK"
        else:
            raise PortfolioError("blocking unknown selftest unexpectedly passed")

        status_block = json.loads(json.dumps(audit))
        status_block["status"] = "BLOCK"
        _write(base / "content-audit.json", status_block)
        try:
            validate(root, request)
        except PortfolioError:
            results["audit_status_block"] = "BLOCK"
        else:
            raise PortfolioError("BLOCK audit selftest unexpectedly passed")

        bad_image_metadata = json.loads(json.dumps(audit))
        bad_image_metadata["evidence_inventory"][0]["width"] = 9
        _write(base / "content-audit.json", bad_image_metadata)
        try:
            validate(root, request)
        except PortfolioError:
            results["invalid_image_metadata"] = "BLOCK"
        else:
            raise PortfolioError("invalid image metadata selftest unexpectedly passed")

        incomplete_coverage = json.loads(json.dumps(coverage))
        incomplete_coverage["slots"][0]["status"] = "PLANNED"
        incomplete_coverage["slots"][0]["evidence_refs"] = []
        incomplete_coverage["summary"] = {"planned": 1, "approved": 0, "waived": 0, "failed": 0, "coverage_status": "FAIL"}
        incomplete_audit = json.loads(json.dumps(audit))
        incomplete_audit["coverage_result"] = incomplete_coverage["summary"]
        incomplete_audit["status"] = "BLOCK"
        _write(base / "coverage-plan.json", incomplete_coverage)
        _write(base / "content-audit.json", incomplete_audit)
        try:
            validate(root, request)
        except PortfolioError:
            results["incomplete_coverage"] = "BLOCK"
        else:
            raise PortfolioError("incomplete coverage selftest unexpectedly passed")
        _write(base / "coverage-plan.json", coverage)
        _write(base / "content-audit.json", audit)

        _write(request / "work" / "visual-spec.json", {"authority_trace": []})
        try:
            validate(root, request)
        except PortfolioError:
            results["missing_visual_concept_authority"] = "BLOCK"
        else:
            raise PortfolioError("missing Visual Spec concept authority selftest unexpectedly passed")
        (request / "work" / "visual-spec.json").unlink()

        prototype = root / "requests" / "game-concept-lab" / "prototype-selftest"
        prototype_final = prototype / "work" / "final"
        prototype_final.mkdir(parents=True)
        _write(prototype / "state.json", {"primary_skill": "sicza-game-concept-lab", "status": "active", "revision": 1})
        prototype_blueprint = _minimal_blueprint("PROTOTYPE")
        prototype_blueprint_path = prototype / "work" / "concept-lab" / "product-blueprint.json"
        _write(prototype_blueprint_path, prototype_blueprint)
        prototype_proposal = prototype_final / "game-concept-proposal.md"
        prototype_spec = {
            "schema_version": "sicza.game-concept.prototype-spec.v1", "product_id": "selftest-game", "status": "PROVISIONAL",
            "direction": {"product_type": "strategy", "player_fantasy": "restore a changing route", "core_verb": "place", "world_rule": "roads decay", "core_reward": "visible access", "world_dependency": "decay changes legal routes"},
            "gameplay_core": {"player_action": "place a repair", "target": "broken route", "system_response": "route reopens", "visible_state_delta": "red break becomes connected road", "reward": "new access", "progression": "larger route graph"},
            "visual_core": {"art_direction": "readable diorama", "proportion": "compact figures", "camera": "isometric", "environment_scale": "district", "prop_scale": "oversized repair nodes", "npc_density": "low", "material_and_lighting": "stone and warm repair light"},
            "test_assets": [{
                "id": "TEST-ASSET-CORE", "asset_type": "Gameplay Hero Screen", "purpose": "prove repair state delta",
                "image_contract": {"aspect_ratio": "16:9", "primary_read": "broken route becomes connected", "subject_count": 1, "position_and_scale": "player lower-left, route fills frame", "interaction_point": "central break", "gameplay_change_area": "middle route", "foreground": "player and tool", "midground": "broken route", "background": "new district", "reading_direction": "left to right", "camera": "isometric", "perspective": "orthographic-like", "framing": "full district", "pose_or_action": "placing repair", "must_show": ["before-after route state"], "must_preserve": ["roads decay"], "must_not_add": ["weapons"]},
                "canonical_prompt": "Create an isometric gameplay hero screen where one builder repairs the central broken route and the newly accessible district lights up.", "status": "READY"
            }],
            "unknowns": []
        }
        prototype_spec_path = prototype / "work" / "concept-lab" / "prototype-spec.json"
        _write(prototype_spec_path, prototype_spec)
        _write(prototype_proposal, "# selftest-game\n\nThe prototype specifies a route-repair strategy direction, the player's visible action and reward, an isometric visual treatment, one executable Gameplay Hero Screen contract, and a canonical generation prompt. The direction remains provisional while the machine artifact makes every required production field explicit and testable.\n")
        _write(prototype / "work" / "final-review.md", "scope_profile: PROTOTYPE\nPROTOTYPE_SPECIFIED\n")
        _write(prototype / "work" / "delivery-manifest.json", {"files": [
            {"role": "concept_proposal", "source": relative(root, prototype_proposal), "sha256": sha256(prototype_proposal), "active": True},
            {"role": "product_blueprint", "source": relative(root, prototype_blueprint_path), "sha256": sha256(prototype_blueprint_path), "active": True},
            {"role": "prototype_spec", "source": relative(root, prototype_spec_path), "sha256": sha256(prototype_spec_path), "active": True},
        ]})
        require(validate(root, prototype)["status"] == "passed", "valid prototype fixture failed")
        results["valid_prototype"] = "PASS"
        prototype_spec_path.unlink()
        try:
            validate(root, prototype)
        except PortfolioError:
            results["missing_prototype_spec"] = "BLOCK"
        else:
            raise PortfolioError("missing prototype spec selftest unexpectedly passed")
        prompt_gate_results = prompt_portfolio_selftest()
        semantic_gate_results = {
            f"prompt_semantic_review_{key}": value
            for key, value in prompt_semantic_review_selftest().items()
        }
        case_gate_results = {**prompt_gate_results, **semantic_gate_results}
        results.update(validate_case_semantic_regressions(case_gate_results))
        results.update(prompt_gate_results)
        results.update(semantic_gate_results)
        results.update(_prompt_portfolio_integration_selftest(root))
        semantic_fixture = load_json(
            SKILL_ROOT / "config" / "case-semantic-regression.json", "case semantic regression fixture"
        )
        fake_sources = json.loads(json.dumps(semantic_fixture))
        for case in fake_sources["cases"]:
            case["source_ids"] = ["FAKE-NOT-A-CASE"]
            case["source_sha256s"] = {"FAKE-NOT-A-CASE": "0" * 64}
        try:
            validate_case_semantic_fixture(fake_sources, case_gate_results)
        except PortfolioError:
            results["case_source_binding_tamper"] = "BLOCK"
        else:
            raise PortfolioError("fake case source bindings unexpectedly passed")
        fake_behavior = json.loads(json.dumps(semantic_fixture))
        fake_behavior["cases"][0]["fixture"]["duplicate_coverage_delta"] = 1
        try:
            validate_case_semantic_fixture(fake_behavior, case_gate_results)
        except PortfolioError:
            results["case_behavior_tamper"] = "BLOCK"
        else:
            raise PortfolioError("invalid case behavior fixture unexpectedly passed")
    return results


def request_path(root: Path, value: str) -> Path:
    request = bounded(root, value, exist=True)
    parts = request.relative_to(root).parts
    require(len(parts) == 3 and parts[0] == "requests", "request must be requests/<type>/<name>")
    require(request.is_dir(), "request directory missing")
    return request


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--request")
    parser.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])
    parser.add_argument("--doctor", action="store_true")
    args = parser.parse_args()
    try:
        if args.doctor:
            print(json.dumps({"status": "ready", "tool": "game-concept-portfolio-gate", "selftests": selftest()}, ensure_ascii=False, indent=2))
            return 0
        require(bool(args.request), "--request is required unless --doctor is used")
        root = args.workspace_root.resolve()
        print(json.dumps(validate(root, request_path(root, str(args.request))), ensure_ascii=False, indent=2))
        return 0
    except (PortfolioError, PromptPortfolioError, OSError, json.JSONDecodeError, ValueError) as exc:
        print(json.dumps({"status": "blocked", "reason": str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    sys.exit(main())
