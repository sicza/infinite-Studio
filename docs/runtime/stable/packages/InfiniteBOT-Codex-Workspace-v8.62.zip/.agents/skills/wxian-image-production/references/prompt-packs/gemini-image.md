# Gemini Image / Nano Banana Prompt Pack

用于当前 Workspace `gemini` API Profile，以及 Prompt-only 的 Gemini / Nano Banana 自然语言生成与编辑。具体模型版本由 Runtime/用户当前目标决定；本文件不硬编码外部能力上限。

## 1. 编译原则

同一 Visual Spec 比 GPT Image 版本更短、更直接。优先：

`Task → Primary Subject/Read → Exact Identity → Action/State → Spatial Relation → Camera/Composition → Light/Material → Style/Identity → Preserve/Change`。

避免长层级嵌套解释；把关系写成明确句子。

## 2. Generate

```text
Create [whole image].
The first read is [decisive subject relationship/result].
[Exact identity anchors]. [Action, contact, gaze, expression].
[Environment + scale + spatial relationship].
[Camera, perspective, composition, foreground/background].
[Lighting, material, surface, atmosphere].
[Value/color/detail hierarchy and focus].
[Text/logo/UI role if any].
Keep the project identity through [memory anchor / visual grammar].
```

## 3. Multi-reference

逐图声明职责，不写“综合参考”：

```text
Image 1: identity only — [...].
Image 2: pose/contact/camera only — [...].
Image 3: environment or rendering only — [...].
Do not transfer from image 2/3: [...].
```

如果两张图对同一高影响变量冲突，必须在上游 Reference Plan 先裁定，不把冲突交给模型自行平均。

## 4. Edit

```text
Change only: [...].
Current defect: [observable problem].
Required visible delta: [...].
Preserve: [specific correct state].
Necessary integration changes: [...].
Do not change/add: [task-specific risks].
```

当用户说“除了 X 什么都别改”，仍允许 X 必然导致的局部衣褶、接触阴影、反射、边缘融合等 Derived Change；范围必须最小。

## 5. Restoration / High-resolution Redraw

先分类：

- `PURE UPSCALE`：只增加采样/尺寸，不发明结构；
- `RESTORATION`：修压缩、边缘、局部纹理；
- `RECONSTRUCTION`：源图确实缺失高频信息，需要基于已锁设计重建。

高精度重绘必须显式写：

`PRESERVE design/geometry → RECONSTRUCT edges/structure/material microdetail → suppress AI over-smoothed texture / random micro-noise → keep focal hierarchy`。

不能同时要求“绝对不改变任何像素关系”和“补出原图不存在的真实结构细节”。

## 6. Sequential Consistency

角色/物体多张连续生产优先：

`Approved Identity Reference + Current Approved Anchor + New Pose/Camera/State`。

不要每张从文字重新发明身份。
