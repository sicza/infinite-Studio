# Visual Intelligence Integration — Image Production

本文件只定义 `wxian-image-production` 如何消费共享 Narrative / Visual 内核。Primary Skill、request、`production_branch`、API Runtime 和最终 Promote Authority 不改变。

## 1. Authority 与顺序

Narrative Solver **不得消费 Project Visual Baseline 作为故事事实**。合法顺序：

```text
current request / requirement-lock / source-lock / Project Brief / request input
→ narrative_route = NONE | HANDOFF_ONLY | SOLVE | REPAIR
→ [需要时] work/narrative-visual-contract.json
→ 正式 Project Visual Baseline + Reference Contract
→ sicza-visual-director
→ canonical work/visual-spec.json
→ Prompt Compilation
→ work/prompt-binding.json
→ 当前 Image Production 执行与 Gate
```

Visual Baseline 是视觉先验，只在 Narrative Contract 之后进入 Visual 层。

## 2. Narrative Route

### `NONE`

纯构图、镜头、光影、材质、成像、排版、风格、细节、视觉层级，没有任何会改变画面的叙事歧义。

### `HANDOFF_ONLY`

剧情/事件/角色状态已锁定，但画面需要明确：

- 决定性时刻；
- 观众此刻知道什么；
- 必须显示/不得暗示什么；
- 哪些可见证据证明因果或关系。

只使用 R09 编译 Narrative–Visual Contract，不重写故事。

### `SOLVE`

以下任一未闭合且会改变画面：

- 当前事件为什么发生、结果是什么；
- 谁主动、谁反应、角色是否知道某事实；
- 动作/物体/伤势/路径/环境状态怎样连续变化；
- 多图、首尾帧或视频之间缺少合法状态桥接；
- “决定性一刻”尚未确定；
- Prompt 正在凭空补角色、道具、敌人、因果或世界事实。

### `REPAIR`

已有叙事输入存在状态跳变、知识泄漏、空间/物体矛盾或不可视觉化冲突。先由 R10 找第一断点，再最小修复。

## 3. Narrative Contract

唯一机器合同：

- `.agents/skills/workspace-governance/config/visual-contracts/narrative-visual-contract-schema.json`
- `<request>/work/narrative-visual-contract.json`

验证：

```text
python .agents/scripts/visual_contract_gate.py validate-narrative \
  --file <request>/work/narrative-visual-contract.json \
  --workspace-root .
```

非 `READY` 不得继续 Visual Spec。

## 4. Visual Director 模式

| production_branch / 情况 | 模式 |
|---|---|
| `new-generation` / `visual-brief-only` / `prompt-only` | `CREATE` |
| `image-edit` 且主动改变视觉系统 | `TRANSFORM` |
| `image-edit` 只修已批准方向 | `ITERATE` |
| `prompt-review-only` | `DIAGNOSE` |
| 多候选视觉选择 | `SELECT`；数值评分仍归 `$wxian-visual-scorecard` |
| 已批准系列继续生产 | `SERIES` |

确定性 resize/localization/composite/postprocess 不默认激活 Visual Director；只有改变信息层级、构图、图文关系或视觉语法时才激活。

## 5. Canonical Visual Spec

全 Workspace 只允许：

- Schema：`.agents/skills/workspace-governance/config/visual-contracts/visual-spec-schema.json`
- Path：`<request>/work/visual-spec.json`

本文件不再维护第二套字段。

Visual Spec 必须绑定真实 `authority_trace`；有 Narrative Contract 时必须完整绑定 `narrative_trace.path / sha256 / contract_id / revision / semantic_checksum`。

验证：

```text
python .agents/scripts/visual_contract_gate.py validate-spec \
  --file <request>/work/visual-spec.json \
  --workspace-root .
```

## 6. Prompt Binding

Prompt Pack 只能把已通过的 Visual Spec 压缩、排序、翻译或编码成目标模型语言，不能新增上游没有的角色、道具、事件、世界规则、玩法或视觉主张。

每个进入执行链的 Prompt 必须先绑定。`--compiler-profile` 只能取 `.agents/skills/workspace-governance/config/visual-contracts/prompt-compiler-profiles.json` 的注册 ID，不能临时发明 adapter 名：

```text
python .agents/scripts/visual_contract_gate.py bind-prompt \
  --visual-spec <request>/work/visual-spec.json \
  --prompt <request>/work/<prompt-file> \
  --compiler-profile <registered-profile> \
  --output <request>/work/prompt-binding.json \
  --workspace-root .
```

这一 binding 只证明 Prompt ← Visual Spec 的语义 lineage；Provider/API 的实际调用证据继续由现有 API Runtime 负责，本轮不改变其实现。

## 7. 专业加载

默认 `1 个主模块 + 0–2 个依赖模块`：

- 巨物像玩具 / 世界像布景 → `W-SCALE / R-CAM / R-DEPTH`；
- 人像假人 / 道具粘手 → `P-BODY / P-CONTACT / P-PROP`；
- 构图强但空间读不清 → `R-COMP / R-OCC / H-READ`；
- 塑料感 / 贴脏 / 假雾 → `A-MAT / A-SURFACE / A-ATM`；
- “有细节但糊、脏、AI味” → `I-* / F-* / H-CLUTTER`；
- 漂亮但像任何同类 → `D-GRAMMAR / D-SIGN / D-MEM / D-CATEGORY`；
- 标题后贴 / 多语言崩 → `G-INFO / G-TYPE / G-LAYOUT / G-REL / G-MULTI`。

## 8. 失败路由

```text
事实错 / 需求错 → current Codex Authority
叙事状态/因果错 → Narrative route
关系/结构/视觉机制错 → Visual Director
Visual Spec 对但 Prompt 丢关系 → Prompt Compilation
Prompt 对但模型失败 → 当前模型能力 / Reference / generation strategy
图正确但文字、Logo、UI 不可精确 → deterministic postprocess
```

同一根因连续两轮只靠追加形容词或 negative terms 无改善，停止补 Prompt，回最早责任层。
