# 比例适配 Prompt 与语言替换契约

## AI 外扩 / 重新构图 Prompt

先判断任务是哪一种，不得用一个“全部禁止移动”的 Prompt 覆盖所有比例变化。

### A. `expand_preserve`：原构图本身成立，只补新增画布

适合轻度变比或用户明确要求主体位置/比例完全不动：保持现有主体、动作、文字、LOGO、UI、镜头和焦点不变，只在新增区域延展环境、透视、景深、光线和氛围；禁止把旧图缩成画中画、模糊边、镜像边或新主体。

### B. `recompose_safe`：明显横竖版转换，需要像原生目标比例

适合 16:9↔9:16、1:1↔9:16 等显著变比。允许为了目标画布对**可变布局**做最小必要重排：主体作为整体平移或等比缩放、标题/LOGO/UI 在各自安全区重新落位、前中远景重新展开；但角色身份、脸、服装、动作、武器/道具设计、主体相对关系、镜头意图、光照方向、色彩和项目风格必须保持。不得非等比拉伸、裁掉 P0、改变人物动作或重新设计场景故事。

Prompt 必须明确目标比例/像素，并说明哪些元素 `protected`、哪些元素 `reflowable`。最终结果应像原生目标比例设计，而不是“旧图居中 + 补边”。

两种模式的目标比例都必须同时写入 API 参数；API 结果必须重新测量布局，再用确定性 resize 输出精确像素。

## 语言替换

复杂语言替换才建立 `work/localization/<locale>/text-replacement-plan.json`，只记录会影响执行的源图、目标语言/地区、原文/译文、文字 bbox、阅读方向、排版策略和实际应用的 Baseline Floor / placement 基准。简单明确替换可直接在专业事实源中锁定，不为格式制造额外文件。

正式语言母版统一走 Gemini/GPT `image_to_image_edit`；本地字体排版只用于 preview/work draft。Prompt 只替换指定文字并保留字体意图、版式、描边、阴影、材质、光效、遮挡关系与背景纹理；自然处理文字区域，其余画面保持。完整 `new-generation` 的每个有文字语言母版都以 `pure_visual_image` 为 base；独立 `localization` 以该分支锁定的真实源图为 base。

语言替换沿用 confirmed Layout Blueprint 的文字区域与资产槽位，不重新测量整图：首版标题/副标题 bbox 就是其他语言的目标排版区，译文只在该区域内通过换行、字距和合理字号变化适配；LOGO、UI、prop slot 与保护区保持同一坐标语义。确定性同构图 Resize 由脚本按 crop/scale 数学派生坐标。只有 AI expand/recompose 真正改变构图时才重新分析一次。标题通用 fallback 区仍为 `x=8%..92%`、`y=75%..100%`；项目 Baseline 或当前用户要求优先。1080×1080 的 LOGO 通用 fallback 内容宽度不小于 250px、边距约 40px。

门禁：目标文字拼写和方向正确；原主体/Logo/UI 未漂移；无临时 Pillow 文字覆盖；目标比例满足等比规则；重新打开并检查每个最终文件后才可列入 `work/delivery-manifest.json`，并且只能由治理准出进入 `output/`。
