#!/usr/bin/env python3
"""Validate image-production delivery facts and derivation lineage."""
from __future__ import annotations
import argparse, hashlib, json, math, sys
from pathlib import Path
try:
    from PIL import Image, ImageChops, ImageOps
except ImportError:
    Image=ImageChops=ImageOps=None

LIB=Path(__file__).resolve().parents[3]/'lib'
if str(LIB) not in sys.path: sys.path.insert(0,str(LIB))
from project_materials import indexed_project_source
from production_contract import ARTIFACT_ONLY_BRANCHES, production_branch, validate_source_lock
import placement_baseline
import image_postprocess
from gpt_image_contract import formal_quality_is_valid, validate_gpt_call_intent_binding, validate_gpt_model, validate_gpt_size
from presentation_contract import PresentationError, require_complete_visual_picture

class DeliveryError(ValueError): pass

def require(c,m):
    if not c: raise DeliveryError(m)
def sha(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def bounded(root:Path,v:str|Path,exist=False)->Path:
    p=Path(v); p=(root/p if not p.is_absolute() else p).resolve(); require(p==root or root in p.parents,'path escapes Workspace')
    if exist: require(p.exists(),f'path missing: {v}')
    return p
def req(root:Path,v:str)->Path:
    p=bounded(root,v,True); parts=p.relative_to(root).parts; require(len(parts)==3 and parts[0]=='requests','request must be requests/<type>/<name>'); return p

def authorized_source(root:Path,r:Path,p:Path)->bool:
    p=p.resolve()
    return (r/'input' in p.parents) or indexed_project_source(root,p)

def require_authorized_source(root:Path,r:Path,p:Path,label:str)->None:
    require(authorized_source(root,r,p),f'{label} must be current request evidence or indexed project material')

def image_size(p:Path)->tuple[int,int]:
    require(Image is not None,'Pillow is required for image delivery validation')
    with Image.open(p) as im: return im.size

def validate_gpt_intent(root:Path,p:Path,call:dict)->None:
    relative=p.resolve().relative_to(root.resolve())
    require(len(relative.parts)>=4 and relative.parts[0]=='requests','GPT output is outside a request')
    request_dir=root.joinpath(*relative.parts[:3]); source=request_dir/'request.md'
    require(source.is_file(),'GPT delivery requires request.md intent source')
    try:
        validate_gpt_call_intent_binding(call,source.read_text(encoding='utf-8'),source.relative_to(root).as_posix(),sha(source),
                                         aspect_ratio=None if call.get('mode')=='image_to_image_edit' else '1:1')
    except ValueError as exc:
        raise DeliveryError(str(exc)) from exc

def pixel_equal(a:Path,b_image)->bool:
    with Image.open(a) as im:
        x=ImageOps.exif_transpose(im).convert('RGBA')
        y=b_image.convert('RGBA')
        if x.size!=y.size: return False
        extrema=ImageChops.difference(x,y).getextrema()
        return all(mx==0 for _,mx in extrema)

PRESENTING_VARIANTS={'icon_artwork','logo_artwork','store_artwork'}

def presenting_variant(r:Path)->str:
    lock=r/'work/requirement-lock.md'
    if not lock.is_file(): return ''
    import re
    m=re.search(r'(?im)^\s*visual_variant:\s*([^\n#]+)',lock.read_text(encoding='utf-8'))
    return m.group(1).strip() if m else ''

def require_presenting_picture(p:Path,label:str)->None:
    """A delivered icon/logo/store artwork must be a complete picture: rounding and
    masking belong to the store/OS, not to the artwork."""
    try:
        require_complete_visual_picture(p,label=label)
    except PresentationError as exc:
        raise DeliveryError(str(exc)) from exc

def prop_required(r:Path)->bool:
    lock=r/'work/requirement-lock.md'
    if not lock.is_file(): return False
    text=lock.read_text(encoding='utf-8')
    import re
    variant=re.search(r'(?im)^\s*visual_variant:\s*([^\n#]+)',text)
    props=re.search(r'(?im)^\s*has_real_props:\s*(true|false)\s*$',text)
    return bool(variant and variant.group(1).strip()=='event_visual_with_asset_frames' and props and props.group(1).lower()=='true')

def logo_required(r:Path)->bool:
    lock=r/'work/requirement-lock.md'
    if not lock.is_file(): return True
    text=lock.read_text(encoding='utf-8')
    import re
    m=re.search(r'(?im)^\s*final_logo:\s*user_explicit_none\s*\|\s*evidence:\s*`([^`]+)`\s*$',text)
    if not m: return True
    quote=m.group(1).strip(); require(quote,'no-LOGO exception requires user evidence')
    request_text=(r/'request.md').read_text(encoding='utf-8') if (r/'request.md').is_file() else ''
    require(quote in request_text,'no-LOGO evidence is not present in request.md')
    return False

def operation_record(root:Path,p:Path)->dict:
    rec=p.with_name(p.name+'.operation.json'); require(rec.is_file(),f'operation record required: {rec.relative_to(root).as_posix()}')
    data=json.loads(rec.read_text(encoding='utf-8')); require(isinstance(data,dict) and data.get('status')=='success','operation record is invalid')
    require(data.get('output')==p.relative_to(root).as_posix() and data.get('output_sha256')==sha(p),f'operation output evidence mismatch: {p.relative_to(root).as_posix()}')
    return data

def require_master_quality(root:Path,p:Path,actual:str,long_edge:int,role:str)->None:
    cp=p.with_name(p.name+'.call.json'); require(cp.is_file(),f'{role} requires generation call evidence')
    call=json.loads(cp.read_text(encoding='utf-8')); require(call.get('status')=='success' and call.get('network_called') is True,f'{role} requires successful network call evidence')
    profile=str(call.get('api_profile','')).strip(); require(profile in {'gemini','gpt'},f'{role} requires Gemini/GPT generation provenance')
    params=call.get('parameters'); require(isinstance(params,dict),'GPT call parameters missing')
    if profile=='gemini':
        require(str(params.get('quality','')).lower()=='4k',f'{role} Gemini source requires quality=4k')
        require(long_edge>=3800,f'{role} Gemini source must be 4K-class, got {actual}')
    else:
        model=str(call.get('model','')).strip(); size=str(params.get('size','')).strip(); quality=str(params.get('quality','')).lower()
        try:
            validate_gpt_model(model); validate_gpt_size(model,size)
        except ValueError as exc:
            raise DeliveryError(str(exc)) from exc
        require(formal_quality_is_valid(model,quality),'GPT formal source quality is unsupported for the selected model')
        validate_gpt_intent(root,p,call)
        if size!='auto':
            ew,eh=(int(v) for v in size.split('x')); require(actual==f'{ew}x{eh}',f'GPT source dimensions must match size={size}')
    require(call.get('output_path')==p.relative_to(root).as_posix() and call.get('output_sha256')==sha(p),f'{role} output evidence mismatch')

def require_image_edit(root:Path,p:Path,base:Path)->None:
    cp=p.with_name(p.name+'.call.json'); require(cp.is_file(),f'image edit call evidence required: {p.relative_to(root).as_posix()}')
    call=json.loads(cp.read_text(encoding='utf-8'))
    require(call.get('status')=='success' and call.get('network_called') is True,'formal image edit requires successful network call')
    require(call.get('api_profile') in {'gemini','gpt'} and call.get('mode')=='image_to_image_edit','formal image edit must use Gemini/GPT image_to_image_edit')
    if call.get('api_profile')=='gpt': validate_gpt_intent(root,p,call)
    require(call.get('output_path')==p.relative_to(root).as_posix() and call.get('output_sha256')==sha(p),'image edit output evidence mismatch')
    require(call.get('base_image')==base.relative_to(root).as_posix(),'image edit base_image path mismatch')
    require(call.get('base_image_sha256')==sha(base),'image edit base_image hash mismatch')
    require(image_size(p)==image_size(base),'formal localization/edit must preserve source canvas unless used as a resize intermediate')

def confirmed_candidate(root:Path,r:Path)->dict:
    pp=r/'work/confirmed-candidate.json'; require(pp.is_file(),'new-generation requires confirmed-candidate.json')
    pointer=json.loads(pp.read_text(encoding='utf-8')); required={'candidate_id','source','sha256','call_record','call_sha256','kind','round','confirmation'}
    require(isinstance(pointer,dict) and set(pointer)==required,'confirmed-candidate schema invalid')
    confirmation=pointer['confirmation']; require(isinstance(confirmation,dict) and set(confirmation)=={'mode','evidence'},'confirmation schema invalid')
    require(confirmation['mode'] in {'user','auto_authorized'} and str(confirmation['evidence']).strip(),'candidate confirmation is invalid')
    text=(r/'request.md').read_text(encoding='utf-8') if (r/'request.md').is_file() else ''
    require(str(confirmation['evidence']) in text,'confirmation evidence no longer matches request.md')
    source=bounded(root,pointer['source'],True); require(pointer['kind'] in {'formal','revision'} and pointer['sha256']==sha(source),'confirmed candidate source mismatch')
    call_path=bounded(root,str(pointer['call_record']),True); require(call_path==source.with_name(source.name+'.call.json'),'confirmed candidate call record path mismatch')
    require(pointer['call_sha256']==sha(call_path),'confirmed candidate call record hash changed')
    idx=json.loads((r/'work/candidates.json').read_text(encoding='utf-8')); matches=[x for x in idx.get('candidates',[]) if x.get('id')==pointer['candidate_id']]
    require(len(matches)==1,'confirmed candidate is absent from candidate history'); item=matches[0]
    require(item.get('source')==pointer['source'] and item.get('sha256')==pointer['sha256']
            and item.get('call_record')==pointer['call_record'] and item.get('call_sha256')==pointer['call_sha256']
            and item.get('self_check',{}).get('decision')=='accept','confirmed candidate does not match accepted history')
    w,h=image_size(source); require_master_quality(root,source,f'{w}x{h}',max(w,h),'confirmed candidate')
    return {**pointer,'path':source,'confirmed_mtime':pp.stat().st_mtime}

def require_pure_visual(root:Path,pure:Path,confirmed:dict)->None:
    require_image_edit(root,pure,confirmed['path'])

def replay_resize(source:Path,op:dict,target:Path)->None:
    with Image.open(source) as opened:
        src=ImageOps.exif_transpose(opened).convert('RGBA')
    require(op.get('source_size')==list(src.size),'resize source_size does not match real input pixels')
    crop=op.get('crop_box')
    if crop is not None:
        require(isinstance(crop,list) and len(crop)==4 and all(isinstance(v,int) for v in crop),'resize crop_box invalid')
        x1,y1,x2,y2=crop; require(0<=x1<x2<=src.width and 0<=y1<y2<=src.height,'resize crop_box outside source')
        src=src.crop((x1,y1,x2,y2))
    tw,th=image_size(target); require(op.get('output_size')==[tw,th],'resize output_size mismatch')
    sx=tw/src.width; sy=th/src.height
    require(math.isclose(float(op.get('scale_x',-1)),sx,rel_tol=0,abs_tol=1e-9) and math.isclose(float(op.get('scale_y',-1)),sy,rel_tol=0,abs_tol=1e-9),'resize scale evidence does not match real geometry')
    require(math.isclose(sx,sy,rel_tol=0,abs_tol=1e-9),'non-uniform deterministic scaling is forbidden')
    expected=src.resize((tw,th),Image.Resampling.LANCZOS)
    require(pixel_equal(target,expected),'resized pixels do not match deterministic resize operation')

def require_ai_intermediate(root:Path,master:Path,intermediate:Path)->None:
    require(intermediate!=master,'AI intermediate must be a distinct file')
    cp=intermediate.with_name(intermediate.name+'.call.json'); require(cp.is_file(),'ratio-changing resize requires image-edit intermediate call evidence')
    call=json.loads(cp.read_text(encoding='utf-8')); require(call.get('status')=='success' and call.get('network_called') is True,'AI resize intermediate requires successful network call')
    require(call.get('api_profile') in {'gemini','gpt'} and call.get('mode')=='image_to_image_edit','AI resize intermediate must use Gemini/GPT image_to_image_edit')
    require(call.get('base_image')==master.relative_to(root).as_posix() and call.get('base_image_sha256')==sha(master),'AI resize intermediate is not anchored to locale master')
    require(call.get('output_path')==intermediate.relative_to(root).as_posix() and call.get('output_sha256')==sha(intermediate),'AI resize intermediate output evidence mismatch')
    w,h=image_size(intermediate); require_master_quality(root,intermediate,f'{w}x{h}',max(w,h),'AI resize intermediate')

def require_resize_edge(root:Path,master:Path,resized:Path,locale:str,size:str)->None:
    require(resized!=master,'resized_source_image must be a separate physical file')
    op=operation_record(root,resized); require(op.get('operation')=='resize','resized_source_image requires deterministic resize operation')
    input_path=bounded(root,str(op.get('input','')),True); require(op.get('input_sha256')==sha(input_path),'resize input hash mismatch')
    require(str(op.get('locale','')).strip()==locale,'resize locale mismatch')
    w,h=(int(v) for v in size.split('x')); require(image_size(resized)==(w,h),'resized source size mismatch')
    master_ratio=image_size(master)[0]/image_size(master)[1]; target_ratio=w/h
    crop=op.get('crop_box')
    if input_path==master:
        if abs(master_ratio-target_ratio)>0.002:
            require(crop is not None,'ratio-changing production resize requires approved crop or AI re-composition intermediate')
            require(op.get('layout_plan') and op.get('crop_id'),'ratio-changing deterministic crop requires validated layout_plan + crop_id')
    else:
        require_ai_intermediate(root,master,input_path)
        ir=image_size(input_path)[0]/image_size(input_path)[1]
        require(abs(ir-target_ratio)<=0.002 or crop is not None,'AI resize intermediate must match target ratio before precise resize/crop')
    replay_resize(input_path,op,resized)

def boxes_intersect(a,b):
    return not (a[2]<=b[0] or b[2]<=a[0] or a[3]<=b[1] or b[3]<=a[1])

def validate_layout_for_place(root:Path,r:Path,base:Path,op:dict)->None:
    lp=bounded(root,str(op.get('layout_plan','')),True); require(r/'work/layout' in lp.parents,'placement layout must be inside current request work/layout')
    canonical=r/'work/layout/confirmed/layout-plan.json'
    if canonical.is_file():
        try:
            image_postprocess.load_usable_layout_for_place(canonical.relative_to(root).as_posix(),base,root)
        except Exception:
            pass
        else:
            require(lp.resolve()==canonical.resolve(),'same-composition placement must reuse the confirmed Layout Blueprint; repeated locale/size layout analysis is not allowed')
    try:
        plan,prior=image_postprocess.load_usable_layout_for_place(lp.relative_to(root).as_posix(),base,root)
    except Exception as exc:
        raise DeliveryError(str(exc)) from exc
    items=plan.get('placement_plan'); require(isinstance(items,list),'placement layout requires placement_plan')
    matches=[x for x in items if isinstance(x,dict) and x.get('id')==op.get('placement_id')]; require(len(matches)==1,'placement id missing/ambiguous in layout plan'); item=matches[0]
    require(item.get('role')==op.get('asset_role') and item.get('content_bbox')==op.get('target_box'),'placement operation does not match geometry-derived layout entry')
    require(float(item.get('confidence',0))>=0.70,'placement confidence below usable threshold')
    if op.get('asset_role')=='prop':
        require(str(item.get('group','')).strip()==str(op.get('placement_group','')).strip(),'prop placement group does not match layout plan')
        require(item.get('slot')==op.get('placement_slot'),'prop placement slot does not match layout plan')
        require(str(item.get('asset_id','')).strip()==str(op.get('asset_id','')).strip(),'prop asset identity does not match committed layout slot')
        require(str(item.get('asset_version','')).strip()==str(op.get('asset_version','')).strip(),'prop asset version does not match committed layout slot')
    if op.get('asset_role')=='logo' and op.get('baseline_source')=='generic':
        logo_items=[x for x in items if isinstance(x,dict) and x.get('role')=='logo']; aligns={x.get('alignment') for x in logo_items}
        require({'top-left','top-right'}<=aligns,'generic LOGO layout must evaluate both top candidates')
        require(item.get('alignment')==op.get('align'),'LOGO placement does not match selected candidate side')
    pb=op.get('placed_box'); require(not any(boxes_intersect(pb,x) for x in prior),'placement overlaps an earlier asset from the same layout plan')
    protected=plan.get('protected_areas') or []; medium=[]
    for x in protected:
        if not isinstance(x,dict) or not isinstance(x.get('bbox'),list): continue
        if boxes_intersect(pb,x['bbox']):
            imp=x.get('importance'); require(imp!='high','placement overlaps high protected area')
            if imp=='medium': medium.append(str(x.get('id','')))
    if medium:
        approval=str(op.get('overlap_approval') or '').strip(); require(approval,'medium protected-area overlap requires approval evidence')
        request_text=(r/'request.md').read_text(encoding='utf-8') if (r/'request.md').is_file() else ''
        require(approval in request_text,'medium overlap approval evidence missing from request.md')

def replay_place(root:Path,output:Path,op:dict)->None:
    base=bounded(root,str(op.get('base','')),True); overlay=bounded(root,str(op.get('overlay','')),True)
    with Image.open(base) as b: canvas=ImageOps.exif_transpose(b).convert('RGBA')
    with Image.open(overlay) as o:
        oriented=ImageOps.exif_transpose(o); require('A' in oriented.getbands(),'placement overlay must have alpha')
        alpha=oriented.getchannel('A'); require(alpha.getextrema()[0]<255,'placement overlay must contain transparency')
        ov=oriented.convert('RGBA'); bbox=ov.getchannel('A').getbbox(); require(bbox is not None,'placement overlay has no visible pixels'); ov=ov.crop(bbox)
    pb=op.get('placed_box'); require(isinstance(pb,list) and len(pb)==4 and all(isinstance(v,int) for v in pb),'placed_box invalid')
    x1,y1,x2,y2=pb; require(0<=x1<x2<=canvas.width and 0<=y1<y2<=canvas.height,'placed_box outside canvas')
    ov=ov.resize((x2-x1,y2-y1),Image.Resampling.LANCZOS); canvas.alpha_composite(ov,(x1,y1))
    require(pixel_equal(output,canvas),'final pixels do not match recorded placement operation')

def validate_project_placement(root:Path,base:Path,op:dict)->None:
    if op.get('baseline_source')!='project': return
    asset_id=str(op.get('asset_id','')).strip(); role=str(op.get('asset_role','')).strip(); region=str(op.get('region','') or 'global').strip() or 'global'
    require(asset_id and role in {'logo','icon','prop'},'project placement requires asset identity/role')
    data=placement_baseline.load(root/'project/baselines/asset-placement.json')
    resolved=placement_baseline.resolve(data,asset_id,role,region,image_size(base)); require(resolved is not None,'project placement baseline is missing')
    require(op.get('baseline_version')==resolved['version'],'placement baseline version mismatch')
    require(op.get('baseline_region')==resolved['baseline_region'],'placement baseline region mismatch')
    require(op.get('baseline_target_box')==resolved['bbox'] and op.get('target_box')==resolved['bbox'],'placement target does not match resolved project baseline')

def validate_generic_logo_geometry(base:Path,op:dict)->None:
    if op.get('baseline_source')!='generic': return
    w,h=image_size(base); margin=round(min(w,h)*0.04); pb=op.get('placed_box'); align=str(op.get('align',''))
    require(align in {'top-left','top-right'},'generic LOGO placement must use a validated top-left/top-right candidate')
    x1,y1,x2,y2=pb; tol=2
    require(abs(y1-margin)<=tol,'generic LOGO top margin must follow 4% safe-margin rule')
    if align=='top-left': require(abs(x1-margin)<=tol,'generic top-left LOGO side margin must equal top margin')
    else: require(abs((w-x2)-margin)<=tol,'generic top-right LOGO side margin must equal top margin')
    target=op.get('target_box'); require(isinstance(target,list) and len(target)==4,'generic LOGO target_box missing')
    tw,th=target[2]-target[0],target[3]-target[1]
    require((x2-x1)<=tw*0.82+1 and (y2-y1)<=th*0.82+1,'generic LOGO exceeds 0.82 safe fill')
    min_logo_width=max(1,round(w*250/1080))
    require((x2-x1)>=min_logo_width,f'generic LOGO width must be at least {min_logo_width}px on this canvas')

def validate_generic_icon_geometry(root:Path,op:dict)->None:
    if op.get('asset_role')!='icon' or op.get('baseline_source')!='generic': return
    overlay=bounded(root,str(op.get('overlay','')),True)
    with Image.open(overlay) as opened:
        rgba=ImageOps.exif_transpose(opened).convert('RGBA'); bbox=rgba.getchannel('A').getbbox()
    require(bbox is not None,'ICON overlay has no visible pixels')
    ow,oh=bbox[2]-bbox[0],bbox[3]-bbox[1]
    target=op.get('target_box'); placed=op.get('placed_box')
    require(isinstance(target,list) and len(target)==4 and isinstance(placed,list) and len(placed)==4,'ICON geometry evidence missing')
    tw,th=target[2]-target[0],target[3]-target[1]; pw,ph=placed[2]-placed[0],placed[3]-placed[1]
    wf,hf=pw/tw,ph/th
    require(0.35<=wf<=0.92 and 0.35<=hf<=0.92,'ICON content fill must stay within 35%-92% on both axes')
    scale=min(tw/ow,th/oh)*0.82; ew=max(1,round(ow*scale)); eh=max(1,round(oh*scale))
    require((pw,ph)==(ew,eh),'ICON placement does not match 0.82 contain scale')

def validate_generic_prop_geometry(root:Path,op:dict)->None:
    if op.get('asset_role')!='prop' or op.get('baseline_source')!='generic': return
    overlay=bounded(root,str(op.get('overlay','')),True)
    with Image.open(overlay) as opened:
        rgba=ImageOps.exif_transpose(opened).convert('RGBA'); bbox=rgba.getchannel('A').getbbox()
    require(bbox is not None,'prop overlay has no visible pixels')
    ow,oh=bbox[2]-bbox[0],bbox[3]-bbox[1]
    target=op.get('target_box'); placed=op.get('placed_box')
    require(isinstance(target,list) and len(target)==4 and isinstance(placed,list) and len(placed)==4,'prop geometry evidence missing')
    tw,th=target[2]-target[0],target[3]-target[1]; pw,ph=placed[2]-placed[0],placed[3]-placed[1]
    scale=min(tw/ow,th/oh)*0.82; ew=max(1,round(ow*scale)); eh=max(1,round(oh*scale))
    require((pw,ph)==(ew,eh),'generic prop placement does not match 0.82 normalized contain scale')
    require(str(op.get('asset_id','')).strip() and str(op.get('asset_version','')).strip(),'prop placement requires asset identity/version')
    require(str(op.get('placement_group','')).strip(),'prop placement requires group')
    slot=op.get('placement_slot'); require(isinstance(slot,int) and not isinstance(slot,bool) and slot>=1,'prop placement requires positive integer slot')

def trace_composite(root:Path,r:Path,final:Path,resized:Path,locale:str,need_logo:bool,need_prop:bool=False)->dict:
    require(final!=resized or not need_logo,'final must include LOGO placement when LOGO is required')
    if final==resized:
        require(not need_prop,'event visual requires real prop placement')
        return {'operations':0,'logo_operations':0,'prop_operations':0}
    current=final; seen=set(); n=logos=props=0; prop_slots=set(); placed_prop_specs=set(); expected_prop_specs=set(); seen_plans=set()
    while current!=resized:
        require(current.resolve() not in seen and n<16,'invalid placement lineage'); seen.add(current.resolve())
        op=operation_record(root,current); require(op.get('operation')=='place','post-resize lineage may contain only place operations')
        plan_path=bounded(root,str(op.get('layout_plan','')),True); plan_key=plan_path.relative_to(root).as_posix()
        if plan_key not in seen_plans:
            plan=json.loads(plan_path.read_text(encoding='utf-8')); items=plan.get('placement_plan') or []
            for item in items:
                if isinstance(item,dict) and item.get('role')=='prop':
                    group=str(item.get('group','')).strip(); slot=item.get('slot'); asset_id=str(item.get('asset_id','')).strip(); asset_version=str(item.get('asset_version','')).strip()
                    require(group and isinstance(slot,int) and slot>=1 and asset_id and asset_version,'prop layout slot requires group/slot/asset identity/version')
                    expected_prop_specs.add((group,slot,asset_id,asset_version))
            seen_plans.add(plan_key)
        base=bounded(root,str(op.get('base','')),True); overlay=bounded(root,str(op.get('overlay','')),True)
        require(op.get('base_sha256')==sha(base) and op.get('overlay_sha256')==sha(overlay),'placement input hash mismatch')
        require(str(op.get('locale','')).strip()==locale,'placement locale mismatch')
        validate_layout_for_place(root,r,base,op); replay_place(root,current,op); validate_generic_icon_geometry(root,op)
        role=op.get('asset_role')
        if role=='logo':
            logos+=1; require(str(op.get('asset_id','')).strip() and str(op.get('asset_version','')).strip(),'LOGO placement requires asset identity/version')
            require_authorized_source(root,r,overlay,'formal LOGO')
            validate_project_placement(root,base,op); validate_generic_logo_geometry(base,op)
        elif role=='prop':
            props+=1
            require(str(op.get('asset_id','')).strip() and str(op.get('asset_version','')).strip(),'prop placement requires asset identity/version')
            require_authorized_source(root,r,overlay,'formal prop')
            validate_project_placement(root,base,op); validate_generic_prop_geometry(root,op)
            slot_key=(str(op.get('placement_group','')).strip(),op.get('placement_slot'))
            require(slot_key not in prop_slots,f'duplicate prop placement slot: {slot_key[0]}#{slot_key[1]}'); prop_slots.add(slot_key)
            placed_prop_specs.add((slot_key[0],slot_key[1],str(op.get('asset_id','')).strip(),str(op.get('asset_version','')).strip()))
        current=base; n+=1
    if need_logo: require(logos>=1,f'final {locale} lacks required real LOGO placement')
    else: require(logos==0,f'LOGO placement exists although user explicitly disabled LOGO for {locale}')
    if need_prop:
        require(props>=1,f'final {locale} lacks required real prop placement')
        require(expected_prop_specs,f'final {locale} requires committed prop slots in layout plan')
        missing=sorted(expected_prop_specs-placed_prop_specs); extra=sorted(placed_prop_specs-expected_prop_specs)
        require(not missing and not extra,f'prop placement roster mismatch for {locale}; missing={missing}, extra={extra}')
    return {'operations':n,'logo_operations':logos,'prop_operations':props}

def video_container(p:Path)->str:
    data=p.read_bytes()[:16]
    if len(data)>=12 and data[4:8]==b'ftyp': return 'mp4-family'
    if data.startswith(b'\x1aE\xdf\xa3'): return 'webm'
    raise DeliveryError(f'video is not a recognized MP4/MOV or WebM container: {p.name}')

def require_seedance_video(root:Path,p:Path)->None:
    require(p.suffix.lower() in {'.mp4','.webm','.mov'},'video delivery must use mp4, webm, or mov')
    cp=p.with_name(p.name+'.call.json'); require(cp.is_file(),f'Seedance call evidence required: {p.relative_to(root).as_posix()}')
    call=json.loads(cp.read_text(encoding='utf-8'))
    require(call.get('status')=='success' and call.get('network_called') is True,'video delivery requires successful network call')
    require(call.get('api_profile')=='seedance','video delivery requires Seedance provenance')
    require(call.get('mode') in {'text_to_video','image_to_video_first_frame','image_to_video_first_last_frame','reference_to_video'},'invalid Seedance mode')
    require(str(call.get('task_id','')).strip() and str(call.get('task_status','')).lower() in {'succeeded','completed'},'Seedance task did not complete successfully')
    require(call.get('output_path')==p.relative_to(root).as_posix() and call.get('output_sha256')==sha(p),'Seedance output evidence mismatch')
    actual=video_container(p); expected='webm' if p.suffix.lower()=='.webm' else 'mp4-family'
    require(actual==expected and call.get('container')==actual,'Seedance video container evidence mismatch')

def validate_resize_items(root:Path,r:Path,resized:list[tuple[str,str,str,Path]])->None:
    for _,locale,size,rz in resized:
        require(size,'resized_source_image requires declared size')
        op=operation_record(root,rz); input_path=bounded(root,str(op.get('input','')),True)
        call_path=input_path.with_name(input_path.name+'.call.json')
        if call_path.is_file():
            call=json.loads(call_path.read_text(encoding='utf-8'))
            if call.get('status')=='success' and call.get('network_called') is True and call.get('mode')=='image_to_image_edit':
                master=bounded(root,str(call.get('base_image','')),True)
                require_authorized_source(root,r,master,'resize source'); require_ai_intermediate(root,master,input_path)
            else:
                master=input_path; require_authorized_source(root,r,master,'resize source')
        else:
            master=input_path; require_authorized_source(root,r,master,'resize source')
        require_resize_edge(root,master,rz,locale,size)

def validate_postprocess(root:Path,r:Path,active:list[tuple[str,str,str,Path]],branch:str)->dict:
    allowed={'localized_ui_text_image','resized_source_image','final_composited_image'}
    require(all(x[0] in allowed for x in active),f'{branch} delivery contains roles outside postprocess contract')
    localized=[x for x in active if x[0]=='localized_ui_text_image']
    resized=[x for x in active if x[0]=='resized_source_image']
    finals=[x for x in active if x[0]=='final_composited_image']
    if branch=='localization':
        require(localized and not resized and not finals,'localization branch delivers localized_ui_text_image only; use postprocess-chain for further derivation')
    elif branch=='resize':
        require(resized and not localized and not finals,'resize branch delivers resized_source_image only; use postprocess-chain for further derivation')
    elif branch=='composite':
        require(finals and resized and not localized,'composite branch requires resized_source_image + final_composited_image; use postprocess-chain when localization is included')
    else:
        require(localized or resized or finals,'postprocess-chain requires at least one formal postprocess output')
    for _,locale,_,p in localized:
        require(locale,'localized_ui_text_image requires locale')
        cp=p.with_name(p.name+'.call.json'); require(cp.is_file(),'localized_ui_text_image requires image-edit call evidence')
        call=json.loads(cp.read_text(encoding='utf-8')); base=bounded(root,str(call.get('base_image','')),True)
        require_authorized_source(root,r,base,'localization base'); require_image_edit(root,p,base)
    validate_resize_items(root,r,resized)
    for _,locale,size,final in finals:
        src=[x for x in resized if x[1]==locale and x[2]==size]
        require(len(src)==1,'final_composited_image requires exactly one matching resized_source_image')
        trace_composite(root,r,final,src[0][3],locale,logo_required(r),prop_required(r))
    return {'status':'passed','branch':branch,'active_count':len(active)}

def validate(root:Path,r:Path)->dict:
    branch=production_branch(r)
    validate_source_lock(root,r)
    if branch=='new-generation':
        import importlib.util
        gate=Path(__file__).resolve().parent/'store_artwork_gate.py'
        spec=importlib.util.spec_from_file_location('wxian_store_artwork_gate',gate)
        require(spec is not None and spec.loader is not None,'store artwork gate unavailable')
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        try:
            store_result=mod.validate(root,r,require_visual_requirement=True)
        except Exception as exc:
            raise DeliveryError(str(exc)) from exc
        require(store_result.get('status') in {'passed','not_applicable'},'store artwork gate failed')
    mp=r/'work/delivery-manifest.json'; require(mp.is_file(),'work/delivery-manifest.json is required')
    m=json.loads(mp.read_text(encoding='utf-8')); require(isinstance(m,dict) and set(m)=={'files'} and isinstance(m['files'],list) and m['files'],'delivery manifest invalid')
    active=[]; keys=set()
    for i,x in enumerate(m['files']):
        require(isinstance(x,dict) and set(x)<={'role','source','sha256','active','locale','size'} and {'role','source','sha256','active'}<=set(x),f'files[{i}] schema invalid')
        p=bounded(root,x['source'],True); require(p.is_file() and r/'work' in p.parents,'delivery source must be current request work file'); require(x['sha256']==sha(p),'delivery hash mismatch')
        role=str(x['role']).strip(); locale=str(x.get('locale','')).strip(); size=str(x.get('size','')).strip(); require(role and isinstance(x['active'],bool),'delivery role/active invalid')
        key=(role,locale,size)
        if x['active']: require(key not in keys,f'duplicate active delivery key: {key}'); keys.add(key); active.append((role,locale,size,p))
        if Image is not None and p.suffix.lower() in {'.png','.jpg','.jpeg','.webp'}:
            w,h=image_size(p); actual=f'{w}x{h}'
            if size: require(actual==size,f'declared size {size} != {actual}')
            if role in {'base_ui_text_image','pure_visual_image','localized_ui_text_image'}: require_master_quality(root,p,actual,max(w,h),role)
    require(active,'delivery manifest requires at least one active file')

    if branch in ARTIFACT_ONLY_BRANCHES:
        media={'.png','.jpg','.jpeg','.webp','.mp4','.webm','.mov'}
        require(all(p.suffix.lower() not in media for _,_,_,p in active),f'{branch} cannot deliver generated image/video media')
        return {'status':'passed','branch':branch,'active_count':len(active)}

    if branch=='video':
        require(all(p.suffix.lower() in {'.mp4','.webm','.mov'} for _,_,_,p in active),'video branch may deliver video files only')
        for _,_,_,p in active: require_seedance_video(root,p)
        return {'status':'passed','branch':branch,'active_count':len(active)}

    if branch=='image-edit':
        require(all(p.suffix.lower() in {'.png','.jpg','.jpeg','.webp'} for _,_,_,p in active),'image-edit branch may deliver image files only')
        for _,_,_,p in active:
            cp=p.with_name(p.name+'.call.json'); require(cp.is_file(),f'image-edit call evidence required: {p.relative_to(root).as_posix()}')
            call=json.loads(cp.read_text(encoding='utf-8')); base=bounded(root,str(call.get('base_image','')),True)
            require_authorized_source(root,r,base,'image-edit base'); require_image_edit(root,p,base)
        return {'status':'passed','branch':branch,'active_count':len(active)}

    if branch in {'resize','localization','composite','postprocess-chain'}:
        return validate_postprocess(root,r,active,branch)

    require(branch=='new-generation',f'unsupported production branch: {branch}')
    confirmed=confirmed_candidate(root,r)
    canonical_layout=r/'work/layout/confirmed/layout-plan.json'
    require(canonical_layout.is_file(),'new-generation requires one confirmed Layout Blueprint after candidate confirmation')
    try:
        image_postprocess.validate_layout_command(argparse.Namespace(plan=canonical_layout.relative_to(root).as_posix(),workspace_root=root,require_usable=True,require_title_zone=False))
    except Exception as exc:
        raise DeliveryError(str(exc)) from exc
    canonical_data=json.loads(canonical_layout.read_text(encoding='utf-8'))
    require(bounded(root,str(canonical_data.get('source_path','')),True)==confirmed['path'],'confirmed Layout Blueprint must analyze the confirmed candidate exactly once')
    require(canonical_data.get('source_sha256')==sha(confirmed['path']),'confirmed Layout Blueprint source hash mismatch')
    roles=lambda name:[x for x in active if x[0]==name]
    bases=roles('base_ui_text_image'); require(len(bases)==1 and bases[0][3]==confirmed['path'],'new-generation base must be the confirmed candidate')
    pure=roles('pure_visual_image'); require(len(pure)==1,'new-generation requires one pure_visual_image'); require(pure[0][3].stat().st_mtime >= confirmed['confirmed_mtime'],'pure visual predates candidate confirmation'); require_pure_visual(root,pure[0][3],confirmed)
    finals=roles('final_composited_image'); require(finals,'new-generation requires final images')
    for role,_,_,p in active:
        if role!='base_ui_text_image': require(p.stat().st_mtime >= confirmed['confirmed_mtime'],f'{role} predates candidate confirmation')
    locales=sorted({x[1] for x in finals}); sizes=sorted({x[2] for x in finals}); require(all(locales) and all(sizes),'finals require locale and size')
    need_logo=logo_required(r); need_prop=prop_required(r); pure_master=pure[0][3]
    for locale in locales:
        loc=[x for x in roles('localized_ui_text_image') if x[1]==locale]
        if locale=='und':
            require(len(loc)==0,'locale=und uses pure_visual_image directly and must not duplicate localized_ui_text_image')
            master=pure_master
        else:
            require(len(loc)==1,f'missing/duplicate localized master for {locale}')
            master=loc[0][3]; require_image_edit(root,master,pure_master)
        for size in sizes:
            rz=[x for x in roles('resized_source_image') if x[1]==locale and x[2]==size]; fn=[x for x in finals if x[1]==locale and x[2]==size]
            require(len(rz)==1 and len(fn)==1,f'missing/duplicate {locale} {size} delivery pair')
            require_resize_edge(root,master,rz[0][3],locale,size); trace_composite(root,r,fn[0][3],rz[0][3],locale,need_logo,need_prop)
    variant=presenting_variant(r)
    if variant in PRESENTING_VARIANTS:
        for role,locale_name,size_name,p in finals:
            require_presenting_picture(p,f'{role} {locale_name}/{size_name} {p.relative_to(root).as_posix()}')
    return {'status':'passed','branch':branch,'active_count':len(active),'presenting_variant':variant or None}

def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--request',required=True); ap.add_argument('--workspace-root',type=Path,default=Path(__file__).resolve().parents[4]); a=ap.parse_args()
    try:
        root=a.workspace_root.resolve(); out=validate(root,req(root,a.request)); print(json.dumps(out,ensure_ascii=False,indent=2)); return 0
    except (DeliveryError,OSError,json.JSONDecodeError,ValueError) as e:
        print(json.dumps({'status':'blocked','reason':str(e)},ensure_ascii=False,indent=2)); return 1
if __name__=='__main__': sys.exit(main())
