#!/usr/bin/env python3
"""Offline regression for GPT call-receipt binding across record, confirm, and delivery."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import sys
import tempfile
from pathlib import Path

from PIL import Image


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ValueError(f"cannot load module: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_json(path: Path, value: dict) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def expect_block(label: str, action) -> None:
    try:
        action()
    except (OSError, ValueError, json.JSONDecodeError):
        return
    raise ValueError(f"negative regression did not block: {label}")


def run(runtime_root: Path) -> dict:
    runtime_root = runtime_root.resolve()
    scripts = runtime_root / ".agents/skills/wxian-image-production/scripts"
    if str(scripts) not in sys.path:
        sys.path.insert(0, str(scripts))
    candidate = load_module(scripts / "candidate_tracker.py", "gpt_lifecycle_candidate_tracker")
    delivery = load_module(scripts / "delivery_gate.py", "gpt_lifecycle_delivery_gate")
    contract = load_module(runtime_root / ".agents/lib/gpt_image_contract.py", "gpt_lifecycle_contract")

    with tempfile.TemporaryDirectory() as temp_dir:
        root = Path(temp_dir).resolve()
        request = root / "requests/image-generation/gpt-lifecycle"
        work = request / "work"
        work.mkdir(parents=True)
        request_text = "请用gpt生图，4K，PNG透明底，16:9，无需确认。"
        request_source = request / "request.md"
        request_source.write_text(request_text, encoding="utf-8")
        source = work / "master.png"
        Image.new("RGB", (3840, 2160), (24, 48, 72)).save(source, format="PNG", optimize=True)
        source_rel = source.relative_to(root).as_posix()
        source_sha = candidate.sha(source)
        resolved = contract.resolve_gpt_request(request_text, aspect_ratio="1:1")
        resolved_sha = hashlib.sha256(
            json.dumps(resolved, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        call = {
            "status": "success",
            "network_called": True,
            "api_profile": "gpt",
            "mode": "text_to_image",
            "model": resolved["model"],
            "parameters": resolved["parameters"],
            "reference_images": [],
            "output_path": source_rel,
            "output_sha256": source_sha,
            "gpt_intent_binding": {
                "request_path": request_source.relative_to(root).as_posix(),
                "request_sha256": candidate.sha(request_source),
                "resolved": resolved,
                "resolved_sha256": resolved_sha,
            },
        }
        call_path = source.with_name(source.name + ".call.json")
        write_json(call_path, call)
        review = {field: True for field in candidate.REVIEW_BOOL_FIELDS}
        review.update({"artifact_risk": "low", "decision": "accept", "reject_reason": "", "next_action": ""})
        write_json(source.with_name(source.name + ".review.json"), review)

        recorded = candidate.record(root, request, source_rel, "formal")
        call_bytes = call_path.read_bytes()
        call_path.write_text("{}\n", encoding="utf-8")
        expect_block(
            "candidate confirm accepts a tampered call receipt",
            lambda: candidate.confirm(root, request, recorded["candidate"]["id"], "auto_authorized", "无需确认"),
        )
        call_path.write_bytes(call_bytes)
        candidate.confirm(root, request, recorded["candidate"]["id"], "auto_authorized", "无需确认")

        changed = json.loads(call_path.read_text(encoding="utf-8"))
        changed["service_request_id"] = "tampered-after-confirm"
        write_json(call_path, changed)
        expect_block(
            "delivery accepts a call receipt changed after confirmation",
            lambda: delivery.confirmed_candidate(root, request),
        )
        call_path.write_bytes(call_bytes)
        delivery.confirmed_candidate(root, request)

        call_path.unlink()
        expect_block(
            "4K master bypasses missing call evidence",
            lambda: delivery.require_master_quality(root, source, "3840x2160", 3840, "4K GPT master"),
        )
        call_path.write_bytes(call_bytes)
        delivery.require_master_quality(root, source, "3840x2160", 3840, "4K GPT master")

        override_request = root / "requests/image-generation/gpt-explicit-overrides"
        override_work = override_request / "work"
        override_work.mkdir(parents=True)
        override_text = "请用gpt生图，无需确认。"
        override_source_text = override_request / "request.md"
        override_source_text.write_text(override_text, encoding="utf-8")
        override_source = override_work / "master.png"
        Image.new("RGB", (2048, 1152), (72, 48, 24)).save(override_source, format="PNG", optimize=True)
        override_parameters = {
            "size": "2048x1152",
            "quality": "high",
            "background": "auto",
            "moderation": "low",
            "output_format": "png",
        }
        override_resolved = contract.validate_resolved_gpt_request(
            override_text, contract.GPT_IMAGE_25_FLARE, override_parameters, aspect_ratio="1:1"
        )
        override_resolved_sha = hashlib.sha256(
            json.dumps(override_resolved, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
        override_call = {
            "status": "success",
            "network_called": True,
            "api_profile": "gpt",
            "mode": "text_to_image",
            "model": contract.GPT_IMAGE_25_FLARE,
            "parameters": override_resolved["parameters"],
            "reference_images": [],
            "output_path": override_source.relative_to(root).as_posix(),
            "output_sha256": candidate.sha(override_source),
            "gpt_intent_binding": {
                "request_path": override_source_text.relative_to(root).as_posix(),
                "request_sha256": candidate.sha(override_source_text),
                "resolved": override_resolved,
                "resolved_sha256": override_resolved_sha,
            },
        }
        write_json(override_source.with_name(override_source.name + ".call.json"), override_call)
        write_json(override_source.with_name(override_source.name + ".review.json"), review)
        override_recorded = candidate.record(
            root, override_request, override_source.relative_to(root).as_posix(), "formal"
        )
        candidate.confirm(
            root, override_request, override_recorded["candidate"]["id"], "auto_authorized", "无需确认"
        )
        delivery.confirmed_candidate(root, override_request)

    return {
        "status": "passed",
        "cases": [
            "confirm-rejects-tampered-call-receipt",
            "delivery-rejects-post-confirm-call-drift",
            "4k-master-requires-call-and-intent-evidence",
            "explicit-legal-overrides-survive-record-confirm-delivery",
        ],
        "network_called": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime-root", type=Path, default=Path(__file__).resolve().parents[4])
    args = parser.parse_args()
    try:
        result = run(args.runtime_root)
        code = 0
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        result = {"status": "failed", "reason": str(exc), "network_called": False}
        code = 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
