# 模型 Prompt 方言索引

本文件只保留兼容索引。完整规则位于 `prompt-packs/`，避免多处维护同一模型语义。

- GPT Image / 当前 `gpt` API Profile → `prompt-packs/gpt-image-2.md`
- Gemini / Nano Banana / 当前 `gemini` API Profile → `prompt-packs/gemini-image.md`
- ComfyUI / Diffusion Prompt-only → `prompt-packs/comfyui-diffusion.md`
- Seedream Prompt-only → `prompt-packs/seedream.md`
- 未知或未提供专用包的模型 → `prompt-packs/generic-natural-language.md`

模型适配只能压缩、重排、翻译和编码已成立 Visual Spec；不得新增上游没有的角色、事件、资产、玩法、构图主张或品牌事实。模型参数继续留在 API/Workflow 请求，不写进主 Prompt。
