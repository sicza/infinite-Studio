#!/usr/bin/env python3
"""Deterministic image resize and transparent asset placement for visual projects."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import sys
from pathlib import Path

LIB=Path(__file__).resolve().parents[3]/'lib'
if str(LIB) not in sys.path: sys.path.insert(0,str(LIB))
from project_materials import indexed_project_source

import placement_baseline

try:
    from PIL import Image, ImageOps, __version__ as pillow_version
except ImportError as exc:  # pragma: no cover - exercised by runtime doctor
    print(json.dumps({"status": "blocked", "reason": "Pillow is not installed"}, ensure_ascii=False))
    raise SystemExit(2) from exc


class PostprocessError(ValueError):
    pass


GENERIC_ASSET_SAFE_FILL = 0.82


def require(condition: bool, message: str) -> None:
    if not condition:
        raise PostprocessError(message)


def parse_box(value: str) -> tuple[int, int, int, int]:
    try:
        parts = tuple(int(item.strip()) for item in value.split(","))
    except ValueError as exc:
        raise argparse.ArgumentTypeError("box must be x1,y1,x2,y2 integers") from exc
    if len(parts) != 4 or parts[0] < 0 or parts[1] < 0 or parts[2] <= parts[0] or parts[3] <= parts[1]:
        raise argparse.ArgumentTypeError("box must satisfy 0 <= x1 < x2 and 0 <= y1 < y2")
    return parts


def boxes_intersect(a: tuple[int, int, int, int], b: tuple[int, int, int, int]) -> bool:
    return not (a[2] <= b[0] or b[2] <= a[0] or a[3] <= b[1] or b[3] <= a[1])


def box_contains(outer: tuple[int, int, int, int], inner: tuple[int, int, int, int]) -> bool:
    return outer[0] <= inner[0] and outer[1] <= inner[1] and outer[2] >= inner[2] and outer[3] >= inner[3]


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def workspace_path(value: str, root: Path, *, must_exist: bool = False) -> Path:
    candidate = Path(value)
    if not candidate.is_absolute():
        candidate = root / candidate
    resolved = candidate.resolve()
    require(resolved == root or root in resolved.parents, f"path escapes Workspace: {value}")
    if must_exist:
        require(resolved.is_file(), f"input does not exist: {value}")
    return resolved


def workspace_relative(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def request_root_from_work(path: Path, root: Path) -> Path:
    relative = path.relative_to(root)
    lowered = [part.lower() for part in relative.parts]
    require("requests" in lowered and "work" in lowered, "output must be inside the current request work directory")
    requests_index = lowered.index("requests")
    work_index = lowered.index("work", requests_index + 1)
    require(work_index >= requests_index + 3, "request path must be requests/<type>/<request>/work")
    return root.joinpath(*relative.parts[:work_index])


def require_source_path(path: Path, root: Path, request_root: Path) -> None:
    path=path.resolve(); allowed=[(request_root/'input').resolve(),(request_root/'work').resolve()]
    ok=any(path==base or base in path.parents for base in allowed) or indexed_project_source(root.resolve(),path)
    require(ok, "source must be current request input/work or current indexed project material")

def prepare_paths(inputs: list[str], output_value: str, root_value: Path) -> tuple[list[Path], Path, Path]:
    root = root_value.resolve()
    require(root.is_dir(), f"Workspace root does not exist: {root}")
    output = workspace_path(output_value, root)
    request_root = request_root_from_work(output, root)
    paths = [workspace_path(value, root, must_exist=True) for value in inputs]
    for path in paths:
        require_source_path(path, root, request_root)
    record = output.with_name(output.name + ".operation.json")
    require(not output.exists(), f"output already exists: {output}")
    require(not record.exists(), f"operation record already exists: {record}")
    output.parent.mkdir(parents=True, exist_ok=True)
    return paths, output, request_root


def prepare_output(path: Path) -> None:
    require(not path.exists(), f"output already exists: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)


def save_image(image: Image.Image, output: Path, source_info: dict) -> None:
    prepare_output(output)
    suffix = output.suffix.lower()
    save_args: dict = {}
    if source_info.get("icc_profile"):
        save_args["icc_profile"] = source_info["icc_profile"]
    if suffix in {".jpg", ".jpeg"}:
        image = image.convert("RGB")
        save_args.update(quality=95, subsampling=0)
    elif suffix == ".png":
        image = image.convert("RGBA")
        save_args.update(optimize=True)
    elif suffix == ".webp":
        save_args.update(quality=95, method=6)
    else:
        raise PostprocessError("output format must be PNG, JPEG, or WEBP")
    image.save(output, **save_args)
    with Image.open(output) as check:
        check.load()
        require(check.size == image.size, "saved image size does not match")


def write_record(output: Path, value: dict) -> Path:
    record = output.with_name(output.name + ".operation.json")
    prepare_output(record)
    record.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return record


def validate_layout_box(value: object, width: int, height: int, label: str) -> tuple[int, int, int, int]:
    require(isinstance(value, list) and len(value) == 4 and all(isinstance(item, int) and not isinstance(item, bool) for item in value),
            f"{label} must be an integer [x1,y1,x2,y2] box")
    box = tuple(value)
    require(0 <= box[0] < box[2] <= width and 0 <= box[1] < box[3] <= height,
            f"{label} exceeds canvas or is invalid")
    return box


def validate_layout_entries(raw: object, width: int, height: int, label: str, *, protected: bool=False) -> list[dict]:
    require(isinstance(raw, list), f"layout plan requires {label} array")
    seen=set(); entries=[]
    fields={"id","role","bbox","confidence","evidence"}|({"importance"} if protected else set())
    for index,item in enumerate(raw):
        require(isinstance(item,dict) and set(item)==fields,f"{label}[{index}] schema invalid")
        item_id=str(item.get("id","")).strip(); role=str(item.get("role","")).strip(); evidence=str(item.get("evidence","")).strip(); confidence=item.get("confidence")
        require(item_id and item_id not in seen and role and evidence,f"{label}[{index}] requires unique id, role, evidence")
        require(isinstance(confidence,(int,float)) and not isinstance(confidence,bool) and 0<=confidence<=1,f"{label}[{index}] confidence invalid")
        validate_layout_box(item.get("bbox"),width,height,f"{label}[{index}].bbox")
        if protected: require(item.get("importance") in {"high","medium","low"},f"{label}[{index}] importance must be high|medium|low")
        seen.add(item_id); entries.append(item)
    return entries

def validate_layout_command(args: argparse.Namespace) -> dict:
    root = args.workspace_root.resolve()
    plan_path = workspace_path(args.plan, root, must_exist=True)
    request_root = request_root_from_work(plan_path, root)
    require(request_root / "work" / "layout" in plan_path.parents,
            "layout plan must be inside current request work/layout")
    try:
        plan = json.loads(plan_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise PostprocessError(f"invalid layout plan JSON: {exc}") from exc
    require(isinstance(plan, dict), "layout plan root must be an object")
    require(set(plan) == {"source_path", "source_sha256", "canvas", "coordinate_system",
                          "protected_areas", "text_areas", "placement_plan", "extendable_background",
                          "approved_crops", "status", "review"},
            "layout plan contains missing or unnecessary fields")
    source_value = str(plan.get("source_path", ""))
    require(source_value and not Path(source_value).is_absolute(), "layout plan source_path must be Workspace-relative")
    source = workspace_path(source_value, root, must_exist=True)
    require_source_path(source, root, request_root)
    require(plan.get("source_sha256") == sha256_file(source), "layout plan source_sha256 mismatch")
    with Image.open(source) as opened:
        opened.load()
        width, height = opened.size
    require(plan.get("canvas") == [width, height], "layout plan canvas does not match source pixels")
    require(plan.get("coordinate_system") == "xyxy-top-left", "layout plan coordinate_system must be xyxy-top-left")
    protected = validate_layout_entries(plan.get("protected_areas"), width, height, "protected_areas", protected=True)
    text = validate_layout_entries(plan.get("text_areas"), width, height, "text_areas")
    if getattr(args, "require_title_zone", False):
        titles = [item for item in text if str(item.get("role", "")).lower() in {"title", "headline", "marketing-title", "marketing_title"}]
        require(len(titles) == 1, "default title-zone check requires exactly one title/headline text area")
        title = tuple(titles[0]["bbox"])
        allowed = (int(round(width * 0.08)), int(round(height * 0.75)), int(round(width * 0.92)), height)
        require(box_contains(allowed, title), "title bbox must stay inside default x=8%..92%, y=75%..100% safe zone")
    extendable = validate_layout_entries(plan.get("extendable_background"), width, height, "extendable_background")
    placements = plan.get("placement_plan")
    require(isinstance(placements, list), "layout plan requires placement_plan array")
    placement_ids: set[str] = set()
    for index, item in enumerate(placements):
        require(isinstance(item, dict), f"placement_plan[{index}] must be an object")
        required={"id","role","frame_bbox","content_bbox","confidence","evidence"}
        allowed=required|{"alignment","group","slot","asset_id","asset_version"}
        require(required <= set(item) <= allowed, f"placement_plan[{index}] schema invalid")
        item_id = str(item.get("id", "")).strip()
        role = str(item.get("role", "")).strip()
        evidence = str(item.get("evidence", "")).strip()
        confidence = item.get("confidence")
        require(item_id and item_id not in placement_ids and role and evidence,
                f"placement_plan[{index}] requires unique id, role, and evidence")
        require(isinstance(confidence, (int, float)) and not isinstance(confidence, bool) and 0 <= confidence <= 1,
                f"placement_plan[{index}] confidence must be between 0 and 1")
        frame = validate_layout_box(item.get("frame_bbox"), width, height, f"placement_plan[{index}].frame_bbox")
        content = validate_layout_box(item.get("content_bbox"), width, height, f"placement_plan[{index}].content_bbox")
        require(box_contains(frame, content), f"placement_plan[{index}] content_bbox must be inside frame_bbox")
        if role == "logo":
            require(item.get("alignment") in {"top-left","top-right"}, f"placement_plan[{index}] LOGO requires top-left/top-right alignment")
            require(not ({"group","slot","asset_id","asset_version"} & set(item)), f"placement_plan[{index}] LOGO does not use prop identity/group/slot fields")
        elif role == "prop":
            group=str(item.get("group","")).strip(); slot=item.get("slot")
            asset_id=str(item.get("asset_id","")).strip(); asset_version=str(item.get("asset_version","")).strip()
            require(group and isinstance(slot,int) and not isinstance(slot,bool) and slot>=1,
                    f"placement_plan[{index}] prop requires group and positive integer slot")
            require(asset_id and asset_version, f"placement_plan[{index}] prop requires asset_id and asset_version")
            require("alignment" not in item, f"placement_plan[{index}] prop alignment is derived by placement, not layout schema")
        else:
            require(not ({"group","slot","asset_id","asset_version"} & set(item)), f"placement_plan[{index}] prop identity/group/slot fields are reserved for prop")
        placement_ids.add(item_id)
    logo_entries=[item for item in placements if item.get("role")=="logo"]
    if logo_entries:
        aligns={item.get("alignment") for item in logo_entries}
        require({"top-left","top-right"} <= aligns, "generic LOGO layout must evaluate both top-left and top-right candidates")
    prop_entries=[item for item in placements if item.get("role")=="prop"]
    prop_slots=set()
    for item in prop_entries:
        key=(str(item["group"]).strip(),int(item["slot"]))
        require(key not in prop_slots, f"duplicate prop group/slot: {key[0]}#{key[1]}")
        prop_slots.add(key)
    approved_crops = plan.get("approved_crops")
    require(isinstance(approved_crops, list), "layout plan requires approved_crops array")
    crop_ids: set[str] = set()
    protected_boxes = [tuple(item["bbox"]) for item in protected]
    for index, item in enumerate(approved_crops):
        require(isinstance(item, dict), f"approved_crops[{index}] must be an object")
        require(set(item) == {"id", "bbox", "evidence"},
                f"approved_crops[{index}] contains missing or unnecessary fields")
        item_id = str(item.get("id", "")).strip()
        evidence = str(item.get("evidence", "")).strip()
        require(item_id and item_id not in crop_ids and evidence,
                f"approved_crops[{index}] requires unique id and evidence")
        crop = validate_layout_box(item.get("bbox"), width, height, f"approved_crops[{index}].bbox")
        require(all(box_contains(crop, protected_box) for protected_box in protected_boxes),
                f"approved_crops[{index}] would remove a protected area")
        crop_ids.add(item_id)
    status = plan.get("status")
    require(status in {"usable", "needs_review", "blocked"}, "layout plan status is invalid")
    review = plan.get("review")
    require(isinstance(review, dict), "layout plan requires main-agent review")
    require(set(review) == {"source_sha256", "decision", "evidence"},
            "layout review contains missing or unnecessary fields")
    require(review.get("source_sha256") == sha256_file(source), "layout review source hash mismatch")
    require(review.get("decision") == status, "layout review decision must equal plan status")
    require(bool(str(review.get("evidence", "")).strip()), "layout review requires concrete visual evidence")
    if status == "usable":
        low_confidence = [item["id"] for item in placements if item["confidence"] < 0.70]
        require(not low_confidence,
                f"usable layout cannot contain placement confidence below 0.70: {low_confidence}")
    if args.require_usable:
        require(status == "usable", f"layout plan is not usable: {status}")
    return {
        "status": "passed",
        "plan": workspace_relative(plan_path, root),
        "plan_sha256": sha256_file(plan_path),
        "source": workspace_relative(source, root),
        "source_sha256": sha256_file(source),
        "canvas": [width, height],
        "protected_area_count": len(protected),
        "text_area_count": len(text),
        "placement_count": len(placements),
        "approved_crop_count": len(approved_crops),
        "extendable_background_count": len(extendable),
        "layout_status": status,
    }


def load_usable_layout(plan_value: str, source: Path, root: Path) -> dict:
    validate_layout_command(argparse.Namespace(plan=plan_value, workspace_root=root, require_usable=True))
    plan_path = workspace_path(plan_value, root, must_exist=True)
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    declared_source = workspace_path(str(plan.get("source_path", "")), root, must_exist=True)
    require(declared_source == source, "layout plan source does not match the operation source")
    return plan


def _compose_affine(current: tuple[float,float,float,float], edge: tuple[float,float,float,float]) -> tuple[float,float,float,float]:
    sx,sy,tx,ty=current; ex,ey,etx,ety=edge
    return ex*sx, ey*sy, ex*tx+etx, ey*ty+ety

def _map_box(box: list[int] | tuple[int,int,int,int], affine: tuple[float,float,float,float], width:int, height:int, label:str) -> list[int]:
    sx,sy,tx,ty=affine; x1,y1,x2,y2=box
    mapped=[round(sx*x1+tx),round(sy*y1+ty),round(sx*x2+tx),round(sy*y2+ty)]
    require(0<=mapped[0]<mapped[2]<=width and 0<=mapped[1]<mapped[3]<=height, f"{label} falls outside the derived canvas; analyze the changed composition once")
    return mapped

def _geometry_edge_from_resize(op:dict, parent:Path, child:Path) -> tuple[float,float,float,float]:
    require(op.get("status")=="success" and op.get("operation")=="resize", "invalid resize geometry edge")
    require(op.get("input")==workspace_relative(parent, op['_root']) and op.get("input_sha256")==sha256_file(parent), "resize geometry input evidence mismatch")
    require(op.get("output")==workspace_relative(child, op['_root']) and op.get("output_sha256")==sha256_file(child), "resize geometry output evidence mismatch")
    with Image.open(parent) as im: pw,ph=im.size
    with Image.open(child) as im: cw,ch=im.size
    crop=op.get("crop_box") or [0,0,pw,ph]
    require(isinstance(crop,list) and len(crop)==4 and all(isinstance(v,int) for v in crop), "resize crop geometry is invalid")
    x1,y1,x2,y2=crop; require(0<=x1<x2<=pw and 0<=y1<y2<=ph, "resize crop exceeds input canvas")
    sx=cw/(x2-x1); sy=ch/(y2-y1)
    require(abs(sx-sy)<=1e-9, "layout geometry only supports uniform deterministic resize")
    return sx,sy,-x1*sx,-y1*sy

def _same_canvas_edit_parent(current:Path, root:Path) -> Path | None:
    call_path=current.with_name(current.name+".call.json")
    if not call_path.is_file(): return None
    call=json.loads(call_path.read_text(encoding="utf-8"))
    if not (call.get("status")=="success" and call.get("network_called") is True and call.get("mode")=="image_to_image_edit"):
        return None
    base_value=str(call.get("base_image","")).strip()
    if not base_value: return None
    base=workspace_path(base_value,root,must_exist=True)
    require(call.get("base_image_sha256")==sha256_file(base), "image-edit geometry base hash mismatch")
    require(call.get("output_path")==workspace_relative(current,root) and call.get("output_sha256")==sha256_file(current), "image-edit geometry output evidence mismatch")
    with Image.open(base) as b, Image.open(current) as c:
        require(b.size==c.size, "AI recompose changed the canvas; create one new layout analysis for that composition")
    return base

def load_usable_layout_for_place(plan_value: str, source: Path, root: Path) -> tuple[dict, list[tuple[int,int,int,int]]]:
    """Reuse one reviewed layout through geometry-preserving edits and deterministic resizes.

    Language edits and pure-visual edits are identity geometry edges when their canvas is unchanged.
    Deterministic resize/crop edges are mapped mathematically. A size-changing AI edit is a new
    composition and therefore requires one new reviewed layout plan.
    """
    validate_layout_command(argparse.Namespace(plan=plan_value, workspace_root=root, require_usable=True, require_title_zone=False))
    plan_path = workspace_path(plan_value, root, must_exist=True)
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    declared_source = workspace_path(str(plan.get("source_path", "")), root, must_exist=True)
    current=source.resolve(); seen=set(); prior=[]; reverse_edges=[]; plan_rel=workspace_relative(plan_path,root)
    while current != declared_source:
        require(current not in seen and len(seen)<32, "layout geometry ancestry is invalid")
        seen.add(current)
        record=current.with_name(current.name+".operation.json")
        if record.is_file():
            op=json.loads(record.read_text(encoding="utf-8"))
            require(op.get("status")=="success" and op.get("output")==workspace_relative(current,root) and op.get("output_sha256")==sha256_file(current), "layout ancestry operation evidence mismatch")
            kind=op.get("operation")
            if kind=="place":
                require(op.get("layout_plan")==plan_rel, "all placements reusing one layout must reference the same layout plan")
                pb=op.get("placed_box"); require(isinstance(pb,list) and len(pb)==4 and all(isinstance(v,int) for v in pb), "prior placement bbox invalid")
                prior.append(tuple(pb)); parent=workspace_path(str(op.get("base","")),root,must_exist=True)
                require(op.get("base_sha256")==sha256_file(parent), "layout ancestry base hash mismatch")
                reverse_edges.append((1.0,1.0,0.0,0.0)); current=parent; continue
            if kind=="resize":
                parent=workspace_path(str(op.get("input","")),root,must_exist=True)
                edge_data=dict(op); edge_data['_root']=root
                reverse_edges.append(_geometry_edge_from_resize(edge_data,parent,current)); current=parent; continue
            raise PostprocessError("layout ancestry contains a geometry-changing operation; analyze that composition once")
        parent=_same_canvas_edit_parent(current,root)
        require(parent is not None, "placement base is not a geometry-preserving descendant of the reviewed layout")
        reverse_edges.append((1.0,1.0,0.0,0.0)); current=parent
    affine=(1.0,1.0,0.0,0.0)
    for edge in reversed(reverse_edges): affine=_compose_affine(affine,edge)
    with Image.open(source) as opened: width,height=opened.size
    mapped=json.loads(json.dumps(plan,ensure_ascii=False))
    mapped["canvas"]=[width,height]
    for collection in ("protected_areas","text_areas","extendable_background"):
        for item in mapped.get(collection,[]): item["bbox"]=_map_box(item["bbox"],affine,width,height,f"{collection}.{item.get('id','?')}")
    for item in mapped.get("placement_plan",[]):
        item["frame_bbox"]=_map_box(item["frame_bbox"],affine,width,height,f"placement.{item.get('id','?')}.frame")
        item["content_bbox"]=_map_box(item["content_bbox"],affine,width,height,f"placement.{item.get('id','?')}.content")
    for item in mapped.get("approved_crops",[]): item["bbox"]=_map_box(item["bbox"],affine,width,height,f"crop.{item.get('id','?')}")
    return mapped, prior


def resize_command(args: argparse.Namespace) -> dict:
    paths, output, _ = prepare_paths([args.input], args.output, args.workspace_root)
    source = paths[0]
    require(args.width > 0 and args.height > 0, "target dimensions must be positive")

    with Image.open(source) as opened:
        opened.load()
        source_info = dict(opened.info)
        image = ImageOps.exif_transpose(opened).convert("RGBA")
        original_size = image.size

    protected_boxes = list(args.protected_box)
    crop_box = None
    if args.crop_id:
        require(bool(args.layout_plan), "crop-id requires a validated layout plan")
        plan = load_usable_layout(args.layout_plan, source, args.workspace_root.resolve())
        protected_boxes.extend(tuple(item["bbox"]) for item in plan["protected_areas"])
        matches = [item for item in plan["approved_crops"] if item["id"] == args.crop_id]
        require(len(matches) == 1, f"crop-id is not uniquely approved by the layout plan: {args.crop_id}")
        crop_box = tuple(matches[0]["bbox"])
    else:
        require(not args.layout_plan, "layout-plan without crop-id is not used by resize")
    invalid_protected = [list(box) for box in protected_boxes if box[2] > image.width or box[3] > image.height]
    require(not invalid_protected, f"protected boxes exceed source bounds: {invalid_protected}")

    if crop_box:
        x1, y1, x2, y2 = crop_box
        require(x2 <= image.width and y2 <= image.height, "crop box exceeds image bounds")
        outside = [list(box) for box in protected_boxes if not box_contains(crop_box, box)]
        require(not outside, f"approved crop would remove protected boxes: {outside}")
        image = image.crop(crop_box)
    source_ratio = image.width / image.height
    target_ratio = args.width / args.height
    require(abs(source_ratio - target_ratio) <= 0.002,
            "aspect ratio differs; use AI expansion or re-composition before deterministic resize")

    resized = image.resize((args.width, args.height), Image.Resampling.LANCZOS)
    scale_x = args.width / image.width
    scale_y = args.height / image.height
    require(abs(scale_x - scale_y) <= 1e-9,
            "non-uniform scaling is forbidden; deterministic output must preserve aspect ratio")
    save_image(resized, output, source_info)
    result = {
        "status": "success",
        "operation": "resize",
        "input": workspace_relative(source, args.workspace_root.resolve()),
        "input_sha256": sha256_file(source),
        "output": workspace_relative(output, args.workspace_root.resolve()),
        "output_sha256": sha256_file(output),
        "source_size": list(original_size),
        "crop_box": list(crop_box) if crop_box else None,
        "crop_id": args.crop_id or None,
        "layout_plan": workspace_relative(workspace_path(args.layout_plan, args.workspace_root.resolve()),
                                           args.workspace_root.resolve()) if args.layout_plan else None,
        "protected_boxes": [list(box) for box in protected_boxes],
        "output_size": [args.width, args.height],
        "scale_x": scale_x,
        "scale_y": scale_y,
        "locale": args.locale,
        "region": args.region,
    }
    result["operation_record"] = workspace_relative(write_record(output, result), args.workspace_root.resolve())
    return result


def place_command(args: argparse.Namespace) -> dict:
    paths, output, _ = prepare_paths([args.base, args.overlay], args.output, args.workspace_root)
    base_path, overlay_path = paths
    root = args.workspace_root.resolve()

    with Image.open(base_path) as opened:
        opened.load()
        source_info = dict(opened.info)
        base = ImageOps.exif_transpose(opened).convert("RGBA")
    with Image.open(overlay_path) as opened:
        opened.load()
        oriented = ImageOps.exif_transpose(opened)
        require("A" in oriented.getbands(), "overlay has no alpha channel; provide a transparent asset")
        alpha_extrema = oriented.getchannel("A").getextrema()
        require(alpha_extrema[0] < 255, "overlay alpha is fully opaque; provide a transparent asset")
        overlay = oriented.convert("RGBA")

    plan, prior_placed_boxes = load_usable_layout_for_place(args.layout_plan, base_path, root)
    matches = [item for item in plan["placement_plan"] if item["id"] == args.placement_id]
    require(len(matches) == 1, f"placement-id is not uniquely defined by the layout plan: {args.placement_id}")
    require(matches[0]["role"] == args.asset_role, "placement role does not match asset-role")
    if args.asset_role == "prop":
        require(str(matches[0].get("asset_id", "")).strip() == str(args.asset_id).strip(), "prop asset-id does not match committed layout slot")
        require(str(matches[0].get("asset_version", "")).strip() == str(args.asset_version).strip(), "prop asset-version does not match committed layout slot")

    baseline = None
    baseline_file = root / "project/baselines/asset-placement.json"
    if args.asset_role in {"logo", "icon", "prop"}:
        require(bool(args.asset_id), "logo/icon/prop placement requires --asset-id so asset identity and project baselines remain traceable")
        data = placement_baseline.load(baseline_file)
        baseline = placement_baseline.resolve(data, args.asset_id, args.asset_role, args.region or "global", base.size)
    elif args.asset_id:
        require(False, "--asset-id is only used for logo/icon/prop placement")

    if baseline:
        target_box = tuple(baseline["bbox"])
        if args.baseline_version:
            require(str(args.baseline_version).lstrip("v") == str(baseline["version"]),
                    "baseline-version does not match the current project placement baseline")
        effective_align = baseline["anchor"] if baseline["anchor"] != "proportional" else "center"
        baseline_source = "project"
        baseline_version = baseline["version"]
        baseline_region = baseline["baseline_region"]
    else:
        require(not args.baseline_version, "baseline-version supplied but no matching project placement baseline exists")
        target_box = tuple(matches[0]["content_bbox"])
        effective_align = matches[0].get("alignment") if args.asset_role=="logo" else args.align
        baseline_source = "generic"
        baseline_version = None
        baseline_region = None

    protected_boxes=[(tuple(box),"high","cli") for box in args.protected_box]
    protected_boxes.extend((tuple(item["bbox"]),item["importance"],item["id"]) for item in plan["protected_areas"])
    invalid_protected=[list(box) for box,_,_ in protected_boxes if box[2]>base.width or box[3]>base.height]
    require(not invalid_protected, f"protected boxes exceed base bounds: {invalid_protected}")

    x1, y1, x2, y2 = target_box
    require(x2 <= base.width and y2 <= base.height, "target box exceeds base image bounds")
    width, height = x2 - x1, y2 - y1
    content_bbox = overlay.getchannel("A").getbbox()
    require(content_bbox is not None, "overlay has no visible pixels")
    overlay = overlay.crop(content_bbox)
    base_scale = min(width / overlay.width, height / overlay.height)
    # A confirmed project baseline already represents the approved visual size. Generic ICON placement
    # keeps the source 0.82 safe-fill rule; a project baseline must not be shrunk again by that fallback.
    safe_fill_ratio = 1.0 if baseline else (GENERIC_ASSET_SAFE_FILL if args.asset_role in {"icon","logo","prop"} else 1.0)
    max_fill_ratio = 1.0 if baseline else (0.92 if args.asset_role in {"icon","prop"} else 1.0)
    scale = min(base_scale * safe_fill_ratio, base_scale * max_fill_ratio)
    target_width = max(1, round(overlay.width * scale))
    target_height = max(1, round(overlay.height * scale))
    if args.asset_role == "icon" and not baseline:
        # Preserve aspect ratio. For ordinary icons, the limiting axis should not collapse below 35% of the frame.
        width_fill = target_width / width
        height_fill = target_height / height
        require(width_fill >= 0.35 and height_fill >= 0.35, "icon is too small for its content bbox; review the placement box or source asset")
        require(width_fill <= 0.92 + 1e-9 and height_fill <= 0.92 + 1e-9, "icon exceeds the 92% safe content fill")
    if args.asset_role == "prop" and not baseline:
        limiting_fill=max(target_width/width,target_height/height)
        require(abs(limiting_fill-GENERIC_ASSET_SAFE_FILL)<=0.01, "generic prop must use the 0.82 normalized safe-fill")
    overlay = overlay.resize((target_width, target_height), Image.Resampling.LANCZOS)

    if args.asset_role == "logo" and not baseline:
        require(effective_align in {"top-left","top-right"}, "generic LOGO must use a top-left/top-right layout candidate")
        min_logo_width=max(1,round(base.width*250/1080))
        require(target_width>=min_logo_width, f"generic LOGO width must be at least {min_logo_width}px on this canvas")
        margin=round(min(base.width,base.height)*0.04)
        target_y=margin
        target_x=margin if effective_align=="top-left" else base.width-margin-target_width
    elif effective_align == "top-left":
        target_x, target_y = x1, y1
    elif effective_align == "top-right":
        target_x, target_y = x2 - target_width, y1
    elif effective_align == "bottom-left":
        target_x, target_y = x1, y2 - target_height
    elif effective_align == "bottom-right":
        target_x, target_y = x2 - target_width, y2 - target_height
    else:
        target_x = x1 + (width - target_width) // 2
        target_y = y1 + (height - target_height) // 2

    placed_box = (target_x, target_y, target_x + target_width, target_y + target_height)
    require(box_contains(target_box, placed_box), "placed asset must remain inside the selected layout candidate box")
    require(not any(boxes_intersect(placed_box,box) for box in prior_placed_boxes), "placed asset overlaps an earlier asset from the same layout plan")
    overlaps=[(box,importance,pid) for box,importance,pid in protected_boxes if boxes_intersect(placed_box,box)]
    high=[list(box) for box,importance,_ in overlaps if importance=="high"]; require(not high,f"placed asset collides with high protected areas: {high}")
    medium=[pid for _,importance,pid in overlaps if importance=="medium"]
    if medium:
        approval=(args.overlap_approval or "").strip(); require(approval,"medium protected-area overlap requires explicit user approval")
        request_text=(request_root_from_work(output,root)/"request.md").read_text(encoding="utf-8")
        require(approval in request_text,"medium protected-area approval evidence is not present in request.md")
    base.alpha_composite(overlay, (target_x, target_y))
    save_image(base, output, source_info)
    placement_group=str(matches[0].get("group","")).strip() if args.asset_role=="prop" else ""
    placement_slot=matches[0].get("slot") if args.asset_role=="prop" else None
    result = {
        "status": "success",
        "operation": "place",
        "base": workspace_relative(base_path, args.workspace_root.resolve()),
        "base_sha256": sha256_file(base_path),
        "overlay": workspace_relative(overlay_path, args.workspace_root.resolve()),
        "overlay_sha256": sha256_file(overlay_path),
        "output": workspace_relative(output, args.workspace_root.resolve()),
        "output_sha256": sha256_file(output),
        "content_bbox": list(content_bbox),
        "target_box": list(target_box),
        "layout_plan": workspace_relative(workspace_path(args.layout_plan, args.workspace_root.resolve()),
                                           args.workspace_root.resolve()),
        "placement_id": args.placement_id,
        "placed_box": list(placed_box),
        "scale": scale,
        "safe_fill_ratio": safe_fill_ratio,
        "align": effective_align,
        "protected_box_count": len(protected_boxes),
        "protected_boxes": [{"bbox":list(box),"importance":importance,"id":pid} for box,importance,pid in protected_boxes],
        "overlaps": [{"id":pid,"importance":importance} for _,importance,pid in overlaps],
        "overlap_approval": (args.overlap_approval or None) if medium else None,
        "asset_role": args.asset_role,
        "asset_id": args.asset_id or None,
        "asset_version": args.asset_version,
        "placement_group": placement_group or None,
        "placement_slot": placement_slot,
        "locale": args.locale,
        "region": args.region,
        "baseline_source": baseline_source,
        "baseline_file": "project/baselines/asset-placement.json" if baseline else None,
        "baseline_version": baseline_version,
        "baseline_region": baseline_region,
        "baseline_target_box": list(target_box) if baseline else None,
    }
    result["operation_record"] = workspace_relative(write_record(output, result), args.workspace_root.resolve())
    return result


def doctor_command() -> dict:
    base = Image.new("RGBA", (64, 64), (20, 30, 40, 255))
    overlay = Image.new("RGBA", (16, 8), (255, 100, 20, 160))
    overlay = overlay.resize((24, 12), Image.Resampling.LANCZOS)
    base.alpha_composite(overlay, (20, 26))
    buffer = io.BytesIO()
    base.save(buffer, format="PNG")
    buffer.seek(0)
    with Image.open(buffer) as check:
        check.load()
        require(check.size == (64, 64), "in-memory save/open check failed")
        require(check.mode == "RGBA", "alpha mode check failed")
    require(boxes_intersect((0, 0, 10, 10), (5, 5, 15, 15)), "collision check failed")
    require(not boxes_intersect((0, 0, 10, 10), (10, 10, 15, 15)), "non-collision check failed")
    mapped=_map_box([100,200,300,400],(0.5,0.5,0.0,0.0),500,500,"doctor-layout")
    require(mapped==[50,100,150,200], "layout geometry inheritance check failed")
    return {
        "status": "ready",
        "tool": "image_postprocess",
        "pillow_version": pillow_version,
        "capabilities": [
            "workspace-bounded-output", "same-ratio-resize", "protected-approved-crop",
            "verified-alpha-placement", "protected-box-collision", "hash-operation-record",
            "layout-plan-schema-and-source-guard", "single-blueprint-geometry-inheritance",
        ],
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("doctor", help="run an in-memory Pillow and algorithm self-test")

    layout = subparsers.add_parser("validate-layout", help="validate a reviewed layout plan against its source pixels")
    layout.add_argument("--plan", required=True)
    layout.add_argument("--require-usable", action="store_true")
    layout.add_argument("--require-title-zone", action="store_true")
    layout.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])

    resize = subparsers.add_parser("resize", help="resize an image without implicit ratio changes")
    resize.add_argument("--input", required=True)
    resize.add_argument("--output", required=True)
    resize.add_argument("--width", type=int, required=True)
    resize.add_argument("--height", type=int, required=True)
    resize.add_argument("--layout-plan", help="reviewed layout plan containing the approved crop")
    resize.add_argument("--crop-id", help="approved_crops id from the layout plan")
    resize.add_argument("--protected-box", type=parse_box, action="append", default=[], help="repeatable protected bbox as x1,y1,x2,y2")
    resize.add_argument("--locale", default="")
    resize.add_argument("--region", default="")
    resize.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])

    place = subparsers.add_parser("place", help="place a transparent LOGO, ICON, UI, or prop in an approved box")
    place.add_argument("--base", required=True)
    place.add_argument("--overlay", required=True)
    place.add_argument("--output", required=True)
    place.add_argument("--layout-plan", required=True, help="reviewed usable layout plan")
    place.add_argument("--placement-id", required=True, help="placement_plan id from the layout plan")
    place.add_argument("--protected-box", type=parse_box, action="append", default=[], help="repeatable protected bbox as x1,y1,x2,y2")
    place.add_argument("--overlap-approval", default="", help="exact user text authorizing a medium protected-area overlap")
    place.add_argument("--align", choices=["center", "top-left", "top-right", "bottom-left", "bottom-right"], default="center")
    place.add_argument("--asset-role", choices=["logo", "icon", "ui", "prop"], required=True)
    place.add_argument("--asset-id", default="", help="stable project asset identity; required for LOGO/ICON/prop")
    place.add_argument("--asset-version", required=True)
    place.add_argument("--locale", default="")
    place.add_argument("--region", default="")
    place.add_argument("--baseline-version", default="")
    place.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        if args.command == "doctor":
            result = doctor_command()
        elif args.command == "validate-layout":
            result = validate_layout_command(args)
        elif args.command == "resize":
            result = resize_command(args)
        else:
            result = place_command(args)
    except (PostprocessError, OSError) as exc:
        print(json.dumps({"status": "blocked", "reason": str(exc)}, ensure_ascii=False, indent=2))
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
