# 商店图专项生产规范

## 1. 定位

`store_artwork` 是直接生产 App Store / Google Play 商店转化图的 `new-generation` 内部视觉变体。它负责把已知真实产品卖点转成单张可交付商店图，不负责从零发散整套 Store 包装策略；整套方向探索、图序策划、每卖点多方向比较进入 `$wxian-visual-packaging`。

商店图不是普通截图加标题，也不是把 KV 裁成竖图。每张图必须有唯一转化职责、唯一主证明和可见证据。

## 2. 五类职责

`work/requirement-lock.md` 在 `visual_variant: store_artwork` 时必须额外锁定：

```text
store_artwork_role: first-screen-conversion|gameplay|worldbuilding|character|selling-point
store_sequence_position: standalone|1|2|3|4|5|6|7|8|9|10
store_claim: <这一张唯一要证明的真实卖点>
```

### first-screen-conversion｜首图转化图

目标：承担首屏最大说服力，让用户在缩略图和短停留内知道“这是什么、为什么值得点进或下载”。

必须：
- 只保留一个最强钩子，不把所有卖点塞进首图；
- 第一焦点同时承载题材/品质/核心差异中的至少两项；
- 画面即使去掉说明性小字，核心吸引仍成立；
- 若标题存在，标题与主体互相证明，不做与画面无关的营销口号；
- 优先高辨识主体、强轮廓、强动作/关系、清晰空间，不默认做普通游戏截图。

失败：首图像普通截图；主体很小；信息超过一个阅读层级；只展示角色但不形成产品钩子；用虚假玩法制造噱头。

### gameplay｜玩法商店图

目标：让用户一眼理解“玩家实际做什么、面对什么、操作/决策后发生什么”。

必须先锁真实玩法事实：

```text
gameplay_truth_source: current_reference|project_material|project_brief|approved_concept|user_confirmed_rule
gameplay_truth_evidence: <Workspace 相对路径或原文证据>
gameplay_truth_approval: <仅 approved_concept 必填；用户选择/自动授权原话>
gameplay_truth_analysis: <当 gameplay_truth_evidence 是视频时必填；指向已验证 video-analysis.md>
gameplay_reference_frame: <当 gameplay_truth_evidence 是视频时必填；指向同一视频的 validated representative frame>
gameplay_action: <玩家执行的核心动作/决策>
gameplay_visible_result: <画面中必须能看见的结果/反馈>
```

生产链必须写成：

```text
真实玩法事实
→ 玩家体验动词
→ 决策/操作
→ 对象/阻力
→ 可见反馈
→ 结果/爽点
→ 商店图定帧
```

画面优先表现“行为正在发生”或“结果刚刚成立”的决定性瞬间，而不是角色站在玩法场景里摆 Pose。可以电影化强化视角、光影、动作、空间和反馈，但不得改变核心规则、交互关系、胜负条件、资源逻辑、UI 含义或真实可达结果。

若真实玩法参考是当前图片/截图，`reference-plan.json` 必须把对应源标成 `role=gameplay + analysis=gameplay-lock + use=must_upload`。若用户直接给 Gameplay 视频，不要求用户截图：在当前 request 内调用 `$wxian-video-source-analysis`，原视频仍写入 `gameplay_truth_evidence`，并额外锁定其已验证 `gameplay_truth_analysis` 与一张 `gameplay_reference_frame`；`gameplay_action / gameplay_visible_result` 必须逐字对应视频 `evidence.json` 中的已验证 Observation。图片模型实际上传该代表帧，并以 `role=gameplay + analysis=gameplay-lock + use=must_upload` 进入 Reference Plan。项目已有玩法资料使用 `project_material`；如果该项目资料本身是视频，也执行同一视频证据链。Project Brief 已明确写明的玩法事实可用 `project_brief`，证据必须是其中真实原文；只有文字规则且由用户在当前 request 明确确认时，才允许 `user_confirmed_rule`，证据原话必须存在于 `request.md`。

当本 request 先调用 `$sicza-game-concept-lab` 从零设计玩法时，只能在用户已选择该方向，或原始需求明确授权自动收敛为最终制作方向后使用 `approved_concept`。`gameplay_truth_evidence` 指向当前 request `work/` 内已确认概念产物，`gameplay_truth_approval` 必须保存能在 `request.md` 找到的选择/授权原话；未经确认的 provisional Prototype 不得作为商店宣传事实。

失败：只看题材猜玩法；把竞品玩法替换角色后当成我方玩法；为了“更刺激”新增不存在的操作、敌人、奖励或 UI；动作、玩法 UI 与结果互不对应；标题说玩法 A、画面证明玩法 B。

### worldbuilding｜世界观商店图

目标：证明世界、环境、生存状态、时代/文化或核心幻想，使用户理解“我将进入怎样的世界”。

必须：地标/环境机制/人物行为至少两者形成因果；场景参与叙事，不做空背景；主体尺度和镜头服务世界感；不借世界观图暗示不存在的玩法。

失败：只有风景；角色只是站景；世界元素互相冲突；画面像概念设定图但没有产品卖点。

### character｜角色商店图

目标：证明角色幻想、身份、关系、阵营、能力或收藏价值。

必须：锁身份锚点；用动作、关系、表情、能力结果或角色间冲突体现卖点；角色不能只是排排站；若展示能力，必须与真实角色能力/设定一致。

失败：只放大脸；角色身份漂移；为了冲击改武器/服装/能力；角色图与游戏本身没有关系。

### selling-point｜卖点商店图

目标：证明一个明确功能/系统/成长/社交/收集/建造/活动等奖励卖点。

必须：`store_claim` 是可被画面证明的具体事实；画面至少包含“被展示对象 + 用户行为/关系 + 可见收益/结果”中的两项；真实 UI/道具/奖励需要真实资产时走后处理，不让生成模型伪造。

失败：标题是空泛价值词；卖点没有视觉证据；系统卖点被画成纯氛围 KV；用不存在的奖励或功能做转化。

## 3. 单张结构

每张 `store_artwork` 的 `visual-requirement.md` 必须明确：

- 平台、画幅、目标尺寸、地区；
- `store_artwork_role` 与 `store_sequence_position`；
- `store_claim`；
- 第一眼焦点；
- 被证明的对象；
- 证明机制；
- 决定性瞬间；
- 主体动作/关系；
- 玩法/UI/系统证据；
- 标题、主体、UI、品牌的阅读顺序；
- 缩略图下仍必须成立的元素；
- 裁切和多语言安全区；
- 与项目 KV / ICON / LOGO / Baseline 的继承项；
- 禁止虚构项。

玩法商店图还必须逐项写 `gameplay_action / gameplay_visible_result / gameplay_truth_evidence`；事实源是视频时再写 `gameplay_truth_analysis / gameplay_reference_frame`。

## 4. 构图与镜头

商店图先解决转化，再解决电影感。

- 首图：一个超级焦点，强轮廓和强对比，信息密度最低。
- 玩法图：优先玩家视角、肩后、斜俯/斜仰、广角近距或能读清操作关系的空间结构；镜头不能牺牲玩法关系。
- 世界观图：优先前中远景和人物尺度对比，让地标/环境机制参与叙事。
- 角色图：优先角色关系、能力结果和身份锚点，不默认居中半身站姿。
- 卖点图：优先“对象—行为—收益”可读性，必要时使用真实 UI 作为证据层，但 UI 不能吞掉主视觉。

任何构图都要在缩略图下测试第一焦点、主体轮廓和标题层级。复杂背景不等于高级；如果缩小后主体、玩法或卖点证据消失，构图失败。

## 5. 文案与证据一致

标题只能放大已被画面证明的事实，不能替代画面证明。`copy=none` 时商店图仍必须靠画面完成核心卖点；不得为了“像商店图”自行补营销标题。

标题、UI、数值、奖励、功能名、角色能力和玩法结果均受真实性约束。无法证实时删掉，不得补全。

## 6. 与其他 Skill 的边界

- “直接做一张玩法商店图” → 当前 Skill，`image-generation → new-generation → store_artwork → gameplay`。
- “先规划整套 Store 图序/每张卖点/多方向” → `$wxian-visual-packaging`。
- “从零想玩法，再做商店图” → 当前 request 内先调用 `$sicza-game-concept-lab` 形成 provisional 玩法方向；用户确认后才可转成正式玩法事实，最终仍由本 Skill 生产。
- “评价现有商店套图” → `$wxian-visual-scorecard` 的 Store Scorecard。
- “研究竞品 Store 表现” → `$wxian-visual-competitive-analysis`，必要时辅助 `$wxian-conducting-internet-research`。

## 7. 失败门禁

以下任一成立不得进入生成 API：

- `store_artwork_role` 缺失或非法；
- `store_claim` 为空；
- `store_sequence_position` 缺失或非法；
- `gameplay` 职责缺 `gameplay_truth_source / gameplay_truth_evidence / gameplay_action / gameplay_visible_result`；`approved_concept` 还缺 `gameplay_truth_approval`；
- `current_reference` 的玩法证据不在当前 request input；图片证据未以 `gameplay + gameplay-lock + must_upload` 进入 reference plan；
- 玩法证据是视频，但未通过 `$wxian-video-source-analysis` 验证，或 `gameplay_action / gameplay_visible_result` 不对应已验证 Observation，或代表帧不属于同一视频且未以 gameplay must_upload 进入 Reference Plan；
- `user_confirmed_rule` 的证据原话不存在于当前 `request.md`；
- `project_material` 指向不存在或未被项目索引授权的文件；
- Prompt / Visual Requirement 与锁定 `store_claim` 或玩法事实冲突。

## 8. 快速自查

| 检查项 | 通过标准 | 失败处理 |
|---|---|---|
| 路由 | 直接成图=`wxian-image-production`；方向策划=`wxian-visual-packaging` | 路由错误先纠正，不继续生产 |
| 单张职责 | 五类职责中只锁一个 | 无法判断时只补问这一张主要证明什么 |
| 唯一卖点 | `store_claim` 具体、真实、可被画面证明 | 空泛口号改成可见事实 |
| 玩法真实性 | 有真实来源、动作、可见结果；视频来源有 Hash+时间线+代表帧 | 缺证据直接 BLOCK |
| 画面证明 | 主体/动作/UI/结果共同证明同一卖点 | 删除与卖点无关元素，重建因果链 |
| 第一眼 | 缩略图仍能识别焦点与卖点 | 放大主证据、降低同级信息 |
| 决定性瞬间 | 画面处于行为或结果最有说服力的时刻 | 拒绝站桩、无事件截图 |
| 文案一致 | 标题只放大画面已证明事实 | 文案与画面不一致则返 Visual Requirement |
| 真实资产 | LOGO/UI/奖励/道具按真实素材职责处理 | 不让模型伪造正式资产 |
| 裁切安全 | 目标平台、比例、多语言后仍保住主证据 | 重新布局/扩图，不硬裁核心信息 |
| 虚假宣传 | 不新增不存在玩法、功能、奖励、角色能力 | 无证据内容删除 |
