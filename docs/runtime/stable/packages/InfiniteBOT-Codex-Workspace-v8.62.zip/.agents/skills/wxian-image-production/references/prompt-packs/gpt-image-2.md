# GPT Image Family Prompt Pack

用于当前 Workspace `gpt` API Profile（GPT Image 2 与 GPT Image 2.5 Sunburst/Flare）的自然语言生成/编辑。模型与参数事实以 API Runtime 为准；本文件只定义共享语义编译。

## 1. Generate

推荐顺序：

```text
Create [complete image / use case].
Primary read: [one decisive relationship/event/result].
Subject identity: [3–6 anchors]. [Action, weight, contact, gaze, expression, interaction].
World and space: [topology, scale evidence, FG/MG/BG, path/pressure].
Camera and composition: [camera position, shot size, perspective, occlusion, visual flow, negative space].
Appearance: [light logic, shadow, material response, surface history, atmosphere].
Image structure: [value hierarchy, color roles, detail-frequency budget, focus/depth].
Graphic communication: [text/logo/UI role, if applicable].
Project identity: [grammar/memory anchor].
Do not add [only task-specific high-risk additions].
```

不要照抄模板字段名；编译成自然语言。

## 2. Reference / Compose

每张 Reference 都必须有单一或明确组合职责：

```text
Use image A only for character identity: [...].
Use image B only for pose/camera/contact: [...].
Use image C only for rendering/material/color: [...].
Do not borrow from B/C: [wrong identity, costume, prop, brand, background...].
```

禁止“combine all references”或“follow the references closely”这种无边界绑定。

## 3. Edit / Iterate

首句直接说局部任务：

```text
Modify only [target change].
Change: [...].
Preserve exactly: [identity anchors + non-target composition/camera/text/logo/UI/background/light if locked].
Allow only necessary derived changes: [cloth tension, joint rotation, shadow/contact, reflection...].
Remove: [...].
Do not add: [specific contamination risks].
Expected visible result: [...].
```

“Preserve exactly”只列真正必须保护的高价值状态，不把姿势、表情、光线全部锁死到无法完成修改。

## 4. High-fidelity Character

身份先于表面细节：

`face silhouette → facial feature geometry → hair mass/partition → body proportion → costume large shapes/color blocks → signature accessory`。

新动作单独描述身体力学和接触关系；动作 Reference 不覆盖身份。

## 5. Material / Detail Quality

“高清、高精度、4K 精度”必须翻译成可观察质量目标：

- 边缘：硬/软边分布与轮廓干净度；
- 结构：部件连接、缝线、关节、装配关系清楚；
- 材质：不同表面的反射、粗糙度、微表面和磨损逻辑可区分；
- 高频：只在焦点和材质需要处存在，背景与次级区主动降频；
- 成像：焦点清楚，不用全图锐化制造“高清”。

## 6. Text / Logo

短文案可要求生成，但必须写准确文本和层级。正式 Logo、长文案、UI 数值优先真实资产后处理；不要要求模型重画已确认 Logo。

## 7. Compression Lint

Prompt 过长先删：装饰形容词、重复质量词、次级微表面、无关氛围。保留结构关系、身份、动作、空间、镜头、图形传播和 Protect。
