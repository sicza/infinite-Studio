# 需求事实与素材 Source Lock

## 唯一事实源

`work/requirement-lock.md` 是当前 request 的唯一关键需求事实源。第一条机器事实必须且只能有一个：

```text
production_branch: new-generation|image-edit|video|resize|localization|composite|postprocess-chain|visual-brief-only|prompt-only|prompt-review-only
```

API、Promote、Audit 都直接读取它；缺失、重复或非法值阻塞，不得根据已有产物反推。其余只记录会改变结果的事实：业务目标/用途/平台/地区/规格、文案状态与语言-地区映射、角色/玩法/场景/资产版本、实际使用文件、must keep/change/not、Reference 职责和无法关闭的未知。

下游视觉需求、Prompt、API 参数和后处理矩阵消费它，不各自复制需求全文。任何动作若改变已锁定的角色/资产版本、文案、语言-地区映射、画幅、目标尺寸、玩法、LOGO 策略或 must-not，必须先有用户新指令并更新 lock；不得静默漂移。

`request_type → primary_skill → production_branch` 由 `.agents/lib/request_routing.py` 与本文件首行 `production_branch` 唯一决定。`KV / ICON / LOGO / Banner / 商店图` 等载体词不得改变 Primary Routing。

若上游/用户明确给出原业务 `source_demand_type`，它只作为业务载体/视觉处理标签保留：

```text
source_demand_type: 活动配图|互动图|BANNER|弹窗|LOGO|ICON|KV|商店图
visual_variant: <visual_variant_resolver.py 的结果>
has_real_props: true|false   # 仅活动配图需要
```

`visual_variant_resolver.py` 只决定当前 `new-generation` 内的视觉处理方式，**无权修改 `request_type`、`primary_skill` 或 `production_branch`**。图像 API 在真实调用前只重新核对 `visual_variant`。互动图仍必须由 `reference-plan.json` 证明存在 `gameplay + must_upload`，否则调用前阻塞。直接做 KV/ICON/LOGO/商店成图仍属于 `image-generation → wxian-image-production → new-generation`；只有用户目标是方案、方向探索或包装策划时才进入 `wxian-visual-packaging`。

当 `visual_variant: store_artwork` 时还必须锁定：

```text
store_artwork_role: first-screen-conversion|gameplay|worldbuilding|character|selling-point
store_sequence_position: standalone|1|2|3|4|5|6|7|8|9|10
store_claim: <这一张唯一要证明的真实卖点>
```

当 `store_artwork_role: gameplay` 时额外锁定：

```text
gameplay_truth_source: current_reference|project_material|project_brief|approved_concept|user_confirmed_rule
gameplay_truth_evidence: <真实路径或原文证据>
gameplay_truth_approval: <仅 approved_concept 必填；用户选择/自动授权原话>
gameplay_action: <玩家实际做什么>
gameplay_visible_result: <操作/决策后画面必须看见什么>
```

详细执行规则读取 `store-artwork-production.md`；这些字段由 `store_artwork_gate.py` 在真实 API 调用和最终交付前硬校验。

先实际打开关键输入。当前 request 优先于项目默认资料；同层冲突才询问。

## 文案 / 地区

文案状态只用：`confirmed | missing | none`。

- `confirmed`：每个正式语言版本锁准确字符串；语言名/地区名不能替代真实文案。用户没指定首版语言时，已确认映射中有英文则默认优先英文；没有英文则直接使用已有真实语言映射，不自行翻译或额外询问。
- `missing`：不得让模型自行补节日名、营销语或品牌文字。正式首版需要该文案时只询问这一处必要信息；仅用户明确允许 preview 时可用明确标记为非最终的 placeholder，且不得进入正式候选/交付。
- `none`：不生成营销标题/说明/按钮占位；玩法成立必需的数字、符号、问号、运算符、选项和计数不按营销文案处理。
- 多语言/多地区数量或映射冲突：不猜对应关系，只询问冲突项。
- 没有画内文案但存在地区：跳过 localization 文案替换；除非用户明确 no-logo，正式 final 仍使用对应地区真实 LOGO/品牌资产。
- 无真实游戏道具素材：不得设计或交付空奖励框、图标槽、待填卡槽。标题可读性优先靠字形/层级/描边/投影/光效/材质/色彩对比解决，不默认加底板。

## 当前素材 Source Lock

`request/input/` 只保存当前需求带入的真实文件。存在文件时运行：

```text
python .agents/skills/workspace-governance/scripts/source_lock_gate.py --request <request> --sync --workspace-root .
```

脚本从真实 `input/` 自动生成并验证 `work/source-lock.json`，Agent 不重复枚举路径。这个锁只证明当前附件没有被静默忽略/替换；是否上传给模型仍由 `reference-plan.json` 的 `must_upload / visual_only / postprocess_only / forbidden_upload` 决定。`input/` 为空时脚本保持 source-lock 不存在。用户只点名项目已有角色/品牌资产而没有当前附件时，按 Project Brief、Baseline、material-index 与真实项目文件解析。

## 首版比例与目标尺寸

同时存在“首版比例”和多个目标尺寸时，正式首版优先使用与锁定比例一致的目标尺寸作为构图基准；例如比例 `1:1` 且目标有 `1920x1080 + 1080x1080`，首版按 `1:1` 构图，确认后再派生 16:9。若没有任何目标尺寸匹配已锁定比例，不自行挑一个，必须只确认“首版以哪个比例/尺寸为基准”这一处冲突。
