#!/usr/bin/env python3
"""Resolve arbitrary delivery pixels to legal model-native intermediate ratios/sizes."""
from __future__ import annotations
import argparse, json, math, sys
from pathlib import Path

LIB=Path(__file__).resolve().parents[3]/'lib'
if str(LIB) not in sys.path: sys.path.insert(0,str(LIB))
from gpt_image_contract import DEFAULT_GPT_IMAGE_MODEL, GPT_IMAGE_MODELS, size_for_ratio, validate_gpt_size

RATIOS={'1:1':1.0,'16:9':16/9,'9:16':9/16,'4:3':4/3,'3:4':3/4,'3:2':3/2,'2:3':2/3,'4:5':4/5,'5:4':5/4,'21:9':21/9}
KNOWN={
 (2796,1290):('21:9',None),(2732,2048):('4:3',None),(2688,1242):('21:9','2796x1290'),
 (2208,1242):('16:9',None),(1920,1080):('16:9',None),(1442,1080):('4:3','2732x2048'),
 (1280,800):('5:4',None),(1200,628):('16:9',None),(1290,2796):('9:16',None),
 (2048,2732):('3:4',None),(1242,2688):('9:16','1290x2796'),(1242,2208):('9:16',None),
 (1080,1920):('9:16',None),(1080,1442):('3:4','2048x2732'),(800,1280):('4:5',None),
}
class ResolveError(ValueError): pass
def require(c,m):
    if not c: raise ResolveError(m)
def nearest_ratio(w:int,h:int)->str:
    target=w/h
    return min(RATIOS,key=lambda key:abs(math.log(target/RATIOS[key])))
def gpt_size(w:int,h:int,model:str)->str:
    exact=f'{w}x{h}'
    try:
        validate_gpt_size(model,exact)
    except ValueError:
        return size_for_ratio(model,nearest_ratio(w,h))
    return exact
def resolve(w:int,h:int,gpt_model:str=DEFAULT_GPT_IMAGE_MODEL)->dict:
    require(w>0 and h>0,'width/height must be positive')
    require(gpt_model in GPT_IMAGE_MODELS,'unsupported GPT image model')
    ratio,derive=KNOWN.get((w,h),(nearest_ratio(w,h),None))
    out={'status':'resolved','target':f'{w}x{h}','gemini_size':ratio,'gpt_model':gpt_model,'gpt_size':gpt_size(w,h,gpt_model),
         'final_python_resize_required':True,'strategy':'derive_from_existing' if derive else 'model_intermediate_then_precise_resize'}
    if derive: out['derive_from']=derive
    return out
def main():
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--width',type=int,required=True); ap.add_argument('--height',type=int,required=True); ap.add_argument('--gpt-model',choices=sorted(GPT_IMAGE_MODELS),default=DEFAULT_GPT_IMAGE_MODEL); a=ap.parse_args()
    try: print(json.dumps(resolve(a.width,a.height,a.gpt_model),ensure_ascii=False,indent=2)); return 0
    except ResolveError as e: print(json.dumps({'status':'blocked','reason':str(e)},ensure_ascii=False,indent=2)); return 1
if __name__=='__main__': sys.exit(main())
