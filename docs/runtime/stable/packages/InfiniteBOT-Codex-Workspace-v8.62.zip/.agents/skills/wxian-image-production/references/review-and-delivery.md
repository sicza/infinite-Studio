# 成图硬证据检查与交付

最终阶段先读取 [formal-output-and-delivery-contract.md](formal-output-and-delivery-contract.md)。这里的职责是证明生产链和文件事实成立，不替用户做审美满意度裁判。

## 完整视觉图门禁（presentation gate）

交付前的载体呈现由机器检查，不靠人工记忆：

    # 全局选项必须写在子命令之前
    python .agents/skills/wxian-image-production/scripts/presentation_gate.py --workspace-root . lint-prompt --prompt <work/api-prompts/main.txt>
    python .agents/skills/wxian-image-production/scripts/presentation_gate.py --workspace-root . check-picture --image <交付成图>
    python .agents/skills/wxian-image-production/scripts/presentation_gate.py --workspace-root . policy

- `lint-prompt`：提示词不得把载体（ICON 等）当造图目标，也不得模拟承载画布（圆角、蒙版、四角留白）；退出码 `2` 阻断并报出命中位置与规则 id；**可复制修正句式由联网前校验（generation_api 的 require_clean_prompt）给出**，CLI 本身不生成该句式；banner/KV/LOGO 等载具词只落机器收据、不阻断。
- `check-picture`：这是一条**形状门禁**，不是载体识别器。三条同时成立即拒（退出码 `2`）：①四个角块是同一片**纯净平整**颜色；②该色在角上向内延伸 ≥5% 短边；③**四条边的中点都不是该色**（内容一直顶到画框）。它命中的是"画面被做成四角留净色、内容顶到边的板状构图"，本项目的真实事故成图（2880²，四角平整、色板占每条边 35%–55%、内容顶到四个边中点）正是此类。
- **代价边界（已实测）**：同一合取几何**也包含合法构图**——平涂背景上主体被四条边裁切（典型的大头像 ICON）、十字/加号构图、出血圆盘。它们会被一并拒绝（同一主体放在渐变/纹理背景上则放行，说明触发点是"四角恰好为同一片纯净色"）。四个在产项目 367 张真实图中，本判据命中 1 张（即事故成图本身）；上述**合法代价族** 0 命中，现实暴露有限；**若确需交付此类构图，必须改写为让主体与画框之间保持非纯净的过渡（渐变/纹理/边缘色），或由人工确认后放行**——这条代价由交付侧的提示词与 Layout 决定，不由本检测器兜底。
- **边界（显式声明，不是缺陷）**：等距留白/边框/letterbox/pillarbox/平涂背景上的居中主体**都不属于本判据**——它们会让边中点仍是背景色，因此一律放行；这类呈现由交付/Layout 评审负责，不由这个检测器负责。细于约 2% 短边的发丝边框低于角块采样下限，在范围外；且由于角块本身必须保持平整，**实体圆角蒙版的检出下限约为短边 7%**（实测合成圆角半径 6.5%–7% 起被拒，5%–6% 放行，1%–5% 放行）。真实平台圆角蒙版（iOS/Android 20%+）远在范围内。判据只回答"有没有烤入圆角承载"，不评价画面质量。
- 联网前同一契约由 `image-generation-api` 强制执行，违规提示词在网络调用前被拒。

## 硬证据

实际打开最终文件并核对：可解码；实际像素/比例/格式/Alpha；精确文字拼写与语言；实际使用的角色/LOGO/ICON/UI/道具文件版本；Reference plan 与真实 API `reference_images`；resize 是否等比或有经验证的重构；manifest 的路径/Hash/role/locale/size/active；完整新图的 pure visual 和语言×尺寸矩阵。

发现文件缺失、Hash/尺寸错误、错误资产版本、精确文案错误、Reference 输入越权、非等比拉伸或矩阵缺项时 blocked，并回最早责任层。

## 视觉判断

角色“是否更像期待”、构图重心、背景扩展自然度、LOGO/ICON 观感大小、翻译语感等进入用户确认/视觉评分；不得仅因主观分数让一个硬证据完整的交付无法完成。需要独立专业评分时调用 `$wxian-visual-scorecard`，其结论用于建议返修，不自动等于 completion gate。

## 根因回退

```text
事实/资产错误 → requirement/reference
画面因果/信息结构 → visual requirement
Prompt 解释 → prompt
单点模型缺陷 → edit/retry
比例/布局 → layout/recompose
合成/导出 → deterministic postprocess
manifest/lineage → delivery
```

`work/final-review.md` 只写：硬证据状态、阻塞项（若有）、待用户确认项（若有）、最终文件。不要复制整个需求或流程历史。

交付清单采用 [formal-output-and-delivery-contract.md](formal-output-and-delivery-contract.md) 的最小 lineage 字段；对应 mode 的 `delivery_gate.py` 必须通过后再 promote。高风险、多产物、多轮返修或状态不确定时再调用 `$wxian-delivery-audit`。
