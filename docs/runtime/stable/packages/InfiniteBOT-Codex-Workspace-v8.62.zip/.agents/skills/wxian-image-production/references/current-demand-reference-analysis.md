# 当前需求图片与视频：按职责分析

当前媒体不是项目 Baseline。目标是只提取**当前任务真正需要的证据**。

## 1. 当前图片

先运行：

```bash
python .agents/skills/wxian-image-production/scripts/request_reference_gate.py scan --request <request> --workspace-root .
```

没有当前图片：不生成空 Manifest、Index、Summary 或空分析文件。

有图片时，主 Agent 建立唯一 `work/reference-plan.json`，每张图只记录：源路径/Hash、职责、分析深度和使用方式。

```json
{"sources":[
  {"source_path":"...","source_sha256":"...","role":"character-identity","analysis":"identity-lock","use":"must_upload"},
  {"source_path":"...","source_sha256":"...","role":"composition","analysis":"full-reverse","use":"visual_only","analysis_path":"..."}
]}
```

### 分析深度

- `identity-lock`：角色图。只在 `requirement-lock.md` 锁定脸、发型、体型、服装/装备、形态、轮廓和不可漂移特征；必须把原图上传为 Reference。不要为角色垫图生成 15–30 Phrase。
- `gameplay-lock`：需求要求还原玩法时，提取当前可见机制、交互状态、UI 关系和不可虚构部分。
- `asset-lock`：道具、UI、素材等只锁定真实资产身份、使用边界和不可重绘项。
- `full-reverse`：只有借构图、镜头、视觉机制、主题或风格时调用 `$wxian-visual-reverse-analysis`。
- `none`：图片只用于对照或后处理，不需要额外视觉推理。

运行 `validate-plan`。完整反推只对 `analysis=full-reverse` 的条目做质量 Gate。

Reference 的作用必须写成“借什么、忽略什么、是否上传”。外部角色、品牌、玩法或文案不能因为在 Reference 中出现就迁入项目。

## 2. 当前视频

当前 `request/input/` 出现 Gameplay 录屏、广告、PV、实拍或其他视频，且其内容会影响当前视觉事实、玩法事实、镜头/动作或 Reference 选择时：

1. 在**当前 request** 内调用 `$wxian-video-source-analysis`；
2. 先 `prepare` 建立原视频 Hash、媒体元数据和 Overview Frames；
3. 对关键事件区间 `refine`；
4. 写并验证该视频的 `evidence.json + video-analysis.md`；
5. 下游只消费已经验证的 Observation / Inference / representative frame。

禁止让用户为了让 Agent 能分析视频而先手动截图、标注时间点或解释玩法。

### 视频与图片 Reference 的边界

- 原视频 = **truth source / temporal evidence**；
- 视频抽帧 = **derived visual evidence**；
- 只有经过视频 source manifest 验证的抽帧，才允许进入 `work/reference-plan.json`；
- 如果抽帧用于复现 Gameplay：`role=gameplay + analysis=gameplay-lock + use=must_upload`；
- 如果只借镜头/构图/色彩：按对应 role 使用，不能因为来自视频就自动变成玩法事实；
- 图片模型真实上传的是关键帧，不是把整段视频伪装成图片 Reference。

`request_reference_gate.py` 会允许且只允许 `work/video-source-analysis/**` 中有真实 source-manifest Hash 证明的派生帧进入 Reference Plan；任意放进 `work/` 的图片不能借此绕过 Source Gate。
