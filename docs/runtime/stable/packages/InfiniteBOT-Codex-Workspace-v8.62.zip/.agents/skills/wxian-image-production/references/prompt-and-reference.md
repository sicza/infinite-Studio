# Prompt 编译、Reference 分工与模型边界

## Reference 决策

Reference 身份不等于值得使用。只对实际影响当前结果的 Reference 记录：它解决什么问题、当前借什么机制、拒绝什么表层、是否必须上传。

职责包括：

- 身份：角色、LOGO、ICON、UI 或道具准确外观；
- 动作/镜头：姿态、机位、焦段感和受力；
- 构图：主体位置、层级、留白和阅读动线；
- 环境：空间、天气、建筑、地貌或氛围；
- 风格：材质、渲染、色彩、光影和完成方式；
- 玩法/UI：真实规则、布局和交互关系；
- 后处理：必须精确呈现且不能由模型重画的素材。

每张图说明 `文件 Hash / 继承什么 / 忽略什么 / 与其他 Reference 的冲突裁定 / must_upload|visual_only|forbidden_upload|postprocess_only / 为什么`。只有身份或内容必须进入模型时才上传；仅用于构图理解、竞品分析或后处理的图不混入模型输入。多个 Reference 对同一角色版本、动作、镜头或布局给出冲突信息时，必须按当前用户要求、项目权威资料、Baseline、当前任务 Reference 的顺序裁定；不能把冲突同时写入 Prompt。

当前请求图片按 `work/reference-plan.json` 进入本步骤；不存在当前图片时不创建空计划。`identity-lock / gameplay-lock / asset-lock` 的必要锚点直接进入 `requirement-lock.md`，只有 `full-reverse` 才读取完整逆向分析。Prompt Package 只记录实际上传/借用的 Reference，不重复所有未使用素材。

Baseline 实际影响当前 Prompt 的身份、品牌、相关 Family 先验与最低 Floor，在 Prompt 外通过 `baseline-consumption.json` 追溯；无关内容不进入本次记录。已有 Family 不是固定 Prompt 模板；当前需求更适合新方向时重新组织 Prompt，并记录 `novel-direction` 理由。用户当前明确要求覆盖 Floor 时记录覆盖项，不能静默改写。

## 角色一致性

权威角色图按当前画面压缩为 3–6 个高价值锚点：头部/发型轮廓、五官、体型、服装大形和主色块、标志配件、职业气质。再单独写新的动作任务。实际角色文件优先使用当前请求中用户明确提供/指定的唯一源；否则依据 `project/project-brief.md`、Baseline/素材索引和真实项目文件定位当前角色/形态的唯一权威原图。项目原始资料可位于 Workspace 任意现实目录；以 `project/material-index.json` 当前记录与 Hash 为项目素材事实源；同一角色/形态存在无法裁定的多个候选时阻塞，不得凭文件名猜。

动作 Reference 只提供动作、镜头和受力，不覆盖角色身份。旧武器、旧姿势、错误皮肤、伤痕、血污和背景元素进入忽略项。多角色分别设置锚点，不能用一句“保持一致”代替。用户指定角色且存在选定角色文件时，必须把该唯一源文件直接上传；互动玩法要求还原时，选定玩法图必须上传。项目素材不要求为了使用而复制进 request；`reference-plan.json` 可以直接引用 material-index 中 Hash 仍有效的真实项目原图。构图 Reference 默认 `visual_only`，只借结构；正式 LOGO/ICON/UI/道具为 `postprocess_only`。旧失败候选和已拒绝方向不得作为 Reference；若用户就是要编辑某张当前候选，把它作为 `base_image`。

先运行 `request_reference_gate.py validate-plan`。真实 API `reference_images` 必须与 plan 中 `must_upload` 集合完全一致；API 执行器还会二次比较，不能靠文字声明绕过。

## 参考图项目化

先提取参考原本解决的机制：玩法判断、构图骨架、信息层级、情绪张力或记忆钩子。再用本项目角色、玩法和资产重建。不得照搬竞品角色、世界观、品牌资产、专属 UI、文案和题材表层。

主体数量、画布比例、信息密度或镜头不适配时，必须先做结构性变化。无法从项目资料证明的对象不得进入 Prompt。

## Visual Spec → Prompt 编译

进入本步骤前，当前视觉方向必须已经通过 `visual-director-integration.md` 形成足够的 Visual Spec。Prompt 不再承担“边写边设计”。

编译顺序不是固定关键词表，而是按因果依赖与模型注意力组织：

1. **Task / Whole Image**：先说明生成、编辑或组合任务，以及整张图是什么；
2. **Primary Read**：第一眼必须看懂的主体关系、事件或展示结果；
3. **Identity / Protected Truth**：角色、品牌、玩法、物体、世界事实与必须保持的锚点；
4. **Performance / Interaction**：动作、重心、接触、视线、表情、道具耦合及其因果关系；
5. **World / Space**：空间拓扑、尺度、路径、前中远景、压力/可供性；
6. **Projection / Composition**：机位、景别、焦段感、透视、遮挡、主体量块、动线和负空间；
7. **Appearance**：光源逻辑、阴影/负补光、材质响应、表面历史、空气介质；
8. **Image Structure**：明暗层级、色彩角色、细节频率、静默区、局部对比；
9. **Image Formation**：焦点、景深、运动采样、镜头/光学效果，只保留真正服务画面的机制；
10. **Graphic Communication**：文案、Logo、UI、字体、图文关系和多语言安全；
11. **Identity / Memory / Series**：项目语法、记忆锚点、避免行业通用化与系列漂移；
12. **Change / Preserve / Remove / Avoid**：编辑与受控转换必须清楚收束边界。

不是每张图都要写满 12 段。简单任务可以合并，但任何会改变结果的关系不得因为“缩短 Prompt”被丢失。

### 关系优先

优先写可观察关系，而不是审美标签：

- 不写“巨物很震撼”，写人物/车辆/建筑作为比例尺、占屏关系、近远遮挡和透视如何证明体量；
- 不写“角色更有力量感”，写重心、支撑腿、肩胯扭转、手与道具接触、受力方向和对手/环境反应；
- 不写“材质高级”，写金属粗糙度、边缘磨损逻辑、皮肤/布料/金属在同一光场下的不同反射响应；
- 不写“电影感”，写相机位置、深度组织、曝光层级、焦点、运动采样和空气透视。

### Lead / Support / Suppress

从 Visual Spec 的 `channel_roles` 继承：只强化 Lead，Support 为 Lead 服务，Suppress 主动降低。禁止把所有通道同时写成“强烈、丰富、超细节”，这会制造感知拥挤。

### Prompt Lint

交付/调用前逐句反查：

`Prompt 重要名词/动作/关系 → Visual Spec → requirement / Narrative Contract / Baseline / Reference role`

找不到上游来源的内容必须删除或返回上游定义，不能在 Prompt 层临时发明。

这条禁令的边界必须写清，否则会退化成“Prompt 只能誊写上游文本”，首稿必然平庸：

- 禁止发明的是**上游事实**：新角色、新事件、新资产、新玩法、新品牌事实，以及 Visual Spec 未成立的构图主张；
- 必须完成的是**创作实现**：在已成立的方向内，把造型、材质、光线、动作受力、质感、氛围具体化到可直接生成的程度。只把上游句子原样搬进 Prompt、不承担任何创作实现，判定 Prompt 未完成；
- 载体词（ICON / LOGO / Banner / KV / 商店图 等）与圆角、蒙版、安全区模拟一律不进入 Prompt：成图必须是完整视觉图，载体呈现属于交付后处理，由 `presentation_gate.py` 机器校验。

## 模型方言

实际模型确定后只读取 `prompt-packs/` 中当前模型对应文件。`model-prompt-dialects.md` 仅保留兼容索引，不再作为完整规则源。当前 API Profile：GPT Image 读取 `prompt-packs/gpt-image-2.md`，Gemini 读取 `prompt-packs/gemini-image.md`；Prompt-only 若用户指定 ComfyUI/扩散工作流读取 `prompt-packs/comfyui-diffusion.md`，指定 Seedream 读取 `prompt-packs/seedream.md`；其他模型无专用包时读取 `prompt-packs/generic-natural-language.md`，不得猜测私有语法。

## 参数与 Prompt 分离

以下只能进入请求参数或调用记录：`api_profile`、模型、比例、像素/分辨率、质量、输出格式、Reference 文件、上传方式、输出路径、seed 和内部路径。不得写进画面 Prompt。

## P0、字体与纯净门禁

只追踪会导致任务失败的 P0：`P0 要求 → visual-requirement 中的决定 → 主 Prompt 对应语句`。记录当前执行类型、唯一主要镜头策略和理由；项目存在字体或标题字效证据时，记录来源文件、沿用项、调整项和转写后的 Prompt 语句，不能只写“项目风格字体”。Baseline Family 只提供先验，不直接复制成 Prompt。 标题不得从无关 Reference 继承厚重材质纹理、浮雕/厚重 3D 浮雕、金属块字、石雕字、过厚 bevel 或强挤压凸起等字效；只有当前项目 Baseline/用户要求明确支持时才可使用相应材质语言。

主 Prompt 不得出现比例、像素、模型、API、路径、工作流节点、产物名、确认状态、返工解释或免责声明。负向句最多三条；删除全部负向句后，完整事件、角色动作、场景分层、构图镜头、字体/文案和画风仍必须成立。专项分支的必产关系、奖励框素材触发和 P0 追踪任一缺失时返回 `visual-requirement.md` 或当前 Prompt 修改。

## 精确内容与后处理

首版必须包含需求要求的标题/营销文案设计；当 Intake/需求锁定为 `copy=none` 时直接省略营销文案；只有 `copy=confirmed` 时才加入已确认标题/营销文案。必须逐字准确的长文本、地区 LOGO、小 ICON、精确 UI 数值、奖励道具和正式品牌素材优先后处理。首版阶段不得让模型重画正式 LOGO。

若需要奖励框，描述为完整主视觉之上的独立轻量 overlay：等大、同轴、间距一致、薄边、轻阴影和透明/半透明内部；不生成真实奖励道具，也不让框体变成黑底、信息面板、场景设备或大卡片。

标题若由模型生成，只使用明确短文字和简单换行；可读性来自字形、字重、颜色对比、轻描边、轻投影和局部光效，不靠大底板。准确长文案转后期。
有正式标题且项目 Baseline/用户当前要求没有覆盖标题区时，视觉需求与主 Prompt 必须把标题设计在画面下四分之一：安全候选 `x=8%..92%, y=75%..100%`，整体视觉中心接近 `87.5%H`，同时避开主体、LOGO、玩法和平台保护区。不要把坐标数值直接塞进给模型的自然语言；转写为“底部四分之一居中、保留安全边距”的视觉语言。

## 负向约束

只关闭本图高风险偏移，例如错误角色版本、额外肢体、假 LOGO、乱码、竞品专属元素或遮挡主体。不要用通用长负向词表弥补模糊事件、动作、构图或 Reference 分工。

## 编辑 Prompt

先写改变项，再写保持项和禁止项：

- 改变：目标区域、目标内容、允许的最低限度连带变化；
- 保持：主体身份、非目标文字、构图、镜头、色彩、光影、背景、LOGO、UI、尺寸和清晰度；
- 禁止：新增对象、重画角色、改变动作、移动焦点或污染其他区域。

整体结构错误才重新生成。局部修正后必须做前后对照，不能只看新图。
