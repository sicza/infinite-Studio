# Generic Natural-language Image Prompt Pack

用于没有专用模型包、或只需要可移植 Prompt 的情况。不得猜测模型私有参数或特殊语法。

## 编译骨架

```text
[Task + Whole Image]
[Primary Read + decisive visual relationship]
[Subject identity + action/performance + interaction]
[World/space + scale + foreground/midground/background]
[Camera/projection + composition + negative space]
[Lighting/material/surface/atmosphere]
[Value/color/detail hierarchy + focus/image formation]
[Graphic communication if any]
[Project identity / memory anchor]
[Preserve / Change / Remove / Avoid when relevant]
```

输出为 1–4 个连贯自然语言段落，不输出标签云。

## 必须保真

- 关系：谁与谁、谁控制什么、什么接触什么、什么改变什么；
- 空间：前后、距离、尺度、路径、遮挡、支撑；
- 读图：第一读、第二读、谁被压低；
- 身份：3–6 个高价值锚点，而不是“same character”；
- 传播：文字/Logo/UI 与图像的层级关系；
- 编辑：改变范围与 Protect 边界。

## 压缩优先级

过长时按以下顺序删除：

`装饰形容词 → 微小表面细节 → 次级道具描述 → 非关键气氛词`

不得删除：

`Task / Primary Read / Identity / Action / Spatial Relation / Composition / Protect / Required Text-or-Asset Role`。

## 禁止

- `masterpiece / best quality / 8K / ultra detailed` 作为质量机制；
- 长 negative list；
- 精确像素坐标、API 参数、seed、steps、CFG 混入画面 Prompt；
- 同时要求所有视觉通道都“强、丰富、锐利、发光”；
- 用“cinematic”代替相机、光、深度和成像定义。
