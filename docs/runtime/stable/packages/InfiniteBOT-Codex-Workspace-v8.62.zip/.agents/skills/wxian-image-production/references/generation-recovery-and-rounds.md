# 生成轮次、候选确认与专业恢复

## 正式候选

- 每次 API 调用只生成/接收 **1 个正式候选**；不要一次请求多张再由 Agent 内部挑。
- `formal` 默认最多 3 轮；确认后的 `revision` 默认最多 2 轮。达到上限仍不可用时停止盲刷，返回最早失败层。
- `formal / validation / revision` 主视觉候选必须直接请求**所选模型的正式质量**，不要擅自用低质量预览充当正式或方向候选：Gemini=`quality=4k` + `size=<目标比例>`；`gpt-image-2` 默认 `quality=high`；GPT Image 2.5 默认 `quality=max`，用户要求 4K 时固定 `quality=xhigh`。用户显式指定官方合法的其他质量档位时按其要求执行并保留意图绑定；没有显式覆盖时必须使用上述默认。GPT Image 2/2.5 都使用官方自定义尺寸边界。当前 Profile 无法满足用户明确质量要求时不具备正式候选资格。
- 每个新候选使用独立输出文件；永不覆盖上一轮。`formal/revision` 候选必须有同名 `<image>.call.json` 证明真实图像模型网络调用、输出路径和输出 Hash；Python/Pillow/本地脚本生成的主视觉不得登记为正式候选。

调用后必须实际打开该候选，先写同名 `<image>.review.json`，再登记候选。review 是候选生产自检：

```json
{
  "subject_correct": true,
  "composition_correct": true,
  "style_matched": true,
  "placeholder_clean": true,
  "no_fake_logo_icon_text": true,
  "artifact_risk": "low | medium | high",
  "decision": "accept | retry | return_to_prompt_pack | return_to_requirement_doc | blocked",
  "reject_reason": "",
  "next_action": ""
}
```

`accept` 必须五个布尔项全为 true、artifact risk 不能是 high；其他 decision 必须写具体 reject_reason 与 next_action。主体/动作、构图和阅读顺序、项目风格、LOGO/图标/标题占位、乱码/假 LOGO/错误图标、手脚/肢体/透视/主体变形等都属于这里的可用性检查。API 成功不等于候选可用。

然后运行：

```bash
python .agents/skills/wxian-image-production/scripts/candidate_tracker.py record --request <request> --source <真实候选> --kind formal|revision --workspace-root .
```

脚本默认读取 `<image>.review.json` 并把 self-check 固化进候选历史；没有专业自检不能登记，`decision != accept` 的候选可以保留用于复盘但不能成为 confirmed source。

方向验证不是低成本抽奖：每个方向只允许 1 张真实正式质量模型候选（Gemini `quality=4k`；`gpt-image-2`=`high`；GPT Image 2.5=`max`，用户要求 4K 时=`xhigh`），并显式绑定方向 ID：

```bash
python .agents/skills/wxian-image-production/scripts/candidate_tracker.py record --request <request> --source <验证图> --kind validation --direction-id <direction_id> --workspace-root .
```

validation 与 smoke 也必须先写各自 `<image>.review.json`；方向比较只能消费已完成 self-check 的候选。只有用户明确要求低清 smoke/技术预检时才使用 `--kind smoke --direction-id <id>`；smoke 仍必须是真实模型调用，但可以低于 4K，且永远不能被 `select` 为确认母版或进入正式后处理/交付。

用户确认某一候选后：

```bash
python .agents/skills/wxian-image-production/scripts/candidate_tracker.py confirm --request <request> --candidate-id <id> --mode user|auto_authorized --evidence '<确认或授权原话>' --workspace-root .
```

之后的派生链固定为 `confirmed candidate → pure_visual_image → locale master → resize → deterministic assets`；每一级读取上一层真实 path/hash，不靠文件名或“最新文件”猜。

## Reference 防污染

- 旧错误候选、已拒绝方向、历史 correction 图默认不得作为 `reference_images`。
- 如果任务就是编辑用户明确指定的那张当前候选，把它作为 `base_image`，不是偷偷塞进 Reference。
- 构图 Reference 默认只理解结构、不上传；角色身份和明确要求还原的 gameplay Reference 必须上传；正式 LOGO/ICON/UI/道具只后处理。

## “方向认可”与旧图

用户只说“这个方向对/按这个方向继续”时，认可的是事件、构图、信息结构、氛围或视觉机制；先把被认可部分抽象回 `visual-requirement.md`，再按新 Prompt 正式生成。只要旧图仍有角色、画风、构图、玩法或质量问题，它默认 `visual_only/forbidden_upload`，不得作为 `base_image` 或 `reference_images`。只有用户明确说“在这张图上改/保留原图只改局部”时才允许作为 `base_image`，并锁定保持区与修改区。

## 角色一致性返工诊断

用户反馈“角色不像/一致性差”时不得先加词盲刷：先查 `visual-requirement/prompt` 是否有可观察身份锚点；再查 `reference-plan` 与真实 API call 是否确实上传正确角色原画；两者都正确仍失败时，检查旧错图、构图/风格 Reference、错误角色版本或互相冲突的描述是否污染输入。第二次同类失败仍未改善，必须回最早错误层重写，不继续同一 request 重采样。

## 失败恢复

先判断失败层，再选择最小但正确的修复：

- 主体不准：重做身份锚点/Reference，不要靠负向词补。
- 背景可用、角色错：保留底图，单独修主体后编辑/合成。
- 特效错：主体与特效同步修，连同边缘光、反射和材质高光一起处理，不贴孤立特效层。
- 次要角色比例/方向错：单独优化次要角色，再回整图。
- 构图太挤：先扩图创造空间，再移动/缩放可变元素，不继续往原构图堆文字。
- 字体效果不稳：反推字体 Reference 的字形/描边/阴影/发光/材质；需要扣图时可先生成干净黑底白字字形。
- 清晰度/材质不足：做保持构图、角色、动作、色彩、文字和品牌资产不变的高清精修；逐区检查轮廓/几何、脸与手部解剖、发丝、皮肤、织物、盔甲/金属、建筑透视、自然元素结构、材质高光/反射和统一光影，去除糊边、噪点、压缩涂抹和无定义填充。精修不能靠随机新增纹理伪造细节；身份、结构、文字或构图发生漂移即作废。
- 整体结构/层级/主体关系/剧情因果错：退回 visual requirement 或 Prompt 重写，不在旧 Prompt 上叠补丁。

## 远端等待状态

图像调用返回 `remote_state_unknown` 时，保留 `<output>.attempt.json` 作为已提交证据；当前轮次停在该状态，不创建同参数重复调用。HTTP 明确失败、请求结构错误等已知失败仍按最早失败层修复后进入新的调用。Seedance 查询超时继续使用原 task id。
