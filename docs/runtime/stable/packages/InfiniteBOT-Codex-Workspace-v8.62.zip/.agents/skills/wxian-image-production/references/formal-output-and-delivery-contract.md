# 正式输出与交付契约

## 首版与 pure visual

`new-generation` 的普通完整生产链：

```text
带标题/文案设计的 base_ui_text_image
→ 用户确认唯一候选
→ 以确认图为 base_image 做 pure_visual_image
→ pure_visual_image 生成各语言母版；无画内语言时直接作为 `und` 母版
→ resize / 真实 LOGO-ICON-UI-道具合成
→ final
```

除用户明确要求无文案的首版外，首版必须有需求要求的标题/文案设计；正式 LOGO/ICON/精确 UI/真实奖励资产仍由后处理加入。

`pure_visual_image` 是完整新图后处理的唯一视觉母版。`base_ui_text_image` 必须就是 `work/confirmed-candidate.json` 锁定的确认候选；pure visual 必须以该候选作为 Gemini/GPT `image_to_image_edit` 的 `base_image`，保持角色、场景、动作、构图、镜头、色彩、光影与项目风格，只清除正式后处理会重新加入的文字、LOGO、ICON、UI、奖励道具及临时标记并自然补全背景。它不能由本地裁切/Pillow伪造。`delivery_gate.py` 验证 `confirmed → pure visual` 的直接 base path/hash。

只有 `image-edit / resize / localization / composite / postprocess-chain` 这类独立分支才允许 pure visual N/A。只要 `production_branch=new-generation`，即使用户只要一张最终成品，也必须存在确认候选与 pure visual 正式源资产。

## LOGO 默认策略

除非用户明确要求最终图不加 LOGO，否则完整新图和需要品牌交付的派生 final 默认必须使用对应地区/语言的**真实项目品牌 LOGO**，且只在生成式编辑/resize 完成后做确定性合成。首版不得让模型生成真实 LOGO。默认不需要额外字段；只有用户明确 no-logo 时才在 `work/requirement-lock.md` 写这一行：

```text
final_logo: user_explicit_none | evidence: `<用户原话片段>`
```

Gate 会确认该片段真实存在于 `request.md`。`delivery_gate.py` 会沿 final 的 `.operation.json` 反向追到对应 `resized_source_image`：默认至少必须命中一条 `asset_role=logo` 的真实 placement，且 locale、asset_id、asset_version 与 operation hash 可验证；显式 no-logo 时反而不得存在 LOGO placement。`work/final-review.md` 同时核对实际 LOGO 源文件/版本/地区语言与合成记录；缺失、错版本或跨地区误用属于硬证据错误。

## 游戏道具 Prop

游戏奖励/货币/装备/宝箱等正式素材使用 `asset_role=prop`。每个 prop 必须有稳定 `asset_id + asset_version`；当前 layout 中写 `group + slot + asset_id + asset_version`，同组 slot 唯一；这些 entry 即该 final 的 prop roster。项目已有 `asset-placement` 基准时按基准 bbox；否则使用当前 `content_bbox`，按真实 Alpha bbox 等比 contain 并使用统一 `safe_fill=0.82`。每次 placement operation 记录 group/slot，Gate 重算 0.82 几何、核对 asset identity/version，并要求 final 完整覆盖该 layout 的全部 prop roster。

## 最终检查边界

最终检查首先是**硬证据审计，不是审美裁判**。硬阻塞只来自可证明的生产事实，例如：文件不存在/不可解码、Hash 不匹配、实际尺寸错误、交付矩阵缺项、精确文案错误、真实资产版本错误、Reference/API 输入与已批准计划不一致、非等比拉伸或被禁止的处理。

标题属于硬版式证据：有正式标题且无项目/用户覆盖时，当前图的 layout plan 必须有唯一 title/headline bbox，并通过 `image_postprocess.py validate-layout --require-title-zone`，默认落在 `x=8%..92%, y=75%..100%` 下四分之一安全区；存在正式项目 placement/Baseline 时改按该基准检查。标题是否“更高级/更有气质”仍是主观视觉判断，不属于 hard gate。

以下属于视觉判断或用户偏好，不得仅凭 Agent 主观评分自动阻止 release：角色“像不像期待”、构图重心是否更理想、背景扩展是否更自然、LOGO/ICON 观感大小是否满意、翻译语感是否更好。它们可以进入 `$wxian-visual-scorecard`、返修建议或用户确认项，但 **scorecard 分数不等于 completion gate**。

如果能通过硬证据证明“用了错误角色资产/错误文案/错误地区 LOGO”，这是事实错误；如果只是“脸还不够像”，属于视觉确认。

## Delivery lineage

`work/delivery-manifest.json` 每个文件只保留真正有生产意义的字段：

```json
{
  "files": [
    {
      "role": "base_ui_text_image | pure_visual_image | localized_ui_text_image | resized_source_image | final_composited_image | 其他实际交付角色",
      "locale": "en",
      "size": "1080x1080",
      "source": "requests/.../work/.../file.png",
      "sha256": "...",
      "active": true
    }
  ]
}
```

`locale` / `size` 仅在该资产有这两个维度时出现。没有图片内语言时使用 `locale="und"`，当前确认母版作为该 locale 的可追踪 source。交付验证不根据 manifest 角色猜模式，而是直接读取 `requirement-lock.md` 的 `production_branch`。

所有图片生产交付统一运行：

```bash
python .agents/skills/wxian-image-production/scripts/delivery_gate.py --request <request> --workspace-root .
```

Gate 从 `production_branch` 选择唯一契约。`new-generation` 必须证明：1 张 active base、1 张 active pure visual、每语言 1 个母版、每语言×尺寸 1 张 resized source、每语言×尺寸 1 张 final。Gemini 母版必须是真实 4K；`gpt-image-2` 默认使用 `quality=high`；GPT Image 2.5 默认 `quality=max`，用户要求 4K 时使用 `quality=xhigh`；用户显式指定的其他官方合法质量由请求意图绑定保留；GPT Image 2/2.5 尺寸都必须满足共享自定义尺寸边界。**所有有画内文字的语言母版，包括首版语言，都必须以 pure visual 为 `base_image` 执行真实 Gemini/GPT `image_to_image_edit`；`locale=und` 时 pure visual 本身就是母版，不再复制 localized 文件。** 每个 resized source 从对应语言母版的真实 resize operation 派生；每个 final 沿连续 place operation 回溯到对应 resized source。独立 `localization` 同样要求真实 image edit；`resize` 要求 resize operation；`composite` 要求 `resized_source_image → place → final`；`postprocess-chain` 组合验证这些边；`image-edit` 验证真实 Gemini/GPT edit；`video` 验证真实 Seedance task、成功状态、容器与 Hash。
