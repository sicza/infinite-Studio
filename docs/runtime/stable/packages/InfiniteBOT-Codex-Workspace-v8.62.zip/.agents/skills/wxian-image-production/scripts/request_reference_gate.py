#!/usr/bin/env python3
"""Validate a minimal reference plan against current-request and selected project images."""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, re, sys
from pathlib import Path

LIB=Path(__file__).resolve().parents[3]/'lib'
if str(LIB) not in sys.path: sys.path.insert(0,str(LIB))
from project_materials import indexed_project_source
from video_evidence import verified_video_frame
from typing import Any

class ReferenceGateError(ValueError): pass

def require(c,m):
    if not c: raise ReferenceGateError(m)

def sha256_file(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def bounded(root:Path,value:str|Path,exist=False)->Path:
    p=Path(value); p=(root/p if not p.is_absolute() else p).resolve()
    require(p==root or root in p.parents,f"path escapes Workspace: {value}")
    if exist: require(p.exists(),f"path does not exist: {value}")
    return p

def relative(root:Path,p:Path)->str: return p.resolve().relative_to(root.resolve()).as_posix()

def request_path(root:Path,value:str)->Path:
    p=bounded(root,value,True); parts=p.relative_to(root).parts
    require(len(parts)==3 and parts[0].lower()=="requests" and p.is_dir(),"request must be requests/<type>/<name>")
    return p

def reverse_gate():
    p=Path(__file__).resolve().parents[2]/"wxian-visual-baselines"/"scripts"/"baseline_gate.py"
    spec=importlib.util.spec_from_file_location("request_ref_reverse",p); require(spec and spec.loader,"reverse gate unavailable")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def allowed_source(root:Path,request:Path,source:Path)->bool:
    source=source.resolve(); req_input=(request/'input').resolve()
    if source==req_input or req_input in source.parents: return True
    if verified_video_frame(root.resolve(),request.resolve(),source): return True
    return indexed_project_source(root.resolve(),source)

def classify(root:Path,request:Path,source:Path)->str:
    if verified_video_frame(root.resolve(),request.resolve(),source): return 'derived-video-frame'
    rel=source.relative_to(root).as_posix().lower()
    tokens=set(re.split(r'[/_.\-\s]+', rel))
    if {'characters','character','角色'} & tokens: return 'character'
    if {'gameplay','game','screenshots','screenshot','玩法','截图'} & tokens: return 'gameplay'
    if {'logo','logos','icon','icons','ui'} & tokens: return 'precision-asset'
    if source==request/'input' or request/'input' in source.parents:
        try:
            parts=tuple(x.lower() for x in source.relative_to(request/'input').parts)
            if parts[:1]==('references',): return 'reference'
        except ValueError: pass
    if '/references/' in f'/{rel}/' or '/reference/' in f'/{rel}/' or '参考' in rel: return 'reference'
    return 'other'

def analysis_path_for(root:Path,request:Path,source:Path)->str:
    digest=sha256_file(source)[:12]
    return relative(root,request/'work'/'current-reference-analysis'/f'{source.stem}-{digest}.md')

def describe(root:Path,request:Path,source:Path)->dict[str,Any]:
    gate=reverse_gate(); require(source.is_file(),f"reference source is not a file: {relative(root,source)}")
    require(source.suffix.lower() in gate.IMAGE_EXTENSIONS,f"reference source is not a supported image: {relative(root,source)}")
    require(allowed_source(root,request,source),f"reference source must be current request input, verified video-derived frame, or current indexed project material: {relative(root,source)}")
    w,h=gate.inspect_image(source)
    return {'source_path':relative(root,source),'source_sha256':sha256_file(source),'source_kind':classify(root,request,source),
            'dimensions':f'{w}x{h}','source_label':source.stem,'character_id':None,
            'full_reverse_path':analysis_path_for(root,request,source)}

def scan(root:Path,request:Path)->list[dict[str,Any]]:
    gate=reverse_gate(); req_input=request/'input'; out=[]
    files=sorted({p.resolve() for p in req_input.rglob('*') if p.is_file() and p.suffix.lower() in gate.IMAGE_EXTENSIONS},
                 key=lambda p:relative(root,p).casefold()) if req_input.is_dir() else []
    for p in files: out.append(describe(root,request,p))
    return out

def validate_plan(root:Path,request:Path,exclude_paths:set[str]|None=None)->dict[str,Any]:
    excluded=set(exclude_paths or set())
    current=[item for item in scan(root,request) if item['source_path'] not in excluded]; plan_path=request/'work'/'reference-plan.json'
    if not current and not plan_path.exists():
        return {'status':'passed','source_count':0,'full_reverse_count':0,'must_upload':[]}
    require(plan_path.is_file(),"work/reference-plan.json is required when references are used")
    plan=json.loads(plan_path.read_text(encoding='utf-8')); require(isinstance(plan,dict) and set(plan)=={'sources'},"reference plan must contain sources only")
    items=plan['sources']; require(isinstance(items,list),"reference plan sources must be array")
    current_paths={s['source_path'] for s in current}; seen=set(); full=0; gate=reverse_gate(); described={s['source_path']:s for s in current}
    allowed_roles={'character-identity','gameplay','composition','style','theme','material','prop-ui','other'}
    allowed_analysis={'identity-lock','gameplay-lock','full-reverse','asset-lock','none'}
    allowed_use={'must_upload','visual_only','postprocess_only','forbidden_upload'}
    base_fields={'source_path','source_sha256','role','analysis','use'}
    for i,item in enumerate(items):
        require(isinstance(item,dict),f"sources[{i}] must be object")
        path=str(item.get('source_path','')); require(path and path not in seen,f"invalid/duplicate source: {path}"); seen.add(path)
        source=bounded(root,path,True); require(allowed_source(root,request,source),f"source is not current request input, verified video-derived frame, or indexed project material: {path}")
        src=described.get(path) or describe(root,request,source); described[path]=src
        require(item.get('source_sha256')==src['source_sha256'],f"source hash mismatch: {path}")
        role=item.get('role'); analysis=item.get('analysis'); use=item.get('use')
        require(role in allowed_roles and analysis in allowed_analysis and use in allowed_use,f"invalid role/analysis/use: {path}")
        if role=='character-identity':
            require(analysis=='identity-lock' and use=='must_upload',f"character identity must be identity-lock + must_upload: {path}")
        if role=='gameplay':
            require(analysis=='gameplay-lock' and use=='must_upload',f"gameplay reproduction reference must be gameplay-lock + must_upload: {path}")
        if role=='composition':
            require(use=='visual_only',f"composition reference is visual-understanding only by default: {path}")
        if role=='prop-ui' or src['source_kind']=='precision-asset':
            require(use=='postprocess_only',f"LOGO/ICON/UI/prop precision assets are postprocess-only: {path}")
        if analysis=='full-reverse':
            require(set(item)==base_fields|{'analysis_path'},f"full-reverse source requires analysis_path only: {path}")
            require(item['analysis_path']==src['full_reverse_path'],f"unexpected full reverse path: {path}")
            entry=dict(src); entry['analysis_path']=item['analysis_path']; entry['source_kind']='reference' if src['source_kind']=='reference' else 'other-asset'
            gate.validate_analysis(root,entry); full+=1
        else:
            require(set(item)==base_fields,f"non-full analysis source must not carry extra fields: {path}")
    missing=sorted(current_paths-seen)
    require(not missing,f"reference plan must classify every current-request image exactly once; missing: {missing}")
    must_upload=sorted(str(i['source_path']) for i in items if i.get('use')=='must_upload')
    return {'status':'passed','source_count':len(items),'current_input_count':len(current),'full_reverse_count':full,
            'identity_lock_count':sum(i.get('analysis')=='identity-lock' for i in items),
            'gameplay_lock_count':sum(i.get('analysis')=='gameplay-lock' for i in items),'must_upload':must_upload}

def main():
    ap=argparse.ArgumentParser(description=__doc__); sub=ap.add_subparsers(dest='cmd',required=True)
    for name in ('scan','validate-plan'):
        p=sub.add_parser(name); p.add_argument('--request',required=True); p.add_argument('--workspace-root',type=Path,default=Path(__file__).resolve().parents[4])
    ins=sub.add_parser('inspect'); ins.add_argument('--request',required=True); ins.add_argument('--source',required=True); ins.add_argument('--workspace-root',type=Path,default=Path(__file__).resolve().parents[4])
    a=ap.parse_args()
    try:
        root=a.workspace_root.resolve(); req=request_path(root,a.request)
        if a.cmd=='scan': result={'status':'ready','sources':scan(root,req)}
        elif a.cmd=='inspect': result={'status':'ready','source':describe(root,req,bounded(root,a.source,True))}
        else: result=validate_plan(root,req)
        print(json.dumps(result,ensure_ascii=False,indent=2)); return 0
    except (ReferenceGateError,OSError,json.JSONDecodeError,ValueError) as e:
        print(json.dumps({'status':'blocked','reason':str(e)},ensure_ascii=False,indent=2)); return 1
if __name__=='__main__': sys.exit(main())
