# Seedream Prompt Pack

用于 Prompt-only 的 Seedream 类图片模型。当前 Workspace Generation API 未因此新增 Seedream 执行能力；执行能力以实际 Runtime 为准。

## 编译重点

保持一张完整画面的自然语言叙述，优先：

`完整场景 → 主体身份 → 当前动作/状态 → 场景关系 → 构图/镜头 → 光影/色彩 → 材质/氛围 → 项目视觉方向 → 保护/禁止`。

重点写清画面叙事与场景关系，不堆 tag。

## 结构

```text
A complete [image type/use case] showing [primary read / event].
[Subject identity and exact action/interaction].
[Environment and spatial relationship, scale evidence].
[Camera position, shot size, perspective, foreground/midground/background].
[Lighting logic, color roles, materials, atmosphere].
[Value/detail hierarchy, focus, project visual identity].
[Text/logo/UI relation if needed].
Preserve [...]; do not add [...].
```

## 边界

- 角色、玩法、世界事实必须来自上游；
- “电影感/超现实/高级”必须落到可观察视觉机制；
- 参数、分辨率、seed、工作流字段不写进主 Prompt；
- 编辑任务仍用明确 `change / preserve / remove / avoid`，不靠长负向词表。
