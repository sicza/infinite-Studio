# 尺寸适配、保护区与精确合成

## 当前图像测量

从实际像素识别并记录：画布宽高、主体/脸/手/武器/接触动作 bbox、标题/LOGO/UI/道具 bbox、平台遮罩、可延展背景和阅读顺序。坐标使用左上原点 `(x1,y1,x2,y2)`，满足 `0 ≤ x1 < x2 ≤ width`、`0 ≤ y1 < y2 ≤ height`。

资产按 Alpha 非透明内容 bbox 判断视觉边界，不按透明画布外框判断。confirmed candidate 完成一次 Layout Analysis 后，换语言不重新测量；同构图等比 resize / 批准裁切由脚本变换既有 bbox。只有 AI expand/recompose 等真正改变构图几何的操作才重新测量一次。

## 尺寸策略

按适用条件选择以下五类策略：

- `scale_only`：源/目标比例一致，等比高质量缩放，`scale_x == scale_y`。
- `safe_crop`：只有轻微变比且经当前图保护区验证不损失关键内容时可用。
- `padded_fit`：不能裁切/扩图且用户或渠道明确接受留边/纯色/模糊边/画中画时使用；默认只属于 preview/internal，不得冒充正式投放比例适配。
- `pillow_background_extend`：只用于用户明确接受的预览/非正式背景补边；不得生成真实场景细节，也不得默认进入正式商店图、投放图或活动图。
- `ai_expand_then_precise_crop` / `recompose_safe`：纯裁切会破坏保护区或明显横竖版转换时的正式默认；先由图像模型得到目标比例中间图，再由确定性 resize 精确到目标像素。

明显比例变化不能默认中心裁切；若不用 AI/recompose，必须有用户明确接受 preview/padded 结果，或有可复现证据证明 `safe_crop` 不损失任何关键元素且结果仍是完整正式画面。禁止非等比拉伸、用模糊/镜像/纯色边冒充真实背景扩图、用 Pillow crop 冒充生成式外扩、把任务 ID 当作扩图结果。多尺寸各自重新判断保护区，不从一个错误裁切继续派生。

Resize 不再额外生成 `resize-record.md`。策略由 `resize_resolver.py` 结果、AI `.call.json`（如有）、最终 `.operation.json` 与对应 layout plan 共同证明；只有出现用户特批裁切/留边等非默认决策时才把原话记录进 `requirement-lock.md`。目标比例不同且无法无损保留高优先级保护区时走 AI 扩图或重新构图。

模型中间比例必须由脚本解析，不能把 `1200×628`、`2796×1290` 等业务像素或任意小数比例直接塞给 API：

```bash
python .agents/skills/wxian-image-production/scripts/resize_resolver.py --width <W> --height <H> --gpt-model <实际 GPT 模型>
```

Resolver 优先使用明确映射（如 `1200×628→16:9`、`2796×1290→21:9`、`1280×800→5:4`，以及 2688×1242/1442×1080/1242×2688/1080×1442 的母版派生关系），其他尺寸才选择最近合法 Gemini ratio；同时给出 GPT 横/竖/方 model-native size。模型结果始终只是中间稿，最终像素仍由确定性 resize/crop 保证。

保护区按源语义分级：`P0` 绝对保护（主角脸/角色身份、核心动作、主标题/CTA、LOGO、关键图标、语言文字区、关键道具）；`P1` 尽量保护（主体身体、重要道具、副标题、信息框边缘）；`P2` 可优先牺牲（普通背景、边缘装饰、无信息留白、暗角）。裁切必须完整包含 P0、尽量保留 P1、优先牺牲 P2；生成式适配后再次检查非扩展区域、保护区与阅读顺序。禁止非等比拉伸、模糊边冒充正式扩画布、切断肢体/武器、让平台遮罩盖住关键信息。

## 术语边界

`ICON` 默认指 App / 游戏启动图标，是独立品牌资产或独立 ICON 任务；当前画面奖励框/道具框里要放的图片称为**游戏道具/prop**，不能因为旧需求叫“图标”就把 App ICON 当道具贴入。没有真实游戏道具素材时不生成空奖励框、图标槽或待填卡位。

## 精确资产合成

LOGO、ICON、UI 和道具优先使用当前请求明确提供的真实资产；否则依据项目 Brief/Baseline/素材索引，从 `project/material-index.json` 定位 Hash 仍有效的唯一当前源文件。Baseline 只规定当前资产 ID、地区/语言范围和 placement 规则，不保存可合成文件。**除非用户明确要求不加 LOGO，否则所有最终交付图默认必须使用对应地区/语言的项目品牌 LOGO**；地区/语言有值时必须选择其唯一匹配版本，不能换用其他地区、历史文件或 Reference 图里的 LOGO。多候选、版本冲突或找不到时阻塞。所有资产必须具有正确状态和原生透明 Alpha。处理顺序：

```text
验证源资产可读与 Alpha
→ 计算 Alpha 内容 bbox
→ 等比缩放
→ 根据阅读顺序和保护区选位置
→ 检查画布边界、平台遮罩和已有元素
→ Alpha composite
→ 放大检查边缘、色边和清晰度
→ 缩略检查视觉权重与阅读顺序
```

目标 bbox 不得越界。与保护区的碰撞按可见 Alpha 区域判断；资产已有时不重复叠加。同一构图的 LOGO/ICON/UI/prop 在 confirmed Layout Blueprint 中一次规划，所有 locale 共享；连续 `place` 以及确定性 resize/crop 由脚本沿 `.call.json/.operation.json` 证明几何 lineage 并映射槽位，不重复做整图 Layout 分析。

ICON 与游戏 prop 都按真实 Alpha bbox 等比 contain；无项目 placement baseline 时默认 `safe_fill_ratio=0.82`。ICON 保留 35%–92% 的通用视觉占用检查；prop 以 limiting-axis 0.82 作为统一归一尺度，极端长宽比仍保持原比例。同一 prop 组用 `group + slot + asset_id + asset_version` 锁定具体素材与顺序，slot 唯一；项目 placement baseline 命中时使用已确认 bbox，不再叠加通用 0.82 缩放。LOGO 无项目基准时同样使用 0.82 safe-fill。

每次合成记录底图/素材/输出 Hash、语言、地区、资产 ID/版本、Baseline 来源/文件/版本、Alpha `content_bbox`、目标 bbox、实际 bbox、scale、对齐方式、保护区和碰撞结果；prop 额外记录 `placement_group + placement_slot`。LOGO/ICON/prop 都传稳定 `asset-id`；脚本在真正放置前自动解析项目基准：当前地区优先，未命中才回退 `global`。项目基准命中后使用其已确认 bbox/anchor/scale policy，并只把通用安全区当冲突检查；若基准越界或碰撞，不得静默回退通用值。相同画布直接复用；允许缩放的基准按其 scale policy 解析到目标画布。LOGO 默认在左上/右上候选中根据阅读和保护区选择；无项目 placement 覆盖时，角落放置使用约 `4% × min(canvas_w, canvas_h)` 的安全边距，并保持上边距=对应左/右边距；若所选安全区不支持等距则回到 layout 判断，不硬贴。1080×1080 的约 40px 规则是这一通用比例的近似。不得添加矩形底板、卡片或容器。

完整新图的资产矩阵与 lineage 以 [formal-output-and-delivery-contract.md](formal-output-and-delivery-contract.md) 为准，并由 `delivery_gate.py` 验证；每个语言/地区 × 尺寸只能有一个 active final。

真实奖励道具保持形状、颜色、文字和版本准确。底图可以由模型生成框体、接触阴影、辉光与环境承托，但正式 prop 本体由确定性 Alpha 合成加入。每个 prop layout entry 写 `group + slot + asset_id + asset_version`，用于固定具体真实素材、同组顺序和唯一槽位；正式 final 必须完成该 layout 中全部已承诺 prop 槽位。

确定性处理只使用当前请求或项目证据目录中的输入，输出先进入当前请求 `work/`，且不覆盖旧文件。脚本参数中的所有 bbox 都是 `(x1,y1,x2,y2)`：

```powershell
python .agents/skills/wxian-image-production/scripts/image_postprocess.py resize --input <源图> --output <work输出> --width <像素> --height <像素> [--layout-plan <已验证计划> --crop-id <批准裁切ID>]
python .agents/skills/wxian-image-production/scripts/image_postprocess.py place --base <底图> --overlay <透明素材> --output <work输出> --layout-plan <已验证计划> --placement-id <放置ID> --asset-role <logo|icon|ui|prop> --asset-id <稳定资产ID> --asset-version <版本> [--locale <语言>] [--region <地区>]
python .agents/skills/wxian-image-production/scripts/placement_baseline.py record --asset-id <ID> --asset-role <logo|icon|prop> --region <地区|global> --canvas <WxH> --bbox <x1,y1,x2,y2> --anchor <top-left|top-right|bottom-left|bottom-right|center|proportional> --scale-policy <exact_canvas|scale_with_canvas_width|proportional_canvas> --source-request <request> [--update]
```

每次成功处理同时生成 `<输出文件>.operation.json`；下一步和最终 manifest 必须读取其中的输入/输出 Hash、实际 bbox、scale、语言、地区和资产版本，不得人工改写记录。

## 验收

终检比较源图与结果：非目标区域是否漂移、主体比例是否变化、裁切是否破坏事件、文字是否准确、资产是否清晰、Alpha/边缘是否干净、位置是否合理、是否重复、阅读顺序是否仍成立。机器事实由 Hash/operation replay/尺寸与碰撞检查全量验证；Agent 不为同一构图的每个语言或尺寸重复做 Layout 识图。只有新构图、高风险异常或机器证据无法证明的视觉问题才重新打开对应图。
