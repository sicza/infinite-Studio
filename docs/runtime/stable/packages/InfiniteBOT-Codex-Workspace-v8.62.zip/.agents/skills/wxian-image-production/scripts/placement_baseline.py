#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path


class BaselineError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise BaselineError(message)


def baseline_path(root: Path) -> Path:
    return root / "project/baselines/asset-placement.json"


def empty_data() -> dict:
    return {"schema_version": 3, "assets": []}


def parse_canvas(text: str) -> tuple[int, int]:
    raw = text.lower().replace(" ", "")
    parts = raw.split("x")
    require(len(parts) == 2, "canvas must be WIDTHxHEIGHT")
    try:
        width, height = (int(parts[0]), int(parts[1]))
    except ValueError as exc:
        raise BaselineError("canvas must be WIDTHxHEIGHT integers") from exc
    require(width > 0 and height > 0, "canvas dimensions must be positive")
    return width, height


def parse_bbox(text: str) -> list[int]:
    try:
        vals = [int(x.strip()) for x in text.split(",")]
    except ValueError as exc:
        raise BaselineError("bbox must be x1,y1,x2,y2 integers") from exc
    require(len(vals) == 4, "bbox must be x1,y1,x2,y2")
    x1, y1, x2, y2 = vals
    require(0 <= x1 < x2 and 0 <= y1 < y2, "invalid bbox")
    return vals


def load(path: Path) -> dict:
    if not path.exists():
        return empty_data()
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise BaselineError(f"invalid asset-placement JSON: {exc}") from exc
    require(data.get("schema_version") in {2, 3} and isinstance(data.get("assets"), list),
            "invalid asset-placement baseline")
    for asset in data["assets"]:
        require(isinstance(asset, dict) and set(asset) == {"asset_id", "asset_role", "versions"},
                "asset-placement asset entry contains missing or unnecessary fields")
        require(asset["asset_role"] in {"logo", "icon", "prop"}, "asset_role must be logo, icon, or prop")
        require(isinstance(asset["versions"], list), "versions must be an array")
    return data


def save(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def find_asset(data: dict, asset_id: str, asset_role: str | None = None) -> dict | None:
    matches = [item for item in data["assets"] if item.get("asset_id") == asset_id]
    if asset_role:
        matches = [item for item in matches if item.get("asset_role") == asset_role]
    require(len(matches) <= 1, f"duplicate asset-placement identity: {asset_id}")
    return matches[0] if matches else None


def latest_version(asset: dict) -> int:
    return max((int(item["version"]) for item in asset["versions"]), default=0)


def select_version(asset: dict, region: str) -> dict | None:
    region = region or "global"
    specific = [item for item in asset["versions"] if item.get("region") == region]
    if specific:
        return max(specific, key=lambda item: int(item["version"]))
    default = [item for item in asset["versions"] if item.get("region") == "global"]
    if default:
        return max(default, key=lambda item: int(item["version"]))
    return None


def scaled_bbox(version: dict, target_canvas: tuple[int, int]) -> list[int]:
    source_canvas = version.get("canvas")
    bbox = version.get("bbox")
    require(isinstance(source_canvas, list) and len(source_canvas) == 2 and all(isinstance(x, int) and x > 0 for x in source_canvas),
            "baseline version has invalid canvas")
    require(isinstance(bbox, list) and len(bbox) == 4 and all(isinstance(x, int) for x in bbox),
            "baseline version has invalid bbox")
    sw, sh = source_canvas
    tw, th = target_canvas
    x1, y1, x2, y2 = bbox
    policy = version.get("scale_policy")
    anchor = version.get("anchor")

    if (sw, sh) == (tw, th):
        result = [x1, y1, x2, y2]
    elif policy == "exact_canvas":
        raise BaselineError("project placement baseline is exact-canvas and does not match current canvas")
    elif policy == "proportional_canvas":
        sx, sy = tw / sw, th / sh
        result = [round(x1 * sx), round(y1 * sy), round(x2 * sx), round(y2 * sy)]
    elif policy == "scale_with_canvas_width":
        factor = tw / sw
        bw = round((x2 - x1) * factor)
        bh = round((y2 - y1) * factor)
        left = round(x1 * factor)
        right = round((sw - x2) * factor)
        top = round(y1 * factor)
        bottom = round((sh - y2) * factor)
        if anchor == "top-left":
            result = [left, top, left + bw, top + bh]
        elif anchor == "top-right":
            result = [tw - right - bw, top, tw - right, top + bh]
        elif anchor == "bottom-left":
            result = [left, th - bottom - bh, left + bw, th - bottom]
        elif anchor == "bottom-right":
            result = [tw - right - bw, th - bottom - bh, tw - right, th - bottom]
        elif anchor == "center":
            cx = round(((x1 + x2) / 2) * factor)
            cy = round(((y1 + y2) / 2) * factor)
            result = [cx - bw // 2, cy - bh // 2, cx - bw // 2 + bw, cy - bh // 2 + bh]
        else:
            # Non-corner placements should use proportional_canvas explicitly.
            raise BaselineError("scale_with_canvas_width requires a stable anchor")
    else:
        raise BaselineError("unsupported placement baseline scale_policy")

    require(0 <= result[0] < result[2] <= tw and 0 <= result[1] < result[3] <= th,
            "project placement baseline resolves outside current canvas; review/update the baseline instead of falling back silently")
    return result


def resolve(data: dict, asset_id: str, asset_role: str, region: str, canvas: tuple[int, int]) -> dict | None:
    asset = find_asset(data, asset_id, asset_role)
    if not asset:
        return None
    version = select_version(asset, region)
    if not version:
        return None
    return {
        "asset_id": asset_id,
        "asset_role": asset_role,
        "requested_region": region or "global",
        "baseline_region": version["region"],
        "version": int(version["version"]),
        "source_canvas": version["canvas"],
        "target_canvas": list(canvas),
        "bbox": scaled_bbox(version, canvas),
        "anchor": version["anchor"],
        "scale_policy": version["scale_policy"],
        "source_request": version["source_request"],
    }


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description="Versioned project LOGO/ICON/prop placement baseline")
    sub = ap.add_subparsers(dest="command", required=True)

    g = sub.add_parser("get", help="get the current stored source placement without target-canvas scaling")
    g.add_argument("--asset-id", required=True)
    g.add_argument("--asset-role", choices=["logo", "icon", "prop"], required=True)
    g.add_argument("--region", default="global")
    g.add_argument("--workspace-root", type=Path, default=Path.cwd())

    x = sub.add_parser("resolve", help="resolve region fallback and scale a confirmed placement to the current canvas")
    x.add_argument("--asset-id", required=True)
    x.add_argument("--asset-role", choices=["logo", "icon", "prop"], required=True)
    x.add_argument("--region", default="global")
    x.add_argument("--canvas", required=True)
    x.add_argument("--workspace-root", type=Path, default=Path.cwd())

    r = sub.add_parser("record")
    r.add_argument("--asset-id", required=True)
    r.add_argument("--asset-role", choices=["logo", "icon", "prop"], required=True)
    r.add_argument("--region", default="global")
    r.add_argument("--canvas", required=True)
    r.add_argument("--bbox", required=True)
    r.add_argument("--anchor", choices=["top-left", "top-right", "bottom-left", "bottom-right", "center", "proportional"], required=True)
    r.add_argument("--scale-policy", choices=["exact_canvas", "scale_with_canvas_width", "proportional_canvas"], required=True)
    r.add_argument("--source-request", required=True)
    r.add_argument("--evidence", required=True)
    r.add_argument("--update", action="store_true")
    r.add_argument("--workspace-root", type=Path, default=Path.cwd())
    return ap


def main() -> int:
    args = build_parser().parse_args()
    try:
        root = args.workspace_root.resolve()
        path = baseline_path(root)
        data = load(path)

        if args.command == "get":
            asset = find_asset(data, args.asset_id, args.asset_role)
            version = select_version(asset, args.region) if asset else None
            if not version:
                print(json.dumps({"status": "not_found"}, ensure_ascii=False))
                return 1
            print(json.dumps({
                "status": "found",
                "asset_id": args.asset_id,
                "asset_role": args.asset_role,
                "requested_region": args.region,
                "baseline_region": version["region"],
                "placement": version,
                "path": "project/baselines/asset-placement.json",
            }, ensure_ascii=False, indent=2))
            return 0

        if args.command == "resolve":
            item = resolve(data, args.asset_id, args.asset_role, args.region, parse_canvas(args.canvas))
            if not item:
                print(json.dumps({"status": "not_found"}, ensure_ascii=False))
                return 1
            item.update({"status": "found", "path": "project/baselines/asset-placement.json"})
            print(json.dumps(item, ensure_ascii=False, indent=2))
            return 0

        canvas = parse_canvas(args.canvas)
        bbox = parse_bbox(args.bbox)
        require(bbox[2] <= canvas[0] and bbox[3] <= canvas[1], "bbox exceeds source canvas")
        if args.anchor == "proportional":
            require(args.scale_policy == "proportional_canvas",
                    "proportional anchor requires proportional_canvas scale policy")
        if args.scale_policy == "scale_with_canvas_width":
            require(args.anchor != "proportional", "scale_with_canvas_width requires a stable anchor")

        source_request=(root/args.source_request).resolve()
        require(source_request==root or root in source_request.parents, "source-request escapes Workspace")
        request_md=source_request/"request.md"
        require(request_md.is_file(), "source-request must contain request.md")
        evidence=args.evidence.strip(); require(evidence and evidence in request_md.read_text(encoding="utf-8"), "project baseline evidence must be present in source request.md")

        asset = find_asset(data, args.asset_id)
        if asset is None:
            asset = {"asset_id": args.asset_id, "asset_role": args.asset_role, "versions": []}
            data["assets"].append(asset)
        else:
            require(asset["asset_role"] == args.asset_role, "asset_id already exists with a different role")
            require(args.update, "placement exists; use --update only after user explicitly confirms a new project baseline")

        data["schema_version"] = 3
        version = latest_version(asset) + 1
        asset["versions"].append({
            "version": version,
            "region": args.region or "global",
            "canvas": list(canvas),
            "bbox": bbox,
            "anchor": args.anchor,
            "scale_policy": args.scale_policy,
            "source_request": args.source_request,
        })
        save(path, data)
        print(json.dumps({
            "status": "recorded",
            "asset_id": args.asset_id,
            "asset_role": args.asset_role,
            "region": args.region or "global",
            "version": version,
            "path": "project/baselines/asset-placement.json",
        }, ensure_ascii=False, indent=2))
        return 0
    except (BaselineError, OSError) as exc:
        print(json.dumps({"status": "blocked", "reason": str(exc)}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
