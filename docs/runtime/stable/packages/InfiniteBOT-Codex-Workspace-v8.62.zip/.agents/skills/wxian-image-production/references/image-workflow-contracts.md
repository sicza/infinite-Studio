# 图片 / 视频分支与返修

## 新图

```text
requirement lock
→ visual requirement（复杂任务才需要）
→ prompt / reference
→ API
→ first-version review
→ user confirmation or explicit auto-continue
→ required postprocess only
→ final review
→ promote
```

首版必须先解决中心事件、主体关系、项目识别、构图和**需求要求的标题/文案设计**。当 Intake/需求锁定为 `copy=none` 时直接按纯视觉首版执行；只有 `copy=confirmed` 时才把真实标题/营销文案纳入首版设计。正式透明 LOGO、精确长文案、小 ICON、精确 UI 数值和正式品牌资产优先在确认后用真实资产/编辑完成。

主视觉候选遵守 [generation-recovery-and-rounds.md](generation-recovery-and-rounds.md)：formal 每轮 1 张最多 3 轮，revision 每轮 1 张最多 2 轮，validation 每个方向只 1 张；三者都必须是真实模型结果并独立保存（Gemini `quality=4k`；`gpt-image-2` 默认 `high`；GPT Image 2.5 默认 `max`、用户要求 4K 时 `xhigh`；用户显式指定其他官方合法质量时保留该覆盖）。未获用户明确要求时不得擅自降级为低清预览。进入后处理的候选必须写入 `work/confirmed-candidate.json`，记录 `user|auto_authorized` 确认模式与证据。连续两次同类失败优先判断上游结构，不继续盲刷。

## 图片编辑

```text
source → change / preserve → edit → before/after review → final
```

局部缺陷局部修；主体关系、构图、层级或核心视觉逻辑错误时重写/重生成受影响阶段。不能因为用户只举了一个表象问题，就默认只改一个字段。

## 独立后处理

```text
source inspection → required deterministic/generative postprocess → final review
```

只做当前必要操作。源图无法支持目标比例时才进入生成式扩图/重构。

## Seedance 视频

支持 `text_to_video`、`image_to_video_first_frame`、`image_to_video_first_last_frame`、`reference_to_video`。提交得到 task id 只代表已提交；下载到真实可读视频并完成技术/视觉检查才是候选。

## 纯视觉母版

完整 `new-generation` 生产链在首版确认后必须按 [formal-output-and-delivery-contract.md](formal-output-and-delivery-contract.md) 生成 `pure_visual_image`；它来自确认候选的图像编辑，不是重新生一张，也不是“下游需要才有”。独立 resize/localization/composite/image-edit 可按 contract 判 N/A。

## 返修

每次先写：

```text
root: 最早根因
scope: local | stage | system
action: patch | regenerate | rewrite
```

- 单点模型伪影：`patch`；
- 模型理解基本正确但需要重新采样：`regenerate`；
- 构图/层级/主体关系/视觉逻辑/Prompt 解释错误或重复失败：`rewrite` 受影响阶段。

只保留用户已经确认且不受此次根因影响的内容；不要用旧 Prompt 继续叠加补丁掩盖结构问题。


需要局部拆层、精修、字体、特效同步或候选轮次决策时读取 [generation-recovery-and-rounds.md](generation-recovery-and-rounds.md)。
