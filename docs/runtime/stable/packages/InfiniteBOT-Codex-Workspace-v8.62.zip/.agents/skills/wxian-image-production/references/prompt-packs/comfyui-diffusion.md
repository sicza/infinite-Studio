# ComfyUI / Diffusion Prompt Pack

只用于 Prompt-only 或用户明确提供本地 Workflow 的任务；当前 Workspace Generation API 不因此自动获得 ComfyUI 执行能力。

## 1. 先识别 Workflow

先确认模型家族与工作流：`FLUX / Qwen-Image / Z-Image / SDXL / specialized edit / custom checkpoint` 等，以及 Text Encoder、VAE、Sampler、Control、LoRA、Edit/Inpaint 链。

未知时只交付 Canonical Semantic Prompt，不发明 CFG/Steps/Sampler/权重语法。

## 2. 四层控制

- Semantic Prompt：主体、场景、动作、整体视觉；
- Structural Control：Pose / Depth / Edge / Line / Layout；
- Identity / Style Control：Reference / Adapter / LoRA；
- Local Edit：Inpaint / Native Edit / Img2Img。

结构风险优先交 Control，不用超长 Prompt 代替几何证据。

## 3. Semantic Prompt

沿用 `generic-natural-language.md` 的 Visual Spec 编译。若目标模型支持较强自然语言，保持完整关系句；只有当前模型/Tokenizer 明确需要 tag-like conditioning 时才做有证据的转换。

## 4. Negative

先确认 Workflow 是否存在有效 Negative Conditioning。需要时只写当前任务具体失败风险；不使用通用“bad anatomy, worst quality...”长表。

## 5. A/B 与可复现

Project Baseline 应保存：`model / workflow / prompt / seed / resolution / controls / loras / key exposed params / output / known failure`。测试一个变量时尽量固定其他变量。

## 6. 失败路由

- Prompt 语义正确但构图错 → 查结构 Control / Workflow；
- 身份每个 seed 漂移 → 建 Identity Reference/LoRA/Approved Anchor；
- Style Control 破坏角色 → 分离 Style 与 Identity；
- 局部编辑污染全图 → 收紧 Mask/Edit mode 与 Preserve，而不是加更多负词。
