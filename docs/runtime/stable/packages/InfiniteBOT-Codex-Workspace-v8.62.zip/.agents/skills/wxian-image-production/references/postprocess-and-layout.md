# 布局、本地化与后处理

## Layout plan

首版候选确认后立即对 **confirmed candidate 只做一次完整视觉 Layout Analysis**，写：

`work/layout/confirmed/layout-plan.json`

这份 plan 是当前构图的唯一 Layout Blueprint。它一次性记录首版英文/原始语言文字真实位置、其他语言复用的文字区域、LOGO 候选与最佳侧、游戏 prop 框数量与每个 slot 的坐标、主体保护区、可延展背景和批准裁切。pure visual、语言替换和同构图尺寸派生只消费这份 Blueprint，不再次让 Agent 看同一构图。

字段：

```text
source_path / source_sha256 / canvas / coordinate_system
protected_areas / text_areas / placement_plan
extendable_background / approved_crops / status / review
```

`coordinate_system=xyxy-top-left`。

`protected_areas[]`：`id/role/bbox/confidence/evidence/importance`，其中 `importance=high|medium|low`：

- high：不得覆盖；
- medium：只有当前用户明确同意覆盖时可用；
- low：必要时可轻微覆盖，operation 必须记录。

`placement_plan[]` 基础字段：`id/role/frame_bbox/content_bbox/confidence/evidence`。LOGO 额外写 `alignment=top-left|top-right`；prop 额外写 `group + slot + asset_id + asset_version`，同组 slot 从 1 起且唯一；这些 prop entry 是当前 final 的已承诺真实资产槽位。无项目 placement baseline 时同时评估顶部左右两个 LOGO 候选。

置信度：`>=0.90` 明确；`0.70–0.89` 可用；`0.50–0.69` needs_review；`<0.50` unusable。`status=usable` 的实际 placement 必须 `confidence>=0.70`。

图标 `content_bbox` 通常相对 `frame_bbox` 内缩约 8%–18%，装饰边越厚内缩越大。

运行：

```bash
python .agents/skills/wxian-image-production/scripts/image_postprocess.py validate-layout \
  --plan <layout-plan.json> --require-usable --workspace-root .
```

默认标题安全区为 `x=8%..92%, y=75%..100%`；没有项目标题基准且需要正式标题时加 `--require-title-zone`。

## 本地化

锁定目标文字、语言/地区、大小写、标点、换行、阅读方向、字体意图和平台限制。只修改目标文字及必要排版区域；主体、构图、品牌资产、非目标文字、色光和画布尺寸保持不变。

文案变长时依次尝试：换行/字距 → 合理缩字号 → 扩大文字区域但不侵入保护区 → 返回版式重构。不得压扁字体或删改文案。

正式 `localized_ui_text_image` 使用 Gemini/GPT `image_to_image_edit`；call record 必须记录真实 `base_image` 路径/Hash 与输出路径/Hash，源和 localized 画布尺寸一致。Pillow/本地文字覆盖只用于 preview/work draft。

## LOGO / ICON / UI / 道具

项目 placement baseline 优先；没有基准时使用当前 layout plan。

通用 LOGO：

- 同时评估 top-left / top-right；
- 最终上边距与对应侧边距均为画布短边约 4%；
- 等比缩放，最大尺寸不超过候选安全区约 82%；
- 透明 Alpha 必须保留；
- high 保护区不可覆盖；medium 需要当前用户明确批准；low 可轻微覆盖并记录。

ICON：等比 contain，默认安全填充 `0.82`。

Prop：奖励/货币/装备/宝箱等使用真实 Alpha 素材；每个 slot 绑定稳定 `asset_id + asset_version`。项目 placement baseline 优先；无基准时以当前 `content_bbox` 为槽位，真实 Alpha bbox 等比 contain，统一 `safe_fill=0.82`。同组通过 `group + slot` 保持顺序与唯一性；Gate 要求 final 实际 placement 与该 layout 中全部 prop 槽位的 `group/slot/asset_id/asset_version` 完全一致。

所有正式合成使用真实项目/request 素材；生成模型只负责底图/框体，不重画正式 LOGO/ICON/UI/prop。confirmed Layout Blueprint 对同一构图的全部 locale 共用：语言 edit 画布不变时坐标恒等继承；确定性 resize/crop 由脚本按 operation lineage 数学映射 bbox；连续 `place` 继续复用同一 plan。只有尺寸变化来自 AI expand/recompose、导致画布/构图几何改变时，才建立该新构图的一份新 plan。
