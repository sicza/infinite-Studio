#!/usr/bin/env python3
"""Validate store_artwork role, claim, and gameplay truth before generation/delivery."""
from __future__ import annotations
import argparse, json, re, sys
from pathlib import Path

LIB=Path(__file__).resolve().parents[3]/'lib'
if str(LIB) not in sys.path:
    sys.path.insert(0,str(LIB))
from project_materials import indexed_project_source
from video_evidence import VIDEO_EXTENSIONS, analysis_dir_from_path, relative, validate_evidence

class StoreArtworkError(ValueError):
    pass

ROLES={'first-screen-conversion','gameplay','worldbuilding','character','selling-point'}
POSITIONS={'standalone',*(str(i) for i in range(1,11))}


def require(cond: bool, message: str) -> None:
    if not cond:
        raise StoreArtworkError(message)


def field(text: str, name: str, required: bool=True) -> str:
    matches=re.findall(rf'(?im)^\s*{re.escape(name)}:\s*([^\n#]+?)\s*$',text)
    if required:
        require(len(matches)==1,f'{name} must exist exactly once in requirement-lock.md')
    elif len(matches)>1:
        raise StoreArtworkError(f'{name} must not be repeated in requirement-lock.md')
    return matches[0].strip() if matches else ''


def bounded(root: Path, value: str) -> Path:
    p=(root/Path(value)).resolve() if not Path(value).is_absolute() else Path(value).resolve()
    require(p==root or root in p.parents,'gameplay evidence path escapes Workspace')
    return p


def plan_sources(request: Path) -> list[dict]:
    p=request/'work/reference-plan.json'
    require(p.is_file(),'gameplay image reference requires work/reference-plan.json')
    try:
        data=json.loads(p.read_text(encoding='utf-8'))
    except json.JSONDecodeError as exc:
        raise StoreArtworkError(f'invalid reference-plan.json: {exc}') from exc
    sources=data.get('sources',[]) if isinstance(data,dict) else []
    require(isinstance(sources,list),'reference-plan.json sources must be a list')
    return [x for x in sources if isinstance(x,dict)]


def require_gameplay_plan_entry(root: Path, request: Path, image_path: Path) -> str:
    rel=relative(root,image_path)
    matching=[x for x in plan_sources(request) if str(x.get('source_path','')).strip()==rel]
    require(len(matching)==1,'gameplay reference frame/image must appear exactly once in reference-plan.json')
    require(matching[0].get('role')=='gameplay' and matching[0].get('analysis')=='gameplay-lock' and matching[0].get('use')=='must_upload',
            'gameplay reference must be role=gameplay + analysis=gameplay-lock + use=must_upload')
    return rel


def validate_video_truth(root: Path, request: Path, source: Path, analysis_value: str, frame_value: str,
                         action: str, result: str) -> dict:
    require(bool(analysis_value),'video gameplay truth requires gameplay_truth_analysis')
    require(bool(frame_value),'video gameplay truth requires gameplay_reference_frame')
    analysis_path=bounded(root,analysis_value)
    require(analysis_path.is_file() and analysis_path.name=='video-analysis.md',
            'gameplay_truth_analysis must point to the validated video-analysis.md')
    analysis_dir=analysis_dir_from_path(root,request,analysis_path)
    try:
        evidence=validate_evidence(root,request,analysis_dir)
    except Exception as exc:
        raise StoreArtworkError(f'video gameplay evidence validation failed: {exc}') from exc
    require(evidence.get('source_path')==relative(root,source),'video analysis is not bound to gameplay_truth_evidence source')

    observations=list(evidence.get('observations',{}).values())
    require(any(item.get('type')=='gameplay_action' and str(item.get('fact','')).strip()==action for item in observations),
            'gameplay_action must exactly match a validated video gameplay_action observation')
    require(any(item.get('type') in {'gameplay_visible_result','ui_feedback','gameplay_state'} and str(item.get('fact','')).strip()==result for item in observations),
            'gameplay_visible_result must exactly match a validated video result/feedback observation')

    frame=bounded(root,frame_value)
    require(frame.is_file(),'gameplay_reference_frame file is missing')
    frame_rel=relative(root,frame)
    require(frame_rel in evidence.get('representative_frames',[]),
            'gameplay_reference_frame must be a validated representative frame from the same video analysis')
    require_gameplay_plan_entry(root,request,frame)
    return {
        'analysis_path': relative(root,analysis_path),
        'reference_frame': frame_rel,
        'video_observation_bound': True,
    }


def validate(root: Path, request: Path, *, require_visual_requirement: bool=True) -> dict:
    lock=request/'work/requirement-lock.md'
    require(lock.is_file(),'work/requirement-lock.md is required')
    text=lock.read_text(encoding='utf-8')

    source_type=field(text,'source_demand_type',required=False)
    variant=field(text,'visual_variant',required=False)
    if source_type!='商店图' and variant!='store_artwork':
        return {'status':'not_applicable'}
    require(source_type=='商店图','store_artwork requires source_demand_type: 商店图')
    require(variant=='store_artwork','source_demand_type: 商店图 requires visual_variant: store_artwork')

    role=field(text,'store_artwork_role')
    position=field(text,'store_sequence_position')
    claim=field(text,'store_claim')
    require(role in ROLES,f'illegal store_artwork_role: {role}')
    require(position in POSITIONS,f'illegal store_sequence_position: {position}')
    require(bool(claim) and claim.lower() not in {'none','unknown','n/a','na','待定','未知'},'store_claim must be one concrete verified claim')

    gameplay={}
    if role=='gameplay':
        truth_source=field(text,'gameplay_truth_source')
        evidence=field(text,'gameplay_truth_evidence')
        action=field(text,'gameplay_action')
        result=field(text,'gameplay_visible_result')
        analysis_value=field(text,'gameplay_truth_analysis',required=False)
        frame_value=field(text,'gameplay_reference_frame',required=False)
        require(truth_source in {'current_reference','project_material','project_brief','approved_concept','user_confirmed_rule'},f'illegal gameplay_truth_source: {truth_source}')
        require(all(x and x.lower() not in {'none','unknown','n/a','na','待定','未知'} for x in (evidence,action,result)),'gameplay truth evidence/action/result must be concrete')

        video_binding={}
        if truth_source=='current_reference':
            p=bounded(root,evidence)
            require(p.is_file(),'current_reference gameplay evidence file is missing')
            request_input=(request/'input').resolve()
            require(request_input in p.parents,'current_reference gameplay evidence must be inside current request input/')
            if p.suffix.lower() in VIDEO_EXTENSIONS:
                video_binding=validate_video_truth(root,request,p,analysis_value,frame_value,action,result)
            else:
                require(not analysis_value and not frame_value,'gameplay_truth_analysis/reference_frame are only allowed when gameplay evidence is video')
                require_gameplay_plan_entry(root,request,p)
        elif truth_source=='project_material':
            p=bounded(root,evidence)
            require(p.is_file(),'project_material gameplay evidence file is missing')
            require(indexed_project_source(root,p),'project_material gameplay evidence is not a current indexed project material')
            if p.suffix.lower() in VIDEO_EXTENSIONS:
                video_binding=validate_video_truth(root,request,p,analysis_value,frame_value,action,result)
            else:
                require(not analysis_value and not frame_value,'gameplay_truth_analysis/reference_frame are only allowed when gameplay evidence is video')
        elif truth_source=='project_brief':
            require(not analysis_value and not frame_value,'video analysis fields are not allowed for project_brief truth')
            brief=root/'project/project-brief.md'
            require(brief.is_file(),'project_brief gameplay truth requires project/project-brief.md')
            require(evidence in brief.read_text(encoding='utf-8'),'project_brief gameplay evidence must exist verbatim in project/project-brief.md')
        elif truth_source=='approved_concept':
            require(not analysis_value and not frame_value,'video analysis fields are not allowed for approved_concept truth')
            p=bounded(root,evidence)
            require(p.is_file(),'approved_concept gameplay evidence file is missing')
            require((request/'work').resolve() in p.parents,'approved_concept gameplay evidence must be inside current request work/')
            approval=field(text,'gameplay_truth_approval')
            request_text=(request/'request.md').read_text(encoding='utf-8') if (request/'request.md').is_file() else ''
            require(approval in request_text,'approved_concept gameplay_truth_approval must exist verbatim in request.md')
        else:
            require(not analysis_value and not frame_value,'video analysis fields are not allowed for user_confirmed_rule truth')
            request_text=(request/'request.md').read_text(encoding='utf-8') if (request/'request.md').is_file() else ''
            require(evidence in request_text,'user_confirmed_rule evidence must exist verbatim in request.md')
        gameplay={'truth_source':truth_source,'evidence':evidence,'action':action,'visible_result':result,**video_binding}
        if truth_source!='approved_concept':
            require(not field(text,'gameplay_truth_approval',required=False),'gameplay_truth_approval is only allowed for approved_concept')
    else:
        for extra in ('gameplay_truth_source','gameplay_truth_evidence','gameplay_truth_approval','gameplay_action','gameplay_visible_result','gameplay_truth_analysis','gameplay_reference_frame'):
            require(not field(text,extra,required=False),f'{extra} is only allowed when store_artwork_role=gameplay')

    if require_visual_requirement:
        vr=request/'work/visual-requirement.md'
        require(vr.is_file(),'store_artwork requires work/visual-requirement.md')
        vtext=vr.read_text(encoding='utf-8')
        require(claim in vtext,'visual-requirement.md must explicitly preserve the locked store_claim')
        require(role in vtext,'visual-requirement.md must explicitly preserve store_artwork_role')
        if role=='gameplay':
            require(gameplay['action'] in vtext,'visual-requirement.md must explicitly preserve gameplay_action')
            require(gameplay['visible_result'] in vtext,'visual-requirement.md must explicitly preserve gameplay_visible_result')

    return {
        'status':'passed',
        'store_artwork_role':role,
        'store_sequence_position':position,
        'store_claim':claim,
        **({'gameplay':gameplay} if gameplay else {})
    }


def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--request',required=True)
    ap.add_argument('--workspace-root',type=Path,default=Path(__file__).resolve().parents[4])
    ap.add_argument('--skip-visual-requirement',action='store_true')
    a=ap.parse_args()
    try:
        root=a.workspace_root.resolve()
        request=(root/a.request).resolve()
        require(request==root or root in request.parents,'request path escapes Workspace')
        require(request.is_dir(),'request directory missing')
        out=validate(root,request,require_visual_requirement=not a.skip_visual_requirement)
        print(json.dumps(out,ensure_ascii=False,indent=2))
        return 0
    except (StoreArtworkError,OSError,ValueError) as exc:
        print(json.dumps({'status':'blocked','reason':str(exc)},ensure_ascii=False,indent=2))
        return 1

if __name__=='__main__':
    sys.exit(main())
