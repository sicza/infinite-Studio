#!/usr/bin/env python3
"""Prove the live image runtime preserves IP Mother References as provider inputs.

This command is intentionally offline and side-effect free.  It executes the
current generation API payload builder with a recorder in place of the
multipart writer, so the resulting evidence is bound to the exact runtime
files that would construct the provider request.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any


CONTRACT_VERSION = "1.6"
PRODUCER_ID = "wxian-image-production/provider-reference-contract-test-v3"
PROVIDERS: dict[str, dict[str, Any]] = {
    "gpt-image": {
        "api_profile": "gpt",
        "runtime_id": "wxian-image-production",
        "adapter_id": "wxian-image-production/gpt-image-reference-adapter-v3",
        "mapping_id": "gpt-image-reference-map-v3",
        "max_inputs": 16,
    },
    "gemini-nano-banana": {
        "api_profile": "gemini",
        "runtime_id": "wxian-image-production",
        "adapter_id": "wxian-image-production/gemini-reference-adapter-v3",
        "mapping_id": "gemini-reference-map-v3",
        "max_inputs": 14,
    },
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_module(path: Path, name: str) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ValueError(f"cannot load runtime module: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def request_path(root: Path, raw: str) -> Path:
    value = Path(raw)
    path = (root / value if not value.is_absolute() else value).resolve()
    if root != path and root not in path.parents:
        raise ValueError("request escapes Workspace")
    parts = path.relative_to(root).parts
    if len(parts) != 3 or parts[0].lower() != "requests" or not path.is_dir():
        raise ValueError("request must be requests/<type>/<name>")
    return path


def workspace_file(root: Path, raw: str, label: str) -> Path:
    value = Path(raw)
    if value.is_absolute():
        raise ValueError(f"{label} must be Workspace-relative: {raw}")
    path = (root / value).resolve()
    if root != path and root not in path.parents:
        raise ValueError(f"{label} escapes Workspace: {raw}")
    if not path.is_file():
        raise ValueError(f"{label} does not exist: {raw}")
    return path


def plan_order(work: Path) -> list[str]:
    path = work / "reference-plan.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    sources = data.get("sources") if isinstance(data, dict) else None
    if not isinstance(sources, list):
        raise ValueError("reference-plan.json sources must be an array")
    return [
        str(item["source_path"])
        for item in sources
        if isinstance(item, dict) and item.get("use") == "must_upload"
    ]


def run(args: argparse.Namespace) -> dict[str, Any]:
    root = args.workspace_root.resolve()
    request = request_path(root, args.request)
    work = request / "work"
    capability = PROVIDERS[args.provider]
    generation_path = root / ".agents/skills/image-generation-api/scripts/generation_api.py"
    gate_path = root / ".agents/skills/wxian-image-production/scripts/request_reference_gate.py"
    producer_path = Path(__file__).resolve()
    if not generation_path.is_file() or not gate_path.is_file():
        raise ValueError("live provider runtime dependency is missing")

    mothers = list(args.reference)
    if not mothers or len(mothers) != len(set(mothers)):
        raise ValueError("at least one unique Mother Reference is required")
    mother_paths = [workspace_file(root, value, "Mother Reference") for value in mothers]

    base_rel: str | None = args.base_image
    if args.mode == "reference_to_image":
        if base_rel:
            raise ValueError("reference_to_image must not include base_image")
        base_path = None
    else:
        if not base_rel:
            raise ValueError("image_to_image_edit requires base_image")
        base_path = workspace_file(root, base_rel, "base_image")

    api = load_module(generation_path, "provider_contract_generation_api")
    gate = load_module(gate_path, "provider_contract_reference_gate")
    excluded = {base_rel} if base_rel else set()
    gate_result = gate.validate_plan(root, request, excluded)
    required = list(gate_result.get("must_upload", []))
    missing = sorted(set(mothers) - set(required))
    if missing:
        raise ValueError("Mother References are not must_upload inputs: " + ", ".join(missing))

    ordered_plan = plan_order(work)
    provider_rel = mothers + [value for value in ordered_plan if value not in set(mothers)]
    if set(provider_rel) != set(required) or len(provider_rel) != len(required):
        raise ValueError("provider input plan does not exactly match validated must_upload inputs")
    provider_paths = [workspace_file(root, value, "provider input") for value in provider_rel]
    for path in [*provider_paths, *([base_path] if base_path else [])]:
        api.require_source_path(path, root, work)
        api.image_mime(path)
    api.validate_reference_plan_match(root, work, provider_paths, [base_path] if base_path else [])

    total = len(provider_paths) + (1 if base_path else 0)
    if total > capability["max_inputs"]:
        raise ValueError(f"provider accepts at most {capability['max_inputs']} total input images, got {total}")

    observed: list[Path] = []
    original_multipart = api.multipart

    def record_multipart(fields: dict[str, str], images: list[tuple[str, Path]]) -> tuple[bytes, str]:
        if any(name != "image" for name, _path in images):
            raise ValueError("provider payload used a non-image multipart field")
        observed.extend(path.resolve() for _name, path in images)
        return b"contract-test", "multipart/form-data; boundary=contract-test"

    api.multipart = record_multipart
    try:
        output = work / ".provider-reference-contract-test.png"
        validated = {
            "mode": args.mode,
            "model": api.CURRENT_GEMINI_IMAGE_MODEL if capability["api_profile"] == "gemini" else api.DEFAULT_GPT_IMAGE_MODEL,
            "prompt": "provider reference contract test",
            "parameters": {"size": "1:1", "quality": "4k"}
            if capability["api_profile"] == "gemini"
            else {"size": "2880x2880", "quality": "max", "background": "opaque", "moderation": "auto", "output_format": "png"},
            "output": output,
            "base_image": base_path,
            "references": provider_paths,
        }
        payload = api.gemini_payload if capability["api_profile"] == "gemini" else api.gpt_payload
        _body, content_type = payload(validated)
    finally:
        api.multipart = original_multipart

    expected_paths = ([base_path] if base_path else []) + provider_paths
    if observed != expected_paths:
        raise ValueError("live generation API did not preserve base/reference provider input order")
    if not content_type.startswith("multipart/form-data;"):
        raise ValueError("live generation API did not select multipart image transport")

    profile = {
        "base_url": "https://provider-contract.invalid/v1",
        "generation_path": "/v1/images/generations",
        "edit_path": "/v1/images/edits",
        "allow_insecure_http": False,
    }
    endpoint = api.image_endpoint(profile, validated)
    runtime_binding = {
        "producer_sha256": sha256_file(producer_path),
        "generation_api_sha256": sha256_file(generation_path),
        "request_reference_gate_sha256": sha256_file(gate_path),
    }
    return {
        "status": "PASS",
        "contract_version": CONTRACT_VERSION,
        "producer": PRODUCER_ID,
        "provider": args.provider,
        "mode": args.mode,
        "runtime_id": capability["runtime_id"],
        "adapter_id": capability["adapter_id"],
        "mapping_id": capability["mapping_id"],
        "challenge": args.challenge,
        "reference_input": {
            "slot_mode": "INTEGER_ORDER",
            "accepted_locator_types": ["LOCAL_PATH"],
            "max_inputs": capability["max_inputs"],
            "max_inputs_semantics": "TOTAL_IMAGES_INCLUDING_BASE_IMAGE",
        },
        "test_run": {
            "mode": args.mode,
            "mother_reference_paths": mothers,
            "mother_reference_sha256": [sha256_file(path) for path in mother_paths],
            "provider_workspace_paths": provider_rel,
            "observed_reference_inputs": len(provider_paths),
            "endpoint_path": "/" + endpoint.split("/", 3)[-1],
            "base_image_path": base_rel,
            "base_image_sha256": sha256_file(base_path) if base_path else None,
            "provider_input_paths": ([base_rel] if base_rel else []) + provider_rel,
            "provider_input_sha256": [sha256_file(path) for path in expected_paths],
        },
        "runtime_binding": runtime_binding,
        "network_called": False,
        "files_written": False,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--provider", required=True, choices=sorted(PROVIDERS))
    parser.add_argument("--workspace-root", required=True, type=Path)
    parser.add_argument("--request", required=True)
    parser.add_argument("--mode", required=True, choices=("reference_to_image", "image_to_image_edit"))
    parser.add_argument("--base-image")
    parser.add_argument("--reference", action="append", default=[])
    parser.add_argument("--challenge", required=True)
    args = parser.parse_args()
    try:
        result = run(args)
        code = 0
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        result = {"status": "FAIL", "reason": str(exc), "network_called": False, "files_written": False}
        code = 2
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
