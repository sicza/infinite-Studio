#!/usr/bin/env python3
"""Complete-visual presentation gate for image production.

Three machine facts, one owner:

- `lint-prompt`  : refuse an authored prompt that frames the carrier slot or
                   simulates the carrier's canvas (rounding / mask / corner field),
                   and report the non-blocking carrier receipt next to it.
- `check-picture`: refuse a delivered artwork that carries a baked carrier mask.
- `policy`       : print the single carrier policy definition and its two levels.

No provider/API calls occur here.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

AGENTS_ROOT = Path(__file__).resolve().parents[3]
LIB = AGENTS_ROOT / "lib"
if str(LIB) not in sys.path:
    sys.path.insert(0, str(LIB))

from presentation_contract import (  # noqa: E402
    PresentationError,
    lint_prompt,
    require_complete_visual_picture,
    rule_ids,
)


def bounded(root: Path, value: str, *, must_exist: bool = True) -> Path:
    candidate = Path(value)
    if not candidate.is_absolute():
        candidate = root / candidate
    resolved = candidate.resolve()
    root = root.resolve()
    if not (resolved == root or root in resolved.parents):
        raise PresentationError(f"path escapes Workspace: {value}")
    if must_exist and not resolved.is_file():
        raise PresentationError(f"file does not exist: {value}")
    return resolved


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[4])
    sub = parser.add_subparsers(dest="command", required=True)
    lint = sub.add_parser("lint-prompt")
    lint.add_argument("--prompt", required=True)
    picture = sub.add_parser("check-picture")
    picture.add_argument("--image", required=True)
    sub.add_parser("policy")
    args = parser.parse_args()
    root = args.workspace_root.resolve()
    try:
        if args.command == "policy":
            print(json.dumps({
                "status": "ready",
                "rule_ids": rule_ids(),
                "carrier_policy": {
                    "blocking": ["ICON / 图标 framing", "carrier word + crop|mask|frame|canvas|shape|ratio|tile|corner"],
                    "receipt": ["banner", "key visual", "kv", "logo", "wordmark", "store artwork/image/screenshot", "feature graphic", "screenshot"],
                },
                "presentation_simulation": "always blocking, no negation exemption",
                "provider_calls": False,
            }, ensure_ascii=False, indent=2))
            return 0
        if args.command == "lint-prompt":
            path = bounded(root, args.prompt)
            verdict = lint_prompt(path.read_text(encoding="utf-8"))
            verdict["prompt_path"] = path.relative_to(root).as_posix()
            print(json.dumps(verdict, ensure_ascii=False, indent=2))
            return 2 if verdict["status"] == "blocked" else 0
        path = bounded(root, args.image)
        observation = require_complete_visual_picture(path, label=f"delivered picture {path.name}")
        observation["status"] = "passed"
        print(json.dumps(observation, ensure_ascii=False, indent=2))
        return 0
    except (PresentationError, OSError, ValueError) as exc:
        print(json.dumps({"status": "blocked", "reason": str(exc)}, ensure_ascii=False, indent=2))
        return 2


if __name__ == "__main__":
    sys.exit(main())
