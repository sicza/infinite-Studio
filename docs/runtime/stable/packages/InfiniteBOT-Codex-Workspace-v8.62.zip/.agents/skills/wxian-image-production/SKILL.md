---
name: wxian-image-production
description: 图片与视频制作：需求锁定、视觉方案、Prompt、生成/编辑、候选确认、纯视觉、本地化、改尺寸、真实资产合成、终检和交付。
---

# 图片生产

本 Skill 作为当前 request 的 Primary 时，进入前执行 `$workspace-governance consume-personal-context --request <request> --consumer wxian-image-production`；阻断则停止。作为其他 Primary 的内部图片执行能力时，继承调用方已验证的 Primary Context；不得用 `wxian-image-production` 再次消费，也不得把辅助 API 执行伪装成第二个 Primary request。

开始或继续本 Skill 前必须通过 Workspace 视觉 preflight；`$workspace-governance` 会在 request 新建、续接、返修和 Promote 时硬执行 `workspace_init.py visual-check`。若返回 `needs_visual_baseline`，先刷新 Baseline，不得继续消费旧规则。

按当前分支/阶段渐进读取 Reference。视觉创意、诊断、改图、Prompt 或 Narrative→Visual 先读 `visual-director-integration.md`；共享内核不改变本 Skill 的 Primary/API/Promote Authority：

- 所有图片分支：`image-workflow-contracts.md`；存在当前附件时再读 `intake-and-source-lock.md`。
- `new-generation`：进入视觉决策时读 `visual-thinking-and-brief.md`；只有 Store 读 `store-artwork-production.md`；使用当前图片/视频事实时读 `current-demand-reference-analysis.md`；编 Prompt 时读 `prompt-and-reference.md`，模型确定后只读 `prompt-packs/` 中当前模型对应文件；产生、登记、确认或返修候选时读 `generation-recovery-and-rounds.md`。
- `localization / resize / composite / postprocess-chain` 以及 `new-generation` 确认后的后处理：只读 `postprocess-and-layout.md`、当前动作需要的 `resize-prompts-and-localization.md` 或 `resize-and-compositing.md`。
- 进入 manifest / Gate 前读 `formal-output-and-delivery-contract.md`；最终人工复核时读 `review-and-delivery.md`。

同一事实只在权威产物保存一次：用户原文留在 `request.md`；需求机器事实留在 `requirement-lock.md`；脚本事实留在 call/operation/manifest。下游按路径、Hash 和必要字段消费，不复制完整上游正文。

## 分支

只执行当前目标需要的分支，并把它作为 `work/requirement-lock.md` 的唯一机器事实：

`production_branch: new-generation | image-edit | video | resize | localization | composite | postprocess-chain | visual-brief-only | prompt-only | prompt-review-only`

缺失、重复或非法值直接阻塞；后续 API、Promote、Audit 都读取这一行，不根据已有文件反推。已有可用母版时不重新生成；确定性后处理不进入创意全链。`visual-brief-only`、`prompt-only`、`prompt-review-only` 在对应产物完成后停止，不调用生成 API。

## 需求锁定

新需求必须先经过 `$workspace-demand-intake`；本 Skill 不重新向用户索取已经由 Intake 锁定的公共字段，也不能把构图、镜头、创意方向等专业展开前移给用户。按 Intake Snapshot 与输入 Reference 写 `work/requirement-lock.md`。当前用户要求和当前 request input 优先；项目长期事实从 Project Brief、Baseline 和 material-index 定向读取。普通新生图尺寸缺失时沿用 Intake 默认 `1:1`；普通视觉任务文案缺失/空白即 `none`，不得因为没有文案再次追问。

`request/input/` 非空时运行 `source_lock_gate.py --sync`，由脚本按真实 input 自动生成并验证 `work/source-lock.json`；Agent 不手抄文件清单。这个锁只证明当前请求证据完整存在，不等于全部上传给模型。当前图片按职责分析：角色锁身份；玩法还原锁机制；构图/风格/主题确实借用时才完整反推。当前 request 存在 Gameplay、广告、PV、实拍等视频且它会影响视觉事实时，在本 request 内调用 `$wxian-video-source-analysis`；不得要求用户先手动截图或解释视频。

使用 Baseline 时先把它当项目视觉先验与最低线：读项目视觉画像、相关现有产出 Family、Baseline Floor 与创新空间。已有 Family 可作为起点，但不是必须复刻；当前需求更适合新方向时使用 `novel-direction`。只记录本次真实消费的 Family / Floor / Character / Reference 与用户覆盖项到 `work/baseline-consumption.json`。本 Skill 的 Primary Skill 名是 `wxian-image-production`，但 Baseline consumption 的唯一 machine key 是 `image-production`：记录必须写 `"consumer": "image-production"`，验证必须使用 `--consumer-name image-production`；不得把 Skill 名写入 machine field。随后运行 `baseline_consumption.py`。

## 视觉需求

当当前 request 的最终交付是实际图片文件，但用户明确要求先从零探索游戏概念、画风玩法、人物×场景×玩法原型或成熟 Gameplay 变异时，先在当前 request 内调用 `$sicza-game-concept-lab`。它只负责形成 PROVISIONAL Direction / Prototype Spec / Test Prompt；用户选择或原始需求已授权自动收敛后，再由本 Skill 把选定结果写入正式视觉需求并进入图片生产。不得把候选 Prototype 当作已确认 Production Truth，也不得为该前置另建 request。

若该前置能力建立长期 IP / 正式角色，必须同时接收 `work/concept-lab/ip-character-system.json`、`ip-character-binding.json`、`ip-character-preflight.json` 与实际 Provider×Mode 的 `ip-character-handoff.json`。后者必须为 `READY`；其 `image_conditioning_inputs` 按 `provider_slot_or_order` 形成 `reference_images` 的不可改序前缀，其余 `must_upload` Reference 才能续接在后。`image_to_image_edit` 的 `base_image` 只作为 edit target，不能升级为 Mother Reference。

`new-generation`、复杂编辑和需要重构的 Resize 写 `work/visual-requirement.md`。把约束分为 P0/P1/P2，并形成 `对象 → 动作/关系 → 空间 → 可见结果`。

系列图同时锁定：角色身份、场景状态、时间进度、关键道具、光线方向、镜头推进。每帧写清继承项、变化项和变化原因。

## Prompt 与 Reference

需要视觉决策的分支按 `visual-director-integration.md` 生成并验证 canonical `work/visual-spec.json`。需要模型时写 `work/prompt-package.md`；主 Prompt 只描述最终画面，不写 API 参数、路径、Hash 或工作流说明；实际模型执行前验证 `work/prompt-binding.json`。

每张 Reference 只有一个明确职责。角色身份与要求还原的 gameplay=`must_upload`；构图默认=`visual_only`；真实 LOGO/ICON/UI/道具=`postprocess_only`。视频本身是 truth source，不直接进入图片 `reference-plan.json`；经 `$wxian-video-source-analysis` 验证的代表帧可以作为 `gameplay/composition/style` 等图片 Reference，且必须保留对原视频 Hash 与时间点的证据链。生成前运行 `request_reference_gate.py validate-plan`；API 再校验真实上传集合。

存在 IP Character contract 时，先按 `$sicza-game-concept-lab` 的 `05a-ip-character-system.md` 执行 production preflight 与 Provider Handoff 编译，再构造 API request。`image-generation-api` 会验证 system/binding Hash、Provider、执行模式、Mother Reference 前缀/顺序/Hash、edit target 与 provider runtime evidence；缺文件、旧 handoff、重排或降级为 text-to-image 都会在联网前阻断。

## 模型执行

图片默认 `gemini`；Gemini 的 `text_to_image / reference_to_image / image_to_image_edit` 均可用。无参考走 `/v1/images/generations` JSON；参考图/图生图走同一 OpenAI-compatible Images 家族的 `/v1/images/edits` multipart，继续使用 `gemini-3.1-flash-image-preview`、`size=<目标比例>`、`quality=4k`。角色身份与 gameplay `must_upload` 不能因为 transport 更新而降级或改用无参考文生图。用户明确指定 GPT 或任务需要 GPT 独有能力时用 `gpt`；视频默认 `seedance`。

GPT 请求先调用 `image-generation-api resolve-gpt` 解析用户原话与比例/尺寸，并原样使用返回结果。路由：普通 GPT→Flare，image2→旧模型，image2.5→Sunburst；高清/高精度/4K/PNG/透明要求强制 Sunburst。2.5 默认 `max + PNG + opaque`，4K 改用 `xhigh`，透明底改为 `transparent`；尺寸与完整边界以 API Skill 的机器解析结果为准。

当 `video` 分支属于“静态 KV / 海报 / Banner → 5 秒剧情微动画”时，以 `execution_mode=production_video` 调用 `$wxian-kv-micro-animation`。一次读图后写入当前 request 的 `work/micro-animation/`：剧情位置、连续性、自动锁定的 Camera Level、`REFERENCE_ROLE` 与完整 Seedance Prompt；随后本 Skill 立即构造 Seedance request 并调用 `$image-generation-api`。`REFERENCE_ROLE=Start Visual` 使用 `image_to_video_first_frame`；`Story Keyframe` 使用 `reference_to_video`；存在明确首尾两张图时才使用 `image_to_video_first_last_frame`。默认 `duration=5`、`resolution=1080p`、`generate_audio=true`，画幅沿用源图。真实视频需求不在 Prompt 与 API 之间增加 Camera 确认，也不把 Prompt 当最终交付。

每轮只生成 1 个候选，不覆盖历史结果。失败按根因返回 requirement / Prompt / edit / regenerate；重复同类失败重写受影响阶段。

## 候选与确认

候选生成、review、登记、轮次上限、确认命令与失败恢复统一执行 `generation-recovery-and-rounds.md`。只有 `decision=accept` 的 formal/revision 候选可确认；进入纯视觉或正式后处理前必须已有绑定当前 request 的 `confirmed-candidate.json`。首版 `copy=none` 不得自行补营销文案，正式 LOGO 默认确认后再用真实资产合成。

## 纯视觉与派生

确认后的正式派生统一执行 `image-workflow-contracts.md`、`formal-output-and-delivery-contract.md` 与 `postprocess-and-layout.md`：完整 `new-generation` 先由 confirmed candidate 生成唯一 `pure_visual_image`，再生成 locale/resize/composite 等正式派生；真实 LOGO/ICON/UI/道具只用当前有效项目/request 资产。confirmed 构图只建立一次 Layout Plan，确定性派生按 operation lineage 映射；只有 AI expand/recompose 真正改变构图几何时才新建 Layout Plan。

## 终检与交付

实际打开最终文件。硬证据检查：需求事实、角色/玩法/项目身份、正式资产、准确文案、尺寸、比例、Alpha、Reference、调用记录、operation lineage、文件可读性。主观审美由用户或 `$wxian-visual-scorecard` 评价，不自动阻塞 completion。

生成 `work/final-review.md` 和 `work/delivery-manifest.json`。正式交付必经 `$workspace-governance promote`，由 Promote 唯一 blocking 调用 `delivery_gate.py` 并按 `production_branch` 验证确认候选、pure visual、派生链、真实 edit、Seedance task/容器或独立后处理 lineage。直接运行 `delivery_gate.py` 只用于显式诊断，不属于正常交付序列。

高风险、多产物或多轮返工时按需调用 `$wxian-delivery-audit`。
