#!/usr/bin/env python3
"""Resolve an optional legacy/business asset label to a visual treatment variant.

This resolver never selects or changes primary_skill or production_branch.
Those are owned by request_routing.py and requirement-lock.md respectively.
"""
from __future__ import annotations
import argparse, json, sys

class VariantError(ValueError):
    pass

def require(condition, message):
    if not condition:
        raise VariantError(message)

def yn(value: str) -> bool:
    x=value.strip().lower()
    require(x in {'true','false'}, 'boolean flags must be true|false')
    return x == 'true'

def norm(value: str) -> str:
    x=value.strip()
    aliases={
        'banner':'BANNER', '活动配图':'活动配图', '互动图':'互动图', '弹窗':'弹窗',
        'logo':'LOGO', 'icon':'ICON', 'kv':'KV', '商店图':'商店图', 'store':'商店图'
    }
    return aliases.get(x.casefold(), aliases.get(x, x))

def resolve(source_type: str, props: bool, gameplay_ref: bool) -> dict:
    t=norm(source_type)
    if t == '活动配图':
        variant='event_visual_with_asset_frames' if props else 'pure_visual_frame'
    elif t == '互动图':
        require(gameplay_ref, '互动图 requires a real gameplay reference before interactive_puzzle can proceed')
        variant='interactive_puzzle'
    elif t == 'BANNER':
        variant='pure_visual_frame'
    elif t == '弹窗':
        variant='popup'
    elif t == 'LOGO':
        variant='logo_artwork'
    elif t == 'ICON':
        variant='icon_artwork'
    elif t == 'KV':
        variant='kv_artwork'
    elif t == '商店图':
        variant='store_artwork'
    else:
        return {'status':'not_applicable','source_demand_type':t,'visual_variant':'auto'}
    return {'status':'passed','source_demand_type':t,'visual_variant':variant}

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--source-demand-type', required=True)
    ap.add_argument('--has-real-props', default='false')
    ap.add_argument('--has-gameplay-reference', default='false')
    args=ap.parse_args()
    try:
        print(json.dumps(resolve(args.source_demand_type, yn(args.has_real_props), yn(args.has_gameplay_reference)), ensure_ascii=False, indent=2))
        return 0
    except VariantError as exc:
        print(json.dumps({'status':'blocked','reason':str(exc)}, ensure_ascii=False, indent=2))
        return 1

if __name__ == '__main__':
    sys.exit(main())
