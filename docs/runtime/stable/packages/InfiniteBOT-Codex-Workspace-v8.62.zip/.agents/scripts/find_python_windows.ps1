$ErrorActionPreference = 'SilentlyContinue'
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'

function Test-HostRuntimePath([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path)) { return $true }
    $normalized = $Path.Replace('/', '\').ToLowerInvariant()
    $blockedFragments = @(
        '\appdata\local\microsoft\windowsapps\',
        '\windowsapps\openai.codex_',
        '\windowsapps\openai.chatgpt_',
        '\.cache\codex-runtimes\',
        '\codex-primary-runtime\'
    )
    foreach ($fragment in $blockedFragments) {
        if ($normalized.Contains($fragment)) { return $true }
    }
    return $false
}

function Test-Python([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path)) { return $false }
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $false }
    if (Test-HostRuntimePath $Path) { return $false }
    $probe = "import sys, ensurepip, pathlib, tempfile; p=pathlib.Path(tempfile.gettempdir()); raise SystemExit(0 if sys.version_info >= (3,10) and p.exists() else 1)"
    $output = & $Path '-X' 'utf8' '-c' $probe 2>&1
    if ($LASTEXITCODE -ne 0) { return $false }
    if (($output | Out-String) -match '(?i)\bCET\b|App Execution Alias') { return $false }
    return $true
}

$candidates = New-Object System.Collections.Generic.List[string]

$py = Get-Command py.exe -ErrorAction SilentlyContinue
if ($py -and -not (Test-HostRuntimePath $py.Source)) {
    $resolved = & $py.Source -3 -X utf8 -c "import sys; print(sys.executable)" 2>$null
    if ($LASTEXITCODE -eq 0 -and $resolved) { $candidates.Add(($resolved | Select-Object -First 1)) }
}

$python = Get-Command python.exe -ErrorAction SilentlyContinue
if ($python -and -not (Test-HostRuntimePath $python.Source)) { $candidates.Add($python.Source) }

$registryRoots = @(
    'HKCU:\Software\Python\PythonCore',
    'HKLM:\Software\Python\PythonCore',
    'HKLM:\Software\WOW6432Node\Python\PythonCore'
)
foreach ($root in $registryRoots) {
    foreach ($versionKey in (Get-ChildItem -LiteralPath $root -ErrorAction SilentlyContinue | Sort-Object PSChildName -Descending)) {
        $installKey = Join-Path $versionKey.PSPath 'InstallPath'
        $props = Get-ItemProperty -LiteralPath $installKey -ErrorAction SilentlyContinue
        if ($props.ExecutablePath) { $candidates.Add([string]$props.ExecutablePath) }
        $item = Get-Item -LiteralPath $installKey -ErrorAction SilentlyContinue
        if ($item) {
            $installDir = [string]$item.GetValue('')
            if ($installDir) { $candidates.Add((Join-Path $installDir 'python.exe')) }
        }
    }
}

$roots = @(
    (Join-Path $env:LOCALAPPDATA 'Programs\Python'),
    $env:ProgramFiles,
    ${env:ProgramFiles(x86)}
) | Where-Object { $_ }
foreach ($root in $roots) {
    if (-not (Test-Path -LiteralPath $root -PathType Container)) { continue }
    Get-ChildItem -LiteralPath $root -Directory -Filter 'Python3*' -ErrorAction SilentlyContinue |
        Sort-Object Name -Descending |
        ForEach-Object { $candidates.Add((Join-Path $_.FullName 'python.exe')) }
}

foreach ($candidate in ($candidates | Select-Object -Unique)) {
    if (Test-Python $candidate) {
        (Resolve-Path -LiteralPath $candidate).Path
        exit 0
    }
}
exit 1
