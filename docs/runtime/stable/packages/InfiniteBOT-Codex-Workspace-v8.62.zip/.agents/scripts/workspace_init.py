#!/usr/bin/env python3
"""Build and verify the project material fingerprint used during Workspace initialization."""

from __future__ import annotations
import os as _bytecode_guard_os, sys as _bytecode_guard_sys
_bytecode_guard_sys.dont_write_bytecode = True
_bytecode_guard_os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import argparse
import hashlib
import importlib.util
import json
import mimetypes
import sys
import os
import subprocess
import re
import zipfile
from datetime import datetime, timezone
from pathlib import Path

AGENTS_ROOT = Path(__file__).resolve().parents[1]
if str(AGENTS_ROOT / "lib") not in sys.path:
    sys.path.insert(0, str(AGENTS_ROOT / "lib"))
from asset_taxonomy import canonical_role as canonical_asset_role
from atomic_io import atomic_write_text
from text_integrity import TextIntegrityError, read_utf8
from baseline_contract import (
    BASELINE_SCHEMA,
    BASELINE_INDEX_SCHEMA,
    BASELINE_SECTION_COUNT,
    project_context_sha256 as shared_project_context_sha256,
)

try:
    from PIL import Image
except ImportError:
    Image = None


START = "<!-- managed-material-inventory:start -->"
END = "<!-- managed-material-inventory:end -->"
DEFAULT_SOURCES = (".",)
EXCLUDED_NAMES = {"project-brief.md", "material-index.md", "material-index.json", "project-visual-standard.md", "AGENTS.md"}
EXCLUDED_TOP_LEVEL = {".agents", ".codex", ".git", "requests", "user", "USER", "tmp", "__pycache__"}
EXCLUDED_ANY_DIR = {".git", "__pycache__", "node_modules", ".venv", ".cache"}
EXCLUDED_FILE_NAMES = {".DS_Store", "Thumbs.db"}
BASELINE_IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif", ".tif", ".tiff"}
RUNTIME_SUBPROCESS_TIMEOUT = 1800
API_CHECK_TIMEOUT = 60
API_KEY_GUI_TIMEOUT = 900
USER_STORE_TIMEOUT = 90



class InitError(ValueError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise InitError(message)


def workspace_path(root: Path, value: str) -> Path:
    candidate = Path(value)
    if not candidate.is_absolute():
        candidate = root / candidate
    resolved = candidate.resolve()
    require(resolved == root or root in resolved.parents, f"path escapes Workspace: {value}")
    return resolved


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def is_project_material(path: Path, root: Path) -> bool:
    rel = path.resolve().relative_to(root.resolve())
    if not rel.parts:
        return False
    if rel.parts[0] in EXCLUDED_TOP_LEVEL:
        return False
    if any(part in EXCLUDED_ANY_DIR for part in rel.parts[:-1]):
        return False
    if path.name in EXCLUDED_FILE_NAMES:
        return False
    if rel.parts[:2] == ("project", "baselines"):
        return False
    if path.name in EXCLUDED_NAMES:
        return False
    return True


def storage_role(path: Path, root: Path) -> str:
    parts = path.resolve().relative_to(root.resolve()).parts
    lowered = tuple(part.lower() for part in parts)
    # One shared asset taxonomy owns the category -> role mapping; a second copy
    # here is what let a published Baseline look stale to the other consumer.
    # The taxonomy preserves the original path segments, so the original parts must be
    # passed here; the lowercased tuple is only for the prefix decisions below.
    canonical = canonical_asset_role(parts)
    if canonical:
        return canonical
    if lowered[:2] == ("project", "references") and len(parts) >= 3:
        return f"reference:{Path(*parts[2:]).with_suffix('').as_posix()}"
    return f"source:{Path(*parts).as_posix()}"

def inspect_file(path: Path, root: Path, *, content_sha256: str | None = None) -> dict[str, object]:
    stat_result = path.stat()
    relative = path.relative_to(root).as_posix()
    mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    readable = stat_result.st_size > 0
    dimensions = ""
    if Image is not None and mime.startswith("image/"):
        try:
            with Image.open(path) as image:
                image.load()
                dimensions = f"{image.width}x{image.height}"
        except Exception:
            readable = False
    elif mime == "application/pdf":
        try:
            data = path.read_bytes()
            readable = data.startswith(b"%PDF-") and b"%%EOF" in data[-4096:]
        except OSError:
            readable = False
    elif path.suffix.lower() in {".docx", ".pptx", ".xlsx"}:
        try:
            with zipfile.ZipFile(path) as archive:
                names = set(archive.namelist())
                required = {
                    ".docx": "word/document.xml",
                    ".pptx": "ppt/presentation.xml",
                    ".xlsx": "xl/workbook.xml",
                }[path.suffix.lower()]
                readable = "[Content_Types].xml" in names and required in names
        except (OSError, zipfile.BadZipFile):
            readable = False
    elif mime.startswith("text/") or path.suffix.lower() in {".md", ".json", ".yaml", ".yml", ".csv", ".tsv"}:
        try:
            path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            readable = False
    return {
        "path": relative,
        "type": mime,
        "bytes": stat_result.st_size,
        "mtime_ns": stat_result.st_mtime_ns,
        "ctime_ns": stat_result.st_ctime_ns,
        "sha256": content_sha256 or sha256_file(path),
        "dimensions": dimensions,
        "readable": readable,
        "storage_role": storage_role(path, root),
    }


def collect(root: Path, sources: list[str], previous: list[dict[str, object]] | None = None) -> tuple[list[dict[str, object]], list[str]]:
    files: list[Path] = []
    missing: list[str] = []
    for source in sources:
        source_path = workspace_path(root, source)
        if not source_path.exists():
            missing.append(source)
            continue
        if source_path.is_file():
            if is_project_material(source_path, root):
                files.append(source_path)
        else:
            files.extend(item for item in source_path.rglob("*") if item.is_file() and is_project_material(item, root))
    unique = sorted({item.resolve() for item in files}, key=lambda item: item.as_posix().lower())
    cached = {str(item.get("path")): item for item in (previous or []) if isinstance(item, dict)}
    entries: list[dict[str, object]] = []
    for item in unique:
        relative = item.relative_to(root).as_posix()
        stat_result = item.stat()
        prior = cached.get(relative)
        content_sha256 = sha256_file(item)
        if (prior and prior.get("sha256") == content_sha256
                and all(key in prior for key in ("dimensions", "readable", "storage_role"))):
            reused = dict(prior)
            reused.update({"bytes": stat_result.st_size, "mtime_ns": stat_result.st_mtime_ns,
                           "ctime_ns": stat_result.st_ctime_ns, "sha256": content_sha256})
            entries.append(reused)
        else:
            entries.append(inspect_file(item, root, content_sha256=content_sha256))
    roles: dict[str, str] = {}
    for entry in entries:
        role = str(entry["storage_role"]); key = role.casefold()
        require(key not in roles, f"duplicate material role: {roles.get(key)} and {entry['path']}")
        roles[key] = str(entry["path"])
    return entries, missing

def fingerprint(entries: list[dict[str, object]]) -> str:
    payload = "\n".join(f"{entry['path']}\t{entry['bytes']}\t{entry['sha256']}" for entry in entries)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def is_reference_entry(entry: dict[str, object]) -> bool:
    parts = tuple(part.casefold() for part in Path(str(entry["path"])).parts)
    return parts[:2] == ("project", "references")


def project_fact_entries(entries: list[dict[str, object]]) -> list[dict[str, object]]:
    # project/references is method/style evidence only. It must not invalidate project identity facts.
    return [entry for entry in entries if not is_reference_entry(entry)]


def visual_input_entries(entries: list[dict[str, object]]) -> list[dict[str, object]]:
    # Any real image that can affect visual production belongs to the Baseline input fingerprint, including canonical logos.
    return [entry for entry in entries if Path(str(entry["path"])).suffix.lower() in BASELINE_IMAGE_EXTENSIONS]


def project_fact_fingerprint(entries: list[dict[str, object]]) -> str:
    return fingerprint(project_fact_entries(entries))


def visual_input_fingerprint(entries: list[dict[str, object]]) -> str:
    return fingerprint(visual_input_entries(entries))


def visual_source_count(entries: list[dict[str, object]]) -> int:
    count = 0
    for entry in entries:
        path = str(entry["path"])
        if Path(path).suffix.lower() not in BASELINE_IMAGE_EXTENSIONS:
            continue
        if path.lower().startswith("project/assets/logos/"):
            continue
        count += 1
    return count


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def project_context_sha256(visual_fingerprint: str, brief: Path) -> str:
    # Keep initialization bound to the exact same contract as the Baseline gate.
    root = brief.resolve().parent.parent
    return shared_project_context_sha256(root, visual_fingerprint, brief)


def field_value(text: str, name: str) -> str:
    match = re.search(rf"(?m)^{re.escape(name)}:\s*([^\n]+?)\s*$", text)
    return match.group(1).strip() if match else ""


def baseline_stale_attribution(root: Path, expected_context: str, changes: dict[str, list[str]] | None = None) -> dict[str, object]:
    """Explain which observable input moved.

    `project_context_sha256` is one hash over visual inputs + project brief +
    evidence registry, so it cannot be decomposed. Reporting the observable pieces
    (published/current context, source-set change, which fact file is newer than the
    publication) is what stops a one-line brief edit from silently forcing a full
    40-image Baseline rebuild.
    """
    baseline = root / "project" / "baselines" / "project-visual-standard.md"
    index_path = root / "project" / "baselines" / "index.json"
    receipt = root / "project" / "baselines" / "publication.json"
    detail: dict[str, object] = {"standard_present": baseline.is_file(), "index_present": index_path.is_file(),
                                 "receipt_present": receipt.is_file()}
    if not index_path.is_file():
        detail["cause"] = "formal Baseline was never published"
        return detail
    try:
        idx = json.loads(read_utf8(index_path))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, TextIntegrityError):
        detail["cause"] = "Baseline index is unreadable"
        return detail
    published = str(idx.get("project_context_sha256", ""))
    detail["published_project_context_sha256"] = published
    detail["current_project_context_sha256"] = expected_context
    if published == expected_context:
        detail["cause"] = "context matches; another Baseline artifact or receipt check failed"
        return detail
    likely: list[str] = []
    if changes is not None:
        exact_reference_changes: dict[str, list[str]] = {}
        for kind in ("added", "changed", "removed"):
            values = [str(path) for path in changes.get(kind, []) if str(path).replace("\\", "/").casefold().startswith("project/references/")]
            if values:
                exact_reference_changes[kind] = values
        if exact_reference_changes:
            detail["reference_changes"] = exact_reference_changes
            detail["reference_change_count"] = sum(len(v) for v in exact_reference_changes.values())
            groups: dict[str, list[str]] = {}
            for kind, values in exact_reference_changes.items():
                for value in values:
                    parts = Path(value).parts
                    family = parts[2] if len(parts) > 2 else "_root"
                    groups.setdefault(family, []).append(f"{kind}:{value}")
            detail["reference_change_groups"] = groups
            likely.append("project/references source set/content changed; see exact reference_changes")
    material_index = root / "project" / "material-index.json"
    if material_index.is_file():
        try:
            current = json.loads(read_utf8(material_index))
            current_count = len(current.get("sources", []))
            detail["published_source_count"] = idx.get("source_count")
            detail["current_source_count"] = current_count
            if idx.get("source_count") != current_count:
                likely.append("visual inputs (material index source set changed)")
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            pass
    published_at = receipt.stat().st_mtime if receipt.is_file() else None
    for rel in ("project/project-brief.md", "project/evidence-registry.json"):
        path = root / rel
        if not path.is_file():
            continue
        if published_at is not None:
            newer = path.stat().st_mtime > published_at
            detail[f"{rel}_newer_than_publication"] = newer
            if newer:
                likely.append(rel)
    detail["likely_changed_inputs"] = likely or ["project brief or evidence registry (mtime inconclusive)"]
    detail["cause"] = "published Baseline context no longer matches current project facts"
    return detail


def validated_baseline_snapshot(root: Path, expected_context: str) -> str | None:
    baseline = root / "project" / "baselines" / "project-visual-standard.md"
    index = root / "project" / "baselines" / "index.json"
    receipt = root / "project" / "baselines" / "publication.json"
    if not (baseline.is_file() and index.is_file() and receipt.is_file()):
        return None
    baseline_root = root / "project" / "baselines"
    try:
        text = read_utf8(baseline)
        idx = json.loads(read_utf8(index))
        pub = json.loads(read_utf8(receipt))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, TextIntegrityError):
        return None
    required_headings = [f"## {i}." for i in range(1, BASELINE_SECTION_COUNT + 1)]
    if not all(h in text for h in required_headings):
        return None
    if field_value(text, "schema_version") != BASELINE_SCHEMA or field_value(text, "baseline_status") != "usable":
        return None
    if field_value(text, "character_identity_status") not in {"established", "partial", "none"}:
        return None
    if field_value(text, "brand_identity_status") not in {"established", "partial", "none"}:
        return None
    if field_value(text, "reference_playbook_status") not in {"established", "partial", "none"}:
        return None
    if field_value(text, "project_context_sha256") != expected_context:
        return None
    source_set = field_value(text, "source_set_sha256")
    if re.fullmatch(r"[0-9a-f]{64}", source_set) is None:
        return None
    baseline_sha = sha256_file(baseline); index_sha = sha256_file(index)
    if idx.get("schema_version") != BASELINE_INDEX_SCHEMA or idx.get("baseline_schema_version") != BASELINE_SCHEMA:
        return None
    if idx.get("baseline_sha256") != baseline_sha or idx.get("project_context_sha256") != expected_context:
        return None
    if idx.get("source_set_sha256") != source_set:
        return None
    if pub.get("schema_version") != BASELINE_INDEX_SCHEMA or pub.get("baseline_schema_version") != BASELINE_SCHEMA or pub.get("baseline_sha256") != baseline_sha:
        return None
    if pub.get("index_sha256") != index_sha or pub.get("project_context_sha256") != expected_context:
        return None
    if pub.get("source_set_sha256") != source_set:
        return None
    files = pub.get("files")
    if not isinstance(files, dict):
        return None
    actual = {}
    try:
        for path in sorted(baseline_root.rglob("*")):
            if path.is_file() and path.name != "publication.json":
                actual[path.relative_to(root).as_posix()] = sha256_file(path)
    except OSError:
        return None
    if files != actual:
        return None
    if set(path.relative_to(root).as_posix() for path in baseline_root.rglob("*") if path.is_file()) != set(files) | {"project/baselines/publication.json"}:
        return None
    return "project/baselines/project-visual-standard.md"


def ensure_baseline_request(root: Path) -> str:
    rel = "requests/baseline/project-visual-baseline"
    request = root / rel
    gate = root / ".agents" / "skills" / "workspace-governance" / "scripts" / "workspace_gate.py"
    require(gate.is_file(), "workspace governance script is missing")
    if not request.exists():
        args = [sys.executable, str(gate), "init-request", "--request", rel, "--primary-skill",
                "wxian-visual-baselines", "--request-text", "建立或刷新当前项目视觉 Baseline",
                "--workspace-root", str(root)]
    else:
        try:
            state = json.loads((request / "state.json").read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise InitError("existing Baseline request state is invalid") from exc
        if state.get("status") == "completed":
            args = [sys.executable, str(gate), "revise-request", "--request", rel, "--workspace-root", str(root)]
        else:
            args = [sys.executable, str(gate), "set-state", "--request", rel, "--workspace-root", str(root)]
    cp = subprocess.run(args, check=False, capture_output=True, text=True, encoding="utf-8")
    require(cp.returncode == 0, f"failed to prepare Baseline request: {cp.stdout or cp.stderr}")
    return rel

def entry_group(path_value: str) -> str:
    path = Path(path_value)
    return path.parts[0] if len(path.parts) > 1 else "."


def diff_entries(previous: list[dict[str, object]], current: list[dict[str, object]]) -> dict[str, list[str]]:
    old = {str(item.get("path")): str(item.get("sha256")) for item in previous}
    new = {str(item.get("path")): str(item.get("sha256")) for item in current}
    return {
        "added": sorted(path for path in new if path not in old),
        "changed": sorted(path for path in new if path in old and new[path] != old[path]),
        "removed": sorted(path for path in old if path not in new),
    }


def load_machine_inventory(root: Path) -> list[dict[str, object]]:
    path = root / "project" / "material-index.json"
    if not path.is_file():
        return []
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return []
    sources = value.get("sources", []) if isinstance(value, dict) else []
    return sources if isinstance(sources, list) else []


def write_machine_inventory(root: Path, entries: list[dict[str, object]], current_fingerprint: str) -> None:
    path = root / "project" / "material-index.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": 2,
        "fingerprint": current_fingerprint,
        "project_fact_fingerprint": project_fact_fingerprint(entries),
        "visual_input_fingerprint": visual_input_fingerprint(entries),
        "sources": entries,
    }
    encoded = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
    if path.is_file() and path.read_text(encoding="utf-8") == encoded:
        return
    atomic_write_text(path, encoded)


def evidence_priority(entry: dict[str, object]) -> tuple[int, str]:
    path = str(entry["path"]).casefold()
    score = 0
    keywords = {
        "readme": 12, "overview": 11, "brief": 10, "项目": 12, "说明": 9, "产品": 9,
        "game": 8, "游戏": 8, "玩法": 9, "gameplay": 9, "世界观": 8, "lore": 8,
        "角色": 8, "character": 8, "brand": 8, "品牌": 8, "design": 6, "spec": 6,
    }
    for key, value in keywords.items():
        if key in path: score += value
    suffix = Path(path).suffix
    if suffix in {".md", ".txt", ".pdf", ".docx", ".pptx"}: score += 3
    return (-score, path)


def visual_priority(entry: dict[str, object]) -> tuple[int, str]:
    path = str(entry["path"]).casefold()
    score = 0
    keywords = {
        "keyart": 12, "key-art": 12, "kv": 11, "主视觉": 12, "hero": 9, "main": 5,
        "character": 10, "角色": 10, "logo": 9, "brand": 7, "品牌": 7, "cover": 7,
        "gameplay": 7, "screenshot": 6, "截图": 6, "icon": 5,
        "道具": 9, "props": 9, "prop": 9,
    }
    for key, value in keywords.items():
        if key in path: score += value
    if path.startswith("project/assets/characters/"): score += 20
    if path.startswith("project/assets/props/"): score += 20
    return (-score, path)


def managed_block(entries: list[dict[str, object]], sources: list[str], missing: list[str], changes: dict[str, list[str]]) -> str:
    current = fingerprint(entries)
    image_entries = sorted((e for e in entries if str(e["type"]).startswith("image/")), key=visual_priority)
    evidence_entries = sorted((e for e in entries if not str(e["type"]).startswith("image/")), key=evidence_priority)
    groups: dict[str, int] = {}
    for entry in entries:
        group = entry_group(str(entry["path"])); groups[group] = groups.get(group, 0) + 1
    fact_fp = project_fact_fingerprint(entries)
    visual_fp = visual_input_fingerprint(entries)
    lines = [
        START,
        f"- 素材指纹：`{current}`",
        f"- 项目事实指纹：`{fact_fp}`",
        f"- 视觉输入指纹：`{visual_fp}`",
        f"- 文件数：{len(entries)}（视觉 {len(image_entries)} / 文档与其他 {len(evidence_entries)}）",
        f"- 扫描来源：{', '.join(f'`{item}`' for item in sources)}",
        f"- 顶层分布：" + (" / ".join(f"`{name}` {count}" for name, count in sorted(groups.items())) if groups else "无"),
        f"- 本次变化：新增 {len(changes['added'])} / 修改 {len(changes['changed'])} / 删除 {len(changes['removed'])}",
        "",
        "### 优先读取的文档证据",
    ]
    for entry in evidence_entries[:40]:
        lines.append(f"- `{entry['path']}` ({entry['type']}, {entry['bytes']} B)")
    if len(evidence_entries) > 40:
        lines.append(f"- 其余 {len(evidence_entries)-40} 个非图像文件见 `project/material-index.json`，仅在需要时检索。")
    if not evidence_entries:
        lines.append("- 无")
    changed = changes["added"] + changes["changed"] + changes["removed"]
    if changed:
        lines += ["", "### 本次变更路径"]
        for path in changed[:30]: lines.append(f"- `{path}`")
        if len(changed) > 30: lines.append(f"- 其余 {len(changed)-30} 项见机器索引；不要为核对 Hash 通读。")
    lines += ["", "### 视觉资料", f"- 共 {len(image_entries)} 张；以下只列最多 12 个高优先入口，完整路径/Hash/尺寸由机器索引与 Baseline 脚本管理。"]
    for entry in image_entries[:12]:
        dimensions = f", {entry['dimensions']}" if entry.get('dimensions') else ""
        lines.append(f"- `{entry['path']}` ({entry['type']}{dimensions})")
    if len(image_entries) > 12:
        lines.append(f"- 其余 {len(image_entries)-12} 张见 `project/material-index.json`；仅在紧凑索引不足以建立身份事实时按路径检索，不通读 Hash 表。")
    if not image_entries:
        lines.append("- 无")
    lines += [END, ""]
    return "\n".join(lines)


def read_existing_fingerprint(output: Path) -> str | None:
    if not output.is_file():
        return None
    for line in output.read_text(encoding="utf-8").splitlines():
        if line.startswith("- 素材指纹：`") and line.endswith("`"):
            return line.removeprefix("- 素材指纹：`").removesuffix("`")
    return None


def write_inventory(output: Path, block: str) -> None:
    if output.exists():
        old = output.read_text(encoding="utf-8")
        if START in old and END in old:
            prefix, remainder = old.split(START, 1)
            _, suffix = remainder.split(END, 1)
            text = prefix.rstrip() + "\n\n" + block.rstrip() + suffix
        else:
            text = old.rstrip() + "\n\n" + block
    else:
        text = "# 项目素材索引\n\n" + block
    rendered = text.rstrip() + "\n"
    if output.is_file() and output.read_text(encoding="utf-8") == rendered:
        return
    atomic_write_text(output, rendered)


def validate_project_brief(brief: Path, root: Path, current_fact_fingerprint: str, material_paths: set[str]) -> tuple[bool, str]:
    if not brief.is_file():
        return False, "project/project-brief.md is missing"
    text = read_utf8(brief)
    fp = re.search(r"(?m)^project_fact_fingerprint:\s*([0-9a-f]{64})\s*$", text)
    if not fp or fp.group(1) != current_fact_fingerprint:
        return False, "project brief is missing the current project_fact_fingerprint; reread only new/changed project-fact evidence and refresh the brief"
    coverage_match = re.search(r"(?m)^coverage:\s*(.+?)\s*$", text)
    if not coverage_match:
        return False, "project brief requires one coverage line for identity/product/mechanic/entity/brand/production"
    coverage = {}
    for item in coverage_match.group(1).split(";"):
        if "=" not in item:
            return False, "project brief coverage must use key=verified|unknown pairs separated by semicolons"
        key, value = (part.strip().lower() for part in item.split("=", 1))
        if key in coverage:
            return False, f"duplicate project brief coverage key: {key}"
        coverage[key] = value
    required_coverage = {"identity", "product", "mechanic", "entity", "brand", "production"}
    if set(coverage) != required_coverage or any(value not in {"verified", "unknown"} for value in coverage.values()):
        return False, "project brief coverage must contain exactly identity/product/mechanic/entity/brand/production with verified|unknown"
    if coverage["identity"] != "verified":
        return False, "project identity must be verified before Workspace can become ready"
    identity_dimensions = {"product", "mechanic", "entity", "brand"}
    if not any(coverage[key] == "verified" for key in identity_dimensions):
        return False, "project brief needs identity plus at least one verified project dimension: product/mechanic/entity/brand; production metadata alone is insufficient"
    facts_match = re.search(r"(?ims)^##\s+Verified facts\s*$([\s\S]*?)(?=^##\s+|\Z)", text)
    unknowns_match = re.search(r"(?ims)^##\s+Unknowns\s*$([\s\S]*?)(?=^##\s+|\Z)", text)
    if not facts_match or not unknowns_match:
        return False, "project brief requires '## Verified facts' and '## Unknowns'"
    if re.search(r"(?im)^##\s+Evidence-backed project inferences\s*$", text):
        return False, "visual conclusions belong in the Baseline, not project brief"
    for field in ("visual_mother", "signature_terms", "family_id", "rendering_mode", "prompt_module_id"):
        if re.search(rf"(?m)^{field}:\s*", text): return False, f"project brief duplicates Baseline field: {field}"
    pattern = re.compile(r"(?im)^\s*-\s*(identity|product|mechanic|entity|brand|production|constraint):\s*(.+?)\s*\|\s*evidence:\s*`([^`]+)`\s*$")
    facts = pattern.findall(facts_match.group(1))
    categories = {category.lower() for category, _, _ in facts}
    for category in required_coverage:
        if coverage[category] == "verified" and category not in categories:
            return False, f"coverage marks {category}=verified but no evidence-backed {category} fact exists"
    if len(facts) < 2:
        return False, "project brief needs at least two evidence-backed facts, including project identity and one production-relevant dimension"
    if "identity" not in categories:
        return False, "project brief requires an evidence-backed identity fact"
    placeholders = {"todo", "tbd", "待补充", "待确认", "placeholder", "unknown", "未知", "资料存在", "有素材", "project fact"}
    for category, claim, value in facts:
        claim=claim.strip(); evidence_value=value.split("#",1)[0].strip()
        if not claim or claim.casefold() in placeholders or len(claim) < 4:
            return False, f"project brief contains a non-substantive {category} fact: {claim}"
        if evidence_value not in material_paths:
            return False, f"project brief evidence is not in current material inventory: {evidence_value}"
        evidence_parts = tuple(part.casefold() for part in Path(evidence_value).parts)
        if evidence_parts[:2] == ("project", "references"):
            return False, f"project Reference cannot verify project facts: {evidence_value}"
        evidence=workspace_path(root,evidence_value)
        if not evidence.is_file() or inspect_file(evidence,root)["readable"] is not True:
            return False, f"project brief evidence is not readable: {evidence_value}"
    unknown_lines=[line.strip() for line in unknowns_match.group(1).splitlines() if line.strip().startswith("-")]
    if not unknown_lines: return False, "project brief must list remaining unknowns or '- none'"
    unknown_categories = set()
    for line in unknown_lines:
        m = re.match(r"-\s*(identity|product|mechanic|entity|brand|production):\s*(.+)", line, flags=re.I)
        if m: unknown_categories.add(m.group(1).lower())
    for category in required_coverage:
        if coverage[category] == "unknown" and category not in unknown_categories:
            return False, f"coverage marks {category}=unknown but Unknowns does not state that dimension"
    return True, "ready"


def check_api(root: Path) -> dict[str, object]:
    """Resolve the local Generation API credential and return its machine state."""
    api_config = root / ".agents" / "skills" / "image-generation-api" / "config" / "api-runtime.json"
    api_script = root / ".agents" / "skills" / "image-generation-api" / "scripts" / "generation_api.py"
    gui_script = root / ".agents" / "scripts" / "configure_api_key_windows.ps1"
    cli_command = f'"{sys.executable}" "{api_script}" configure --config "{api_config}"'

    def run_check() -> dict[str, object]:
        try:
            checked = subprocess.run(
                [sys.executable, str(api_script), "check-config", "--config", str(api_config)],
                check=False, capture_output=True, text=True, encoding="utf-8", errors="replace",
                env=os.environ.copy(), timeout=API_CHECK_TIMEOUT,
            )
        except subprocess.TimeoutExpired:
            return {"status": "blocked", "reason": f"API credential check timed out after {API_CHECK_TIMEOUT}s", "network_called": False}
        if not checked.stdout.strip():
            return {"status": "blocked", "reason": checked.stderr.strip() or "API check returned no result", "network_called": False}
        return json.loads(checked.stdout)

    def missing_credential(status: dict[str, object]) -> bool:
        connection = status.get("connection")
        return isinstance(connection, dict) and connection.get("credential_present") is False

    def run_windows_gui() -> dict[str, object]:
        if not gui_script.is_file():
            return {"status": "blocked", "reason": "Windows API key dialog script is missing"}
        try:
            completed = subprocess.run(
                ["powershell.exe", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-File", str(gui_script)],
                cwd=str(root), check=False, capture_output=True, text=True, encoding="utf-8", errors="replace",
                timeout=API_KEY_GUI_TIMEOUT,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            return {"status": "blocked", "reason": str(exc)}
        if completed.stdout.strip():
            try:
                return json.loads(completed.stdout.strip().splitlines()[-1])
            except json.JSONDecodeError:
                pass
        if completed.returncode == 3:
            return {"status": "cancelled"}
        return {"status": "blocked", "reason": completed.stderr.strip() or "API key dialog did not complete"}

    try:
        status = run_check()
        if status.get("status") == "ready":
            return {**status, "prompt_attempted": False}
        if not missing_credential(status):
            return {**status, "prompt_attempted": False}
        connection = status.get("connection") if isinstance(status.get("connection"), dict) else {}
        credential_store = str(connection.get("credential_store") or ".agents/runtime/credentials.json")
        prompt_attempted = False
        configuration_cancelled = False
        if sys.platform == "win32":
            prompt_attempted = True
            configured = run_windows_gui()
            if configured.get("status") == "configured":
                refreshed = run_check()
                if refreshed.get("status") == "ready":
                    return {**refreshed, "prompt_attempted": True, "credential_configured": True}
            configuration_cancelled = configured.get("status") == "cancelled"
            next_command = f'powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "{gui_script}"'
            input_mode = "local_gui"
        else:
            next_command = cli_command
            input_mode = "local_hidden"
        return {
            "status": "needs_api_key",
            "credential_store": credential_store,
            "credential_present": False,
            "credential_value_exposed": False,
            "network_called": False,
            "reason": "Generation API key is not configured",
            "next_command": next_command,
            "input_mode": input_mode,
            "prompt_attempted": prompt_attempted,
            "configuration_cancelled": configuration_cancelled,
        }
    except (OSError, json.JSONDecodeError):
        return {"status": "blocked", "reason": "invalid or missing api-runtime.json", "network_called": False}


def ensure_runtime_environment(root: Path, repair: bool, *, minimal: bool = False) -> dict[str, object]:
    """Run either minimal session readiness or the explicit full doctor/repair."""
    script = root / ".agents" / "scripts" / "runtime_bootstrap.py"
    require(script.is_file(), "runtime bootstrap script is missing")
    command = "check" if minimal else ("repair" if repair else "doctor")
    try:
        completed = subprocess.run(
            [sys.executable, str(script), command, "--workspace-root", str(root)],
            check=False, capture_output=True, text=True, encoding="utf-8", errors="replace",
            env=os.environ.copy(), timeout=RUNTIME_SUBPROCESS_TIMEOUT,
        )
    except subprocess.TimeoutExpired as exc:
        raise InitError(f"runtime bootstrap timed out after {RUNTIME_SUBPROCESS_TIMEOUT}s") from exc
    try:
        result = json.loads(completed.stdout) if completed.stdout.strip() else {}
    except json.JSONDecodeError as exc:
        raise InitError("runtime bootstrap returned invalid output") from exc
    require(completed.returncode == 0 and result.get("status") == "ready",
            str(result.get("reason") or completed.stderr.strip() or "runtime environment is not ready: unknown error"))
    global Image
    if not minimal and Image is None:
        try:
            from PIL import Image as PillowImage
        except ImportError as exc:
            raise InitError("Pillow repair completed but current Python process still cannot import PIL") from exc
        Image = PillowImage
    return result

def require_project_runtime(root: Path) -> None:
    """Block project initialization inside the Canonical Mother before any mutation."""
    maintainer = root / ".agents" / "skills" / "workspace-master-maintainer" / "SKILL.md"
    require(not maintainer.is_file(),
            "canonical Mother is not a project Runtime; export a Project Runtime before project initialization")


def initialize_user_store(root: Path) -> dict[str, object]:
    script = root / ".agents" / "skills" / "workspace-personal-skill" / "scripts" / "personal_skill.py"
    require(script.is_file(), "workspace-personal-skill script is missing")
    try:
        completed = subprocess.run(
            [sys.executable, str(script), "init-store", "--workspace-root", str(root)],
            check=False, capture_output=True, text=True, encoding="utf-8", errors="replace",
            env=os.environ.copy(), timeout=USER_STORE_TIMEOUT,
        )
    except subprocess.TimeoutExpired as exc:
        raise InitError(f"user manifest initialization timed out after {USER_STORE_TIMEOUT}s") from exc
    try:
        result = json.loads(completed.stdout)
    except json.JSONDecodeError as exc:
        raise InitError("workspace-personal-skill returned invalid output") from exc
    require(completed.returncode == 0 and result.get("status") == "ready",
            f"user manifest initialization failed: {result.get('reason', 'unknown error')}")
    return {"status": "ready"}


def init_status_path(root: Path) -> Path:
    return root / ".agents" / "runtime" / "init-status.json"


def write_init_status(root: Path, *, phase: str, status: str, detail: str = "", result_status: str | None = None) -> None:
    path = init_status_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "phase": phase,
        "status": status,
        "result_status": result_status,
        "detail": detail,
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "pid": os.getpid(),
        "python": str(Path(sys.executable).resolve()),
    }
    atomic_write_text(path, json.dumps(payload, ensure_ascii=False, indent=2) + "\n")


def finish_init(root: Path, result: dict[str, object]) -> dict[str, object]:
    status = str(result.get("status") or "blocked")
    phase = {
        "needs_api_key": "api_credential",
        "needs_project_brief": "project_brief",
        "needs_visual_baseline": "visual_baseline",
        "ready": "complete",
        "blocked": "blocked",
    }.get(status, "complete")
    write_init_status(root, phase=phase, status="ready" if status == "ready" else "waiting",
                      detail=str(result.get("reason") or result.get("next") or ""), result_status=status)
    return result


def project_state(root: Path, sources: list[str], output: Path, *, include_user_store: bool, check_api_credential: bool) -> dict[str, object]:
    """Refresh inventories and resolve Project Brief/Baseline validity from separated fact and visual fingerprints."""
    require_project_runtime(root)
    if check_api_credential:
        write_init_status(root, phase="api_credential", status="running", detail="checking local Generation API credential; no network call")
        api_status = {**check_api(root), "initialization_blocking": False}
    else:
        api_status = {"status": "not_checked"}
    if include_user_store:
        write_init_status(root, phase="runtime", status="running", detail="checking/repairing local Runtime")
        runtime_status = ensure_runtime_environment(root, repair=False, minimal=True)
        write_init_status(root, phase="runtime", status="ready", detail="local Runtime ready")
    else:
        runtime_status = {"status": "not_checked"}
    if include_user_store:
        initialize_user_store(root)
    write_init_status(root, phase="materials", status="running", detail="refreshing project material inventory") if include_user_store else None
    previous_entries = load_machine_inventory(root)
    previous_full = fingerprint(previous_entries) if previous_entries else None
    previous_fact = project_fact_fingerprint(previous_entries) if previous_entries else None
    previous_visual = visual_input_fingerprint(previous_entries) if previous_entries else None
    entries, missing = collect(root, sources, previous_entries)
    require(bool(entries), "no project materials found; place project files anywhere outside .agents/requests/user/tmp before initialization")
    current = fingerprint(entries)
    fact_fp = project_fact_fingerprint(entries)
    visual_fp = visual_input_fingerprint(entries)
    changes = diff_entries(previous_entries, entries)
    write_inventory(output, managed_block(entries, sources, missing, changes))
    write_machine_inventory(root, entries, current)
    material_paths = {str(entry["path"]) for entry in entries}
    brief = root / "project" / "project-brief.md"
    brief_ready, brief_reason = validate_project_brief(brief, root, fact_fp, material_paths)
    common = {
        "material_count": len(entries),
        "fingerprint": current,
        "project_fact_fingerprint": fact_fp,
        "visual_input_fingerprint": visual_fp,
        "changes": changes,
        "change_scope": {
            "project_fact_changed": previous_fact is not None and previous_fact != fact_fp,
            "visual_input_changed": previous_visual is not None and previous_visual != visual_fp,
            "reference_only": bool(changes["added"] or changes["changed"] or changes["removed"]) and all(
                tuple(part.casefold() for part in Path(path).parts)[:2] == ("project", "references")
                for path in changes["added"] + changes["changed"] + changes["removed"]
            ),
            "first_scan": previous_full is None,
        },
        "api": api_status,
        "runtime": runtime_status,
    }
    if not brief_ready:
        return finish_init(root, {"status": "needs_project_brief", **common, "reason": brief_reason,
                "next": "Read only the compact material index plus necessary project-fact evidence; write project/project-brief.md with current project_fact_fingerprint, one coverage line for identity/product/mechanic/entity/brand/production, evidence-backed verified facts, and explicit unknown dimensions; rerun initialize or visual-check."})
    context_sha = project_context_sha256(visual_fp, brief)
    visual_count = visual_source_count(entries)
    baseline_request = None
    baseline = None
    if visual_count:
        baseline = validated_baseline_snapshot(root, context_sha)
        if baseline is None:
            baseline_request = ensure_baseline_request(root)
            return finish_init(root, {"status": "needs_visual_baseline", **common,
                    "visual_source_count": visual_count, "project_context_sha256": context_sha,
                    "project_brief": "project/project-brief.md", "baseline_request": baseline_request,
                    "reason": "formal Baseline is missing, stale, or lacks a matching publication receipt",
                    "baseline_stale_detail": baseline_stale_attribution(root, context_sha, changes),
                    "next": "Run wxian-visual-baselines on baseline_request. Reuse unchanged deep analyses only when exact source path/hash and the current analysis contract, reverse-analysis skill version, and grounding-gate version all match. For <=100 unique References, deep-analyze every image; for larger pools, first rebuild the 100% visual census and semantic clusters, then deep-analyze required representatives. Re-verify character cards and brand profile, and rebuild a Schema 8 Baseline through project-level visual synthesis: all deep analyses must participate in the internal synthesis ledger, but the final Baseline must contain only cross-image project cognition, current output structure, project-specific Visual DNA, cross-family differences, Floors and innovation space. Do not copy per-image notes into the final Baseline. Run blind-reconstruction, swap-test, semantic-duplication, grounding-review, one-shot calibration, and UTF-8 text-integrity gates before publish. Publish, complete the internal Baseline request, then rerun initialize or visual-check."})
    return finish_init(root, {"status": "ready", **common, "visual_source_count": visual_count,
            "project_context_sha256": context_sha, "project_brief": "project/project-brief.md",
            "baseline": baseline, "baseline_request": baseline_request,
            "next": "Route the user's current goal to exactly one primary professional Skill."})


def initialize(root: Path, sources: list[str], output: Path) -> dict[str, object]:
    """New-session initialization performs only task-independent local readiness."""
    return project_state(root, sources, output, include_user_store=True, check_api_credential=False)


def visual_check(root: Path, sources: list[str], output: Path) -> dict[str, object]:
    """Same-session visual preflight. Detect visual/reference changes without rerunning unrelated session setup."""
    return project_state(root, sources, output, include_user_store=False, check_api_credential=False)

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("build", "check", "initialize", "visual-check", "api-check", "runtime-check", "runtime-repair"))
    parser.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[2])
    parser.add_argument("--source", action="append", dest="sources")
    parser.add_argument("--output", default="project/material-index.md")
    args = parser.parse_args()
    try:
        root = args.workspace_root.resolve()
        require(root.is_dir(), f"Workspace root does not exist: {root}")
        sources = args.sources or list(DEFAULT_SOURCES)
        if args.command in {"runtime-check", "runtime-repair"}:
            result = ensure_runtime_environment(root, repair=args.command == "runtime-repair")
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
        if args.command == "api-check":
            result = check_api(root)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0 if result.get("status") == "ready" else 1
        if args.command in {"initialize", "visual-check"}:
            result = (initialize(root, sources, workspace_path(root, args.output))
                      if args.command == "initialize" else visual_check(root, sources, workspace_path(root, args.output)))
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0 if result["status"] == "ready" else 1
        previous_entries = load_machine_inventory(root)
        entries, missing = collect(root, sources)
        current = fingerprint(entries)
        changes = diff_entries(previous_entries, entries)
        output = workspace_path(root, args.output)
        previous = read_existing_fingerprint(output)
        if args.command == "build":
            require(bool(entries), "no project materials found")
            write_inventory(output, managed_block(entries, sources, missing, changes))
            write_machine_inventory(root, entries, current)
            status = "initialized" if previous is None else ("unchanged" if previous == current else "updated")
        else:
            status = "unchanged" if previous == current and previous is not None else "changed"
        print(json.dumps({
            "status": status,
            "workspace_root": str(root),
            "output": str(output),
            "material_count": len(entries),
            "fingerprint": current,
            "previous_fingerprint": previous,
            "missing_sources": missing,
        }, ensure_ascii=False, indent=2))
        return 0 if status != "changed" else 1
    except (InitError, TextIntegrityError, OSError, subprocess.TimeoutExpired) as exc:
        try:
            if 'args' in locals() and args.command == "initialize" and 'root' in locals():
                write_init_status(root, phase="blocked", status="blocked", detail=str(exc), result_status="blocked")
        except Exception:
            pass
        print(json.dumps({
            "status": "blocked",
            "reason": str(exc),
        }, ensure_ascii=False, indent=2))
        return 2


if __name__ == "__main__":
    sys.exit(main())
