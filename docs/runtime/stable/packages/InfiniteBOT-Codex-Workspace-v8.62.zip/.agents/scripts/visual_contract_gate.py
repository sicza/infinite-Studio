#!/usr/bin/env python3
"""Create/validate request-bound Narrative→Visual→Prompt→Gate evidence. No provider/API calls."""
from __future__ import annotations

import argparse, json, shutil, sys, tempfile
from pathlib import Path

AGENTS_ROOT = Path(__file__).resolve().parents[1]
LIB = AGENTS_ROOT / "lib"
if str(LIB) not in sys.path: sys.path.insert(0, str(LIB))
from request_identity import identity as request_identity
from atomic_io import atomic_write_text
from visual_contracts import (
    VisualContractError, load_json, registry, semantic_checksum, sha256_file,
    validate_baseline_consumption, validate_narrative_contract, validate_prompt_binding,
    validate_schema, validate_visual_gate_result, validate_visual_return, validate_visual_spec,
    schema, workspace_relative,
)


def write_json(path: Path, value: dict) -> None:
    atomic_write_text(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def compiler_profile(name: str) -> dict:
    profiles = registry("prompt-compiler-profiles.json", "sicza.prompt-compiler-profiles.v1")
    value = profiles.get(name)
    if not isinstance(value, dict): raise VisualContractError(f"unknown prompt compiler profile: {name}")
    return value


def positive_spec(root: Path, request: Path, *, profile_id: str = "visual.still.production.v1") -> dict:
    ident=request_identity(root,request); req=workspace_relative(root,request)
    return {
        "schema_version":"sicza.visual-spec.v2",**ident,"profile_id":profile_id,"mode":"CREATE","task_kind":"still",
        "authority_trace":[{"role":"current_request","path":f"{req}/request.md","sha256":sha256_file(request/'request.md')}],
        "narrative_trace":None,
        "intent":{"primary":"make the requested subject immediately legible"},
        "truth_protection":{"protect":["locked subject identity"]},
        "world_space":{"space":"one coherent grounded scene"},
        "performance":{},
        "projection":{"camera":"stable readable perspective"},
        "appearance":{"surface":"material response remains coherent"},
        "image_structure":{"hierarchy":"clear first and second read"},
        "image_formation":{"focus":"focus and edge hierarchy match intent"},
        "graphic":{},"identity":{"lock":"preserve required identity"},"channel_roles":{},"motion":None,"change_set":{},
        "success_condition":["target remains readable at delivery size"],"unresolved":[]
    }


def semantic_selftest() -> dict:
    results={}
    with tempfile.TemporaryDirectory(prefix="visual-contract-selftest-") as td:
        root=Path(td)
        # Copy the one prompt pack used by the positive fixture. Registries/schemas stay authoritative in this installation.
        profile=compiler_profile("image.generic.v1")
        pack_rel=Path(profile["prompt_pack"]); pack=root/pack_rel; pack.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(AGENTS_ROOT.parent/pack_rel,pack)
        for name in ("a","b"):
            req=root/"requests"/"image-generation"/name
            (req/"input").mkdir(parents=True); (req/"work").mkdir(); (req/"output").mkdir()
            (req/"request.md").write_text(f"request {name}\n",encoding="utf-8")
            write_json(req/"state.json",{"primary_skill":"wxian-image-production","status":"active","revision":1})
            (req/"work"/"requirement-lock.md").write_text("production_branch: new-generation\n",encoding="utf-8")
        req=root/"requests"/"image-generation"/"a"; other=root/"requests"/"image-generation"/"b"
        spec=positive_spec(root,req); spec_path=req/"work"/"visual-spec.json"; write_json(spec_path,spec)
        prompt=req/"work"/"prompt-package.md"; prompt.write_text("subject, coherent perspective, readable hierarchy\n",encoding="utf-8")
        ident=request_identity(root,req)
        binding={"schema_version":"sicza.prompt-binding.v2",**ident,"visual_spec_path":workspace_relative(root,spec_path),"visual_spec_sha256":sha256_file(spec_path),"narrative_semantic_checksum":None,"prompt_path":workspace_relative(root,prompt),"prompt_sha256":sha256_file(prompt),"compiler_profile":"image.generic.v1","adapter_family":profile["adapter_family"],"prompt_pack_path":profile["prompt_pack"],"prompt_pack_sha256":sha256_file(pack)}
        binding_path=req/"work"/"prompt-binding.json"; write_json(binding_path,binding)
        target=req/"work"/"candidate.png"; target.write_bytes(b"visual-target")
        ev={"target_path":workspace_relative(root,target),"target_sha256":sha256_file(target),"observation":"observable target evidence is bound to this exact file"}
        gates=[{"gate":name,"result":"PASS","evidence":[dict(ev)],"owner":"sicza-visual-director"} for name in ["VG-INTENT","VG-INTEGRITY","VG-HIERARCHY","VG-COHERENCE","VG-DELIVERY-FIT"]]
        gate={"schema_version":"sicza.visual-gate-result.v2",**ident,"gate_profile":"gate.visual.production.v1","target_path":workspace_relative(root,target),"target_sha256":sha256_file(target),"visual_spec_path":workspace_relative(root,spec_path),"visual_spec_sha256":sha256_file(spec_path),"prompt_binding_path":workspace_relative(root,binding_path),"prompt_binding_sha256":sha256_file(binding_path),"result":"VISUAL_PASS","gates":gates,"reviewer":"sicza-visual-director"}
        gate_path=req/"work"/"visual-gate-result.json"; write_json(gate_path,gate)
        validate_visual_spec(root,spec_path); validate_prompt_binding(root,binding_path); validate_visual_gate_result(root,gate_path)
        results["positive_chain"]="PASS"

        def blocked(name, fn):
            try: fn()
            except (VisualContractError,OSError,ValueError): results[name]="BLOCK"
            else: raise VisualContractError(f"semantic self-test unexpectedly passed: {name}")

        # stale revision
        write_json(req/"state.json",{"primary_skill":"wxian-image-production","status":"active","revision":2})
        blocked("stale_revision",lambda:validate_visual_spec(root,spec_path))
        write_json(req/"state.json",{"primary_skill":"wxian-image-production","status":"active","revision":1})

        # cross-request request-local authority
        bad=json.loads(json.dumps(spec)); bad["authority_trace"].append({"role":"requirement_lock","path":workspace_relative(root,other/'work'/'requirement-lock.md'),"sha256":sha256_file(other/'work'/'requirement-lock.md')})
        write_json(spec_path,bad); blocked("cross_request_authority",lambda:validate_visual_spec(root,spec_path)); write_json(spec_path,spec)

        # vacuous spec despite syntactically valid containers
        vac=json.loads(json.dumps(spec)); vac["intent"]={}; write_json(spec_path,vac); blocked("vacuous_visual_spec",lambda:validate_visual_spec(root,spec_path)); write_json(spec_path,spec)

        # restore binding because spec bytes may have changed during negative fixture
        binding["visual_spec_sha256"]=sha256_file(spec_path); write_json(binding_path,binding)
        gate["visual_spec_sha256"]=sha256_file(spec_path); gate["prompt_binding_sha256"]=sha256_file(binding_path); write_json(gate_path,gate)

        missing=json.loads(json.dumps(gate)); missing["gates"]=[g for g in missing["gates"] if g["gate"]!="VG-COHERENCE"]; write_json(gate_path,missing); blocked("missing_mandatory_gate",lambda:validate_visual_gate_result(root,gate_path))
        empty=json.loads(json.dumps(gate)); empty["gates"][0]["evidence"]=[]; write_json(gate_path,empty); blocked("empty_gate_evidence",lambda:validate_visual_gate_result(root,gate_path))
        weak=json.loads(json.dumps(gate)); weak["gates"][0]["evidence"][0]["observation"]="looks ok"; write_json(gate_path,weak); blocked("weak_gate_evidence",lambda:validate_visual_gate_result(root,gate_path))
        unknown=json.loads(json.dumps(binding)); unknown["compiler_profile"]="unknown.profile"; write_json(binding_path,unknown); blocked("unknown_compiler_profile",lambda:validate_prompt_binding(root,binding_path))
        mismatch=json.loads(json.dumps(binding)); mismatch["adapter_family"]="wrong-adapter"; write_json(binding_path,mismatch); blocked("adapter_mismatch",lambda:validate_prompt_binding(root,binding_path))
        write_json(binding_path,binding)
        cross=json.loads(json.dumps(gate)); other_target=other/"work"/"candidate.png"; other_target.write_bytes(b"other"); cross["target_path"]=workspace_relative(root,other_target); cross["target_sha256"]=sha256_file(other_target)
        for g in cross["gates"]:
            for e in g["evidence"]: e["target_path"]=cross["target_path"]; e["target_sha256"]=cross["target_sha256"]
        write_json(gate_path,cross); blocked("cross_request_target",lambda:validate_visual_gate_result(root,gate_path))
    return results


def main() -> int:
    ap=argparse.ArgumentParser(description=__doc__); sub=ap.add_subparsers(dest="command",required=True)
    for command in ("validate-narrative","validate-spec","validate-binding","validate-visual-gate","validate-baseline","validate-return"):
        p=sub.add_parser(command); p.add_argument("--file",type=Path,required=True); p.add_argument("--workspace-root",type=Path,default=Path(__file__).resolve().parents[2])
    stamp=sub.add_parser("stamp-narrative"); stamp.add_argument("--file",type=Path,required=True); stamp.add_argument("--workspace-root",type=Path,default=Path(__file__).resolve().parents[2])
    bind=sub.add_parser("bind-prompt"); bind.add_argument("--visual-spec",type=Path,required=True); bind.add_argument("--prompt",type=Path,required=True); bind.add_argument("--compiler-profile",required=True); bind.add_argument("--output",type=Path,required=True); bind.add_argument("--workspace-root",type=Path,default=Path(__file__).resolve().parents[2])
    ident=sub.add_parser("identity"); ident.add_argument("--request",type=Path,required=True); ident.add_argument("--workspace-root",type=Path,default=Path(__file__).resolve().parents[2])
    sub.add_parser("doctor")
    args=ap.parse_args()
    try:
        if args.command=="doctor":
            schema_ids={"narrative-visual-contract-schema.json":"sicza.narrative-visual-contract.v2","visual-spec-schema.json":"sicza.visual-spec.v2","prompt-binding-schema.json":"sicza.prompt-binding.v2","visual-gate-result-schema.json":"sicza.visual-gate-result.v2","baseline-consumption-schema.json":"sicza.baseline-consumption.v2","visual-return-schema.json":"sicza.visual-return.v1"}
            for name,expected in schema_ids.items():
                obj=schema(name)
                if obj.get("$id")!=expected: raise VisualContractError(f"invalid contract schema id: {name}")
            registry("visual-spec-profiles.json","sicza.visual-spec-profiles.v1"); registry("visual-gate-profiles.json","sicza.visual-gate-profiles.v1"); registry("prompt-compiler-profiles.json","sicza.prompt-compiler-profiles.v1"); registry("visual-enforcement-profiles.json","sicza.visual-enforcement-profiles.v1")
            tests=semantic_selftest()
            print(json.dumps({"status":"ready","schemas":list(schema_ids),"semantic_selftests":tests,"provider_calls":False},ensure_ascii=False,indent=2)); return 0
        root=args.workspace_root.resolve()
        if args.command=="identity":
            request=(root/args.request).resolve() if not args.request.is_absolute() else args.request.resolve(); print(json.dumps({"status":"ready",**request_identity(root,request)},ensure_ascii=False,indent=2)); return 0
        if args.command=="stamp-narrative":
            path=args.file.resolve(); obj=load_json(path); request=(root/obj["request_ref"]).resolve(); obj.update(request_identity(root,request)); obj["contract_revision"]=obj["request_revision"]
            if not isinstance(obj.get("semantic_checksum"),str) or len(str(obj.get("semantic_checksum","")))!=64: obj["semantic_checksum"]="0"*64
            validate_schema(obj,schema("narrative-visual-contract-schema.json")); obj["semantic_checksum"]=semantic_checksum(obj); write_json(path,obj); validate_narrative_contract(root,path)
            print(json.dumps({"status":"stamped","file":str(path),"semantic_checksum":obj["semantic_checksum"]},ensure_ascii=False,indent=2)); return 0
        if args.command=="bind-prompt":
            spec_path=args.visual_spec.resolve(); prompt_path=args.prompt.resolve(); spec=validate_visual_spec(root,spec_path); request=(root/spec["request_ref"]).resolve(); prof=compiler_profile(args.compiler_profile); pack=(root/prof["prompt_pack"]).resolve()
            if not pack.is_file(): raise VisualContractError(f"compiler prompt pack is missing: {prof['prompt_pack']}")
            value={"schema_version":"sicza.prompt-binding.v2",**request_identity(root,request),"visual_spec_path":workspace_relative(root,spec_path),"visual_spec_sha256":sha256_file(spec_path),"narrative_semantic_checksum":spec["narrative_trace"]["semantic_checksum"] if spec["narrative_trace"] else None,"prompt_path":workspace_relative(root,prompt_path),"prompt_sha256":sha256_file(prompt_path),"compiler_profile":args.compiler_profile,"adapter_family":prof["adapter_family"],"prompt_pack_path":prof["prompt_pack"],"prompt_pack_sha256":sha256_file(pack)}
            write_json(args.output.resolve(),value); obj=validate_prompt_binding(root,args.output.resolve())
        elif args.command=="validate-narrative": obj=validate_narrative_contract(root,args.file.resolve())
        elif args.command=="validate-spec": obj=validate_visual_spec(root,args.file.resolve())
        elif args.command=="validate-binding": obj=validate_prompt_binding(root,args.file.resolve())
        elif args.command=="validate-visual-gate": obj=validate_visual_gate_result(root,args.file.resolve())
        elif args.command=="validate-baseline": obj=validate_baseline_consumption(root,args.file.resolve())
        elif args.command=="validate-return": obj=validate_visual_return(root,args.file.resolve())
        else: raise VisualContractError("unsupported command")
        print(json.dumps({"status":"passed","schema_version":obj.get("schema_version")},ensure_ascii=False,indent=2)); return 0
    except (VisualContractError,OSError,ValueError,KeyError) as exc:
        print(json.dumps({"status":"blocked","reason":str(exc)},ensure_ascii=False,indent=2)); return 2

if __name__=="__main__": raise SystemExit(main())
