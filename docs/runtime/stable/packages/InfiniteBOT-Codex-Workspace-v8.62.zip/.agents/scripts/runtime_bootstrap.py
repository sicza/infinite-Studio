#!/usr/bin/env python3
"""Validate and repair local execution dependencies after Python is available."""
from __future__ import annotations
import os as _bytecode_guard_os, sys as _bytecode_guard_sys
_bytecode_guard_sys.dont_write_bytecode = True
_bytecode_guard_os.environ["PYTHONDONTWRITEBYTECODE"] = "1"

import argparse
import hashlib
import importlib
import json
import os
import platform
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

AGENTS_ROOT = Path(__file__).resolve().parents[1]
LIB = AGENTS_ROOT / "lib"
if str(LIB) not in sys.path:
    sys.path.insert(0, str(LIB))
from atomic_io import atomic_write_text
from runtime_environment import resolve_binary, runtime_state_path

MIN_PYTHON = (3, 10)
PIP_TIMEOUT = 300
INSTALL_TIMEOUT = 900


class RuntimeError_(RuntimeError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError_(message)


def run(args: list[str], *, timeout: int = 120, env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(args, check=False, capture_output=True, text=True, encoding="utf-8", errors="replace",
                          timeout=timeout, env=env or os.environ.copy())


def python_status() -> dict[str, Any]:
    version = platform.python_version()
    ok = sys.version_info >= MIN_PYTHON
    return {
        "status": "ready" if ok else "blocked",
        "version": version,
        "executable": os.path.abspath(sys.executable),
        "virtualenv": sys.prefix != getattr(sys, "base_prefix", sys.prefix),
        "prefix": os.path.abspath(sys.prefix),
        "base_prefix": os.path.abspath(getattr(sys, "base_prefix", sys.prefix)),
        "minimum": ".".join(map(str, MIN_PYTHON)),
        "reason": None if ok else f"Python >= {'.'.join(map(str, MIN_PYTHON))} is required",
    }


def pip_status() -> dict[str, Any]:
    cp = run([sys.executable, "-m", "pip", "--version"], timeout=60)
    return {
        "status": "ready" if cp.returncode == 0 else "missing",
        "detail": (cp.stdout or cp.stderr).strip(),
    }


def ensure_pip() -> dict[str, Any]:
    current = pip_status()
    if current["status"] == "ready":
        return current
    cp = run([sys.executable, "-m", "ensurepip", "--upgrade"], timeout=PIP_TIMEOUT)
    checked = pip_status()
    if checked["status"] != "ready":
        checked["repair_error"] = (cp.stderr or cp.stdout).strip()[-1200:]
    return checked


def module_version(module: str) -> str | None:
    try:
        value = importlib.import_module(module)
    except Exception:
        return None
    return str(getattr(value, "__version__", "unknown"))


def pip_install(package: str, *, force_reinstall: bool = False) -> tuple[bool, str]:
    install_args = ["install", "--disable-pip-version-check", "--no-input"]
    if force_reinstall:
        install_args += ["--upgrade", "--force-reinstall"]
    commands = [[sys.executable, "-m", "pip", *install_args, package]]
    # PEP-668/global-site restrictions are common on POSIX. A user-site retry is safe when not in a venv.
    if sys.prefix == getattr(sys, "base_prefix", sys.prefix):
        user_args = ["install", "--disable-pip-version-check", "--no-input", "--user"]
        if force_reinstall:
            user_args += ["--upgrade", "--force-reinstall"]
        commands.append([sys.executable, "-m", "pip", *user_args, package])
    errors: list[str] = []
    for command in commands:
        cp = run(command, timeout=INSTALL_TIMEOUT)
        if cp.returncode == 0:
            importlib.invalidate_caches()
            return True, (cp.stdout or "installed").strip()[-1200:]
        errors.append((cp.stderr or cp.stdout).strip()[-1200:])
    return False, " | ".join(item for item in errors if item)


def pillow_status() -> dict[str, Any]:
    try:
        from PIL import Image, features
        version = str(getattr(Image, "__version__", "unknown"))
        webp = bool(features.check("webp"))
        return {"status": "ready" if webp else "blocked", "version": version, "webp": webp,
                "reason": None if webp else "Pillow is installed but WEBP codec support is unavailable"}
    except Exception as exc:
        return {"status": "missing", "reason": str(exc)}


def ensure_pillow() -> dict[str, Any]:
    current = pillow_status()
    if current["status"] == "ready":
        return current
    ok, detail = pip_install("Pillow", force_reinstall=current["status"] == "blocked")
    if ok:
        # A just-installed package may not be visible if an earlier failed import left module state; clear only PIL entries.
        for name in [key for key in list(sys.modules) if key == "PIL" or key.startswith("PIL.")]:
            sys.modules.pop(name, None)
        current = pillow_status()
    else:
        current["repair_error"] = detail
    return current


def psd_node_contract(root: Path) -> dict[str, str]:
    path = root / ".agents" / "skills" / "wxian-layered-psd-export" / "config" / "node-runtime.json"
    require(path.is_file(), f"PSD Node Runtime contract missing: {path}")
    value = json.loads(path.read_text(encoding="utf-8"))
    require(value.get("schema_version") == "wxian.psd-node-runtime.v1", "PSD Node Runtime contract schema mismatch")
    package = str(value.get("node_package", "")).strip(); version = str(value.get("version", "")).strip()
    install_root = str(value.get("install_root", "")).strip()
    require(package and version and install_root, "PSD Node Runtime contract is incomplete")
    return {"package": package, "version": version, "install_root": install_root}


def psd_node_root(root: Path) -> Path:
    contract = psd_node_contract(root)
    candidate = (root / contract["install_root"]).resolve()
    require(root.resolve() == candidate or root.resolve() in candidate.parents, "PSD Node Runtime install_root escapes Workspace")
    return candidate


def psd_node_status(root: Path) -> dict[str, Any]:
    node = shutil.which("node")
    npm = shutil.which("npm")
    module_root = psd_node_root(root)
    contract = psd_node_contract(root)
    package_name = contract["package"]; package_version = contract["version"]
    package_meta = module_root / "node_modules" / package_name / "package.json"
    if not node:
        return {"status": "missing", "reason": "Node.js is required for code-only Smart Object PSD export"}
    if not npm:
        return {"status": "missing", "node": node, "reason": "npm is required to install the pinned PSD runtime"}
    if not package_meta.is_file():
        return {"status": "missing", "node": node, "npm": npm, "module_root": str(module_root),
                "reason": f"{package_name}@{package_version} is not installed"}
    try:
        version = str(json.loads(package_meta.read_text(encoding="utf-8")).get("version", ""))
    except (OSError, json.JSONDecodeError) as exc:
        return {"status": "blocked", "reason": f"PSD Node package metadata unreadable: {exc}"}
    if version != package_version:
        return {"status": "blocked", "node": node, "npm": npm, "module_root": str(module_root), "version": version,
                "reason": f"PSD Runtime requires {package_name}@{package_version}"}
    smoke = run([node, "-e", (
        "const {createRequire}=require('module'); const path=require('path'); "
        "const r=createRequire(path.join(process.argv[1],'package.json')); "
        "const m=r(process.argv[2]); if(typeof m.writePsdBuffer!=='function'||typeof m.readPsd!=='function') process.exit(3);"
    ), str(module_root), package_name], timeout=30)
    if smoke.returncode != 0:
        return {"status": "blocked", "node": node, "npm": npm, "module_root": str(module_root),
                "reason": (smoke.stderr or smoke.stdout).strip()[-1000:] or "ag-psd import smoke failed"}
    return {"status": "ready", "node": node, "npm": npm, "module_root": str(module_root), "version": version}


def ensure_psd_node(root: Path, *, repair: bool) -> dict[str, Any]:
    current = psd_node_status(root)
    if current["status"] == "ready" or not repair:
        return current
    node = shutil.which("node")
    npm = shutil.which("npm")
    if not node or not npm:
        return current
    module_root = psd_node_root(root)
    module_root.mkdir(parents=True, exist_ok=True)
    package = module_root / "package.json"
    contract = psd_node_contract(root)
    package.write_text(json.dumps({
        "name": "wxian-psd-runtime", "private": True, "version": "1.0.0",
        "dependencies": {contract["package"]: contract["version"]},
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    cp = run([npm, "install", "--prefix", str(module_root), "--no-audit", "--no-fund", "--ignore-scripts"], timeout=INSTALL_TIMEOUT)
    checked = psd_node_status(root)
    if checked["status"] != "ready":
        checked["repair_error"] = (cp.stderr or cp.stdout).strip()[-1600:]
    return checked


def postprocess_smoke() -> dict[str, Any]:
    try:
        from PIL import Image
        with tempfile.TemporaryDirectory(prefix="wxian-postprocess-") as tmp:
            root = Path(tmp)
            base = Image.new("RGBA", (64, 64), (20, 30, 40, 255))
            overlay = Image.new("RGBA", (32, 32), (220, 120, 40, 128))
            base.alpha_composite(overlay, (16, 16))
            resized = base.resize((96, 48), Image.Resampling.LANCZOS)
            paths = {"png": root / "smoke.png", "jpg": root / "smoke.jpg", "webp": root / "smoke.webp"}
            resized.save(paths["png"], format="PNG", optimize=True)
            resized.convert("RGB").save(paths["jpg"], format="JPEG", quality=95, subsampling=0)
            resized.save(paths["webp"], format="WEBP", quality=95, method=6)
            decoded: dict[str, list[int]] = {}
            for kind, path in paths.items():
                with Image.open(path) as check:
                    check.load()
                    require(check.size == (96, 48), f"{kind} round-trip size mismatch")
                    decoded[kind] = [check.width, check.height]
        return {"status": "ready", "operations": ["rgba", "alpha-composite", "resize", "png", "jpeg", "webp", "decode"],
                "round_trip": decoded}
    except Exception as exc:
        return {"status": "blocked", "reason": str(exc)}


def binary_version(path: str, name: str) -> tuple[bool, str]:
    try:
        cp = run([path, "-version"], timeout=30)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return False, str(exc)
    line = (cp.stdout or cp.stderr).splitlines()
    return cp.returncode == 0, (line[0] if line else f"{name} returned no version text")


def ffmpeg_paths(root: Path) -> dict[str, str | None]:
    return {"ffmpeg": resolve_binary(root, "ffmpeg"), "ffprobe": resolve_binary(root, "ffprobe")}


def ffmpeg_status(root: Path) -> dict[str, Any]:
    paths = ffmpeg_paths(root)
    if not paths["ffmpeg"] or not paths["ffprobe"]:
        return {"status": "missing", "paths": paths, "reason": "ffmpeg and ffprobe are both required for the primary video backend"}
    ok1, v1 = binary_version(str(paths["ffmpeg"]), "ffmpeg")
    ok2, v2 = binary_version(str(paths["ffprobe"]), "ffprobe")
    if not (ok1 and ok2):
        return {"status": "blocked", "paths": paths, "ffmpeg_version": v1, "ffprobe_version": v2,
                "reason": "ffmpeg/ffprobe binaries are present but not executable"}
    return {"status": "ready", "paths": paths, "ffmpeg_version": v1, "ffprobe_version": v2}


def discover_windows_ffmpeg() -> dict[str, str] | None:
    local = os.environ.get("LOCALAPPDATA")
    if not local:
        return None
    bases = [Path(local) / "Microsoft" / "WinGet" / "Links", Path(local) / "Microsoft" / "WinGet" / "Packages"]
    found: dict[str, str] = {}
    for base in bases:
        if not base.exists():
            continue
        for name in ("ffmpeg.exe", "ffprobe.exe"):
            candidates = list(base.rglob(name)) if base.name == "Packages" else [base / name]
            candidate = next((p for p in candidates if p.is_file()), None)
            if candidate:
                found[name[:-4]] = str(candidate.resolve())
    return found if set(found) == {"ffmpeg", "ffprobe"} else None


def attempt_ffmpeg_install() -> dict[str, Any]:
    system = platform.system().lower()
    attempts: list[dict[str, Any]] = []
    commands: list[tuple[str, list[str]]] = []
    if system == "windows" and shutil.which("winget"):
        commands.append(("winget", ["winget", "install", "--id", "Gyan.FFmpeg", "--exact", "--silent",
                                    "--accept-package-agreements", "--accept-source-agreements"]))
    elif system == "darwin" and shutil.which("brew"):
        commands.append(("brew", ["brew", "install", "ffmpeg"]))
    elif system == "linux":
        if shutil.which("apt-get") and hasattr(os, "geteuid") and os.geteuid() == 0:
            commands.append(("apt-get", ["apt-get", "update"]))
            commands.append(("apt-get", ["apt-get", "install", "-y", "ffmpeg"]))
        elif shutil.which("dnf") and hasattr(os, "geteuid") and os.geteuid() == 0:
            commands.append(("dnf", ["dnf", "install", "-y", "ffmpeg"]))
        elif shutil.which("pacman") and hasattr(os, "geteuid") and os.geteuid() == 0:
            commands.append(("pacman", ["pacman", "-Sy", "--noconfirm", "ffmpeg"]))
    if not commands:
        return {"status": "unavailable", "attempts": [], "reason": "no safe unattended system package-manager path is available"}
    for manager, command in commands:
        try:
            cp = run(command, timeout=INSTALL_TIMEOUT)
            attempts.append({"manager": manager, "returncode": cp.returncode,
                             "detail": (cp.stderr or cp.stdout).strip()[-1200:]})
            if cp.returncode != 0:
                return {"status": "failed", "attempts": attempts}
        except (OSError, subprocess.TimeoutExpired) as exc:
            attempts.append({"manager": manager, "returncode": None, "detail": str(exc)})
            return {"status": "failed", "attempts": attempts}
    return {"status": "installed", "attempts": attempts}


def ffmpeg_smoke(root: Path) -> dict[str, Any]:
    status = ffmpeg_status(root)
    if status["status"] != "ready":
        return status
    ffmpeg = str(status["paths"]["ffmpeg"]); ffprobe = str(status["paths"]["ffprobe"])
    try:
        with tempfile.TemporaryDirectory(prefix="wxian-video-") as tmp:
            td = Path(tmp); video = td / "smoke.mp4"; frame = td / "frame.jpg"
            cp = run([ffmpeg, "-v", "error", "-f", "lavfi", "-i", "color=c=black:s=64x64:d=0.4:r=5",
                      "-an", "-c:v", "mpeg4", "-y", str(video)], timeout=60)
            require(cp.returncode == 0 and video.is_file() and video.stat().st_size > 0,
                    f"ffmpeg synthetic video failed: {(cp.stderr or cp.stdout).strip()[-400:]}")
            cp = run([ffprobe, "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height",
                      "-of", "json", str(video)], timeout=30)
            require(cp.returncode == 0 and '64' in cp.stdout, "ffprobe could not inspect synthetic video")
            cp = run([ffmpeg, "-v", "error", "-ss", "0.1", "-i", str(video), "-frames:v", "1", "-y", str(frame)], timeout=30)
            require(cp.returncode == 0 and frame.is_file() and frame.stat().st_size > 0, "ffmpeg frame extraction failed")
        return {"status": "ready", "backend": "ffmpeg", "paths": status["paths"],
                "operations": ["encode-test", "probe-test", "extract-frame-test"]}
    except Exception as exc:
        return {"status": "blocked", "backend": "ffmpeg", "paths": status.get("paths", {}), "reason": str(exc)}


def opencv_status() -> dict[str, Any]:
    try:
        import cv2  # type: ignore
        return {"status": "ready", "version": str(cv2.__version__)}
    except Exception as exc:
        return {"status": "missing", "reason": str(exc)}


def opencv_smoke() -> dict[str, Any]:
    try:
        import cv2  # type: ignore
        import numpy as np  # type: ignore
        with tempfile.TemporaryDirectory(prefix="wxian-opencv-") as tmp:
            path = Path(tmp) / "smoke.avi"
            writer = cv2.VideoWriter(str(path), cv2.VideoWriter_fourcc(*"MJPG"), 5.0, (64, 64))
            require(writer.isOpened(), "OpenCV VideoWriter is unavailable")
            frame = np.zeros((64, 64, 3), dtype=np.uint8)
            for _ in range(3):
                writer.write(frame)
            writer.release()
            cap = cv2.VideoCapture(str(path))
            require(cap.isOpened(), "OpenCV cannot reopen its smoke video")
            ok, decoded = cap.read(); cap.release()
            require(ok and decoded is not None and decoded.shape[1] == 64 and decoded.shape[0] == 64,
                    "OpenCV video decode smoke failed")
        return {"status": "ready", "backend": "opencv", "version": str(cv2.__version__),
                "operations": ["encode-test", "decode-test"]}
    except Exception as exc:
        return {"status": "blocked", "backend": "opencv", "reason": str(exc)}


def ensure_video_backend(root: Path, repair: bool) -> dict[str, Any]:
    primary = ffmpeg_smoke(root)
    repair_result: dict[str, Any] | None = None
    if primary["status"] != "ready" and repair:
        repair_result = attempt_ffmpeg_install()
        if platform.system().lower() == "windows":
            discovered = discover_windows_ffmpeg()
            if discovered:
                # Persisted below in resolved_tools; make this process able to resolve immediately too.
                for binary in discovered.values():
                    parent = str(Path(binary).parent)
                    if parent not in os.environ.get("PATH", "").split(os.pathsep):
                        os.environ["PATH"] = parent + os.pathsep + os.environ.get("PATH", "")
        primary = ffmpeg_smoke(root)
    fallback = {"status": "not_needed"}
    if primary["status"] != "ready":
        fallback = opencv_smoke() if opencv_status()["status"] == "ready" else opencv_status()
        if fallback["status"] != "ready" and repair:
            ok, detail = pip_install("opencv-python-headless")
            if ok:
                for name in [key for key in list(sys.modules) if key == "cv2" or key.startswith("cv2.")]:
                    sys.modules.pop(name, None)
                fallback = opencv_smoke()
            else:
                fallback = {"status": "blocked", "backend": "opencv", "reason": detail}
    if primary["status"] == "ready":
        return {"status": "ready", "backend": "ffmpeg", "primary": primary, "fallback": fallback,
                "repair": repair_result}
    if fallback["status"] == "ready":
        return {"status": "ready_with_fallback", "backend": "opencv", "primary": primary, "fallback": fallback,
                "repair": repair_result, "warning": "ffmpeg/ffprobe unavailable; OpenCV fallback cannot provide full audio/container evidence"}
    return {"status": "blocked", "backend": None, "primary": primary, "fallback": fallback,
            "repair": repair_result, "reason": "no verified video backend is available"}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def visual_intelligence_integrity(root: Path) -> dict[str, Any]:
    manifest_path = root / ".agents" / "skills" / "workspace-governance" / "config" / "visual-contracts" / "visual-intelligence-manifest.json"
    try:
        require(manifest_path.is_file(), "visual intelligence manifest is missing")
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        require(isinstance(manifest, dict), "visual intelligence manifest must be an object")
        require(manifest.get("schema_version") == "sicza.visual-intelligence-manifest.v1", "visual intelligence manifest schema mismatch")
        require(manifest.get("algorithm") == "sha256", "visual intelligence manifest algorithm must be sha256")
        files = manifest.get("files")
        require(isinstance(files, dict) and files, "visual intelligence manifest files must be a non-empty object")
        errors: list[str] = []
        checked = 0
        root_resolved = root.resolve()
        for rel, expected in sorted(files.items()):
            if not isinstance(rel, str) or not isinstance(expected, str):
                errors.append(f"invalid manifest entry: {rel!r}")
                continue
            path = (root / rel).resolve()
            try:
                path.relative_to(root_resolved)
            except ValueError:
                errors.append(f"manifest path escapes Workspace: {rel}")
                continue
            if not path.is_file():
                errors.append(f"missing: {rel} (Runtime-owned file: restore it from the release; "
                              "do not hand-edit a project copy)")
                continue
            actual = sha256_file(path)
            checked += 1
            if actual != expected:
                errors.append(f"sha256 mismatch: {rel} (Runtime-owned file: a change here must be made "
                              "through the owning Skill and shipped as a new Runtime release, not by editing "
                              "this project copy)")

        # The two shared visual intelligence cores are closed scopes. Adding or deleting a
        # production file without updating the manifest is itself an integrity failure.
        core_scopes = (
            ".agents/skills/workspace-governance/config/visual-contracts",
            ".agents/skills/sicza-causal-narrative-runtime",
            ".agents/skills/sicza-visual-director",
        )
        for prefix in core_scopes:
            base = root / prefix
            if not base.is_dir():
                errors.append(f"missing core scope: {prefix}")
                continue
            actual_scope = {
                path.relative_to(root).as_posix()
                for path in base.rglob("*")
                if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc"
                and path.name != "visual-intelligence-manifest.json"
            }
            declared_scope = {rel for rel in files if rel.startswith(prefix + "/")}
            for rel in sorted(actual_scope - declared_scope):
                errors.append(f"undeclared core dependency: {rel}")
            for rel in sorted(declared_scope - actual_scope):
                errors.append(f"declared core dependency missing from scope: {rel}")

        schema_ids = {
            ".agents/skills/workspace-governance/config/visual-contracts/narrative-visual-contract-schema.json": "sicza.narrative-visual-contract.v2",
            ".agents/skills/workspace-governance/config/visual-contracts/visual-spec-schema.json": "sicza.visual-spec.v2",
            ".agents/skills/workspace-governance/config/visual-contracts/prompt-binding-schema.json": "sicza.prompt-binding.v2",
            ".agents/skills/workspace-governance/config/visual-contracts/visual-gate-result-schema.json": "sicza.visual-gate-result.v2",
            ".agents/skills/workspace-governance/config/visual-contracts/baseline-consumption-schema.json": "sicza.baseline-consumption.v2",
            ".agents/skills/workspace-governance/config/visual-contracts/visual-return-schema.json": "sicza.visual-return.v1",
        }
        for rel, expected_id in schema_ids.items():
            path = root / rel
            if not path.is_file():
                errors.append(f"missing schema: {rel}")
                continue
            try:
                obj = json.loads(path.read_text(encoding="utf-8"))
                if not isinstance(obj, dict) or obj.get("$id") != expected_id:
                    errors.append(f"schema id mismatch: {rel}")
            except json.JSONDecodeError as exc:
                errors.append(f"invalid schema JSON: {rel}: {exc}")

        registry_versions = {
            ".agents/skills/workspace-governance/config/visual-contracts/visual-spec-profiles.json": "sicza.visual-spec-profiles.v1",
            ".agents/skills/workspace-governance/config/visual-contracts/visual-gate-profiles.json": "sicza.visual-gate-profiles.v1",
            ".agents/skills/workspace-governance/config/visual-contracts/prompt-compiler-profiles.json": "sicza.prompt-compiler-profiles.v1",
            ".agents/skills/workspace-governance/config/visual-contracts/visual-enforcement-profiles.json": "sicza.visual-enforcement-profiles.v1",
        }
        for rel, expected_version in registry_versions.items():
            path = root / rel
            if not path.is_file():
                errors.append(f"missing registry: {rel}")
                continue
            try:
                obj = json.loads(path.read_text(encoding="utf-8"))
                if not isinstance(obj, dict) or obj.get("schema_version") != expected_version or not isinstance(obj.get("profiles"), dict):
                    errors.append(f"registry version/shape mismatch: {rel}")
            except json.JSONDecodeError as exc:
                errors.append(f"invalid registry JSON: {rel}: {exc}")

        # Causal Runtime line-range optimization has its own hash table. Validate the table,
        # its mode manifest, every referenced source hash, and every declared line range.
        causal_root = root / ".agents" / "skills" / "sicza-causal-narrative-runtime"
        integrity_path = causal_root / "config" / "runtime-mode-integrity.json"
        mode_manifest_path = causal_root / "config" / "runtime-mode-manifest.json"
        try:
            integrity = json.loads(integrity_path.read_text(encoding="utf-8"))
            mode_manifest = json.loads(mode_manifest_path.read_text(encoding="utf-8"))
            if integrity.get("algorithm") != "sha256":
                errors.append("causal runtime integrity algorithm must be sha256")
            if integrity.get("mode_manifest_sha256") != sha256_file(mode_manifest_path):
                errors.append("causal runtime mode manifest sha256 mismatch")
            reference_hashes = integrity.get("reference_sha256")
            if not isinstance(reference_hashes, dict) or not reference_hashes:
                errors.append("causal runtime reference_sha256 must be a non-empty object")
                reference_hashes = {}
            if not isinstance(mode_manifest, dict) or set(mode_manifest) != set(reference_hashes):
                errors.append("causal runtime mode manifest/reference hash file set mismatch")
            for name, expected in sorted(reference_hashes.items()):
                reference = causal_root / "references" / str(name)
                if not reference.is_file():
                    errors.append(f"causal runtime reference missing: {name}")
                    continue
                if sha256_file(reference) != expected:
                    errors.append(f"causal runtime reference sha256 mismatch: {name}")
                    continue
                line_count = len(reference.read_text(encoding="utf-8").splitlines())
                modes = mode_manifest.get(name)
                if not isinstance(modes, dict) or not modes:
                    errors.append(f"causal runtime modes missing: {name}")
                    continue
                occupied: list[tuple[int, int, str]] = []
                for mode, ranges in modes.items():
                    if not isinstance(ranges, list) or not ranges:
                        errors.append(f"causal runtime mode has no ranges: {name}:{mode}")
                        continue
                    for value in ranges:
                        if not (isinstance(value, list) and len(value) == 2 and all(isinstance(x, int) and not isinstance(x, bool) for x in value)):
                            errors.append(f"invalid causal runtime range: {name}:{mode}:{value!r}")
                            continue
                        start, end = value
                        if start < 1 or end < start or end > line_count:
                            errors.append(f"out-of-bounds causal runtime range: {name}:{mode}:{start}-{end}/{line_count}")
                            continue
                        occupied.append((start, end, str(mode)))
                occupied.sort()
                for previous, current in zip(occupied, occupied[1:]):
                    if current[0] <= previous[1]:
                        errors.append(
                            f"overlapping causal runtime ranges: {name}:{previous[2]} {previous[0]}-{previous[1]} / "
                            f"{current[2]} {current[0]}-{current[1]}"
                        )
        except (OSError, json.JSONDecodeError) as exc:
            errors.append(f"causal runtime integrity invalid: {exc}")

        return {
            "status": "ready" if not errors else "blocked",
            "manifest": ".agents/skills/workspace-governance/config/visual-contracts/visual-intelligence-manifest.json",
            "checked_files": checked,
            "declared_files": len(files),
            "core_scopes": list(core_scopes),
            "causal_runtime_integrity": "ready" if not any(item.startswith("causal runtime") or item.startswith("invalid causal") or item.startswith("out-of-bounds causal") or item.startswith("overlapping causal") for item in errors) else "blocked",
            "errors": errors[:60],
        }
    except (RuntimeError_, OSError, json.JSONDecodeError) as exc:
        return {"status": "blocked", "reason": str(exc)}


def source_compile_smoke(root: Path) -> dict[str, Any]:
    errors: list[str] = []
    count = 0
    source_roots = (
        root / ".agents" / "scripts",
        root / ".agents" / "lib",
        root / ".agents" / "skills",
    )
    paths = sorted(
        path
        for source_root in source_roots
        if source_root.is_dir()
        for path in source_root.rglob("*.py")
        if path.is_file()
    )
    for path in paths:
        try:
            source = path.read_text(encoding="utf-8")
            compile(source, str(path), "exec")
            count += 1
        except Exception as exc:
            errors.append(f"{path.relative_to(root).as_posix()}: {exc}")
    return {"status": "ready" if not errors else "blocked", "compiled_files": count, "errors": errors[:20]}


def summarize_integrity_failure(integrity: dict[str, Any]) -> dict[str, Any]:
    errors = [str(item) for item in integrity.get("errors", []) if str(item).strip()]
    reason = str(integrity.get("reason") or "").strip()
    if reason and not errors:
        errors = [reason]
    return {
        "status": "blocked",
        "repair_available": False,
        "reason": "Runtime source integrity failed",
        "errors": errors[:60],
        "recovery_action": "Replace this project's .agents Runtime from one verified official Release ZIP; runtime-repair only repairs local execution dependencies and must not synthesize or hand-edit Runtime source files.",
    }


def script_smoke(root: Path, *, integrity: dict[str, Any] | None = None) -> dict[str, Any]:
    integrity = integrity if integrity is not None else visual_intelligence_integrity(root)
    if integrity.get("status") != "ready":
        return summarize_integrity_failure(integrity)
    commands = [
        ("generation_api_doctor", [sys.executable, str(root / ".agents/skills/image-generation-api/scripts/generation_api.py"), "doctor"]),
        ("layer_assets_doctor", [sys.executable, str(root / ".agents/skills/wxian-image-layer-decomposition/scripts/layer_assets.py"), "doctor"]),
        ("kv_layer_batch_doctor", [sys.executable, str(root / ".agents/skills/wxian-image-layer-decomposition/scripts/layer_batch.py"), "doctor"]),
        ("kv_layer_contract_selftest", [sys.executable, str(root / ".agents/skills/wxian-image-layer-decomposition/scripts/contract_selftest.py"), "--workspace-root", str(root)]),
        ("kv_layer_integration_selftest", [sys.executable, str(root / ".agents/skills/wxian-image-layer-decomposition/scripts/integration_selftest.py")]),
        ("kv_layer_finalization_selftest", [sys.executable, str(root / ".agents/skills/wxian-image-layer-decomposition/scripts/finalization_selftest.py")]),
        ("ui_layer_batch_doctor", [sys.executable, str(root / ".agents/skills/wxian-game-ui-layer-decomposition/scripts/ui_layer_batch.py"), "doctor"]),
        ("ui_layer_contract_selftest", [sys.executable, str(root / ".agents/skills/wxian-game-ui-layer-decomposition/scripts/contract_selftest.py"), "--workspace-root", str(root)]),
        ("ui_layer_finalization_selftest", [sys.executable, str(root / ".agents/skills/wxian-game-ui-layer-decomposition/scripts/finalization_selftest.py")]),
        ("psd_export_contract_selftest", [sys.executable, str(root / ".agents/skills/wxian-layered-psd-export/scripts/contract_selftest.py")]),
        ("psd_smart_object_roundtrip_selftest", [sys.executable, str(root / ".agents/skills/wxian-layered-psd-export/scripts/roundtrip_selftest.py")]),
        ("delivery_gate_import", [sys.executable, str(root / ".agents/skills/wxian-image-production/scripts/delivery_gate.py"), "--help"]),
        ("visual_contract_gate_doctor", [sys.executable, str(root / ".agents/scripts/visual_contract_gate.py"), "doctor"]),
        ("workspace_governance_doctor", [sys.executable, str(root / ".agents/skills/workspace-governance/scripts/workspace_gate.py"), "doctor", "--workspace-root", str(root)]),
    ]
    results: dict[str, Any] = {}
    ok = True
    for name, command in commands:
        try:
            cp = run(command, timeout=120)
            passed = cp.returncode == 0
            ok = ok and passed
            results[name] = {"status": "ready" if passed else "blocked", "returncode": cp.returncode,
                             "detail": (cp.stderr or cp.stdout).strip()[-1000:] if not passed else "passed"}
        except Exception as exc:
            ok = False; results[name] = {"status": "blocked", "reason": str(exc)}

    results["visual_intelligence_core"] = integrity

    # Execute the real deterministic postprocess script, not only an import check.
    try:
        from PIL import Image
        tmp_parent = root / "tmp"
        tmp_parent.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix="runtime-smoke-", dir=str(tmp_parent)) as tmp:
            base = Path(tmp) / "requests" / "image-generation" / "runtime-smoke"
            source = base / "input" / "source.png"
            output = base / "work" / "resized.webp"
            source.parent.mkdir(parents=True, exist_ok=True)
            Image.new("RGBA", (64, 64), (80, 100, 120, 255)).save(source, format="PNG")
            cp = run([sys.executable, str(root / ".agents/skills/wxian-image-production/scripts/image_postprocess.py"),
                      "resize", "--input", source.relative_to(root).as_posix(),
                      "--output", output.relative_to(root).as_posix(), "--width", "32", "--height", "32",
                      "--workspace-root", str(root)], timeout=120)
            record = output.with_name(output.name + ".operation.json")
            passed = cp.returncode == 0 and output.is_file() and record.is_file()
            if passed:
                with Image.open(output) as check:
                    check.load(); passed = check.size == (32, 32)
            ok = ok and passed
            results["image_postprocess_resize"] = {"status": "ready" if passed else "blocked",
                                                    "returncode": cp.returncode,
                                                    "detail": "passed" if passed else (cp.stderr or cp.stdout).strip()[-1000:]}
    except Exception as exc:
        ok = False; results["image_postprocess_resize"] = {"status": "blocked", "reason": str(exc)}
    return {"status": "ready" if ok else "blocked", "checks": results}


def write_state(root: Path, value: dict[str, Any]) -> None:
    path = runtime_state_path(root)
    atomic_write_text(path, json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def resolved_tools(root: Path) -> dict[str, str]:
    paths = ffmpeg_paths(root)
    if platform.system().lower() == "windows" and (not paths["ffmpeg"] or not paths["ffprobe"]):
        discovered = discover_windows_ffmpeg()
        if discovered:
            paths.update(discovered)
    return {key: str(Path(value).resolve()) for key, value in paths.items() if value and Path(value).is_file()}


def assess(root: Path, *, repair: bool) -> dict[str, Any]:
    py = python_status()
    if py["status"] != "ready":
        value = {"status": "blocked", "repair_mode": repair, "python": py, "reason": py["reason"], "resolved_tools": {}}
        write_state(root, value); return value
    if not py["virtualenv"]:
        value = {
            "status": "blocked",
            "repair_mode": repair,
            "python": py,
            "reason": "Workspace Runtime requires .agents/runtime/toolchain/venv",
            "resolved_tools": {},
        }
        write_state(root, value); return value
    integrity = visual_intelligence_integrity(root)
    if integrity.get("status") != "ready":
        source_failure = summarize_integrity_failure(integrity)
        value = {
            "status": "blocked",
            "repair_mode": repair,
            "python": py,
            "runtime_source_integrity": source_failure,
            "script_smoke": {"status": "not_run", "reason": "Runtime source integrity must pass before script smoke"},
            "reason": source_failure["reason"] + ": " + "; ".join(source_failure["errors"][:5]),
            "recovery_action": source_failure["recovery_action"],
            "resolved_tools": {},
        }
        write_state(root, value)
        return value
    pip = ensure_pip() if repair else pip_status()
    pillow = ensure_pillow() if repair and pip["status"] == "ready" else pillow_status()
    post = postprocess_smoke() if pillow["status"] == "ready" else {"status": "blocked", "reason": "Pillow runtime is not ready"}
    psd_node = ensure_psd_node(root, repair=repair)
    video = ensure_video_backend(root, repair=repair) if pip["status"] == "ready" else {"status": "blocked", "reason": "pip runtime is not ready"}
    compile_check = source_compile_smoke(root)
    scripts = script_smoke(root, integrity=integrity) if pillow["status"] == "ready" and compile_check["status"] == "ready" else {"status": "blocked", "reason": "core Python runtime is not ready"}
    required_ready = all(item["status"] == "ready" for item in (pip, pillow, post, psd_node, compile_check, scripts))
    video_ready = video.get("status") in {"ready", "ready_with_fallback"}
    status = "ready" if required_ready and video_ready else "blocked"
    value = {
        "status": status,
        "repair_mode": repair,
        "python": py,
        "pip": pip,
        "pillow": pillow,
        "postprocess": post,
        "psd_smart_object": psd_node,
        "video": video,
        "source_compile": compile_check,
        "script_smoke": scripts,
        "resolved_tools": resolved_tools(root),
    }
    if status != "ready":
        failures = [name for name, item in (("pip", pip), ("pillow", pillow), ("postprocess", post), ("psd_smart_object", psd_node), ("video", video),
                                             ("source_compile", compile_check), ("script_smoke", scripts))
                    if item.get("status") not in {"ready", "ready_with_fallback"}]
        value["failed_components"] = failures
        smoke_failures = [name for name, item in scripts.get("checks", {}).items()
                          if isinstance(item, dict) and item.get("status") != "ready"]
        if smoke_failures:
            value["failed_script_checks"] = smoke_failures
        value["reason"] = "runtime environment is not ready: " + ", ".join(failures)
        if smoke_failures:
            value["reason"] += " (failed checks: " + ", ".join(smoke_failures) + ")"
    write_state(root, value)
    return value


def assess_minimal(root: Path) -> dict[str, Any]:
    """Check only the interpreter contract required to enter a normal session."""
    py = python_status()
    pip = pip_status() if py.get("status") == "ready" and py.get("virtualenv") else {
        "status": "blocked", "reason": "Workspace Runtime requires .agents/runtime/toolchain/venv"
    }
    status = "ready" if py.get("status") == "ready" and py.get("virtualenv") and pip.get("status") == "ready" else "blocked"
    value = {
        "status": status,
        "check_mode": "minimal",
        "python": py,
        "pip": pip,
        "resolved_tools": resolved_tools(root),
    }
    if status != "ready":
        value["reason"] = str(pip.get("reason") or py.get("reason") or "core Python runtime is not ready")
    write_state(root, value)
    return value


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("command", choices=("check", "doctor", "repair"))
    ap.add_argument("--workspace-root", type=Path, default=Path(__file__).resolve().parents[2])
    args = ap.parse_args()
    root = args.workspace_root.resolve()
    try:
        require(root.is_dir(), f"Workspace root does not exist: {root}")
        result = assess_minimal(root) if args.command == "check" else assess(root, repair=args.command == "repair")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["status"] == "ready" else 2
    except (RuntimeError_, OSError, subprocess.SubprocessError) as exc:
        print(json.dumps({"status": "blocked", "reason": str(exc)}, ensure_ascii=False, indent=2))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
