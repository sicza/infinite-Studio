$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$workspaceRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$runtimeDir = Join-Path $workspaceRoot '.agents\runtime'
$credentialPath = Join-Path $runtimeDir 'credentials.json'

$form = New-Object System.Windows.Forms.Form
$form.Text = 'InfiniteBOT Codex - API Key'
$form.StartPosition = 'CenterScreen'
$form.ClientSize = New-Object System.Drawing.Size(520, 150)
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.MinimizeBox = $false
$form.TopMost = $true

$label = New-Object System.Windows.Forms.Label
$label.Text = 'Generation API Key'
$label.AutoSize = $true
$label.Location = New-Object System.Drawing.Point(20, 20)
$form.Controls.Add($label)

$textBox = New-Object System.Windows.Forms.TextBox
$textBox.Location = New-Object System.Drawing.Point(20, 48)
$textBox.Size = New-Object System.Drawing.Size(480, 24)
$textBox.UseSystemPasswordChar = $true
$form.Controls.Add($textBox)

$ok = New-Object System.Windows.Forms.Button
$ok.Text = 'Save'
$ok.DialogResult = [System.Windows.Forms.DialogResult]::OK
$ok.Location = New-Object System.Drawing.Point(330, 95)
$ok.Size = New-Object System.Drawing.Size(80, 30)
$form.Controls.Add($ok)

$cancel = New-Object System.Windows.Forms.Button
$cancel.Text = 'Cancel'
$cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$cancel.Location = New-Object System.Drawing.Point(420, 95)
$cancel.Size = New-Object System.Drawing.Size(80, 30)
$form.Controls.Add($cancel)

$form.AcceptButton = $ok
$form.CancelButton = $cancel
$form.Add_Shown({ $textBox.Focus() })
$result = $form.ShowDialog()
if ($result -ne [System.Windows.Forms.DialogResult]::OK) {
    exit 3
}

$key = $textBox.Text.Trim()
if ([string]::IsNullOrWhiteSpace($key)) {
    [System.Windows.Forms.MessageBox]::Show('API Key cannot be empty.', 'InfiniteBOT Codex', 'OK', 'Warning') | Out-Null
    exit 4
}

[System.IO.Directory]::CreateDirectory($runtimeDir) | Out-Null
$payload = @{ generation_api_key = $key } | ConvertTo-Json
$utf8 = New-Object System.Text.UTF8Encoding($false)
[System.IO.File]::WriteAllText($credentialPath, $payload + [Environment]::NewLine, $utf8)

$identity = [System.Security.Principal.WindowsIdentity]::GetCurrent().User
$acl = New-Object System.Security.AccessControl.FileSecurity
$acl.SetAccessRuleProtection($true, $false)
$rule = New-Object System.Security.AccessControl.FileSystemAccessRule($identity, 'FullControl', 'Allow')
$acl.AddAccessRule($rule)
[System.IO.File]::SetAccessControl($credentialPath, $acl)

Write-Output '{"status":"configured","credential_store":".agents/runtime/credentials.json","credential_value_exposed":false}'
exit 0
