#!/usr/bin/env sh
set -eu
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=$(CDPATH= cd -- "$SCRIPT_DIR/../.." && pwd)
cd "$ROOT"

export PYTHONUTF8=1
export PYTHONIOENCODING=utf-8

COMMAND=initialize
case "${1-}" in
  build|check|initialize|visual-check|api-check|runtime-check|runtime-repair)
    COMMAND=$1
    shift
    ;;
esac

RUNTIME_ROOT="$ROOT/.agents/runtime/toolchain"
VENV_DIR="$RUNTIME_ROOT/venv"
VENV_PYTHON="$VENV_DIR/bin/python"
LOCK_DIR="$RUNTIME_ROOT/bootstrap.lock"
mkdir -p "$RUNTIME_ROOT"

release_bootstrap_lock() {
  if [ -d "$LOCK_DIR" ] && [ "$(cat "$LOCK_DIR/pid" 2>/dev/null || true)" = "$$" ]; then
    rm -rf "$LOCK_DIR"
  fi
}

acquire_bootstrap_lock() {
  attempts=0
  while ! mkdir "$LOCK_DIR" 2>/dev/null; do
    owner_pid=$(cat "$LOCK_DIR/pid" 2>/dev/null || true)
    if [ -z "$owner_pid" ]; then
      sleep 1
      owner_pid=$(cat "$LOCK_DIR/pid" 2>/dev/null || true)
    fi
    if [ -z "$owner_pid" ] || ! kill -0 "$owner_pid" 2>/dev/null; then
      rm -rf "$LOCK_DIR"
      continue
    fi
    attempts=$((attempts + 1))
    if [ "$attempts" -ge 900 ]; then
      printf '%s\n' '{"status":"blocked","reason":"another Workspace Runtime bootstrap did not finish within 15 minutes","stage":"workspace_bootstrap_lock","retry_safe":true}'
      exit 2
    fi
    sleep 1
  done
  printf '%s\n' "$$" > "$LOCK_DIR/pid"
  trap 'release_bootstrap_lock' EXIT HUP INT TERM
}

acquire_bootstrap_lock

test_workspace_python() {
  [ -x "$1" ] && "$1" -X utf8 -c 'import sys, pathlib, tempfile, pip; p=pathlib.Path(tempfile.gettempdir()); raise SystemExit(0 if sys.version_info >= (3,10) and sys.prefix != sys.base_prefix and p.exists() else 1)' >/dev/null 2>&1
}

if test_workspace_python "$VENV_PYTHON"; then
  release_bootstrap_lock
  trap - EXIT HUP INT TERM
  set +e
  "$VENV_PYTHON" -X utf8 .agents/scripts/workspace_init.py "$COMMAND" --workspace-root . "$@"
  rc=$?
  set -e
  exit "$rc"
fi

find_python() {
  for candidate in python3 python; do
    if command -v "$candidate" >/dev/null 2>&1 && "$candidate" -X utf8 -c 'import sys, ensurepip, venv; raise SystemExit(0 if sys.version_info >= (3,10) else 1)' >/dev/null 2>&1; then
      printf '%s' "$candidate"; return 0
    fi
  done
  return 1
}

PYTHON=$(find_python || true)
if [ -z "$PYTHON" ]; then
  if command -v brew >/dev/null 2>&1; then
    brew install python
  elif [ "$(id -u 2>/dev/null || printf 1)" = "0" ] && command -v apt-get >/dev/null 2>&1; then
    apt-get update && apt-get install -y python3 python3-pip python3-venv
  elif [ "$(id -u 2>/dev/null || printf 1)" = "0" ] && command -v dnf >/dev/null 2>&1; then
    dnf install -y python3 python3-pip
  else
    printf '%s\n' '{"status":"blocked","reason":"Python 3.10+ is missing and no unattended installer is available"}'
    exit 2
  fi
  PYTHON=$(find_python || true)
fi

if [ -z "$PYTHON" ]; then
  printf '%s\n' '{"status":"blocked","reason":"Python installation completed but no compatible interpreter was found"}'
  exit 2
fi

rm -rf "$VENV_DIR"
if ! "$PYTHON" -X utf8 -m venv "$VENV_DIR"; then
  printf '%s\n' '{"status":"blocked","reason":"Workspace virtual environment creation failed"}'
  exit 2
fi

if ! test_workspace_python "$VENV_PYTHON"; then
  printf '%s\n' '{"status":"blocked","reason":"Workspace virtual environment failed the runtime probe"}'
  exit 2
fi

set +e
release_bootstrap_lock
trap - EXIT HUP INT TERM
"$VENV_PYTHON" -X utf8 .agents/scripts/workspace_init.py "$COMMAND" --workspace-root . "$@"
rc=$?
set -e
exit "$rc"
