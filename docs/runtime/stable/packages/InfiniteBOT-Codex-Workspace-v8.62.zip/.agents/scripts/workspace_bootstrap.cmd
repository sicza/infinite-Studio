@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0\..\.."

set "BOOTSTRAP_PS1=.agents\scripts\workspace_bootstrap_windows.ps1"

where pwsh.exe >nul 2>nul
if !ERRORLEVEL! EQU 0 (
  pwsh.exe -NoLogo -NoProfile -NonInteractive -Command "$PSVersionTable.PSVersion.Major" >nul 2>nul
  if !ERRORLEVEL! EQU 0 (
    pwsh.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%BOOTSTRAP_PS1%" %*
    exit /b !ERRORLEVEL!
  )
)

set "WINDOWS_POWERSHELL=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if exist "%WINDOWS_POWERSHELL%" (
  "%WINDOWS_POWERSHELL%" -NoLogo -NoProfile -NonInteractive -Command "$PSVersionTable.PSVersion.Major" >nul 2>nul
  if !ERRORLEVEL! EQU 0 (
    "%WINDOWS_POWERSHELL%" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%BOOTSTRAP_PS1%" %*
    exit /b !ERRORLEVEL!
  )
)

powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%BOOTSTRAP_PS1%" %*
exit /b %ERRORLEVEL%
