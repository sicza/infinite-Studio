$ErrorActionPreference = 'Stop'
Set-Location (Resolve-Path (Join-Path $PSScriptRoot '..\..'))

$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8'

$KnownCommands = @('build', 'check', 'initialize', 'visual-check', 'api-check', 'runtime-check', 'runtime-repair')
$RawArgs = @($args)
$Command = 'initialize'
$CommandArgs = @()
if ($RawArgs.Count -gt 0 -and $KnownCommands -contains [string]$RawArgs[0]) {
    $Command = [string]$RawArgs[0]
    if ($RawArgs.Count -gt 1) { $CommandArgs = @($RawArgs[1..($RawArgs.Count - 1)]) }
} else {
    $CommandArgs = $RawArgs
}

$runtimeRoot = Join-Path (Get-Location) '.agents\runtime\toolchain'
$uvDir = Join-Path $runtimeRoot 'uv'
$pythonDir = Join-Path $runtimeRoot 'python'
$pythonBinDir = Join-Path $runtimeRoot 'python-bin'
$venvDir = Join-Path $runtimeRoot 'venv'
$cacheDir = Join-Path $runtimeRoot 'uv-cache'
$uvExe = Join-Path $uvDir 'uv.exe'
$venvPython = Join-Path $venvDir 'Scripts\python.exe'

New-Item -ItemType Directory -Force -Path $runtimeRoot | Out-Null

# Serialize bootstrap per Workspace. Concurrent first-run invocations otherwise
# race on the same uv, managed-Python and venv directories and can leave a
# python.exe without pyvenv.cfg. A named mutex is released by Windows even if
# the owning process exits unexpectedly.
$workspaceIdentity = [System.IO.Path]::GetFullPath((Get-Location).Path).ToLowerInvariant()
$sha256 = [System.Security.Cryptography.SHA256]::Create()
try {
    $identityBytes = [System.Text.Encoding]::UTF8.GetBytes($workspaceIdentity)
    $mutexSuffix = ([System.BitConverter]::ToString($sha256.ComputeHash($identityBytes))).Replace('-', '')
}
finally {
    $sha256.Dispose()
}
$bootstrapMutex = [System.Threading.Mutex]::new($false, "Local\InfiniteBOT-Runtime-Bootstrap-$mutexSuffix")
$lockAcquired = $false
try {
    try {
        $lockAcquired = $bootstrapMutex.WaitOne([TimeSpan]::FromMinutes(15))
    }
    catch [System.Threading.AbandonedMutexException] {
        $lockAcquired = $true
    }
    if (-not $lockAcquired) {
        $result = [ordered]@{
            status = 'blocked'
            reason = 'another Workspace Runtime bootstrap did not finish within 15 minutes'
            stage = 'workspace_bootstrap_lock'
            retry_safe = $true
        }
        $result | ConvertTo-Json -Compress
        exit 2
    }
}
catch {
    $result = [ordered]@{
        status = 'blocked'
        reason = "failed to acquire Workspace Runtime bootstrap lock: $($_.Exception.Message)"
        stage = 'workspace_bootstrap_lock'
        retry_safe = $true
    }
    $result | ConvertTo-Json -Compress
    exit 2
}

function Test-WorkspacePython([string]$PythonExe) {
    if ([string]::IsNullOrWhiteSpace($PythonExe)) { return $false }
    if (-not (Test-Path -LiteralPath $PythonExe -PathType Leaf)) { return $false }
    $probe = "import sys, pathlib, tempfile, pip; p=pathlib.Path(tempfile.gettempdir()); raise SystemExit(0 if sys.version_info >= (3,10) and sys.prefix != sys.base_prefix and p.exists() else 1)"
    $previousPreference = $ErrorActionPreference
    try {
        # A partially-created venv may emit native stderr before returning a
        # non-zero exit code. Treat it as an invalid venv, not a terminating
        # PowerShell exception, so the serialized repair path can rebuild it.
        $ErrorActionPreference = 'Continue'
        & $PythonExe '-X' 'utf8' '-c' $probe *> $null
        $probeExitCode = $LASTEXITCODE
        return ($probeExitCode -eq 0)
    }
    catch {
        return $false
    }
    finally {
        $ErrorActionPreference = $previousPreference
    }
}

function Release-BootstrapMutex {
    if ($lockAcquired) {
        $bootstrapMutex.ReleaseMutex()
        $script:lockAcquired = $false
    }
    $bootstrapMutex.Dispose()
}

function Invoke-WorkspaceCommand([string]$PythonExe) {
    Release-BootstrapMutex
    & $PythonExe '-X' 'utf8' '.agents\scripts\workspace_init.py' $Command '--workspace-root' '.' @CommandArgs
    exit $LASTEXITCODE
}

function Resolve-ExistingPython {
    try {
        $candidate = & '.agents\scripts\find_python_windows.ps1' 2>$null | Select-Object -First 1
        if ($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) {
            return [string]$candidate
        }
    } catch {}
    return $null
}

function New-VenvFromPython([string]$BasePython) {
    try {
        & $BasePython '-X' 'utf8' '-m' 'venv' '--clear' $venvDir *> $null
        if ($LASTEXITCODE -eq 0 -and (Test-WorkspacePython $venvPython)) { return $true }
    } catch {}
    return $false
}

if (Test-WorkspacePython $venvPython) {
    Invoke-WorkspaceCommand $venvPython
}

$existing = Resolve-ExistingPython
if ($existing -and (New-VenvFromPython $existing)) {
    Invoke-WorkspaceCommand $venvPython
}

try {
    New-Item -ItemType Directory -Force -Path $uvDir, $pythonDir, $pythonBinDir, $cacheDir | Out-Null

    if (-not (Test-Path -LiteralPath $uvExe -PathType Leaf)) {
        $env:UV_UNMANAGED_INSTALL = $uvDir
        $env:UV_NO_MODIFY_PATH = '1'
        Invoke-RestMethod 'https://astral.sh/uv/install.ps1' | Invoke-Expression
    }

    if (-not (Test-Path -LiteralPath $uvExe -PathType Leaf)) {
        throw 'uv bootstrap did not produce uv.exe'
    }

    & $uvExe '--version' *> $null
    if ($LASTEXITCODE -ne 0) {
        throw 'uv.exe is not executable'
    }

    $env:UV_PYTHON_INSTALL_DIR = $pythonDir
    $env:UV_PYTHON_BIN_DIR = $pythonBinDir
    $env:UV_CACHE_DIR = $cacheDir
    $env:UV_PYTHON_INSTALL_REGISTRY = '0'
    $env:UV_PYTHON_NO_REGISTRY = '1'

    $managed = & $uvExe 'python' 'find' '3.12' '--managed-python' 2>$null | Select-Object -First 1
    if (-not ($managed -and (Test-Path -LiteralPath $managed -PathType Leaf))) {
        & $uvExe 'python' 'install' '3.12' '--no-registry' '--no-progress'
        if ($LASTEXITCODE -ne 0) {
            throw "uv managed Python installation failed with exit code $LASTEXITCODE"
        }
        $managed = & $uvExe 'python' 'find' '3.12' '--managed-python' 2>$null | Select-Object -First 1
    }

    if (-not ($managed -and (Test-Path -LiteralPath $managed -PathType Leaf))) {
        throw 'uv managed Python was installed but no interpreter was resolved'
    }

    & $managed '-X' 'utf8' '-c' "import sys, ensurepip, venv, pathlib, tempfile; p=pathlib.Path(tempfile.gettempdir()); raise SystemExit(0 if sys.version_info >= (3,10) and p.exists() else 1)" *> $null
    if ($LASTEXITCODE -ne 0) {
        throw 'workspace-local managed Python failed the runtime compatibility probe'
    }

    if (-not (New-VenvFromPython $managed)) {
        throw 'workspace virtual environment creation failed'
    }

    Invoke-WorkspaceCommand $venvPython
}
catch {
    $result = [ordered]@{
        status = 'blocked'
        reason = [string]$_.Exception.Message
        stage = 'workspace_local_python_bootstrap'
    }
    $result | ConvertTo-Json -Compress
    exit 2
}
