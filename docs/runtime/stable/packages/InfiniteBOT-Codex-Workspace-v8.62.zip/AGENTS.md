# Project Visual Production Workspace

一个 Workspace 对应一个项目。首次会话建立项目事实与 Visual Baseline；后续请求复用当前项目状态。

## 会话入口

新会话首个业务请求先初始化：

```text
Windows: .agents\scripts\workspace_bootstrap.cmd
macOS / Linux: sh .agents/scripts/workspace_bootstrap.sh
```

普通 Bootstrap 只确认 Workspace Python 并做最小初始化。完整 doctor、自测和可选依赖修复仅由 `runtime-check` / `runtime-repair` 执行；后者不修源码。初始化不检查 API Key。

按返回状态继续：

- `needs_project_brief`：从当前 material-index 与必要项目事实生成/刷新 `project/project-brief.md`，再重跑初始化。
- `needs_visual_baseline`：执行返回的 `baseline_request`，由 `$wxian-visual-baselines` 发布 Baseline，再重跑初始化。
- `ready`：进入当前业务目标。
- `blocked`：按机器 `reason` 处理根因。

真实生成仍在联网前强制检查 Key。重新配置：Windows `.agents\scripts\workspace_bootstrap.cmd api-check`；macOS / Linux `sh .agents/scripts/workspace_bootstrap.sh api-check`。

```text
Windows: .agents\scripts\workspace_bootstrap.cmd runtime-repair
macOS / Linux: sh .agents/scripts/workspace_bootstrap.sh runtime-repair
```

消费正式 Baseline 的视觉任务由 Governance 在新建、续接、返修和 Promote 时执行 `visual-check`。`project/references/**` 变化更新 `visual_input_fingerprint`；项目事实源变化更新 `project_fact_fingerprint`。

## 事实与上下文

事实优先级：`当前用户要求 / 当前 request input` > `Project Brief + 正式 Baseline + material-index 当前项目文件` > 专业推断。Reference 提供方法、构图、风格或机制证据，不改写项目身份。

启用 Personal Layer 时，Governance 调用 `$workspace-personal-skill` 写 `work/personal-context.json`。Primary Skill 执行 `$workspace-governance consume-personal-context --request <request> --consumer <自身名>`；不匹配/失效即阻断。生图 API 写入 Prompt 与调用证据。

Workspace 自有 Markdown/JSON/TXT/YAML 使用 UTF-8；正式文本由 Python UTF-8 writer 原子写入，Promote 前执行 text-integrity。

共享视觉能力仅作为 request辅助能力；不得建立第二 request、Canon、Baseline 或 Release Authority。Primary Skill 按阶段读取 integration Reference，机器合同与 Promote强度由 `$workspace-governance` config/script 维护。

## 新需求与路由

新目标先进入 `$workspace-demand-intake`。Intake 复用当前消息、附件、Project Brief、Baseline 和类型默认值，只补会改变执行链的 blocking 信息；续接、返修、补素材和交付直接回原 request。

`.agents/lib/request_routing.py` 是 `request_type → primary_skill → production_branch` 的唯一机器路由表。Intake 负责识别用户意图并调用 `$workspace-governance init-request`；Governance 自动创建：

```text
requests/<request_type>/【YYYYMMDD】NN-需求类型-需求标题/
```

`NN` 是当天整个 Workspace 的用户需求总序号。KV / ICON / LOGO / Banner / Store 等载体只描述业务对象；“直接产成品”与“做方案/方向”由用户执行意图区分。专业辅助研究、视频证据分析、概念探索、微动画规划、API 执行和 Delivery Audit 在当前 request 内组合，不另建辅助 request。

`wxian-image-production` 在任何 API/交付前由 `work/requirement-lock.md` 锁唯一 `production_branch`；API、Promote、Audit 都读取该机器事实。

Personal Skill 的加载范围在沉淀完成时由用户确认一次：`global` 或当前机器路由表中的单个/多个 `request_type`。Governance 每次只解析 registry，不预读所有个人 Skill 正文；只有命中的 Skill 文件才进入当前需求上下文。若同一需求类型命中多个 Personal Skill，则全部属于用户明确授权的当前类型能力并按 registry 一并加载。

## 请求生命周期

新目标创建新 request；未完成任务用 `resolve-request` 续接；“上一张/刚交付”用 `resolve-latest`，已完成任务返修改走 `revise-request` 并保持同一 request 的 revision lineage。

返修定位最早责任层：`requirement/reference → visual requirement → prompt → model edit/retry → layout/recompose → deterministic postprocess → delivery`。首版确认或自动继续授权的用户原话写入当前 `request.md`，再由候选脚本登记 confirmed candidate。

项目原始资料保持现实目录与文件名。Workspace 派生产物进入 `project/` 的索引/Brief/Baseline、`requests/`、`user/`、`tmp/`；`.agents/` 保存运行能力与本机 Runtime。`user/` 是可整目录复制到其他 Project Workspace 的用户长期层，不属于项目事实或公共 Runtime。

## 交付

最终阶段实际打开关键输入与正式文件。文件、Hash、尺寸、文案、资产版本、Reference、API call、operation lineage 和交付矩阵由对应 Gate 验证；主观视觉判断交给用户或专业 Scorecard。

用户交付型 request 由 `$workspace-governance promote` 写入 `completed` 并生成正式 revision/output manifest；Canonical Baseline 由其专用 publish/complete gate 完成。Promote 后 `$workspace-user-feedback` 登记本次 revision；实际交付后询问一次 1–5 分，评分不改变已验证的 completion 状态。若已交付但 Promote 未完成，评分写入 `pending_delivery`，同一 request + revision Promote 后对账；不得伪造 manifest 或丢弃反馈。


子 Agent 处理输入固定、边界明确、可独立验证的子任务；主 Agent负责需求判断、创意收敛、事实合并与最终交付。模板、Skill、脚本与 Runtime 契约在 Canonical Mother 维护。
